import express from "express";
import cors from "cors";
import { Request, Response } from "express";
import { fetch } from "undici";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Environment variables
const HOT51_CF_WORKER_URL = process.env.HOT51_CF_WORKER_URL || "https://hot51-proxy.feryputrafer.workers.dev";
const HOT51_PROXY_URL = process.env.HOT51_PROXY_URL || "";
const HOT51_STREAM_KEY = process.env.HOT51_STREAM_KEY || "";

// In-memory cache for room data (short-lived to avoid stale tokens)
let roomCache: any = null;
let roomCacheTime = 0;
const CACHE_TTL = 15000; // 15 seconds max cache

// Middleware
app.use(cors({
  origin: ["http://localhost:5173", "http://localhost:3000", "*"],
  credentials: true,
}));
app.use(express.json());

// ─── Helpers ─────────────────────────────────────────────────────

async function fetchComHubRooms(limit = 30): Promise<any[]> {
  const comhubUrl = `${HOT51_CF_WORKER_URL}/comhub?path=/vchat/app/live/livingList`;
  const res = await fetch(comhubUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "token": "guest",
      "userId": "0",
    },
    body: JSON.stringify({ page: 1, pageSize: limit }),
  });
  if (!res.ok) throw new Error(`ComHub API ${res.status}`);
  const data = await res.json() as any;
  return data.data?.list || [];
}

function getRealStreamUrl(room: any): { streamUrl: string; hlsUrl?: string } {
  const hlsUrl = room.pullAddr265 || room.hlsUrl || "";
  const streamUrl = room.pullAddr || room.streamUrl || "";
  return { streamUrl, hlsUrl: hlsUrl || undefined };
}

function wrapWithCfWorker(rawUrl: string): string {
  if (!HOT51_CF_WORKER_URL) return rawUrl;
  return `${HOT51_CF_WORKER_URL}?url=${encodeURIComponent(rawUrl)}`;
}

// ─── Health & Status ──────────────────────────────────────────────

app.get("/api/health", (_req: Request, res: Response) => {
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    version: "1.0.0",
    cfWorker: HOT51_CF_WORKER_URL ? "configured" : "not set",
    proxy: HOT51_PROXY_URL ? "configured" : "not set",
  });
});

app.get("/api/cf-worker-status", (_req: Request, res: Response) => {
  res.json({
    configured: !!HOT51_CF_WORKER_URL,
    url: HOT51_CF_WORKER_URL ? HOT51_CF_WORKER_URL.replace(/\/\?.*$/, "") : null,
  });
});

app.get("/api/proxy-status", (_req: Request, res: Response) => {
  res.json({
    configured: !!HOT51_PROXY_URL,
    url: HOT51_PROXY_URL ? HOT51_PROXY_URL.replace(/:\/\/.*@/, "://***@") : null,
  });
});

app.get("/api/session-status", (_req: Request, res: Response) => {
  res.json({
    loggedIn: false,
    username: null,
    message: "Guest session",
  });
});

// ─── Live Rooms ───────────────────────────────────────────────────

app.get("/api/live-rooms", async (_req: Request, res: Response) => {
  try {
    const limit = parseInt(req.query.limit as string) || 30;

    const now = Date.now();
    if (roomCache && now - roomCacheTime < CACHE_TTL) {
      return res.json({
        success: true,
        rooms: roomCache,
        total: roomCache.length,
        source: "cache",
        proxy: HOT51_PROXY_URL ? "active" : "not set",
      });
    }

    const list = await fetchComHubRooms(limit);

    const rooms = list.map((room: any, i: number) => {
      const urls = getRealStreamUrl(room);
      return {
        id: room.id || room.anchorId || `room-${i}`,
        anchorId: room.anchorId || room.id,
        liveId: room.liveId || room.id,
        name: room.anchorNickname || room.name || "Streamer",
        viewers: room.onlineCount || 0,
        cover: room.coverUrl || "",
        avatar: room.anchorAvatarUrl || `https://api.dicebear.com/7.x/avataaars/svg?seed=${room.anchorId || room.id || i}`,
        liveName: room.liveName || "Live Stream",
        streamUrl: urls.streamUrl,
        hlsUrl: urls.hlsUrl,
      };
    });

    roomCache = rooms;
    roomCacheTime = now;

    res.json({
      success: true,
      rooms,
      total: rooms.length,
      source: "live",
      proxy: HOT51_PROXY_URL ? "active" : "not set",
    });
  } catch (error: any) {
    console.error("[live-rooms] ERROR:", error.message);
    if (roomCache) {
      return res.json({
        success: true,
        rooms: roomCache,
        total: roomCache.length,
        source: "stale-cache",
        warning: error.message,
      });
    }
    res.status(502).json({
      success: false,
      error: error.message || "Failed to fetch live rooms",
      proxy: HOT51_PROXY_URL ? "active" : "not set",
    });
  }
});

// ─── HLS Proxy (manifest) ─────────────────────────────────────────

app.get("/api/hls-proxy", async (req: Request, res: Response) => {
  const startTime = Date.now();
  const roomId = req.query.room as string;
  const rawUrl = req.query.url as string;

  try {
    let targetUrl: string;
    let mode = "direct";

    if (roomId) {
      const list = await fetchComHubRooms(100);
      const room = list.find((r: any) => r.anchorId === roomId || r.id === roomId);
      if (!room) {
        return res.status(404).json({ error: "Room not found", roomId });
      }
      const urls = getRealStreamUrl(room);
      targetUrl = urls.hlsUrl || urls.streamUrl;
      if (!targetUrl) {
        return res.status(404).json({ error: "No stream URL for room", roomId });
      }
      mode = "room-fetch";
    } else if (rawUrl) {
      targetUrl = rawUrl;
      mode = "url-direct";
    } else {
      return res.status(400).json({ error: "Missing ?room or ?url parameter" });
    }

    // Try Cloudflare Worker first
    const cfUrl = wrapWithCfWorker(targetUrl);
    const cfRes = await fetch(cfUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36",
        "Accept": "*/*",
        "Referer": "https://hot51.com/",
      },
    });

    if (cfRes.ok) {
      const body = await cfRes.text();
      // Rewrite relative TS URLs in manifest to use our /api/ts-proxy
      const base = new URL(targetUrl);
      const rewritten = body.replace(
        /^(?!#)([^\r\n]+)$/gm,
        (line: string) => {
          if (!line.trim() || line.startsWith("#")) return line;
          try {
            const segUrl = new URL(line, base).href;
            return `/api/ts-proxy?url=${encodeURIComponent(segUrl)}`;
          } catch { return line; }
        }
      );

      res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
      res.setHeader("X-Proxy-Mode", "cloudflare");
      res.setHeader("X-Proxy-By", "scrollap1-backend");
      res.setHeader("X-Response-Time", `${Date.now() - startTime}ms`);
      res.send(rewritten);
      console.log(`[hls-proxy] OK ${mode} via cloudflare ${Date.now() - startTime}ms`);
      return;
    }

    // Fallback: direct fetch
    const directRes = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
        "Accept": "*/*",
        "Referer": "https://hot51.com/",
      },
    });

    if (!directRes.ok) {
      throw new Error(`Direct fetch failed: ${directRes.status}`);
    }

    const body = await directRes.text();
    res.setHeader("Content-Type", "application/vnd.apple.mpegurl");
    res.setHeader("X-Proxy-Mode", "direct");
    res.setHeader("X-Proxy-By", "scrollap1-backend");
    res.send(body);
    console.log(`[hls-proxy] OK ${mode} via direct ${Date.now() - startTime}ms`);

  } catch (error: any) {
    console.error(`[hls-proxy] ERROR ${mode}:`, error.message);
    res.status(502).json({
      error: error.message,
      mode,
      roomId: roomId || undefined,
      time: `${Date.now() - startTime}ms`,
    });
  }
});

// ─── TS Proxy (segments) ────────────────────────────────────────

app.get("/api/ts-proxy", async (req: Request, res: Response) => {
  const startTime = Date.now();
  const rawUrl = req.query.url as string;

  if (!rawUrl) {
    return res.status(400).json({ error: "Missing ?url parameter" });
  }

  let mode = "direct";

  try {
    // Step 1: Try Cloudflare Worker first
    if (HOT51_CF_WORKER_URL) {
      const cfUrl = wrapWithCfWorker(rawUrl);
      const cfHeaders: any = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36",
        "Accept": "*/*",
        "Referer": "https://hot51.com/",
      };
      if (req.headers.range) {
        cfHeaders["Range"] = req.headers.range;
      }

      try {
        const cfRes = await fetch(cfUrl, { headers: cfHeaders });
        if (cfRes.ok || cfRes.status === 206) {
          res.setHeader("Content-Type", cfRes.headers.get("content-type") || "video/mp2t");
          res.setHeader("X-Proxy-Mode", "cloudflare");
          res.setHeader("X-Proxy-By", "scrollap1-backend");
          res.setHeader("X-Response-Time", `${Date.now() - startTime}ms`);
          if (req.headers.range) {
            res.setHeader("Accept-Ranges", "bytes");
            res.setHeader("Content-Range", cfRes.headers.get("content-range") || "");
          }
          const body = await cfRes.arrayBuffer();
          res.status(cfRes.status).send(Buffer.from(body));
          console.log(`[ts-proxy] OK via cloudflare ${Date.now() - startTime}ms | ${rawUrl.slice(0, 60)}...`);
          return;
        }
      } catch (cfErr: any) {
        console.log(`[ts-proxy] CF fallback: ${cfErr.message}`);
      }
    }

    // Step 2: Direct fetch
    const directHeaders: any = {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
      "Accept": "*/*",
      "Referer": "https://hot51.com/",
    };
    if (req.headers.range) {
      directHeaders["Range"] = req.headers.range;
    }

    const directRes = await fetch(rawUrl, { headers: directHeaders });

    if (!directRes.ok && directRes.status !== 206) {
      throw new Error(`Direct fetch failed: ${directRes.status}`);
    }

    res.setHeader("Content-Type", directRes.headers.get("content-type") || "video/mp2t");
    res.setHeader("X-Proxy-Mode", "direct");
    res.setHeader("X-Proxy-By", "scrollap1-backend");
    if (req.headers.range) {
      res.setHeader("Accept-Ranges", "bytes");
      res.setHeader("Content-Range", directRes.headers.get("content-range") || "");
    }
    const body = await directRes.arrayBuffer();
    res.status(directRes.status).send(Buffer.from(body));
    console.log(`[ts-proxy] OK via direct ${Date.now() - startTime}ms | ${rawUrl.slice(0, 60)}...`);

  } catch (error: any) {
    console.error(`[ts-proxy] ERROR ${mode}:`, error.message, rawUrl.slice(0, 80));
    res.status(502).json({
      error: error.message,
      mode,
      url: rawUrl.slice(0, 100) + "...",
      time: `${Date.now() - startTime}ms`,
    });
  }
});

// ─── Stream Proxy (legacy) ──────────────────────────────────────

app.get("/api/stream-proxy", async (req: Request, res: Response) => {
  try {
    const { roomId, anchorId } = req.query;

    if (!roomId && !anchorId) {
      return res.status(400).json({ error: "roomId or anchorId required" });
    }

    const list = await fetchComHubRooms(100);
    const room = list.find(
      (r: any) => r.anchorId === roomId || r.id === roomId || r.anchorId === anchorId
    );

    if (!room) {
      return res.status(404).json({ success: false, error: "Room not found" });
    }

    const urls = getRealStreamUrl(room);

    res.json({
      success: true,
      streamUrl: urls.streamUrl,
      hlsUrl: urls.hlsUrl,
      cover: room.coverUrl,
      name: room.anchorNickname,
    });
  } catch (error: any) {
    res.status(502).json({
      success: false,
      error: error.message || "Failed to proxy stream",
    });
  }
});

// ─── Live Next ──────────────────────────────────────────────────

app.post("/api/live-next", async (req: Request, res: Response) => {
  try {
    const { anchorId } = req.body;
    if (!anchorId) {
      return res.status(400).json({ success: false, error: "anchorId required" });
    }

    const list = await fetchComHubRooms(100);
    const currentIndex = list.findIndex(
      (r: any) => r.anchorId === anchorId || r.id === anchorId
    );

    const nextRoom = list[currentIndex + 1] || list[0];

    if (nextRoom) {
      const urls = getRealStreamUrl(nextRoom);
      return res.json({
        success: true,
        data: {
          room: {
            anchorId: nextRoom.anchorId || nextRoom.id,
            liveId: nextRoom.liveId || nextRoom.id,
            name: nextRoom.anchorNickname || nextRoom.name,
            viewers: nextRoom.onlineCount || 0,
            cover: nextRoom.coverUrl,
            avatar: nextRoom.anchorAvatarUrl,
            liveName: nextRoom.liveName,
            streamUrl: urls.streamUrl,
            hlsUrl: urls.hlsUrl,
          },
        },
      });
    }

    res.json({ success: false, error: "No more rooms available" });
  } catch (error: any) {
    res.status(502).json({
      success: false,
      error: error.message || "Failed to fetch next room",
    });
  }
});

// ─── Generic ComHub Proxy ───────────────────────────────────────

app.all("/api/comhub/*", async (req: Request, res: Response) => {
  try {
    const path = req.path.replace("/api/comhub", "");
    const targetUrl = `${HOT51_CF_WORKER_URL}/comhub?path=${path}`;

    const response = await fetch(targetUrl, {
      method: req.method,
      headers: {
        "Content-Type": "application/json",
        ...req.headers,
      } as any,
      body: req.method !== "GET" && req.method !== "HEAD" ? JSON.stringify(req.body) : undefined,
    });

    const data = await response.text();
    res.status(response.status).type(response.headers.get("content-type") || "application/json").send(data);
  } catch (error: any) {
    res.status(502).json({ error: error.message });
  }
});

// ─── Serve frontend in production ───────────────────────────────

if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../../frontend/dist")));
  app.get("*", (_req: Request, res: Response) => {
    res.sendFile(path.join(__dirname, "../../frontend/dist/index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`🚀 Scrollap1 API Server running on port ${PORT}`);
  console.log(`📡 Hot51 Worker: ${HOT51_CF_WORKER_URL}`);
  console.log(`🔑 Proxy configured: ${HOT51_PROXY_URL ? "Yes" : "No"}`);
  console.log(`🎯 Ready to serve live streams!`);
});
