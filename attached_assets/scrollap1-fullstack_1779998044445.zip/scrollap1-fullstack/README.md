# Scrollap1 Fullstack

TikTok-style live streaming application with Hot51 integration.

## Structure

- `frontend/` - React + Vite + Tailwind CSS UI
- `backend/` - Express.js API Server
- `worker/` - Cloudflare Worker proxy for Hot51

## Quick Start

```bash
# Install all dependencies
npm run install:all

# Copy environment variables
cp .env.example .env
# Edit .env with your actual values

# Run both frontend and backend
npm run dev
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `HOT51_CF_WORKER_URL` | Cloudflare Worker URL for proxy |
| `HOT51_PROXY_URL` | Proxy URL for Hot51 API |
| `HOT51_STREAM_KEY` | Stream key for authentication |
| `PORT` | Backend server port |
| `JWT_SECRET` | Secret for JWT tokens |

## API Endpoints

- `GET /api/health` - Health check
- `GET /api/live-rooms` - Get live rooms from Hot51
- `POST /api/live-next` - Get next live room
- `GET /api/stream-proxy` - Proxy stream URL
- `GET /api/session-status` - Check session status

## Deployment

### Frontend
Build: `npm run build:frontend`
Deploy `frontend/dist/` to any static hosting.

### Backend
Build: `npm run build:backend`
Start: `cd backend && npm start`

### Cloudflare Worker
Copy `worker/hot51-proxy.js` to your Cloudflare Worker.
