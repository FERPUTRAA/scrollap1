import React, { useState } from "react";
import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "sonner";
import { AnimatePresence, motion } from "framer-motion";

import BottomNav from "./components/BottomNav";
import Feed from "./pages/Feed";
import Discover from "./pages/Discover";
import Create from "./pages/Create";
import Inbox from "./pages/Inbox";
import Profile from "./pages/Profile";
import ComHub from "./pages/ComHub";
import NotFound from "./pages/not-found";

const pageTransition = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
  transition: { duration: 0.2 }
};

function AppContent() {
  const [location, setLocation] = useLocation();

  const handleTabChange = (path: string) => {
    setLocation(path);
  };

  const showNav = ["/", "/discover", "/create", "/inbox", "/profile"].includes(location);

  return (
    <div className="h-screen w-full bg-black text-white overflow-hidden flex flex-col">
      <div className="flex-1 overflow-hidden relative">
        <AnimatePresence mode="wait">
          <Switch>
            <Route path="/">
              <motion.div key="feed" {...pageTransition} className="h-full">
                <Feed />
              </motion.div>
            </Route>
            <Route path="/discover">
              <motion.div key="discover" {...pageTransition} className="h-full">
                <Discover />
              </motion.div>
            </Route>
            <Route path="/create">
              <motion.div key="create" {...pageTransition} className="h-full">
                <Create />
              </motion.div>
            </Route>
            <Route path="/inbox">
              <motion.div key="inbox" {...pageTransition} className="h-full">
                <Inbox />
              </motion.div>
            </Route>
            <Route path="/profile">
              <motion.div key="profile" {...pageTransition} className="h-full">
                <Profile />
              </motion.div>
            </Route>
            <Route path="/comhub">
              <motion.div key="comhub" {...pageTransition} className="h-full">
                <ComHub />
              </motion.div>
            </Route>
            <Route>
              <motion.div key="notfound" {...pageTransition} className="h-full">
                <NotFound />
              </motion.div>
            </Route>
          </Switch>
        </AnimatePresence>
      </div>

      {showNav && (
        <BottomNav activeTab={location} onTabChange={handleTabChange} />
      )}

      <Toaster 
        position="top-center" 
        toastOptions={{
          style: {
            background: '#1a1a1a',
            color: '#fff',
            border: '1px solid #333',
          },
        }}
      />
    </div>
  );
}

function App() {
  return <AppContent />;
}

export default App;