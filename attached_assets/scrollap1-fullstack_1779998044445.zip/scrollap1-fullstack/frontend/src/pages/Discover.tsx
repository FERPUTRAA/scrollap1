import React, { useState } from "react";
import { Search, TrendingUp, Hash, Users } from "lucide-react";
import { motion } from "framer-motion";

const categories = [
  { id: "all", name: "Semua", icon: TrendingUp },
  { id: "gaming", name: "Gaming", icon: Hash },
  { id: "music", name: "Musik", icon: Hash },
  { id: "dance", name: "Dance", icon: Hash },
  { id: "talk", name: "Talk Show", icon: Users },
];

const trendingStreams = [
  { id: "1", title: "Live Gaming Malam", host: "GamerPro", viewers: 12500, category: "gaming", thumbnail: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400" },
  { id: "2", title: "Karaoke Bareng", host: "Singer123", viewers: 8900, category: "music", thumbnail: "https://images.unsplash.com/photo-1516280440614-6697288d5d38?w=400" },
  { id: "3", title: "Dance Challenge", host: "DancerX", viewers: 15600, category: "dance", thumbnail: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=400" },
  { id: "4", title: "Ngobrol Santai", host: "TalkMaster", viewers: 6700, category: "talk", thumbnail: "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=400" },
  { id: "5", title: "Mobile Legends Rank", host: "MLPro", viewers: 22100, category: "gaming", thumbnail: "https://images.unsplash.com/photo-1552820728-8b83bb6b2b0a?w=400" },
  { id: "6", title: "Acoustic Session", host: "GuitarHero", viewers: 9800, category: "music", thumbnail: "https://images.unsplash.com/photo-1510915361894-db8b60106cb1?w=400" },
];

const topCreators = [
  { id: "1", name: "StreamerKing", followers: "2.5M", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=king" },
  { id: "2", name: "QueenLive", followers: "1.8M", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=queen" },
  { id: "3", name: "ProGamer", followers: "1.2M", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=gamer" },
  { id: "4", name: "DanceMaster", followers: "980K", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=dance" },
];

export default function Discover() {
  const [activeCategory, setActiveCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = trendingStreams.filter((s) => {
    const matchesCategory = activeCategory === "all" || s.category === activeCategory;
    const matchesSearch = s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.host.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="h-full bg-black overflow-y-auto no-scrollbar">
      {/* Search bar */}
      <div className="sticky top-0 z-20 bg-black/95 backdrop-blur-md px-4 py-3">
        <div className="relative">
          <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari streamer, kategori, atau tag..."
            className="w-full bg-white/10 rounded-full pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-1 focus:ring-white/30"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="flex gap-2 px-4 py-3 overflow-x-auto no-scrollbar">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? "bg-white text-black"
                  : "bg-white/10 text-white/70 hover:bg-white/20"
              }`}
            >
              <Icon size={14} />
              {cat.name}
            </button>
          );
        })}
      </div>

      {/* Trending Streams */}
      <div className="px-4 py-2">
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <TrendingUp size={20} className="text-red-500" />
          Trending Live
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {filtered.map((stream) => (
            <motion.div
              key={stream.id}
              whileTap={{ scale: 0.95 }}
              className="relative aspect-[3/4] rounded-xl overflow-hidden bg-white/5"
            >
              <img
                src={stream.thumbnail}
                alt={stream.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 bg-red-500 rounded text-[10px] font-bold text-white live-badge">
                <div className="w-1.5 h-1.5 bg-white rounded-full" />
                LIVE
              </div>
              <div className="absolute bottom-2 left-2 right-2">
                <p className="text-sm font-semibold line-clamp-1">{stream.title}</p>
                <p className="text-xs text-white/70">@{stream.host}</p>
                <div className="flex items-center gap-1 mt-1 text-xs text-white/50">
                  <Users size={10} />
                  {(stream.viewers / 1000).toFixed(1)}K menonton
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Top Creators */}
      <div className="px-4 py-4">
        <h2 className="text-lg font-bold mb-3">Top Creators</h2>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
          {topCreators.map((creator) => (
            <motion.div
              key={creator.id}
              whileTap={{ scale: 0.95 }}
              className="flex flex-col items-center gap-2 min-w-[80px]"
            >
              <div className="relative">
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-16 h-16 rounded-full border-2 border-pink-500 object-cover"
                />
                <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="white">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
              </div>
              <p className="text-xs font-medium text-center">{creator.name}</p>
              <p className="text-[10px] text-white/50">{creator.followers}</p>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="h-20" />
    </div>
  );
}