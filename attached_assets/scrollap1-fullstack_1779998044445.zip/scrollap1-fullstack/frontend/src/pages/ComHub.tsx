import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Radio,
  Search,
  Eye,
  Heart,
  MessageCircle,
  Gift,
  ArrowLeft,
  Loader2,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import LivePlayer from "../components/LivePlayer";

const API_BASE = import.meta.env.VITE_API_URL || "";
const CF_WORKER = import.meta.env.VITE_HOT51_CF_WORKER_URL || "https://hot51-proxy.feryputrafer.workers.dev";

interface ComHubRoom {
  id: string;
  anchorId: string;
  name: string;
  avatar: string;
  cover: string;
  viewers: number;
  title: string;
  streamUrl: string;
  hlsUrl?: string;
  tags: string[];
}

export default function ComHub() {
  const [rooms, setRooms] = useState<ComHubRoom[]>([]);
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState("");
  const [selectedRoom, setSelectedRoom] = useState<ComHubRoom | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterTag, setFilterTag] = useState("all");

  const fetchComHubRooms = useCallback(async () => {
    setStatus("loading");
    try {
      const res = await fetch(`${API_BASE}/api/live-rooms?limit=50`);

      if (!res.ok) throw new Error(`HTTP ${res.status}`);

      const data = await res.json();

      if (data.success && data.rooms && Array.isArray(data.rooms)) {
        const mapped = data.rooms.map((room: any, i: number) => ({
          id: room.id || room.anchorId || `room-${i}`,
          anchorId: room.anchorId || room.id,
          name: room.name || "Streamer",
          avatar: room.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${i}`,
          cover: room.cover || "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800",
          viewers: room.viewers || 0,
          title: room.liveName || room.title || "Live Stream",
          streamUrl: room.streamUrl || "",
          hlsUrl: room.hlsUrl,
          tags: ["Live"],
        }));
        setRooms(mapped);
        setStatus("ok");
      } else {
        throw new Error(data.error || "Format data tidak valid");
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : "Gagal memuat data");
      setStatus("error");
    }
  }, []);

  useEffect(() => {
    fetchComHubRooms();
  }, [fetchComHubRooms]);

  const filteredRooms = rooms.filter((room) => {
    const matchesSearch =
      room.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      room.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTag = filterTag === "all" || room.tags.includes(filterTag);
    return matchesSearch && matchesTag;
  });

  const allTags = Array.from(new Set(rooms.flatMap((r) => r.tags)));

  if (selectedRoom) {
    return (
      <div className="h-full bg-black relative">
        <LivePlayer
          src={selectedRoom.streamUrl}
          hlsUrl={selectedRoom.hlsUrl}
          cover={selectedRoom.cover}
          anchorId={selectedRoom.anchorId}
          autoPlay={true}
          muted={true}
        />

        {/* Top bar */}
        <div className="absolute top-0 inset-x-0 z-30 flex items-center gap-3 p-4 bg-gradient-to-b from-black/60 to-transparent">
          <button
            onClick={() => setSelectedRoom(null)}
            className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="flex-1">
            <p className="text-sm font-semibold">{selectedRoom.name}</p>
            <div className="flex items-center gap-1 text-xs text-white/60">
              <Radio size={10} className="text-red-500 live-badge" />
              <span>LIVE</span>
              <span>·</span>
              <Eye size={10} />
              <span>{selectedRoom.viewers.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Bottom info */}
        <div className="absolute bottom-0 inset-x-0 z-20 p-4 bg-gradient-to-t from-black/80 to-transparent">
          <div className="flex items-center gap-3 mb-3">
            <img
              src={selectedRoom.avatar}
              alt={selectedRoom.name}
              className="w-10 h-10 rounded-full border border-white/30 object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedRoom.name}`;
              }}
            />
            <div>
              <p className="text-sm font-semibold">@{selectedRoom.name}</p>
              <p className="text-xs text-white/60">{selectedRoom.title}</p>
            </div>
            <button className="ml-auto px-4 py-1.5 bg-white text-black rounded-full text-xs font-semibold">
              Ikuti
            </button>
          </div>

          <div className="flex items-center gap-4">
            <button className="flex items-center gap-1 text-white/80">
              <Heart size={20} />
              <span className="text-xs">Suka</span>
            </button>
            <button className="flex items-center gap-1 text-white/80">
              <MessageCircle size={20} />
              <span className="text-xs">Chat</span>
            </button>
            <button className="flex items-center gap-1 text-white/80">
              <Gift size={20} />
              <span className="text-xs">Gift</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full bg-black overflow-y-auto no-scrollbar">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-black/95 backdrop-blur-md px-4 py-3">
        <div className="flex items-center gap-3 mb-3">
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Radio size={20} className="text-red-500 live-badge" />
            ComHub Live
          </h1>
        </div>

        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari streamer..."
            className="w-full bg-white/10 rounded-full pl-10 pr-4 py-2 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-1 focus:ring-white/30"
          />
        </div>
      </div>

      {/* Filter tags */}
      <div className="flex gap-2 px-4 py-2 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setFilterTag("all")}
          className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
            filterTag === "all" ? "bg-white text-black" : "bg-white/10 text-white/60"
          }`}
        >
          Semua
        </button>
        {allTags.slice(0, 10).map((tag) => (
          <button
            key={tag}
            onClick={() => setFilterTag(tag)}
            className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
              filterTag === tag ? "bg-white text-black" : "bg-white/10 text-white/60"
            }`}
          >
            {tag}
          </button>
        ))}
      </div>

      {/* Content */}
      {status === "loading" && (
        <div className="h-64 flex flex-col items-center justify-center gap-3">
          <Loader2 size={32} className="text-white/40 animate-spin" />
          <p className="text-sm text-white/60">Memuat siaran ComHub...</p>
        </div>
      )}

      {status === "error" && (
        <div className="h-64 flex flex-col items-center justify-center gap-3 px-8">
          <AlertTriangle size={32} className="text-red-400" />
          <p className="text-sm text-white/60 text-center">{errorMsg}</p>
          <button
            onClick={fetchComHubRooms}
            className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-full text-sm transition-colors"
          >
            <RefreshCw size={14} />
            Coba Lagi
          </button>
        </div>
      )}

      {status === "ok" && (
        <div className="grid grid-cols-2 gap-3 px-4 py-2">
          {filteredRooms.map((room) => (
            <motion.div
              key={room.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedRoom(room)}
              className="relative aspect-[3/4] rounded-xl overflow-hidden bg-white/5 cursor-pointer"
            >
              <img
                src={room.cover}
                alt={room.name}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800";
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />

              <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 bg-red-500 rounded text-[10px] font-bold text-white live-badge">
                <div className="w-1.5 h-1.5 bg-white rounded-full" />
                LIVE
              </div>

              <div className="absolute bottom-2 left-2 right-2">
                <div className="flex items-center gap-2 mb-1">
                  <img
                    src={room.avatar}
                    alt={room.name}
                    className="w-6 h-6 rounded-full object-cover border border-white/30"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${room.name}`;
                    }}
                  />
                  <span className="text-xs font-medium truncate">@{room.name}</span>
                </div>
                <p className="text-[10px] text-white/70 line-clamp-1">{room.title}</p>
                <div className="flex items-center gap-2 mt-1 text-[10px] text-white/50">
                  <span className="flex items-center gap-0.5">
                    <Eye size={10} />
                    {(room.viewers / 1000).toFixed(1)}K
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {status === "ok" && filteredRooms.length === 0 && (
        <div className="h-64 flex items-center justify-center">
          <p className="text-sm text-white/40">Tidak ada streamer yang cocok</p>
        </div>
      )}

      <div className="h-20" />
    </div>
  );
}