import React, { useState, useEffect, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Radio, AlertTriangle, RefreshCw, WifiOff } from "lucide-react";
import VideoCard from "../components/VideoCard";

const API_BASE = import.meta.env.VITE_API_URL || "";

interface LiveRoom {
  id: string;
  anchorId: string;
  liveId: string;
  name: string;
  viewers: number;
  cover: string;
  avatar: string;
  liveName: string;
  streamUrl: string;
  hlsUrl?: string;
}

interface ApiResponse {
  success: boolean;
  rooms?: LiveRoom[];
  total?: number;
  error?: string;
  proxy?: string;
  source?: string;
}

function formatCount(n: number): string {
  if (n >= 1000000) return (n / 1000000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return n.toString();
}

function mapRoomToVideo(room: LiveRoom, index: number = 0) {
  return {
    id: room.id || room.anchorId || String(index),
    anchorId: room.anchorId || room.id,
    username: room.name || "Streamer",
    avatar: room.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${room.anchorId || room.id}`,
    description: room.liveName || `Live streaming oleh ${room.name}`,
    music: "Original Sound - Hot51 Live",
    likes: formatCount(Math.floor(room.viewers * 0.3)),
    comments: formatCount(Math.floor(room.viewers * 0.1)),
    shares: formatCount(Math.floor(room.viewers * 0.05)),
    viewers: room.viewers || 0,
    streamUrl: room.streamUrl || "",
    hlsUrl: room.hlsUrl,
    cover: room.cover || "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800",
    isLive: true,
  };
}

export default function Feed() {
  const [videos, setVideos] = useState<ReturnType<typeof mapRoomToVideo>[]>([]);
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading");
  const [errorMsg, setErrorMsg] = useState("");
  const [isGeoBlocked, setIsGeoBlocked] = useState(false);
  const [proxyStatus, setProxyStatus] = useState("");
  const [total, setTotal] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loadingMore, setLoadingMore] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const currentAnchorRef = useRef("");
  const refreshInterval = useRef<ReturnType<typeof setInterval> | null>(null);

  const isGeoError = (msg: string) =>
    msg.toLowerCase().includes("geo") ||
    msg.toLowerCase().includes("block") ||
    msg.toLowerCase().includes("indonesia") ||
    msg.toLowerCase().includes("region") ||
    msg.toLowerCase().includes("403") ||
    msg.toLowerCase().includes("forbidden");

  const fetchRooms = useCallback(async (showLoading = true) => {
    if (showLoading) setStatus("loading");
    setIsGeoBlocked(false);
    try {
      const res = await fetch(`${API_BASE}/api/live-rooms?limit=30`, {
        headers: { "Accept": "application/json" },
      });
      const data: ApiResponse = await res.json();

      if (data.success && data.rooms && data.rooms.length > 0) {
        const mapped = data.rooms.map((r, i) => mapRoomToVideo(r, i));
        setVideos(mapped);
        setTotal(data.total ?? data.rooms.length);
        setStatus("ok");
        setErrorMsg("");
        setProxyStatus(data.proxy || "");
        if (data.rooms[0]) currentAnchorRef.current = data.rooms[0].anchorId ?? data.rooms[0].id;
      } else if (!data.success) {
        setProxyStatus(data.proxy || "");
        const errMsg = data.error ?? "Tidak ada data dari Hot51";
        if (isGeoError(errMsg)) setIsGeoBlocked(true);
        throw new Error(errMsg);
      } else {
        throw new Error("Tidak ada live room aktif saat ini");
      }
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : "Gagal memuat data");
      setStatus("error");
    }
  }, []);

  const loadNextRoom = useCallback(async (anchorId: string) => {
    if (loadingMore || !anchorId) return;
    setLoadingMore(true);
    try {
      const res = await fetch(`${API_BASE}/api/live-next`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ anchorId }),
      });
      const result = await res.json();
      if (result.success && result.data) {
        const d = result.data as Record<string, unknown>;
        const room = (d.room ?? d.data ?? d) as Record<string, unknown>;
        const newAnchorId = (room.anchorId ?? room.aid ?? room.id) as string | undefined;
        if (newAnchorId && newAnchorId !== anchorId) {
          const newRoom: LiveRoom = {
            id: newAnchorId,
            anchorId: newAnchorId,
            liveId: (room.liveId ?? room.lid ?? newAnchorId) as string,
            name: (room.anchorNickname ?? room.ann ?? room.name ?? "") as string,
            viewers: Number(room.onlineCount ?? room.wuc ?? room.viewers ?? 0),
            cover: (room.coverUrl ?? room.cover ?? "") as string,
            avatar: (room.anchorAvatarUrl ?? room.ahp ?? room.avatar ?? "") as string,
            liveName: (room.liveName ?? room.ln ?? "") as string,
            streamUrl: (room.pullAddr ?? room.streamUrl ?? "") as string,
            hlsUrl: (room.pullAddr265 ?? room.hlsUrl ?? undefined) as string | undefined,
          };
          setVideos((prev) => [...prev, mapRoomToVideo(newRoom, prev.length)]);
          currentAnchorRef.current = newAnchorId;
        }
      }
    } catch {
      // silent fail
    } finally {
      setLoadingMore(false);
    }
  }, [loadingMore]);

  useEffect(() => {
    fetchRooms();
    // Refresh every 20s — Hot51 CDN tokens expire in ~29s so we must rotate
    refreshInterval.current = setInterval(() => {
      fetchRooms(false).catch(() => {});
    }, 20000);
    return () => {
      if (refreshInterval.current) clearInterval(refreshInterval.current);
    };
  }, [fetchRooms]);

  const handleSwipeUp = () => {
    if (currentIndex < videos.length - 1) {
      setCurrentIndex((prev) => prev + 1);
    }
  };

  const handleSwipeDown = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prev) => prev - 1);
    }
  };

  const handleNearEnd = useCallback((currentId: string) => {
    loadNextRoom(currentId || currentAnchorRef.current);
  }, [loadNextRoom]);

  return (
    <div ref={containerRef} className="h-full w-full bg-black relative overflow-hidden">
      {/* Top bar */}
      <div className="absolute top-0 inset-x-0 z-30 flex items-center justify-center gap-6 pt-4 pb-2 bg-gradient-to-b from-black/60 to-transparent">
        <button className="text-white/50 text-sm font-medium">Mengikuti</button>
        <button className="text-white text-sm font-bold relative">
          Untuk Anda
          <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-white rounded-full" />
        </button>
        <div className="flex items-center gap-1 text-red-500">
          <Radio size={14} className="live-badge" />
          <span className="text-xs font-bold">
            LIVE {total > 0 && `· ${formatCount(total)}`}
          </span>
        </div>
      </div>

      {/* Content */}
      {status === "loading" && videos.length === 0 && (
        <div className="h-full flex flex-col items-center justify-center gap-4">
          <div className="w-12 h-12 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          <p className="text-white/60 text-sm">Menghubungi Hot51...</p>
        </div>
      )}

      {status === "error" && (
        <div className="h-full flex flex-col items-center justify-center gap-4 px-8">
          <div className="w-16 h-16 rounded-full bg-red-500/10 flex items-center justify-center">
            <WifiOff size={32} className="text-red-400" />
          </div>
          <h3 className="text-lg font-semibold text-white">Hot51 Tidak Tersedia</h3>
          <p className="text-sm text-white/60 text-center">{errorMsg || "Server Hot51 tidak bisa diakses"}</p>

          {isGeoBlocked ? (
            <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4 text-sm text-yellow-200/80 text-center">
              <AlertTriangle size={16} className="mx-auto mb-2" />
              Server Hot51 memblokir IP luar Indonesia.
              <br />Set HOT51_PROXY_URL di environment variables.
            </div>
          ) : proxyStatus === "not set" ? (
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 text-sm text-blue-200/80 text-center">
              Hot51 CDN membutuhkan IP Indonesia.
              <br />Set HOT51_PROXY_URL di environment variables.
            </div>
          ) : (
            <div className="bg-white/5 rounded-lg p-4 text-sm text-white/60 text-center">
              Proxy aktif tapi tidak bisa menjangkau Hot51.
              <br />Coba proxy Indonesia lain atau gunakan ComHub.
            </div>
          )}

          <button
            onClick={() => fetchRooms()}
            className="flex items-center gap-2 px-6 py-3 bg-white/10 hover:bg-white/20 rounded-full text-sm font-medium transition-colors"
          >
            <RefreshCw size={16} />
            Coba Lagi
          </button>

          <p className="text-xs text-white/40 text-center mt-2">
            Gunakan tab ComHub untuk menonton siaran alternatif
          </p>
        </div>
      )}

      {status === "ok" && videos.length > 0 && (
        <div className="h-full relative">
          <AnimatePresence mode="popLayout">
            {videos.map((video, i) => (
              <motion.div
                key={video.id}
                initial={{ opacity: 0, y: 100 }}
                animate={{
                  opacity: i === currentIndex ? 1 : 0,
                  y: i === currentIndex ? 0 : i < currentIndex ? -100 : 100,
                  scale: i === currentIndex ? 1 : 0.9,
                }}
                transition={{ duration: 0.3, ease: "easeInOut" }}
                className="absolute inset-0"
                style={{ pointerEvents: i === currentIndex ? "auto" : "none" }}
              >
                <VideoCard
                  video={video}
                  isActive={i === currentIndex}
                  onSwipeUp={handleSwipeUp}
                  onSwipeDown={handleSwipeDown}
                  onNearEnd={i === videos.length - 2 ? () => handleNearEnd(video.anchorId) : undefined}
                />
              </motion.div>
            ))}
          </AnimatePresence>

          {/* Pagination dots */}
          <div className="absolute right-2 top-1/2 -translate-y-1/2 z-20 flex flex-col gap-1.5">
            {videos.slice(0, 6).map((_, i) => (
              <div
                key={i}
                className={`w-1.5 rounded-full transition-all duration-300 ${
                  i === currentIndex ? "h-6 bg-white" : "h-1.5 bg-white/30"
                }`}
              />
            ))}
            {videos.length > 6 && (
              <div className="w-1.5 h-1.5 rounded-full bg-white/30" />
            )}
          </div>

          {/* Loading more indicator */}
          {loadingMore && (
            <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2 bg-black/60 backdrop-blur-sm px-4 py-2 rounded-full">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span className="text-xs text-white/70">Memuat siaran berikutnya...</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}