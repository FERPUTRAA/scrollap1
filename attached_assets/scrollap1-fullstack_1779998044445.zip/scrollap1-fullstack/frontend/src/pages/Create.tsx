import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Camera, Mic, MicOff, Video, VideoOff, SwitchCamera, Radio, AlertCircle } from "lucide-react";

export default function Create() {
  const [isLive, setIsLive] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [title, setTitle] = useState("");
  const [viewers, setViewers] = useState(0);
  const [facingMode, setFacingMode] = useState<"user" | "environment">("user");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode },
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera error:", err);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  useEffect(() => {
    if (cameraOn) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
  }, [cameraOn, facingMode]);

  const toggleCamera = () => setCameraOn(!cameraOn);
  const toggleMic = () => {
    if (streamRef.current) {
      streamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !micOn;
      });
    }
    setMicOn(!micOn);
  };

  const switchCamera = () => {
    setFacingMode((prev) => (prev === "user" ? "environment" : "user"));
  };

  const startLive = () => {
    if (!title.trim()) return;
    setIsLive(true);
    // Simulate viewer growth
    const interval = setInterval(() => {
      setViewers((prev) => prev + Math.floor(Math.random() * 10));
    }, 3000);
    return () => clearInterval(interval);
  };

  const stopLive = () => {
    setIsLive(false);
    setViewers(0);
  };

  return (
    <div className="h-full bg-black relative">
      {/* Camera preview */}
      <div className="absolute inset-0">
        {cameraOn ? (
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-neutral-900 flex items-center justify-center">
            <Camera size={64} className="text-white/20" />
          </div>
        )}
        <div className="gradient-overlay" />
      </div>

      {/* Top controls */}
      <div className="absolute top-0 inset-x-0 z-20 flex items-center justify-between p-4">
        <button
          onClick={() => setFacingMode((prev) => (prev === "user" ? "environment" : "user"))}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white"
        >
          <SwitchCamera size={20} />
        </button>

        {isLive && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-red-500/80 rounded-full">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
            <span className="text-xs font-bold text-white">LIVE</span>
            <span className="text-xs text-white/80">{viewers.toLocaleString()}</span>
          </div>
        )}

        <button className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white">
          <AlertCircle size={20} />
        </button>
      </div>

      {/* Bottom controls */}
      <div className="absolute bottom-0 inset-x-0 z-20 p-4">
        {!isLive ? (
          <div className="space-y-4">
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Judul live stream..."
              className="w-full bg-white/10 backdrop-blur-sm rounded-xl px-4 py-3 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-1 focus:ring-white/30"
            />

            <div className="flex items-center justify-center gap-6">
              <button
                onClick={toggleCamera}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
                  cameraOn ? "bg-white/20 text-white" : "bg-red-500/20 text-red-400"
                }`}
              >
                {cameraOn ? <Video size={24} /> : <VideoOff size={24} />}
              </button>

              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={startLive}
                disabled={!title.trim()}
                className="w-20 h-20 rounded-full bg-gradient-to-br from-red-500 to-pink-600 flex items-center justify-center disabled:opacity-50 shadow-lg shadow-red-500/30"
              >
                <Radio size={32} className="text-white" />
              </motion.button>

              <button
                onClick={toggleMic}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors ${
                  micOn ? "bg-white/20 text-white" : "bg-red-500/20 text-red-400"
                }`}
              >
                {micOn ? <Mic size={24} /> : <MicOff size={24} />}
              </button>
            </div>

            <p className="text-center text-xs text-white/40">
              Pastikan koneksi internet stabil sebelum memulai live
            </p>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={toggleCamera}
              className={`w-12 h-12 rounded-full flex items-center justify-center ${
                cameraOn ? "bg-white/20 text-white" : "bg-red-500/20 text-red-400"
              }`}
            >
              {cameraOn ? <Video size={20} /> : <VideoOff size={20} />}
            </button>

            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={stopLive}
              className="px-8 py-3 bg-red-500 hover:bg-red-600 rounded-full text-sm font-bold text-white transition-colors"
            >
              Akhiri Live
            </motion.button>

            <button
              onClick={toggleMic}
              className={`w-12 h-12 rounded-full flex items-center justify-center ${
                micOn ? "bg-white/20 text-white" : "bg-red-500/20 text-red-400"
              }`}
            >
              {micOn ? <Mic size={20} /> : <MicOff size={20} />}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}