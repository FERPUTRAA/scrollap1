import React, { useState } from "react";
import { motion } from "framer-motion";
import { Settings, Grid, Bookmark, Heart, Eye, Users, Link as LinkIcon, ChevronRight } from "lucide-react";

const stats = [
  { label: "Pengikut", value: "12.5K" },
  { label: "Mengikuti", value: "234" },
  { label: "Suka", value: "45.2K" },
];

const videos = [
  { id: "1", views: "1.2K", likes: "234", thumbnail: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=300" },
  { id: "2", views: "890", likes: "156", thumbnail: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=300" },
  { id: "3", views: "2.1K", likes: "445", thumbnail: "https://images.unsplash.com/photo-1516280440614-6697288d5d38?w=300" },
  { id: "4", views: "567", likes: "89", thumbnail: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=300" },
  { id: "5", views: "3.4K", likes: "678", thumbnail: "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?w=300" },
  { id: "6", views: "1.8K", likes: "345", thumbnail: "https://images.unsplash.com/photo-1552820728-8b83bb6b2b0a?w=300" },
];

const tabs = [
  { id: "videos", icon: Grid, label: "Video" },
  { id: "saved", icon: Bookmark, label: "Tersimpan" },
  { id: "liked", icon: Heart, label: "Suka" },
];

export default function Profile() {
  const [activeTab, setActiveTab] = useState("videos");

  return (
    <div className="h-full bg-black overflow-y-auto no-scrollbar">
      {/* Header */}
      <div className="sticky top-0 z-20 bg-black/95 backdrop-blur-md px-4 py-3 flex items-center justify-between">
        <h1 className="text-lg font-bold">Profil Saya</h1>
        <button className="p-2 hover:bg-white/10 rounded-full">
          <Settings size={20} />
        </button>
      </div>

      {/* Profile info */}
      <div className="px-4 py-4">
        <div className="flex items-center gap-4">
          <div className="relative">
            <img
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=me"
              alt="Profile"
              className="w-20 h-20 rounded-full border-2 border-white/20 object-cover"
            />
            <div className="absolute bottom-0 right-0 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center border-2 border-black">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="white">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
              </svg>
            </div>
          </div>
          <div className="flex-1">
            <h2 className="text-lg font-bold">@streamer_saya</h2>
            <p className="text-sm text-white/60">Streamer & Content Creator</p>
          </div>
        </div>

        {/* Stats */}
        <div className="flex justify-around py-4 mt-2">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-lg font-bold">{stat.value}</p>
              <p className="text-xs text-white/50">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Bio */}
        <div className="space-y-2 mb-4">
          <p className="text-sm text-white/80">
            🎮 Live streaming setiap malam jam 8 PM WIB
            <br />
            🎵 Musik | Gaming | Talk Show
          </p>
          <div className="flex items-center gap-1 text-sm text-blue-400">
            <LinkIcon size={14} />
            <span>linktr.ee/streamer_saya</span>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-2">
          <button className="flex-1 py-2 bg-white text-black rounded-lg text-sm font-semibold">
            Edit Profil
          </button>
          <button className="flex-1 py-2 bg-white/10 text-white rounded-lg text-sm font-semibold">
            Promosikan
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-white/10">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 text-sm font-medium transition-colors ${
                isActive ? "text-white border-b-2 border-white" : "text-white/50"
              }`}
            >
              <Icon size={16} />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Content grid */}
      <div className="grid grid-cols-3 gap-0.5 p-0.5">
        {videos.map((video) => (
          <motion.div
            key={video.id}
            whileTap={{ scale: 0.95 }}
            className="relative aspect-[3/4] bg-white/5"
          >
            <img
              src={video.thumbnail}
              alt="Video"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-1 left-1 right-1 flex items-center justify-between text-[10px] text-white/80">
              <div className="flex items-center gap-0.5">
                <Eye size={10} />
                {video.views}
              </div>
              <div className="flex items-center gap-0.5">
                <Heart size={10} />
                {video.likes}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Menu items */}
      <div className="px-4 py-4 space-y-1">
        {[
          { icon: Users, label: "Teman", value: "234" },
          { icon: Bookmark, label: "Koleksi", value: "12" },
          { icon: Heart, label: "Video Disukai", value: "456" },
          { icon: Settings, label: "Pengaturan", value: "" },
        ].map((item) => (
          <button
            key={item.label}
            className="w-full flex items-center justify-between py-3 border-b border-white/5"
          >
            <div className="flex items-center gap-3">
              <item.icon size={18} className="text-white/60" />
              <span className="text-sm">{item.label}</span>
            </div>
            <div className="flex items-center gap-2">
              {item.value && <span className="text-xs text-white/40">{item.value}</span>}
              <ChevronRight size={16} className="text-white/30" />
            </div>
          </button>
        ))}
      </div>

      <div className="h-20" />
    </div>
  );
}