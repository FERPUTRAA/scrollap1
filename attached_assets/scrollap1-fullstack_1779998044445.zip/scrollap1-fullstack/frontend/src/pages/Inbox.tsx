import React, { useState } from "react";
import { motion } from "framer-motion";
import { MessageSquare, Heart, UserPlus, Bell, ChevronRight, Search } from "lucide-react";

const tabs = [
  { id: "all", label: "Semua" },
  { id: "mentions", label: "Sebutan" },
  { id: "likes", label: "Suka" },
  { id: "follows", label: "Ikuti" },
];

const notifications = [
  { id: "1", type: "like", user: "User123", text: "menyukai video Anda", time: "2m", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=1" },
  { id: "2", type: "follow", user: "NewFan", text: "mulai mengikuti Anda", time: "5m", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=2" },
  { id: "3", type: "mention", user: "Friend99", text: "menyebut Anda dalam komentar", time: "15m", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=3" },
  { id: "4", type: "like", user: "ViewerX", text: "menyukai live Anda", time: "30m", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=4" },
  { id: "5", type: "follow", user: "Subscriber", text: "mulai mengikuti Anda", time: "1h", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=5" },
  { id: "6", type: "system", user: "Sistem", text: "Live Anda telah berakhir. Statistik tersedia di profil.", time: "2h", avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=system" },
];

const messages = [
  { id: "1", user: "Admin", text: "Selamat datang di Scrollap1!", time: "1d", unread: true, avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=admin" },
  { id: "2", user: "Support", text: "Jika ada pertanyaan, hubungi kami.", time: "1d", unread: false, avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=support" },
];

export default function Inbox() {
  const [activeTab, setActiveTab] = useState("all");
  const [activeSection, setActiveSection] = useState<"notifications" | "messages">("notifications");

  const filtered = notifications.filter((n) => {
    if (activeTab === "all") return true;
    if (activeTab === "likes") return n.type === "like";
    if (activeTab === "follows") return n.type === "follow";
    if (activeTab === "mentions") return n.type === "mention";
    return true;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case "like": return <Heart size={16} className="text-red-400" />;
      case "follow": return <UserPlus size={16} className="text-green-400" />;
      case "mention": return <MessageSquare size={16} className="text-blue-400" />;
      default: return <Bell size={16} className="text-white/50" />;
    }
  };

  return (
    <div className="h-full bg-black flex flex-col">
      {/* Header */}
      <div className="px-4 pt-4 pb-2">
        <h1 className="text-xl font-bold mb-3">Kotak Masuk</h1>
        <div className="flex gap-2 mb-3">
          <button
            onClick={() => setActiveSection("notifications")}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeSection === "notifications" ? "bg-white text-black" : "bg-white/10 text-white/70"
            }`}
          >
            Notifikasi
          </button>
          <button
            onClick={() => setActiveSection("messages")}
            className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
              activeSection === "messages" ? "bg-white text-black" : "bg-white/10 text-white/70"
            }`}
          >
            Pesan
          </button>
        </div>
      </div>

      {activeSection === "notifications" ? (
        <>
          {/* Tabs */}
          <div className="flex gap-2 px-4 pb-2 overflow-x-auto no-scrollbar">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                  activeTab === tab.id ? "bg-white text-black" : "bg-white/10 text-white/60"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Notification list */}
          <div className="flex-1 overflow-y-auto no-scrollbar">
            {filtered.map((notif) => (
              <motion.div
                key={notif.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-start gap-3 px-4 py-3 border-b border-white/5 hover:bg-white/5 transition-colors"
              >
                <div className="relative shrink-0">
                  <img
                    src={notif.avatar}
                    alt={notif.user}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-black flex items-center justify-center">
                    {getIcon(notif.type)}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <span className="font-semibold">{notif.user}</span>{" "}
                    <span className="text-white/70">{notif.text}</span>
                  </p>
                  <p className="text-xs text-white/40 mt-0.5">{notif.time}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </>
      ) : (
        <div className="flex-1 overflow-y-auto no-scrollbar">
          {/* Search */}
          <div className="px-4 py-2">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
              <input
                type="text"
                placeholder="Cari pesan..."
                className="w-full bg-white/10 rounded-full pl-10 pr-4 py-2 text-sm text-white placeholder:text-white/40 focus:outline-none"
              />
            </div>
          </div>

          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              whileTap={{ scale: 0.98 }}
              className="flex items-center gap-3 px-4 py-3 border-b border-white/5"
            >
              <div className="relative">
                <img
                  src={msg.avatar}
                  alt={msg.user}
                  className="w-12 h-12 rounded-full object-cover"
                />
                {msg.unread && (
                  <div className="absolute top-0 right-0 w-3 h-3 bg-red-500 rounded-full border-2 border-black" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold">{msg.user}</p>
                  <span className="text-xs text-white/40">{msg.time}</span>
                </div>
                <p className="text-sm text-white/60 truncate">{msg.text}</p>
              </div>
              <ChevronRight size={16} className="text-white/30 shrink-0" />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}