import React from "react";
import { Link } from "wouter";
import { Home, AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="h-full flex flex-col items-center justify-center gap-4 px-8">
      <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center">
        <AlertCircle size={32} className="text-white/50" />
      </div>
      <h1 className="text-2xl font-bold">404</h1>
      <p className="text-sm text-white/60 text-center">
        Halaman tidak ditemukan. Mungkin sudah dipindahkan atau dihapus.
      </p>
      <Link href="/">
        <button className="flex items-center gap-2 px-6 py-3 bg-white text-black rounded-full text-sm font-medium hover:bg-white/90 transition-colors">
          <Home size={16} />
          Kembali ke Beranda
        </button>
      </Link>
    </div>
  );
}