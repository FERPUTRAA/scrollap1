/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL: string
  readonly VITE_HOT51_CF_WORKER_URL: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}