import React from "react";
import { Home, Search, PlusSquare, MessageCircle, User } from "lucide-react";

interface BottomNavProps {
  activeTab: string;
  onTabChange: (path: string) => void;
}

const tabs = [
  { path: "/", icon: Home, label: "Beranda" },
  { path: "/discover", icon: Search, label: "Jelajahi" },
  { path: "/create", icon: PlusSquare, label: "Buat" },
  { path: "/inbox", icon: MessageCircle, label: "Pesan" },
  { path: "/profile", icon: User, label: "Profil" },
];

export default function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <nav className="h-14 bg-black/90 backdrop-blur-md border-t border-white/10 flex items-center justify-around z-50 shrink-0">
      {tabs.map((tab) => {
        const isActive = activeTab === tab.path;
        const Icon = tab.icon;
        return (
          <button
            key={tab.path}
            onClick={() => onTabChange(tab.path)}
            className={`flex flex-col items-center justify-center gap-0.5 w-16 h-full transition-colors ${
              isActive ? "text-white nav-active" : "text-white/50 hover:text-white/70"
            }`}
          >
            <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
            <span className="text-[10px] font-medium">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
}