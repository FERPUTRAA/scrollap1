import React, { useRef, useEffect, useState, useCallback } from "react";
import Hls from "hls.js";
import { Volume2, VolumeX, Maximize2, Minimize2, RefreshCw, Radio } from "lucide-react";

interface LivePlayerProps {
  src: string;
  hlsUrl?: string;
  cover?: string;
  autoPlay?: boolean;
  muted?: boolean;
  className?: string;
  onError?: () => void;
  onReady?: () => void;
  anchorId?: string;
}

type PlayerState = "loading" | "playing" | "error" | "blocked";

const API_BASE = import.meta.env.VITE_API_URL || "";

export default function LivePlayer({
  src,
  hlsUrl,
  cover,
  autoPlay = true,
  muted: initialMuted = true,
  className = "",
  onError,
  onReady,
  anchorId,
}: LivePlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const retryCount = useRef(0);
  const maxRetries = 3;

  const [state, setState] = useState<PlayerState>("loading");
  const [errorMsg, setErrorMsg] = useState("");
  const [muted, setMuted] = useState(initialMuted);
  const [fullscreen, setFullscreen] = useState(false);
  const [mode, setMode] = useState<"hls" | "flv" | "native">("hls");
  const [proxyMode, setProxyMode] = useState<string>("");

  const cleanup = useCallback(() => {
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.removeAttribute("src");
      videoRef.current.load();
    }
  }, []);

  // Build HLS proxy URL — ALWAYS use /api/hls-proxy?room= for fresh tokens
  const buildHlsUrl = useCallback((): string | null => {
    // Priority 1: Use anchorId to fetch fresh manifest (avoids stale CDN tokens)
    if (anchorId) {
      return `${API_BASE}/api/hls-proxy?room=${encodeURIComponent(anchorId)}`;
    }
    // Priority 2: Use provided hlsUrl directly through proxy
    if (hlsUrl && hlsUrl.includes(".m3u8")) {
      return `${API_BASE}/api/hls-proxy?url=${encodeURIComponent(hlsUrl)}`;
    }
    // Priority 3: Use src if it's m3u8
    if (src && src.includes(".m3u8")) {
      return `${API_BASE}/api/hls-proxy?url=${encodeURIComponent(src)}`;
    }
    return null;
  }, [anchorId, hlsUrl, src]);

  const setupHls = useCallback(async (url: string) => {
    const video = videoRef.current;
    if (!video) return;

    cleanup();
    setState("loading");
    setMode("hls");
    retryCount.current = 0;

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 30,
        maxBufferLength: 30,
        liveSyncDurationCount: 3,
        manifestLoadingTimeOut: 15000,
        manifestLoadingMaxRetry: 2,
        levelLoadingTimeOut: 15000,
        fragLoadingTimeOut: 20000,
        fragLoadingMaxRetry: 3,
        // Use our backend for all segment requests
        xhrSetup: (xhr, url) => {
          // Segments are already rewritten to /api/ts-proxy by backend
          // Just ensure proper headers
          xhr.setRequestHeader("Referer", "https://hot51.com/");
        },
      });

      hls.on(Hls.Events.MEDIA_ATTACHED, () => {
        hls.loadSource(url);
      });

      hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
        setState("playing");
        setErrorMsg("");
        onReady?.();
        if (autoPlay) {
          video.play().catch(() => {});
        }
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        console.error("[HLS Error]", data.type, data.details, data);

        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              if (retryCount.current < maxRetries) {
                retryCount.current++;
                setErrorMsg(`Koneksi terputus, mencoba ulang (${retryCount.current}/${maxRetries})...`);
                setState("blocked");
                hls.startLoad();
              } else {
                setState("error");
                setErrorMsg("Gagal memuat stream setelah beberapa percobaan. Coba refresh halaman.");
                onError?.();
              }
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              setState("error");
              setErrorMsg("Error pemutaran: " + (data.details || "Unknown"));
              onError?.();
              break;
          }
        }
      });

      hls.on(Hls.Events.FRAG_LOADED, (_event, data) => {
        // Check proxy mode from response headers (if available via proxy)
        // This is a best-effort check
      });

      hls.attachMedia(video);
      hlsRef.current = hls;
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      // Native HLS support (Safari)
      video.src = url;
      video.addEventListener("loadedmetadata", () => {
        setState("playing");
        onReady?.();
      }, { once: true });
      video.addEventListener("error", () => {
        setState("error");
        setErrorMsg("Browser tidak bisa memutar stream ini");
        onError?.();
      }, { once: true });
    } else {
      setState("error");
      setErrorMsg("Browser tidak mendukung pemutaran HLS");
      onError?.();
    }
  }, [autoPlay, cleanup, onError, onReady]);

  const setupNative = useCallback((url: string) => {
    const video = videoRef.current;
    if (!video) return;

    cleanup();
    setState("loading");
    setMode("native");

    video.src = url;
    video.addEventListener("canplay", () => {
      setState("playing");
      onReady?.();
      if (autoPlay) video.play().catch(() => {});
    }, { once: true });

    video.addEventListener("error", () => {
      setState("error");
      setErrorMsg("Gagal memuat stream");
      onError?.();
    }, { once: true });

    video.load();
  }, [autoPlay, cleanup, onError, onReady]);

  useEffect(() => {
    if (!src && !hlsUrl && !anchorId) return;

    const hlsProxyUrl = buildHlsUrl();

    if (hlsProxyUrl) {
      setupHls(hlsProxyUrl);
    } else if (src) {
      setupNative(src);
    }

    return cleanup;
  }, [src, hlsUrl, anchorId, buildHlsUrl, setupHls, setupNative, cleanup]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = muted;
    }
  }, [muted]);

  const toggleMute = () => setMuted(!muted);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setFullscreen(false);
    }
  };

  const retry = () => {
    const hlsProxyUrl = buildHlsUrl();
    if (hlsProxyUrl) {
      setupHls(hlsProxyUrl);
    } else if (src) {
      setupNative(src);
    }
  };

  return (
    <div ref={containerRef} className={`relative w-full h-full bg-black ${className}`}>
      {/* Cover image while loading */}
      {state === "loading" && cover && (
        <img
          src={cover}
          alt="Cover"
          className="absolute inset-0 w-full h-full object-cover opacity-50"
          onError={(e) => {
            (e.target as HTMLImageElement).style.display = "none";
          }}
        />
      )}

      {/* Video element */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        playsInline
        webkit-playsinline="true"
        muted={muted}
        autoPlay={autoPlay}
        loop
      />

      {/* Gradient overlay */}
      <div className="gradient-overlay" />

      {/* Loading state */}
      {state === "loading" && (
        <div className="absolute inset-0 flex items-center justify-center z-20">
          <div className="flex flex-col items-center gap-3">
            <div className="w-10 h-10 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            <span className="text-sm text-white/70">Memuat HLS...</span>
            {anchorId && (
              <span className="text-xs text-white/40">Mengambil token segar...</span>
            )}
          </div>
        </div>
      )}

      {/* Error state */}
      {(state === "error" || state === "blocked") && (
        <div className="absolute inset-0 flex items-center justify-center z-20 bg-black/60">
          <div className="flex flex-col items-center gap-3 px-6 max-w-xs">
            <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
              <RefreshCw size={24} className="text-red-400" />
            </div>
            <p className="text-sm text-white/80 text-center">
              {state === "error" ? "Gagal memuat stream" : "Mencoba koneksi ulang..."}
            </p>
            <p className="text-xs text-white/50 text-center">
              {errorMsg || "Koneksi terputus. Periksa jaringan dan coba lagi."}
            </p>
            <button
              onClick={retry}
              className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-full text-sm text-white transition-colors"
            >
              <RefreshCw size={14} />
              Coba Lagi
            </button>
            {state === "error" && (
              <p className="text-[10px] text-white/30 text-center">
                Jika masalah berlanjut, coba gunakan tab ComHub atau Create
              </p>
            )}
          </div>
        </div>
      )}

      {/* Controls overlay */}
      <div className="absolute bottom-4 right-4 flex gap-2 z-30">
        <button
          onClick={toggleMute}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white hover:bg-black/60 transition-colors"
        >
          {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
        </button>
        <button
          onClick={toggleFullscreen}
          className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center text-white hover:bg-black/60 transition-colors"
        >
          {fullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
        </button>
      </div>

      {/* Mode badge */}
      {state === "playing" && (
        <div className="absolute top-4 right-4 z-30 flex items-center gap-2">
          <span className="flex items-center gap-1 px-2 py-1 bg-red-500/80 rounded text-[10px] font-bold text-white live-badge">
            <Radio size={10} />
            LIVE
          </span>
          <span className="px-2 py-1 bg-black/40 backdrop-blur-sm rounded text-[10px] font-medium text-white/70 uppercase tracking-wider">
            {mode === "hls" ? "HLS" : mode === "flv" ? "FLV" : "NATIVE"}
          </span>
        </div>
      )}
    </div>
  );
}