import React, { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  Music,
  Eye,
  Send,
  Gift,
  X,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import LivePlayer from "./LivePlayer";

interface VideoData {
  id: string;
  anchorId: string;
  username: string;
  avatar: string;
  description: string;
  music: string;
  likes: string;
  comments: string;
  shares: string;
  viewers: number;
  streamUrl: string;
  hlsUrl?: string;
  cover: string;
  isLive: boolean;
}

interface VideoCardProps {
  video: VideoData;
  isActive: boolean;
  onSwipeUp?: () => void;
  onSwipeDown?: () => void;
  onNearEnd?: () => void;
}

export default function VideoCard({
  video,
  isActive,
  onSwipeUp,
  onSwipeDown,
  onNearEnd,
}: VideoCardProps) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [showGiftPanel, setShowGiftPanel] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [comments, setComments] = useState([
    { id: "1", user: "User123", text: "Halo! 🔥", time: "1m" },
    { id: "2", user: "Viewer99", text: "Keren banget! 👏", time: "2m" },
    { id: "3", user: "FanBoy", text: "GG bro 💪", time: "3m" },
  ]);
  const [giftAnimation, setGiftAnimation] = useState<string | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef(0);
  const touchEndY = useRef(0);

  useEffect(() => {
    if (isActive && onNearEnd) {
      const timer = setTimeout(() => onNearEnd(), 5000);
      return () => clearTimeout(timer);
    }
  }, [isActive, onNearEnd]);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = () => {
    const diff = touchStartY.current - touchEndY.current;
    if (Math.abs(diff) > 50) {
      if (diff > 0 && onSwipeUp) onSwipeUp();
      else if (diff < 0 && onSwipeDown) onSwipeDown();
    }
  };

  const handleLike = () => {
    setLiked(!liked);
  };

  const handleGift = (giftType: string) => {
    setGiftAnimation(giftType);
    setTimeout(() => setGiftAnimation(null), 1500);
    setShowGiftPanel(false);
  };

  const sendComment = () => {
    if (!commentText.trim()) return;
    setComments((prev) => [
      { id: Date.now().toString(), user: "Anda", text: commentText, time: "Now" },
      ...prev,
    ]);
    setCommentText("");
  };

  const gifts = [
    { id: "rose", name: "Mawar", icon: "🌹", price: 1 },
    { id: "heart", name: "Hati", icon: "❤️", price: 5 },
    { id: "crown", name: "Mahkota", icon: "👑", price: 50 },
    { id: "rocket", name: "Roket", icon: "🚀", price: 100 },
    { id: "diamond", name: "Berlian", icon: "💎", price: 500 },
    { id: "star", name: "Bintang", icon: "⭐", price: 10 },
  ];

  return (
    <div
      ref={cardRef}
      className="video-container"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Live Player - pass anchorId for fresh token fetching */}
      {isActive && (
        <LivePlayer
          src={video.streamUrl}
          hlsUrl={video.hlsUrl}
          cover={video.cover}
          anchorId={video.anchorId}
          autoPlay={true}
          muted={true}
        />
      )}
      {!isActive && (
        <img
          src={video.cover}
          alt={video.username}
          className="absolute inset-0 w-full h-full object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=800";
          }}
        />
      )}

      {/* Gradient overlay */}
      <div className="gradient-overlay" />

      {/* Gift animation */}
      <AnimatePresence>
        {giftAnimation && (
          <motion.div
            initial={{ opacity: 1, y: 0, scale: 1 }}
            animate={{ opacity: 0, y: -300, scale: 0.5, rotate: 20 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 }}
            className="absolute bottom-1/2 left-1/2 -translate-x-1/2 z-40 text-6xl"
          >
            {gifts.find((g) => g.id === giftAnimation)?.icon}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Left side - User info */}
      <div className="absolute bottom-20 left-4 right-20 z-20">
        <div className="flex items-center gap-3 mb-2">
          <div className="relative">
            <img
              src={video.avatar}
              alt={video.username}
              className="w-10 h-10 rounded-full border-2 border-white/50 object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "https://api.dicebear.com/7.x/avataaars/svg?seed=" + video.username;
              }}
            />
            {video.isLive && (
              <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 bg-red-500 text-[8px] font-bold text-white rounded live-badge">
                LIVE
              </span>
            )}
          </div>
          <div>
            <p className="text-sm font-semibold text-white">@{video.username}</p>
            <div className="flex items-center gap-1 text-xs text-white/70">
              <Eye size={12} />
              <span>{video.viewers.toLocaleString()}</span>
            </div>
          </div>
          <button className="ml-2 px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-xs font-medium text-white transition-colors">
            Ikuti
          </button>
        </div>
        <p className="text-sm text-white/90 line-clamp-2 mb-2">{video.description}</p>
        <div className="flex items-center gap-2 text-xs text-white/60">
          <Music size={12} className="spin-slow" />
          <span className="truncate">{video.music}</span>
        </div>
      </div>

      {/* Right side - Action buttons */}
      <div className="absolute bottom-20 right-2 flex flex-col items-center gap-4 z-20">
        <button onClick={handleLike} className="flex flex-col items-center gap-1">
          <motion.div
            whileTap={{ scale: 1.3 }}
            className={`w-12 h-12 rounded-full flex items-center justify-center ${
              liked ? "bg-red-500/20" : "bg-black/20"
            }`}
          >
            <Heart size={28} className={liked ? "text-red-500 fill-red-500" : "text-white"} />
          </motion.div>
          <span className="text-xs text-white/80 font-medium">
            {liked ? (parseInt(video.likes.replace(/[^0-9]/g, "")) || 0) + 1 : video.likes}
          </span>
        </button>

        <button onClick={() => setShowComments(true)} className="flex flex-col items-center gap-1">
          <div className="w-12 h-12 rounded-full bg-black/20 flex items-center justify-center">
            <MessageCircle size={26} className="text-white" />
          </div>
          <span className="text-xs text-white/80 font-medium">{video.comments}</span>
        </button>

        <button className="flex flex-col items-center gap-1">
          <div className="w-12 h-12 rounded-full bg-black/20 flex items-center justify-center">
            <Bookmark
              size={26}
              className={saved ? "text-yellow-400 fill-yellow-400" : "text-white"}
              onClick={() => setSaved(!saved)}
            />
          </div>
          <span className="text-xs text-white/80 font-medium">
            {saved ? "Tersimpan" : "Simpan"}
          </span>
        </button>

        <button className="flex flex-col items-center gap-1">
          <div className="w-12 h-12 rounded-full bg-black/20 flex items-center justify-center">
            <Share2 size={26} className="text-white" />
          </div>
          <span className="text-xs text-white/80 font-medium">{video.shares}</span>
        </button>

        <button onClick={() => setShowGiftPanel(true)} className="flex flex-col items-center gap-1">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Gift size={26} className="text-white" />
          </div>
          <span className="text-xs text-white/80 font-medium">Gift</span>
        </button>
      </div>

      {/* Comments Panel */}
      <AnimatePresence>
        {showComments && (
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="absolute inset-x-0 bottom-0 z-50 bg-black/95 backdrop-blur-xl rounded-t-2xl max-h-[60%] flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <h3 className="text-base font-semibold">Komentar ({comments.length})</h3>
              <button onClick={() => setShowComments(false)} className="p-1 hover:bg-white/10 rounded-full">
                <X size={20} />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center text-xs font-bold shrink-0">
                    {comment.user[0]}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-white/90">{comment.user}</span>
                      <span className="text-xs text-white/40">{comment.time}</span>
                    </div>
                    <p className="text-sm text-white/70 mt-0.5">{comment.text}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-3 border-t border-white/10 flex gap-2">
              <input
                type="text"
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendComment()}
                placeholder="Tambahkan komentar..."
                className="flex-1 bg-white/10 rounded-full px-4 py-2 text-sm text-white placeholder:text-white/40 focus:outline-none focus:ring-1 focus:ring-white/30"
              />
              <button
                onClick={sendComment}
                disabled={!commentText.trim()}
                className="p-2 bg-white text-black rounded-full disabled:opacity-30"
              >
                <Send size={18} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Gift Panel */}
      <AnimatePresence>
        {showGiftPanel && (
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="absolute inset-x-0 bottom-0 z-50 bg-black/95 backdrop-blur-xl rounded-t-2xl p-4"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">Kirim Gift</h3>
              <button onClick={() => setShowGiftPanel(false)} className="p-1 hover:bg-white/10 rounded-full">
                <X size={20} />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {gifts.map((gift) => (
                <button
                  key={gift.id}
                  onClick={() => handleGift(gift.id)}
                  className="flex flex-col items-center gap-2 p-3 bg-white/5 hover:bg-white/10 rounded-xl transition-colors"
                >
                  <span className="text-3xl">{gift.icon}</span>
                  <span className="text-xs font-medium">{gift.name}</span>
                  <span className="text-xs text-white/50">{gift.price} coin</span>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}