.class public interface abstract Li8/d;
.super Ljava/lang/Object;

# interfaces
.implements Lkotlin/v;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<P1:",
        "Ljava/lang/Object;",
        "P2:",
        "Ljava/lang/Object;",
        "P3:",
        "Ljava/lang/Object;",
        "P4:",
        "Ljava/lang/Object;",
        "P5:",
        "Ljava/lang/Object;",
        "P6:",
        "Ljava/lang/Object;",
        "P7:",
        "Ljava/lang/Object;",
        "P8:",
        "Ljava/lang/Object;",
        "P9:",
        "Ljava/lang/Object;",
        "P10:",
        "Ljava/lang/Object;",
        "P11:",
        "Ljava/lang/Object;",
        "P12:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlin/v<",
        "TR;>;"
    }
.end annotation


# virtual methods
.method public abstract K(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TP1;TP2;TP3;TP4;TP5;TP6;TP7;TP8;TP9;TP10;TP11;TP12;)TR;"
        }
    .end annotation
.end method
