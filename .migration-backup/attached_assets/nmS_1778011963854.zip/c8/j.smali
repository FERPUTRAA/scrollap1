.class public interface abstract Lc8/j;
.super Ljava/lang/Object;

# interfaces
.implements Lc8/e;


# annotations
.annotation build Lc8/f;
.end annotation

.annotation build Lkotlin/g1;
    version = "1.3"
.end annotation

.annotation build Lkotlin/internal/b;
.end annotation


# virtual methods
.method public abstract a(Z)Lc8/b;
    .annotation build Lc8/f;
    .end annotation

    .annotation build Lia/d;
    .end annotation

    .annotation build Lkotlin/internal/b;
    .end annotation
.end method
