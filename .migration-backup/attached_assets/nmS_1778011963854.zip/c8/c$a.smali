.class public final Lc8/c$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lc8/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# direct methods
.method public static synthetic a(Lc8/c;Lkotlin/v;Lc8/g;ILjava/lang/Object;)Lc8/a;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "1~so~ / ~~@   bb~t~o.  @v@m ~~n@-l f@~@c @@t~ @s@@ @~lyr/~~iS~K4@~b@@@~@ofiu i @ @@~~o~~oMd~oa~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    if-nez p4, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    and-int/lit8 p3, p3, 0x2

    const/4 v0, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p3, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    sget-object p2, Lc8/g;->d:Lc8/g;

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-interface {p0, p1, p2}, Lc8/c;->d(Lkotlin/v;Lc8/g;)Lc8/a;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    const-string p1, "hnlmlPws gass  tefsen: acilrIt  undeinrit afglt,ittcaa chrsentsau mode eoSp nuorultltpp"

    const-string p1, "cssptinntelsa Sl titsoutsPI ifceeaulagtr rn hdw u,ioateamtelnd  l:cruepa tlrnfng spouh "

    const/4 v1, 0x4

    const-string p1, "nhtmoIoftpit feugw ldonssdtcPua trtsro l guseeaiilpnurelctracth nt  sala plncS,en ue :i"

    const-string p1, "Super calls with default arguments not supported in this target, function: callsInPlace"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    throw p0
.end method
