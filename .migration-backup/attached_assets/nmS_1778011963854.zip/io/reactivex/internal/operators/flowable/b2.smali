.class public final Lio/reactivex/internal/operators/flowable/b2;
.super Lio/reactivex/internal/operators/flowable/a;

# interfaces
.implements Lt7/g;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/b2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;",
        "Lt7/g<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v0, 0x5

    move v1, v0

    iput-object p0, p0, Lio/reactivex/internal/operators/flowable/b2;->c:Lt7/g;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Lja/b;Lt7/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/g<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/b2;->c:Lt7/g;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~aso o~ c@~~~@ f.@~S~s~y@ @Mr@@ ~oltK1~ @~o@~ l@i~/b~/f ~-~@@ @ ~ @b4 @ib ov  @ ~n@~@d~u~ti o@~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/b2$a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/b2;->c:Lt7/g;

    const/4 v4, 0x7

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/b2$a;-><init>(Lja/c;Lt7/g;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public accept(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
