.class final Lio/reactivex/internal/operators/flowable/m$b;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/c;
.implements Lja/d;
.implements Lt7/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "C::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;",
        "Lt7/e;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x66485ec0ba03436dL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TC;>;"
        }
    .end annotation
.end field

.field final bufferSupplier:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TC;>;"
        }
    .end annotation
.end field

.field final buffers:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "TC;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field done:Z

.field index:I

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field produced:J

.field s:Lja/d;

.field final size:I

.field final skip:I


# direct methods
.method constructor <init>(Lja/c;IILjava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TC;>;II",
            "Ljava/util/concurrent/Callable<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$b;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m$b;->size:I

    const/4 v0, 0x2

    move v1, v0

    iput p3, p0, Lio/reactivex/internal/operators/flowable/m$b;->skip:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/m$b;->bufferSupplier:Ljava/util/concurrent/Callable;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$b;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    new-instance p1, Ljava/util/ArrayDeque;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$b;->buffers:Ljava/util/ArrayDeque;

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "tos/yo~od loon~~Ml.o@b ~~@s~i~~v@f@c ~~/u@~ ~@a ~i@b-~ @~ ~~ i~@@~@f  b m~r@~@@~Kt@ @  1S @@@4@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->cancelled:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->cancelled:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->s:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->done:Z

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->buffers:Ljava/util/ArrayDeque;

    const/4 v7, 0x3

    move v8, v7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m$b;->index:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    add-int/lit8 v2, v1, 0x1

    const/4 v8, 0x2

    if-nez v1, :cond_1

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m$b;->bufferSupplier:Ljava/util/concurrent/Callable;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string v3, "etbmTruSeun reldlfurb ueuf h seprfipferna"

    const-string v3, "hlslreuuepfert erlbTbuSaed nifu rf enfrup"

    const/4 v8, 0x3

    const-string v3, "Trebonrbeduftlrrpef hlS ffu eluuenui erpa"

    const-string v3, "The bufferSupplier returned a null buffer"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v1, v3}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    check-cast v1, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    const/4 v8, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m$b;->cancel()V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m$b;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x4

    move v8, v7

    return-void

    :cond_1
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    check-cast v1, Ljava/util/Collection;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v1, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v1}, Ljava/util/Collection;->size()I

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget v4, p0, Lio/reactivex/internal/operators/flowable/m$b;->size:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-ne v3, v4, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {v1, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/m$b;->produced:J

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    add-long/2addr v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    iput-wide v3, p0, Lio/reactivex/internal/operators/flowable/m$b;->produced:J

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/m$b;->actual:Lja/c;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-interface {v3, v1}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v1, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    check-cast v1, Ljava/util/Collection;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-interface {v1, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    goto :goto_1

    :cond_3
    const/4 v7, 0x5

    const/4 v8, 0x0

    iget p1, p0, Lio/reactivex/internal/operators/flowable/m$b;->skip:I

    if-ne v2, p1, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v2, 0x0

    :cond_4
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput v2, p0, Lio/reactivex/internal/operators/flowable/m$b;->index:I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-void
.end method

.method public g(J)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-eqz v0, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/m$b;->actual:Lja/c;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/m$b;->buffers:Ljava/util/ArrayDeque;

    move-wide v1, p1

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static/range {v1 .. v6}, Lio/reactivex/internal/util/u;->j(JLja/c;Ljava/util/Queue;Ljava/util/concurrent/atomic/AtomicLong;Lt7/e;)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-void

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-nez v0, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v0, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->skip:I

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    int-to-long v0, v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    sub-long/2addr p1, v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->size:I

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    int-to-long v0, v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->c(JJ)J

    move-result-wide p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->s:Lja/d;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->skip:I

    const/4 v7, 0x6

    move v8, v7

    int-to-long v0, v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->s:Lja/d;

    const/4 v8, 0x6

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    :cond_2
    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->done:Z

    const/4 v5, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->done:Z

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->produced:J

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    cmp-long v2, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0, v0, v1}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->actual:Lja/c;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m$b;->buffers:Ljava/util/ArrayDeque;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0, v1, p0, p0}, Lio/reactivex/internal/util/u;->h(Lja/c;Ljava/util/Queue;Ljava/util/concurrent/atomic/AtomicLong;Lt7/e;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->done:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->buffers:Ljava/util/ArrayDeque;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->actual:Lja/c;

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$b;->s:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$b;->s:Lja/d;

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m$b;->actual:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
