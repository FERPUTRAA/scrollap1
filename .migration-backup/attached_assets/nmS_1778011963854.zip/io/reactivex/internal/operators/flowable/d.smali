.class public final Lio/reactivex/internal/operators/flowable/d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Iterable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/d$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/lang/Iterable<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;TT;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d;->a:Lja/b;

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/d;->b:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TT;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@Ks@ t ~uo@~~4 diM~~@~r  @cl1@@bo   @nv~ ~f@/s a@~@~@oo.~b ~ ~@ i~- ~y@Sm@ oo~f~@@~~l/~@~tb@~ @ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/d$a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d;->b:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lio/reactivex/internal/operators/flowable/d$a;-><init>(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d;->a:Lja/b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/d$a;->d()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method
