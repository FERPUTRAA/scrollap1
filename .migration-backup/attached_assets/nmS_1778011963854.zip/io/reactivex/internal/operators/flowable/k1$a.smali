.class final Lio/reactivex/internal/operators/flowable/k1$a;
.super Ljava/lang/Object;

# interfaces
.implements Lu7/l;
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lu7/l<",
        "TT;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field b:Lja/d;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k1$a;->a:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/s@o@io@~ oo Mau~@~b~4 ~~S ~@@/ory@~~~ t~~b@i  ~~@i~ 1   f v~@@~l@~@@@f@@ nl@K ~d @~tb o.~-s@ c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k1$a;->b:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public clear()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x1

    xor-int/2addr v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x3

    return v0
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    and-int/lit8 p1, p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p1
.end method

.method public offer(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, " oom dh en!lblludeatS"

    const-string v0, "Should not be called!"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k1$a;->a:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k1$a;->a:Lja/c;

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public p(Ljava/lang/Object;Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)Z"
        }
    .end annotation

    const/4 v0, 0x7

    move v1, v0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v0, 0x5

    shr-int/2addr v1, v0

    const-string p2, "  thoSdnlldocabs!l eu"

    const-string p2, "! sutdladbcln ehoSle "

    const/4 v1, 0x1

    const-string p2, "noStobcedl uba !edlh "

    const-string p2, "Should not be called!"

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    throw p1
.end method

.method public poll()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k1$a;->b:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k1$a;->b:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k1$a;->a:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method
