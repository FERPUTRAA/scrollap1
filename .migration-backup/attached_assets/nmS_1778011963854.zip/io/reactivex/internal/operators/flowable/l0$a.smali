.class final Lio/reactivex/internal/operators/flowable/l0$a;
.super Lio/reactivex/internal/subscriptions/c;

# interfaces
.implements Lu7/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/l0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/c<",
        "TT;>;",
        "Lu7/a<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x3907ba0b13897e3dL


# instance fields
.field final actual:Lu7/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/a<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final onFinally:Lt7/a;

.field qs:Lu7/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/l<",
            "TT;>;"
        }
    .end annotation
.end field

.field s:Lja/d;

.field syncFused:Z


# direct methods
.method constructor <init>(Lu7/a;Lt7/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-TT;>;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/c;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l0$a;->actual:Lu7/a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l0$a;->onFinally:Lt7/a;

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~~ @@@ rnf~~~@@~~@/~mb@Sl ofa /yoi@M@ @i  @o @ ~~t@@ 1 bs-bv~K@~~@ ~c@u  ~~dt.@l~~ o~~ ~oi4o@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    and-int/2addr v3, v2

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->onFinally:Lt7/a;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->s:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/l0$a;->a()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->qs:Lu7/l;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Lu7/o;->clear()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->actual:Lu7/a;

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->s:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v1, 0x5

    move v2, v1

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->qs:Lu7/l;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0}, Lu7/o;->isEmpty()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public l(I)I
    .locals 5

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->qs:Lu7/l;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    and-int/lit8 v2, p1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v2, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lu7/k;->l(I)I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x5

    shl-int/2addr v3, v0

    const/4 v4, 0x2

    if-ne p1, v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-boolean v1, p0, Lio/reactivex/internal/operators/flowable/l0$a;->syncFused:Z

    :cond_1
    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return p1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v1
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->actual:Lu7/a;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->actual:Lu7/a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/l0$a;->a()V

    const/4 v1, 0x5

    or-int/2addr v2, v1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->actual:Lu7/a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/l0$a;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public poll()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->qs:Lu7/l;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-boolean v1, p0, Lio/reactivex/internal/operators/flowable/l0$a;->syncFused:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/l0$a;->a()V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l0$a;->s:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l0$a;->s:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    instance-of v0, p1, Lu7/l;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p1, Lu7/l;

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l0$a;->qs:Lu7/l;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/l0$a;->actual:Lu7/a;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method
