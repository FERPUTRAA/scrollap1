.class public final Lio/reactivex/internal/operators/flowable/h2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/h2$b;,
        Lio/reactivex/internal/operators/flowable/h2$a;,
        Lio/reactivex/internal/operators/flowable/h2$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TR;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;+",
            "Lja/b<",
            "+TR;>;>;"
        }
    .end annotation
.end field

.field final d:I

.field final e:Z


# direct methods
.method public constructor <init>(Lja/b;Lt7/o;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/o<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;+",
            "Lja/b<",
            "+TR;>;>;IZ)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h2;->c:Lt7/o;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p3, p0, Lio/reactivex/internal/operators/flowable/h2;->d:I

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-boolean p4, p0, Lio/reactivex/internal/operators/flowable/h2;->e:Z

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@rs~ @m@ l~~oi l@M @ t@ fcb@no@1@@~dib ~@@~ y~ @~/@ -a~   o~~o~~@~.b~@@/ ~ovoK~Ss ~~i~@ u4~@ ~f@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/h2;->d:I

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/h2;->e:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/h2$a;-><init>(IZ)V

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h2;->c:Lt7/o;

    const/4 v4, 0x3

    invoke-interface {v1, v0}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v2, " tsmohtsPue   ullbeilnuscelerardnr"

    const-string v2, "rssdlorPab s tth rlcnuueirelnl eeu"

    const/4 v4, 0x6

    const-string v2, "rdbeoct rtsPel eseululornlra eh ni"

    const-string v2, "selector returned a null Publisher"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast v1, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v2, Lio/reactivex/internal/operators/flowable/h2$c;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v2, p1, v0}, Lio/reactivex/internal/operators/flowable/h2$c;-><init>(Lja/c;Lio/reactivex/internal/operators/flowable/h2$a;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x6

    move v4, v3

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method
