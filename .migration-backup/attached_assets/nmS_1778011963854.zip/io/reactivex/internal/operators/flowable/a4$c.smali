.class final Lio/reactivex/internal/operators/flowable/a4$c;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:J

.field final c:Ljava/util/concurrent/TimeUnit;

.field final d:Lio/reactivex/e0$c;

.field e:Lja/d;

.field final f:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field volatile g:J

.field volatile h:Z


# direct methods
.method constructor <init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0$c;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->f:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$c;->a:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/a4$c;->b:J

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/a4$c;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/a4$c;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s i@@o  r~@~1f~~~@~o  i o~@.bb~Mt@~4 o m@~sd~@~@y ~@K @n@~i o~ cSb~latv /~~/ ~@ @@@@u-@ l@~fo~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    return v0
.end method

.method b(J)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->f:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a4$c;->f:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget-object v2, Lio/reactivex/internal/operators/flowable/a4;->g:Lio/reactivex/disposables/c;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1, v0, v2}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->d:Lio/reactivex/e0$c;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v1, Lio/reactivex/internal/operators/flowable/a4$c$a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1, p0, p1, p2}, Lio/reactivex/internal/operators/flowable/a4$c$a;-><init>(Lio/reactivex/internal/operators/flowable/a4$c;J)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-wide p1, p0, Lio/reactivex/internal/operators/flowable/a4$c;->b:J

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$c;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p1, p2, v2}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/a4$c;->f:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p2, p1}, Lio/reactivex/internal/disposables/d;->d(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public cancel()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a4$c;->e()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->f:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x7

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->e:Lja/d;

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->h:Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->g:J

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->g:J

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$c;->a:Lja/c;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v2, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/operators/flowable/a4$c;->b(J)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->e:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->h:Z

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->h:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a4$c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->a:Lja/c;

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->h:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->h:Z

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a4$c;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->a:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c;->e:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$c;->e:Lja/d;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$c;->a:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/operators/flowable/a4$c;->b(J)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method
