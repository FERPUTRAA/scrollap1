.class public final Lio/reactivex/internal/operators/flowable/n4;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/n4$b;,
        Lio/reactivex/internal/operators/flowable/n4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TR;>;"
    }
.end annotation


# instance fields
.field final b:[Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lja/b<",
            "+TT;>;>;"
        }
    .end annotation
.end field

.field final d:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "+TR;>;"
        }
    .end annotation
.end field

.field final e:I

.field final f:Z


# direct methods
.method public constructor <init>([Lja/b;Ljava/lang/Iterable;Lt7/o;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lja/b<",
            "+TT;>;",
            "Ljava/lang/Iterable<",
            "+",
            "Lja/b<",
            "+TT;>;>;",
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "+TR;>;IZ)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n4;->b:[Lja/b;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n4;->c:Ljava/lang/Iterable;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/n4;->d:Lt7/o;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p4, p0, Lio/reactivex/internal/operators/flowable/n4;->e:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-boolean p5, p0, Lio/reactivex/internal/operators/flowable/n4;->f:Z

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;)V"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "o~sot~ ~iac/~Mi~ K@b@~~S@~@ @n1oy@~d~@~~ot @~ fv @~@ul  @~l@@@ @  bm.~b ~s  i~@~@fr~-/ @~@  o4@o"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n4;->b:[Lja/b;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-nez v0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/16 v0, 0x8

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    new-array v0, v0, [Lja/b;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n4;->c:Ljava/lang/Iterable;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    move v3, v2

    move v3, v2

    const/4 v10, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz v4, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    check-cast v4, Lja/b;

    const/4 v10, 0x1

    const/4 v9, 0x4

    array-length v5, v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-ne v3, v5, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    shr-int/lit8 v5, v3, 0x2

    const/4 v10, 0x1

    add-int/2addr v5, v3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-array v5, v5, [Lja/b;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v0, v2, v5, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    add-int/lit8 v5, v3, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x1

    aput-object v4, v0, v3

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move v3, v5

    move v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    goto :goto_0

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    array-length v3, v0

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    move v7, v3

    move v7, v3

    const/4 v10, 0x4

    move v7, v3

    move v7, v3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-nez v7, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x5

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/g;->a(Lja/c;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    return-void

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    new-instance v8, Lio/reactivex/internal/operators/flowable/n4$a;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/n4;->d:Lt7/o;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    iget v5, p0, Lio/reactivex/internal/operators/flowable/n4;->e:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-boolean v6, p0, Lio/reactivex/internal/operators/flowable/n4;->f:Z

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    move v4, v7

    move v4, v7

    const/4 v10, 0x2

    move v4, v7

    move v4, v7

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-direct/range {v1 .. v6}, Lio/reactivex/internal/operators/flowable/n4$a;-><init>(Lja/c;Lt7/o;IIZ)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-interface {p1, v8}, Lja/c;->q(Lja/d;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v8, v0, v7}, Lio/reactivex/internal/operators/flowable/n4$a;->d([Lja/b;I)V

    const/4 v9, 0x4

    move v10, v9

    return-void
.end method
