.class public final Lio/reactivex/internal/operators/flowable/p;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/p$a;,
        Lio/reactivex/internal/operators/flowable/p$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TU;>;"
    }
.end annotation


# instance fields
.field final c:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TB;>;"
        }
    .end annotation
.end field

.field final d:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lja/b;Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "TB;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/p;->c:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/p;->d:Ljava/util/concurrent/Callable;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@sb~n~ @@ @c @~1 ~tf@ob @@oy~i@~  ~Ma~r @l/  v~~o@@.~S@~~m~K @o~@@  /tbs-~o~f  @do@@~li~4~ui@~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/p$b;

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v5, 0x7

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p;->d:Ljava/util/concurrent/Callable;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/p;->c:Lja/b;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v1, v2, p1, v3}, Lio/reactivex/internal/operators/flowable/p$b;-><init>(Lja/c;Ljava/util/concurrent/Callable;Lja/b;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method
