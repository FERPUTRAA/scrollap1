.class public final Lio/reactivex/internal/operators/flowable/t;
.super Lio/reactivex/f0;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/t$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "TU;>;",
        "Lu7/b<",
        "TU;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+TU;>;"
        }
    .end annotation
.end field

.field final c:Lt7/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/b<",
            "-TU;-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/util/concurrent/Callable;Lt7/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/Callable<",
            "+TU;>;",
            "Lt7/b<",
            "-TU;-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/t;->a:Lja/b;

    const/4 v0, 0x5

    move v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/t;->b:Ljava/util/concurrent/Callable;

    const/4 v0, 0x7

    move v1, v0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/t;->c:Lt7/b;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TU;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s t@ob1@~K~f ~b@@~S@ ~@@@ ~u.M /o o@ @r~ @m@@~~~@~io~ao~v/~~  y-b is@@f~ct~ @ ln 4@~odli~ ~~@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t;->b:Ljava/util/concurrent/Callable;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "vulmripn saieehruraeile natlTlS t undplei"

    const-string v1, "lnsldutarlr aeaiiprlnve tiie pluTu hene S"

    const/4 v5, 0x0

    const-string v1, "arveoTuaidlprrS  iluuh netl  eelieinnualp"

    const-string v1, "The initialSupplier returned a null value"

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t;->a:Lja/b;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v2, Lio/reactivex/internal/operators/flowable/t$a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/t;->c:Lt7/b;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {v2, p1, v0, v3}, Lio/reactivex/internal/operators/flowable/t$a;-><init>(Lio/reactivex/h0;Ljava/lang/Object;Lt7/b;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->o(Ljava/lang/Throwable;Lio/reactivex/h0;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TU;>;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/s;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t;->a:Lja/b;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t;->b:Ljava/util/concurrent/Callable;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/t;->c:Lt7/b;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v0, v1, v2, v3}, Lio/reactivex/internal/operators/flowable/s;-><init>(Lja/b;Ljava/util/concurrent/Callable;Lt7/b;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object v0
.end method
