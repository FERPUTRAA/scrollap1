.class final Lio/reactivex/internal/operators/flowable/m1$d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/m1;->g(Lio/reactivex/k;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)Ljava/util/concurrent/Callable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lio/reactivex/flowables/a<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/k;

.field final synthetic b:J

.field final synthetic c:Ljava/util/concurrent/TimeUnit;

.field final synthetic d:Lio/reactivex/e0;


# direct methods
.method constructor <init>(Lio/reactivex/k;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$d;->a:Lio/reactivex/k;

    const/4 v0, 0x1

    move v1, v0

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/m1$d;->b:J

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/m1$d;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/m1$d;->d:Lio/reactivex/e0;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Lio/reactivex/flowables/a;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " os //fi@ds@oaib K@@ @iytr 4 ~-@@ ~~~o@~~l@~ bm~~u.@o~l  ftnv@b~~@o @@o S@~@~@@~ @ M ~@ ~ 1c~~~~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$d;->a:Lio/reactivex/k;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/m1$d;->b:J

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/m1$d;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/m1$d;->d:Lio/reactivex/e0;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2, v3, v4}, Lio/reactivex/k;->I4(JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)Lio/reactivex/flowables/a;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m1$d;->a()Lio/reactivex/flowables/a;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method
