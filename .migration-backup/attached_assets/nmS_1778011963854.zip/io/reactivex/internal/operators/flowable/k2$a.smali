.class final Lio/reactivex/internal/operators/flowable/k2$a;
.super Lio/reactivex/internal/subscriptions/f;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/f<",
        "TT;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x40b970e193918fd6L


# instance fields
.field final reducer:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TT;TT;TT;>;"
        }
    .end annotation
.end field

.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;Lt7/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/c<",
            "TT;TT;TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/k2$a;->reducer:Lt7/c;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  sd/f@i ~~c~ @b ~@o@moy~o@.u~~@n~@   S~@/Mbta ~~4~o~i@@@@@~ t@r-o ~ @~ ~@f@b 1~o@s @iv~~~  lKl~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/f;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v1, 0x5

    and-int/2addr v2, v1

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x7

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k2$a;->reducer:Lt7/c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v1, v0, p1}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, "elam ulvueu eenechrntd drlrrT sua"

    const-string v0, " rs rt lenhuerl uue revldeanaTcud"

    const/4 v3, 0x6

    const-string v0, "ceerouedeu vurt lrrT eha uanedl l"

    const-string v0, "The reducer returned a null value"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/k2$a;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x7

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k2$a;->s:Lja/d;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v2, 0x6

    move v3, v2

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x5

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method
