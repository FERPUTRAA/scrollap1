.class final Lio/reactivex/internal/operators/flowable/g0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/g0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "Lio/reactivex/w<",
        "TT;>;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field b:Z

.field c:Lja/d;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g0$a;->a:Lja/c;

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public a(Lio/reactivex/w;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/w<",
            "TT;>;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s1~@@~b~iKb ~@@@-c@M~~~t~o@ @//@o. @d m~  @~~oof4@l  @  ~v u ~iyt@ sS~~~b~@~lr~n@o@i@o a@f@~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Lio/reactivex/w;->g()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1}, Lio/reactivex/w;->d()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Lio/reactivex/w;->g()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->c:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1}, Lio/reactivex/w;->d()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/g0$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1}, Lio/reactivex/w;->f()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g0$a;->c:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g0$a;->onComplete()V

    const/4 v2, 0x1

    goto :goto_0

    :cond_3
    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->a:Lja/c;

    const/4 v2, 0x2

    invoke-virtual {p1}, Lio/reactivex/w;->e()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->c:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public bridge synthetic f(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p1, Lio/reactivex/w;

    const/4 v0, 0x1

    move v1, v0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/g0$a;->a(Lio/reactivex/w;)V

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->c:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->b:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->a:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->b:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->b:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->a:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g0$a;->c:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g0$a;->c:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g0$a;->a:Lja/c;

    const/4 v1, 0x0

    move v2, v1

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method
