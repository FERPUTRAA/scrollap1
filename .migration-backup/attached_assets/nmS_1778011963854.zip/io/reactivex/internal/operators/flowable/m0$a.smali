.class final Lio/reactivex/internal/operators/flowable/m0$a;
.super Lio/reactivex/internal/subscribers/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final f:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final g:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field final h:Lt7/a;

.field final i:Lt7/a;


# direct methods
.method constructor <init>(Lu7/a;Lt7/g;Lt7/g;Lt7/a;Lt7/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-TT;>;",
            "Lt7/g<",
            "-TT;>;",
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;",
            "Lt7/a;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/a;-><init>(Lu7/a;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m0$a;->f:Lt7/g;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/m0$a;->g:Lt7/g;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/m0$a;->h:Lt7/a;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/m0$a;->i:Lt7/a;

    const/4 v1, 0x1

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~@c~ ~y~b~@r  mb~f@~~@~ @~~ @~@~ @@o1tln @i@sb - ~@i@/4~Mo~@S v o@o~d~~i.oKo @af@@~ / t@ @ l~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lio/reactivex/internal/subscribers/a;->e:I

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x0

    xor-int/2addr v2, v0

    const/4 v1, 0x2

    move v2, v1

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x7

    return-void

    :cond_1
    :try_start_0
    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$a;->f:Lt7/g;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x7

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->c(Ljava/lang/Throwable;)V

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->d(I)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p1
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v1

    :cond_0
    :try_start_0
    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$a;->f:Lt7/g;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->c(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$a;->h:Lt7/a;

    const/4 v2, 0x2

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/c;->onComplete()V

    :try_start_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$a;->i:Lt7/a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void

    :catchall_1
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscribers/a;->c(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 8

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v6, 0x2

    move v7, v6

    const/4 v0, 0x1

    or-int/2addr v7, v0

    const/4 v6, 0x1

    move v7, v6

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->g:Lt7/g;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v1, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    iget-object v2, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v3, Lio/reactivex/exceptions/a;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v4, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-array v4, v4, [Ljava/lang/Throwable;

    const/4 v6, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    aput-object p1, v4, v5

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput-object v1, v4, v0

    const/4 v7, 0x4

    invoke-direct {v3, v4}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    invoke-interface {v2, v3}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    move v0, v5

    move v0, v5

    const/4 v7, 0x2

    move v0, v5

    move v0, v5

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_1
    :try_start_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->i:Lt7/a;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {p1}, Lt7/a;->run()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v7, 0x1

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    and-int/2addr v7, v6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-void
.end method

.method public poll()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->c:Lu7/l;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->f:Lt7/g;

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-interface {v1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->i:Lt7/a;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v1}, Lt7/a;->run()V

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->i:Lt7/a;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v1}, Lt7/a;->run()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    throw v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    iget v1, p0, Lio/reactivex/internal/subscribers/a;->e:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-ne v1, v2, :cond_1

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->h:Lt7/a;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v1}, Lt7/a;->run()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$a;->i:Lt7/a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1}, Lt7/a;->run()V

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method
