.class final Lio/reactivex/internal/operators/flowable/b4$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/b4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lio/reactivex/disposables/c;",
        ">;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x26fd42ce5a1686a7L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field volatile requested:Z


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b4$a;->actual:Lja/c;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lio/reactivex/disposables/c;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s/l@/u@o@doc @o@fo~o~@@y~ it@~M~~. @ ~@f 4@ bmi ~~~ o~bst @@ ~@~ ~1b~ @S~~@Kir-a l@@ ~ @@~ v~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lio/reactivex/internal/disposables/d;->i(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public cancel()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/b4$a;->requested:Z

    :cond_0
    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public run()V
    .locals 5

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v3, 0x7

    and-int/2addr v4, v3

    if-eq v0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b4$a;->requested:Z

    const/4 v3, 0x1

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b4$a;->actual:Lja/c;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    sget-object v0, Lio/reactivex/internal/disposables/e;->a:Lio/reactivex/internal/disposables/e;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b4$a;->actual:Lja/c;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object v0, Lio/reactivex/internal/disposables/e;->a:Lio/reactivex/internal/disposables/e;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b4$a;->actual:Lja/c;

    const/4 v4, 0x2

    new-instance v1, Lio/reactivex/exceptions/c;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v2, "l/amneced tfl /rvvuqei srldsu  sCtou a teaeo"

    const-string/jumbo v2, "vvsakf/ loeCt srqs  eo llreued/ndtacia t euu"

    const/4 v4, 0x2

    const-string v2, "ortsotulCu teei lsdvr //ae aanq dfkcelvuoe e"

    const-string v2, "Can\'t deliver value due to lack of requests"

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    invoke-direct {v1, v2}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v4, 0x5

    return-void
.end method
