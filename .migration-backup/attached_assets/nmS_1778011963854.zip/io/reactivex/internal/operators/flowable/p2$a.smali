.class final Lio/reactivex/internal/operators/flowable/p2$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/p2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x628271a96862fff0L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field remaining:J

.field final sa:Lio/reactivex/internal/subscriptions/o;

.field final source:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;JLio/reactivex/internal/subscriptions/o;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J",
            "Lio/reactivex/internal/subscriptions/o;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p2$a;->actual:Lja/c;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/p2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v0, 0x3

    move v1, v0

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/p2$a;->source:Lja/b;

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/p2$a;->remaining:J

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s/@~a  @@~ @bfi~oo/ ~@ @on~o . ~c1@~K idu~@~~~v  ~@r@~@@~~~ @~~@4@ y  s@@~@lb f ~~obtS-olMm@ti"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1}, Lio/reactivex/internal/subscriptions/o;->c()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x6

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p2$a;->source:Lja/b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v1, p0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    neg-int v0, v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p2$a;->actual:Lja/c;

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x4

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Lio/reactivex/internal/subscriptions/o;->e(J)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x5

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/p2$a;->remaining:J

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const/4 v5, 0x7

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    cmp-long v2, v0, v2

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    sub-long v2, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/p2$a;->remaining:J

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p2$a;->a()V

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p2$a;->actual:Lja/c;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {v0}, Lja/c;->onComplete()V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p2$a;->actual:Lja/c;

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
