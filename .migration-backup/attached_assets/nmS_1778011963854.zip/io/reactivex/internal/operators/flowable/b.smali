.class public final Lio/reactivex/internal/operators/flowable/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Iterable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/b$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/lang/Iterable<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final b:I


# direct methods
.method public constructor <init>(Lja/b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b;->a:Lja/b;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p2, p0, Lio/reactivex/internal/operators/flowable/b;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public iterator()Ljava/util/Iterator;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TT;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "u@s4M@a@@c @o-~@  /@~@o~~~~~@ f@~~v@1  @@ol~  b@~bbny@l@d ~@@@ t ~~ i ~oSs~ t@mf~.ir o ~~~ o~~i/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/b$a;

    const/4 v3, 0x7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/b;->b:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {v0, v1}, Lio/reactivex/internal/operators/flowable/b$a;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b;->a:Lja/b;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x0

    return-object v0
.end method
