.class public final Lio/reactivex/internal/operators/flowable/s2;
.super Lio/reactivex/flowables/a;

# interfaces
.implements Lu7/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/s2$l;,
        Lio/reactivex/internal/operators/flowable/s2$m;,
        Lio/reactivex/internal/operators/flowable/s2$g;,
        Lio/reactivex/internal/operators/flowable/s2$i;,
        Lio/reactivex/internal/operators/flowable/s2$n;,
        Lio/reactivex/internal/operators/flowable/s2$j;,
        Lio/reactivex/internal/operators/flowable/s2$h;,
        Lio/reactivex/internal/operators/flowable/s2$k;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/flowables/a<",
        "TT;>;",
        "Lu7/h<",
        "TT;>;"
    }
.end annotation


# static fields
.field static final f:Ljava/util/concurrent/Callable;


# instance fields
.field final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/internal/operators/flowable/s2$k<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final d:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final e:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/internal/operators/flowable/s2$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Lio/reactivex/internal/operators/flowable/s2$a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-object v0, Lio/reactivex/internal/operators/flowable/s2;->f:Ljava/util/concurrent/Callable;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>(Lja/b;Lja/b;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/internal/operators/flowable/s2$k<",
            "TT;>;>;",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/flowables/a;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2;->e:Lja/b;

    const/4 v1, 0x7

    const/4 v0, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s2;->b:Lja/b;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/s2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/s2;->d:Ljava/util/concurrent/Callable;

    const/4 v1, 0x7

    return-void
.end method

.method public static e8(Lja/b;I)Lio/reactivex/flowables/a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "TT;>;I)",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s~ ~ oi. bm dS~@@r~/u@ ~@@ oo~ ~l@o-4~  Ms~  t/  o 1@~~~~~t~~@~fn@i@vo@@K@c@ia~b@~ ~@@f@y ~@l@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const v0, 0x7fffffff

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0}, Lio/reactivex/internal/operators/flowable/s2;->i8(Lja/b;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/s2$d;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lio/reactivex/internal/operators/flowable/s2$d;-><init>(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lio/reactivex/internal/operators/flowable/s2;->h8(Lja/b;Ljava/util/concurrent/Callable;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method public static f8(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)Lio/reactivex/flowables/a;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            ")",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    const v5, 0x7fffffff

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-wide v1, p1

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/s2;->g8(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;I)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-object p0
.end method

.method public static g8(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;I)Lio/reactivex/flowables/a;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "I)",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v6, Lio/reactivex/internal/operators/flowable/s2$e;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x7

    const/4 v7, 0x1

    move v1, p5

    move v1, p5

    const/4 v8, 0x7

    move v1, p5

    move v1, p5

    move-wide v2, p1

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/s2$e;-><init>(IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {p0, v6}, Lio/reactivex/internal/operators/flowable/s2;->h8(Lja/b;Ljava/util/concurrent/Callable;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-object p0
.end method

.method static h8(Lja/b;Ljava/util/concurrent/Callable;)Lio/reactivex/flowables/a;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;>;)",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x0

    move v4, v3

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/s2$f;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v1, v0, p1}, Lio/reactivex/internal/operators/flowable/s2$f;-><init>(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/Callable;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v2, Lio/reactivex/internal/operators/flowable/s2;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v2, v1, p0, v0, p1}, Lio/reactivex/internal/operators/flowable/s2;-><init>(Lja/b;Lja/b;Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/Callable;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v2}, Lio/reactivex/plugins/a;->R(Lio/reactivex/flowables/a;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p0
.end method

.method public static i8(Lja/b;)Lio/reactivex/flowables/a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "+TT;>;)",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lio/reactivex/internal/operators/flowable/s2;->f:Ljava/util/concurrent/Callable;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lio/reactivex/internal/operators/flowable/s2;->h8(Lja/b;Ljava/util/concurrent/Callable;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public static j8(Ljava/util/concurrent/Callable;Lt7/o;)Lio/reactivex/k;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<U:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lio/reactivex/flowables/a<",
            "TU;>;>;",
            "Lt7/o<",
            "-",
            "Lio/reactivex/k<",
            "TU;>;+",
            "Lja/b<",
            "TR;>;>;)",
            "Lio/reactivex/k<",
            "TR;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/s2$b;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Lio/reactivex/internal/operators/flowable/s2$b;-><init>(Ljava/util/concurrent/Callable;Lt7/o;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/k;->d7(Lja/b;)Lio/reactivex/k;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public static k8(Lio/reactivex/flowables/a;Lio/reactivex/e0;)Lio/reactivex/flowables/a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lio/reactivex/flowables/a<",
            "TT;>;",
            "Lio/reactivex/e0;",
            ")",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/k;->I3(Lio/reactivex/e0;)Lio/reactivex/k;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lio/reactivex/internal/operators/flowable/s2$c;

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Lio/reactivex/internal/operators/flowable/s2$c;-><init>(Lio/reactivex/flowables/a;Lio/reactivex/k;)V

    const/4 v1, 0x4

    move v2, v1

    invoke-static {v0}, Lio/reactivex/plugins/a;->R(Lio/reactivex/flowables/a;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2;->e:Lja/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/b;->j(Lja/c;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public c8(Lt7/g;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;)V"
        }
    .end annotation

    :goto_0
    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    check-cast v0, Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/s2$k;->a()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    :cond_0
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2;->d:Ljava/util/concurrent/Callable;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    check-cast v1, Lio/reactivex/internal/operators/flowable/s2$j;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v2, v1}, Lio/reactivex/internal/operators/flowable/s2$k;-><init>(Lio/reactivex/internal/operators/flowable/s2$j;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1, v0, v2}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/s2$k;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/s2$k;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v3, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    const/4 v5, 0x0

    move v1, v2

    move v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_1

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    move v1, v3

    move v1, v3

    move v1, v3

    move v1, v3

    :goto_1
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {p1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/s2;->b:Lja/b;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_5

    const/4 v4, 0x6

    or-int/2addr v5, v4

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/s2$k;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p1}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw p1

    :catchall_1
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p1}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    throw p1
.end method

.method public source()Lja/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lja/b<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2;->b:Lja/b;

    const/4 v2, 0x2

    return-object v0
.end method
