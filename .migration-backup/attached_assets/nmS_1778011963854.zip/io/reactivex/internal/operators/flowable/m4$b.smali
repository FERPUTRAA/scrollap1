.class final Lio/reactivex/internal/operators/flowable/m4$b;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x15e3c5e57e438349L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TR;>;"
        }
    .end annotation
.end field

.field final combiner:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "TR;>;"
        }
    .end annotation
.end field

.field volatile done:Z

.field final error:Lio/reactivex/internal/util/c;

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final s:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field

.field final subscribers:[Lio/reactivex/internal/operators/flowable/m4$c;

.field final values:Ljava/util/concurrent/atomic/AtomicReferenceArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReferenceArray<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/o;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "TR;>;I)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->actual:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m4$b;->combiner:Lt7/o;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-array p1, p3, [Lio/reactivex/internal/operators/flowable/m4$c;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p2, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-ge p2, p3, :cond_0

    const/4 v2, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/m4$c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0, p0, p2}, Lio/reactivex/internal/operators/flowable/m4$c;-><init>(Lio/reactivex/internal/operators/flowable/m4$b;I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    aput-object v0, p1, p2

    const/4 v2, 0x1

    const/4 v1, 0x7

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->subscribers:[Lio/reactivex/internal/operators/flowable/m4$c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, p3}, Ljava/util/concurrent/atomic/AtomicReferenceArray;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->values:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p1, Lio/reactivex/internal/util/c;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method a(I)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "iis@4  @n@is@b-~@  ~~~~ r1/M@~fo @ ~o@~S  ~o@ ~@  lKb~.@o~u ~/v~  @d~t@@y~~om@~~@@a @b@l~fo ~~t@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->subscribers:[Lio/reactivex/internal/operators/flowable/m4$c;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    array-length v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ge v1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eq v1, p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    aget-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2}, Lio/reactivex/internal/operators/flowable/m4$c;->e()V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    move v4, v3

    return-void
.end method

.method b(IZ)V
    .locals 2

    const/4 v1, 0x4

    if-nez p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p2, 0x1

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-boolean p2, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m4$b;->a(I)V

    const/4 v1, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->actual:Lja/c;

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/m4$b;->error:Lio/reactivex/internal/util/c;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1, p0, p2}, Lio/reactivex/internal/util/k;->b(Lja/c;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    :cond_0
    const/4 v1, 0x2

    return-void
.end method

.method c(ILjava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m4$b;->a(I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p2, p0, v0}, Lio/reactivex/internal/util/k;->d(Lja/c;Ljava/lang/Throwable;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public cancel()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->subscribers:[Lio/reactivex/internal/operators/flowable/m4$c;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    array-length v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-ge v2, v1, :cond_0

    const/4 v5, 0x6

    aget-object v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v3}, Lio/reactivex/disposables/c;->e()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method d(ILjava/lang/Object;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->values:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {v0, p1, p2}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->set(ILjava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method e([Lja/b;I)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lja/b<",
            "*>;I)V"
        }
    .end annotation

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->subscribers:[Lio/reactivex/internal/operators/flowable/m4$c;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ge v2, p2, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    check-cast v3, Lja/d;

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v3}, Lio/reactivex/internal/subscriptions/p;->d(Lja/d;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    if-nez v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_1

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget-object v3, p1, v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    aget-object v4, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-interface {v3, v4}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->values:Ljava/util/concurrent/atomic/AtomicReferenceArray;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->length()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x0

    move v5, v3

    const/4 v4, 0x3

    move v5, v4

    aput-object p1, v2, v3

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ge v3, v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v3}, Ljava/util/concurrent/atomic/AtomicReferenceArray;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast p1, Lja/d;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v5, 0x5

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v5, 0x1

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    aput-object p1, v2, v3

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->combiner:Lt7/o;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {p1, v2}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v0, "mb muuo licd lsreel ravnaurnee"

    const-string v0, "ocsuanltaeedun lruei  mrl vebr"

    const/4 v5, 0x4

    const-string v0, "nt ro uenmlvdceollabr iauureen"

    const-string v0, "combiner returned a null value"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->actual:Lja/c;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->error:Lio/reactivex/internal/util/c;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0, p1, p0, v1}, Lio/reactivex/internal/util/k;->f(Lja/c;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m4$b;->cancel()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m4$b;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v2, 0x1

    move v3, v2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/m4$b;->a(I)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, p0, v1}, Lio/reactivex/internal/util/k;->b(Lja/c;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->done:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/m4$b;->a(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0, p1, p0, v1}, Lio/reactivex/internal/util/k;->d(Lja/c;Ljava/lang/Throwable;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method
