.class final Lio/reactivex/internal/operators/flowable/f4$a;
.super Ljava/util/concurrent/atomic/AtomicBoolean;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/f4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "D:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicBoolean;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x51f0e7a17ed319a6L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final disposer:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TD;>;"
        }
    .end annotation
.end field

.field final eager:Z

.field final resource:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TD;"
        }
    .end annotation
.end field

.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;Ljava/lang/Object;Lt7/g;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;TD;",
            "Lt7/g<",
            "-TD;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/f4$a;->resource:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/f4$a;->disposer:Lt7/g;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-boolean p4, p0, Lio/reactivex/internal/operators/flowable/f4$a;->eager:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bsM~ mtli~ S~ ~/@~a@@o@ ~~@ or~otfy.~~~ ~    b~u@~ @ @sK4@~bi@i@   @~@n~o-1~@/~@@c@~@o~v @o @df"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->disposer:Lt7/g;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->resource:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v2, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/f4$a;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->eager:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->disposer:Lt7/g;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->resource:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/f4$a;->a()V

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->eager:Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    if-eqz v2, :cond_0

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/f4$a;->disposer:Lt7/g;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/f4$a;->resource:Ljava/lang/Object;

    const/4 v7, 0x1

    invoke-interface {v2, v3}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-static {v2}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    shr-int/2addr v7, v6

    goto :goto_1

    :cond_0
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v2, 0x0

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v3}, Lja/d;->cancel()V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance v4, Lio/reactivex/exceptions/a;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v5, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-array v5, v5, [Ljava/lang/Throwable;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    aput-object p1, v5, v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    aput-object v2, v5, v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v4, v5}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {v3, v4}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    goto :goto_2

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_2

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    move v7, v6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v7, 0x6

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/f4$a;->a()V

    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->s:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/f4$a;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
