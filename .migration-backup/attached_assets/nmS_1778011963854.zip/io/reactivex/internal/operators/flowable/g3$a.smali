.class final Lio/reactivex/internal/operators/flowable/g3$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/g3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/h0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/h0<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field c:Lja/d;

.field d:Z

.field e:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/h0;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TT;>;TT;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->a:Lio/reactivex/h0;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/g3$a;->b:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~@@~.@ -b@ol  o /s~o/ m~@~o~~Mu@~~@v@So4~@  c~@~ oK ni i@@~@f tbt~~@~a ~y f~ @@i@~~lbr@1@d@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->e:Ljava/lang/Object;

    const/4 v2, 0x1

    move v3, v2

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x5

    xor-int/2addr v2, p1

    const/4 v3, 0x7

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object p1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->a:Lio/reactivex/h0;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, " eqm seoeneotl eeoantmnecumsentarn ihc!S"

    const-string v1, "nesrten   ltiaaoueme ehtnnSnecesec!qmnoo"

    const/4 v3, 0x5

    const-string v1, "nmeeoransotmauct  qe !nteeio nhe nelSocn"

    const-string v1, "Sequence contains more than one element!"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->e:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->d:Z

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->d:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->e:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->e:Ljava/lang/Object;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->b:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->a:Lio/reactivex/h0;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v1, v0}, Lio/reactivex/h0;->onSuccess(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->a:Lio/reactivex/h0;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v1, Ljava/util/NoSuchElementException;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v1}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v0, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->a:Lio/reactivex/h0;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g3$a;->c:Lja/d;

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3$a;->a:Lio/reactivex/h0;

    const/4 v3, 0x5

    invoke-interface {v0, p0}, Lio/reactivex/h0;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
