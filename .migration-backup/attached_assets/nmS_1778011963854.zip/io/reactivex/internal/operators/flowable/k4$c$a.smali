.class Lio/reactivex/internal/operators/flowable/k4$c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/k4$c;->q(Lja/d;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/processors/g;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/k4$c;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/k4$c;Lio/reactivex/processors/g;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k4$c$a;->b:Lio/reactivex/internal/operators/flowable/k4$c;

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/k4$c$a;->a:Lio/reactivex/processors/g;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "M s@@@~4~viK~@@b~ m~@ @oc~a  @~@ ~1 s~~@@@lf@@~ y~@tr / tb@oo l@~~@i@.~o~   d~-u@i b ~no~~~~fS o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$c$a;->b:Lio/reactivex/internal/operators/flowable/k4$c;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k4$c$a;->a:Lio/reactivex/processors/g;

    const/4 v2, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/k4$c;->t(Lio/reactivex/processors/g;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method
