.class public final Lio/reactivex/internal/operators/flowable/i0;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/i0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "K:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;TK;>;"
        }
    .end annotation
.end field

.field final d:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+",
            "Ljava/util/Collection<",
            "-TK;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lt7/o;Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/o<",
            "-TT;TK;>;",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Ljava/util/Collection<",
            "-TK;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i0;->c:Lt7/o;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/i0;->d:Ljava/util/concurrent/Callable;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "l~s@ ~m~@ ~l @ do/tt@ @ @4K@ fbi ~@~@i@ ~~  ~~bc s  oo fya~ @/~S~o@o~@iu~o~@1@~~~~-@b@n.v M@~r@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i0;->d:Ljava/util/concurrent/Callable;

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v1, "denmclog.yrpix rleild on h o nosen. rliuolaproepre lrua.oe tsle rnl ol aiwead tu2 csnTeSar Nutucneelasen ueclltvlcsa l"

    const-string v1, "saseeolern ln x.laee lipopocdue ol.e edeaal  gnlraulptrSno t v nta euldoon  o lNneaueTliciriy2cowl.rs rl cseshncrtluur"

    const/4 v5, 0x3

    const-string v1, "o s ounortn coNesx ol edine.al  rolr glsl  appna rluuipnluaru2cvSer loeuii.tlleetcehrdlatnc dls toeyel.anwealoTecre n "

    const-string v1, "The collectionSupplier returned a null collection. Null values are generally not allowed in 2.x operators and sources."

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v2, Lio/reactivex/internal/operators/flowable/i0$a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/i0;->c:Lt7/o;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v2, p1, v3, v0}, Lio/reactivex/internal/operators/flowable/i0$a;-><init>(Lja/c;Lt7/o;Ljava/util/Collection;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v5, 0x2

    return-void
.end method
