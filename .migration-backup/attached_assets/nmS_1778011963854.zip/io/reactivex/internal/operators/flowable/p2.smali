.class public final Lio/reactivex/internal/operators/flowable/p2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/p2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J


# direct methods
.method public constructor <init>(Lja/b;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J)V"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x0

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/p2;->c:J

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@ s o4@l/f~1uri~@@ ~s@  ~ ~o~oc@~~ibt~va d~  ~m@o~ @b@b~y/St ~~i n @ @l-@f~M@~@o@~@o~ ~@.@K@@~ ~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    new-instance v4, Lio/reactivex/internal/subscriptions/o;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {v4}, Lio/reactivex/internal/subscriptions/o;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {p1, v4}, Lja/c;->q(Lja/d;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v6, Lio/reactivex/internal/operators/flowable/p2$a;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/p2;->c:J

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-wide v2, 0x7fffffffffffffffL

    const/4 v8, 0x1

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    cmp-long v5, v0, v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v5, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x5

    sub-long/2addr v0, v2

    move-wide v2, v0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/p2$a;-><init>(Lja/c;JLio/reactivex/internal/subscriptions/o;Lja/b;)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v6}, Lio/reactivex/internal/operators/flowable/p2$a;->a()V

    const/4 v8, 0x7

    return-void
.end method
