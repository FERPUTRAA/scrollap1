.class final Lio/reactivex/internal/operators/flowable/g2$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/g2;->e8(Lio/reactivex/k;I)Lio/reactivex/flowables/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lja/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/atomic/AtomicReference;

.field final synthetic b:I


# direct methods
.method constructor <init>(Ljava/util/concurrent/atomic/AtomicReference;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g2$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p2, p0, Lio/reactivex/internal/operators/flowable/g2$a;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public j(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~sio@~l  ~~u@t @i@@ b@@~~~~~n@/rsM1 v@~.lb~@~@K o o -@@~fStb~o~f4~ @@@y @~c@~@ od i~ /~ ~ a  m~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    new-instance v0, Lio/reactivex/internal/operators/flowable/g2$b;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {v0, p1}, Lio/reactivex/internal/operators/flowable/g2$b;-><init>(Lja/c;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    :cond_0
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g2$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    check-cast p1, Lio/reactivex/internal/operators/flowable/g2$c;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz p1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/g2$c;->a()Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v1, :cond_3

    :cond_1
    const/4 v5, 0x2

    new-instance v1, Lio/reactivex/internal/operators/flowable/g2$c;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g2$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x6

    iget v3, p0, Lio/reactivex/internal/operators/flowable/g2$a;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1, v2, v3}, Lio/reactivex/internal/operators/flowable/g2$c;-><init>(Ljava/util/concurrent/atomic/AtomicReference;I)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g2$a;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2, p1, v1}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-nez p1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1, v0}, Lio/reactivex/internal/operators/flowable/g2$c;->b(Lio/reactivex/internal/operators/flowable/g2$b;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-wide/high16 v3, -0x8000000000000000L

    const-wide/high16 v3, -0x8000000000000000L

    const/4 v6, 0x0

    const-wide/high16 v3, -0x8000000000000000L

    const-wide/high16 v3, -0x8000000000000000L

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    cmp-long v1, v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez v1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Lio/reactivex/internal/operators/flowable/g2$c;->g(Lio/reactivex/internal/operators/flowable/g2$b;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_1

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput-object p1, v0, Lio/reactivex/internal/operators/flowable/g2$b;->parent:Lio/reactivex/internal/operators/flowable/g2$c;

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/g2$c;->d()V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void
.end method
