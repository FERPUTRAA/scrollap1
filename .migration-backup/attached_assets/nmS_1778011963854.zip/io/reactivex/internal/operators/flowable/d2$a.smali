.class final Lio/reactivex/internal/operators/flowable/d2$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/d2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x24360dbf312449bL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final current:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "TT;>;"
        }
    .end annotation
.end field

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x2

    move v2, v1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x0

    move v2, v1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->current:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d2$a;->actual:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method a(ZZLja/c;Ljava/util/concurrent/atomic/AtomicReference;)Z
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lja/c<",
            "*>;",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "TT;>;)Z"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "o@svso@l @o@ao n ~ @ bi@y~~~@@d@~u@@i@Ko~~@ .t@~ ~1f /~rcM~~~   /~b b~~~@4m@lf~ ~S ~@@@@~o  ~t i"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->cancelled:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p4, v1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return v2

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/d2$a;->error:Ljava/lang/Throwable;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p4, v1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v2

    :cond_1
    const/4 v4, 0x0

    if-eqz p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {p3}, Lja/c;->onComplete()V

    const/4 v4, 0x4

    return v2

    :cond_2
    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x1

    move v3, p1

    move v3, p1

    const/4 v4, 0x1

    return p1
.end method

.method b()V
    .locals 15

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x2

    if-eqz v0, :cond_0

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x3

    return-void

    :cond_0
    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->actual:Lja/c;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d2$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v13, 0x2

    const/4 v14, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/d2$a;->current:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x6

    const/4 v3, 0x1

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x5

    move v4, v3

    move v4, v3

    const/4 v14, 0x2

    move v4, v3

    move v4, v3

    :cond_1
    const/4 v14, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    move-wide v7, v5

    :goto_0
    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v9

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x6

    cmp-long v9, v7, v9

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x2

    const/4 v10, 0x0

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x5

    if-eqz v9, :cond_5

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    iget-boolean v9, p0, Lio/reactivex/internal/operators/flowable/d2$a;->done:Z

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x5

    const/4 v11, 0x0

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x4

    invoke-virtual {v2, v11}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x3

    if-nez v11, :cond_2

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x5

    move v12, v3

    move v12, v3

    const/4 v14, 0x0

    move v12, v3

    move v12, v3

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x6

    goto :goto_1

    :cond_2
    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x3

    move v12, v10

    move v12, v10

    move v12, v10

    :goto_1
    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {p0, v9, v12, v0, v2}, Lio/reactivex/internal/operators/flowable/d2$a;->a(ZZLja/c;Ljava/util/concurrent/atomic/AtomicReference;)Z

    move-result v9

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x4

    if-eqz v9, :cond_3

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x1

    return-void

    :cond_3
    const/4 v14, 0x2

    const/4 v13, 0x7

    if-eqz v12, :cond_4

    const/4 v13, 0x5

    move v14, v13

    goto :goto_2

    :cond_4
    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-interface {v0, v11}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x1

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const/4 v14, 0x5

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x3

    add-long/2addr v7, v9

    const/4 v14, 0x0

    goto :goto_0

    :cond_5
    :goto_2
    const/4 v14, 0x4

    const/4 v13, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v11

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x4

    cmp-long v9, v7, v11

    if-nez v9, :cond_7

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x5

    iget-boolean v9, p0, Lio/reactivex/internal/operators/flowable/d2$a;->done:Z

    const/4 v13, 0x7

    move v14, v13

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v11

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x7

    if-nez v11, :cond_6

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    move v10, v3

    :cond_6
    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x6

    invoke-virtual {p0, v9, v10, v0, v2}, Lio/reactivex/internal/operators/flowable/d2$a;->a(ZZLja/c;Ljava/util/concurrent/atomic/AtomicReference;)Z

    move-result v9

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x1

    if-eqz v9, :cond_7

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x1

    return-void

    :cond_7
    const/4 v13, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x1

    cmp-long v5, v7, v5

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x0

    if-eqz v5, :cond_8

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x2

    invoke-static {v1, v7, v8}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_8
    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x6

    neg-int v4, v4

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v4

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x3

    if-nez v4, :cond_1

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x4

    return-void
.end method

.method public cancel()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->cancelled:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->cancelled:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->s:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->current:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x0

    or-int/2addr v3, v1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->current:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/d2$a;->b()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/d2$a;->b()V

    :cond_0
    const/4 v2, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->done:Z

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/d2$a;->b()V

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d2$a;->error:Ljava/lang/Throwable;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/d2$a;->done:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/d2$a;->b()V

    const/4 v0, 0x5

    and-int/2addr v1, v0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->s:Lja/d;

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d2$a;->s:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d2$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    return-void
.end method
