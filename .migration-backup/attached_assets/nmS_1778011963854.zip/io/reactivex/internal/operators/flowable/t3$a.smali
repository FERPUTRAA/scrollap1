.class final Lio/reactivex/internal/operators/flowable/t3$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/t3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4eca0434695949bbL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final count:J

.field final delayError:Z

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;

.field final scheduler:Lio/reactivex/e0;

.field final time:J

.field final unit:Ljava/util/concurrent/TimeUnit;


# direct methods
.method constructor <init>(Lja/c;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "IZ)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->actual:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/t3$a;->count:J

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/t3$a;->time:J

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/t3$a;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p7, p0, Lio/reactivex/internal/operators/flowable/t3$a;->scheduler:Lio/reactivex/e0;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1, p8}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-boolean p9, p0, Lio/reactivex/internal/operators/flowable/t3$a;->delayError:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method a(ZLja/c;Z)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z",
            "Lja/c<",
            "-TT;>;Z)Z"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "- s~@@@yo@@ or/@o~b@~@S@@i  ~~~i@4d @ ~1~ ~ @ibo~@@o~c~t n@ lo~abK~@m~tM~f~~s ~     lf/@~u@~ ~v."

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->cancelled:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    and-int/2addr v3, v1

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->error:Ljava/lang/Throwable;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {p2, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {p2}, Lja/c;->onComplete()V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    return v1

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object p3, p0, Lio/reactivex/internal/operators/flowable/t3$a;->error:Ljava/lang/Throwable;

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p3, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {p2, p3}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return v1

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p2}, Lja/c;->onComplete()V

    const/4 v3, 0x1

    return v1

    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return p1
.end method

.method b()V
    .locals 15

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x0

    if-eqz v0, :cond_0

    const/4 v13, 0x3

    move v14, v13

    return-void

    :cond_0
    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->actual:Lja/c;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/t3$a;->delayError:Z

    const/4 v14, 0x3

    const/4 v3, 0x1

    const/4 v14, 0x0

    move v13, v3

    move v13, v3

    const/4 v14, 0x5

    move v4, v3

    const/4 v14, 0x1

    move v4, v3

    move v4, v3

    :cond_1
    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x3

    iget-boolean v5, p0, Lio/reactivex/internal/operators/flowable/t3$a;->done:Z

    const/4 v13, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x4

    if-eqz v5, :cond_6

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x1

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v5

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-virtual {p0, v5, v0, v2}, Lio/reactivex/internal/operators/flowable/t3$a;->a(ZLja/c;Z)Z

    move-result v5

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x5

    if-eqz v5, :cond_2

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x2

    return-void

    :cond_2
    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x5

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/t3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x2

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v5

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x6

    const-wide/16 v7, 0x0

    const/4 v14, 0x3

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    move-wide v9, v7

    :goto_0
    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x5

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->peek()Ljava/lang/Object;

    move-result-object v11

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x3

    if-nez v11, :cond_3

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x7

    move v11, v3

    move v11, v3

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x3

    goto :goto_1

    :cond_3
    const/4 v13, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x6

    const/4 v11, 0x0

    :goto_1
    const/4 v14, 0x1

    invoke-virtual {p0, v11, v0, v2}, Lio/reactivex/internal/operators/flowable/t3$a;->a(ZLja/c;Z)Z

    move-result v11

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x4

    if-eqz v11, :cond_4

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x7

    return-void

    :cond_4
    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x5

    cmp-long v11, v5, v9

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x2

    if-nez v11, :cond_5

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x4

    cmp-long v5, v9, v7

    const/4 v14, 0x3

    if-eqz v5, :cond_6

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x2

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/t3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x1

    invoke-static {v5, v9, v10}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x3

    goto :goto_2

    :cond_5
    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v11

    const/4 v14, 0x6

    const/4 v13, 0x3

    invoke-interface {v0, v11}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v13, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x2

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x0

    add-long/2addr v9, v11

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x4

    goto :goto_0

    :cond_6
    :goto_2
    const/4 v13, 0x5

    const/4 v14, 0x3

    neg-int v4, v4

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x3

    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v4

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x4

    if-nez v4, :cond_1

    const/4 v13, 0x6

    shl-int/2addr v14, v13

    return-void
.end method

.method c(JLio/reactivex/internal/queue/c;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lio/reactivex/internal/queue/c<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->time:J

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/t3$a;->count:J

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const/4 v11, 0x0

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    cmp-long v4, v2, v4

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v5, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-nez v4, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    move v4, v5

    move v4, v5

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    goto :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v4, 0x0

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p3}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v6

    const/4 v11, 0x7

    const/4 v10, 0x2

    if-nez v6, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {p3}, Lio/reactivex/internal/queue/c;->peek()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    check-cast v6, Ljava/lang/Long;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v6}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    sub-long v8, p1, v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    cmp-long v6, v6, v8

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-ltz v6, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-nez v4, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {p3}, Lio/reactivex/internal/queue/c;->r()I

    move-result v6

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    shr-int/2addr v6, v5

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    int-to-long v6, v6

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    cmp-long v6, v6, v2

    const/4 v11, 0x5

    const/4 v10, 0x6

    if-lez v6, :cond_2

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p3}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {p3}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    goto :goto_0

    :cond_2
    const/4 v10, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->cancelled:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->cancelled:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->s:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    :cond_0
    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->scheduler:Lio/reactivex/e0;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t3$a;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v3, p1}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v4, 0x1

    and-int/2addr v5, v4

    invoke-virtual {p0, v1, v2, v0}, Lio/reactivex/internal/operators/flowable/t3$a;->c(JLio/reactivex/internal/queue/c;)V

    const/4 v5, 0x1

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/t3$a;->b()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->scheduler:Lio/reactivex/e0;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0, v0, v1, v2}, Lio/reactivex/internal/operators/flowable/t3$a;->c(JLio/reactivex/internal/queue/c;)V

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->done:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/t3$a;->b()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->delayError:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->scheduler:Lio/reactivex/e0;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v4, 0x4

    invoke-virtual {p0, v0, v1, v2}, Lio/reactivex/internal/operators/flowable/t3$a;->c(JLio/reactivex/internal/queue/c;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->error:Ljava/lang/Throwable;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->done:Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/t3$a;->b()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->s:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/t3$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t3$a;->actual:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
