.class Lio/reactivex/internal/operators/flowable/d$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/d$a;->d()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private a:Ljava/lang/Object;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/d$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/d$a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->b:Lio/reactivex/internal/operators/flowable/d$a;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public hasNext()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "t sv@-bKyl@~~o~~~fis@@~~@i@o @ @rb~1  ~@ @o  m@uno~~~~co@@4  o~f.~/ ~~S@a  l  ~~b@i@/~@M  d~@@@t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->b:Lio/reactivex/internal/operators/flowable/d$a;

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/d$a;->b:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/util/p;->m(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->b:Lio/reactivex/internal/operators/flowable/d$a;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/d$a;->b:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-static {v1}, Lio/reactivex/internal/util/p;->m(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v1}, Lio/reactivex/internal/util/p;->p(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1}, Lio/reactivex/internal/util/p;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v1

    :cond_1
    :try_start_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v1}, Lio/reactivex/internal/util/p;->i(Ljava/lang/Object;)Ljava/lang/Throwable;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    throw v1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Ljava/util/NoSuchElementException;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x7

    throw v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/d$a$a;->a:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw v1
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const-string v1, "iyomraeRsta tole d"

    const-string/jumbo v1, "trs lRaireydetoa o"

    const/4 v3, 0x5

    const-string v1, "aialot  noRrrdyoee"

    const-string v1, "Read only iterator"

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    throw v0
.end method
