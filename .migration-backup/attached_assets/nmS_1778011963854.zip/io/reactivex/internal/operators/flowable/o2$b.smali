.class Lio/reactivex/internal/operators/flowable/o2$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/o2;->Y7(Lio/reactivex/disposables/b;)Lio/reactivex/disposables/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/disposables/b;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/o2;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/o2;Lio/reactivex/disposables/b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v0, 0x1

    move v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o2$b;->a:Lio/reactivex/disposables/b;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ss ~@/u@@ c @o~f@S b~@/@~4@@ftoo~~ @a ~~n@o o~@~@~b1@iv~i  m@  b Ki~M@d~~r~ l@~ ~@@~t . y~ ~~-l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$b;->a:Lio/reactivex/disposables/b;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x7

    const/4 v2, 0x4

    new-instance v1, Lio/reactivex/disposables/b;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v1, v0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$b;->b:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x2

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw v0
.end method
