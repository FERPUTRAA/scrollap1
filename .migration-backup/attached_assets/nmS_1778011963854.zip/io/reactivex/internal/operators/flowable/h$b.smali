.class final Lio/reactivex/internal/operators/flowable/h$b;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x10756d62aa142dccL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final index:I

.field final missedRequested:Ljava/util/concurrent/atomic/AtomicLong;

.field final parent:Lio/reactivex/internal/operators/flowable/h$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/h$a<",
            "TT;>;"
        }
    .end annotation
.end field

.field won:Z


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/h$a;ILja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/h$a<",
            "TT;>;I",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->missedRequested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h$b;->parent:Lio/reactivex/internal/operators/flowable/h$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p2, p0, Lio/reactivex/internal/operators/flowable/h$b;->index:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->won:Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->parent:Lio/reactivex/internal/operators/flowable/h$a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/h$b;->index:I

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/h$a;->b(I)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->won:Z

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    check-cast p1, Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p1}, Lja/d;->cancel()V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->missedRequested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0, v0, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->won:Z

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->parent:Lio/reactivex/internal/operators/flowable/h$a;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, p0, Lio/reactivex/internal/operators/flowable/h$b;->index:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/h$a;->b(I)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->won:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->won:Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->parent:Lio/reactivex/internal/operators/flowable/h$a;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lio/reactivex/internal/operators/flowable/h$b;->index:I

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/h$a;->b(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->won:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$b;->missedRequested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x5

    invoke-static {p0, v0, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v2, 0x1

    return-void
.end method
