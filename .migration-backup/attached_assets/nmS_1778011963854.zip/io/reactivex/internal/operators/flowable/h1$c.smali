.class final Lio/reactivex/internal/operators/flowable/h1$c;
.super Lio/reactivex/internal/subscriptions/c;

# interfaces
.implements Lja/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "K:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/c<",
        "TT;>;",
        "Lja/b<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x35762a4bbab31538L


# instance fields
.field final actual:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/c<",
            "-TT;>;>;"
        }
    .end annotation
.end field

.field final cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final delayError:Z

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final key:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TK;"
        }
    .end annotation
.end field

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field outputFused:Z

.field final parent:Lio/reactivex/internal/operators/flowable/h1$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/h1$a<",
            "*TK;TT;>;"
        }
    .end annotation
.end field

.field produced:I

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "TT;>;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;


# direct methods
.method constructor <init>(ILio/reactivex/internal/operators/flowable/h1$a;Ljava/lang/Object;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lio/reactivex/internal/operators/flowable/h1$a<",
            "*TK;TT;>;TK;Z)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/c;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->actual:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h1$c;->parent:Lio/reactivex/internal/operators/flowable/h1$a;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/h1$c;->key:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-boolean p4, p0, Lio/reactivex/internal/operators/flowable/h1$c;->delayError:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method a(ZZLja/c;Z)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lja/c<",
            "-TT;>;Z)Z"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~v~Sna~ /l~~~@~i~r ~o4~~i@bu~oy s@@@o. f~o@~@@@o  im~ /d1 ~@ @ Kb ~@~t@  @@  @Mo~@l@~t- fcb @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p4, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p2, :cond_4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->error:Ljava/lang/Throwable;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p3}, Lja/c;->onComplete()V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v1

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->error:Ljava/lang/Throwable;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p1, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p2}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    return v1

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p2, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p3}, Lja/c;->onComplete()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v1

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p1
.end method

.method c()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->outputFused:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->e()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->k()V

    :goto_0
    const/4 v2, 0x6

    return-void
.end method

.method public cancel()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->parent:Lio/reactivex/internal/operators/flowable/h1$a;

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->key:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/h1$a;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method e()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->actual:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v1, Lja/c;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v2, 0x1

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h1$c;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/h1$c;->done:Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v3, :cond_2

    const/4 v6, 0x7

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/h1$c;->delayError:Z

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/h1$c;->error:Ljava/lang/Throwable;

    const/4 v6, 0x3

    const/4 v5, 0x3

    if-eqz v4, :cond_2

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1, v4}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void

    :cond_2
    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v1, v4}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v3, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->error:Ljava/lang/Throwable;

    const/4 v6, 0x0

    if-eqz v0, :cond_3

    const/4 v6, 0x5

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v1}, Lja/c;->onComplete()V

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-void

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    neg-int v2, v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v2, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->actual:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    check-cast v1, Lja/c;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto/16 :goto_0
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/queue/c;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->c()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->c()V

    :cond_0
    const/4 v1, 0x2

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public j(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->actual:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->c()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const-string v1, "e nmsolOybalclondre ewsru! i"

    const-string v1, "nes!badOeSlulrwocos n ryiel "

    const/4 v4, 0x6

    const-string v1, "Only one Subscriber allowed!"

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method k()V
    .locals 15

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    iget-boolean v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->delayError:Z

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/h1$c;->actual:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lja/c;

    const/4 v3, 0x1

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :cond_0
    :goto_0
    if-eqz v2, :cond_7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/h1$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v5

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    move-wide v9, v7

    :goto_1
    cmp-long v11, v9, v5

    if-eqz v11, :cond_4

    iget-boolean v12, p0, Lio/reactivex/internal/operators/flowable/h1$c;->done:Z

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v13

    if-nez v13, :cond_1

    move v14, v3

    move v14, v3

    move v14, v3

    move v14, v3

    goto :goto_2

    :cond_1
    const/4 v14, 0x0

    :goto_2
    invoke-virtual {p0, v12, v14, v2, v1}, Lio/reactivex/internal/operators/flowable/h1$c;->a(ZZLja/c;Z)Z

    move-result v12

    if-eqz v12, :cond_2

    return-void

    :cond_2
    if-eqz v14, :cond_3

    goto :goto_3

    :cond_3
    invoke-interface {v2, v13}, Lja/c;->f(Ljava/lang/Object;)V

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    add-long/2addr v9, v11

    goto :goto_1

    :cond_4
    :goto_3
    if-nez v11, :cond_5

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/h1$c;->done:Z

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v12

    invoke-virtual {p0, v11, v12, v2, v1}, Lio/reactivex/internal/operators/flowable/h1$c;->a(ZZLja/c;Z)Z

    move-result v11

    if-eqz v11, :cond_5

    return-void

    :cond_5
    cmp-long v7, v9, v7

    if-eqz v7, :cond_7

    const-wide v7, 0x7fffffffffffffffL

    const-wide v7, 0x7fffffffffffffffL

    const-wide v7, 0x7fffffffffffffffL

    cmp-long v5, v5, v7

    if-eqz v5, :cond_6

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/h1$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    neg-long v6, v9

    invoke-virtual {v5, v6, v7}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    :cond_6
    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/h1$c;->parent:Lio/reactivex/internal/operators/flowable/h1$a;

    iget-object v5, v5, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    invoke-interface {v5, v9, v10}, Lja/d;->g(J)V

    :cond_7
    neg-int v4, v4

    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v4

    if-nez v4, :cond_8

    return-void

    :cond_8
    if-nez v2, :cond_0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/h1$c;->actual:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lja/c;

    goto :goto_0
.end method

.method public l(I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->outputFused:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->done:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->c()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->error:Ljava/lang/Throwable;

    const/4 v0, 0x6

    and-int/2addr v1, v0

    const/4 p1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->done:Z

    const/4 v0, 0x2

    shl-int/2addr v1, v0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$c;->c()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public poll()Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    move v5, v4

    iget v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->produced:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->produced:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/h1$c;->produced:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->produced:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$c;->parent:Lio/reactivex/internal/operators/flowable/h1$a;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    int-to-long v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v1, v2, v3}, Lja/d;->g(J)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object v0
.end method
