.class final Lio/reactivex/internal/operators/flowable/h3$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field b:J

.field c:Lja/d;


# direct methods
.method constructor <init>(Lja/c;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h3$a;->a:Lja/c;

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/h3$a;->b:J

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ls@iyb~/~K b~   @~~s~/@cf@~Mn@~@@l@~~@i-oa @@~r~o@ m b~@~@~t~  S u~o~~v@ ~o4@@ o.~@id1@ o~@f  t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->c:Lja/d;

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->b:J

    const/4 v5, 0x2

    const/4 v4, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    cmp-long v2, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    sub-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->b:J

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->a:Lja/c;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->c:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->a:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->a:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->c:Lja/d;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/h3$a;->b:J

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h3$a;->c:Lja/d;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/h3$a;->a:Lja/c;

    const/4 v4, 0x1

    invoke-interface {v2, p0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method
