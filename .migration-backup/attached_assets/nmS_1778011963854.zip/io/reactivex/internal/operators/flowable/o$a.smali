.class final Lio/reactivex/internal/operators/flowable/o$a;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TB;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/o$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/o$b<",
            "TT;TU;TB;>;"
        }
    .end annotation
.end field

.field c:Z


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/o$b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/o$b<",
            "TT;TU;TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o$a;->b:Lio/reactivex/internal/operators/flowable/o$b;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TB;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@bsli @y 4~o@@d-fi@~l@Mo~tS~@~K@r~ @b@  i o~ ~m@of 1~~n~/@ t@~@ @b v ~ ~ /o~@~ ~@.ao~~s@ ~u~@c~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/o$a;->c:Z

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 p1, 0x7

    const/4 p1, 0x1

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/o$a;->c:Z

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-virtual {p0}, Lio/reactivex/subscribers/b;->b()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o$a;->b:Lio/reactivex/internal/operators/flowable/o$b;

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/o$b;->v()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o$a;->c:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o$a;->c:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o$a;->b:Lio/reactivex/internal/operators/flowable/o$b;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/o$b;->v()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o$a;->c:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o$a;->c:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o$a;->b:Lio/reactivex/internal/operators/flowable/o$b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/o$b;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method
