.class final Lio/reactivex/internal/operators/flowable/q2$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/q2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x628271a96862fff0L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final sa:Lio/reactivex/internal/subscriptions/o;

.field final source:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final stop:Lt7/e;


# direct methods
.method constructor <init>(Lja/c;Lt7/e;Lio/reactivex/internal/subscriptions/o;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/e;",
            "Lio/reactivex/internal/subscriptions/o;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q2$a;->actual:Lja/c;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/q2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/q2$a;->source:Lja/b;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/q2$a;->stop:Lt7/e;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "r@s@n~ lo~ f @  ~io@ ~ ~~oK@b@. @f @a@@~~t~/lo~b~~~i~  y -@ @c~s v@~@b/d  u~ S@1o@~~t~@@i4o@~m@M"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x1

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q2$a;->source:Lja/b;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v1, p0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    neg-int v0, v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q2$a;->actual:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x5

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Lio/reactivex/internal/subscriptions/o;->e(J)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q2$a;->stop:Lt7/e;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0}, Lt7/e;->a()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q2$a;->actual:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q2$a;->a()V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q2$a;->actual:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q2$a;->actual:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method
