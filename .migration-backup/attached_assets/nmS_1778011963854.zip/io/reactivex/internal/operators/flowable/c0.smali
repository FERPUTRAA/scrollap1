.class public final Lio/reactivex/internal/operators/flowable/c0;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/c0$a;,
        Lio/reactivex/internal/operators/flowable/c0$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:Ljava/util/concurrent/TimeUnit;

.field final e:Lio/reactivex/e0;


# direct methods
.method public constructor <init>(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/c0;->c:J

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/c0;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/c0;->e:Lio/reactivex/e0;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, " ls  @4@-/@~ @~ @~ts@ ~@~b @@@o@o yic@a/~v@b~if~u1 M~f~@~~ K@~@~~oo  @r~~ Sm oli~@@on b~~ dt@.~~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v9, 0x6

    const/4 v8, 0x0

    new-instance v7, Lio/reactivex/internal/operators/flowable/c0$b;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/c0;->c:J

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/c0;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x6

    move v9, v8

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c0;->e:Lio/reactivex/e0;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p1}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v6

    move-object v1, v7

    move-object v1, v7

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct/range {v1 .. v6}, Lio/reactivex/internal/operators/flowable/c0$b;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;)V

    const/4 v9, 0x1

    invoke-interface {v0, v7}, Lja/b;->j(Lja/c;)V

    const/4 v9, 0x3

    return-void
.end method
