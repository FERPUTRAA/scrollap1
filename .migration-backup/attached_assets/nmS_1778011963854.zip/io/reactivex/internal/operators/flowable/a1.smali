.class public final Lio/reactivex/internal/operators/flowable/a1;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/a1$a;,
        Lio/reactivex/internal/operators/flowable/a1$b;,
        Lio/reactivex/internal/operators/flowable/a1$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:[Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>([Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([TT;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v0, 0x4

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a1;->b:[Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "o s o~~@b@~@KM ~@@@1@4o b~f~i@b@~s@@~@~i~y~@ lo/-@~tml o~~a~ i~@~~@ d  ~ o@~    @tuSc/~n ~.@@vfr"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    instance-of v0, p1, Lu7/a;

    const/4 v3, 0x7

    and-int/2addr v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v0, Lio/reactivex/internal/operators/flowable/a1$a;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v4, 0x5

    check-cast v1, Lu7/a;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a1;->b:[Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/a1$a;-><init>(Lu7/a;[Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/a1$b;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a1;->b:[Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0, p1, v1}, Lio/reactivex/internal/operators/flowable/a1$b;-><init>(Lja/c;[Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method
