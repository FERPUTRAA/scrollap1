.class final Lio/reactivex/internal/operators/flowable/n3$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/n3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Ljava/lang/Thread;",
        ">;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x70559c6a66be0138L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final nonScheduledRequests:Z

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final s:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field

.field source:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final worker:Lio/reactivex/e0$c;


# direct methods
.method constructor <init>(Lja/c;Lio/reactivex/e0$c;Lja/b;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lio/reactivex/e0$c;",
            "Lja/b<",
            "TT;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n3$a;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n3$a;->worker:Lio/reactivex/e0$c;

    const/4 v1, 0x0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/n3$a;->source:Lja/b;

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-boolean p4, p0, Lio/reactivex/internal/operators/flowable/n3$a;->nonScheduledRequests:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method a(JLja/d;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bsrfd  @~ o@u@~~  .@ @i@~n ~@l/   /~sl  ~@@o@@Kci~@@ov~bS@  b~Mo ~@~a~yi@o@- ~~m~ ~ot~~@ft~1~@4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->nonScheduledRequests:Z

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->worker:Lio/reactivex/e0$c;

    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/n3$a$a;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v1, p0, p3, p1, p2}, Lio/reactivex/internal/operators/flowable/n3$a$a;-><init>(Lio/reactivex/internal/operators/flowable/n3$a;Lja/d;J)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/e0$c;->c(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-interface {p3, p1, p2}, Lja/d;->g(J)V

    :goto_1
    const/4 v3, 0x4

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->worker:Lio/reactivex/e0$c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public g(J)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    move v5, v4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v0, Lja/d;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0, p1, p2, v0}, Lio/reactivex/internal/operators/flowable/n3$a;->a(JLja/d;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast p1, Lja/d;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/n3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const/4 v5, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->getAndSet(J)J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    cmp-long p2, v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz p2, :cond_1

    const/4 v5, 0x0

    invoke-virtual {p0, v2, v3, p1}, Lio/reactivex/internal/operators/flowable/n3$a;->a(JLja/d;)V

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->worker:Lio/reactivex/e0$c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->actual:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n3$a;->worker:Lio/reactivex/e0$c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p1}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-wide/16 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;->getAndSet(J)J

    move-result-wide v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    cmp-long v0, v3, v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    invoke-virtual {p0, v3, v4, p1}, Lio/reactivex/internal/operators/flowable/n3$a;->a(JLja/d;)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method

.method public run()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3$a;->source:Lja/b;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/n3$a;->source:Lja/b;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0, p0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method
