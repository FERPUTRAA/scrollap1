.class final Lio/reactivex/internal/operators/flowable/m1$e;
.super Ljava/lang/Object;

# interfaces
.implements Lt7/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/m1;->h(Lt7/o;Lio/reactivex/e0;)Lt7/o;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lt7/o<",
        "Lio/reactivex/k<",
        "TT;>;",
        "Lja/b<",
        "TR;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lt7/o;

.field final synthetic b:Lio/reactivex/e0;


# direct methods
.method constructor <init>(Lt7/o;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$e;->a:Lt7/o;

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m1$e;->b:Lio/reactivex/e0;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public a(Lio/reactivex/k;)Lja/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/k<",
            "TT;>;)",
            "Lja/b<",
            "TR;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$e;->a:Lt7/o;

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p1, Lja/b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/k;->A2(Lja/b;)Lio/reactivex/k;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$e;->b:Lio/reactivex/e0;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lio/reactivex/k;->I3(Lio/reactivex/e0;)Lio/reactivex/k;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    check-cast p1, Lio/reactivex/k;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m1$e;->a(Lio/reactivex/k;)Lja/b;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method
