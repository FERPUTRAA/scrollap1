.class abstract Lio/reactivex/internal/operators/flowable/a0$b;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lio/reactivex/l;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lio/reactivex/l<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x65ac35ee8a56a4bfL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final serial:Lio/reactivex/internal/disposables/k;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    new-instance p1, Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p1}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final b(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/internal/disposables/k;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public final c(Lt7/f;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    new-instance v0, Lio/reactivex/internal/disposables/b;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lio/reactivex/internal/disposables/b;-><init>(Lt7/f;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a0$b;->b(Lio/reactivex/disposables/c;)V

    const/4 v1, 0x6

    move v2, v1

    return-void
.end method

.method public final cancel()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->h()V

    const/4 v2, 0x5

    return-void
.end method

.method public final d()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-wide v0
.end method

.method e()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public final g(J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->e()V

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method h()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public final isCancelled()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->a()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Lja/c;->onComplete()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->e()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/disposables/k;->e()V

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v0
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "u sduryN Er.nsoa liapde s l aha e. rtlnn atuec  ssogre .llluoietnnno2aedrcsrll elxvwaeoor orl"

    const-string v0, "i suyarnodornaEulegc.lc es veolo laleapx uoelr ld  s.dtw eln wnileur l.osar nnseNtata rh2 orr"

    const/4 v2, 0x2

    const-string v0, "rvlmnole a anuo   opalrlooescdtstartnrrN uons  d.ur aaglioye  xeln. l2ewrllrEe.wuiae dnscelh "

    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v1, 0x6

    const/4 v1, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-void

    :cond_1
    :try_start_0
    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1}, Lio/reactivex/internal/disposables/k;->e()V

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->serial:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->e()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p1
.end method

.method public final serialize()Lio/reactivex/l;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/l<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/a0$i;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/flowable/a0$i;-><init>(Lio/reactivex/internal/operators/flowable/a0$b;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method
