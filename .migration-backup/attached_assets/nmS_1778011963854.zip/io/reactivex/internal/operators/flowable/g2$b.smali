.class final Lio/reactivex/internal/operators/flowable/g2$b;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/g2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x3dcf6c3b2e70d8baL


# instance fields
.field final child:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile parent:Lio/reactivex/internal/operators/flowable/g2$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/g2$c<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g2$b;->child:Lja/c;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(J)J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "c sMo@.@@u~ibb s-or ~~od@ ~~t@  @@@ t ~~@@K~  ~@~@4~ @l@ibi@my~o o~ ~f~f@@~n@@S~/v a~@~ ~ ~ 1/o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->f(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-wide p1
.end method

.method public cancel()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x2

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;->getAndSet(J)J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g2$b;->parent:Lio/reactivex/internal/operators/flowable/g2$c;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Lio/reactivex/internal/operators/flowable/g2$c;->g(Lio/reactivex/internal/operators/flowable/g2$b;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/g2$c;->d()V

    :cond_0
    const/4 v5, 0x2

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->b(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g2$b;->parent:Lio/reactivex/internal/operators/flowable/g2$c;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/g2$c;->d()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method
