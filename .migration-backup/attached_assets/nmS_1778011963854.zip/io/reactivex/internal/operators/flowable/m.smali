.class public final Lio/reactivex/internal/operators/flowable/m;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/m$b;,
        Lio/reactivex/internal/operators/flowable/m$c;,
        Lio/reactivex/internal/operators/flowable/m$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "C::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TC;>;"
    }
.end annotation


# instance fields
.field final c:I

.field final d:I

.field final e:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TC;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;IILjava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;II",
            "Ljava/util/concurrent/Callable<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p3, p0, Lio/reactivex/internal/operators/flowable/m;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/m;->e:Ljava/util/concurrent/Callable;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TC;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    iget v0, p0, Lio/reactivex/internal/operators/flowable/m;->c:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m;->d:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-ne v0, v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-instance v2, Lio/reactivex/internal/operators/flowable/m$a;

    const/4 v6, 0x7

    const/4 v5, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/m;->e:Ljava/util/concurrent/Callable;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {v2, p1, v0, v3}, Lio/reactivex/internal/operators/flowable/m$a;-><init>(Lja/c;ILjava/util/concurrent/Callable;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-le v1, v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/m$c;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v2, p0, Lio/reactivex/internal/operators/flowable/m;->c:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v3, p0, Lio/reactivex/internal/operators/flowable/m;->d:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/m;->e:Ljava/util/concurrent/Callable;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v1, p1, v2, v3, v4}, Lio/reactivex/internal/operators/flowable/m$c;-><init>(Lja/c;IILjava/util/concurrent/Callable;)V

    const/4 v5, 0x6

    and-int/2addr v6, v5

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/m$b;

    const/4 v6, 0x4

    const/4 v5, 0x4

    iget v2, p0, Lio/reactivex/internal/operators/flowable/m;->c:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v3, p0, Lio/reactivex/internal/operators/flowable/m;->d:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/m;->e:Ljava/util/concurrent/Callable;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v1, p1, v2, v3, v4}, Lio/reactivex/internal/operators/flowable/m$b;-><init>(Lja/c;IILjava/util/concurrent/Callable;)V

    const/4 v6, 0x5

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    return-void
.end method
