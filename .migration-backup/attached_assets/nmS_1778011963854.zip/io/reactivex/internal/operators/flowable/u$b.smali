.class final Lio/reactivex/internal/operators/flowable/u$b;
.super Lio/reactivex/internal/subscriptions/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/c<",
        "TR;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4687de9589e4abbdL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TR;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final combiner:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "+TR;>;"
        }
    .end annotation
.end field

.field completedSources:I

.field final delayErrors:Z

.field volatile done:Z

.field final error:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field final latest:[Ljava/lang/Object;

.field nonEmptySources:I

.field outputFused:Z

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final subscribers:[Lio/reactivex/internal/operators/flowable/u$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lio/reactivex/internal/operators/flowable/u$c<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/o;IIZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "+TR;>;IIZ)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/c;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->actual:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/u$b;->combiner:Lt7/o;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-array p1, p3, [Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p2, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-ge p2, p3, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0, p0, p2, p4}, Lio/reactivex/internal/operators/flowable/u$c;-><init>(Lio/reactivex/internal/operators/flowable/u$b;II)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    aput-object v0, p1, p2

    const/4 v2, 0x3

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->subscribers:[Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-array p1, p3, [Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->latest:[Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p1, p4}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-boolean p5, p0, Lio/reactivex/internal/operators/flowable/u$b;->delayErrors:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "S s.~~ t ~@bolb ~@ @~@~uo @f~/v~@-~~K1@~ti~~@~4@fs@~@ono M @ ~@~i ~rd@icy@am  ~~@@@@~ @oo l ~ / "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->subscribers:[Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    array-length v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x0

    if-ge v2, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    aget-object v3, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {v3}, Lio/reactivex/internal/operators/flowable/u$c;->a()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method c()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->outputFused:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->n()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->k()V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->cancelled:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v2, 0x2

    return-void
.end method

.method public clear()V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method e(ZZLja/c;Lio/reactivex/internal/queue/c;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lja/c<",
            "*>;",
            "Lio/reactivex/internal/queue/c<",
            "*>;)Z"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->cancelled:Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v3, 0x4

    invoke-virtual {p4}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz p1, :cond_4

    const/4 v3, 0x2

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->delayErrors:Z

    const/4 v2, 0x7

    move v3, v2

    if-eqz p1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p2, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1}, Lio/reactivex/internal/util/j;->c(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x2

    move v3, v2

    sget-object p2, Lio/reactivex/internal/util/j;->a:Ljava/lang/Throwable;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eq p1, p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p3}, Lja/c;->onComplete()V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1}, Lio/reactivex/internal/util/j;->c(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p1, :cond_3

    const/4 v3, 0x3

    sget-object v0, Lio/reactivex/internal/util/j;->a:Ljava/lang/Throwable;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eq p1, v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p4}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    return v1

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p2, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v2, 0x7

    const/4 v2, 0x4

    invoke-interface {p3}, Lja/c;->onComplete()V

    const/4 v3, 0x7

    return v1

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p1
.end method

.method public g(J)V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->c()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method k()V
    .locals 15

    const/4 v14, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->actual:Lja/c;

    const/4 v14, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v14, 0x5

    const/4 v2, 0x1

    const/4 v14, 0x6

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :cond_0
    const/4 v14, 0x0

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/u$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x1

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    const/4 v14, 0x2

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    move-wide v8, v6

    :goto_0
    const/4 v14, 0x5

    cmp-long v10, v8, v4

    const/4 v14, 0x6

    if-eqz v10, :cond_4

    const/4 v14, 0x1

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    const/4 v14, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x1

    if-nez v12, :cond_1

    const/4 v14, 0x2

    move v13, v2

    move v13, v2

    move v13, v2

    move v13, v2

    const/4 v14, 0x3

    goto :goto_1

    :cond_1
    const/4 v14, 0x7

    const/4 v13, 0x0

    :goto_1
    const/4 v14, 0x6

    invoke-virtual {p0, v11, v13, v0, v1}, Lio/reactivex/internal/operators/flowable/u$b;->e(ZZLja/c;Lio/reactivex/internal/queue/c;)Z

    move-result v11

    const/4 v14, 0x5

    if-eqz v11, :cond_2

    const/4 v14, 0x7

    return-void

    :cond_2
    if-eqz v13, :cond_3

    goto :goto_2

    :cond_3
    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v10

    const/4 v14, 0x3

    check-cast v10, [Ljava/lang/Object;

    :try_start_0
    const/4 v14, 0x5

    iget-object v11, p0, Lio/reactivex/internal/operators/flowable/u$b;->combiner:Lt7/o;

    const/4 v14, 0x7

    invoke-interface {v11, v10}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    const/4 v14, 0x4

    const-string v11, "nlnmlTteaiel o ce eudemr vnubrshra"

    const-string v11, "emsreTnie nleatr hl dlucb r oenvau"

    const-string v11, "The combiner returned a null value"

    const/4 v14, 0x0

    invoke-static {v10, v11}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x0

    invoke-interface {v0, v10}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v14, 0x6

    check-cast v12, Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v14, 0x0

    invoke-virtual {v12}, Lio/reactivex/internal/operators/flowable/u$c;->b()V

    const/4 v14, 0x2

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const/4 v14, 0x7

    add-long/2addr v8, v10

    const/4 v14, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v14, 0x0

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v14, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v14, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-static {v2, v1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    const/4 v14, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v14, 0x5

    invoke-static {v1}, Lio/reactivex/internal/util/j;->c(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    move-result-object v1

    const/4 v14, 0x6

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v14, 0x4

    return-void

    :cond_4
    :goto_2
    const/4 v14, 0x0

    if-nez v10, :cond_5

    iget-boolean v10, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    const/4 v14, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v11

    const/4 v14, 0x5

    invoke-virtual {p0, v10, v11, v0, v1}, Lio/reactivex/internal/operators/flowable/u$b;->e(ZZLja/c;Lio/reactivex/internal/queue/c;)Z

    move-result v10

    const/4 v14, 0x3

    if-eqz v10, :cond_5

    const/4 v14, 0x1

    return-void

    :cond_5
    const/4 v14, 0x5

    cmp-long v6, v8, v6

    const/4 v14, 0x4

    if-eqz v6, :cond_6

    const/4 v14, 0x0

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const/4 v14, 0x1

    cmp-long v4, v4, v6

    const/4 v14, 0x2

    if-eqz v4, :cond_6

    const/4 v14, 0x7

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/u$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x0

    neg-long v5, v8

    const/4 v14, 0x7

    invoke-virtual {v4, v5, v6}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    :cond_6
    neg-int v3, v3

    const/4 v14, 0x0

    invoke-virtual {p0, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const/4 v14, 0x0

    if-nez v3, :cond_0

    const/4 v14, 0x6

    return-void
.end method

.method public l(I)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    and-int/lit8 v0, p1, 0x4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    and-int/lit8 p1, p1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-boolean v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->outputFused:Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    return p1
.end method

.method n()V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->actual:Lja/c;

    const/4 v6, 0x5

    move v7, v6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v2, 0x1

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/u$b;->cancelled:Z

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v3, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-void

    :cond_1
    const/4 v7, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    check-cast v3, Ljava/lang/Throwable;

    const/4 v7, 0x5

    const/4 v6, 0x7

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v7, 0x5

    invoke-interface {v0, v3}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-nez v4, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v5, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {v0, v5}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v3, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v4, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-void

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    neg-int v2, v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez v2, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-void
.end method

.method public poll()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TR;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v4, 0x5

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast v1, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/u$b;->combiner:Lt7/o;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v2, v1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast v0, Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v4, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/u$c;->b()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v1
.end method

.method s(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->latest:[Ljava/lang/Object;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    aget-object p1, v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->completedSources:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    add-int/2addr p1, v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    array-length v0, v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne p1, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-boolean v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    iput p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->completedSources:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-boolean v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    :goto_0
    const/4 v2, 0x7

    const/4 v3, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->c()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw p1
.end method

.method t(ILjava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0, p2}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-boolean p2, p0, Lio/reactivex/internal/operators/flowable/u$b;->delayErrors:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->c()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/u$b;->s(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p2}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method u(ILjava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITT;)V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->latest:[Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->nonEmptySources:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    aget-object v2, v0, p1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->nonEmptySources:I

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    aput-object p2, v0, p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    array-length p2, v0

    if-ne p2, v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/u$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/u$b;->subscribers:[Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    aget-object v1, v1, p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, v1, v0}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p2, 0x1

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz p2, :cond_2

    const/4 v4, 0x0

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/u$b;->subscribers:[Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    aget-object p1, p2, p1

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/u$c;->b()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/u$b;->c()V

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    throw p1
.end method

.method v([Lja/b;I)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lja/b<",
            "+TT;>;I)V"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/u$b;->subscribers:[Lio/reactivex/internal/operators/flowable/u$c;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    if-ge v1, p2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/u$b;->done:Z

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/u$b;->cancelled:Z

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    aget-object v2, p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    aget-object v3, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v2, v3}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x5

    move v5, v4

    return-void
.end method
