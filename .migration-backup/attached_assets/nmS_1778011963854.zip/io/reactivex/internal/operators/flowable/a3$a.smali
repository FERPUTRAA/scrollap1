.class final Lio/reactivex/internal/operators/flowable/a3$a;
.super Lio/reactivex/internal/subscribers/t;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/t<",
        "TT;TR;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x18a87226297dfae5L


# instance fields
.field final accumulator:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TR;-TT;TR;>;"
        }
    .end annotation
.end field

.field done:Z


# direct methods
.method constructor <init>(Lja/c;Lt7/c;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lt7/c<",
            "TR;-TT;TR;>;TR;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/t;-><init>(Lja/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/a3$a;->accumulator:Lt7/c;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/subscribers/t;->value:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "u@so@ @@o~ M/~ @~~@ @@1 ~~@ @a@@~@~/  l nt@ ~ovioo@~ib . ~~SKcd~4s~bfo@~~@- t~@fiy   rl@~~mb ~~~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a3$a;->done:Z

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/t;->value:Ljava/lang/Object;

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a3$a;->accumulator:Lt7/c;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v1, v0, p1}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string/jumbo v1, "unemlaTeulouaerrn tllv uta c mcaur dh"

    const-string v1, "The accumulator returned a null value"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p1, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput-object p1, p0, Lio/reactivex/internal/subscribers/t;->value:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-wide v1, p0, Lio/reactivex/internal/subscribers/t;->produced:J

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x7

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-long/2addr v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput-wide v1, p0, Lio/reactivex/internal/subscribers/t;->produced:J

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object p1, p0, Lio/reactivex/internal/subscribers/t;->actual:Lja/c;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/t;->s:Lja/d;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a3$a;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a3$a;->done:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a3$a;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/t;->value:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscribers/t;->a(Ljava/lang/Object;)V

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a3$a;->done:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a3$a;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lio/reactivex/internal/subscribers/t;->value:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/t;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method
