.class final Lio/reactivex/internal/operators/flowable/r2$b;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/r2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "Ljava/lang/Object;",
        ">;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x273e43a975384721L


# instance fields
.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final source:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field subscriber:Lio/reactivex/internal/operators/flowable/r2$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/r2$c<",
            "TT;TU;>;"
        }
    .end annotation
.end field

.field final subscription:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->source:Lja/b;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscription:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    move v1, v0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " /s~~ o~ ~@Sy.@ ub@   a-fr~~ l~m~1 ~o~~ ~l~M d@~s@b ~@ @~~~@@fv@@@@@4/  ~~K ito c@~@~onot@ib@@@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscription:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez p1, :cond_2

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscription:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p1, Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/p;->d(Lja/d;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->source:Lja/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscriber:Lio/reactivex/internal/operators/flowable/r2$c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    if-nez p1, :cond_0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscription:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscriber:Lio/reactivex/internal/operators/flowable/r2$c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/r2$c;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscriber:Lio/reactivex/internal/operators/flowable/r2$c;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/r2$c;->actual:Lja/c;

    const/4 v1, 0x7

    or-int/2addr v2, v1

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscriber:Lio/reactivex/internal/operators/flowable/r2$c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/r2$c;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscriber:Lio/reactivex/internal/operators/flowable/r2$c;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/r2$c;->actual:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$b;->subscription:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x0

    invoke-static {v0, v1, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method
