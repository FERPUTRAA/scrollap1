.class public final Lio/reactivex/internal/operators/flowable/d4;
.super Lio/reactivex/f0;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/d4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Lio/reactivex/f0<",
        "TU;>;",
        "Lu7/b<",
        "TU;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lio/reactivex/internal/util/b;->b()Ljava/util/concurrent/Callable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/operators/flowable/d4;-><init>(Lja/b;Ljava/util/concurrent/Callable;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Lja/b;Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d4;->a:Lja/b;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/d4;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TU;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "S@s~1ob@ c.r ~~  ~t@ /~~~@d@@ ~n  i@@@~@f@io l~@ b~~  f- a4~ vl ooysoob@ ~~K@~i ~M@~u~~@~t~@/@@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d4;->b:Ljava/util/concurrent/Callable;

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, "g nmeaeaslre ielunlyctlnurirertl.el oSl ruruc  l Nxsdwtvsdhalnnot . raotdpcaeT rlo ico anunp nla2useeopsocolle o eeli."

    const-string v1, "2 s  geclirlolcaolu o lwee erdtnladslnpvln iextaSoot.u.ascdtrT elounelnsprcart  nnlepa  ure  sruellh eaiey.coilouo rnN"

    const/4 v4, 0x4

    const-string v1, "rSs ocl  t nsr swnouroi  dudn aooc eletogrele nlNetveira erltdsoepuiehye2laollrlcon uprTeu anl apl onl.nc elle.tau.axi"

    const-string v1, "The collectionSupplier returned a null collection. Null values are generally not allowed in 2.x operators and sources."

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d4;->a:Lja/b;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v2, Lio/reactivex/internal/operators/flowable/d4$a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v2, p1, v0}, Lio/reactivex/internal/operators/flowable/d4$a;-><init>(Lio/reactivex/h0;Ljava/util/Collection;)V

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->o(Ljava/lang/Throwable;Lio/reactivex/h0;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TU;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/c4;

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d4;->a:Lja/b;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/d4;->b:Ljava/util/concurrent/Callable;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/c4;-><init>(Lja/b;Ljava/util/concurrent/Callable;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0
.end method
