.class public final Lio/reactivex/internal/operators/flowable/n3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/n3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lio/reactivex/e0;

.field final d:Z


# direct methods
.method public constructor <init>(Lja/b;Lio/reactivex/e0;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lio/reactivex/e0;",
            "Z)V"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n3;->c:Lio/reactivex/e0;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-boolean p3, p0, Lio/reactivex/internal/operators/flowable/n3;->d:Z

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~vssd~@~ c~@@@@i~@ /@@@~ ~lo@o~bSboo fMtm@o~ i ~/@u@ ~4@ yi~~ @a@-~~.o 1 K~~~@@ nb@@rf l~~ t~   "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n3;->c:Lio/reactivex/e0;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/n3$a;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x5

    move v5, v4

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/n3;->d:Z

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v1, p1, v0, v2, v3}, Lio/reactivex/internal/operators/flowable/n3$a;-><init>(Lja/c;Lio/reactivex/e0$c;Lja/b;Z)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lio/reactivex/e0$c;->c(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method
