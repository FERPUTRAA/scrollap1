.class final Lio/reactivex/internal/operators/flowable/m1$o;
.super Ljava/lang/Object;

# interfaces
.implements Lt7/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "o"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lt7/g<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$o;->a:Lja/c;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public accept(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$o;->a:Lja/c;

    const/4 v1, 0x2

    move v2, v1

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    return-void
.end method
