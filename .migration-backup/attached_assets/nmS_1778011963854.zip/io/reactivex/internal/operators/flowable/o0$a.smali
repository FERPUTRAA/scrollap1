.class final Lio/reactivex/internal/operators/flowable/o0$a;
.super Lio/reactivex/internal/subscriptions/f;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/o0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/f<",
        "TT;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x386f7dd17fceb6ddL


# instance fields
.field count:J

.field final defaultValue:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field done:Z

.field final errorOnFewer:Z

.field final index:J

.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;JLjava/lang/Object;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;JTT;Z)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/o0$a;->index:J

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/o0$a;->defaultValue:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p5, p0, Lio/reactivex/internal/operators/flowable/o0$a;->errorOnFewer:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s/ ~ ~o~@-lfv@@.  o@@@yb/ t~~@b ~ so@@i~o@dS o c @~a@Mom~~@K~b~@~r @~@ @u~~~4n@  1~f~i  @~it~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/f;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->s:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->done:Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->count:J

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/o0$a;->index:J

    const/4 v4, 0x1

    const/4 v5, 0x2

    cmp-long v2, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v2, :cond_1

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x0

    or-int/2addr v4, v0

    const/4 v5, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->done:Z

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->s:Lja/d;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x5

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-long/2addr v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->count:J

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->done:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->done:Z

    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->defaultValue:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->errorOnFewer:Z

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    and-int/2addr v3, v2

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x4

    new-instance v1, Ljava/util/NoSuchElementException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v1}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->done:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->done:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o0$a;->s:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o0$a;->s:Lja/d;

    const/4 v2, 0x2

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    return-void
.end method
