.class final Lio/reactivex/internal/operators/flowable/s3$a;
.super Lio/reactivex/internal/subscriptions/f;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/f<",
        "TT;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4be1b28db2b70fbaL


# instance fields
.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~tsb-~@fs~~~.@@o4v~c~d@~o @@@S @rlo@@iu~ @o~o~    @m~ /  @@~ ~b~~~@ ~ob@~@ ~i@~fKM ~1n@@   yi/al"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/f;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s3$a;->s:Lja/d;

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    invoke-interface {v0}, Lja/c;->onComplete()V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v1, 0x5

    const/4 v1, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s3$a;->s:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s3$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method
