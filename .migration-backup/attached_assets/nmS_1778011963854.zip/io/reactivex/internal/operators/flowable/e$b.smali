.class final Lio/reactivex/internal/operators/flowable/e$b;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "Lio/reactivex/w<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field private final b:Ljava/util/concurrent/BlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/BlockingQueue<",
            "Lio/reactivex/w<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final c:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Ljava/util/concurrent/ArrayBlockingQueue;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/ArrayBlockingQueue;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic f(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~  bauo@@y@i~~@@~@ o ~-~M1@o~io  ~ @S4f s~@@@ r@@ v/ b~c~~dt@@ ~ li~~ ~m~l@~o@n/b  @Ko~~~@.ft"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p1, Lio/reactivex/w;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/e$b;->g(Lio/reactivex/w;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public g(Lio/reactivex/w;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/w<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndSet(I)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1}, Lio/reactivex/w;->h()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    :cond_0
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Ljava/util/concurrent/BlockingQueue;->offer(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast v0, Lio/reactivex/w;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/reactivex/w;->h()Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v1, :cond_0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method h()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public i()Lio/reactivex/w;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/w<",
            "TT;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/InterruptedException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/e$b;->h()V

    const/4 v2, 0x7

    invoke-static {}, Lio/reactivex/internal/util/e;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$b;->b:Ljava/util/concurrent/BlockingQueue;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast v0, Lio/reactivex/w;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public onComplete()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
