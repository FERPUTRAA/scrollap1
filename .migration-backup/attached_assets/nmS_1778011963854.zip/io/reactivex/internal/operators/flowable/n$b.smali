.class final Lio/reactivex/internal/operators/flowable/n$b;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;Open:",
        "Ljava/lang/Object;",
        "Close:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TClose;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/n$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/n$a<",
            "TT;TU;TOpen;TClose;>;"
        }
    .end annotation
.end field

.field final c:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TU;"
        }
    .end annotation
.end field

.field d:Z


# direct methods
.method constructor <init>(Ljava/util/Collection;Lio/reactivex/internal/operators/flowable/n$a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;",
            "Lio/reactivex/internal/operators/flowable/n$a<",
            "TT;TU;TOpen;TClose;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n$b;->b:Lio/reactivex/internal/operators/flowable/n$a;

    const/4 v1, 0x2

    const/4 v0, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n$b;->c:Ljava/util/Collection;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TClose;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~@So~~mb@-~~~y@ dv~Mt~@~   i4 u@tf~~o  @@n@ @@b ol.@@/oc~@s/~ ~oo~1 ~@~~ba@ifK@@  ~l ~@ @  i~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/n$b;->onComplete()V

    const/4 v1, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/n$b;->d:Z

    const/4 v2, 0x3

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/n$b;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$b;->b:Lio/reactivex/internal/operators/flowable/n$a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$b;->c:Ljava/util/Collection;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p0}, Lio/reactivex/internal/operators/flowable/n$a;->u(Ljava/util/Collection;Lio/reactivex/disposables/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/n$b;->d:Z

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$b;->b:Lio/reactivex/internal/operators/flowable/n$a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/n$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method
