.class Lio/reactivex/internal/operators/flowable/a4$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/a4$b;->b(J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Lio/reactivex/internal/operators/flowable/a4$b;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/a4$b;J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->a:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  s@~dK/@  ~~Mo@~@oot ~ ~c b@ib@lmo~r~~~@@ u@ ~ @t~l@@oiS ~ /i @sf@ ~~@o~~@~ ~y.@ ~bv1-@n~@~a f@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->a:J

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-wide v2, v2, Lio/reactivex/internal/operators/flowable/a4$b;->i:J

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x1

    shl-int/2addr v5, v1

    const/4 v4, 0x1

    move v5, v4

    iput-boolean v1, v0, Lio/reactivex/internal/operators/flowable/a4$b;->j:Z

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v5, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a4$b;->c()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b$a;->b:Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    :cond_0
    return-void
.end method
