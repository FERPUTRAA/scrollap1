.class final Lio/reactivex/internal/operators/flowable/f3$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/f3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/r<",
            "-TT;>;"
        }
    .end annotation
.end field

.field b:Lja/d;

.field c:Z

.field d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/r;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->a:Lio/reactivex/r;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~sa@s~u~y~~ff@~@~~@~oSio~@~v@./oc@i@~@ b@~tbM~n ~ ~@@l~@1K -/ 4 ~ ~  r@@ ~ mi @ d@~to @lo @  o~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x1

    move v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->c:Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    and-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->d:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->c:Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v3, 0x5

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v3, 0x0

    sget-object p1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->a:Lio/reactivex/r;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "m emeattinehelct ooreq  eemnnscasuo n!Se"

    const-string v1, "ansomhe cen tooeeu meietSqsteann n rcel!"

    const/4 v3, 0x5

    const-string v1, " tnSo thoee en eonocenainesuectlnr mm!qa"

    const-string v1, "Sequence contains more than one element!"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {p1, v0}, Lio/reactivex/r;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->d:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->c:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->c:Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->d:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x6

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->d:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->a:Lio/reactivex/r;

    const/4 v3, 0x5

    invoke-interface {v0}, Lio/reactivex/r;->onComplete()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->a:Lio/reactivex/r;

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v1, v0}, Lio/reactivex/r;->onSuccess(Ljava/lang/Object;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->a:Lio/reactivex/r;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lio/reactivex/r;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f3$a;->b:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3$a;->a:Lio/reactivex/r;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, p0}, Lio/reactivex/r;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
