.class final Lio/reactivex/internal/operators/flowable/s2$k;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "k"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field static final i:[Lio/reactivex/internal/operators/flowable/s2$h;

.field static final j:[Lio/reactivex/internal/operators/flowable/s2$h;


# instance fields
.field final a:Lio/reactivex/internal/operators/flowable/s2$j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;"
        }
    .end annotation
.end field

.field b:Z

.field final c:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "[",
            "Lio/reactivex/internal/operators/flowable/s2$h<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final d:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final e:Ljava/util/concurrent/atomic/AtomicInteger;

.field f:J

.field g:J

.field volatile h:Lja/d;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x6

    new-array v1, v0, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object v1, Lio/reactivex/internal/operators/flowable/s2$k;->i:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-array v0, v0, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    sput-object v0, Lio/reactivex/internal/operators/flowable/s2$k;->j:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method constructor <init>(Lio/reactivex/internal/operators/flowable/s2$j;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lio/reactivex/internal/operators/flowable/s2$k;->i:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x7

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s  ~ ~@bi~@/@@ -o ~~ @l~@o@isKc~@fo@/iu~ d b@@o.v4@t~~@~a~~ f@ @~t n@b   ~l @o@~y ~M1~o ~m@~S@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v1, Lio/reactivex/internal/operators/flowable/s2$k;->j:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v0, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method b(Lio/reactivex/internal/operators/flowable/s2$h;)Z
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/s2$h<",
            "TT;>;)Z"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    check-cast v0, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    sget-object v1, Lio/reactivex/internal/operators/flowable/s2$k;->j:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-ne v0, v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v2

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    array-length v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    add-int/lit8 v3, v1, 0x1

    const/4 v5, 0x4

    new-array v3, v3, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v2, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object p1, v3, v1

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v1, v0, v3}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 p1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return p1
.end method

.method c()V
    .locals 13

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    if-eqz v0, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-void

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v0, 0x1

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/s2$k;->a()Z

    move-result v1

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-eqz v1, :cond_2

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    return-void

    :cond_2
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v12, 0x3

    const/4 v11, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    check-cast v1, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/s2$k;->f:J

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    array-length v4, v1

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    const/4 v5, 0x0

    move-wide v6, v2

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    if-ge v5, v4, :cond_3

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    aget-object v8, v1, v5

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget-object v8, v8, Lio/reactivex/internal/operators/flowable/s2$h;->totalRequested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v8

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-static {v6, v7, v8, v9}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v6

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    add-int/lit8 v5, v5, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    goto :goto_0

    :cond_3
    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/s2$k;->g:J

    const/4 v12, 0x3

    const/4 v11, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->h:Lja/d;

    const/4 v12, 0x0

    const/4 v11, 0x3

    sub-long v2, v6, v2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    cmp-long v10, v2, v8

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-eqz v10, :cond_7

    const/4 v12, 0x5

    iput-wide v6, p0, Lio/reactivex/internal/operators/flowable/s2$k;->f:J

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-eqz v1, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    cmp-long v6, v4, v8

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    if-eqz v6, :cond_4

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    iput-wide v8, p0, Lio/reactivex/internal/operators/flowable/s2$k;->g:J

    const/4 v11, 0x3

    move v12, v11

    add-long/2addr v4, v2

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-interface {v1, v4, v5}, Lja/d;->g(J)V

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    goto :goto_1

    :cond_4
    const/4 v12, 0x5

    invoke-interface {v1, v2, v3}, Lja/d;->g(J)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    goto :goto_1

    :cond_5
    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    add-long/2addr v4, v2

    const/4 v12, 0x6

    cmp-long v1, v4, v8

    const/4 v12, 0x1

    const/4 v11, 0x3

    if-gez v1, :cond_6

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    :cond_6
    const/4 v12, 0x5

    iput-wide v4, p0, Lio/reactivex/internal/operators/flowable/s2$k;->g:J

    const/4 v12, 0x5

    const/4 v11, 0x4

    goto :goto_1

    :cond_7
    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    cmp-long v2, v4, v8

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-eqz v2, :cond_8

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-eqz v1, :cond_8

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    iput-wide v8, p0, Lio/reactivex/internal/operators/flowable/s2$k;->g:J

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-interface {v1, v4, v5}, Lja/d;->g(J)V

    :cond_8
    :goto_1
    const/4 v12, 0x1

    const/4 v11, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    neg-int v0, v0

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-nez v0, :cond_1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    return-void
.end method

.method d(Lio/reactivex/internal/operators/flowable/s2$h;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/s2$h<",
            "TT;>;)V"
        }
    .end annotation

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    check-cast v0, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    array-length v1, v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-void

    :cond_1
    const/4 v6, 0x1

    move v7, v6

    const/4 v2, 0x0

    move v7, v2

    const/4 v6, 0x5

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-ge v3, v1, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    aget-object v4, v0, v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v4, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_1

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto :goto_0

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v3, -0x1

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-gez v3, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-ne v1, v4, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v1, Lio/reactivex/internal/operators/flowable/s2$k;->i:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_2

    :cond_5
    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    add-int/lit8 v5, v1, -0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-array v5, v5, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v7, 0x1

    invoke-static {v0, v2, v5, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    add-int/lit8 v2, v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    sub-int/2addr v1, v3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    sub-int/2addr v1, v4

    const/4 v6, 0x0

    move v7, v6

    invoke-static {v0, v2, v5, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v2, v0, v1}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    xor-int/2addr v7, v6

    return-void
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v1, Lio/reactivex/internal/operators/flowable/s2$k;->j:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->h:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0, p1}, Lio/reactivex/internal/operators/flowable/s2$j;->d(Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast p1, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x5

    const/4 v4, 0x3

    array-length v0, p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ge v1, v0, :cond_0

    const/4 v5, 0x6

    aget-object v2, p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {v3, v2}, Lio/reactivex/internal/operators/flowable/s2$j;->e(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->b:Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->b:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v0}, Lio/reactivex/internal/operators/flowable/s2$j;->a()V

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    sget-object v1, Lio/reactivex/internal/operators/flowable/s2$k;->j:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    check-cast v0, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    array-length v1, v0

    const/4 v5, 0x0

    move v6, v5

    const/4 v2, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ge v2, v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    aget-object v3, v0, v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v4, v3}, Lio/reactivex/internal/operators/flowable/s2$j;->e(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->b:Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0, p1}, Lio/reactivex/internal/operators/flowable/s2$j;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v0, Lio/reactivex/internal/operators/flowable/s2$k;->j:[Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    check-cast p1, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    array-length v0, p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ge v1, v0, :cond_1

    const/4 v5, 0x0

    aget-object v2, p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v3, v2}, Lio/reactivex/internal/operators/flowable/s2$j;->e(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$k;->h:Lja/d;

    const/4 v5, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->h:Lja/d;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/s2$k;->c()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$k;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    check-cast p1, [Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    array-length v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ge v1, v0, :cond_0

    const/4 v5, 0x7

    aget-object v2, p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v3, v2}, Lio/reactivex/internal/operators/flowable/s2$j;->e(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    move v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    return-void
.end method
