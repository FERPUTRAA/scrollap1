.class final Lio/reactivex/internal/operators/flowable/t0$a;
.super Lio/reactivex/internal/subscribers/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/t0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final f:Lt7/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/r<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lu7/a;Lt7/r;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-TT;>;",
            "Lt7/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/a;-><init>(Lu7/a;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/t0$a;->f:Lt7/r;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "c@s  @~~@ b  @/ @ @ ~dn @~~Mfvb~~~@~bi/S1 ~ stK @~@~oyo@ o a4~~l@.~o-o~t  @u~@@mr@@~~@@@i ~~foil"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/t0$a;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/subscribers/a;->b:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x6

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->d(I)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return p1
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/a;->d:Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    move v4, v3

    return v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v0, p0, Lio/reactivex/internal/subscribers/a;->e:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object p1, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {p1, v0}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return p1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x1

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t0$a;->f:Lt7/r;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v2, p1}, Lt7/r;->test(Ljava/lang/Object;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v2, p1}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    move v1, v0

    move v1, v0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v1

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->c(Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v0
.end method

.method public poll()Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->c:Lu7/l;

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t0$a;->f:Lt7/r;

    :cond_0
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object v0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v1, v2}, Lt7/r;->test(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-object v2

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lio/reactivex/internal/subscribers/a;->e:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne v2, v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x6

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v0, v2, v3}, Lja/d;->g(J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0
.end method
