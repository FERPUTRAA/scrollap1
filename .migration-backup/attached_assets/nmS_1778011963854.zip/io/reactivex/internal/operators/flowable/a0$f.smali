.class final Lio/reactivex/internal/operators/flowable/a0$f;
.super Lio/reactivex/internal/operators/flowable/a0$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a0$b<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x37d61f4a35bdda6fL


# instance fields
.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final queue:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "TT;>;"
        }
    .end annotation
.end field

.field final wip:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;-><init>(Lja/c;)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$f;->queue:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$f;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method e()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~/s @~1vl~  ou4m~biMt~l o@@/ @@~ ~a@oy@@@~i@~@@~ @@~ o~ d f @~c~@~oStiK@ ro.b~@~b~  ~s@@  ~nf~- "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$f;->i()V

    const/4 v1, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$f;->done:Z

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    move v2, v1

    if-nez p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x4

    const-string v0, "eisr oteil s tatl  .lls  onNvNuawcd.ll.nhnualgxox elrnrdndelleaauu  as oye anpeorrte w2 ceso"

    const-string v0, "lltmsnc e .tnnvtralulNponwogee Nsdalrua eex2a u clrs  ey.sted haol oa dlnn xol oilrwu.r ilee"

    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$f;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    return-void

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$f;->queue:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$f;->i()V

    :cond_2
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method h()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$f;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$f;->queue:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method i()V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/a0$f;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    iget-object v2, v0, Lio/reactivex/internal/operators/flowable/a0$f;->queue:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :cond_1
    invoke-virtual/range {p0 .. p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v5

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    move-wide v9, v7

    :goto_0
    cmp-long v11, v9, v5

    const/4 v12, 0x0

    const/4 v13, 0x0

    if-eqz v11, :cond_7

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v14

    if-eqz v14, :cond_2

    invoke-virtual {v2, v13}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    return-void

    :cond_2
    iget-boolean v14, v0, Lio/reactivex/internal/operators/flowable/a0$f;->done:Z

    invoke-virtual {v2, v13}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    if-nez v15, :cond_3

    move/from16 v16, v3

    move/from16 v16, v3

    move/from16 v16, v3

    move/from16 v16, v3

    goto :goto_1

    :cond_3
    move/from16 v16, v12

    move/from16 v16, v12

    move/from16 v16, v12

    move/from16 v16, v12

    :goto_1
    if-eqz v14, :cond_5

    if-eqz v16, :cond_5

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/a0$f;->error:Ljava/lang/Throwable;

    if-eqz v1, :cond_4

    invoke-super {v0, v1}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    goto :goto_2

    :cond_4
    invoke-super/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/a0$b;->onComplete()V

    :goto_2
    return-void

    :cond_5
    if-eqz v16, :cond_6

    goto :goto_3

    :cond_6
    invoke-interface {v1, v15}, Lja/c;->f(Ljava/lang/Object;)V

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    const-wide/16 v11, 0x1

    add-long/2addr v9, v11

    goto :goto_0

    :cond_7
    :goto_3
    if-nez v11, :cond_b

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v5

    if-eqz v5, :cond_8

    invoke-virtual {v2, v13}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    return-void

    :cond_8
    iget-boolean v5, v0, Lio/reactivex/internal/operators/flowable/a0$f;->done:Z

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_9

    move v12, v3

    move v12, v3

    move v12, v3

    move v12, v3

    :cond_9
    if-eqz v5, :cond_b

    if-eqz v12, :cond_b

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/a0$f;->error:Ljava/lang/Throwable;

    if-eqz v1, :cond_a

    invoke-super {v0, v1}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    goto :goto_4

    :cond_a
    invoke-super/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/a0$b;->onComplete()V

    :goto_4
    return-void

    :cond_b
    cmp-long v5, v9, v7

    if-eqz v5, :cond_c

    invoke-static {v0, v9, v10}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_c
    iget-object v5, v0, Lio/reactivex/internal/operators/flowable/a0$f;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    neg-int v4, v4

    invoke-virtual {v5, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v4

    if-nez v4, :cond_1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$f;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$f;->i()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$f;->done:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "el maeuoeyerwrlo heola  prdarclullsilt troe w 2Eon ldo rslcdxN.s  a .uotnnlgrninaelu nvsea r."

    const/4 v3, 0x6

    const-string v1, "rn ooedi  llaln rcxus radur.ca tsell nror e.slept  nlENoryo o2dsanavuliee.a lltreln wogaeh ow"

    const-string v1, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a0$f;->onError(Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$f;->error:Ljava/lang/Throwable;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/a0$f;->done:Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$f;->i()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :cond_2
    :goto_0
    const/4 v3, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    return-void
.end method
