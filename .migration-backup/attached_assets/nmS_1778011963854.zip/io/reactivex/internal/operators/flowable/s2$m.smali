.class final Lio/reactivex/internal/operators/flowable/s2$m;
.super Lio/reactivex/internal/operators/flowable/s2$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "m"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/s2$g<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x51dae9f17ccbb88eL


# instance fields
.field final limit:I


# direct methods
.method constructor <init>(I)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/internal/operators/flowable/s2$g;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lio/reactivex/internal/operators/flowable/s2$m;->limit:I

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method n()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ srob  oot~@@i~@ u @y d~~~ ~K~i@ @o~.ob@@Sf~@@i~/ 4 t@f~  ~nM1-c~/v~ol @~@~l~@~ @m @b@@~  a~@~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget v0, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/s2$m;->limit:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-le v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/s2$g;->k()V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
