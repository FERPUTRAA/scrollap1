.class final Lio/reactivex/internal/operators/flowable/j$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/h0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/h0<",
            "-",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final b:Lt7/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/r<",
            "-TT;>;"
        }
    .end annotation
.end field

.field c:Lja/d;

.field d:Z


# direct methods
.method constructor <init>(Lio/reactivex/h0;Lt7/r;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-",
            "Ljava/lang/Boolean;",
            ">;",
            "Lt7/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j$a;->a:Lio/reactivex/h0;

    const/4 v1, 0x2

    const/4 v0, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/j$a;->b:Lt7/r;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "obs~yiMl@@@o/~@sf~~~@@  ~ @@1t @-~~ @K@oi~ul  c@~~@am4~ ~~o~S ~  ~ .oib@/d~@ tr@bnvf o ~~  @~@@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->b:Lt7/r;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lt7/r;->test(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/j$a;->d:Z

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object p1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/j$a;->a:Lio/reactivex/h0;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lio/reactivex/h0;->onSuccess(Ljava/lang/Object;)V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v1, 0x0

    move v2, v1

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/j$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->d:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->a:Lio/reactivex/h0;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Lio/reactivex/h0;->onSuccess(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->d:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->d:Z

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->a:Lio/reactivex/h0;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j$a;->c:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j$a;->a:Lio/reactivex/h0;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v0, p0}, Lio/reactivex/h0;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method
