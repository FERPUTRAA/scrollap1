.class abstract Lio/reactivex/internal/operators/flowable/a;
.super Lio/reactivex/k;

# interfaces
.implements Lu7/h;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TR;>;",
        "Lu7/h<",
        "TT;>;"
    }
.end annotation


# instance fields
.field protected final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    const-string v0, "sosu cnli resu"

    const-string v0, "olsecssru in u"

    const-string/jumbo v0, "uilmcsul  rnso"

    const-string v0, "source is null"

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p1, Lja/b;

    const/4 v2, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public final source()Lja/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lja/b<",
            "TT;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@f@o@os lc@  @ ~b  ~~~ K~u@- .@o~~fa~ @ bool@mn itb@@/ /~ 41~@~y~i@~@~v~~~r Mt d@o@@@@@~oS~i ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method
