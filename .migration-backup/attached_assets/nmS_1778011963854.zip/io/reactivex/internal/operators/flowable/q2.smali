.class public final Lio/reactivex/internal/operators/flowable/q2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/q2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/e;


# direct methods
.method public constructor <init>(Lja/b;Lt7/e;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/e;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/q2;->c:Lt7/e;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ s  .~~ b~@ f b ~@@@@~@t~ @@~ oo@o@lK v@o~ tlb~M~S-oy/1~~~ @u i@as~ ~ ~@/~@idfo~i ~ ~@m@@~4r@nc"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    new-instance v0, Lio/reactivex/internal/subscriptions/o;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v0}, Lio/reactivex/internal/subscriptions/o;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/q2$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/q2;->c:Lt7/e;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v1, p1, v2, v0, v3}, Lio/reactivex/internal/operators/flowable/q2$a;-><init>(Lja/c;Lt7/e;Lio/reactivex/internal/subscriptions/o;Lja/b;)V

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {v1}, Lio/reactivex/internal/operators/flowable/q2$a;->a()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method
