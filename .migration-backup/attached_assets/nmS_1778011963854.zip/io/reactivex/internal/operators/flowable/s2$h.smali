.class final Lio/reactivex/internal/operators/flowable/s2$h;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/d;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lja/d;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field static final a:J = -0x8000000000000000L

.field private static final serialVersionUID:J = -0x3dcf6c3b2e70d8baL


# instance fields
.field final child:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field emitting:Z

.field index:Ljava/lang/Object;

.field missed:Z

.field final parent:Lio/reactivex/internal/operators/flowable/s2$k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/s2$k<",
            "TT;>;"
        }
    .end annotation
.end field

.field final totalRequested:Ljava/util/concurrent/atomic/AtomicLong;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/s2$k;Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/s2$k<",
            "TT;>;",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$h;->parent:Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s2$h;->child:Lja/c;

    const/4 v1, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$h;->totalRequested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "nbs @~@vlM1m.~ta~o~ o~ ~4o@~u~b~~~@@@oict  @@ ir @/@  f~@@/Ko@ @  ~i@ S@-~~~l f~@s@ ~d ~~yb o~~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x1

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v0, 0x6

    const/4 v0, 0x1

    xor-int/2addr v5, v0

    const/4 v4, 0x4

    move v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v0
.end method

.method b()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<U:",
            "Ljava/lang/Object;",
            ">()TU;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$h;->index:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public c(J)J
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->f(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-wide p1
.end method

.method public cancel()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/s2$h;->e()V

    const/4 v1, 0x2

    return-void
.end method

.method public e()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-wide/high16 v0, -0x8000000000000000L

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v5, 0x5

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->getAndSet(J)J

    move-result-wide v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    cmp-long v0, v2, v0

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$h;->parent:Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Lio/reactivex/internal/operators/flowable/s2$k;->d(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$h;->parent:Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/s2$k;->c()V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method

.method public g(J)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v0, :cond_3

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    cmp-long v2, v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    cmp-long v4, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ltz v4, :cond_2

    const/4 v6, 0x6

    cmp-long v2, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-void

    :cond_2
    const/4 v6, 0x2

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->c(JJ)J

    move-result-wide v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0, v0, v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    move v6, v5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$h;->totalRequested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$h;->parent:Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v6, 0x5

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/s2$k;->c()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$h;->parent:Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v6, 0x4

    iget-object p1, p1, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p1, p0}, Lio/reactivex/internal/operators/flowable/s2$j;->e(Lio/reactivex/internal/operators/flowable/s2$h;)V

    :cond_3
    const/4 v5, 0x6

    move v6, v5

    return-void
.end method
