.class final Lio/reactivex/internal/operators/flowable/q$a;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;
.implements Ljava/lang/Runnable;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;TU;TU;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final A0:J

.field final B0:Ljava/util/concurrent/TimeUnit;

.field final C0:I

.field final D0:Z

.field final E0:Lio/reactivex/e0$c;

.field F0:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TU;"
        }
    .end annotation
.end field

.field G0:Lio/reactivex/disposables/c;

.field H0:Lja/d;

.field I0:J

.field J0:J

.field final k0:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;IZLio/reactivex/e0$c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "IZ",
            "Lio/reactivex/e0$c;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/q$a;->k0:Ljava/util/concurrent/Callable;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-wide p3, p0, Lio/reactivex/internal/operators/flowable/q$a;->A0:J

    const/4 v1, 0x2

    move v2, v1

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/q$a;->B0:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    iput p6, p0, Lio/reactivex/internal/operators/flowable/q$a;->C0:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-boolean p7, p0, Lio/reactivex/internal/operators/flowable/q$a;->D0:Z

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p8, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sfdc/@~ @ @n1-lf@~@ ~ot@Kb@ov  ~.~ Sb@ ~ ~u  ~~r~@/mo~  ~@@bo @~~~~@Mo@~@ y~~i@i @at~@@ 4s ~lo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$a;->e()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x0

    monitor-enter p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v2, 0x7

    const/4 v1, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->H0:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    throw v0
.end method

.method public f(Ljava/lang/Object;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v13, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x7

    if-nez v0, :cond_0

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x0

    monitor-exit p0

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x0

    return-void

    :cond_0
    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result p1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x3

    iget v1, p0, Lio/reactivex/internal/operators/flowable/q$a;->C0:I

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x5

    if-ge p1, v1, :cond_1

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x3

    monitor-exit p0

    const/4 v13, 0x5

    const/4 v12, 0x5

    return-void

    :cond_1
    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x6

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    const/4 v13, 0x4

    const/4 v12, 0x6

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->D0:Z

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x6

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v12, 0x3

    shr-int/2addr v13, v12

    if-eqz p1, :cond_2

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x3

    const/4 p1, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x2

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/q$a;->I0:J

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x1

    add-long/2addr v3, v1

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x5

    iput-wide v3, p0, Lio/reactivex/internal/operators/flowable/q$a;->I0:J

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->G0:Lio/reactivex/disposables/c;

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-interface {p1}, Lio/reactivex/disposables/c;->e()V

    :cond_2
    const/4 v13, 0x3

    const/4 p1, 0x0

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-virtual {p0, v0, p1, p0}, Lio/reactivex/internal/subscribers/n;->r(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    :try_start_1
    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->k0:Ljava/util/concurrent/Callable;

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-interface {p1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x6

    const-string v0, "pfnmlfid  sul se lTuierbhse"

    const-string v0, "l s ebdlse ihliuspruTeffnp "

    const/4 v13, 0x4

    const-string v0, "fedpoe r bTiue ulfuslin slh"

    const-string v0, "The supplied buffer is null"

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x4

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x0

    check-cast p1, Ljava/util/Collection;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/4 v12, 0x1

    move v13, v12

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->D0:Z

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x2

    if-eqz v0, :cond_3

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x5

    monitor-enter p0

    :try_start_2
    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x5

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/q$a;->J0:J

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x5

    add-long/2addr v3, v1

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x0

    iput-wide v3, p0, Lio/reactivex/internal/operators/flowable/q$a;->J0:J

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x0

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x3

    iget-wide v9, p0, Lio/reactivex/internal/operators/flowable/q$a;->A0:J

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x7

    iget-object v11, p0, Lio/reactivex/internal/operators/flowable/q$a;->B0:Ljava/util/concurrent/TimeUnit;

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-wide v7, v9

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-virtual/range {v5 .. v11}, Lio/reactivex/e0$c;->f(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->G0:Lio/reactivex/disposables/c;

    const/4 v12, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_3
    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x7

    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    throw p1

    :cond_3
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x0

    monitor-enter p0

    :try_start_4
    const/4 v13, 0x2

    const/4 v12, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x2

    monitor-exit p0

    :goto_0
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    return-void

    :catchall_1
    move-exception p1

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x1

    monitor-exit p0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x4

    throw p1

    :catchall_2
    move-exception p1

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$a;->cancel()V

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x2

    return-void

    :catchall_3
    move-exception p1

    :try_start_5
    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x0

    monitor-exit p0
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x7

    throw p1
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic k(Lja/c;Ljava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    check-cast p2, Ljava/util/Collection;

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/q$a;->t(Lja/c;Ljava/util/Collection;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v4, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v1, v0}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, v1, v2, p0, p0}, Lio/reactivex/internal/util/u;->f(Lu7/o;Lja/c;ZLio/reactivex/disposables/c;Lio/reactivex/internal/util/t;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw v0
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    monitor-enter p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    move v2, v1

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p1
.end method

.method public q(Lja/d;)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->H0:Lja/d;

    const/4 v9, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    if-nez v0, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    return-void

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$a;->H0:Lja/d;

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->k0:Ljava/util/concurrent/Callable;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v1, "fnfldbls  suuiTu bereemhlip"

    const-string v1, "ir m hllsebl nfdsefT upiueu"

    const/4 v9, 0x0

    const-string v1, " iuul udnlbf  eieleTsuhppfr"

    const-string v1, "The supplied buffer is null"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/q$a;->A0:J

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/q$a;->B0:Ljava/util/concurrent/TimeUnit;

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, v5

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual/range {v1 .. v7}, Lio/reactivex/e0$c;->f(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->G0:Lio/reactivex/disposables/c;

    const/4 v9, 0x5

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$a;->E0:Lio/reactivex/e0$c;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-interface {v1}, Lio/reactivex/disposables/c;->e()V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object p1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    return-void
.end method

.method public run()V
    .locals 8

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->k0:Ljava/util/concurrent/Callable;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v1, "sep dfupuspuoil ll rnTei bf"

    const-string v1, "ips osul febllfu pue iTendr"

    const/4 v7, 0x0

    const-string v1, "lhep  iuqlTfuspsefdn  bilre"

    const-string v1, "The supplied buffer is null"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    monitor-enter p0

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/q$a;->I0:J

    const/4 v6, 0x4

    const/4 v6, 0x2

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/q$a;->J0:J

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    cmp-long v2, v2, v4

    const/4 v6, 0x5

    shl-int/2addr v7, v6

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$a;->F0:Ljava/util/Collection;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p0, v1, v0, p0}, Lio/reactivex/internal/subscribers/n;->r(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-void

    :cond_1
    :goto_0
    :try_start_2
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    monitor-exit p0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    throw v0

    :catchall_1
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$a;->cancel()V

    const/4 v7, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v7, 0x0

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    return-void
.end method

.method public t(Lja/c;Ljava/util/Collection;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;TU;)Z"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-interface {p1, p2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v1, 0x5

    const/4 p1, 0x7

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p1
.end method
