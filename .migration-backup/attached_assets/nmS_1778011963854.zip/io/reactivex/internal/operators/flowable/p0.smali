.class public final Lio/reactivex/internal/operators/flowable/p0;
.super Lio/reactivex/p;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/p0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/p<",
        "TT;>;",
        "Lu7/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:J


# direct methods
.method public constructor <init>(Lja/b;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/p;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p0;->a:Lja/b;

    const/4 v1, 0x0

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/p0;->b:J

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public e()Lio/reactivex/k;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@~s .f~/r~~@@m@ou@oot~@b/@ ~S~~~K~~c@il @~~@l~~a @b oi M@@o ~@@y@ @~~ ~4@ d1-  ~tb ov@i~@s ~ nf "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x7

    new-instance v6, Lio/reactivex/internal/operators/flowable/o0;

    const/4 v8, 0x5

    const/4 v7, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p0;->a:Lja/b;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/p0;->b:J

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v5, 0x0

    move-object v0, v6

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/o0;-><init>(Lja/b;JLjava/lang/Object;Z)V

    const/4 v7, 0x0

    and-int/2addr v8, v7

    invoke-static {v6}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-object v0
.end method

.method protected n1(Lio/reactivex/r;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v4, 0x7

    move v5, v4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0;->a:Lja/b;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/p0$a;

    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/p0;->b:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v1, p1, v2, v3}, Lio/reactivex/internal/operators/flowable/p0$a;-><init>(Lio/reactivex/r;J)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method
