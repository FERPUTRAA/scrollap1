.class public final Lio/reactivex/internal/operators/flowable/g3;
.super Lio/reactivex/f0;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/g3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "TT;>;",
        "Lu7/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;TT;)V"
        }
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g3;->a:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/g3;->b:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~isdb    f  m@c~o~@~~@o@@M~b a@~ @~-@l14@~~s ~~b~~.l~@@/ ur~@~ @~K@~o/t@~@o fi@   i ~@oyo~ @Svt@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g3;->a:Lja/b;

    const/4 v4, 0x1

    new-instance v1, Lio/reactivex/internal/operators/flowable/g3$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g3;->b:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/g3$a;-><init>(Lio/reactivex/h0;Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/e3;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/g3;->a:Lja/b;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g3;->b:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/e3;-><init>(Lja/b;Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-object v0
.end method
