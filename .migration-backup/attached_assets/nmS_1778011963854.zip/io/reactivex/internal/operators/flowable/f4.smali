.class public final Lio/reactivex/internal/operators/flowable/f4;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/f4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "D:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+TD;>;"
        }
    .end annotation
.end field

.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TD;+",
            "Lja/b<",
            "+TT;>;>;"
        }
    .end annotation
.end field

.field final d:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TD;>;"
        }
    .end annotation
.end field

.field final e:Z


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;Lt7/o;Lt7/g;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "+TD;>;",
            "Lt7/o<",
            "-TD;+",
            "Lja/b<",
            "+TT;>;>;",
            "Lt7/g<",
            "-TD;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f4;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/f4;->c:Lt7/o;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/f4;->d:Lt7/g;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-boolean p4, p0, Lio/reactivex/internal/operators/flowable/f4;->e:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  s@u@~ s~~ f 4@~~o@Kd@~f.   ~a@~tS o@ i@@M@@ ~v~i~ ~mc~~@@/i~~n@~ ~ l /@o@l @~btb1@@~o b-r~~oyo"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f4;->b:Ljava/util/concurrent/Callable;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/f4;->c:Lt7/o;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v1, v0}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    check-cast v1, Lja/b;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance v2, Lio/reactivex/internal/operators/flowable/f4$a;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/f4;->d:Lt7/g;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/f4;->e:Z

    const/4 v6, 0x4

    invoke-direct {v2, p1, v0, v3, v4}, Lio/reactivex/internal/operators/flowable/f4$a;-><init>(Lja/c;Ljava/lang/Object;Lt7/g;Z)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    :try_start_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/f4;->d:Lt7/g;

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v2, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void

    :catchall_1
    move-exception v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v2, Lio/reactivex/exceptions/a;

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v3, 0x2

    move v6, v3

    new-array v3, v3, [Ljava/lang/Throwable;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x5

    aput-object v1, v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    aput-object v0, v3, v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v2, v3}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v2, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :catchall_2
    move-exception v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v5, 0x5

    move v6, v5

    return-void
.end method
