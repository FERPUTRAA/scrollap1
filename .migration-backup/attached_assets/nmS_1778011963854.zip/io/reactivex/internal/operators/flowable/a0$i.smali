.class final Lio/reactivex/internal/operators/flowable/a0$i;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lio/reactivex/l;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lio/reactivex/l<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x43c4fdd95fbcd5c6L


# instance fields
.field volatile done:Z

.field final emitter:Lio/reactivex/internal/operators/flowable/a0$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/a0$b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final error:Lio/reactivex/internal/util/c;

.field final queue:Lu7/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/n<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/a0$b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/a0$b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    new-instance p1, Lio/reactivex/internal/util/c;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p1}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$i;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/16 v0, 0x10

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {p1, v0}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$i;->queue:Lu7/n;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public b(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@Ss@ .~~1o @~@oc@~ ~ @b@fudi~~@n-l  ~@vboo~a/~~@o @@K~~ ~@m4i  ~sy @ M@@@~~@ @~ /t~ @tbri fl~ ~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;->b(Lio/reactivex/disposables/c;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public c(Lt7/f;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;->c(Lt7/f;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public d()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->d()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-wide v0
.end method

.method e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$i;->g()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->done:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, "dw moowaordttssnNanpelaronNi llacru  nslrtlllxe.c esga aiylexentrhdvo2ua oln. l  ue. le ue s"

    const-string v0, "eas.nevl ese dsw rnl allurlg aolrxanyow i.ud a alnitt olaldeso nc.lh uos   Nclnueerorxp2ttNe"

    const/4 v3, 0x1

    const-string v0, "seieor taalyva so .ruosx nel rceenN.l llea2xcoalgeteanNsuldtl. ed lonwnn  lr ldwohp  t iouur"

    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$i;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v2, 0x3

    move v3, v2

    const/4 v0, 0x0

    shl-int/2addr v3, v0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lio/reactivex/j;->f(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->queue:Lu7/n;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$i;->g()V

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p1

    :cond_4
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method g()V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a0$i;->queue:Lu7/n;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a0$i;->error:Lio/reactivex/internal/util/c;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v3, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    move v4, v3

    move v4, v3

    const/4 v9, 0x0

    move v4, v3

    move v4, v3

    :cond_0
    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v5, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v1}, Lu7/o;->clear()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    return-void

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz v5, :cond_2

    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-interface {v1}, Lu7/o;->clear()V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    return-void

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-boolean v5, p0, Lio/reactivex/internal/operators/flowable/a0$i;->done:Z

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-interface {v1}, Lu7/n;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x0

    if-nez v6, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v7, v3

    move v7, v3

    move v7, v3

    move v7, v3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    goto :goto_1

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v7, 0x0

    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v5, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v7, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->onComplete()V

    const/4 v9, 0x4

    return-void

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz v7, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    neg-int v4, v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-nez v4, :cond_0

    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    return-void

    :cond_5
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-interface {v0, v6}, Lio/reactivex/j;->f(Ljava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto/16 :goto_0
.end method

.method public isCancelled()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->done:Z

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$i;->e()V

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->emitter:Lio/reactivex/internal/operators/flowable/a0$b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->done:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_1

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "e nllbcolaalo.heouupls vao eoulais etr r.ea l aedwnnm yrsrrt.s2 aEnnwlN xr lce uet idgorlldor"

    const-string v0, "r um lpao2ow  ycslieusawtvdaasnn dte n.alllrrrldnhr  c galorll.oEeoe  s.eoeouillnan  rNxeurte"

    const/4 v2, 0x6

    const-string v0, " le ueusnpr s.l2nln swenilaattha  delnogiEccollre aota l n. u  rvwyrroNareasxoorelduro ulle. "

    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$i;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/a0$i;->done:Z

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$i;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void

    :cond_3
    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public serialize()Lio/reactivex/l;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/l<",
            "TT;>;"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method
