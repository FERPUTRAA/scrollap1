.class final Lio/reactivex/internal/operators/flowable/f2$a;
.super Lio/reactivex/internal/subscribers/t;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/f2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/t<",
        "TT;TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x33ea157c2cf0a1deL


# instance fields
.field final valueSupplier:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/t;-><init>(Lja/c;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/f2$a;->valueSupplier:Lt7/o;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " isrM~@@~ilf4oK@~@ bb@@@  ~b~@ /@~o@uo ~ @t@ @@ /~~ooo~d ~  @ntm~~ sS 1-~~~@@c @v  iyl.f~~@~~~a~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-wide v0, p0, Lio/reactivex/internal/subscribers/t;->produced:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-wide v0, p0, Lio/reactivex/internal/subscribers/t;->produced:J

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/t;->actual:Lja/c;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/t;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 7

    :try_start_0
    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f2$a;->valueSupplier:Lt7/o;

    const/4 v6, 0x0

    invoke-interface {v0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v1, "h amrulipru aeveu ueennde TueltvlSra lp"

    const-string v1, "The valueSupplier returned a null value"

    const/4 v6, 0x7

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/t;->a(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, p0, Lio/reactivex/internal/subscribers/t;->actual:Lja/c;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v2, Lio/reactivex/exceptions/a;

    const/4 v6, 0x5

    const/4 v3, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-array v3, v3, [Ljava/lang/Throwable;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    move v6, v5

    aput-object p1, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 p1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    aput-object v0, v3, p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v2, v3}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v1, v2}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void
.end method
