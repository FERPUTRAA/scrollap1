.class final Lio/reactivex/internal/operators/flowable/a4$b;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:J

.field final c:Ljava/util/concurrent/TimeUnit;

.field final d:Lio/reactivex/e0$c;

.field final e:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field f:Lja/d;

.field final g:Lio/reactivex/internal/subscriptions/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/subscriptions/h<",
            "TT;>;"
        }
    .end annotation
.end field

.field final h:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field volatile i:J

.field volatile j:Z


# direct methods
.method constructor <init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;Lja/b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0$c;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->a:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/a4$b;->b:J

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/a4$b;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/a4$b;->e:Lja/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance p2, Lio/reactivex/internal/subscriptions/h;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 p3, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p2, p1, p0, p3}, Lio/reactivex/internal/subscriptions/h;-><init>(Lja/c;Lio/reactivex/disposables/c;I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " lsooa@/mfb~/S fv b@@@~y~@ @ ~i t~~o@~~~-~oo @.   ~  iu@@in@4  ~~~~o~@ t~d@@@r~Ks~c@~1@ @b~M@~@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method b(J)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v2, Lio/reactivex/internal/operators/flowable/a4;->g:Lio/reactivex/disposables/c;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1, v0, v2}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/a4$b$a;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v1, p0, p1, p2}, Lio/reactivex/internal/operators/flowable/a4$b$a;-><init>(Lio/reactivex/internal/operators/flowable/a4$b;J)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-wide p1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->b:J

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$b;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1, p1, p2, v2}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p2, p1}, Lio/reactivex/internal/disposables/d;->d(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method c()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->e:Lja/b;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Lio/reactivex/internal/subscribers/i;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Lio/reactivex/internal/subscribers/i;-><init>(Lio/reactivex/internal/subscriptions/h;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->j:Z

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->i:J

    const/4 v4, 0x2

    const/4 v4, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-long/2addr v0, v2

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->i:J

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v5, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, p1, v3}, Lio/reactivex/internal/subscriptions/h;->e(Ljava/lang/Object;Lja/d;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/operators/flowable/a4$b;->b(J)V

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->j:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->j:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lio/reactivex/internal/subscriptions/h;->c(Lja/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->j:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->j:Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->d:Lio/reactivex/e0$c;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1, v1}, Lio/reactivex/internal/subscriptions/h;->d(Ljava/lang/Throwable;Lja/d;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->f:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/h;->f(Lja/d;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$b;->a:Lja/c;

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$b;->g:Lio/reactivex/internal/subscriptions/h;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/operators/flowable/a4$b;->b(J)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method
