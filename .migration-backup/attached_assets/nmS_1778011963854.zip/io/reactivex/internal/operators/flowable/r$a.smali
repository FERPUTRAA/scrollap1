.class final Lio/reactivex/internal/operators/flowable/r$a;
.super Lio/reactivex/internal/util/m;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/util/m;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field static final k:[Lio/reactivex/internal/operators/flowable/r$b;

.field static final l:[Lio/reactivex/internal/operators/flowable/r$b;


# instance fields
.field final f:Lio/reactivex/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/k<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final g:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field

.field final h:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "[",
            "Lio/reactivex/internal/operators/flowable/r$b<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field volatile i:Z

.field j:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-array v1, v0, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v1, Lio/reactivex/internal/operators/flowable/r$a;->k:[Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-array v0, v0, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    sput-object v0, Lio/reactivex/internal/operators/flowable/r$a;->l:[Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method constructor <init>(Lio/reactivex/k;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/k<",
            "+TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p2}, Lio/reactivex/internal/util/m;-><init>(I)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    new-instance p2, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    invoke-direct {p2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/r$a;->g:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r$a;->f:Lio/reactivex/k;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    sget-object p2, Lio/reactivex/internal/operators/flowable/r$a;->k:[Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public e(Lio/reactivex/internal/operators/flowable/r$b;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/r$b<",
            "TT;>;)V"
        }
    .end annotation

    :cond_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "cls ~~~  fi.r @ y~m~~t~@~@o/ @4~oi @@ lniod~ ~f@@bKb@u ~o@1~b@@@sMSo  ~~@ ~  @~a @@t@/o-~@ ~v~~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    check-cast v0, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v5, 0x5

    sget-object v1, Lio/reactivex/internal/operators/flowable/r$a;->l:[Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v4, 0x1

    move v5, v4

    if-ne v0, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-array v2, v2, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object p1, v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1, v0, v2}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->j:Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Lio/reactivex/internal/util/p;->s(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/util/m;->a(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast p1, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    array-length v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ge v1, v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    aget-object v2, p1, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {v2}, Lio/reactivex/internal/operators/flowable/r$b;->a()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method public g()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->f:Lio/reactivex/k;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Lio/reactivex/k;->j(Lja/c;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->i:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public h(Lio/reactivex/internal/operators/flowable/r$b;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/r$b<",
            "TT;>;)V"
        }
    .end annotation

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    check-cast v0, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    array-length v1, v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-nez v1, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ge v3, v1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    aget-object v4, v0, v3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v4, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v4, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_0

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v3, -0x1

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-gez v3, :cond_4

    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-void

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-ne v1, v4, :cond_5

    const/4 v7, 0x4

    return-void

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    add-int/lit8 v5, v1, -0x1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-array v5, v5, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v0, v2, v5, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x3

    add-int/lit8 v2, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    sub-int/2addr v1, v3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    sub-int/2addr v1, v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v2, v5, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v1, v0, v5}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->j:Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->j:Z

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {}, Lio/reactivex/internal/util/p;->e()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Lio/reactivex/internal/util/m;->a(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->g:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Lio/reactivex/internal/operators/flowable/r$a;->l:[Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v0, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ge v2, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    aget-object v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v3}, Lio/reactivex/internal/operators/flowable/r$b;->a()V

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->j:Z

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x7

    move v3, v0

    move v3, v0

    const/4 v4, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->j:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1}, Lio/reactivex/internal/util/p;->g(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/util/m;->a(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r$a;->g:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object v0, Lio/reactivex/internal/operators/flowable/r$a;->l:[Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast p1, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length v0, p1

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    shl-int/2addr v3, v1

    :goto_0
    const/4 v4, 0x3

    if-ge v1, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    aget-object v2, p1, v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2}, Lio/reactivex/internal/operators/flowable/r$b;->a()V

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r$a;->g:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
