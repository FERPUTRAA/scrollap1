.class Lio/reactivex/internal/operators/flowable/a4$c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/a4$c;->b(J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Lio/reactivex/internal/operators/flowable/a4$c;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/a4$c;J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->b:Lio/reactivex/internal/operators/flowable/a4$c;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->a:J

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@s ~@~t/rK~l y@@M~~b~@ ~bvsm/@ ~o@-@o  i f.@~@ d~S@~ ~~lo@ b~@@   ~oa@o~ ~@4u~n1i@~~oft @@~ci~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->b:Lio/reactivex/internal/operators/flowable/a4$c;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-wide v2, v2, Lio/reactivex/internal/operators/flowable/a4$c;->g:J

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v4, 0x0

    move v5, v4

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->b:Lio/reactivex/internal/operators/flowable/a4$c;

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-boolean v1, v0, Lio/reactivex/internal/operators/flowable/a4$c;->h:Z

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->b:Lio/reactivex/internal/operators/flowable/a4$c;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/a4$c;->e()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4$c$a;->b:Lio/reactivex/internal/operators/flowable/a4$c;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/a4$c;->a:Lja/c;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v1, Ljava/util/concurrent/TimeoutException;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/util/concurrent/TimeoutException;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method
