.class final Lio/reactivex/internal/operators/flowable/m1$c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/m1;->f(Lio/reactivex/k;IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)Ljava/util/concurrent/Callable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lio/reactivex/flowables/a<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/k;

.field final synthetic b:I

.field final synthetic c:J

.field final synthetic d:Ljava/util/concurrent/TimeUnit;

.field final synthetic e:Lio/reactivex/e0;


# direct methods
.method constructor <init>(Lio/reactivex/k;IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$c;->a:Lio/reactivex/k;

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m1$c;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-wide p3, p0, Lio/reactivex/internal/operators/flowable/m1$c;->c:J

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/m1$c;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x2

    const/4 v0, 0x1

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/m1$c;->e:Lio/reactivex/e0;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Lio/reactivex/flowables/a;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$c;->a:Lio/reactivex/k;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m1$c;->b:I

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/m1$c;->c:J

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/m1$c;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/m1$c;->e:Lio/reactivex/e0;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual/range {v0 .. v5}, Lio/reactivex/k;->F4(IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)Lio/reactivex/flowables/a;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m1$c;->a()Lio/reactivex/flowables/a;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method
