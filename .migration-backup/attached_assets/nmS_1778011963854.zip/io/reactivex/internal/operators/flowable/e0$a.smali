.class final Lio/reactivex/internal/operators/flowable/e0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/e0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:J

.field final c:Ljava/util/concurrent/TimeUnit;

.field final d:Lio/reactivex/e0$c;

.field final e:Z

.field f:Lja/d;


# direct methods
.method constructor <init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0$c;",
            "Z)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e0$a;->a:Lja/c;

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/e0$a;->b:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/e0$a;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v0, 0x0

    move v1, v0

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-boolean p6, p0, Lio/reactivex/internal/operators/flowable/e0$a;->e:Z

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@fs@- @.4~o i~/@br~@~Ky o@@ f~~ a @@~l @iti~@n@~  o~ @@s  @~@~/v u@m~~S@d~~ o~~ c~ooM~t1b@  l~b~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->f:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/e0$a$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/flowable/e0$a$a;-><init>(Lio/reactivex/internal/operators/flowable/e0$a;Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/e0$a;->b:J

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e0$a;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2, v3, p1}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->f:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v6, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/e0$a$c;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-direct {v1, p0}, Lio/reactivex/internal/operators/flowable/e0$a$c;-><init>(Lio/reactivex/internal/operators/flowable/e0$a;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/e0$a;->b:J

    const/4 v5, 0x4

    move v6, v5

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/e0$a;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v0, v1, v2, v3, v4}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v5, 0x3

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/e0$a$b;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/flowable/e0$a$b;-><init>(Lio/reactivex/internal/operators/flowable/e0$a;Ljava/lang/Throwable;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/e0$a;->e:Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/e0$a;->b:J

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e0$a;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2, v3, p1}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a;->f:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e0$a;->f:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e0$a;->a:Lja/c;

    const/4 v2, 0x2

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method
