.class final Lio/reactivex/internal/operators/flowable/k3$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lu7/a;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/k3$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lu7/a<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x5707023ca3cf971dL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final error:Lio/reactivex/internal/util/c;

.field volatile gate:Z

.field final other:Lio/reactivex/internal/operators/flowable/k3$a$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/k3$a<",
            "TT;>.a;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final s:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->actual:Lja/c;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v0, 0x5

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    new-instance p1, Lio/reactivex/internal/operators/flowable/k3$a$a;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p1, p0}, Lio/reactivex/internal/operators/flowable/k3$a$a;-><init>(Lio/reactivex/internal/operators/flowable/k3$a;)V

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->other:Lio/reactivex/internal/operators/flowable/k3$a$a;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    new-instance p1, Lio/reactivex/internal/util/c;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p1}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@sl~ @ @@@ ~b@t  @/~@@~ u @f@~i~Ms@~c-@ @t fyi1r ~Ko~v/ ~4 @obao~~~~oml@o~ @~n~i~~d@S ~@ ~. ~ o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->other:Lio/reactivex/internal/operators/flowable/k3$a$a;

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/k3$a;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p1, Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-wide/16 v0, 0x1

    const/4 v3, 0x6

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x6

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    const/4 v2, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x6

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->gate:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, p1, p0, v1}, Lio/reactivex/internal/util/k;->f(Lja/c;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p1
.end method

.method public onComplete()V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->other:Lio/reactivex/internal/operators/flowable/k3$a$a;

    const/4 v3, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0, p0, v1}, Lio/reactivex/internal/util/k;->b(Lja/c;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->other:Lio/reactivex/internal/operators/flowable/k3$a$a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->actual:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x6

    invoke-static {v0, p1, p0, v1}, Lio/reactivex/internal/util/k;->d(Lja/c;Ljava/lang/Throwable;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-static {v0, v1, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
