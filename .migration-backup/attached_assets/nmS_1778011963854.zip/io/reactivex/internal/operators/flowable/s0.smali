.class public final Lio/reactivex/internal/operators/flowable/s0;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s0;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " os~@@@ @lv@mo~c yK~@ /.f @@i~u ~si@ b~~4 ~~n~/@~~Sa@@or ~ ~~ M~~b@b@io~tt@~@  ~1@@l-f@o@~do    "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s0;->b:Ljava/util/concurrent/Callable;

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string/jumbo v1, "ur myewNl.gle raonllCrdtbn.stolat te e rvol deleu axlus nsaalip oea2nbla e u.esusdrhlraae  l rcoenrwl"

    const-string v1, " aslrvuealn r l .tdnyo. glaelwul e woenalnrc telhlledlruessasaNCe  ab ex e.oaelo rrlr2 rotuinsbadutnp"

    const/4 v3, 0x2

    const-string/jumbo v1, "uenloese erwo  .oelrealslcerbt tls  urluteanaaelvulainn2s g y..awnC oanaxord ep ddorloNlr tabrlll h e"

    const-string v1, "Callable returned null throwable. Null values are generally not allowed in 2.x operators and sources."

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/Throwable;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method
