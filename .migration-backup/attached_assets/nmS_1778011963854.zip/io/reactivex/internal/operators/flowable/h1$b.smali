.class final Lio/reactivex/internal/operators/flowable/h1$b;
.super Lio/reactivex/flowables/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/flowables/b<",
        "TK;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lio/reactivex/internal/operators/flowable/h1$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/h1$c<",
            "TT;TK;>;"
        }
    .end annotation
.end field


# direct methods
.method protected constructor <init>(Ljava/lang/Object;Lio/reactivex/internal/operators/flowable/h1$c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;",
            "Lio/reactivex/internal/operators/flowable/h1$c<",
            "TT;TK;>;)V"
        }
    .end annotation

    invoke-direct {p0, p1}, Lio/reactivex/flowables/b;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h1$b;->c:Lio/reactivex/internal/operators/flowable/h1$c;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static Z7(Ljava/lang/Object;ILio/reactivex/internal/operators/flowable/h1$a;Z)Lio/reactivex/internal/operators/flowable/h1$b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "K:",
            "Ljava/lang/Object;",
            ">(TK;I",
            "Lio/reactivex/internal/operators/flowable/h1$a<",
            "*TK;TT;>;Z)",
            "Lio/reactivex/internal/operators/flowable/h1$b<",
            "TK;TT;>;"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~is ~@-~/i@l~@a@~@nu@4 @@~ @ y@mt~~@oo~~cM~@bs S @o@b  v~~@  o/ i~~ ~fob~d.~f ~ o ~l@@@~1K@r @~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/h1$c;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0, p1, p2, p0, p3}, Lio/reactivex/internal/operators/flowable/h1$c;-><init>(ILio/reactivex/internal/operators/flowable/h1$a;Ljava/lang/Object;Z)V

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p1, Lio/reactivex/internal/operators/flowable/h1$b;

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p1, p0, v0}, Lio/reactivex/internal/operators/flowable/h1$b;-><init>(Ljava/lang/Object;Lio/reactivex/internal/operators/flowable/h1$c;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$b;->c:Lio/reactivex/internal/operators/flowable/h1$c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/h1$c;->j(Lja/c;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$b;->c:Lio/reactivex/internal/operators/flowable/h1$c;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/h1$c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$b;->c:Lio/reactivex/internal/operators/flowable/h1$c;

    const/4 v1, 0x1

    or-int/2addr v2, v1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/h1$c;->onComplete()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$b;->c:Lio/reactivex/internal/operators/flowable/h1$c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/h1$c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method
