.class abstract Lio/reactivex/internal/operators/flowable/i2$a;
.super Lio/reactivex/internal/subscriptions/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/internal/subscriptions/d<",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x1f442a7d211232e5L


# instance fields
.field volatile cancelled:Z

.field final end:I

.field index:I


# direct methods
.method constructor <init>(II)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/d;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p2, p0, Lio/reactivex/internal/operators/flowable/i2$a;->end:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method abstract a()V
.end method

.method public final b()Ljava/lang/Integer;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~sv /~@1@ y@ti K~ o~bo~ f oid/uo@@@~@@~ml  ~on b- ~4@~@@c~~~a@t~i@f@@~s@Mlo ~ @b~@ S@~  ~~.r@  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->end:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v2, 0x1

    or-int/2addr v3, v2

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x2

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/lit8 v1, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput v1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0
.end method

.method abstract c(J)V
.end method

.method public final cancel()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->cancelled:Z

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public final clear()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->end:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v2, 0x4

    return-void
.end method

.method public final g(J)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    cmp-long v0, p1, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i2$a;->a()V

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/i2$a;->c(J)V

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method public final isEmpty()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->end:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v2, 0x0

    move v3, v2

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v0
.end method

.method public final l(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    and-int/lit8 p1, p1, 0x1

    const/4 v0, 0x7

    move v1, v0

    return p1
.end method

.method public bridge synthetic poll()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i2$a;->b()Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object v0
.end method
