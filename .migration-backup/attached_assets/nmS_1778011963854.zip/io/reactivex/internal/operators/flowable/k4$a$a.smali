.class final Lio/reactivex/internal/operators/flowable/k4$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k4$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field final a:J

.field final b:Lio/reactivex/internal/operators/flowable/k4$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/k4$a<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(JLio/reactivex/internal/operators/flowable/k4$a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lio/reactivex/internal/operators/flowable/k4$a<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/k4$a$a;->a:J

    const/4 v0, 0x6

    move v1, v0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/k4$a$a;->b:Lio/reactivex/internal/operators/flowable/k4$a;

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s@@ ~t @1@~ @ ob~i@y@~~ fr@~o @@@  v-~ u@@~4~@~tm~S@o@~ ~~/~i~@b /~cKaM bl.o~io~~~n~l   fd@os@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$a$a;->b:Lio/reactivex/internal/operators/flowable/k4$a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Lio/reactivex/internal/operators/flowable/k4$a;->t(Lio/reactivex/internal/operators/flowable/k4$a;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/internal/operators/flowable/k4$a;->u(Lio/reactivex/internal/operators/flowable/k4$a;)Lu7/n;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v1, p0}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x4

    iput-boolean v1, v0, Lio/reactivex/internal/operators/flowable/k4$a;->K0:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/k4$a;->e()V

    :goto_0
    const/4 v3, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/k4$a;->v()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method
