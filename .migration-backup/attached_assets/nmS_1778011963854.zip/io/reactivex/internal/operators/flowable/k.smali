.class public final Lio/reactivex/internal/operators/flowable/k;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/flowables/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/flowables/a<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:I

.field final d:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field final e:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method public constructor <init>(Lio/reactivex/flowables/a;ILt7/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/flowables/a<",
            "+TT;>;I",
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k;->b:Lio/reactivex/flowables/a;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p2, p0, Lio/reactivex/internal/operators/flowable/k;->c:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/k;->d:Lt7/g;

    const/4 v1, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "m~s ~b~@o o@i~-s~@1@l@@~b So @4icto  ~~@b@o~  l~f~ iu~@n t~~d  @o~ @/~~~ @fK~y~r@a@/.M@ ~@@@ v@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k;->b:Lio/reactivex/flowables/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/k;->j(Lja/c;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/k;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lio/reactivex/internal/operators/flowable/k;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-ne p1, v0, :cond_0

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/k;->b:Lio/reactivex/flowables/a;

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k;->d:Lt7/g;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Lio/reactivex/flowables/a;->c8(Lt7/g;)V

    :cond_0
    const/4 v2, 0x5

    return-void
.end method
