.class public final Lio/reactivex/internal/operators/flowable/g;
.super Lio/reactivex/f0;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/g$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "Ljava/lang/Boolean;",
        ">;",
        "Lu7/b<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Lt7/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/r<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lt7/r;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g;->a:Lja/b;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/g;->b:Lt7/r;

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "-.scSi@~/~bo~~ o@b~Ko/@~~  @ ~ob@ @@ ~@  @~@~@@ M~f@~u ~~4y~f@@vn~~@o@s~~@  i  l 1~a@tdti r~ml@o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g;->a:Lja/b;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v1, Lio/reactivex/internal/operators/flowable/g$a;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g;->b:Lt7/r;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/g$a;-><init>(Lio/reactivex/h0;Lt7/r;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/f;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/g;->a:Lja/b;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g;->b:Lt7/r;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/f;-><init>(Lja/b;Lt7/r;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object v0
.end method
