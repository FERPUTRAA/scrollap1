.class public final Lio/reactivex/internal/operators/flowable/e4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/e4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lio/reactivex/e0;


# direct methods
.method public constructor <init>(Lja/b;Lio/reactivex/e0;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lio/reactivex/e0;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v0, 0x3

    move v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/e4;->c:Lio/reactivex/e0;

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ sl@o1f@/4@bo~@ ~v@ i@@ro~ @ t~  o~ to@u~f@~~-~cn@~ bM@~~ ~@dy S~@ o.~ ~@  ~~~@@l@~K~iba  @i@/m"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/e4$a;

    const/4 v3, 0x3

    move v4, v3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/e4;->c:Lio/reactivex/e0;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/e4$a;-><init>(Lja/c;Lio/reactivex/e0;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method
