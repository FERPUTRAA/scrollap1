.class final Lio/reactivex/internal/operators/flowable/m$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "C::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TC;>;"
        }
    .end annotation
.end field

.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TC;>;"
        }
    .end annotation
.end field

.field final c:I

.field d:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TC;"
        }
    .end annotation
.end field

.field e:Lja/d;

.field f:Z

.field g:I


# direct methods
.method constructor <init>(Lja/c;ILjava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TC;>;I",
            "Ljava/util/concurrent/Callable<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->a:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m$a;->c:I

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/m$a;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ls/ /K@   yvf~@f ~lu @c@@o oM~~b~~@~@@~ @ ~ @@bo i-. ~~sS@~~ar~~i ~@mbtd @ @@i@@@~o4t~~o@ o~ ~n"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->e:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->f:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->d:Ljava/util/Collection;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v0, :cond_1

    :try_start_0
    const/4 v2, 0x5

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->b:Ljava/util/concurrent/Callable;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v1, "eprmbenupeSl e lurrf dnraT uueefifrh ltbs"

    const-string/jumbo v1, "ueslfneeffrlrSTeerpdrpir fbubt l euh  nau"

    const/4 v3, 0x5

    const-string v1, "rfenouu du nr lbblrfu Tferpe fieerlhuapeS"

    const-string v1, "The bufferSupplier returned a null buffer"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->d:Ljava/util/Collection;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m$a;->cancel()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m$a;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->g:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m$a;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne p1, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->g:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->d:Ljava/util/Collection;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->a:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->g:I

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public g(J)V
    .locals 5

    const/4 v4, 0x7

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->e:Lja/d;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m$a;->c:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    int-to-long v1, v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, p2, v1, v2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->f:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->f:Z

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->d:Ljava/util/Collection;

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m$a;->a:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-interface {v1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->a:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x5

    move v3, v2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->f:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    move v2, v1

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->f:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->a:Lja/c;

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$a;->e:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->e:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m$a;->a:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method
