.class public final Lio/reactivex/internal/operators/flowable/m4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/m4$c;,
        Lio/reactivex/internal/operators/flowable/m4$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TR;>;"
    }
.end annotation


# instance fields
.field final c:[Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lja/b<",
            "*>;"
        }
    .end annotation
.end field

.field final d:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lja/b<",
            "*>;>;"
        }
    .end annotation
.end field

.field final e:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "TR;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/lang/Iterable;Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Ljava/lang/Iterable<",
            "+",
            "Lja/b<",
            "*>;>;",
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "TR;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4;->c:[Lja/b;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m4;->d:Ljava/lang/Iterable;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/m4;->e:Lt7/o;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Lja/b;[Lja/b;Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;[",
            "Lja/b<",
            "*>;",
            "Lt7/o<",
            "-[",
            "Ljava/lang/Object;",
            "TR;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m4;->c:[Lja/b;

    const/4 v0, 0x7

    move v1, v0

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4;->d:Ljava/lang/Iterable;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/m4;->e:Lt7/o;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "4os.K @t@~~@    ~~~~oo @ @t@o@lu@~Mi~  i~y ~1 r~l-~m @nS @f@ib~o~f/b/s~  b~@@v~@ ~~@ @~@@a~@~od@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4;->c:[Lja/b;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/16 v0, 0x8

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-array v0, v0, [Lja/b;

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m4;->d:Ljava/lang/Iterable;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    check-cast v3, Lja/b;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    array-length v4, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ne v2, v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    shr-int/lit8 v4, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    add-int/2addr v4, v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0, v4}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v0, [Lja/b;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/lit8 v4, v2, 0x1

    const/4 v6, 0x0

    aput-object v3, v0, v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v2, v4

    move v2, v4

    const/4 v6, 0x0

    move v2, v4

    move v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    array-length v2, v0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez v2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v0, Lio/reactivex/internal/operators/flowable/u1;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v2, Lio/reactivex/internal/operators/flowable/m4$a;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v2, p0}, Lio/reactivex/internal/operators/flowable/m4$a;-><init>(Lio/reactivex/internal/operators/flowable/m4;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/u1;-><init>(Lja/b;Lt7/o;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/u1;->H5(Lja/c;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-void

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance v1, Lio/reactivex/internal/operators/flowable/m4$b;

    const/4 v5, 0x4

    move v6, v5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/m4;->e:Lt7/o;

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v1, p1, v3, v2}, Lio/reactivex/internal/operators/flowable/m4$b;-><init>(Lja/c;Lt7/o;I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, v0, v2}, Lio/reactivex/internal/operators/flowable/m4$b;->e([Lja/b;I)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {p1, v1}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    return-void
.end method
