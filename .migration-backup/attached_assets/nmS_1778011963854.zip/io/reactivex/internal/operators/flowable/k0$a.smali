.class final Lio/reactivex/internal/operators/flowable/k0$a;
.super Lio/reactivex/internal/subscribers/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final f:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lu7/a;Lt7/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-TT;>;",
            "Lt7/g<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/a;-><init>(Lu7/a;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/k0$a;->f:Lt7/g;

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@r~f @@  oMy ~o ~@@~.u/@fl-@@oibba~ s ~~~ ~1 l~K~@~d~m  ~ @@@@ o~vo@toc/@~~it4@@ ~S~i~ @@nb~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lio/reactivex/internal/subscribers/a;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_0

    :try_start_0
    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k0$a;->f:Lt7/g;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->c(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->d(I)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p1
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->a:Lu7/a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k0$a;->f:Lt7/g;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v1, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/a;->c(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method public poll()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/a;->c:Lu7/l;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k0$a;->f:Lt7/g;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-interface {v1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method
