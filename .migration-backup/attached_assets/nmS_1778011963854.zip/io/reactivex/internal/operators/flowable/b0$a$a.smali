.class final Lio/reactivex/internal/operators/flowable/b0$a$a;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/b0$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TU;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/b0$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/b0$a<",
            "TT;TU;>;"
        }
    .end annotation
.end field

.field final c:J

.field final d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field e:Z

.field final f:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/b0$a;JLjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/b0$a<",
            "TT;TU;>;JTT;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->b:Lio/reactivex/internal/operators/flowable/b0$a;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->c:J

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->d:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ scu@~~~@~   ~@a@ ~  y b@~o/~@rl ~o@n Kf@ ~tio~s@@MSto~b@o-~fl@@@~~@1bi/~ ~ d~ @@ ~moi~. @@v4 @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->e:Z

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->e:Z

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-virtual {p0}, Lio/reactivex/subscribers/b;->b()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b0$a$a;->g()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method g()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    const/4 v2, 0x1

    shl-int/2addr v5, v2

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->b:Lio/reactivex/internal/operators/flowable/b0$a;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->c:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->d:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2, v3}, Lio/reactivex/internal/operators/flowable/b0$a;->a(JLjava/lang/Object;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->e:Z

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b0$a$a;->g()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b0$a$a;->b:Lio/reactivex/internal/operators/flowable/b0$a;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/b0$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method
