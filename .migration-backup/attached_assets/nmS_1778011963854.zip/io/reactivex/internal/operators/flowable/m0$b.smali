.class final Lio/reactivex/internal/operators/flowable/m0$b;
.super Lio/reactivex/internal/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/b<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final f:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final g:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field final h:Lt7/a;

.field final i:Lt7/a;


# direct methods
.method constructor <init>(Lja/c;Lt7/g;Lt7/g;Lt7/a;Lt7/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/g<",
            "-TT;>;",
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;",
            "Lt7/a;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/b;-><init>(Lja/c;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m0$b;->f:Lt7/g;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/m0$b;->g:Lt7/g;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/m0$b;->h:Lt7/a;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/m0$b;->i:Lt7/a;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "-4s@li@~i~~@@ ~~bvt@~~~@o Sc ~~@Mo~/~  @~1  ~ds@f@b@ a ~@/tu~oo~i@~~K or@@ @ml  fo .n@@~ @~ @~yb"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void

    :cond_1
    :try_start_0
    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$b;->f:Lt7/g;

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->c(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->d(I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$b;->h:Lt7/a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    :try_start_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m0$b;->i:Lt7/a;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    :catchall_1
    move-exception v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscribers/b;->c(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 8

    const/4 v6, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    return-void

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v0, 0x1

    const/4 v7, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->g:Lt7/g;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-interface {v1, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v2, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v3, Lio/reactivex/exceptions/a;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v4, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-array v4, v4, [Ljava/lang/Throwable;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    aput-object p1, v4, v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    aput-object v1, v4, v0

    const/4 v7, 0x1

    invoke-direct {v3, v4}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    invoke-interface {v2, v3}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    move v0, v5

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_1
    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->i:Lt7/a;

    const/4 v7, 0x2

    invoke-interface {p1}, Lt7/a;->run()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-void
.end method

.method public poll()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->c:Lu7/l;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->f:Lt7/g;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->i:Lt7/a;

    invoke-interface {v1}, Lt7/a;->run()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->i:Lt7/a;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-interface {v1}, Lt7/a;->run()V

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    throw v0

    :cond_0
    const/4 v3, 0x3

    move v4, v3

    iget v1, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ne v1, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->h:Lt7/a;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-interface {v1}, Lt7/a;->run()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m0$b;->i:Lt7/a;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v1}, Lt7/a;->run()V

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0
.end method
