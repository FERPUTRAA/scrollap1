.class public final Lio/reactivex/internal/operators/flowable/c3;
.super Lio/reactivex/f0;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/c3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "Ljava/lang/Boolean;",
        ">;",
        "Lu7/b<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-TT;-TT;>;"
        }
    .end annotation
.end field

.field final d:I


# direct methods
.method public constructor <init>(Lja/b;Lja/b;Lt7/d;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;",
            "Lja/b<",
            "+TT;>;",
            "Lt7/d<",
            "-TT;-TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c3;->a:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/c3;->b:Lja/b;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/c3;->c:Lt7/d;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p4, p0, Lio/reactivex/internal/operators/flowable/c3;->d:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public K0(Lio/reactivex/h0;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "los@@@@v@ ~oyc~~~ @/n@  @b@f~r1@ /.tu @ K@a  ~@S~~@ ~iom~~@ ifb ~~@io ~~ b@M s l@~@o~~ ~t~@o4d-~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/c3$a;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/c3;->d:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/c3;->c:Lt7/d;

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-direct {v0, p1, v1, v2}, Lio/reactivex/internal/operators/flowable/c3$a;-><init>(Lio/reactivex/h0;ILt7/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Lio/reactivex/h0;->d(Lio/reactivex/disposables/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c3;->a:Lja/b;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/c3;->b:Lja/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1}, Lio/reactivex/internal/operators/flowable/c3$a;->f(Lja/b;Lja/b;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/b3;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/c3;->a:Lja/b;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/c3;->b:Lja/b;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/c3;->c:Lt7/d;

    const/4 v5, 0x6

    iget v4, p0, Lio/reactivex/internal/operators/flowable/c3;->d:I

    const/4 v5, 0x2

    and-int/2addr v6, v5

    invoke-direct {v0, v1, v2, v3, v4}, Lio/reactivex/internal/operators/flowable/b3;-><init>(Lja/b;Lja/b;Lt7/d;I)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-object v0
.end method
