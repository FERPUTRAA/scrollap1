.class final Lio/reactivex/internal/operators/flowable/p1$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/d;
.implements Lio/reactivex/internal/operators/flowable/i1$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/p1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T",
        "Left:Ljava/lang/Object;",
        "TRight:",
        "Ljava/lang/Object;",
        "T",
        "LeftEnd:Ljava/lang/Object;",
        "TRightEnd:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/d;",
        "Lio/reactivex/internal/operators/flowable/i1$b;"
    }
.end annotation


# static fields
.field static final a:Ljava/lang/Integer;

.field static final b:Ljava/lang/Integer;

.field static final c:Ljava/lang/Integer;

.field static final d:Ljava/lang/Integer;

.field private static final serialVersionUID:J = -0x54414b546f40e739L


# instance fields
.field final active:Ljava/util/concurrent/atomic/AtomicInteger;

.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TR;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final disposables:Lio/reactivex/disposables/b;

.field final error:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field final leftEnd:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT",
            "Left;",
            "+",
            "Lja/b<",
            "TT",
            "LeftEnd;",
            ">;>;"
        }
    .end annotation
.end field

.field leftIndex:I

.field final lefts:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "TT",
            "Left;",
            ">;"
        }
    .end annotation
.end field

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final resultSelector:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT",
            "Left;",
            "-TTRight;+TR;>;"
        }
    .end annotation
.end field

.field final rightEnd:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TTRight;+",
            "Lja/b<",
            "TTRightEnd;>;>;"
        }
    .end annotation
.end field

.field rightIndex:I

.field final rights:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "TTRight;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->a:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->b:Ljava/lang/Integer;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->c:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    sput-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->d:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method constructor <init>(Lja/c;Lt7/o;Lt7/o;Lt7/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lt7/o<",
            "-TT",
            "Left;",
            "+",
            "Lja/b<",
            "TT",
            "LeftEnd;",
            ">;>;",
            "Lt7/o<",
            "-TTRight;+",
            "Lja/b<",
            "TTRightEnd;>;>;",
            "Lt7/c<",
            "-TT",
            "Left;",
            "-TTRight;+TR;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->actual:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance p1, Lio/reactivex/disposables/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p1}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x2

    invoke-static {}, Lio/reactivex/k;->V()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    new-instance p1, Ljava/util/LinkedHashMap;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->lefts:Ljava/util/Map;

    const/4 v2, 0x3

    new-instance p1, Ljava/util/LinkedHashMap;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->rights:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/p1$a;->leftEnd:Lt7/o;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/p1$a;->rightEnd:Lt7/o;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/p1$a;->resultSelector:Lt7/c;

    const/4 v2, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p2, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/as~ Mildf@@o~ ~@@is~o ~ ~1l  f~r  v by ~S~@-4o~@@tbo ~ i@~~~@@~@bnt~ ~.~~ @@/@ c~@@o o ~m@@u@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public b(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->h()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public c(ZLjava/lang/Object;)V
    .locals 3

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object p1, Lio/reactivex/internal/operators/flowable/p1$a;->a:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object p1, Lio/reactivex/internal/operators/flowable/p1$a;->b:Ljava/lang/Integer;

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->h()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    throw p1
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->cancelled:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->cancelled:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public d(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->h()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public e(ZLio/reactivex/internal/operators/flowable/i1$c;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-enter p0

    :try_start_0
    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object p1, Lio/reactivex/internal/operators/flowable/p1$a;->c:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object p1, Lio/reactivex/internal/operators/flowable/p1$a;->d:Ljava/lang/Integer;

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->h()V

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p1
.end method

.method public f(Lio/reactivex/internal/operators/flowable/i1$d;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->d(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->h()V

    const/4 v2, 0x1

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x4

    move v2, v1

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method h()V
    .locals 17

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    invoke-virtual/range {p0 .. p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    if-eqz v0, :cond_0

    return-void

    :cond_0
    iget-object v2, v1, Lio/reactivex/internal/operators/flowable/p1$a;->queue:Lio/reactivex/internal/queue/c;

    iget-object v3, v1, Lio/reactivex/internal/operators/flowable/p1$a;->actual:Lja/c;

    const/4 v0, 0x1

    move v4, v0

    move v4, v0

    move v4, v0

    :cond_1
    :goto_0
    iget-boolean v5, v1, Lio/reactivex/internal/operators/flowable/p1$a;->cancelled:Z

    if-eqz v5, :cond_2

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->clear()V

    return-void

    :cond_2
    iget-object v5, v1, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Throwable;

    if-eqz v5, :cond_3

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->clear()V

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    invoke-virtual {v1, v3}, Lio/reactivex/internal/operators/flowable/p1$a;->i(Lja/c;)V

    return-void

    :cond_3
    iget-object v5, v1, Lio/reactivex/internal/operators/flowable/p1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v5

    const/4 v6, 0x0

    if-nez v5, :cond_4

    move v5, v0

    move v5, v0

    move v5, v0

    goto :goto_1

    :cond_4
    move v5, v6

    move v5, v6

    move v5, v6

    move v5, v6

    :goto_1
    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Integer;

    if-nez v7, :cond_5

    move v8, v0

    move v8, v0

    move v8, v0

    move v8, v0

    goto :goto_2

    :cond_5
    move v8, v6

    move v8, v6

    move v8, v6

    move v8, v6

    :goto_2
    if-eqz v5, :cond_6

    if-eqz v8, :cond_6

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->lefts:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rights:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    invoke-interface {v3}, Lja/c;->onComplete()V

    return-void

    :cond_6
    if-eqz v8, :cond_7

    neg-int v4, v4

    invoke-virtual {v1, v4}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v4

    if-nez v4, :cond_1

    return-void

    :cond_7
    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v5

    sget-object v8, Lio/reactivex/internal/operators/flowable/p1$a;->a:Ljava/lang/Integer;

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const-string v11, "eudmstoue  uf tssttculdlkl Ce  oeae iamqvro "

    const-string v11, " lscd u rudtoqotkaet ssClooi vfe eam eeu utl"

    const-string v11, "cdumoeeoarulet C vk eistalfnt qtd ouuool es "

    const-string v11, "Could not emit value due to lack of requests"

    const-string v12, "auTrabhee  t elnrettnluee cerm lurSulsov"

    const-string v12, "luemelaecrSTlttura loer u veu tsnh neelr"

    const-string v12, "ser Tou rar e nterlhutllueuelStnceduvla "

    const-string v12, "The resultSelector returned a null value"

    if-ne v7, v8, :cond_b

    iget v6, v1, Lio/reactivex/internal/operators/flowable/p1$a;->leftIndex:I

    add-int/lit8 v7, v6, 0x1

    iput v7, v1, Lio/reactivex/internal/operators/flowable/p1$a;->leftIndex:I

    iget-object v7, v1, Lio/reactivex/internal/operators/flowable/p1$a;->lefts:Ljava/util/Map;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v7, v8, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_0
    iget-object v7, v1, Lio/reactivex/internal/operators/flowable/p1$a;->leftEnd:Lt7/o;

    invoke-interface {v7, v5}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const-string v8, "ilt alnped rlnefeulEbe P uTrds hrheto"

    const-string v8, "hshrou   elPtfleudebEurldn lTneiart e"

    const-string v8, "rl  fPblqe shrdre EtutnnlTl udneeehau"

    const-string v8, "The leftEnd returned a null Publisher"

    invoke-static {v7, v8}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    new-instance v8, Lio/reactivex/internal/operators/flowable/i1$c;

    invoke-direct {v8, v1, v0, v6}, Lio/reactivex/internal/operators/flowable/i1$c;-><init>(Lio/reactivex/internal/operators/flowable/i1$b;ZI)V

    iget-object v6, v1, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    invoke-virtual {v6, v8}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    invoke-interface {v7, v8}, Lja/b;->j(Lja/c;)V

    iget-object v6, v1, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Throwable;

    if-eqz v6, :cond_8

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->clear()V

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    invoke-virtual {v1, v3}, Lio/reactivex/internal/operators/flowable/p1$a;->i(Lja/c;)V

    return-void

    :cond_8
    iget-object v6, v1, Lio/reactivex/internal/operators/flowable/p1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v6

    iget-object v8, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rights:Ljava/util/Map;

    invoke-interface {v8}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v8

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    :goto_3
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_a

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    :try_start_1
    iget-object v15, v1, Lio/reactivex/internal/operators/flowable/p1$a;->resultSelector:Lt7/c;

    invoke-interface {v15, v5, v0}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, v12}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    cmp-long v15, v13, v6

    if-eqz v15, :cond_9

    invoke-interface {v3, v0}, Lja/c;->f(Ljava/lang/Object;)V

    add-long/2addr v13, v9

    const/4 v0, 0x1

    goto :goto_3

    :cond_9
    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v4, Lio/reactivex/exceptions/c;

    invoke-direct {v4, v11}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    invoke-static {v0, v4}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->clear()V

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    invoke-virtual {v1, v3}, Lio/reactivex/internal/operators/flowable/p1$a;->i(Lja/c;)V

    return-void

    :catchall_0
    move-exception v0

    invoke-virtual {v1, v0, v3, v2}, Lio/reactivex/internal/operators/flowable/p1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    return-void

    :cond_a
    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    cmp-long v0, v13, v5

    if-eqz v0, :cond_11

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-static {v0, v13, v14}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    goto/16 :goto_5

    :catchall_1
    move-exception v0

    invoke-virtual {v1, v0, v3, v2}, Lio/reactivex/internal/operators/flowable/p1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    return-void

    :cond_b
    sget-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->b:Ljava/lang/Integer;

    if-ne v7, v0, :cond_f

    iget v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rightIndex:I

    add-int/lit8 v7, v0, 0x1

    iput v7, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rightIndex:I

    iget-object v7, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rights:Ljava/util/Map;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-interface {v7, v8, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_2
    iget-object v7, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rightEnd:Lt7/o;

    invoke-interface {v7, v5}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const-string v8, "dtsrlbr Eerunhb g n uuheriTtlhiP aseed"

    const-string v8, "iuretbslherlr ruhP tnhenunEidabeg T  d"

    const-string v8, "etsm nia  dliEP lbteuheuguTnrrrrdeh hl"

    const-string v8, "The rightEnd returned a null Publisher"

    invoke-static {v7, v8}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lja/b;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    new-instance v8, Lio/reactivex/internal/operators/flowable/i1$c;

    invoke-direct {v8, v1, v6, v0}, Lio/reactivex/internal/operators/flowable/i1$c;-><init>(Lio/reactivex/internal/operators/flowable/i1$b;ZI)V

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    invoke-virtual {v0, v8}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    invoke-interface {v7, v8}, Lja/b;->j(Lja/c;)V

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Throwable;

    if-eqz v0, :cond_c

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->clear()V

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    invoke-virtual {v1, v3}, Lio/reactivex/internal/operators/flowable/p1$a;->i(Lja/c;)V

    return-void

    :cond_c
    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v6

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->lefts:Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-wide/16 v13, 0x0

    const-wide/16 v13, 0x0

    :goto_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_e

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    :try_start_3
    iget-object v15, v1, Lio/reactivex/internal/operators/flowable/p1$a;->resultSelector:Lt7/c;

    invoke-interface {v15, v8, v5}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    invoke-static {v8, v12}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    cmp-long v15, v13, v6

    if-eqz v15, :cond_d

    invoke-interface {v3, v8}, Lja/c;->f(Ljava/lang/Object;)V

    add-long/2addr v13, v9

    goto :goto_4

    :cond_d
    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v4, Lio/reactivex/exceptions/c;

    invoke-direct {v4, v11}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    invoke-static {v0, v4}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->clear()V

    invoke-virtual/range {p0 .. p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    invoke-virtual {v1, v3}, Lio/reactivex/internal/operators/flowable/p1$a;->i(Lja/c;)V

    return-void

    :catchall_2
    move-exception v0

    invoke-virtual {v1, v0, v3, v2}, Lio/reactivex/internal/operators/flowable/p1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    return-void

    :cond_e
    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    cmp-long v0, v13, v5

    if-eqz v0, :cond_11

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-static {v0, v13, v14}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    goto :goto_5

    :catchall_3
    move-exception v0

    invoke-virtual {v1, v0, v3, v2}, Lio/reactivex/internal/operators/flowable/p1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    return-void

    :cond_f
    sget-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->c:Ljava/lang/Integer;

    if-ne v7, v0, :cond_10

    check-cast v5, Lio/reactivex/internal/operators/flowable/i1$c;

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->lefts:Ljava/util/Map;

    iget v6, v5, Lio/reactivex/internal/operators/flowable/i1$c;->index:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v0, v6}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    invoke-virtual {v0, v5}, Lio/reactivex/disposables/b;->b(Lio/reactivex/disposables/c;)Z

    goto :goto_5

    :cond_10
    sget-object v0, Lio/reactivex/internal/operators/flowable/p1$a;->d:Ljava/lang/Integer;

    if-ne v7, v0, :cond_11

    check-cast v5, Lio/reactivex/internal/operators/flowable/i1$c;

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->rights:Ljava/util/Map;

    iget v6, v5, Lio/reactivex/internal/operators/flowable/i1$c;->index:I

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-interface {v0, v6}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, v1, Lio/reactivex/internal/operators/flowable/p1$a;->disposables:Lio/reactivex/disposables/b;

    invoke-virtual {v0, v5}, Lio/reactivex/disposables/b;->b(Lio/reactivex/disposables/c;)Z

    :cond_11
    :goto_5
    const/4 v0, 0x1

    goto/16 :goto_0
.end method

.method i(Lja/c;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "*>;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/internal/util/j;->c(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->lefts:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p1$a;->rights:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            "Lja/c<",
            "*>;",
            "Lu7/o<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {p3}, Lu7/o;->clear()V

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p1$a;->a()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Lio/reactivex/internal/operators/flowable/p1$a;->i(Lja/c;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method
