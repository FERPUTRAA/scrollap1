.class public final Lio/reactivex/internal/operators/flowable/b3;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/b3$c;,
        Lio/reactivex/internal/operators/flowable/b3$a;,
        Lio/reactivex/internal/operators/flowable/b3$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "Ljava/lang/Boolean;",
        ">;"
    }
.end annotation


# instance fields
.field final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final d:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-TT;-TT;>;"
        }
    .end annotation
.end field

.field final e:I


# direct methods
.method public constructor <init>(Lja/b;Lja/b;Lt7/d;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;",
            "Lja/b<",
            "+TT;>;",
            "Lt7/d<",
            "-TT;-TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b3;->b:Lja/b;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/b3;->c:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/b3;->d:Lt7/d;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p4, p0, Lio/reactivex/internal/operators/flowable/b3;->e:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "1@s ~ ~/~ ~oa@b@d~ ~nf@~o@i~@~~.~o@r@y@oS  @~@@~@  @lt/~K~c@ b ~i mbou  ~i@@ ~ lt~vM4~  @~-@f@so"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance v0, Lio/reactivex/internal/operators/flowable/b3$a;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/b3;->e:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/b3;->d:Lt7/d;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, p1, v1, v2}, Lio/reactivex/internal/operators/flowable/b3$a;-><init>(Lja/c;ILt7/d;)V

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/b3;->b:Lja/b;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3;->c:Lja/b;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, p1, v1}, Lio/reactivex/internal/operators/flowable/b3$a;->s(Lja/b;Lja/b;)V

    const/4 v3, 0x6

    move v4, v3

    return-void
.end method
