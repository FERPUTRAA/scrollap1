.class public final Lio/reactivex/internal/operators/flowable/l0;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/l0$a;,
        Lio/reactivex/internal/operators/flowable/l0$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation

.annotation build Ls7/e;
.end annotation


# instance fields
.field final c:Lt7/a;


# direct methods
.method public constructor <init>(Lja/b;Lt7/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l0;->c:Lt7/a;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@osf @dtoi@o n r i~ @@ ~@oi ~~@@~@~s~b~  ~/  ~u~o@/v@@y~l@t 4~~fb~. ~~ M@ K@a~1@~c-m@~@o@~b ~ lS"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    instance-of v0, p1, Lu7/a;

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/l0$a;

    const/4 v4, 0x7

    const/4 v3, 0x6

    check-cast p1, Lu7/a;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/l0;->c:Lt7/a;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/l0$a;-><init>(Lu7/a;Lt7/a;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/l0$b;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/l0;->c:Lt7/a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/l0$b;-><init>(Lja/c;Lt7/a;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method
