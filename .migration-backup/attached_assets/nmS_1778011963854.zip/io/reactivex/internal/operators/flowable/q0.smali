.class public final Lio/reactivex/internal/operators/flowable/q0;
.super Lio/reactivex/f0;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/q0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "TT;>;",
        "Lu7/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:J

.field final c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;JLjava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;JTT;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q0;->a:Lja/b;

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/q0;->b:J

    const/4 v1, 0x6

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/q0;->c:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ls@io@@o~Kl ~d~ ~ ~o   4@~1Mb  ~~  @ c.@ab~b /@@~~ @@in~~t@-So@f~s ~~/y~f~u @@@o~vr@i~tm@~o  @~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q0;->a:Lja/b;

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/q0$a;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/q0;->b:J

    const/4 v6, 0x1

    const/4 v5, 0x2

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/q0;->c:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v1, p1, v2, v3, v4}, Lio/reactivex/internal/operators/flowable/q0$a;-><init>(Lio/reactivex/h0;JLjava/lang/Object;)V

    const/4 v6, 0x0

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation

    const/4 v8, 0x7

    new-instance v6, Lio/reactivex/internal/operators/flowable/o0;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q0;->a:Lja/b;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/q0;->b:J

    const/4 v7, 0x2

    const/4 v7, 0x5

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/q0;->c:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v5, 0x1

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/o0;-><init>(Lja/b;JLjava/lang/Object;Z)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v6}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-object v0
.end method
