.class public final Lio/reactivex/internal/operators/flowable/s1;
.super Lio/reactivex/f0;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/s1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;TT;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s1;->a:Lja/b;

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s1;->b:Ljava/lang/Object;

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "ocs~ io~no~ f-~ i.o @@~/~~~d~~@@~ob@ bb@ u  ~@v@ty S ~i@~  ~1m@sM@llot@@@~@/ @4~@@~ ~~f @ r~ ~Ka"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s1;->a:Lja/b;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance v1, Lio/reactivex/internal/operators/flowable/s1$a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/s1;->b:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/s1$a;-><init>(Lio/reactivex/h0;Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x3

    return-void
.end method
