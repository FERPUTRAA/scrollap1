.class final Lio/reactivex/internal/operators/flowable/m4$c;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "Ljava/lang/Object;",
        ">;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x2d3210de62c61a18L


# instance fields
.field hasValue:Z

.field final index:I

.field final parent:Lio/reactivex/internal/operators/flowable/m4$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/m4$b<",
            "**>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/m4$b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/m4$b<",
            "**>;I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m4$c;->parent:Lio/reactivex/internal/operators/flowable/m4$b;

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m4$c;->index:I

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sot1~@@~@o@bl~~i@.@ b@~@o@l@um~~so~ ~~f~@@~ ~o ~/ f t -c~@4~~@~/  @ @rb @ ia~o  nS y KvM@i@d@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, Lja/d;

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->d(Lja/d;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$c;->hasValue:Z

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m4$c;->hasValue:Z

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$c;->parent:Lio/reactivex/internal/operators/flowable/m4$b;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m4$c;->index:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Lio/reactivex/internal/operators/flowable/m4$b;->d(ILjava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$c;->parent:Lio/reactivex/internal/operators/flowable/m4$b;

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m4$c;->index:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/m4$c;->hasValue:Z

    invoke-virtual {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/m4$b;->b(IZ)V

    const/4 v4, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m4$c;->parent:Lio/reactivex/internal/operators/flowable/m4$b;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m4$c;->index:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Lio/reactivex/internal/operators/flowable/m4$b;->c(ILjava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method
