.class final Lio/reactivex/internal/operators/flowable/c0$b;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/c0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x7e5310a1f6e139dcL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field done:Z

.field volatile index:J

.field s:Lja/d;

.field final timeout:J

.field final timer:Lio/reactivex/internal/disposables/k;

.field final unit:Ljava/util/concurrent/TimeUnit;

.field final worker:Lio/reactivex/e0$c;


# direct methods
.method constructor <init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0$c;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$b;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timeout:J

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/c0$b;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/c0$b;->worker:Lio/reactivex/e0$c;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method a(JLjava/lang/Object;Lio/reactivex/internal/operators/flowable/c0$a;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JTT;",
            "Lio/reactivex/internal/operators/flowable/c0$a<",
            "TT;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sb@  @@y   l~@  @~@@ ~o~  @@~Sos.d@o-~@fM ri~uK~oc ~~~ @@~/n ~tb1oi@f v/@m ~a~o4@~lb~@it@ ~~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->index:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    cmp-long p1, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    cmp-long p1, p1, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$b;->actual:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1, p3}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const-wide/16 p1, 0x1

    const-wide/16 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p4}, Lio/reactivex/internal/operators/flowable/c0$a;->e()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/c0$b;->cancel()V

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$b;->actual:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p2, Lio/reactivex/exceptions/c;

    const/4 v3, 0x6

    const-string/jumbo p3, "tv mrd soeoiescsdluroanuee  Ct keod luvtlu  qle"

    const-string p3, "e sCln qudoeveatu oe oscrd eeldkulti tv orlsau "

    const/4 v3, 0x3

    const-string p3, "Could not deliver value due to lack of requests"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p2, p3}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p1, p2}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->worker:Lio/reactivex/e0$c;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->s:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->done:Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->index:J

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    add-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->index:J

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v2, Lio/reactivex/disposables/c;

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v2}, Lio/reactivex/disposables/c;->e()V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Lio/reactivex/internal/operators/flowable/c0$a;

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    invoke-direct {v2, p1, v0, v1, p0}, Lio/reactivex/internal/operators/flowable/c0$a;-><init>(Ljava/lang/Object;JLio/reactivex/internal/operators/flowable/c0$b;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1, v2}, Lio/reactivex/internal/disposables/k;->b(Lio/reactivex/disposables/c;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$b;->worker:Lio/reactivex/e0$c;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timeout:J

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/c0$b;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, v2, v0, v1, v3}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Lio/reactivex/internal/operators/flowable/c0$a;->c(Lio/reactivex/disposables/c;)V

    :cond_2
    const/4 v5, 0x7

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->done:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->c(Lio/reactivex/disposables/c;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    if-nez v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Lio/reactivex/internal/operators/flowable/c0$a;

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/c0$a;->b()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->worker:Lio/reactivex/e0$c;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->actual:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    :cond_2
    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->done:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->done:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->timer:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->actual:Lja/c;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->s:Lja/d;

    const/4 v2, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$b;->s:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$b;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method
