.class final Lio/reactivex/internal/operators/flowable/a1$b;
.super Lio/reactivex/internal/operators/flowable/a1$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a1$c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x23e7f25903d0c345L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;[Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;[TT;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p2}, Lio/reactivex/internal/operators/flowable/a1$c;-><init>([Ljava/lang/Object;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a1$b;->actual:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method a()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~ls~@~@~@~@b@ ~i  db4~~ ~o  @~@st ~@@f@. r- @S@cu@bin @ ~oovm~@y~@l@K   @~io@@/a~~of1/M~~~o  ~t "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    array-length v1, v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a1$b;->actual:Lja/c;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget v3, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    :goto_0
    const/4 v6, 0x5

    if-eq v3, v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-void

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    aget-object v4, v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v4, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v1, "aeamn u e sslyltirrnm"

    const-string v1, "i ssnury  lnereltamla"

    const/4 v6, 0x1

    const-string v1, "s eyoa lnatlimeerunl "

    const-string v1, "array element is null"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v2, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-void

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v2, v4}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v2}, Lja/c;->onComplete()V

    const/4 v6, 0x7

    return-void
.end method

.method b(J)V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v11, 0x7

    array-length v1, v0

    const/4 v11, 0x2

    iget v2, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a1$b;->actual:Lja/c;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    :cond_0
    move-wide v6, v4

    :cond_1
    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    cmp-long v8, v6, p1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-eqz v8, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eq v2, v1, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-boolean v8, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v8, :cond_2

    const/4 v11, 0x3

    return-void

    :cond_2
    const/4 v10, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    aget-object v8, v0, v2

    const/4 v11, 0x4

    if-nez v8, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v11, 0x5

    const-string p2, "a irubmet e mlelnasrn"

    const-string p2, "elam esln temnay irur"

    const/4 v11, 0x5

    const-string p2, "rr nnmuluiyee l steal"

    const-string p2, "array element is null"

    const/4 v10, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-interface {v3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    return-void

    :cond_3
    const/4 v11, 0x6

    invoke-interface {v3, v8}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    add-long/2addr v6, v8

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    goto :goto_0

    :cond_4
    const/4 v11, 0x0

    const/4 v10, 0x2

    if-ne v2, v1, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-nez p1, :cond_5

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-interface {v3}, Lja/c;->onComplete()V

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    return-void

    :cond_6
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    cmp-long v8, v6, p1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-nez v8, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    iput v2, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    neg-long p1, v6

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    cmp-long v6, p1, v4

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-nez v6, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    return-void
.end method
