.class public final Lio/reactivex/internal/operators/flowable/r3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/r3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:I


# direct methods
.method public constructor <init>(Lja/b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x0

    iput p2, p0, Lio/reactivex/internal/operators/flowable/r3;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s@o fl @~M~@vK~so@  o@4iu@@~@~~/~b~ n~@~  o./ob1@i@m@~- @~y~~ r@~ti@~ft~ d  ~~c  @ o~~@@ S@b~a"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v1, Lio/reactivex/internal/operators/flowable/r3$a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v2, p0, Lio/reactivex/internal/operators/flowable/r3;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/r3$a;-><init>(Lja/c;I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method
