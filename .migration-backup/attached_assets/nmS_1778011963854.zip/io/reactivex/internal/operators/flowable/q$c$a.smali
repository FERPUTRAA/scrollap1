.class Lio/reactivex/internal/operators/flowable/q$c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/q$c;->q(Lja/d;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/Collection;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/q$c;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/q$c;Ljava/util/Collection;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->b:Lio/reactivex/internal/operators/flowable/q$c;

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->a:Ljava/util/Collection;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ns~t/  @omySfi@~au  d~@r~ ~@s~~ @K~@b@c~- ~i@~@@@t@o~o ~M~~ @.@@lo~@  o~o4@ ~f@~@ vb 1i/ b~@l~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->b:Lio/reactivex/internal/operators/flowable/q$c;

    const/4 v5, 0x5

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->b:Lio/reactivex/internal/operators/flowable/q$c;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->a:Ljava/util/Collection;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v1, v2}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->b:Lio/reactivex/internal/operators/flowable/q$c;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c$a;->a:Ljava/util/Collection;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v3, v0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1, v2, v3}, Lio/reactivex/internal/operators/flowable/q$c;->u(Lio/reactivex/internal/operators/flowable/q$c;Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    throw v1
.end method
