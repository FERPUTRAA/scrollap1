.class public final Lio/reactivex/internal/operators/flowable/o1;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/o1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/k<",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/e0;

.field final c:J

.field final d:J

.field final e:J

.field final f:J

.field final g:Ljava/util/concurrent/TimeUnit;


# direct methods
.method public constructor <init>(JJJJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-wide p5, p0, Lio/reactivex/internal/operators/flowable/o1;->e:J

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-wide p7, p0, Lio/reactivex/internal/operators/flowable/o1;->f:J

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p9, p0, Lio/reactivex/internal/operators/flowable/o1;->g:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x1

    iput-object p10, p0, Lio/reactivex/internal/operators/flowable/o1;->b:Lio/reactivex/e0;

    const/4 v1, 0x0

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/o1;->c:J

    const/4 v1, 0x2

    iput-wide p3, p0, Lio/reactivex/internal/operators/flowable/o1;->d:J

    const/4 v1, 0x3

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@~sao@si~~@~M@u   - m~o@@@@@f~   r@oi~@@o@ ~~~b~1t/@  ~~S @l@l ~v~ n~.fK@/ b~~o y~~ibdct~ 4@o @~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    new-instance v7, Lio/reactivex/internal/operators/flowable/o1$a;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/o1;->c:J

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/o1;->d:J

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/o1$a;-><init>(Lja/c;JJ)V

    const/4 v9, 0x4

    invoke-interface {p1, v7}, Lja/c;->q(Lja/d;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1;->b:Lio/reactivex/e0;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/o1;->e:J

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/o1;->f:J

    const/4 v9, 0x7

    const/4 v8, 0x2

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/o1;->g:Ljava/util/concurrent/TimeUnit;

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual/range {v0 .. v6}, Lio/reactivex/e0;->h(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v7, p1}, Lio/reactivex/internal/operators/flowable/o1$a;->a(Lio/reactivex/disposables/c;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    return-void
.end method
