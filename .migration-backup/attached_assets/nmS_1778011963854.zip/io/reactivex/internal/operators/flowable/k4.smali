.class public final Lio/reactivex/internal/operators/flowable/k4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/k4$c;,
        Lio/reactivex/internal/operators/flowable/k4$a;,
        Lio/reactivex/internal/operators/flowable/k4$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;",
        "Lio/reactivex/k<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:J

.field final e:Ljava/util/concurrent/TimeUnit;

.field final f:Lio/reactivex/e0;

.field final g:J

.field final h:I

.field final i:Z


# direct methods
.method public constructor <init>(Lja/b;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;JIZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "JIZ)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/k4;->c:J

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/k4;->d:J

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/k4;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p7, p0, Lio/reactivex/internal/operators/flowable/k4;->f:Lio/reactivex/e0;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-wide p8, p0, Lio/reactivex/internal/operators/flowable/k4;->g:J

    const/4 v0, 0x0

    move v1, v0

    iput p10, p0, Lio/reactivex/internal/operators/flowable/k4;->h:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-boolean p11, p0, Lio/reactivex/internal/operators/flowable/k4;->i:Z

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;)V"
        }
    .end annotation

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v11, " bs~  tbv~@~ys~~@~~@@@~@-~  foK1 . /S ~ @u~~m~M fi /ni@~~ @ao@  @~~@@d~r@o~lo~@4 i@c~@ ~loo@t@ @"

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v1, Lio/reactivex/subscribers/e;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-direct {v1, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/k4;->c:J

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/k4;->d:J

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    cmp-long p1, v2, v4

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x1

    if-nez p1, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    iget-wide v7, p0, Lio/reactivex/internal/operators/flowable/k4;->g:J

    const/4 v12, 0x3

    const-wide v4, 0x7fffffffffffffffL

    const/4 v12, 0x1

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    cmp-long p1, v7, v4

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-nez p1, :cond_0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    new-instance v7, Lio/reactivex/internal/operators/flowable/k4$b;

    const/4 v11, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/k4;->c:J

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/k4;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/k4;->f:Lio/reactivex/e0;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget v6, p0, Lio/reactivex/internal/operators/flowable/k4;->h:I

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct/range {v0 .. v6}, Lio/reactivex/internal/operators/flowable/k4$b;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;I)V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-interface {p1, v7}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x7

    return-void

    :cond_0
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    new-instance v10, Lio/reactivex/internal/operators/flowable/k4$a;

    const/4 v12, 0x5

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/k4;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/k4;->f:Lio/reactivex/e0;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v6, p0, Lio/reactivex/internal/operators/flowable/k4;->h:I

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    iget-boolean v9, p0, Lio/reactivex/internal/operators/flowable/k4;->i:Z

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-direct/range {v0 .. v9}, Lio/reactivex/internal/operators/flowable/k4$a;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IJZ)V

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-interface {p1, v10}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    return-void

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x1

    new-instance v9, Lio/reactivex/internal/operators/flowable/k4$c;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x7

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/k4;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4;->f:Lio/reactivex/e0;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v0}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v7

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget v8, p0, Lio/reactivex/internal/operators/flowable/k4;->h:I

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-direct/range {v0 .. v8}, Lio/reactivex/internal/operators/flowable/k4$c;-><init>(Lja/c;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;I)V

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-interface {p1, v9}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    return-void
.end method
