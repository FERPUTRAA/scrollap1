.class final Lio/reactivex/internal/operators/flowable/c0$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Ljava/lang/Runnable;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/c0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lio/reactivex/disposables/c;",
        ">;",
        "Ljava/lang/Runnable;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x5e8933e4e0c30cf5L


# instance fields
.field final idx:J

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final parent:Lio/reactivex/internal/operators/flowable/c0$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/c0$b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final value:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;JLio/reactivex/internal/operators/flowable/c0$b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;J",
            "Lio/reactivex/internal/operators/flowable/c0$b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c0$a;->value:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/c0$a;->idx:J

    const/4 v2, 0x1

    const/4 v1, 0x4

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/c0$a;->parent:Lio/reactivex/internal/operators/flowable/c0$b;

    const/4 v1, 0x7

    move v2, v1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~rs @~@ iol-o@b~ @~ ~1~.4v@i~~~b@@@lo~~@ @~ ub@@ s@~@ ~nt@d    /~K@c  f~o~o~ tf m~My/@ia@ ~~o@@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method b()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c0$a;->parent:Lio/reactivex/internal/operators/flowable/c0$b;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/c0$a;->idx:J

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/c0$a;->value:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3, p0}, Lio/reactivex/internal/operators/flowable/c0$b;->a(JLjava/lang/Object;Lio/reactivex/internal/operators/flowable/c0$a;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public c(Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lio/reactivex/internal/disposables/d;->d(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public run()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/c0$a;->b()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method
