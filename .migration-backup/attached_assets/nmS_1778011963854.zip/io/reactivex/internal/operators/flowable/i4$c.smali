.class final Lio/reactivex/internal/operators/flowable/i4$c;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;",
        "Ljava/lang/Object;",
        "Lio/reactivex/k<",
        "TT;>;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final A0:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TB;+",
            "Lja/b<",
            "TV;>;>;"
        }
    .end annotation
.end field

.field final B0:I

.field final C0:Lio/reactivex/disposables/b;

.field D0:Lja/d;

.field final E0:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field final F0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/reactivex/processors/g<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final G0:Ljava/util/concurrent/atomic/AtomicLong;

.field final k0:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TB;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lja/b;Lt7/o;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;",
            "Lja/b<",
            "TB;>;",
            "Lt7/o<",
            "-TB;+",
            "Lja/b<",
            "TV;>;>;I)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v1, 0x7

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x3

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$c;->E0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$c;->G0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i4$c;->k0:Lja/b;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/i4$c;->A0:Lt7/o;

    const/4 v2, 0x5

    const/4 v1, 0x4

    iput p4, p0, Lio/reactivex/internal/operators/flowable/i4$c;->B0:I

    const/4 v2, 0x4

    new-instance p2, Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p2}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p2, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p2}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i4$c;->F0:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-wide/16 p2, 0x1

    const-wide/16 p2, 0x1

    const/4 v2, 0x3

    const-wide/16 p2, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1, p2, p3}, Ljava/util/concurrent/atomic/AtomicLong;->lazySet(J)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "t siobo~ ~~@sin~ @ o@o@r~~u~ .@ S M@~1~@mt~ialc o@~~b@@~~@~@ yf@dK@@v@ @~-~/@b ~/f~@     o ~~4~l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method e()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->E0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x5

    move v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->n()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->F0:Ljava/util/List;

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v1, Lio/reactivex/processors/g;

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Lio/reactivex/internal/util/p;->s(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez p1, :cond_3

    const/4 v3, 0x0

    return-void

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->u()V

    const/4 v2, 0x1

    move v3, v2

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public k(Lja/c;Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->u()V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->G0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x1

    and-int/2addr v5, v4

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v5, 0x5

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    :cond_2
    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    iput-object p1, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->u()V

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->G0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    cmp-long v0, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    :cond_2
    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->D0:Lja/d;

    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$c;->D0:Lja/d;

    const/4 v3, 0x5

    move v4, v3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    new-instance v0, Lio/reactivex/internal/operators/flowable/i4$b;

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/flowable/i4$b;-><init>(Lio/reactivex/internal/operators/flowable/i4$c;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i4$c;->E0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v1, v2, v0}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i4$c;->G0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v4, 0x3

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-interface {p1, v1, v2}, Lja/d;->g(J)V

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$c;->k0:Lja/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method

.method t(Lio/reactivex/internal/operators/flowable/i4$a;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/i4$a<",
            "TT;TV;>;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->d(Lio/reactivex/disposables/c;)Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Lio/reactivex/internal/operators/flowable/i4$d;

    const/4 v3, 0x0

    and-int/2addr v4, v3

    iget-object p1, p1, Lio/reactivex/internal/operators/flowable/i4$a;->c:Lio/reactivex/processors/g;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/i4$d;-><init>(Lio/reactivex/processors/g;Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->u()V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method u()V
    .locals 13

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/i4$c;->F0:Ljava/util/List;

    const/4 v12, 0x5

    const/4 v3, 0x1

    const/4 v12, 0x1

    move v11, v3

    move v11, v3

    move v4, v3

    move v4, v3

    const/4 v12, 0x0

    move v4, v3

    move v4, v3

    :cond_0
    :goto_0
    const/4 v12, 0x1

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-interface {v0}, Lu7/n;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x4

    if-nez v6, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    move v7, v3

    move v7, v3

    const/4 v12, 0x1

    move v7, v3

    move v7, v3

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    goto :goto_1

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    const/4 v7, 0x0

    :goto_1
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-eqz v5, :cond_4

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-eqz v7, :cond_4

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->e()V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    if-eqz v0, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    if-eqz v3, :cond_3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    check-cast v3, Lio/reactivex/processors/g;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {v3, v0}, Lio/reactivex/processors/g;->onError(Ljava/lang/Throwable;)V

    const/4 v12, 0x0

    const/4 v11, 0x2

    goto :goto_2

    :cond_2
    const/4 v12, 0x2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    if-eqz v1, :cond_3

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    check-cast v1, Lio/reactivex/processors/g;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v1}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    goto :goto_3

    :cond_3
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-interface {v2}, Ljava/util/List;->clear()V

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    return-void

    :cond_4
    const/4 v12, 0x3

    const/4 v11, 0x0

    if-eqz v7, :cond_5

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    neg-int v4, v4

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {p0, v4}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result v4

    const/4 v11, 0x6

    shl-int/2addr v12, v11

    if-nez v4, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    return-void

    :cond_5
    const/4 v11, 0x2

    const/4 v12, 0x2

    instance-of v5, v6, Lio/reactivex/internal/operators/flowable/i4$d;

    const/4 v12, 0x5

    const/4 v11, 0x4

    if-eqz v5, :cond_a

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    check-cast v6, Lio/reactivex/internal/operators/flowable/i4$d;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget-object v5, v6, Lio/reactivex/internal/operators/flowable/i4$d;->a:Lio/reactivex/processors/g;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    if-eqz v5, :cond_6

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-interface {v2, v5}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    if-eqz v5, :cond_0

    const/4 v11, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v5, v6, Lio/reactivex/internal/operators/flowable/i4$d;->a:Lio/reactivex/processors/g;

    const/4 v12, 0x5

    const/4 v11, 0x0

    invoke-virtual {v5}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i4$c;->G0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    cmp-long v5, v5, v7

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    if-nez v5, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->e()V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    return-void

    :cond_6
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x4

    if-eqz v5, :cond_7

    const/4 v12, 0x1

    const/4 v11, 0x4

    goto/16 :goto_0

    :cond_7
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget v5, p0, Lio/reactivex/internal/operators/flowable/i4$c;->B0:I

    const/4 v12, 0x0

    const/4 v11, 0x0

    invoke-static {v5}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v5

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v9

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    cmp-long v7, v9, v7

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-eqz v7, :cond_9

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-interface {v2, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-interface {v1, v5}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v11, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-wide v7, 0x7fffffffffffffffL

    const/4 v12, 0x5

    const-wide v7, 0x7fffffffffffffffL

    const-wide v7, 0x7fffffffffffffffL

    const/4 v12, 0x4

    const/4 v11, 0x7

    cmp-long v7, v9, v7

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-eqz v7, :cond_8

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v11, 0x1

    or-int/2addr v12, v11

    invoke-virtual {p0, v7, v8}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_8
    :try_start_0
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/i4$c;->A0:Lt7/o;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-object v6, v6, Lio/reactivex/internal/operators/flowable/i4$d;->b:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-interface {v7, v6}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-string v7, "ppnmies ehp  erlThsiiuludbusll"

    const-string v7, "bhs suiinillspurpee pldTlushe "

    const/4 v12, 0x3

    const-string v7, "bh ro ihupeselilisunudpsT lp l"

    const-string v7, "The publisher supplied is null"

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-static {v6, v7}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    check-cast v6, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x5

    new-instance v7, Lio/reactivex/internal/operators/flowable/i4$a;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-direct {v7, p0, v5}, Lio/reactivex/internal/operators/flowable/i4$a;-><init>(Lio/reactivex/internal/operators/flowable/i4$c;Lio/reactivex/processors/g;)V

    const/4 v11, 0x7

    xor-int/2addr v12, v11

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v5, v7}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    move-result v5

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-eqz v5, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i4$c;->G0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-interface {v6, v7}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x5

    const/4 v11, 0x3

    goto/16 :goto_0

    :catchall_0
    move-exception v5

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    iput-boolean v3, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    invoke-interface {v1, v5}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    goto/16 :goto_0

    :cond_9
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    iput-boolean v3, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v12, 0x3

    new-instance v5, Lio/reactivex/exceptions/c;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v6, "ddwotb su ela wiiomnlevfned  setlneCqu ctoor rd wuo "

    const-string/jumbo v6, "uoume orldlti cunrdoda ntn Cww  ws eedqs efvl oeitko"

    const/4 v12, 0x1

    const-string v6, "fleouvuoq oo tk u d la snutwlCceew rdnt iewri dnseod"

    const-string v6, "Could not deliver new window due to lack of requests"

    const/4 v11, 0x2

    xor-int/2addr v12, v11

    invoke-direct {v5, v6}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-interface {v1, v5}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v12, 0x2

    goto/16 :goto_0

    :cond_a
    const/4 v11, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_4
    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-eqz v7, :cond_0

    const/4 v11, 0x7

    move v12, v11

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    check-cast v7, Lio/reactivex/processors/g;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-static {v6}, Lio/reactivex/internal/util/p;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v7, v8}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    goto :goto_4
.end method

.method v(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->D0:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$c;->E0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method w(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TB;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/i4$d;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v1, v2, p1}, Lio/reactivex/internal/operators/flowable/i4$d;-><init>(Lio/reactivex/processors/g;Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i4$c;->u()V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    return-void
.end method
