.class final Lio/reactivex/internal/operators/flowable/a2$b;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x2cf94dc376ca3e41L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final bufferSize:J

.field volatile cancelled:Z

.field final deque:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "TT;>;"
        }
    .end annotation
.end field

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final onOverflow:Lt7/a;

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;

.field final strategy:Lio/reactivex/a;


# direct methods
.method constructor <init>(Lja/c;Lt7/a;Lio/reactivex/a;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/a;",
            "Lio/reactivex/a;",
            "J)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->actual:Lja/c;

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/a2$b;->onOverflow:Lt7/a;

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/a2$b;->strategy:Lio/reactivex/a;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/a2$b;->bufferSize:J

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x3

    new-instance p1, Ljava/util/ArrayDeque;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->deque:Ljava/util/Deque;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method a(Ljava/util/Deque;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Deque<",
            "TT;>;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y@s~@@~ m~vfio~Mt@@f o@o  ~~b.~ ~ ~@s  @l -/@@a~@K~~@@1~ @~@u~ld @r@~/~i  b@4@@ oi ~t~o~bS~~ onc"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    monitor-enter p1

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-interface {p1}, Ljava/util/Collection;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-exit p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw v0
.end method

.method b()V
    .locals 15

    const/4 v14, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v14, 0x7

    if-eqz v0, :cond_0

    const/4 v14, 0x1

    return-void

    :cond_0
    const/4 v14, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->deque:Ljava/util/Deque;

    const/4 v14, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->actual:Lja/c;

    const/4 v2, 0x1

    move v14, v2

    move v14, v2

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :cond_1
    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/a2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x6

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    const/4 v14, 0x4

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    move-wide v8, v6

    :goto_0
    const/4 v14, 0x2

    cmp-long v10, v8, v4

    const/4 v14, 0x6

    if-eqz v10, :cond_7

    const/4 v14, 0x5

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/a2$b;->cancelled:Z

    const/4 v14, 0x2

    if-eqz v11, :cond_2

    const/4 v14, 0x5

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a2$b;->a(Ljava/util/Deque;)V

    const/4 v14, 0x0

    return-void

    :cond_2
    const/4 v14, 0x0

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/a2$b;->done:Z

    const/4 v14, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v14, 0x1

    invoke-interface {v0}, Ljava/util/Deque;->poll()Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x0

    if-nez v12, :cond_3

    const/4 v14, 0x4

    move v13, v2

    move v13, v2

    const/4 v14, 0x0

    goto :goto_1

    :cond_3
    const/4 v14, 0x4

    const/4 v13, 0x0

    :goto_1
    const/4 v14, 0x1

    if-eqz v11, :cond_5

    iget-object v11, p0, Lio/reactivex/internal/operators/flowable/a2$b;->error:Ljava/lang/Throwable;

    const/4 v14, 0x1

    if-eqz v11, :cond_4

    const/4 v14, 0x6

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a2$b;->a(Ljava/util/Deque;)V

    invoke-interface {v1, v11}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v14, 0x2

    return-void

    :cond_4
    const/4 v14, 0x0

    if-eqz v13, :cond_5

    const/4 v14, 0x4

    invoke-interface {v1}, Lja/c;->onComplete()V

    const/4 v14, 0x5

    return-void

    :cond_5
    if-eqz v13, :cond_6

    const/4 v14, 0x6

    goto :goto_2

    :cond_6
    const/4 v14, 0x5

    invoke-interface {v1, v12}, Lja/c;->f(Ljava/lang/Object;)V

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const/4 v14, 0x4

    add-long/2addr v8, v10

    const/4 v14, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v14, 0x0

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    throw v1

    :cond_7
    :goto_2
    const/4 v14, 0x0

    if-nez v10, :cond_a

    const/4 v14, 0x1

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/a2$b;->cancelled:Z

    const/4 v14, 0x1

    if-eqz v4, :cond_8

    const/4 v14, 0x0

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a2$b;->a(Ljava/util/Deque;)V

    const/4 v14, 0x3

    return-void

    :cond_8
    const/4 v14, 0x5

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/a2$b;->done:Z

    const/4 v14, 0x4

    monitor-enter v0

    :try_start_2
    const/4 v14, 0x1

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v5

    const/4 v14, 0x4

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v14, 0x7

    if-eqz v4, :cond_a

    const/4 v14, 0x3

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/a2$b;->error:Ljava/lang/Throwable;

    const/4 v14, 0x2

    if-eqz v4, :cond_9

    const/4 v14, 0x2

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a2$b;->a(Ljava/util/Deque;)V

    const/4 v14, 0x3

    invoke-interface {v1, v4}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v14, 0x2

    return-void

    :cond_9
    const/4 v14, 0x1

    if-eqz v5, :cond_a

    const/4 v14, 0x6

    invoke-interface {v1}, Lja/c;->onComplete()V

    const/4 v14, 0x6

    return-void

    :catchall_1
    move-exception v1

    :try_start_3
    const/4 v14, 0x4

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v14, 0x0

    throw v1

    :cond_a
    const/4 v14, 0x4

    cmp-long v4, v8, v6

    const/4 v14, 0x7

    if-eqz v4, :cond_b

    const/4 v14, 0x4

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/a2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x2

    invoke-static {v4, v8, v9}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_b
    const/4 v14, 0x3

    neg-int v3, v3

    invoke-virtual {p0, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const/4 v14, 0x3

    if-nez v3, :cond_1

    const/4 v14, 0x5

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->cancelled:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->s:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->deque:Ljava/util/Deque;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/a2$b;->a(Ljava/util/Deque;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->done:Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-void

    :cond_0
    const/4 v7, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->deque:Ljava/util/Deque;

    const/4 v7, 0x7

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/Deque;->size()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    int-to-long v1, v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/a2$b;->bufferSize:J

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    cmp-long v1, v1, v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez v1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object v1, Lio/reactivex/internal/operators/flowable/a2$a;->a:[I

    const/4 v7, 0x4

    const/4 v6, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a2$b;->strategy:Lio/reactivex/a;

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    aget v1, v1, v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x3

    move v7, v6

    if-eq v1, v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v4, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eq v1, v4, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-interface {v0}, Ljava/util/Deque;->poll()Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v0, p1}, Ljava/util/Deque;->offer(Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v0}, Ljava/util/Deque;->pollLast()Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-interface {v0, p1}, Ljava/util/Deque;->offer(Ljava/lang/Object;)Z

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    move v5, v3

    move v5, v3

    const/4 v7, 0x2

    move v5, v3

    move v5, v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    const/4 v7, 0x1

    move v3, v2

    move v3, v2

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    move v2, v5

    move v2, v5

    const/4 v7, 0x4

    move v2, v5

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v0, p1}, Ljava/util/Deque;->offer(Ljava/lang/Object;)Z

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v6, 0x1

    move v7, v6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v2, :cond_4

    const/4 v7, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->onOverflow:Lt7/a;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz p1, :cond_6

    :try_start_1
    const/4 v7, 0x7

    invoke-interface {p1}, Lt7/a;->run()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_2

    :catchall_0
    move-exception p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->s:Lja/d;

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a2$b;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_2

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v3, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->s:Lja/d;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v7, 0x7

    invoke-direct {p1}, Lio/reactivex/exceptions/c;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a2$b;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    goto :goto_2

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a2$b;->b()V

    :cond_6
    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void

    :catchall_1
    move-exception p1

    :try_start_2
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x6

    throw p1
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a2$b;->b()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->done:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a2$b;->b()V

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->error:Ljava/lang/Throwable;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a2$b;->b()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->s:Lja/d;

    const/4 v2, 0x3

    move v3, v2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a2$b;->s:Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a2$b;->actual:Lja/c;

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method
