.class final Lio/reactivex/internal/operators/flowable/h2$c;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TR;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TR;>;"
        }
    .end annotation
.end field

.field final b:Lio/reactivex/internal/operators/flowable/h2$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/h2$a<",
            "*>;"
        }
    .end annotation
.end field

.field c:Lja/d;


# direct methods
.method constructor <init>(Lja/c;Lio/reactivex/internal/operators/flowable/h2$a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lio/reactivex/internal/operators/flowable/h2$a<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h2$c;->a:Lja/c;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h2$c;->b:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~st@~~~iro@ ~@ .b 1@  o~fvS@ @~oi @d~s ~~ @~y@bi@/@ l~ Mo ~@@ ~f~~ l~@o@@/ Km4~~at @~u-n@~~ @ob"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->c:Lja/d;

    const/4 v1, 0x1

    move v2, v1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->b:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/h2$a;->e()V

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->a:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->c:Lja/d;

    const/4 v1, 0x4

    move v2, v1

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->a:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->b:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/h2$a;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->a:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    and-int/2addr v2, v1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h2$c;->b:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/h2$a;->e()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$c;->c:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h2$c;->c:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h2$c;->a:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x1

    return-void
.end method
