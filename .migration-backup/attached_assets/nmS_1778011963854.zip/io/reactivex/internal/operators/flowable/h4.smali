.class public final Lio/reactivex/internal/operators/flowable/h4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/h4$a;,
        Lio/reactivex/internal/operators/flowable/h4$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;",
        "Lio/reactivex/k<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final c:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TB;>;"
        }
    .end annotation
.end field

.field final d:I


# direct methods
.method public constructor <init>(Lja/b;Lja/b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "TB;>;I)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h4;->c:Lja/b;

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    iput p3, p0, Lio/reactivex/internal/operators/flowable/h4;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "nysK.fo ~~~o-@@o~@ ~~4@@i~M c~~@ @f@/S@~va~~ i~i~b@~ ~~~td   @@b@b ~ @u~/ ~r@ 1@ o@ lo@ @@ tmlo~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/h4$b;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v5, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h4;->c:Lja/b;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget v3, p0, Lio/reactivex/internal/operators/flowable/h4;->d:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v1, v2, p1, v3}, Lio/reactivex/internal/operators/flowable/h4$b;-><init>(Lja/c;Lja/b;I)V

    const/4 v5, 0x6

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    return-void
.end method
