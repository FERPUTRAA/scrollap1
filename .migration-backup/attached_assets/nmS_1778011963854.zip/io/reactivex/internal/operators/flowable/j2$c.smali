.class final Lio/reactivex/internal/operators/flowable/j2$c;
.super Lio/reactivex/internal/operators/flowable/j2$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x23e7f25903d0c345L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;JJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;JJ)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p2, p3, p4, p5}, Lio/reactivex/internal/operators/flowable/j2$a;-><init>(JJ)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j2$c;->actual:Lja/c;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method a()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@ s@~Klmtnirod @ ~.~@ o@Si@b~@1/@~o@co@~@ @u y~b @/ff@-~~~ s  @o@4lM~~b~~~@  @ via~@ ~  o~~ ~~@~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j2$c;->actual:Lja/c;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    :goto_0
    const/4 v8, 0x0

    cmp-long v5, v3, v0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v5, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-boolean v5, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v5, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    invoke-interface {v2, v5}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x5

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-long/2addr v3, v5

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v0, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-void

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-interface {v2}, Lja/c;->onComplete()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-void
.end method

.method c(J)V
    .locals 13

    const/4 v11, 0x5

    move v12, v11

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/j2$c;->actual:Lja/c;

    const/4 v12, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    :cond_0
    move-wide v7, v5

    :cond_1
    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    cmp-long v9, v7, p1

    const/4 v12, 0x2

    const/4 v11, 0x2

    if-eqz v9, :cond_3

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    cmp-long v9, v2, v0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-eqz v9, :cond_3

    const/4 v11, 0x6

    shl-int/2addr v12, v11

    iget-boolean v9, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-eqz v9, :cond_2

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    return-void

    :cond_2
    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-interface {v4, v9}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const/4 v12, 0x2

    const-wide/16 v9, 0x1

    const-wide/16 v9, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    add-long/2addr v7, v9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    add-long/2addr v2, v9

    const/4 v12, 0x2

    goto :goto_0

    :cond_3
    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    cmp-long p1, v2, v0

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-nez p1, :cond_5

    const/4 v12, 0x0

    const/4 v11, 0x4

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-nez p1, :cond_4

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-interface {v4}, Lja/c;->onComplete()V

    :cond_4
    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    return-void

    :cond_5
    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    cmp-long v9, v7, p1

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-nez v9, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    neg-long p1, v7

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    cmp-long v7, p1, v5

    const/4 v11, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x1

    if-nez v7, :cond_0

    const/4 v12, 0x5

    return-void
.end method
