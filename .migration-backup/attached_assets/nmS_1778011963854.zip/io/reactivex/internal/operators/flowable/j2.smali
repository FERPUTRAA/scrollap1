.class public final Lio/reactivex/internal/operators/flowable/j2;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/j2$b;,
        Lio/reactivex/internal/operators/flowable/j2$c;,
        Lio/reactivex/internal/operators/flowable/j2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/k<",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation


# instance fields
.field final b:J

.field final c:J


# direct methods
.method public constructor <init>(JJ)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/j2;->b:J

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    add-long/2addr p1, p3

    const/4 v1, 0x6

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/j2;->c:J

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const-string v13, "oos@~m vo~@  t~~@o@@ sS@ f b/@lK~ . @~icui  ~-@~ 1 @~~  l@o@o@r~@~~~@y~@~d@~ @4@ntbbif~M~/~ a@ ~"

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    instance-of v0, p1, Lu7/a;

    const/4 v13, 0x3

    if-eqz v0, :cond_0

    const/4 v13, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/j2$b;

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v13, 0x0

    check-cast v2, Lu7/a;

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/j2;->b:J

    const/4 v13, 0x1

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/j2;->c:J

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v13, 0x2

    invoke-direct/range {v1 .. v6}, Lio/reactivex/internal/operators/flowable/j2$b;-><init>(Lu7/a;JJ)V

    const/4 v13, 0x4

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v13, 0x0

    goto :goto_0

    :cond_0
    const/4 v13, 0x6

    new-instance v0, Lio/reactivex/internal/operators/flowable/j2$c;

    const/4 v13, 0x1

    iget-wide v9, p0, Lio/reactivex/internal/operators/flowable/j2;->b:J

    const/4 v13, 0x7

    iget-wide v11, p0, Lio/reactivex/internal/operators/flowable/j2;->c:J

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v13, 0x5

    invoke-direct/range {v7 .. v12}, Lio/reactivex/internal/operators/flowable/j2$c;-><init>(Lja/c;JJ)V

    const/4 v13, 0x2

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    :goto_0
    const/4 v13, 0x6

    return-void
.end method
