.class final Lio/reactivex/internal/operators/flowable/s2$l;
.super Lio/reactivex/internal/operators/flowable/s2$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "l"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/s2$g<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x2ffd21f3bea38aacL


# instance fields
.field final limit:I

.field final maxAge:J

.field final scheduler:Lio/reactivex/e0;

.field final unit:Ljava/util/concurrent/TimeUnit;


# direct methods
.method constructor <init>(IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/reactivex/internal/operators/flowable/s2$g;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/s2$l;->scheduler:Lio/reactivex/e0;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lio/reactivex/internal/operators/flowable/s2$l;->limit:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/s2$l;->maxAge:J

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/s2$l;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method g(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    new-instance v0, Lio/reactivex/schedulers/c;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$l;->scheduler:Lio/reactivex/e0;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/s2$l;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v1, v2}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/s2$l;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x7

    move v5, v4

    invoke-direct {v0, p1, v1, v2, v3}, Lio/reactivex/schedulers/c;-><init>(Ljava/lang/Object;JLjava/util/concurrent/TimeUnit;)V

    const/4 v4, 0x0

    move v5, v4

    return-object v0
.end method

.method j(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p1, Lio/reactivex/schedulers/c;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Lio/reactivex/schedulers/c;->d()Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x4

    return-object p1
.end method

.method n()V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$l;->scheduler:Lio/reactivex/e0;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$l;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/s2$l;->maxAge:J

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    sub-long/2addr v0, v2

    const/4 v9, 0x4

    const/4 v8, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    check-cast v2, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    check-cast v3, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v4, 0x0

    :goto_0
    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    move-object v2, v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eqz v2, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget v5, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget v6, p0, Lio/reactivex/internal/operators/flowable/s2$l;->limit:I

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-le v5, v6, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    add-int/lit8 v5, v5, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iput v5, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    check-cast v3, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v9, 0x0

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v5, v2, Lio/reactivex/internal/operators/flowable/s2$i;->value:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    check-cast v5, Lio/reactivex/schedulers/c;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v5}, Lio/reactivex/schedulers/c;->a()J

    move-result-wide v5

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    cmp-long v5, v5, v0

    const/4 v8, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-gtz v5, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget v3, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v9, 0x4

    const/4 v8, 0x3

    add-int/lit8 v3, v3, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    iput v3, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    check-cast v3, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz v4, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p0, v3}, Lio/reactivex/internal/operators/flowable/s2$g;->m(Lio/reactivex/internal/operators/flowable/s2$i;)V

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    return-void
.end method

.method o()V
    .locals 12

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$l;->scheduler:Lio/reactivex/e0;

    const/4 v11, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$l;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v0, v1}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/s2$l;->maxAge:J

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    sub-long/2addr v0, v2

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    check-cast v2, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    check-cast v3, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v4, 0x0

    :goto_0
    move-object v9, v3

    move-object v9, v3

    move-object v9, v3

    move-object v9, v3

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v3, v2

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-eqz v2, :cond_0

    const/4 v10, 0x4

    move v11, v10

    iget v5, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    const/4 v6, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    if-le v5, v6, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    iget-object v5, v2, Lio/reactivex/internal/operators/flowable/s2$i;->value:Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    check-cast v5, Lio/reactivex/schedulers/c;

    const/4 v10, 0x6

    shl-int/2addr v11, v10

    invoke-virtual {v5}, Lio/reactivex/schedulers/c;->a()J

    move-result-wide v7

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    cmp-long v5, v7, v0

    const/4 v10, 0x6

    move v11, v10

    if-gtz v5, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget v3, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    sub-int/2addr v3, v6

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    iput v3, p0, Lio/reactivex/internal/operators/flowable/s2$g;->size:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    check-cast v3, Lio/reactivex/internal/operators/flowable/s2$i;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    goto :goto_0

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v4, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {p0, v3}, Lio/reactivex/internal/operators/flowable/s2$g;->m(Lio/reactivex/internal/operators/flowable/s2$i;)V

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    return-void
.end method
