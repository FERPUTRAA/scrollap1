.class final Lio/reactivex/internal/operators/flowable/i1$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/d;
.implements Lio/reactivex/internal/operators/flowable/i1$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T",
        "Left:Ljava/lang/Object;",
        "TRight:",
        "Ljava/lang/Object;",
        "T",
        "LeftEnd:Ljava/lang/Object;",
        "TRightEnd:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/d;",
        "Lio/reactivex/internal/operators/flowable/i1$b;"
    }
.end annotation


# static fields
.field static final a:Ljava/lang/Integer;

.field static final b:Ljava/lang/Integer;

.field static final c:Ljava/lang/Integer;

.field static final d:Ljava/lang/Integer;

.field private static final serialVersionUID:J = -0x54414b546f40e739L


# instance fields
.field final active:Ljava/util/concurrent/atomic/AtomicInteger;

.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TR;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final disposables:Lio/reactivex/disposables/b;

.field final error:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field final leftEnd:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT",
            "Left;",
            "+",
            "Lja/b<",
            "TT",
            "LeftEnd;",
            ">;>;"
        }
    .end annotation
.end field

.field leftIndex:I

.field final lefts:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Lio/reactivex/processors/g<",
            "TTRight;>;>;"
        }
    .end annotation
.end field

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final resultSelector:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT",
            "Left;",
            "-",
            "Lio/reactivex/k<",
            "TTRight;>;+TR;>;"
        }
    .end annotation
.end field

.field final rightEnd:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TTRight;+",
            "Lja/b<",
            "TTRightEnd;>;>;"
        }
    .end annotation
.end field

.field rightIndex:I

.field final rights:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "TTRight;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    const/4 v0, 0x1

    and-int/2addr v2, v0

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Lio/reactivex/internal/operators/flowable/i1$a;->a:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput-object v0, Lio/reactivex/internal/operators/flowable/i1$a;->b:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object v0, Lio/reactivex/internal/operators/flowable/i1$a;->c:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    sput-object v0, Lio/reactivex/internal/operators/flowable/i1$a;->d:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method constructor <init>(Lja/c;Lt7/o;Lt7/o;Lt7/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lt7/o<",
            "-TT",
            "Left;",
            "+",
            "Lja/b<",
            "TT",
            "LeftEnd;",
            ">;>;",
            "Lt7/o<",
            "-TTRight;+",
            "Lja/b<",
            "TTRightEnd;>;>;",
            "Lt7/c<",
            "-TT",
            "Left;",
            "-",
            "Lio/reactivex/k<",
            "TTRight;>;+TR;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p1, Lio/reactivex/disposables/b;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    invoke-direct {p1}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v1, 0x2

    or-int/2addr v2, v1

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lio/reactivex/k;->V()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance p1, Ljava/util/LinkedHashMap;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    new-instance p1, Ljava/util/LinkedHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rights:Ljava/util/Map;

    const/4 v2, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i1$a;->leftEnd:Lt7/o;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rightEnd:Lt7/o;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/i1$a;->resultSelector:Lt7/c;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p2, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "l sb@ ~ @@~ d~~@~ ~omt  ~ r4 @ y~  @~l~~@~~@M~@/cs@f~@uo1@K@ io o@@ bof~/@~~@~.@i@ @~~iSavb -no~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public b(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->h()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public c(ZLjava/lang/Object;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    sget-object p1, Lio/reactivex/internal/operators/flowable/i1$a;->a:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object p1, Lio/reactivex/internal/operators/flowable/i1$a;->b:Ljava/lang/Integer;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v1, 0x1

    move v2, v1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->h()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x1

    throw p1
.end method

.method public cancel()V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->cancelled:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->cancelled:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public d(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->h()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public e(ZLio/reactivex/internal/operators/flowable/i1$c;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object p1, Lio/reactivex/internal/operators/flowable/i1$a;->c:Ljava/lang/Integer;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object p1, Lio/reactivex/internal/operators/flowable/i1$a;->d:Ljava/lang/Integer;

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->h()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw p1
.end method

.method public f(Lio/reactivex/internal/operators/flowable/i1$d;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->d(Lio/reactivex/disposables/c;)Z

    const/4 v1, 0x2

    move v2, v1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->h()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x4

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method h()V
    .locals 12

    const/4 v11, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-eqz v0, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    return-void

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->actual:Lja/c;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    const/4 v2, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    move v3, v2

    move v3, v2

    const/4 v11, 0x4

    move v3, v2

    move v3, v2

    :cond_1
    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/i1$a;->cancelled:Z

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-eqz v4, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    return-void

    :cond_2
    const/4 v11, 0x6

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v11, 0x4

    const/4 v10, 0x0

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    check-cast v4, Ljava/lang/Throwable;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-eqz v4, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->a()V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p0, v1}, Lio/reactivex/internal/operators/flowable/i1$a;->i(Lja/c;)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    return-void

    :cond_3
    const/4 v11, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/i1$a;->active:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v4

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v5, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    if-nez v4, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    move v4, v2

    move v4, v2

    const/4 v11, 0x6

    move v4, v2

    move v4, v2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    goto :goto_1

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    move v4, v5

    move v4, v5

    const/4 v11, 0x3

    move v4, v5

    :goto_1
    const/4 v11, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    check-cast v6, Ljava/lang/Integer;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-nez v6, :cond_5

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    move v7, v2

    move v7, v2

    const/4 v11, 0x4

    move v7, v2

    move v7, v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto :goto_2

    :cond_5
    const/4 v10, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    move v7, v5

    move v7, v5

    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-eqz v4, :cond_7

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-eqz v7, :cond_7

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-eqz v2, :cond_6

    const/4 v11, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    check-cast v2, Lio/reactivex/processors/g;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    goto :goto_3

    :cond_6
    const/4 v11, 0x1

    const/4 v10, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v11, 0x2

    const/4 v10, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rights:Ljava/util/Map;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-interface {v1}, Lja/c;->onComplete()V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    return-void

    :cond_7
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v7, :cond_8

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    neg-int v3, v3

    const/4 v10, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p0, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-nez v3, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    return-void

    :cond_8
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget-object v7, Lio/reactivex/internal/operators/flowable/i1$a;->a:Ljava/lang/Integer;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    if-ne v6, v7, :cond_b

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {}, Lio/reactivex/processors/g;->e8()Lio/reactivex/processors/g;

    move-result-object v5

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->leftIndex:I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    add-int/lit8 v7, v6, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    iput v7, p0, Lio/reactivex/internal/operators/flowable/i1$a;->leftIndex:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-interface {v7, v8, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_0
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/i1$a;->leftEnd:Lt7/o;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-interface {v7, v4}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x7

    const/4 v10, 0x5

    const-string/jumbo v8, "ufsb nlrEeTdeeln uusenthr  edaiPrlhtl"

    const/4 v11, 0x2

    const-string v8, "PtsmTui edtlre hlbnEnrle ahuul  ndere"

    const-string v8, "The leftEnd returned a null Publisher"

    const/4 v10, 0x3

    shl-int/2addr v11, v10

    invoke-static {v7, v8}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    check-cast v7, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    new-instance v8, Lio/reactivex/internal/operators/flowable/i1$c;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-direct {v8, p0, v2, v6}, Lio/reactivex/internal/operators/flowable/i1$c;-><init>(Lio/reactivex/internal/operators/flowable/i1$b;ZI)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v6, v8}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-interface {v7, v8}, Lja/b;->j(Lja/c;)V

    const/4 v11, 0x5

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    check-cast v6, Ljava/lang/Throwable;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v6, :cond_9

    const/4 v11, 0x5

    const/4 v10, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->a()V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p0, v1}, Lio/reactivex/internal/operators/flowable/i1$a;->i(Lja/c;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    return-void

    :cond_9
    :try_start_1
    const/4 v11, 0x1

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->resultSelector:Lt7/c;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v6, v4, v5}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string v6, "clurolt orelud tlrnmuvSeh une  erTlaeets"

    const-string v6, "alumlseaSetrevnletnrrlotdueu  lue  rh cT"

    const/4 v11, 0x7

    const-string v6, "ev lTblr tSaree u ele rtlutedhnlsureoauc"

    const-string v6, "The resultSelector returned a null value"

    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v4, v6}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v6

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x3

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    cmp-long v6, v6, v8

    const/4 v11, 0x3

    const/4 v10, 0x4

    if-eqz v6, :cond_a

    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-interface {v1, v4}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/i1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v11, 0x5

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v4, v6, v7}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rights:Ljava/util/Map;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-interface {v4}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v4

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-interface {v4}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_4
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v11, 0x0

    const/4 v10, 0x0

    if-eqz v6, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v5, v6}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    goto :goto_4

    :cond_a
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v2, Lio/reactivex/exceptions/c;

    const/4 v11, 0x6

    const-string v3, "Caduoatsteln  ktec rvofeo emieuqod l s ouul "

    const-string v3, " sqsm un uCeeva a ldult uroed toolkfee itcto"

    const-string v3, "Could not emit value due to lack of requests"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {v2, v3}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    invoke-virtual {p0, v2, v1, v0}, Lio/reactivex/internal/operators/flowable/i1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    return-void

    :catchall_0
    move-exception v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0, v2, v1, v0}, Lio/reactivex/internal/operators/flowable/i1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    return-void

    :catchall_1
    move-exception v2

    const/4 v11, 0x7

    const/4 v10, 0x0

    invoke-virtual {p0, v2, v1, v0}, Lio/reactivex/internal/operators/flowable/i1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    return-void

    :cond_b
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    sget-object v7, Lio/reactivex/internal/operators/flowable/i1$a;->b:Ljava/lang/Integer;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-ne v6, v7, :cond_d

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rightIndex:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    add-int/lit8 v7, v6, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    iput v7, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rightIndex:I

    const/4 v10, 0x1

    move v11, v10

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rights:Ljava/util/Map;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-interface {v7, v8, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :try_start_2
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rightEnd:Lt7/o;

    const/4 v10, 0x1

    move v11, v10

    invoke-interface {v7, v4}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string v8, "lrnliebptehEhdThrnlg b   uirt durPeaen"

    const-string v8, "rhrldb rne ihlebtlPEuugTntuhed ar n ie"

    const/4 v11, 0x3

    const-string v8, "lusrhu iqituETe etnb lhadhrl rnendgr e"

    const-string v8, "The rightEnd returned a null Publisher"

    const/4 v11, 0x0

    invoke-static {v7, v8}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x0

    const/4 v10, 0x3

    check-cast v7, Lja/b;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v10, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v8, Lio/reactivex/internal/operators/flowable/i1$c;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-direct {v8, p0, v5, v6}, Lio/reactivex/internal/operators/flowable/i1$c;-><init>(Lio/reactivex/internal/operators/flowable/i1$b;ZI)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v5, v8}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v7, v8}, Lja/b;->j(Lja/c;)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v10, 0x4

    move v11, v10

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v5

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    check-cast v5, Ljava/lang/Throwable;

    const/4 v11, 0x1

    if-eqz v5, :cond_c

    const/4 v10, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v10, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->a()V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0, v1}, Lio/reactivex/internal/operators/flowable/i1$a;->i(Lja/c;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    return-void

    :cond_c
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v11, 0x0

    const/4 v10, 0x0

    invoke-interface {v5}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v5

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_5
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-eqz v6, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    check-cast v6, Lio/reactivex/processors/g;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v6, v4}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v11, 0x2

    const/4 v10, 0x4

    goto :goto_5

    :catchall_2
    move-exception v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p0, v2, v1, v0}, Lio/reactivex/internal/operators/flowable/i1$a;->j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    return-void

    :cond_d
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    sget-object v5, Lio/reactivex/internal/operators/flowable/i1$a;->c:Ljava/lang/Integer;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-ne v6, v5, :cond_e

    const/4 v11, 0x0

    check-cast v4, Lio/reactivex/internal/operators/flowable/i1$c;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v11, 0x2

    iget v6, v4, Lio/reactivex/internal/operators/flowable/i1$c;->index:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-interface {v5, v6}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    check-cast v5, Lio/reactivex/processors/g;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v6, v4}, Lio/reactivex/disposables/b;->b(Lio/reactivex/disposables/c;)Z

    const/4 v11, 0x3

    if-eqz v5, :cond_1

    const/4 v10, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v5}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v10, 0x2

    move v11, v10

    goto/16 :goto_0

    :cond_e
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v5, Lio/reactivex/internal/operators/flowable/i1$a;->d:Ljava/lang/Integer;

    const/4 v11, 0x1

    const/4 v10, 0x6

    if-ne v6, v5, :cond_1

    const/4 v10, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    check-cast v4, Lio/reactivex/internal/operators/flowable/i1$c;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rights:Ljava/util/Map;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget v6, v4, Lio/reactivex/internal/operators/flowable/i1$c;->index:I

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-interface {v5, v6}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x5

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/i1$a;->disposables:Lio/reactivex/disposables/b;

    const/4 v11, 0x5

    const/4 v10, 0x2

    invoke-virtual {v5, v4}, Lio/reactivex/disposables/b;->b(Lio/reactivex/disposables/c;)Z

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto/16 :goto_0
.end method

.method i(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "*>;)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0}, Lio/reactivex/internal/util/j;->c(Ljava/util/concurrent/atomic/AtomicReference;)Ljava/lang/Throwable;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v3, 0x4

    and-int/2addr v4, v3

    invoke-interface {v1}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    check-cast v2, Lio/reactivex/processors/g;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v2, v0}, Lio/reactivex/processors/g;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->lefts:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v3, 0x6

    move v4, v3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i1$a;->rights:Ljava/util/Map;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map;->clear()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method j(Ljava/lang/Throwable;Lja/c;Lu7/o;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Throwable;",
            "Lja/c<",
            "*>;",
            "Lu7/o<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$a;->error:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/util/j;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Throwable;)Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-interface {p3}, Lu7/o;->clear()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/i1$a;->a()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Lio/reactivex/internal/operators/flowable/i1$a;->i(Lja/c;)V

    const/4 v2, 0x7

    return-void
.end method
