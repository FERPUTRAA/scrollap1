.class Lio/reactivex/internal/operators/flowable/o2$a;
.super Ljava/lang/Object;

# interfaces
.implements Lt7/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/o2;->a8(Lja/c;Ljava/util/concurrent/atomic/AtomicBoolean;)Lt7/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lt7/g<",
        "Lio/reactivex/disposables/c;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lja/c;

.field final synthetic b:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final synthetic c:Lio/reactivex/internal/operators/flowable/o2;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/o2;Lja/c;Ljava/util/concurrent/atomic/AtomicBoolean;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->c:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o2$a;->a:Lja/c;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/o2$a;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Lio/reactivex/disposables/c;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ saybb~l~fmo@~~ @SK@~t@@@ f @~ /-. @o@sb@~u ~ @il~iM@@@  o~~~ ~4 ~n@/~i~@vo1o c @~@~o@r ~~d @ ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->c:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->c:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->a:Lja/c;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v2, p1, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v2}, Lio/reactivex/internal/operators/flowable/o2;->Z7(Lja/c;Lio/reactivex/disposables/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->c:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object p1, p1, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v3, 0x6

    move v4, v3

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->c:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$a;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    throw p1
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    check-cast p1, Lio/reactivex/disposables/c;

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/o2$a;->a(Lio/reactivex/disposables/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method
