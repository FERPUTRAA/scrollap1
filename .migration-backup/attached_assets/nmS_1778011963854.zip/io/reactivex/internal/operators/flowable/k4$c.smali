.class final Lio/reactivex/internal/operators/flowable/k4$c;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/k4$c$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;",
        "Ljava/lang/Object;",
        "Lio/reactivex/k<",
        "TT;>;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# instance fields
.field final A0:J

.field final B0:Ljava/util/concurrent/TimeUnit;

.field final C0:Lio/reactivex/e0$c;

.field final D0:I

.field final E0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lio/reactivex/processors/g<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field F0:Lja/d;

.field volatile G0:Z

.field final k0:J


# direct methods
.method constructor <init>(Lja/c;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0$c;",
            "I)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/k4$c;->k0:J

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/k4$c;->A0:J

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/k4$c;->B0:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p7, p0, Lio/reactivex/internal/operators/flowable/k4$c;->C0:Lio/reactivex/e0$c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput p8, p0, Lio/reactivex/internal/operators/flowable/k4$c;->D0:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p1, Ljava/util/LinkedList;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k4$c;->E0:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@ to~~@@ ~M l@@~m@~ 1bo  ~~u@~l@yfic  iS@@@-@~~~i @o~4 ~@~@o~@r.Kva n~~ t@~o  f ob~/~s@@d/b  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x1

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$c;->C0:Lio/reactivex/e0$c;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->n()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$c;->E0:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v1, Lio/reactivex/processors/g;

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    const/4 p1, -0x1

    move v3, p1

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_2

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez p1, :cond_2

    const/4 v3, 0x6

    return-void

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->u()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->u()V

    :cond_0
    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->u()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public q(Lja/d;)V
    .locals 14

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$c;->F0:Lja/d;

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    if-eqz v0, :cond_3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k4$c;->F0:Lja/d;

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    if-eqz v0, :cond_0

    return-void

    :cond_0
    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-eqz v2, :cond_2

    iget v2, p0, Lio/reactivex/internal/operators/flowable/k4$c;->D0:I

    invoke-static {v2}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v2

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/k4$c;->E0:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget-object v3, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    invoke-interface {v3, v2}, Lja/c;->f(Ljava/lang/Object;)V

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    cmp-long v0, v0, v3

    if-eqz v0, :cond_1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_1
    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$c;->C0:Lio/reactivex/e0$c;

    new-instance v1, Lio/reactivex/internal/operators/flowable/k4$c$a;

    invoke-direct {v1, p0, v2}, Lio/reactivex/internal/operators/flowable/k4$c$a;-><init>(Lio/reactivex/internal/operators/flowable/k4$c;Lio/reactivex/processors/g;)V

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/k4$c;->k0:J

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/k4$c;->B0:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v1, v5, v6, v2}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/k4$c;->C0:Lio/reactivex/e0$c;

    iget-wide v11, p0, Lio/reactivex/internal/operators/flowable/k4$c;->A0:J

    iget-object v13, p0, Lio/reactivex/internal/operators/flowable/k4$c;->B0:Ljava/util/concurrent/TimeUnit;

    move-object v8, p0

    move-object v8, p0

    move-wide v9, v11

    invoke-virtual/range {v7 .. v13}, Lio/reactivex/e0$c;->f(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    invoke-interface {p1, v3, v4}, Lja/d;->g(J)V

    goto :goto_0

    :cond_2
    invoke-interface {p1}, Lja/d;->cancel()V

    iget-object p1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    new-instance v0, Lio/reactivex/exceptions/c;

    const-string/jumbo v1, "uo m ksdrasteo d etwftiefot rlhsleC u ndwut ineot coism"

    const-string v1, "nusfmi   clerdwtalskhsuw e ed iCesttouqoot od tioetr fn"

    const-string v1, "d  oodoudrtol Co ntew  aste sficefws uuqiti  lneekohtmr"

    const-string v1, "Could not emit the first window due to lack of requests"

    invoke-direct {v0, v1}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    return-void
.end method

.method public run()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/k4$c;->D0:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/k4$c$c;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    shr-int/2addr v4, v2

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    invoke-direct {v1, v0, v2}, Lio/reactivex/internal/operators/flowable/k4$c$c;-><init>(Lio/reactivex/processors/g;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->u()V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method t(Lio/reactivex/processors/g;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/processors/g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x1

    const/4 v3, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/k4$c$c;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/k4$c$c;-><init>(Lio/reactivex/processors/g;Z)V

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->u()V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method u()V
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/k4$c;->E0:Ljava/util/List;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/4 v3, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    move v4, v3

    move v4, v3

    const/4 v11, 0x5

    move v4, v3

    :cond_0
    :goto_0
    const/4 v10, 0x1

    const/4 v11, 0x3

    iget-boolean v5, p0, Lio/reactivex/internal/operators/flowable/k4$c;->G0:Z

    const/4 v11, 0x0

    if-eqz v5, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/k4$c;->F0:Lja/d;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-interface {v1}, Lja/d;->cancel()V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->e()V

    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-interface {v0}, Lu7/o;->clear()V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-interface {v2}, Ljava/util/List;->clear()V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    return-void

    :cond_1
    const/4 v11, 0x4

    const/4 v10, 0x1

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v0}, Lu7/n;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-nez v6, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x5

    move v7, v3

    move v7, v3

    const/4 v11, 0x0

    move v7, v3

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    goto :goto_1

    :cond_2
    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v7, 0x0

    :goto_1
    const/4 v11, 0x1

    instance-of v8, v6, Lio/reactivex/internal/operators/flowable/k4$c$c;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-eqz v5, :cond_6

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-nez v7, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-eqz v8, :cond_6

    :cond_3
    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-interface {v0}, Lu7/o;->clear()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$c;->e()V

    const/4 v11, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    if-eqz v0, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_2
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v3, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x6

    check-cast v3, Lio/reactivex/processors/g;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v3, v0}, Lio/reactivex/processors/g;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    goto :goto_2

    :cond_4
    const/4 v10, 0x1

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_3
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-eqz v1, :cond_5

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    check-cast v1, Lio/reactivex/processors/g;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    goto :goto_3

    :cond_5
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-interface {v2}, Ljava/util/List;->clear()V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    return-void

    :cond_6
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v7, :cond_7

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    neg-int v4, v4

    const/4 v11, 0x7

    const/4 v10, 0x7

    invoke-virtual {p0, v4}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result v4

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-nez v4, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    return-void

    :cond_7
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz v8, :cond_c

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    check-cast v6, Lio/reactivex/internal/operators/flowable/k4$c$c;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-boolean v5, v6, Lio/reactivex/internal/operators/flowable/k4$c$c;->b:Z

    const/4 v11, 0x4

    if-eqz v5, :cond_b

    const/4 v10, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v5, :cond_8

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    goto/16 :goto_0

    :cond_8
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v5

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x1

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    cmp-long v7, v5, v7

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-eqz v7, :cond_a

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget v7, p0, Lio/reactivex/internal/operators/flowable/k4$c;->D0:I

    const/4 v11, 0x5

    invoke-static {v7}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v7

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-interface {v1, v7}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-wide v8, 0x7fffffffffffffffL

    const-wide v8, 0x7fffffffffffffffL

    const/4 v11, 0x2

    const-wide v8, 0x7fffffffffffffffL

    const-wide v8, 0x7fffffffffffffffL

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    cmp-long v5, v5, v8

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-eqz v5, :cond_9

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v11, 0x2

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p0, v5, v6}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_9
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/k4$c;->C0:Lio/reactivex/e0$c;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance v6, Lio/reactivex/internal/operators/flowable/k4$c$b;

    const/4 v10, 0x6

    shr-int/2addr v11, v10

    invoke-direct {v6, p0, v7}, Lio/reactivex/internal/operators/flowable/k4$c$b;-><init>(Lio/reactivex/internal/operators/flowable/k4$c;Lio/reactivex/processors/g;)V

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-wide v7, p0, Lio/reactivex/internal/operators/flowable/k4$c;->k0:J

    const/4 v11, 0x7

    const/4 v10, 0x3

    iget-object v9, p0, Lio/reactivex/internal/operators/flowable/k4$c;->B0:Ljava/util/concurrent/TimeUnit;

    const/4 v11, 0x0

    invoke-virtual {v5, v6, v7, v8, v9}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v10, 0x1

    and-int/2addr v11, v10

    goto/16 :goto_0

    :cond_a
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-instance v5, Lio/reactivex/exceptions/c;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string v6, "/otatbmdmuld t skras inn  cotiCoe wqeue/ w"

    const-string/jumbo v6, "tedm motwqforsn k/ui  si/we  oenu tlcCaadt"

    const/4 v11, 0x3

    const-string/jumbo v6, "uqecaCu r m//itd o afd liteosoekt wtuwsnn "

    const-string v6, "Can\'t emit window due to lack of requests"

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-direct {v5, v6}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-interface {v1, v5}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto/16 :goto_0

    :cond_b
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    iget-object v5, v6, Lio/reactivex/internal/operators/flowable/k4$c$c;->a:Lio/reactivex/processors/g;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-interface {v2, v5}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    iget-object v5, v6, Lio/reactivex/internal/operators/flowable/k4$c$c;->a:Lio/reactivex/processors/g;

    const/4 v11, 0x0

    invoke-virtual {v5}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v5

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz v5, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x4

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v5, :cond_0

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    iput-boolean v3, p0, Lio/reactivex/internal/operators/flowable/k4$c;->G0:Z

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_c
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_4
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v7, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    check-cast v7, Lio/reactivex/processors/g;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v7, v6}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto :goto_4
.end method
