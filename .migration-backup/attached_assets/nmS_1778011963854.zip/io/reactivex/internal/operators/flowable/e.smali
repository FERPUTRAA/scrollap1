.class public final Lio/reactivex/internal/operators/flowable/e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Iterable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/e$b;,
        Lio/reactivex/internal/operators/flowable/e$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/lang/Iterable<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e;->a:Lja/b;

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public iterator()Ljava/util/Iterator;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "TT;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance v0, Lio/reactivex/internal/operators/flowable/e$b;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0}, Lio/reactivex/internal/operators/flowable/e$b;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/e$a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/e;->a:Lja/b;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v1, v2, v0}, Lio/reactivex/internal/operators/flowable/e$a;-><init>(Lja/b;Lio/reactivex/internal/operators/flowable/e$b;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v1
.end method
