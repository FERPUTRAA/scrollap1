.class abstract Lio/reactivex/internal/operators/flowable/r2$c;
.super Lio/reactivex/internal/subscriptions/o;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/r2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/o;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4dc79ef2e0d16b40L


# instance fields
.field protected final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field protected final processor:Lio/reactivex/processors/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/processors/c<",
            "TU;>;"
        }
    .end annotation
.end field

.field private produced:J

.field protected final receiver:Lja/d;


# direct methods
.method constructor <init>(Lja/c;Lio/reactivex/processors/c;Lja/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lio/reactivex/processors/c<",
            "TU;>;",
            "Lja/d;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/o;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r2$c;->actual:Lja/c;

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/r2$c;->processor:Lio/reactivex/processors/c;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/r2$c;->receiver:Lja/d;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ si  @~1 @~t@K os/S~@~ @i@~@u@  cbof~  ~ db~nfl~~~@~ ~~b@o@ol@/ M~.mia@t ~r~@@ ~ ~ 4vo-y@~@@@o~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/o;->cancel()V

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->receiver:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public final f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x6

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->produced:J

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    add-long/2addr v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->produced:J

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->actual:Lja/c;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method protected final i(Ljava/lang/Object;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;)V"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->produced:J

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x6

    const-wide/16 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    cmp-long v4, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v4, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/r2$c;->produced:J

    const/4 v6, 0x0

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/subscriptions/o;->e(J)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->receiver:Lja/d;

    const/4 v5, 0x7

    move v6, v5

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v6, 0x1

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0, v1, v2}, Lja/d;->g(J)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r2$c;->processor:Lio/reactivex/processors/c;

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x5

    return-void
.end method

.method public final q(Lja/d;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method
