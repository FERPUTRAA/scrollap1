.class public final Lio/reactivex/internal/operators/flowable/h1$a;
.super Lio/reactivex/internal/subscriptions/c;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/c<",
        "Lio/reactivex/flowables/b<",
        "TK;TV;>;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field static final a:Ljava/lang/Object;

.field private static final serialVersionUID:J = -0x332f71b8460722ceL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-",
            "Lio/reactivex/flowables/b<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field

.field final bufferSize:I

.field final cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final delayError:Z

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final groupCount:Ljava/util/concurrent/atomic/AtomicInteger;

.field final groups:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Object;",
            "Lio/reactivex/internal/operators/flowable/h1$b<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field

.field final keySelector:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;+TK;>;"
        }
    .end annotation
.end field

.field outputFused:Z

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Lio/reactivex/flowables/b<",
            "TK;TV;>;>;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;

.field final valueSelector:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;+TV;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    sput-object v0, Lio/reactivex/internal/operators/flowable/h1$a;->a:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Lja/c;Lt7/o;Lt7/o;IZ)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/flowables/b<",
            "TK;TV;>;>;",
            "Lt7/o<",
            "-TT;+TK;>;",
            "Lt7/o<",
            "-TT;+TV;>;IZ)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/c;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groupCount:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h1$a;->keySelector:Lt7/o;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/h1$a;->valueSelector:Lt7/o;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput p4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->bufferSize:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    iput-boolean p5, p0, Lio/reactivex/internal/operators/flowable/h1$a;->delayError:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p1, p4}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~d biM~~f@ /i@lfc@~ ~ @@b~ ~i @~~@ ~ v oo@t~~ @ ~lK~@~~mtyr~ ~. s ~ @o -@@@@u@~1o4o@n~/oaS ~b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object p1, Lio/reactivex/internal/operators/flowable/h1$a;->a:Ljava/lang/Object;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    invoke-interface {v0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groupCount:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez p1, :cond_1

    const/4 v2, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x5

    invoke-virtual {p1}, Lio/reactivex/internal/queue/c;->clear()V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method c()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->outputFused:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->k()V

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->n()V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public cancel()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x6

    move v4, v3

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    shr-int/2addr v4, v2

    move v3, v2

    move v3, v2

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groupCount:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    :cond_0
    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method e(ZZLja/c;Lio/reactivex/internal/queue/c;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lja/c<",
            "*>;",
            "Lio/reactivex/internal/queue/c<",
            "*>;)Z"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {p4}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->delayError:Z

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz p1, :cond_4

    const/4 v3, 0x7

    if-eqz p2, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->error:Ljava/lang/Throwable;

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {p3}, Lja/c;->onComplete()V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v1

    :cond_2
    const/4 v3, 0x6

    if-eqz p1, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->error:Ljava/lang/Throwable;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p4}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v1

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p2, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p3}, Lja/c;->onComplete()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return v1

    :cond_4
    const/4 v2, 0x4

    move v3, v2

    const/4 p1, 0x0

    move v3, p1

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return p1
.end method

.method public f(Ljava/lang/Object;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->keySelector:Lt7/o;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v1, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v1, :cond_1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object v2, Lio/reactivex/internal/operators/flowable/h1$a;->a:Ljava/lang/Object;

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v3, Lio/reactivex/internal/operators/flowable/h1$b;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez v3, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h1$a;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-void

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget v3, p0, Lio/reactivex/internal/operators/flowable/h1$a;->bufferSize:I

    const/4 v6, 0x5

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->delayError:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v1, v3, p0, v4}, Lio/reactivex/internal/operators/flowable/h1$b;->Z7(Ljava/lang/Object;ILio/reactivex/internal/operators/flowable/h1$a;Z)Lio/reactivex/internal/operators/flowable/h1$b;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groupCount:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    goto :goto_1

    :cond_3
    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v1, 0x0

    :goto_1
    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/h1$a;->valueSelector:Lt7/o;

    const/4 v6, 0x2

    invoke-interface {v2, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v2, "uenmlu eeuerhS eclrvtnlrTteold "

    const-string/jumbo v2, "vesuTeenruruc Shelr d llnolteet"

    const/4 v6, 0x7

    const-string v2, "oldeorhcnaere ulSllteenv r utTu"

    const-string v2, "The valueSelector returned null"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Lio/reactivex/internal/operators/flowable/h1$b;->f(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v1, :cond_4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0, v3}, Lio/reactivex/internal/queue/c;->offer(Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->c()V

    :cond_4
    const/4 v5, 0x0

    const/4 v6, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/h1$a;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void

    :catchall_1
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/h1$a;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->c()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method k()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->actual:Lja/c;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v2, 0x1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h1$a;->cancelled:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->delayError:Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-nez v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->error:Ljava/lang/Throwable;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v4, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-interface {v1, v4}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x5

    invoke-interface {v1, v4}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v3, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->error:Ljava/lang/Throwable;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :cond_3
    invoke-interface {v1}, Lja/c;->onComplete()V

    :goto_0
    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    neg-int v2, v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez v2, :cond_0

    const/4 v6, 0x2

    return-void
.end method

.method public l(I)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    and-int/2addr p1, v0

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->outputFused:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p1
.end method

.method n()V
    .locals 15

    const/4 v14, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v14, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->actual:Lja/c;

    const/4 v14, 0x4

    const/4 v2, 0x1

    const/4 v14, 0x0

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :cond_0
    const/4 v14, 0x6

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x3

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    const/4 v14, 0x4

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    move-wide v8, v6

    :goto_0
    const/4 v14, 0x5

    cmp-long v10, v8, v4

    const/4 v14, 0x2

    if-eqz v10, :cond_4

    const/4 v14, 0x2

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v14, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x0

    check-cast v12, Lio/reactivex/flowables/b;

    const/4 v14, 0x4

    if-nez v12, :cond_1

    const/4 v14, 0x7

    move v13, v2

    move v13, v2

    move v13, v2

    move v13, v2

    const/4 v14, 0x4

    goto :goto_1

    :cond_1
    const/4 v14, 0x5

    const/4 v13, 0x0

    :goto_1
    invoke-virtual {p0, v11, v13, v1, v0}, Lio/reactivex/internal/operators/flowable/h1$a;->e(ZZLja/c;Lio/reactivex/internal/queue/c;)Z

    move-result v11

    const/4 v14, 0x1

    if-eqz v11, :cond_2

    const/4 v14, 0x2

    return-void

    :cond_2
    if-eqz v13, :cond_3

    const/4 v14, 0x1

    goto :goto_2

    :cond_3
    const/4 v14, 0x2

    invoke-interface {v1, v12}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v14, 0x5

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const/4 v14, 0x4

    add-long/2addr v8, v10

    const/4 v14, 0x5

    goto :goto_0

    :cond_4
    :goto_2
    const/4 v14, 0x7

    if-nez v10, :cond_5

    const/4 v14, 0x6

    iget-boolean v10, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v14, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v11

    const/4 v14, 0x7

    invoke-virtual {p0, v10, v11, v1, v0}, Lio/reactivex/internal/operators/flowable/h1$a;->e(ZZLja/c;Lio/reactivex/internal/queue/c;)Z

    move-result v10

    const/4 v14, 0x1

    if-eqz v10, :cond_5

    const/4 v14, 0x0

    return-void

    :cond_5
    const/4 v14, 0x3

    cmp-long v6, v8, v6

    const/4 v14, 0x7

    if-eqz v6, :cond_7

    const/4 v14, 0x7

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const/4 v14, 0x1

    cmp-long v4, v4, v6

    const/4 v14, 0x3

    if-eqz v4, :cond_6

    const/4 v14, 0x6

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x7

    neg-long v5, v8

    const/4 v14, 0x5

    invoke-virtual {v4, v5, v6}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    :cond_6
    const/4 v14, 0x4

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v14, 0x7

    invoke-interface {v4, v8, v9}, Lja/d;->g(J)V

    :cond_7
    const/4 v14, 0x2

    neg-int v3, v3

    const/4 v14, 0x1

    invoke-virtual {p0, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const/4 v14, 0x3

    if-nez v3, :cond_0

    const/4 v14, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v1, Lio/reactivex/internal/operators/flowable/h1$b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/operators/flowable/h1$b;->onComplete()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->c()V

    :cond_1
    const/4 v3, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v1, Lio/reactivex/internal/operators/flowable/h1$b;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Lio/reactivex/internal/operators/flowable/h1$b;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->groups:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Map;->clear()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->error:Ljava/lang/Throwable;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->done:Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->c()V

    const/4 v3, 0x2

    return-void
.end method

.method public bridge synthetic poll()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h1$a;->s()Lio/reactivex/flowables/b;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h1$a;->s:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->actual:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x3

    iget v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->bufferSize:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    int-to-long v0, v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public s()Lio/reactivex/flowables/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/flowables/b<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h1$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast v0, Lio/reactivex/flowables/b;

    const/4 v2, 0x2

    return-object v0
.end method
