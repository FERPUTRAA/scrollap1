.class public final Lio/reactivex/internal/operators/flowable/n2;
.super Lio/reactivex/f0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "TR;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TR;>;"
        }
    .end annotation
.end field

.field final c:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TR;-TT;TR;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/util/concurrent/Callable;Lt7/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/Callable<",
            "TR;>;",
            "Lt7/c<",
            "TR;-TT;TR;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n2;->a:Lja/b;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n2;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/n2;->c:Lt7/c;

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TR;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n2;->b:Ljava/util/concurrent/Callable;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v1, " dsrpTurindls eeteuesl Snlhuruvee e la"

    const-string v1, "Shslnu nuep vslpltreueereuiaerddl   eT"

    const/4 v5, 0x1

    const-string v1, "The seedSupplier returned a null value"

    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n2;->a:Lja/b;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v2, Lio/reactivex/internal/operators/flowable/m2$a;

    const/4 v5, 0x4

    const/4 v4, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/n2;->c:Lt7/c;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v2, p1, v3, v0}, Lio/reactivex/internal/operators/flowable/m2$a;-><init>(Lio/reactivex/h0;Lt7/c;Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->o(Ljava/lang/Throwable;Lio/reactivex/h0;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method
