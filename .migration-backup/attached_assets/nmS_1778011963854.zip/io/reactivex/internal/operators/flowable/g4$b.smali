.class final Lio/reactivex/internal/operators/flowable/g4$b;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/g4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x21b3dc811227de88L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final bufferSize:I

.field volatile cancelled:Z

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final firstRequest:Ljava/util/concurrent/atomic/AtomicBoolean;

.field index:J

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field produced:J

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Lio/reactivex/processors/g<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;

.field final size:J

.field final skip:J

.field final windows:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Lio/reactivex/processors/g<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final wip:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lja/c;JJI)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;JJI)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/g4$b;->size:J

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->skip:J

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p1, p6}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x3

    new-instance p1, Ljava/util/ArrayDeque;

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->firstRequest:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x0

    move v2, v1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput p6, p0, Lio/reactivex/internal/operators/flowable/g4$b;->bufferSize:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method a(ZZLja/c;Lio/reactivex/internal/queue/c;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lja/c<",
            "*>;",
            "Lio/reactivex/internal/queue/c<",
            "*>;)Z"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Ss n.@@o@ ii ~ @  @  ~/o~~@~ lo4 -~~o@o ~1 ~i/@m @~ab~lb@@ ~~v@Kty @M b~@dc~sfou~~~r@~f@~@@@@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->cancelled:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {p4}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->error:Ljava/lang/Throwable;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p4}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p2, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {p3}, Lja/c;->onComplete()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return p1
.end method

.method b()V
    .locals 15

    const/4 v14, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v14, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v14, 0x5

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v14, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->actual:Lja/c;

    const/4 v14, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v14, 0x2

    const/4 v2, 0x1

    const/4 v14, 0x3

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :cond_1
    const/4 v14, 0x0

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x5

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    const/4 v14, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    move-wide v8, v6

    :goto_0
    const/4 v14, 0x6

    cmp-long v10, v8, v4

    const/4 v14, 0x6

    if-eqz v10, :cond_5

    const/4 v14, 0x6

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x6

    check-cast v12, Lio/reactivex/processors/g;

    const/4 v14, 0x0

    if-nez v12, :cond_2

    const/4 v14, 0x0

    move v13, v2

    move v13, v2

    move v13, v2

    const/4 v14, 0x7

    goto :goto_1

    :cond_2
    const/4 v14, 0x3

    const/4 v13, 0x0

    :goto_1
    const/4 v14, 0x6

    invoke-virtual {p0, v11, v13, v0, v1}, Lio/reactivex/internal/operators/flowable/g4$b;->a(ZZLja/c;Lio/reactivex/internal/queue/c;)Z

    move-result v11

    const/4 v14, 0x7

    if-eqz v11, :cond_3

    const/4 v14, 0x6

    return-void

    :cond_3
    const/4 v14, 0x2

    if-eqz v13, :cond_4

    const/4 v14, 0x6

    goto :goto_2

    :cond_4
    invoke-interface {v0, v12}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v14, 0x5

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const/4 v14, 0x0

    add-long/2addr v8, v10

    const/4 v14, 0x7

    goto :goto_0

    :cond_5
    :goto_2
    const/4 v14, 0x2

    if-nez v10, :cond_6

    const/4 v14, 0x3

    iget-boolean v10, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v11

    const/4 v14, 0x3

    invoke-virtual {p0, v10, v11, v0, v1}, Lio/reactivex/internal/operators/flowable/g4$b;->a(ZZLja/c;Lio/reactivex/internal/queue/c;)Z

    move-result v10

    const/4 v14, 0x3

    if-eqz v10, :cond_6

    return-void

    :cond_6
    const/4 v14, 0x0

    cmp-long v6, v8, v6

    const/4 v14, 0x0

    if-eqz v6, :cond_7

    const/4 v14, 0x5

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const/4 v14, 0x4

    cmp-long v4, v4, v6

    const/4 v14, 0x0

    if-eqz v4, :cond_7

    const/4 v14, 0x4

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v14, 0x4

    neg-long v5, v8

    const/4 v14, 0x2

    invoke-virtual {v4, v5, v6}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    :cond_7
    const/4 v14, 0x2

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v14, 0x0

    neg-int v3, v3

    const/4 v14, 0x4

    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const/4 v14, 0x7

    if-nez v3, :cond_1

    const/4 v14, 0x6

    return-void
.end method

.method public cancel()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->cancelled:Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, v2, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g4$b;->run()V

    :cond_0
    const/4 v4, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v0, :cond_0

    const/4 v8, 0x1

    shr-int/2addr v9, v8

    return-void

    :cond_0
    const/4 v9, 0x3

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->index:J

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    cmp-long v4, v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    if-nez v4, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->cancelled:Z

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-nez v4, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->bufferSize:I

    const/4 v9, 0x7

    invoke-static {v4, p0}, Lio/reactivex/processors/g;->g8(ILjava/lang/Runnable;)Lio/reactivex/processors/g;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v5, v4}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/g4$b;->queue:Lio/reactivex/internal/queue/c;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v5, v4}, Lio/reactivex/internal/queue/c;->offer(Ljava/lang/Object;)Z

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g4$b;->b()V

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v9, 0x3

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    add-long/2addr v0, v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v6}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz v7, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    check-cast v7, Lja/a;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {v7, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_0

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-wide v6, p0, Lio/reactivex/internal/operators/flowable/g4$b;->produced:J

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    add-long/2addr v6, v4

    const/4 v9, 0x6

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->size:J

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    cmp-long p1, v6, v4

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez p1, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->skip:J

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    sub-long/2addr v6, v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    iput-wide v6, p0, Lio/reactivex/internal/operators/flowable/g4$b;->produced:J

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v8, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    check-cast p1, Lja/a;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz p1, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-interface {p1}, Lja/c;->onComplete()V

    const/4 v9, 0x4

    const/4 v8, 0x6

    goto :goto_1

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput-wide v6, p0, Lio/reactivex/internal/operators/flowable/g4$b;->produced:J

    :cond_4
    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/g4$b;->skip:J

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    cmp-long p1, v0, v4

    const/4 v9, 0x4

    const/4 v8, 0x4

    if-nez p1, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/g4$b;->index:J

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    goto :goto_2

    :cond_5
    const/4 v8, 0x4

    const/4 v9, 0x1

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->index:J

    :goto_2
    const/4 v9, 0x3

    const/4 v8, 0x7

    return-void
.end method

.method public g(J)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x2

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v5, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->firstRequest:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->firstRequest:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x0

    move v4, v1

    move v4, v1

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->skip:J

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    sub-long/2addr p1, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->size:J

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->c(JJ)J

    move-result-wide p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->s:Lja/d;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    move v5, v4

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->skip:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->s:Lja/d;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g4$b;->b()V

    :cond_1
    const/4 v5, 0x0

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v1, Lja/a;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v1}, Lja/c;->onComplete()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    move v3, v2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g4$b;->b()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v1, Lja/a;

    const/4 v3, 0x3

    invoke-interface {v1, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->windows:Ljava/util/ArrayDeque;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->clear()V

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->error:Ljava/lang/Throwable;

    const/4 v2, 0x4

    move v3, v2

    const/4 p1, 0x1

    move v3, p1

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->done:Z

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g4$b;->b()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->s:Lja/d;

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->s:Lja/d;

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$b;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public run()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$b;->s:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
