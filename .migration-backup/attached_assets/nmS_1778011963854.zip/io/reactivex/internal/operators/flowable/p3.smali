.class public final Lio/reactivex/internal/operators/flowable/p3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/p3$a;,
        Lio/reactivex/internal/operators/flowable/p3$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TR;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;+",
            "Lja/b<",
            "+TR;>;>;"
        }
    .end annotation
.end field

.field final d:I

.field final e:Z


# direct methods
.method public constructor <init>(Lja/b;Lt7/o;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/o<",
            "-TT;+",
            "Lja/b<",
            "+TR;>;>;IZ)V"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/p3;->c:Lt7/o;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p3, p0, Lio/reactivex/internal/operators/flowable/p3;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-boolean p4, p0, Lio/reactivex/internal/operators/flowable/p3;->e:Z

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " mstio4l~@cs~ vo@@~ @nb @ S@/i~@@@@~M~ to~ ~ f@ f ~~~-.@K@l boo@~1~@d~~o b y@ ~~@~@@ua/ r ~~~@~ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p3;->c:Lt7/o;

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-static {v0, p1, v1}, Lio/reactivex/internal/operators/flowable/y2;->b(Lja/b;Lja/c;Lt7/o;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v1, Lio/reactivex/internal/operators/flowable/p3$b;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/p3;->c:Lt7/o;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v3, p0, Lio/reactivex/internal/operators/flowable/p3;->d:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/p3;->e:Z

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v1, p1, v2, v3, v4}, Lio/reactivex/internal/operators/flowable/p3$b;-><init>(Lja/c;Lt7/o;IZ)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void
.end method
