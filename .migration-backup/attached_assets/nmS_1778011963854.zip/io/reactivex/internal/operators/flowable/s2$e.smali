.class final Lio/reactivex/internal/operators/flowable/s2$e;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/s2;->g8(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;I)Lio/reactivex/flowables/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lio/reactivex/internal/operators/flowable/s2$j<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:J

.field final synthetic c:Ljava/util/concurrent/TimeUnit;

.field final synthetic d:Lio/reactivex/e0;


# direct methods
.method constructor <init>(IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x6

    iput p1, p0, Lio/reactivex/internal/operators/flowable/s2$e;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/s2$e;->b:J

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/s2$e;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/s2$e;->d:Lio/reactivex/e0;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Lio/reactivex/internal/operators/flowable/s2$j;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    new-instance v6, Lio/reactivex/internal/operators/flowable/s2$l;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget v1, p0, Lio/reactivex/internal/operators/flowable/s2$e;->a:I

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/s2$e;->b:J

    const/4 v8, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/s2$e;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x2

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/s2$e;->d:Lio/reactivex/e0;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lio/reactivex/internal/operators/flowable/s2$l;-><init>(IJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    return-object v6
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/s2$e;->a()Lio/reactivex/internal/operators/flowable/s2$j;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method
