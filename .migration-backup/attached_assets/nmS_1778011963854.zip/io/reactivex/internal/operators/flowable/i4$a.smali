.class final Lio/reactivex/internal/operators/flowable/i4$a;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TV;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/i4$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/i4$c<",
            "TT;*TV;>;"
        }
    .end annotation
.end field

.field final c:Lio/reactivex/processors/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/processors/g<",
            "TT;>;"
        }
    .end annotation
.end field

.field d:Z


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/i4$c;Lio/reactivex/processors/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/i4$c<",
            "TT;*TV;>;",
            "Lio/reactivex/processors/g<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$a;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i4$a;->c:Lio/reactivex/processors/g;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "f1sf~~ //~ i Soo@@lc @@b~@@    ~tv~~@ @@m@~~~~b a~sKdt4o~~ ~@oo@@@.@nM~~o@@l@~~ by@  i i u~ -~@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/i4$a;->d:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/i4$a;->d:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0}, Lio/reactivex/subscribers/b;->b()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$a;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1, p0}, Lio/reactivex/internal/operators/flowable/i4$c;->t(Lio/reactivex/internal/operators/flowable/i4$a;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$a;->d:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$a;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$a;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v1, 0x2

    or-int/2addr v2, v1

    invoke-virtual {v0, p0}, Lio/reactivex/internal/operators/flowable/i4$c;->t(Lio/reactivex/internal/operators/flowable/i4$a;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$a;->d:Z

    const/4 v1, 0x7

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$a;->d:Z

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$a;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/i4$c;->v(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method
