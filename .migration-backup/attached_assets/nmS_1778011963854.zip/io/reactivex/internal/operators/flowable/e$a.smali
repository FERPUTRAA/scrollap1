.class final Lio/reactivex/internal/operators/flowable/e$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation


# instance fields
.field private final a:Lio/reactivex/internal/operators/flowable/e$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/e$b<",
            "TT;>;"
        }
    .end annotation
.end field

.field private final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field private c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field private d:Z

.field private e:Z

.field private f:Ljava/lang/Throwable;

.field private g:Z


# direct methods
.method constructor <init>(Lja/b;Lio/reactivex/internal/operators/flowable/e$b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;",
            "Lio/reactivex/internal/operators/flowable/e$b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->d:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->e:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e$a;->b:Lja/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/e$a;->a:Lio/reactivex/internal/operators/flowable/e$b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method private a()Z
    .locals 6

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s@   @~~ib~i ~~@~fM~/  cl@ ~o@~@~ b~.b @~ s@~oo~@m~f~v@i @~t4t@  oooKd  l1@~@~@~-y ~/@@r @ua@n"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->g:Z

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput-boolean v1, p0, Lio/reactivex/internal/operators/flowable/e$a;->g:Z

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->a:Lio/reactivex/internal/operators/flowable/e$b;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/e$b;->h()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->b:Lja/b;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v0}, Lio/reactivex/k;->A2(Lja/b;)Lio/reactivex/k;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Lio/reactivex/k;->l3()Lio/reactivex/k;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/e$a;->a:Lio/reactivex/internal/operators/flowable/e$b;

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Lio/reactivex/k;->j(Lja/c;)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->a:Lio/reactivex/internal/operators/flowable/e$b;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/e$b;->i()Lio/reactivex/w;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Lio/reactivex/w;->h()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    iput-boolean v3, p0, Lio/reactivex/internal/operators/flowable/e$a;->e:Z

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Lio/reactivex/w;->e()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->c:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-boolean v3, p0, Lio/reactivex/internal/operators/flowable/e$a;->d:Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Lio/reactivex/w;->f()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v3

    :cond_2
    const/4 v5, 0x3

    invoke-virtual {v0}, Lio/reactivex/w;->g()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Lio/reactivex/w;->d()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->f:Ljava/lang/Throwable;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    throw v0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v1, "o umcren d ohhsrlehta"

    const-string v1, "rdsato  chhlrn eSuhoe"

    const/4 v5, 0x7

    const-string v1, "ahSroteoehcn uoehldr "

    const-string v1, "Should not reach here"

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw v0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/e$a;->a:Lio/reactivex/internal/operators/flowable/e$b;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1}, Lio/reactivex/subscribers/b;->e()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->f:Ljava/lang/Throwable;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v5, 0x5

    throw v0
.end method


# virtual methods
.method public hasNext()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->f:Ljava/lang/Throwable;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->d:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->e:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0}, Lio/reactivex/internal/operators/flowable/e$a;->a()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v1

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    throw v0
.end method

.method public next()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->f:Ljava/lang/Throwable;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/e$a;->hasNext()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x1

    move v3, v0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->e:Z

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e$a;->c:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "eNe mbel mntrsme"

    const-string v1, "etnmesl mN eeorm"

    const/4 v3, 0x1

    const-string v1, "e omelueNsmoetnr"

    const-string v1, "No more elements"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    throw v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw v0
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "a oyoRo anrttelred"

    const/4 v3, 0x5

    const-string v1, "Rtrteaopaiorn  led"

    const-string v1, "Read only iterator"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw v0
.end method
