.class final Lio/reactivex/internal/operators/flowable/g1$a;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lio/reactivex/j;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/g1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "S:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lio/reactivex/j<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x68ffc50b57428478L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final disposeState:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TS;>;"
        }
    .end annotation
.end field

.field final generator:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TS;-",
            "Lio/reactivex/j<",
            "TT;>;TS;>;"
        }
    .end annotation
.end field

.field hasNext:Z

.field state:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TS;"
        }
    .end annotation
.end field

.field terminate:Z


# direct methods
.method constructor <init>(Lja/c;Lt7/c;Lt7/g;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/c<",
            "TS;-",
            "Lio/reactivex/j<",
            "TT;>;TS;>;",
            "Lt7/g<",
            "-TS;>;TS;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g1$a;->actual:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/g1$a;->generator:Lt7/c;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/g1$a;->disposeState:Lt7/g;

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method private e(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TS;)V"
        }
    .end annotation

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s Mf~ .~s@ @vu~~@~4~@o @~ ~bf@tlcoi @ @ ba~y@~t@~ -@o@/@K ~@mb ~ oni~~S@@~@ / ~i@@@ d ~1o~lr~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->disposeState:Lt7/g;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->cancelled:Z

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->cancelled:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0, v0, v1}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x0

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lio/reactivex/internal/operators/flowable/g1$a;->e(Ljava/lang/Object;)V

    :cond_0
    const/4 v5, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->terminate:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-nez v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->hasNext:Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v1, 0x2

    const/4 v1, 0x2

    const-string v0, "clsna n ttgdotharlr exyee eN ntnriliadu ees"

    const/4 v2, 0x7

    const-string/jumbo v0, "tremnde sottltnecgheryr aaleN dn auxli ine "

    const-string v0, "onNext already called in this generate turn"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/g1$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, " tnmoe nsu lge. .NrhrldanlnspNanuaelaaio llo2osw usnrorde.a trulxacyololv det e lte cle e wx"

    const-string v0, "nolmord reaasruetvewlr oldsin lanNNstlaoxtw eascngap elhu nx 2ey orl .auln.. e ull lcedeot  "

    const/4 v2, 0x2

    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/g1$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->hasNext:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->actual:Lja/c;

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_2
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public g(J)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-nez v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide v0

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    cmp-long v0, v0, v2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz v0, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    return-void

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/g1$a;->generator:Lt7/c;

    :cond_2
    move-wide v4, v2

    :cond_3
    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    cmp-long v6, v4, p1

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-eqz v6, :cond_6

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-boolean v6, p0, Lio/reactivex/internal/operators/flowable/g1$a;->cancelled:Z

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v7, 0x0

    move v10, v7

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    if-eqz v6, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    iput-object v7, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {p0, v0}, Lio/reactivex/internal/operators/flowable/g1$a;->e(Ljava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    return-void

    :cond_4
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v6, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput-boolean v6, p0, Lio/reactivex/internal/operators/flowable/g1$a;->hasNext:Z

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v6, 0x1

    :try_start_0
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-interface {v1, v0, p0}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-boolean v8, p0, Lio/reactivex/internal/operators/flowable/g1$a;->terminate:Z

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eqz v8, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    iput-boolean v6, p0, Lio/reactivex/internal/operators/flowable/g1$a;->cancelled:Z

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    iput-object v7, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-direct {p0, v0}, Lio/reactivex/internal/operators/flowable/g1$a;->e(Ljava/lang/Object;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v10, 0x0

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x3

    add-long/2addr v4, v6

    const/4 v10, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    iput-boolean v6, p0, Lio/reactivex/internal/operators/flowable/g1$a;->cancelled:Z

    const/4 v9, 0x2

    move v10, v9

    iput-object v7, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/g1$a;->onError(Ljava/lang/Throwable;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {p0, v0}, Lio/reactivex/internal/operators/flowable/g1$a;->e(Ljava/lang/Object;)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-void

    :cond_6
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    cmp-long v6, v4, p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-nez v6, :cond_3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->state:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    neg-long p1, v4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    cmp-long v4, p1, v2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-nez v4, :cond_2

    const/4 v10, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->terminate:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->terminate:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->actual:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->terminate:Z

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "lrniybu .cladwooue o .r ndreir ans  o owodlvllersxru osllrgln eentolreala esa lEu c tp.naNtha"

    const-string v0, "nalvo ctwosrdealodEu.spod a rxenlnelor n loiasrnlr eoe sr ene leaar .ity lga.uulw Nrh tu cllo"

    const/4 v2, 0x2

    const-string v0, " eh lounal e sEu l.a lrao lsdirteN nolvilraylrsgerexnasplcroawda loo 2.trl uctenrwe no du .ue"

    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    move v1, v0

    move v1, v0

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->terminate:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1$a;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method
