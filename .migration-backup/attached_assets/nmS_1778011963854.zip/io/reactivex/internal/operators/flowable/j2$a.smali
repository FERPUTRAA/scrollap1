.class abstract Lio/reactivex/internal/operators/flowable/j2$a;
.super Lio/reactivex/internal/subscriptions/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/internal/subscriptions/d<",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x1f442a7d211232e5L


# instance fields
.field volatile cancelled:Z

.field final end:J

.field index:J


# direct methods
.method constructor <init>(JJ)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/d;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-wide p3, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method abstract a()V
.end method

.method public final b()Ljava/lang/Long;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " Ks i@  - soy@@l~ @ tS ~fb@  r1~~oa@@f~o~@ ~@ ~~/~~ ~l@~/o@.m~td~i@ ~@co@~  @~@n~b4Mbi@o@v ~@~@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v5, 0x6

    const/4 v4, 0x4

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    cmp-long v2, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    return-object v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    add-long/2addr v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v0
.end method

.method abstract c(J)V
.end method

.method public final cancel()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public final clear()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public final g(J)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    cmp-long v0, p1, v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j2$a;->a()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/j2$a;->c(J)V

    :cond_1
    :goto_0
    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void
.end method

.method public final isEmpty()Z
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    cmp-long v0, v0, v2

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v0
.end method

.method public final l(I)I
    .locals 2

    const/4 v1, 0x3

    and-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method public bridge synthetic poll()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j2$a;->b()Ljava/lang/Long;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method
