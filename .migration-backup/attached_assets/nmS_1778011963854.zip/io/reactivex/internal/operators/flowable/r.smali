.class public final Lio/reactivex/internal/operators/flowable/r;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/r$b;,
        Lio/reactivex/internal/operators/flowable/r$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lio/reactivex/internal/operators/flowable/r$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/r$a<",
            "TT;>;"
        }
    .end annotation
.end field

.field final d:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Lio/reactivex/k;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/k<",
            "TT;>;I)V"
        }
    .end annotation

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v2, 0x0

    invoke-direct {v0, p1, p2}, Lio/reactivex/internal/operators/flowable/r$a;-><init>(Lio/reactivex/k;I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~sM oi~.~1~~yK~d@~c   bo~@  o~ ~bf@S@~i i~t@~~ t@l@a~@~~s@@@~ @b   /-@ m@@~@rf/~v4o lu@~@@ on o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, p1, v1}, Lio/reactivex/internal/operators/flowable/r$b;-><init>(Lja/c;Lio/reactivex/internal/operators/flowable/r$a;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Lio/reactivex/internal/operators/flowable/r$a;->e(Lio/reactivex/internal/operators/flowable/r$b;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/r$a;->g()V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method Y7()I
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/util/m;->c()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method Z7()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/r$a;->h:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast v0, [Lio/reactivex/internal/operators/flowable/r$b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    array-length v0, v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method a8()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r;->c:Lio/reactivex/internal/operators/flowable/r$a;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, v0, Lio/reactivex/internal/operators/flowable/r$a;->i:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    return v0
.end method
