.class final Lio/reactivex/internal/operators/flowable/i2$b;
.super Lio/reactivex/internal/operators/flowable/i2$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x23e7f25903d0c345L


# instance fields
.field final actual:Lu7/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/a<",
            "-",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lu7/a;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-",
            "Ljava/lang/Integer;",
            ">;II)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p2, p3}, Lio/reactivex/internal/operators/flowable/i2$a;-><init>(II)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i2$b;->actual:Lu7/a;

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method


# virtual methods
.method a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ sait @~~t~s~o~iyn1o@ o @@/@ ~Ki~@forc@@v @M~o/-~ @~ ~~@    fm So@d@.@~~  b@b@~4ub~ l~~@@ @l~~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->end:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i2$b;->actual:Lu7/a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget v2, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eq v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/i2$a;->cancelled:Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v1, v3}, Lu7/a;->o(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->cancelled:Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v4, 0x6

    move v5, v4

    invoke-interface {v1}, Lja/c;->onComplete()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void
.end method

.method c(J)V
    .locals 11

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget v0, p0, Lio/reactivex/internal/operators/flowable/i2$a;->end:I

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/i2$b;->actual:Lu7/a;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    :cond_0
    move-wide v5, v3

    :cond_1
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    cmp-long v7, v5, p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz v7, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eq v1, v0, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-boolean v7, p0, Lio/reactivex/internal/operators/flowable/i2$a;->cancelled:Z

    const/4 v10, 0x3

    if-eqz v7, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    invoke-interface {v2, v7}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result v7

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v7, :cond_3

    const/4 v10, 0x6

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v10, 0x4

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    add-long/2addr v5, v7

    :cond_3
    const/4 v10, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto :goto_0

    :cond_4
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-ne v1, v0, :cond_6

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->cancelled:Z

    const/4 v10, 0x2

    const/4 v9, 0x6

    if-nez p1, :cond_5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v2}, Lja/c;->onComplete()V

    :cond_5
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    return-void

    :cond_6
    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    cmp-long v7, v5, p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-nez v7, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    iput v1, p0, Lio/reactivex/internal/operators/flowable/i2$a;->index:I

    const/4 v10, 0x3

    neg-long p1, v5

    const/4 v10, 0x2

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    cmp-long v5, p1, v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-nez v5, :cond_0

    const/4 v9, 0x2

    and-int/2addr v10, v9

    return-void
.end method
