.class abstract Lio/reactivex/internal/operators/flowable/d1$a;
.super Lio/reactivex/internal/subscriptions/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/d1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/d<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x1f442a7d211232e5L


# instance fields
.field volatile cancelled:Z

.field it:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "+TT;>;"
        }
    .end annotation
.end field

.field once:Z


# direct methods
.method constructor <init>(Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Iterator<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/d;-><init>()V

    const/4 v0, 0x3

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method abstract a()V
.end method

.method abstract b(J)V
.end method

.method public final cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "r@sM~~@@Si~ @~@/~fv~@@ @l~o~ @.ts n~~~~@ io~@~ic1~  ~b@K@foo  @/@ al~@ y ~~tm b do@b -o4~@@u @ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v2, 0x3

    return-void
.end method

.method public final clear()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v2, 0x3

    return-void
.end method

.method public final g(J)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    move v5, v4

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    cmp-long v0, p1, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/d1$a;->a()V

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/d1$a;->b(J)V

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method public final isEmpty()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public final l(I)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    and-int/lit8 p1, p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p1
.end method

.method public final poll()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x7

    move v4, v3

    return-object v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/d1$a;->once:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez v2, :cond_1

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->once:Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v1

    :cond_2
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v3, 0x4

    move v4, v3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v1, "lelm(tn nlaev )a.Itras rnueott duerxe"

    const-string/jumbo v1, "ttsa  o.a( edlIveennuxrt)rnelr atuerl"

    const/4 v4, 0x5

    const-string v1, "nnelode  lurttrrte(ue xv aetr)nouaIal"

    const-string v1, "Iterator.next() returned a null value"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method
