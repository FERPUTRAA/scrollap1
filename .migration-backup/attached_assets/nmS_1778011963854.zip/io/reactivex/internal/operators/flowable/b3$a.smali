.class final Lio/reactivex/internal/operators/flowable/b3$a;
.super Lio/reactivex/internal/subscriptions/f;

# interfaces
.implements Lio/reactivex/internal/operators/flowable/b3$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/b3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/f<",
        "Ljava/lang/Boolean;",
        ">;",
        "Lio/reactivex/internal/operators/flowable/b3$b;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x55bcb3aaa8a061f8L


# instance fields
.field final comparer:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-TT;-TT;>;"
        }
    .end annotation
.end field

.field final error:Lio/reactivex/internal/util/c;

.field final first:Lio/reactivex/internal/operators/flowable/b3$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/b3$c<",
            "TT;>;"
        }
    .end annotation
.end field

.field final second:Lio/reactivex/internal/operators/flowable/b3$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/b3$c<",
            "TT;>;"
        }
    .end annotation
.end field

.field v1:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field v2:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field final wip:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lja/c;ILt7/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Boolean;",
            ">;I",
            "Lt7/d<",
            "-TT;-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/b3$a;->comparer:Lt7/d;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x5

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    new-instance p1, Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1, p0, p2}, Lio/reactivex/internal/operators/flowable/b3$c;-><init>(Lio/reactivex/internal/operators/flowable/b3$b;I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    new-instance p1, Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    invoke-direct {p1, p0, p2}, Lio/reactivex/internal/operators/flowable/b3$c;-><init>(Lio/reactivex/internal/operators/flowable/b3$b;I)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v1, 0x7

    new-instance p1, Lio/reactivex/internal/util/c;

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-direct {p1}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public b(Ljava/lang/Throwable;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os o@@o~ s -~bm~@vt@ b~ @~@r/ .@no@~~M @~/caf~@i  4 l ~S@@~ 1~~ @Ko~  @ui@@do@~@~~~l@~  bt~~if~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->c()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public c()V
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-eqz v0, :cond_0

    const/4 v11, 0x7

    return-void

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v0, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    move v1, v0

    move v1, v0

    const/4 v11, 0x2

    move v1, v0

    move v1, v0

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-object v2, v2, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    iget-object v3, v3, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-eqz v2, :cond_c

    const/4 v11, 0x4

    if-eqz v3, :cond_c

    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/subscriptions/f;->e()Z

    move-result v4

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-eqz v4, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    return-void

    :cond_2
    const/4 v11, 0x7

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x6

    check-cast v4, Ljava/lang/Throwable;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-eqz v4, :cond_3

    const/4 v11, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v11, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v10, 0x5

    move v11, v10

    invoke-virtual {v1}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    return-void

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-boolean v4, v4, Lio/reactivex/internal/operators/flowable/b3$c;->done:Z

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/b3$a;->v1:Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-nez v5, :cond_4

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-interface {v2}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v5
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    iput-object v5, p0, Lio/reactivex/internal/operators/flowable/b3$a;->v1:Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x2

    invoke-virtual {v1, v0}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x4

    invoke-virtual {v1}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x0

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    return-void

    :cond_4
    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    const/4 v6, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-nez v5, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x2

    move v7, v0

    move v7, v0

    const/4 v11, 0x5

    move v7, v0

    move v7, v0

    const/4 v10, 0x0

    const/4 v10, 0x6

    goto :goto_2

    :cond_5
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    move v7, v6

    move v7, v6

    const/4 v11, 0x0

    move v7, v6

    move v7, v6

    :goto_2
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget-object v8, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-boolean v8, v8, Lio/reactivex/internal/operators/flowable/b3$c;->done:Z

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget-object v9, p0, Lio/reactivex/internal/operators/flowable/b3$a;->v2:Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-nez v9, :cond_6

    :try_start_1
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-interface {v3}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v9
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v11, 0x2

    const/4 v10, 0x0

    iput-object v9, p0, Lio/reactivex/internal/operators/flowable/b3$a;->v2:Ljava/lang/Object;

    const/4 v10, 0x7

    or-int/2addr v11, v10

    goto :goto_3

    :catchall_1
    move-exception v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v10, 0x3

    move v11, v10

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v1, v0}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    return-void

    :cond_6
    :goto_3
    const/4 v10, 0x4

    move v11, v10

    if-nez v9, :cond_7

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    move v6, v0

    move v6, v0

    :cond_7
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eqz v4, :cond_8

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-eqz v8, :cond_8

    const/4 v11, 0x2

    if-eqz v7, :cond_8

    const/4 v11, 0x1

    if-eqz v6, :cond_8

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    return-void

    :cond_8
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v4, :cond_9

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v8, :cond_9

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eq v7, v6, :cond_9

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v10, 0x5

    const/4 v11, 0x6

    return-void

    :cond_9
    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-nez v7, :cond_e

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v6, :cond_a

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    goto/16 :goto_4

    :cond_a
    :try_start_2
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->comparer:Lt7/d;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v4, v5, v9}, Lt7/d;->test(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v11, 0x7

    const/4 v10, 0x6

    if-nez v4, :cond_b

    const/4 v11, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    return-void

    :cond_b
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    iput-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->v1:Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    iput-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->v2:Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v4}, Lio/reactivex/internal/operators/flowable/b3$c;->c()V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v4}, Lio/reactivex/internal/operators/flowable/b3$c;->c()V

    const/4 v10, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    goto/16 :goto_0

    :catchall_2
    move-exception v0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v1, v0}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v1}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    return-void

    :cond_c
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/subscriptions/f;->e()Z

    move-result v2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v2, :cond_d

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x7

    const/4 v10, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v11, 0x2

    const/4 v10, 0x2

    return-void

    :cond_d
    const/4 v11, 0x7

    const/4 v10, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x4

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    check-cast v2, Ljava/lang/Throwable;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v2, :cond_e

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b3$a;->n()V

    const/4 v10, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    return-void

    :cond_e
    :goto_4
    const/4 v11, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/b3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v11, 0x5

    neg-int v1, v1

    const/4 v10, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v2, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-nez v1, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/f;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method n()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->a()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/b3$c;->b()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method s(Lja/b;Lja/b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$a;->first:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$a;->second:Lio/reactivex/internal/operators/flowable/b3$c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {p2, p1}, Lja/b;->j(Lja/c;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method
