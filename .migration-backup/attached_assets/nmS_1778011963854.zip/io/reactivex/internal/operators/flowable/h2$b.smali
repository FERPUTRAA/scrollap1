.class final Lio/reactivex/internal/operators/flowable/h2$b;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x783f9b81a81b45ffL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final parent:Lio/reactivex/internal/operators/flowable/h2$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/h2$a<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lio/reactivex/internal/operators/flowable/h2$a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lio/reactivex/internal/operators/flowable/h2$a<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h2$b;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h2$b;->parent:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s@~-n@~ So oo@i c //s@b~@ ~@4@l~aMr~@~t~b@t@~i @~ dv~o    @@@@1~@Kf@~oimo~u y@~~~@.~ ~~lf b  ~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    return v0
.end method

.method public cancel()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v5, 0x7

    const-wide/high16 v0, -0x8000000000000000L

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->getAndSet(J)J

    move-result-wide v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    cmp-long v0, v2, v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$b;->parent:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Lio/reactivex/internal/operators/flowable/h2$a;->c8(Lio/reactivex/internal/operators/flowable/h2$b;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h2$b;->parent:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/h2$a;->a8()V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->b(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x1

    const/4 v1, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h2$b;->parent:Lio/reactivex/internal/operators/flowable/h2$a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/h2$a;->a8()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method
