.class final Lio/reactivex/internal/operators/flowable/m1$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/m1;->e(Lio/reactivex/k;I)Ljava/util/concurrent/Callable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lio/reactivex/flowables/a<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/k;

.field final synthetic b:I


# direct methods
.method constructor <init>(Lio/reactivex/k;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$b;->a:Lio/reactivex/k;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m1$b;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()Lio/reactivex/flowables/a;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~osl~@-MfKay@~@@ ~@~o  @~~@ ~ ~Sd@ n~~ @~~~vm@@~4 to@.b @@ii 1@l ~cbft@s/ io@ ~@~u~  @r oob/~~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$b;->a:Lio/reactivex/k;

    const/4 v3, 0x2

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m1$b;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Lio/reactivex/k;->D4(I)Lio/reactivex/flowables/a;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m1$b;->a()Lio/reactivex/flowables/a;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object v0
.end method
