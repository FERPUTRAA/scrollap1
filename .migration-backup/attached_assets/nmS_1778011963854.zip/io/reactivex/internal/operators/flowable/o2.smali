.class public final Lio/reactivex/internal/operators/flowable/o2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/o2$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lio/reactivex/flowables/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/flowables/a<",
            "+TT;>;"
        }
    .end annotation
.end field

.field volatile d:Lio/reactivex/disposables/b;

.field final e:Ljava/util/concurrent/atomic/AtomicInteger;

.field final f:Ljava/util/concurrent/locks/ReentrantLock;


# direct methods
.method public constructor <init>(Lio/reactivex/flowables/a;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/flowables/a<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x4

    or-int/2addr v2, v1

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o2;->c:Lio/reactivex/flowables/a;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private Y7(Lio/reactivex/disposables/b;)Lio/reactivex/disposables/c;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os~ -~n@.i vt~f~@@@@l/@~@c  @~f1~~ ~oo@ra@~  b~  d@o4@ u @~bi~~ ~~  ~m~sb@~o ~~K @@/Sy@o@@l@it "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Lio/reactivex/internal/operators/flowable/o2$b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1}, Lio/reactivex/internal/operators/flowable/o2$b;-><init>(Lio/reactivex/internal/operators/flowable/o2;Lio/reactivex/disposables/b;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/disposables/d;->f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method

.method private a8(Lja/c;Ljava/util/concurrent/atomic/AtomicBoolean;)Lt7/g;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Ljava/util/concurrent/atomic/AtomicBoolean;",
            ")",
            "Lt7/g<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/o2$a;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p0, p1, p2}, Lio/reactivex/internal/operators/flowable/o2$a;-><init>(Lio/reactivex/internal/operators/flowable/o2;Lja/c;Ljava/util/concurrent/atomic/AtomicBoolean;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ne v0, v1, :cond_1

    const/4 v2, 0x3

    and-int/2addr v3, v2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2;->c:Lio/reactivex/flowables/a;

    const/4 v3, 0x4

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/operators/flowable/o2;->a8(Lja/c;Ljava/util/concurrent/atomic/AtomicBoolean;)Lt7/g;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Lio/reactivex/flowables/a;->c8(Lt7/g;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p1

    :cond_1
    :try_start_1
    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p1, v0}, Lio/reactivex/internal/operators/flowable/o2;->Z7(Lja/c;Lio/reactivex/disposables/b;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    :cond_2
    :goto_0
    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :catchall_1
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p1
.end method

.method Z7(Lja/c;Lio/reactivex/disposables/b;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lio/reactivex/disposables/b;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0, p2}, Lio/reactivex/internal/operators/flowable/o2;->Y7(Lio/reactivex/disposables/b;)Lio/reactivex/disposables/c;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v1, Lio/reactivex/internal/operators/flowable/o2$c;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v1, p0, p1, p2, v0}, Lio/reactivex/internal/operators/flowable/o2$c;-><init>(Lio/reactivex/internal/operators/flowable/o2;Lja/c;Lio/reactivex/disposables/b;Lio/reactivex/disposables/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o2;->c:Lio/reactivex/flowables/a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v1}, Lio/reactivex/k;->j(Lja/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
