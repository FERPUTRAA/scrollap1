.class final Lio/reactivex/internal/operators/flowable/p3$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/p3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "TR;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x3540c639803a63b9L


# instance fields
.field final bufferSize:I

.field volatile done:Z

.field fusionMode:I

.field final index:J

.field final parent:Lio/reactivex/internal/operators/flowable/p3$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/p3$b<",
            "TT;TR;>;"
        }
    .end annotation
.end field

.field volatile queue:Lu7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/o<",
            "TR;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/p3$b;JI)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/p3$b<",
            "TT;TR;>;JI)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->parent:Lio/reactivex/internal/operators/flowable/p3$b;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/p3$a;->index:J

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput p4, p0, Lio/reactivex/internal/operators/flowable/p3$a;->bufferSize:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s~@~r~@~~@ f @i~ 1t@~@bn-~ ~@o l~o @@~o.~ @K~du@i ~~~ /obb@v~@~of @o@4@aym@M ~~t~ i S  sc @~/l"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TR;)V"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->parent:Lio/reactivex/internal/operators/flowable/p3$b;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->index:J

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-wide v3, v0, Lio/reactivex/internal/operators/flowable/p3$b;->unique:J

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    cmp-long v1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->fusionMode:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->queue:Lu7/o;

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-interface {v1, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez p1, :cond_0

    const/4 v6, 0x7

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v0, "!lum seul?Qe"

    const-string v0, "lesuueul?!Q "

    const/4 v6, 0x7

    const-string v0, "Queue full?!"

    const/4 v6, 0x7

    invoke-direct {p1, v0}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/p3$a;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/p3$b;->b()V

    :cond_1
    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 7

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->parent:Lio/reactivex/internal/operators/flowable/p3$b;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->index:J

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-wide v3, v0, Lio/reactivex/internal/operators/flowable/p3$b;->unique:J

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    cmp-long v1, v1, v3

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput-boolean v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->done:Z

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/p3$b;->b()V

    :cond_0
    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->parent:Lio/reactivex/internal/operators/flowable/p3$b;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->index:J

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-wide v3, v0, Lio/reactivex/internal/operators/flowable/p3$b;->unique:J

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    cmp-long v1, v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/p3$b;->error:Lio/reactivex/internal/util/c;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1, p1}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-boolean p1, v0, Lio/reactivex/internal/operators/flowable/p3$b;->delayErrors:Z

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object p1, v0, Lio/reactivex/internal/operators/flowable/p3$b;->s:Lja/d;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {p1}, Lja/d;->cancel()V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 p1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->done:Z

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/p3$b;->b()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    instance-of v0, p1, Lu7/l;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    check-cast v0, Lu7/l;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Lu7/k;->l(I)I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-ne v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->fusionMode:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->queue:Lu7/o;

    const/4 v4, 0x0

    iput-boolean v2, p0, Lio/reactivex/internal/operators/flowable/p3$a;->done:Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->parent:Lio/reactivex/internal/operators/flowable/p3$b;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/p3$b;->b()V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->fusionMode:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->queue:Lu7/o;

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->bufferSize:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    int-to-long v0, v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v0, Lio/reactivex/internal/queue/b;

    const/4 v4, 0x6

    iget v1, p0, Lio/reactivex/internal/operators/flowable/p3$a;->bufferSize:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Lio/reactivex/internal/queue/b;-><init>(I)V

    const/4 v4, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->queue:Lu7/o;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lio/reactivex/internal/operators/flowable/p3$a;->bufferSize:I

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    int-to-long v0, v0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    return-void
.end method
