.class final Lio/reactivex/internal/operators/flowable/j2$b;
.super Lio/reactivex/internal/operators/flowable/j2$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x23e7f25903d0c345L


# instance fields
.field final actual:Lu7/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/a<",
            "-",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lu7/a;JJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-",
            "Ljava/lang/Long;",
            ">;JJ)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-direct {p0, p2, p3, p4, p5}, Lio/reactivex/internal/operators/flowable/j2$a;-><init>(JJ)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j2$b;->actual:Lu7/a;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method a()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~1s~i~- ~~ofnfKt~c~o @m~  du ~  S4o@~ @o~@ ~@l@ib~@/t@.~@ @   l@@@v~ @ o~oia@@~@~~@r~sMb@/@y  b~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j2$b;->actual:Lu7/a;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    cmp-long v5, v3, v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v5, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-boolean v5, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v5, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-interface {v2, v5}, Lu7/a;->o(Ljava/lang/Object;)Z

    const/4 v8, 0x4

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x4

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    add-long/2addr v3, v5

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-void

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {v2}, Lja/c;->onComplete()V

    const/4 v8, 0x5

    const/4 v7, 0x5

    return-void
.end method

.method c(J)V
    .locals 13

    const/4 v12, 0x6

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/j2$a;->end:J

    const/4 v12, 0x7

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/j2$b;->actual:Lu7/a;

    const/4 v12, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    :cond_0
    move-wide v7, v5

    :cond_1
    :goto_0
    const/4 v12, 0x0

    cmp-long v9, v7, p1

    const/4 v12, 0x6

    if-eqz v9, :cond_4

    const/4 v12, 0x2

    cmp-long v9, v2, v0

    const/4 v12, 0x3

    if-eqz v9, :cond_4

    const/4 v12, 0x5

    iget-boolean v9, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v12, 0x2

    if-eqz v9, :cond_2

    return-void

    :cond_2
    const/4 v12, 0x6

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    const/4 v12, 0x1

    invoke-interface {v4, v9}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result v9

    const/4 v12, 0x5

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const/4 v12, 0x6

    if-eqz v9, :cond_3

    const/4 v12, 0x2

    add-long/2addr v7, v10

    :cond_3
    const/4 v12, 0x5

    add-long/2addr v2, v10

    const/4 v12, 0x2

    goto :goto_0

    :cond_4
    const/4 v12, 0x3

    cmp-long p1, v2, v0

    const/4 v12, 0x2

    if-nez p1, :cond_6

    const/4 v12, 0x2

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/j2$a;->cancelled:Z

    const/4 v12, 0x6

    if-nez p1, :cond_5

    const/4 v12, 0x2

    invoke-interface {v4}, Lja/c;->onComplete()V

    :cond_5
    return-void

    :cond_6
    const/4 v12, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v12, 0x4

    cmp-long v9, v7, p1

    const/4 v12, 0x1

    if-nez v9, :cond_1

    const/4 v12, 0x7

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/j2$a;->index:J

    const/4 v12, 0x6

    neg-long p1, v7

    const/4 v12, 0x2

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v12, 0x0

    cmp-long v7, p1, v5

    const/4 v12, 0x1

    if-nez v7, :cond_0

    const/4 v12, 0x5

    return-void
.end method
