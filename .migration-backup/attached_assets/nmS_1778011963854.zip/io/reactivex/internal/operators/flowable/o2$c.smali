.class final Lio/reactivex/internal/operators/flowable/o2$c;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/o2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x21c3e08adcbe456L


# instance fields
.field final currentBase:Lio/reactivex/disposables/b;

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final resource:Lio/reactivex/disposables/c;

.field final subscriber:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lio/reactivex/internal/operators/flowable/o2;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/o2;Lja/c;Lio/reactivex/disposables/b;Lio/reactivex/disposables/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lio/reactivex/disposables/b;",
            "Lio/reactivex/disposables/c;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o2$c;->subscriber:Lja/c;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/o2$c;->currentBase:Lio/reactivex/disposables/b;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/o2$c;->resource:Lio/reactivex/disposables/c;

    const/4 v1, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o2$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ts~~ 1r@bs@@~btol@@@@v~ - ~o noy~~@ o 4 ~~/@f@~f@@~u S~~a@~ o @ d~i b/~oi~@@ m .lK~~c M @~@~~@i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$c;->currentBase:Lio/reactivex/disposables/b;

    const/4 v2, 0x2

    move v3, v2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v3, 0x4

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v1, Lio/reactivex/disposables/b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-direct {v1}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v1, v0, Lio/reactivex/internal/operators/flowable/o2;->d:Lio/reactivex/disposables/b;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->e:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o2$c;->this$0:Lio/reactivex/internal/operators/flowable/o2;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/o2;->f:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw v0
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->resource:Lio/reactivex/disposables/c;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->subscriber:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p0, v0, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/o2$c;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->subscriber:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/o2$c;->a()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->subscriber:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o2$c;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0, v0, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v2, 0x1

    return-void
.end method
