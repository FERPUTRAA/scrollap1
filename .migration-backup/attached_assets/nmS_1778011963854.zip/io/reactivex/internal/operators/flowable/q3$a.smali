.class final Lio/reactivex/internal/operators/flowable/q3$a;
.super Ljava/util/concurrent/atomic/AtomicBoolean;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/q3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicBoolean;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4e3906c454cf527fL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field done:Z

.field final limit:J

.field remaining:J

.field subscription:Lja/d;


# direct methods
.method constructor <init>(Lja/c;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->actual:Lja/c;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/q3$a;->limit:J

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/q3$a;->remaining:J

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sn brv @-/~@ ~ b Mt.s@o~@d~@4foy ~@@@~S~ ~~l~~o~o~@ Ki~l u~m~  @@o~@1@t@i@@c~~    a ~/i bf~o@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->done:Z

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez v0, :cond_1

    const/4 v6, 0x2

    move v7, v6

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->remaining:J

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v7, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    sub-long v2, v0, v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/q3$a;->remaining:J

    const/4 v7, 0x3

    const/4 v6, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    cmp-long v0, v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-lez v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    cmp-long v0, v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-nez v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v0, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->actual:Lja/c;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-interface {v1, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q3$a;->onComplete()V

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->limit:J

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    cmp-long v0, p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-ltz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->done:Z

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->done:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->actual:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0}, Lja/c;->onComplete()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->done:Z

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->done:Z

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->actual:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->subscription:Lja/d;

    const/4 v5, 0x0

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/q3$a;->limit:J

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->done:Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->actual:Lja/c;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/g;->a(Lja/c;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q3$a;->actual:Lja/c;

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_1
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method
