.class final Lio/reactivex/internal/operators/flowable/s2$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public call()Ljava/lang/Object;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s/d@ b~l4iysm c~~@iKb ~@tu@1-@o@ o~  ~@ @@ av@n~ @ ~l~o@Si@~@ o@t Mo~f~~ ~@.~r~~~~~ob @   ~f@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Lio/reactivex/internal/operators/flowable/s2$n;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/16 v1, 0x10

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    invoke-direct {v0, v1}, Lio/reactivex/internal/operators/flowable/s2$n;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method
