.class final Lio/reactivex/internal/operators/flowable/r3$a;
.super Ljava/util/ArrayDeque;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/r3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/ArrayDeque<",
        "TT;>;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x6479cc5265c56d72L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final count:I

.field volatile done:Z

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;

.field final wip:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lja/c;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;I)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/util/ArrayDeque;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r3$a;->actual:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput p2, p0, Lio/reactivex/internal/operators/flowable/r3$a;->count:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method a()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~ s@l~@b@i-fb  ~ o~ @/~o~Sn@@~~yi ~u~t@M@~o  @   ~@vtb ~f.~~c@@a@@  ~K@~/~mo@ 4~@@ od~1@s@ o~ri~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-nez v0, :cond_6

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->actual:Lja/c;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v10, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v1

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/r3$a;->cancelled:Z

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v3, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    return-void

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/r3$a;->done:Z

    const/4 v9, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz v3, :cond_5

    const/4 v9, 0x7

    and-int/2addr v10, v9

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-wide v5, v3

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    cmp-long v7, v5, v1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eqz v7, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-boolean v7, p0, Lio/reactivex/internal/operators/flowable/r3$a;->cancelled:Z

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v7, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-void

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-nez v7, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v10, 0x5

    return-void

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-interface {v0, v7}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v10, 0x7

    const-wide/16 v7, 0x1

    const-wide/16 v7, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto :goto_0

    :cond_4
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    cmp-long v3, v5, v3

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v3, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    const/4 v10, 0x5

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    cmp-long v3, v1, v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eqz v3, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/r3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    neg-long v2, v5

    const/4 v10, 0x1

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide v1

    :cond_5
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/r3$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-nez v3, :cond_0

    :cond_6
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->cancelled:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->s:Lja/d;

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->count:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/r3$a;->a()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->done:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/r3$a;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->actual:Lja/c;

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->s:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/r3$a;->s:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/r3$a;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method
