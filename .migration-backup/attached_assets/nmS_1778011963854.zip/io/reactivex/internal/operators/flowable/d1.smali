.class public final Lio/reactivex/internal/operators/flowable/d1;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/d1$b;,
        Lio/reactivex/internal/operators/flowable/d1$c;,
        Lio/reactivex/internal/operators/flowable/d1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d1;->b:Ljava/lang/Iterable;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static Y7(Lja/c;Ljava/util/Iterator;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/c<",
            "-TT;>;",
            "Ljava/util/Iterator<",
            "+TT;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ts/ Kv oS~@~ ~~@b.@@~~ @ola  c @~~@o@ ~o-~ bb@o~s ou d@ ~~~~~~1 ~~@/yr@fi~@@ n@@m4@@f~ii tl M~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/g;->a(Lja/c;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    instance-of v0, p0, Lu7/a;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/d1$b;

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v1, Lu7/a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1, p1}, Lio/reactivex/internal/operators/flowable/d1$b;-><init>(Lu7/a;Ljava/util/Iterator;)V

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Lio/reactivex/internal/operators/flowable/d1$c;

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0, p0, p1}, Lio/reactivex/internal/operators/flowable/d1$c;-><init>(Lja/c;Ljava/util/Iterator;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p0, v0}, Lja/c;->q(Lja/d;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1, p0}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d1;->b:Ljava/lang/Iterable;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lio/reactivex/internal/operators/flowable/d1;->Y7(Lja/c;Ljava/util/Iterator;)V

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method
