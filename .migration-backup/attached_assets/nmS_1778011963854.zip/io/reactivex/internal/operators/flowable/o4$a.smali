.class final Lio/reactivex/internal/operators/flowable/o4$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/o4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TV;>;"
        }
    .end annotation
.end field

.field final b:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "TU;>;"
        }
    .end annotation
.end field

.field final c:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT;-TU;+TV;>;"
        }
    .end annotation
.end field

.field d:Lja/d;

.field e:Z


# direct methods
.method constructor <init>(Lja/c;Ljava/util/Iterator;Lt7/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TV;>;",
            "Ljava/util/Iterator<",
            "TU;>;",
            "Lt7/c<",
            "-TT;-TU;+TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o4$a;->b:Ljava/util/Iterator;

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/o4$a;->c:Lt7/c;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method a(Ljava/lang/Throwable;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@tr@@ @~omiu ~~f @@/-o4nfMS~~v~~Kba@~i ~~@b~ .b@do@~o /  ~~@t@~~~@@@l@oy  @o ~1 ls @ @@~c~ ~i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->d:Lja/d;

    const/4 v1, 0x3

    move v2, v1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->d:Lja/d;

    const/4 v1, 0x3

    move v2, v1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->b:Ljava/util/Iterator;

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v1, "la meuinrnuedeaesltrTatovh u rrtle"

    const-string v1, "onsnlteu rehrlruaeeuitdr tTae avl "

    const/4 v3, 0x4

    const-string/jumbo v1, "teero aaTnu liearnlue tudolvt r he"

    const-string v1, "The iterator returned a null value"

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->c:Lt7/c;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v1, p1, v0}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v0, "ouvunbualcelmazntd fn uriireneeT  p e tlp"

    const-string/jumbo v0, "zT muc etnrneflhnpeenipldueov rlauu   iat"

    const/4 v3, 0x4

    const-string v0, "  tvurut izdifpo erennlu reunTenelacahlup"

    const-string v0, "The zipper function returned a null value"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    :try_start_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->b:Ljava/util/Iterator;

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->d:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1}, Lja/c;->onComplete()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/o4$a;->a(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :catchall_1
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/o4$a;->a(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :catchall_2
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/o4$a;->a(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->d:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4$a;->d:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->d:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/o4$a;->a:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method
