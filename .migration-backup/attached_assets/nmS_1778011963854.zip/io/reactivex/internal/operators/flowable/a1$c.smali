.class abstract Lio/reactivex/internal/operators/flowable/a1$c;
.super Lio/reactivex/internal/subscriptions/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/d<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x1f442a7d211232e5L


# instance fields
.field final array:[Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[TT;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field index:I


# direct methods
.method constructor <init>([Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([TT;)V"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x1

    invoke-direct {p0}, Lio/reactivex/internal/subscriptions/d;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method abstract a()V
.end method

.method abstract b(J)V
.end method

.method public final cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/@s@ ~t~~@os1@ ~@S~@~@r~@~@~@i/ Kbf~~ub  ~@ my@ l f ~@l ~~ob cvMa@ o@~~@@~ ~i@@d  ~ .io~n4o@ot~-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public final clear()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v1, 0x2

    or-int/2addr v2, v1

    array-length v0, v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public final g(J)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    cmp-long v0, p1, v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a1$c;->a()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/a1$c;->b(J)V

    :cond_1
    :goto_0
    const/4 v4, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public final isEmpty()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    array-length v1, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public final l(I)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    and-int/lit8 p1, p1, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method public final poll()Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    array-length v2, v1

    const/4 v4, 0x7

    if-ne v0, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/lit8 v2, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput v2, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    aget-object v0, v1, v0

    const/4 v4, 0x3

    const-string v1, "nrlmetesneyi rla s lm"

    const-string v1, "elsult e rnnis mleray"

    const/4 v4, 0x1

    const-string v1, "erylotaenl  aerlnmsiu"

    const-string v1, "array element is null"

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method
