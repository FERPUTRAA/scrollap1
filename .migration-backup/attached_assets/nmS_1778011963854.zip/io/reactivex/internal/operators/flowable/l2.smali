.class public final Lio/reactivex/internal/operators/flowable/l2;
.super Lio/reactivex/p;

# interfaces
.implements Lu7/h;
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/l2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/p<",
        "TT;>;",
        "Lu7/h<",
        "TT;>;",
        "Lu7/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation
.end field

.field final b:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TT;TT;TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lio/reactivex/k;Lt7/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/k<",
            "TT;>;",
            "Lt7/c<",
            "TT;TT;TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/p;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l2;->a:Lio/reactivex/k;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l2;->b:Lt7/c;

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public e()Lio/reactivex/k;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ sr~~~~M~~41 @ @@i~t~@~ @@m~/~~fo@~o@~@~t~bnobK @@ S.~ a  @l@iu@@yb s@@vol @@~@ o~~d  f/  i -c~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    new-instance v0, Lio/reactivex/internal/operators/flowable/k2;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l2;->a:Lio/reactivex/k;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/l2;->b:Lt7/c;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/k2;-><init>(Lja/b;Lt7/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0
.end method

.method protected n1(Lio/reactivex/r;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v3, 0x3

    move v4, v3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2;->a:Lio/reactivex/k;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/l2$a;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/l2;->b:Lt7/c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/flowable/l2$a;-><init>(Lio/reactivex/r;Lt7/c;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/k;->j(Lja/c;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public source()Lja/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lja/b<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2;->a:Lio/reactivex/k;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method
