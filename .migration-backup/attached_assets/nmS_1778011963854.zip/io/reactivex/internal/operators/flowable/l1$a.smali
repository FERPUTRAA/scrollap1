.class final Lio/reactivex/internal/operators/flowable/l1$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/l1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/e;

.field b:Lja/d;


# direct methods
.method constructor <init>(Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l1$a;->a:Lio/reactivex/e;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "obs4~~@yi@~-~~ooo~@ 1 s@v~b~@d~ @ m ~@o@ @i@Srtlf~ ~@@  c @@ tn/~~.@~blui@~a~~ ~@@@ K fM~ o~  /@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    const/4 v0, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x4

    const/4 v1, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->a:Lio/reactivex/e;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->a:Lio/reactivex/e;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l1$a;->b:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1$a;->a:Lio/reactivex/e;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v0, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x5

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    return-void
.end method
