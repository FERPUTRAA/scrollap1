.class final Lio/reactivex/internal/operators/flowable/b$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Ljava/util/Iterator;
.implements Ljava/lang/Runnable;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "TT;>;",
        "Ljava/util/Iterator<",
        "TT;>;",
        "Ljava/lang/Runnable;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x5cea3901b29dcb72L


# instance fields
.field final batchSize:J

.field final condition:Ljava/util/concurrent/locks/Condition;

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final limit:J

.field final lock:Ljava/util/concurrent/locks/Lock;

.field produced:J

.field final queue:Lio/reactivex/internal/queue/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v3, 0x7

    new-instance v0, Lio/reactivex/internal/queue/b;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, p1}, Lio/reactivex/internal/queue/b;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->queue:Lio/reactivex/internal/queue/b;

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    int-to-long v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->batchSize:J

    const/4 v3, 0x7

    shr-int/lit8 v0, p1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    sub-int/2addr p1, v0

    const/4 v2, 0x3

    or-int/2addr v3, v2

    int-to-long v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->limit:J

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p1, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/util/concurrent/locks/Lock;->newCondition()Ljava/util/concurrent/locks/Condition;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b$a;->condition:Ljava/util/concurrent/locks/Condition;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "ols~ ~@@ sni@@~@ @ou K /f~av~1@@~bb~ trM~  ~o~@i@o. @@@~@@tS~ ~ y@~/@  d ~  l@co@@f~~~~~-4~mi~ob"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast v0, Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->d(Lja/d;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method b()V
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->condition:Ljava/util/concurrent/locks/Condition;

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Condition;->signalAll()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw v0
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->queue:Lio/reactivex/internal/queue/b;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/internal/queue/b;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v2, 0x0

    const-string v0, "eQlmesl ?ufu"

    const-string/jumbo v0, "uuseelf?Qlu "

    const-string v0, "efeuo!l uuQl"

    const-string v0, "Queue full?!"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/b$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b$a;->b()V

    :goto_0
    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method public hasNext()Z
    .locals 4

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->done:Z

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b$a;->queue:Lio/reactivex/internal/queue/b;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/queue/b;->isEmpty()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->error:Ljava/lang/Throwable;

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    throw v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {}, Lio/reactivex/internal/util/e;->b()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    :goto_1
    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->done:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->queue:Lio/reactivex/internal/queue/b;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lio/reactivex/internal/queue/b;->isEmpty()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->condition:Ljava/util/concurrent/locks/Condition;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/locks/Condition;->await()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_2

    :catch_0
    move-exception v0

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b$a;->run()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_2
    const/4 v3, 0x3

    const/4 v2, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b$a;->lock:Ljava/util/concurrent/locks/Lock;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v1}, Ljava/util/concurrent/locks/Lock;->unlock()V

    const/4 v3, 0x3

    throw v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x3

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b$a;->hasNext()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->queue:Lio/reactivex/internal/queue/b;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/queue/b;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/b$a;->produced:J

    const/4 v6, 0x5

    const/4 v5, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x3

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    add-long/2addr v1, v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/b$a;->limit:J

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    cmp-long v3, v1, v3

    const/4 v6, 0x6

    if-nez v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x2

    iput-wide v3, p0, Lio/reactivex/internal/operators/flowable/b$a;->produced:J

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    check-cast v3, Lja/d;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v3, v1, v2}, Lja/d;->g(J)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-wide v1, p0, Lio/reactivex/internal/operators/flowable/b$a;->produced:J

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-object v0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    throw v0
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->done:Z

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b$a;->b()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b$a;->error:Ljava/lang/Throwable;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v0, 0x3

    xor-int/2addr v1, v0

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/b$a;->done:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b$a;->b()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/b$a;->batchSize:J

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "memorb"

    const-string v1, "remmov"

    const/4 v3, 0x7

    const-string/jumbo v1, "ureevm"

    const-string v1, "remove"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw v0
.end method

.method public run()V
    .locals 2

    const/4 v1, 0x5

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/b$a;->b()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method
