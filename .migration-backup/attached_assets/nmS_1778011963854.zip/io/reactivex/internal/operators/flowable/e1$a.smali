.class Lio/reactivex/internal/operators/flowable/e1$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/d0;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/e1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lio/reactivex/d0<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field private final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field private b:Lio/reactivex/disposables/c;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e1$a;->a:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s b~f~@@@@~o l@KM@o~ ~@u~@~~i ~-~@dS~~ ~ s vti y~@4 ~f~  @ b@~~ o@ @/o~m  obtl./a@ro@n@@~~i1@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e1$a;->b:Lio/reactivex/disposables/c;

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e1$a;->b:Lio/reactivex/disposables/c;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e1$a;->a:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e1$a;->a:Lja/c;

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e1$a;->a:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e1$a;->a:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method
