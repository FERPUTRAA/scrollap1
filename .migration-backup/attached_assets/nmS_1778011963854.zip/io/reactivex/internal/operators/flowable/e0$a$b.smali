.class Lio/reactivex/internal/operators/flowable/e0$a$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/e0$a;->onError(Ljava/lang/Throwable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Throwable;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/e0$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/e0$a;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e0$a$b;->b:Lio/reactivex/internal/operators/flowable/e0$a;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/e0$a$b;->a:Ljava/lang/Throwable;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "uys@ba@ .o~~v@@  od@~bl  mo1 @ 4i@ @~~~r~@~~~~@M~b~t@ ~lcs~ t n/@@i~~ oKi@~ ~S@~ @~-~f@ofo @@/ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a$b;->b:Lio/reactivex/internal/operators/flowable/e0$a;

    const/4 v3, 0x7

    const/4 v2, 0x6

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/e0$a;->a:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/e0$a$b;->a:Ljava/lang/Throwable;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e0$a$b;->b:Lio/reactivex/internal/operators/flowable/e0$a;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v2, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/e0$a$b;->b:Lio/reactivex/internal/operators/flowable/e0$a;

    const/4 v3, 0x0

    const/4 v2, 0x2

    iget-object v1, v1, Lio/reactivex/internal/operators/flowable/e0$a;->d:Lio/reactivex/e0$c;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v1}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw v0
.end method
