.class public final Lio/reactivex/internal/operators/flowable/j3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/j3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:Ljava/util/concurrent/TimeUnit;

.field final e:Lio/reactivex/e0;

.field final f:I

.field final g:Z


# direct methods
.method public constructor <init>(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "IZ)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/j3;->c:J

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/j3;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/j3;->e:Lio/reactivex/e0;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p6, p0, Lio/reactivex/internal/operators/flowable/j3;->f:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-boolean p7, p0, Lio/reactivex/internal/operators/flowable/j3;->g:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v9, Lio/reactivex/internal/operators/flowable/j3$a;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/j3;->c:J

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/j3;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/j3;->e:Lio/reactivex/e0;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget v7, p0, Lio/reactivex/internal/operators/flowable/j3;->f:I

    const/4 v10, 0x6

    shl-int/2addr v11, v10

    iget-boolean v8, p0, Lio/reactivex/internal/operators/flowable/j3;->g:Z

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-direct/range {v1 .. v8}, Lio/reactivex/internal/operators/flowable/j3$a;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IZ)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v0, v9}, Lja/b;->j(Lja/c;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    return-void
.end method
