.class public final Lio/reactivex/internal/operators/flowable/i2;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/i2$b;,
        Lio/reactivex/internal/operators/flowable/i2$c;,
        Lio/reactivex/internal/operators/flowable/i2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/k<",
        "Ljava/lang/Integer;",
        ">;"
    }
.end annotation


# instance fields
.field final b:I

.field final c:I


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lio/reactivex/internal/operators/flowable/i2;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    add-int/2addr p1, p2

    const/4 v0, 0x1

    move v1, v0

    iput p1, p0, Lio/reactivex/internal/operators/flowable/i2;->c:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "l~s~Slr .  f~~bu~s~~M @~o @K~ b~~@~~~oa -o@n ~~@@~b~~o i@i m o4@o /~@@@  @@t@c~ vdi@ ~@/1@f@ @y@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    instance-of v0, p1, Lu7/a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/i2$b;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast v1, Lu7/a;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget v2, p0, Lio/reactivex/internal/operators/flowable/i2;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v3, p0, Lio/reactivex/internal/operators/flowable/i2;->c:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v0, v1, v2, v3}, Lio/reactivex/internal/operators/flowable/i2$b;-><init>(Lu7/a;II)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Lio/reactivex/internal/operators/flowable/i2$c;

    const/4 v5, 0x2

    const/4 v4, 0x0

    iget v1, p0, Lio/reactivex/internal/operators/flowable/i2;->b:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget v2, p0, Lio/reactivex/internal/operators/flowable/i2;->c:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v0, p1, v1, v2}, Lio/reactivex/internal/operators/flowable/i2$c;-><init>(Lja/c;II)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method
