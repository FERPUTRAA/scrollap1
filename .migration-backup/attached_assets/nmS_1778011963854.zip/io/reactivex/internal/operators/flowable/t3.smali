.class public final Lio/reactivex/internal/operators/flowable/t3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/t3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:J

.field final e:Ljava/util/concurrent/TimeUnit;

.field final f:Lio/reactivex/e0;

.field final g:I

.field final h:Z


# direct methods
.method public constructor <init>(Lja/b;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "IZ)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/t3;->c:J

    const/4 v1, 0x3

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/t3;->d:J

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/t3;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p7, p0, Lio/reactivex/internal/operators/flowable/t3;->f:Lio/reactivex/e0;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p8, p0, Lio/reactivex/internal/operators/flowable/t3;->g:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-boolean p9, p0, Lio/reactivex/internal/operators/flowable/t3;->h:Z

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v12, "~~s  ~f~r @~~bo @ lc~S~@. @~@~~~t~ @i@~/tdo ~~y@o@@m1 bo~~ i ~~l@ b@iM4of @a @v@ /~o n~@@s @K@@-"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v13, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    new-instance v11, Lio/reactivex/internal/operators/flowable/t3$a;

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x1

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/t3;->c:J

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x0

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/t3;->d:J

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x1

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/t3;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v13, 0x5

    iget-object v8, p0, Lio/reactivex/internal/operators/flowable/t3;->f:Lio/reactivex/e0;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x0

    iget v9, p0, Lio/reactivex/internal/operators/flowable/t3;->g:I

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x1

    iget-boolean v10, p0, Lio/reactivex/internal/operators/flowable/t3;->h:Z

    move-object v1, v11

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-direct/range {v1 .. v10}, Lio/reactivex/internal/operators/flowable/t3$a;-><init>(Lja/c;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IZ)V

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-interface {v0, v11}, Lja/b;->j(Lja/c;)V

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x0

    return-void
.end method
