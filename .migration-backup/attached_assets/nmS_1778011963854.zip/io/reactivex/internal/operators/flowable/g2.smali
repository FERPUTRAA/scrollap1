.class public final Lio/reactivex/internal/operators/flowable/g2;
.super Lio/reactivex/flowables/a;

# interfaces
.implements Lu7/h;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/g2$b;,
        Lio/reactivex/internal/operators/flowable/g2$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/flowables/a<",
        "TT;>;",
        "Lu7/h<",
        "TT;>;"
    }
.end annotation


# static fields
.field static final f:J = -0x8000000000000000L


# instance fields
.field final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/internal/operators/flowable/g2$c<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final d:I

.field final e:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>(Lja/b;Lja/b;Ljava/util/concurrent/atomic/AtomicReference;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/internal/operators/flowable/g2$c<",
            "TT;>;>;I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/flowables/a;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g2;->e:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/g2;->b:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/g2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p4, p0, Lio/reactivex/internal/operators/flowable/g2;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static e8(Lio/reactivex/k;I)Lio/reactivex/flowables/a;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lio/reactivex/k<",
            "TT;>;I)",
            "Lio/reactivex/flowables/a<",
            "TT;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s@@~~s@@-4@f ~~b~@t~@o  1~  i cf@ ~ oo/Ko ~o~ /~li~a v My@o@ d@ @S~~n@~@ l~@@ ~~i@b@tr@m@~ .u~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v1, Lio/reactivex/internal/operators/flowable/g2$a;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v1, v0, p1}, Lio/reactivex/internal/operators/flowable/g2$a;-><init>(Ljava/util/concurrent/atomic/AtomicReference;I)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v2, Lio/reactivex/internal/operators/flowable/g2;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v2, v1, p0, v0, p1}, Lio/reactivex/internal/operators/flowable/g2;-><init>(Lja/b;Lja/b;Ljava/util/concurrent/atomic/AtomicReference;I)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-static {v2}, Lio/reactivex/plugins/a;->R(Lio/reactivex/flowables/a;)Lio/reactivex/flowables/a;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p0
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g2;->e:Lja/b;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/b;->j(Lja/c;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public c8(Lt7/g;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;)V"
        }
    .end annotation

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    check-cast v0, Lio/reactivex/internal/operators/flowable/g2$c;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/g2$c;->a()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_2

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/g2$c;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    iget v3, p0, Lio/reactivex/internal/operators/flowable/g2;->d:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {v1, v2, v3}, Lio/reactivex/internal/operators/flowable/g2$c;-><init>(Ljava/util/concurrent/atomic/AtomicReference;I)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g2;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v2, v0, v1}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/g2$c;->shouldConnect:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/g2$c;->shouldConnect:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    move v2, v3

    move v2, v3

    const/4 v5, 0x0

    move v2, v3

    move v2, v3

    :cond_3
    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g2;->b:Lja/b;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    throw p1
.end method

.method public source()Lja/b;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lja/b<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g2;->b:Lja/b;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method
