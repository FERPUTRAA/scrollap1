.class public final Lio/reactivex/internal/operators/flowable/l4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/l4$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TR;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT;-TU;+TR;>;"
        }
    .end annotation
.end field

.field final d:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TU;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lt7/c;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/c<",
            "-TT;-TU;+TR;>;",
            "Lja/b<",
            "+TU;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l4;->c:Lt7/c;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/l4;->d:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~b~@@ f@ -/1 i~M@@   @~f suKtn~ i~~4~~y.l~~@@@i@oov~ @~or@d mt~cbo @~ ~ @@b@~@~/@~a o@l~ S~ o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Lio/reactivex/subscribers/e;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance p1, Lio/reactivex/internal/operators/flowable/l4$b;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l4;->c:Lt7/c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p1, v0, v1}, Lio/reactivex/internal/operators/flowable/l4$b;-><init>(Lja/c;Lt7/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lio/reactivex/subscribers/e;->q(Lja/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4;->d:Lja/b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Lio/reactivex/internal/operators/flowable/l4$a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/flowable/l4$a;-><init>(Lio/reactivex/internal/operators/flowable/l4;Lio/reactivex/internal/operators/flowable/l4$b;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-void
.end method
