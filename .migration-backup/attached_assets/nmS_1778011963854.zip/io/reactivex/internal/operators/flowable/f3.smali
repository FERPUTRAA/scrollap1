.class public final Lio/reactivex/internal/operators/flowable/f3;
.super Lio/reactivex/p;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/f3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/p<",
        "TT;>;",
        "Lu7/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/p;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f3;->a:Lja/b;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public e()Lio/reactivex/k;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~s-o@~i~a ~ @~~~ @uso@~@fM/~ n@4m~~ io@@~ b @l~ ~~f@@Sbi~ t@ @ 1~@ ~ybr@oco@  v./lo@ @td~@~K~@ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/e3;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/f3;->a:Lja/b;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Lio/reactivex/internal/operators/flowable/e3;-><init>(Lja/b;Ljava/lang/Object;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0
.end method

.method protected n1(Lio/reactivex/r;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f3;->a:Lja/b;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/f3$a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v1, p1}, Lio/reactivex/internal/operators/flowable/f3$a;-><init>(Lio/reactivex/r;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method
