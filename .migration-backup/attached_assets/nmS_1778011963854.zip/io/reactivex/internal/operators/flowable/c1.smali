.class public final Lio/reactivex/internal/operators/flowable/c1;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/util/concurrent/Future;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Future<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:J

.field final d:Ljava/util/concurrent/TimeUnit;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Future;JLjava/util/concurrent/TimeUnit;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Future<",
            "+TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c1;->b:Ljava/util/concurrent/Future;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/c1;->c:J

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/c1;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "nos@ @ @~y~~m~ K~@~~o ~u /~ tlf@ s 4~t~~-@@v~od@r~/ l~~@@c~o@~@ ai.~1@o @ob@  bi~M@~ @S ~ @fb i@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    new-instance v0, Lio/reactivex/internal/subscriptions/f;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/c1;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/c1;->b:Ljava/util/concurrent/Future;

    const/4 v6, 0x5

    const/4 v5, 0x7

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/c1;->c:J

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-interface {v2, v3, v4, v1}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/c1;->b:Ljava/util/concurrent/Future;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const-string v1, "desueuehrlnft ur n ulerT"

    const/4 v6, 0x5

    const-string v1, "rhtmeutdeeuf l ruuTnre l"

    const-string v1, "The future returned null"

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v0, v1}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    :goto_1
    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/subscriptions/f;->e()Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-nez v0, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {p1, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-void
.end method
