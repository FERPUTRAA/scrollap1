.class public final Lio/reactivex/internal/operators/flowable/o0;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/o0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field final e:Z


# direct methods
.method public constructor <init>(Lja/b;JLjava/lang/Object;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;JTT;Z)V"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/o0;->c:J

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/o0;->d:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p5, p0, Lio/reactivex/internal/operators/flowable/o0;->e:Z

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, " is ~@@~o~b@@-yt o~ Kfua~~ @@@@~m d @f ~ v@i~s/o~tc@l~ @@o~ ~M@ ~~/@~b1@@~@S@~ ~ ~n  io .bl4o~r@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v9, 0x5

    const/4 v8, 0x4

    new-instance v7, Lio/reactivex/internal/operators/flowable/o0$a;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/o0;->c:J

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/o0;->d:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-boolean v6, p0, Lio/reactivex/internal/operators/flowable/o0;->e:Z

    move-object v1, v7

    move-object v1, v7

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-direct/range {v1 .. v6}, Lio/reactivex/internal/operators/flowable/o0$a;-><init>(Lja/c;JLjava/lang/Object;Z)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {v0, v7}, Lja/b;->j(Lja/c;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    return-void
.end method
