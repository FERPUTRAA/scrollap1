.class final Lio/reactivex/internal/operators/flowable/e2$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/e2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+",
            "Lja/b<",
            "+TT;>;>;"
        }
    .end annotation
.end field

.field final c:Z

.field final d:Lio/reactivex/internal/subscriptions/o;

.field e:Z

.field f:Z


# direct methods
.method constructor <init>(Lja/c;Lt7/o;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+",
            "Lja/b<",
            "+TT;>;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/e2$a;->b:Lt7/o;

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-boolean p3, p0, Lio/reactivex/internal/operators/flowable/e2$a;->c:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    new-instance p1, Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p1}, Lio/reactivex/internal/subscriptions/o;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->d:Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sa ~~r oo ~l~o@v  un~1@~s ~~m@K~/@@it/@ @d@ ~c @f@~o~f. ~~ ib4 @ @~~ySb@@~l~@t @@o-b@@M ~~io~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->f:Z

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    move v3, v2

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->e:Z

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->d:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-wide/16 v0, 0x1

    const/4 v3, 0x6

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Lio/reactivex/internal/subscriptions/o;->e(J)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->f:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->e:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->e:Z

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->f:Z

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-void

    :cond_0
    const/4 v7, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->e:Z

    const/4 v7, 0x7

    iget-boolean v1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->c:Z

    const/4 v7, 0x3

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    instance-of v1, p1, Ljava/lang/Exception;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez v1, :cond_2

    const/4 v7, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-void

    :cond_2
    :try_start_0
    const/4 v7, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->b:Lt7/o;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v1, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    check-cast v1, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    if-nez v1, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x5

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string v1, "hlumlPulsir sbsie"

    const-string v1, "reslui sPhbs luli"

    const/4 v7, 0x4

    const-string v1, "eiuPo llnshlib ru"

    const-string v1, "Publisher is null"

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-void

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v1, p0}, Lja/b;->j(Lja/c;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-void

    :catchall_0
    move-exception v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/e2$a;->a:Lja/c;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v3, Lio/reactivex/exceptions/a;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v4, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-array v4, v4, [Ljava/lang/Throwable;

    const/4 v6, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput-object p1, v4, v5

    const/4 v7, 0x7

    aput-object v1, v4, v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-direct {v3, v4}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v2, v3}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e2$a;->d:Lio/reactivex/internal/subscriptions/o;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
