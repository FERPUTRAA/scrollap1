.class final Lio/reactivex/internal/operators/flowable/t2$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/t2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x628271a96862fff0L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final predicate:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field retries:I

.field final sa:Lio/reactivex/internal/subscriptions/o;

.field final source:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/d;Lio/reactivex/internal/subscriptions/o;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/d<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Throwable;",
            ">;",
            "Lio/reactivex/internal/subscriptions/o;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/t2$a;->actual:Lja/c;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/t2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/t2$a;->source:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/t2$a;->predicate:Lt7/d;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Ks@y~o@-~ m~~as~ M@br@~~f@~i~ o~bo@@~  oS@~./  n@o@o@@ @ @v@@~@  ~tc  ~ /@itd@@~l4  bu~f~~~i 1l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x4

    const/4 v0, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x7

    invoke-virtual {v1}, Lio/reactivex/internal/subscriptions/o;->c()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t2$a;->source:Lja/b;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v1, p0}, Lja/b;->j(Lja/c;)V

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    neg-int v0, v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v0, :cond_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t2$a;->actual:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/t2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1, v0, v1}, Lio/reactivex/internal/subscriptions/o;->e(J)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t2$a;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v0, 0x1

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t2$a;->predicate:Lt7/d;

    const/4 v7, 0x5

    const/4 v6, 0x3

    iget v2, p0, Lio/reactivex/internal/operators/flowable/t2$a;->retries:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/2addr v2, v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput v2, p0, Lio/reactivex/internal/operators/flowable/t2$a;->retries:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v1, v2, p1}, Lt7/d;->test(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t2$a;->actual:Lja/c;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/t2$a;->a()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-void

    :catchall_0
    move-exception v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t2$a;->actual:Lja/c;

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v3, Lio/reactivex/exceptions/a;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v4, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-array v4, v4, [Ljava/lang/Throwable;

    const/4 v7, 0x3

    const/4 v5, 0x0

    const/4 v7, 0x7

    move v6, v5

    move v6, v5

    const/4 v7, 0x3

    aput-object p1, v4, v5

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    aput-object v1, v4, v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {v3, v4}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v2, v3}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t2$a;->sa:Lio/reactivex/internal/subscriptions/o;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method
