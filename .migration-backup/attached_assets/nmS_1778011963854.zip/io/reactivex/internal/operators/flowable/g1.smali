.class public final Lio/reactivex/internal/operators/flowable/g1;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/g1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "S:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TS;>;"
        }
    .end annotation
.end field

.field final c:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TS;",
            "Lio/reactivex/j<",
            "TT;>;TS;>;"
        }
    .end annotation
.end field

.field final d:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TS;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;Lt7/c;Lt7/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "TS;>;",
            "Lt7/c<",
            "TS;",
            "Lio/reactivex/j<",
            "TT;>;TS;>;",
            "Lt7/g<",
            "-TS;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g1;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/g1;->c:Lt7/c;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/g1;->d:Lt7/g;

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s @@o@K@~~@dt~~ v@@@o~ @bc~~l~~   ~@@ i ~i@/l@ ~ @t 4fi@u~r~. @o@f~@bS/  ~~ bs@~~ma o-~1oon~M~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g1;->b:Ljava/util/concurrent/Callable;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/g1$a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g1;->c:Lt7/c;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/g1;->d:Lt7/g;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v1, p1, v2, v3, v0}, Lio/reactivex/internal/operators/flowable/g1$a;-><init>(Lja/c;Lt7/c;Lt7/g;Ljava/lang/Object;)V

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void
.end method
