.class final Lio/reactivex/internal/operators/flowable/i1$c;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "Ljava/lang/Object;",
        ">;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1a24ec53e2780a15L


# instance fields
.field final index:I

.field final isLeft:Z

.field final parent:Lio/reactivex/internal/operators/flowable/i1$b;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/i1$b;ZI)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$c;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-boolean p2, p0, Lio/reactivex/internal/operators/flowable/i1$c;->isLeft:Z

    const/4 v1, 0x0

    iput p3, p0, Lio/reactivex/internal/operators/flowable/i1$c;->index:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " fs@Sno~~@ M@@~@@cob~~  @i  ~v@@@ab~ i ~@-umlt~ ~@~or@~@f~ys/t 4 ~~o@.1i@~~ o ~~@ @@d Ko~~/~@ b "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast v0, Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->d(Lja/d;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    return v0
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$c;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i1$c;->isLeft:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1, v0, p0}, Lio/reactivex/internal/operators/flowable/i1$b;->e(ZLio/reactivex/internal/operators/flowable/i1$c;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$c;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v3, 0x0

    iget-boolean v1, p0, Lio/reactivex/internal/operators/flowable/i1$c;->isLeft:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-interface {v0, v1, p0}, Lio/reactivex/internal/operators/flowable/i1$b;->e(ZLio/reactivex/internal/operators/flowable/i1$c;)V

    const/4 v2, 0x3

    or-int/2addr v3, v2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$c;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lio/reactivex/internal/operators/flowable/i1$b;->d(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method
