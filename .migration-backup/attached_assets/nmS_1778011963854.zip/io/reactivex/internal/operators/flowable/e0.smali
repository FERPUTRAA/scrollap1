.class public final Lio/reactivex/internal/operators/flowable/e0;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/e0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:Ljava/util/concurrent/TimeUnit;

.field final e:Lio/reactivex/e0;

.field final f:Z


# direct methods
.method public constructor <init>(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "Z)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/e0;->c:J

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/e0;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/e0;->e:Lio/reactivex/e0;

    const/4 v1, 0x1

    const/4 v0, 0x7

    iput-boolean p6, p0, Lio/reactivex/internal/operators/flowable/e0;->f:Z

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~ s@@ ~f/~~~o @@n vM@-@~~~4~i@   u@ro lab~~ ~l@ ~  o@~~~@/@d@@o@ic s.ib~Ko1~b~~ m@@o S~tf @y t~@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e0;->f:Z

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x3

    new-instance v0, Lio/reactivex/subscribers/e;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {v0, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e0;->e:Lio/reactivex/e0;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p1}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/e0$a;

    const/4 v9, 0x6

    const/4 v8, 0x7

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/e0;->c:J

    const/4 v8, 0x1

    move v9, v8

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/e0;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v9, 0x5

    iget-boolean v7, p0, Lio/reactivex/internal/operators/flowable/e0;->f:Z

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    invoke-direct/range {v1 .. v7}, Lio/reactivex/internal/operators/flowable/e0$a;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;Z)V

    const/4 v9, 0x3

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    return-void
.end method
