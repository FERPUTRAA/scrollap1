.class public final Lio/reactivex/internal/operators/flowable/l1;
.super Lio/reactivex/c;

# interfaces
.implements Lu7/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/l1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/c;",
        "Lu7/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l1;->a:Lja/b;

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@fs~tlK@ S l ab@@@@b~o~  //~~@.~ds4~m ~o~~@  o@r~~~iu  co@f@~vMi@@@@ - @n~t @1o~~ yoi~~@~ b~ ~@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l1;->a:Lja/b;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/l1$a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v1, p1}, Lio/reactivex/internal/operators/flowable/l1$a;-><init>(Lio/reactivex/e;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public e()Lio/reactivex/k;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/k<",
            "TT;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/k1;

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l1;->a:Lja/b;

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-direct {v0, v1}, Lio/reactivex/internal/operators/flowable/k1;-><init>(Lja/b;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0}, Lio/reactivex/plugins/a;->N(Lio/reactivex/k;)Lio/reactivex/k;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0
.end method
