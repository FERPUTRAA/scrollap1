.class public final Lio/reactivex/internal/operators/flowable/a2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/a2$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:Lt7/a;

.field final e:Lio/reactivex/a;


# direct methods
.method public constructor <init>(Lja/b;JLt7/a;Lio/reactivex/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J",
            "Lt7/a;",
            "Lio/reactivex/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/a2;->c:J

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/a2;->d:Lt7/a;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/a2;->e:Lio/reactivex/a;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~ s ~@~bml~u~~S@ @-an ~o f.ob~ o@1 t@~~y@r@4 @ @@fo~~@tcob@lM~~ d @~s K@@~@~~ @@~ v@ i~/io@  i~~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v7, Lio/reactivex/internal/operators/flowable/a2$b;

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a2;->d:Lt7/a;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/a2;->e:Lio/reactivex/a;

    const/4 v9, 0x1

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/a2;->c:J

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-direct/range {v1 .. v6}, Lio/reactivex/internal/operators/flowable/a2$b;-><init>(Lja/c;Lt7/a;Lio/reactivex/a;J)V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-interface {v0, v7}, Lja/b;->j(Lja/c;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    return-void
.end method
