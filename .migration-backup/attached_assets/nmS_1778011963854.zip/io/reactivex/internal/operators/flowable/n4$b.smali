.class final Lio/reactivex/internal/operators/flowable/n4$b;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/n4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4037183c76e39a4cL


# instance fields
.field volatile done:Z

.field final index:I

.field final limit:I

.field final parent:Lio/reactivex/internal/operators/flowable/n4$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/n4$a<",
            "TT;TR;>;"
        }
    .end annotation
.end field

.field final prefetch:I

.field produced:J

.field queue:Lu7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/o<",
            "TT;>;"
        }
    .end annotation
.end field

.field sourceMode:I


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/n4$a;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/n4$a<",
            "TT;TR;>;II)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->parent:Lio/reactivex/internal/operators/flowable/n4$a;

    const/4 v1, 0x4

    iput p2, p0, Lio/reactivex/internal/operators/flowable/n4$b;->prefetch:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p3, p0, Lio/reactivex/internal/operators/flowable/n4$b;->index:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    shr-int/lit8 p1, p2, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    sub-int/2addr p2, p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p2, p0, Lio/reactivex/internal/operators/flowable/n4$b;->limit:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@bs~ ~y~~-l@M @@ @ ~@~rumo@t dctKb ~S~@@/  o@a~@4@@/si ~~~oo~~.v~o@ fn@b~~ @@ol@~ ~  fi  ~ ~@1@i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->sourceMode:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eq v0, v1, :cond_0

    const/4 v2, 0x3

    and-int/2addr v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->queue:Lu7/o;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->parent:Lio/reactivex/internal/operators/flowable/n4$a;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/n4$a;->b()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->sourceMode:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x5

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->produced:J

    const/4 v3, 0x6

    add-long/2addr v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget p1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->limit:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    int-to-long p1, p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    cmp-long p1, v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ltz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x0

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->produced:J

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast p1, Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->produced:J

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->done:Z

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->parent:Lio/reactivex/internal/operators/flowable/n4$a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/n4$a;->b()V

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->parent:Lio/reactivex/internal/operators/flowable/n4$a;

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    invoke-virtual {v0, p0, p1}, Lio/reactivex/internal/operators/flowable/n4$a;->c(Lio/reactivex/internal/operators/flowable/n4$b;Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    instance-of v0, p1, Lu7/l;

    const/4 v3, 0x5

    move v4, v3

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    check-cast v0, Lu7/l;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x7

    const/4 v3, 0x0

    or-int/2addr v4, v3

    invoke-interface {v0, v1}, Lu7/k;->l(I)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-ne v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    iput v1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->sourceMode:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->queue:Lu7/o;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-boolean v2, p0, Lio/reactivex/internal/operators/flowable/n4$b;->done:Z

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->parent:Lio/reactivex/internal/operators/flowable/n4$a;

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/n4$a;->b()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-ne v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->sourceMode:I

    const/4 v4, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->queue:Lu7/o;

    const/4 v4, 0x0

    const/4 v3, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->prefetch:I

    const/4 v4, 0x4

    int-to-long v0, v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Lio/reactivex/internal/queue/b;

    const/4 v4, 0x7

    iget v1, p0, Lio/reactivex/internal/operators/flowable/n4$b;->prefetch:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Lio/reactivex/internal/queue/b;-><init>(I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->queue:Lu7/o;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget v0, p0, Lio/reactivex/internal/operators/flowable/n4$b;->prefetch:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    int-to-long v0, v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_2
    const/4 v3, 0x3

    move v4, v3

    return-void
.end method
