.class Lio/reactivex/internal/operators/flowable/f0$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/f0$a;->q(Lja/d;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lja/d;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/f0$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/f0$a;Lja/d;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f0$a$a;->b:Lio/reactivex/internal/operators/flowable/f0$a;

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/f0$a$a;->a:Lja/d;

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f0$a$a;->a:Lja/d;

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
