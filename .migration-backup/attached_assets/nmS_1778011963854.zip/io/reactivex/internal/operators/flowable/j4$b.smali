.class final Lio/reactivex/internal/operators/flowable/j4$b;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;",
        "Ljava/lang/Object;",
        "Lio/reactivex/k<",
        "TT;>;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field static final F0:Ljava/lang/Object;


# instance fields
.field final A0:I

.field B0:Lja/d;

.field final C0:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field D0:Lio/reactivex/processors/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/processors/g<",
            "TT;>;"
        }
    .end annotation
.end field

.field final E0:Ljava/util/concurrent/atomic/AtomicLong;

.field final k0:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lja/b<",
            "TB;>;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput-object v0, Lio/reactivex/internal/operators/flowable/j4$b;->F0:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method constructor <init>(Lja/c;Ljava/util/concurrent/Callable;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lja/b<",
            "TB;>;>;I)V"
        }
    .end annotation

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v1, 0x0

    move v2, v1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v2, 0x6

    const/4 v1, 0x1

    iput p3, p0, Lio/reactivex/internal/operators/flowable/j4$b;->A0:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-wide/16 p2, 0x1

    const-wide/16 p2, 0x1

    const/4 v2, 0x2

    const-wide/16 p2, 0x1

    const-wide/16 p2, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1, p2, p3}, Ljava/util/concurrent/atomic/AtomicLong;->lazySet(J)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "1osu~t@~~@y @@b@l.  @~tai~~o  S@~il/@f~~ ~i /@o4  @vob~-~~K@~~@o c~~   ~@@ b ~~@n~ @rso ~M@fdm@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->n()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->D0:Lio/reactivex/processors/g;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 p1, -0x1

    move v2, p1

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-nez p1, :cond_2

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Lio/reactivex/internal/util/p;->s(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    if-nez p1, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j4$b;->t()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    move v5, v4

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j4$b;->t()V

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    move v5, v4

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-object p1, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j4$b;->t()V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    cmp-long v0, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 9

    const/4 v8, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->B0:Lja/d;

    const/4 v8, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v0, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j4$b;->B0:Lja/d;

    const/4 v8, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v8, 0x2

    if-eqz v1, :cond_0

    const/4 v8, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/j4$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v2, "fiemTlpe urlssrhlh niut unoswp  lspddsibiie"

    const-string v2, "issb lhoihu lpsirrsldedp uips tuele wni Tnf"

    const/4 v8, 0x7

    const-string/jumbo v2, "up ioilei lbwfdstrishhnopr wulle n Tipsdu s"

    const-string v2, "The first window publisher supplied is null"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    check-cast v1, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x3

    iget v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->A0:I

    const/4 v8, 0x5

    invoke-static {v2}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    cmp-long v5, v3, v5

    const/4 v8, 0x7

    if-eqz v5, :cond_2

    const/4 v7, 0x4

    move v8, v7

    invoke-interface {v0, v2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-wide v5, 0x7fffffffffffffffL

    const-wide v5, 0x7fffffffffffffffL

    const-wide v5, 0x7fffffffffffffffL

    const-wide v5, 0x7fffffffffffffffL

    const/4 v8, 0x1

    cmp-long v0, v3, v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v0, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x7

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0, v3, v4}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-object v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->D0:Lio/reactivex/processors/g;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/j4$a;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/flowable/j4$a;-><init>(Lio/reactivex/internal/operators/flowable/j4$b;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x0

    shr-int/2addr v8, v7

    invoke-static {v2, v3, v0}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v2, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-interface {p1, v5, v6}, Lja/d;->g(J)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v1, "freatbootuoduesuw  tid olsrmvCflwe sdqik  dlt cnnrei  "

    const-string v1, " utmeeuovlCnksfloca  irilern dtoi osqrfewtddu   dtse w"

    const/4 v8, 0x4

    const-string v1, "rce souu eaw df ettdCor sedtii o nnirelq uuod fsokwtvl"

    const-string v1, "Could not deliver first window due to lack of requests"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {p1, v1}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    return-void

    :catchall_0
    move-exception v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-void
.end method

.method t()V
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->D0:Lio/reactivex/processors/g;

    const/4 v11, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    const/4 v3, 0x1

    const/4 v11, 0x0

    xor-int/2addr v12, v11

    move v4, v3

    const/4 v12, 0x5

    move v4, v3

    move v4, v3

    :cond_0
    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-interface {v0}, Lu7/n;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-nez v6, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    move v7, v3

    move v7, v3

    const/4 v12, 0x5

    move v7, v3

    move v7, v3

    const/4 v12, 0x7

    goto :goto_1

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v7, 0x0

    :goto_1
    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    if-eqz v5, :cond_3

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    if-eqz v7, :cond_3

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    if-eqz v0, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v2, v0}, Lio/reactivex/processors/g;->onError(Ljava/lang/Throwable;)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto :goto_2

    :cond_2
    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    :goto_2
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    return-void

    :cond_3
    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-eqz v7, :cond_4

    const/4 v12, 0x7

    const/4 v11, 0x4

    neg-int v4, v4

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {p0, v4}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result v4

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-nez v4, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    return-void

    :cond_4
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    sget-object v5, Lio/reactivex/internal/operators/flowable/j4$b;->F0:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-ne v6, v5, :cond_a

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/j4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v5

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v12, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v12, 0x3

    cmp-long v5, v5, v7

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-nez v5, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    return-void

    :cond_5
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-eqz v5, :cond_6

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x0

    goto/16 :goto_0

    :cond_6
    :try_start_0
    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-interface {v2}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x7

    const-string v5, " lluspipTnsbl hr pes upehidelu"

    const-string/jumbo v5, "ud lorpusp hblin ulieesphe lsT"

    const/4 v12, 0x4

    const-string v5, "ebip spsqndl pTluuuh ihslirele"

    const-string v5, "The publisher supplied is null"

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v2, v5}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    check-cast v2, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x5

    const/4 v11, 0x2

    iget v5, p0, Lio/reactivex/internal/operators/flowable/j4$b;->A0:I

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-static {v5}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v5

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v9

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    cmp-long v6, v9, v7

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-eqz v6, :cond_8

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/j4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v12, 0x0

    const/4 v11, 0x7

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-interface {v1, v5}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v12, 0x1

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    cmp-long v6, v9, v6

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz v6, :cond_7

    const/4 v12, 0x2

    const/4 v11, 0x4

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v12, 0x5

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {p0, v6, v7}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_7
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    iput-object v5, p0, Lio/reactivex/internal/operators/flowable/j4$b;->D0:Lio/reactivex/processors/g;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    new-instance v6, Lio/reactivex/internal/operators/flowable/j4$a;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-direct {v6, p0}, Lio/reactivex/internal/operators/flowable/j4$a;-><init>(Lio/reactivex/internal/operators/flowable/j4$b;)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v8

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v7, v8, v6}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    if-eqz v7, :cond_9

    const/4 v12, 0x5

    invoke-interface {v2, v6}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    goto :goto_3

    :cond_8
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    iput-boolean v3, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v12, 0x1

    const/4 v11, 0x0

    new-instance v2, Lio/reactivex/exceptions/c;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x2

    const-string v6, "f seio  dstt dclCvb ro ueieono ksqa nwnreddteow uleu"

    const-string v6, " Coelbuclet w ri au vetfwutoekono e indwdresnsqod  d"

    const/4 v12, 0x5

    const-string v6, "lknmll ve ie oCtuoandwtf rt eiwouc   sendsdequrw eoo"

    const-string v6, "Could not deliver new window due to lack of requests"

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-direct {v2, v6}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-interface {v1, v2}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_9
    :goto_3
    move-object v2, v5

    move-object v2, v5

    move-object v2, v5

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-static {v2}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v12, 0x6

    const/4 v11, 0x1

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    return-void

    :cond_a
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-static {v6}, Lio/reactivex/internal/util/p;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v2, v5}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    goto/16 :goto_0
.end method

.method u()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v3, 0x2

    sget-object v1, Lio/reactivex/internal/operators/flowable/j4$b;->F0:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j4$b;->t()V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method
