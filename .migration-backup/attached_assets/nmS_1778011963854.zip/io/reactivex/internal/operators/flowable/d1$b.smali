.class final Lio/reactivex/internal/operators/flowable/d1$b;
.super Lio/reactivex/internal/operators/flowable/d1$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/d1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/d1$a<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x53954cbe186540ffL


# instance fields
.field final actual:Lu7/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/a<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lu7/a;Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-TT;>;",
            "Ljava/util/Iterator<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-direct {p0, p2}, Lio/reactivex/internal/operators/flowable/d1$a;-><init>(Ljava/util/Iterator;)V

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/d1$b;->actual:Lu7/a;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@/sn@l@  ~@ ~M~ @a@~fo t41~~~~fco@ ~u@@ @v~ @@ mK i ~-b~@ /@bo@oi~S@ tbo~~~~sy ~o d~@ r. ~i@~@~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v4, 0x2

    move v5, v4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d1$b;->actual:Lu7/a;

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :cond_1
    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v3, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v5, 0x5

    const-string v2, "Ilrmuteetdr ).n e utsvnola ueaernltxr"

    const-string v2, "ntsunlu uea.er ldvtnlaeexI r)rttr oae"

    const/4 v5, 0x3

    const-string v2, "a(taoxatln nvn.er elut Iuetu elerdr)r"

    const-string v2, "Iterator.next() returned a null value"

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    return-void

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1, v2}, Lu7/a;->o(Ljava/lang/Object;)Z

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v2, :cond_4

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    return-void

    :cond_4
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_5

    const/4 v4, 0x2

    move v5, v4

    invoke-interface {v1}, Lja/c;->onComplete()V

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void

    :catchall_1
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method

.method b(J)V
    .locals 10

    const/4 v9, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/d1$a;->it:Ljava/util/Iterator;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/d1$b;->actual:Lu7/a;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :cond_0
    move-wide v4, v2

    :cond_1
    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    cmp-long v6, v4, p1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v6, :cond_8

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-boolean v6, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v6, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x7

    return-void

    :cond_2
    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-boolean v7, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v7, :cond_3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    return-void

    :cond_3
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v6, :cond_4

    const/4 v9, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo p2, "trx.abela(rtmveod )u lnten reItuaulnr"

    const-string p2, "rl.mIvtr)totue r(ulxleu  neaaend ntra"

    const/4 v9, 0x3

    const-string p2, " exdaru Irtleanvoerluunu() aerentl tt"

    const-string p2, "Iterator.next() returned a null value"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v1, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    return-void

    :cond_4
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {v1, v6}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-boolean v7, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz v7, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-void

    :cond_5
    :try_start_1
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-nez v7, :cond_7

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/d1$a;->cancelled:Z

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-nez p1, :cond_6

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {v1}, Lja/c;->onComplete()V

    :cond_6
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    return-void

    :cond_7
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-eqz v6, :cond_1

    const/4 v8, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v9, 0x0

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v8, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    add-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {v1, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x6

    return-void

    :catchall_1
    move-exception p1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v1, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    return-void

    :cond_8
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    cmp-long v6, v4, p1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-nez v6, :cond_1

    const/4 v8, 0x0

    move v9, v8

    neg-long p1, v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    cmp-long v4, p1, v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez v4, :cond_0

    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    return-void
.end method
