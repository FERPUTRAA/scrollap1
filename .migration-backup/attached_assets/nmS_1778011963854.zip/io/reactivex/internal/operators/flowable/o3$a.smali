.class final Lio/reactivex/internal/operators/flowable/o3$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/o3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Lio/reactivex/internal/subscriptions/o;

.field d:Z


# direct methods
.method constructor <init>(Lja/c;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o3$a;->a:Lja/c;

    const/4 v1, 0x1

    const/4 v0, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o3$a;->b:Lja/b;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x4

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/o3$a;->d:Z

    const/4 v1, 0x7

    const/4 v0, 0x4

    new-instance p1, Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p1}, Lio/reactivex/internal/subscriptions/o;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o3$a;->c:Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b s~~@ @ n~ ~~~~@o~o~ @@~~~~i41-@@ bf s@@@od~l~. y@om@~f ~/t@M~  l~ur ~ac @ b/i@ @~t@v Sio@@o@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->d:Z

    const/4 v1, 0x5

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v0, 0x0

    move v2, v0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->d:Z

    :cond_0
    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->a:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->b:Lja/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Lja/b;->j(Lja/c;)V

    const/4 v1, 0x2

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->a:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->a:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o3$a;->c:Lio/reactivex/internal/subscriptions/o;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method
