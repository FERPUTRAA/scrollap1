.class final Lio/reactivex/internal/operators/flowable/h0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field b:Lja/d;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "o.s ~ib4 @u1  @~to@~@s @/@~ o l~ ~@~@ ~t o ~ ~@~f ~l@~@~v@b~r@/f~m@@ o -Kc~~M~ni@dia@~@ y So~b~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v1, Lio/reactivex/internal/util/h;->a:Lio/reactivex/internal/util/h;

    const/4 v3, 0x7

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lio/reactivex/internal/util/h;->c()Lja/c;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x4

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v1, Lio/reactivex/internal/util/h;->a:Lio/reactivex/internal/util/h;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {}, Lio/reactivex/internal/util/h;->c()Lja/c;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object v1, Lio/reactivex/internal/util/h;->a:Lio/reactivex/internal/util/h;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {}, Lio/reactivex/internal/util/h;->c()Lja/c;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->b:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h0$a;->a:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
