.class final Lio/reactivex/internal/operators/flowable/h$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:[Lio/reactivex/internal/operators/flowable/h$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lio/reactivex/internal/operators/flowable/h$b<",
            "TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lja/c;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;I)V"
        }
    .end annotation

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h$a;->a:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-array p1, p2, [Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h$a;->b:[Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a([Lja/b;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->b:[Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    array-length v1, v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x3

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x0

    if-ge v3, v1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    new-instance v4, Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    add-int/lit8 v5, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/h$a;->a:Lja/c;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v4, p0, v5, v6}, Lio/reactivex/internal/operators/flowable/h$b;-><init>(Lio/reactivex/internal/operators/flowable/h$a;ILja/c;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    aput-object v4, v0, v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    move v3, v5

    move v3, v5

    const/4 v8, 0x0

    move v3, v5

    move v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v3, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->lazySet(I)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h$a;->a:Lja/c;

    const/4 v8, 0x2

    invoke-interface {v3, p0}, Lja/c;->q(Lja/d;)V

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-ge v2, v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v3, :cond_1

    const/4 v7, 0x6

    move v8, v7

    return-void

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    aget-object v3, p1, v2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    aget-object v4, v0, v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-interface {v3, v4}, Lja/b;->j(Lja/c;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_1

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    return-void
.end method

.method public b(I)Z
    .locals 6

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v1, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->b:[Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v5, 0x7

    array-length v2, v0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-ge v1, v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/lit8 v3, v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq v3, p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    aget-object v1, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1}, Lio/reactivex/internal/operators/flowable/h$b;->cancel()V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    move v1, v3

    move v1, v3

    const/4 v5, 0x5

    move v1, v3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x6

    return p1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    return v1
.end method

.method public cancel()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v0, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->lazySet(I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->b:[Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ge v2, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    aget-object v3, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3}, Lio/reactivex/internal/operators/flowable/h$b;->cancel()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method public g(J)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-lez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h$a;->b:[Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    aget-object v0, v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, p1, p2}, Lio/reactivex/internal/operators/flowable/h$b;->g(J)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h$a;->b:[Lio/reactivex/internal/operators/flowable/h$b;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    array-length v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ge v2, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    aget-object v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v3, p1, p2}, Lio/reactivex/internal/operators/flowable/h$b;->g(J)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void
.end method
