.class final Lio/reactivex/internal/operators/flowable/s2$b;
.super Ljava/lang/Object;

# interfaces
.implements Lja/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/s2;->j8(Ljava/util/concurrent/Callable;Lt7/o;)Lio/reactivex/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lja/b<",
        "TR;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/Callable;

.field final synthetic b:Lt7/o;


# direct methods
.method constructor <init>(Ljava/util/concurrent/Callable;Lt7/o;)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$b;->a:Ljava/util/concurrent/Callable;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s2$b;->b:Lt7/o;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public j(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s~l~SMs@~a4@~ @b-/@ ~ f ~@/@@~@lt~ir~~~@~1byt @ionvfo~ob~~m@  @ c~ ~@@~~ K i@o ~@ .u@@ @~ oo~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$b;->a:Ljava/util/concurrent/Callable;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "ycumrTlcdcnne Ft ne noeaetultsbealro"

    const-string v1, "aosonu eaTtntdnulcl Fnccytble rehree"

    const/4 v4, 0x4

    const-string v1, "al doF rrlynbteclrea eeoconntuTchuet"

    const-string v1, "The connectableFactory returned null"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast v0, Lio/reactivex/flowables/a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s2$b;->b:Lt7/o;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1, v0}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v2, "eh eibrc nPlerts lrmsoeelnruh dal eubt"

    const-string v2, "ei mcotraruerheetdhessnnl  ul ePTr bll"

    const/4 v4, 0x5

    const-string v2, " inPesulue tele uhoaTtl renru lscrdheb"

    const-string v2, "The selector returned a null Publisher"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast v1, Lja/b;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v2, Lio/reactivex/internal/subscribers/u;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v2, p1}, Lio/reactivex/internal/subscribers/u;-><init>(Lja/c;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance p1, Lio/reactivex/internal/operators/flowable/s2$b$a;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p1, p0, v2}, Lio/reactivex/internal/operators/flowable/s2$b$a;-><init>(Lio/reactivex/internal/operators/flowable/s2$b;Lio/reactivex/internal/subscribers/u;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lio/reactivex/flowables/a;->c8(Lt7/g;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v4, 0x6

    return-void

    :catchall_1
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method
