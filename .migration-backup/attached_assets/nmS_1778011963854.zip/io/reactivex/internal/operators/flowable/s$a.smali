.class final Lio/reactivex/internal/operators/flowable/s$a;
.super Lio/reactivex/internal/subscriptions/f;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/f<",
        "TU;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x31d0a4e7db0f306eL


# instance fields
.field final collector:Lt7/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/b<",
            "-TU;-TT;>;"
        }
    .end annotation
.end field

.field done:Z

.field s:Lja/d;

.field final u:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TU;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Ljava/lang/Object;Lt7/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;TU;",
            "Lt7/b<",
            "-TU;-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/s$a;->collector:Lt7/b;

    const/4 v0, 0x5

    move v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s$a;->u:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "-@s@lb~ @@@ u@@ ~~l~Kns a/~ 1 tii~  ~@~M ~ @~~@~/ oy~~ov@4c@f oo~t@@ @@ofi@~ rb~@ ~dmb@@~ o~. S~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/f;->cancel()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->s:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->done:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    move v3, v2

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->collector:Lt7/b;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/s$a;->u:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v0, v1, p1}, Lt7/b;->accept(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    move v3, v2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->s:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/s$a;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->u:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->done:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s$a;->s:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s$a;->s:Lja/d;

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method
