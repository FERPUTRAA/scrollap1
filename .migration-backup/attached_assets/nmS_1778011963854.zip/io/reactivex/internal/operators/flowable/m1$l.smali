.class final Lio/reactivex/internal/operators/flowable/m1$l;
.super Ljava/lang/Object;

# interfaces
.implements Lt7/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "l"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "S:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lt7/c<",
        "TS;",
        "Lio/reactivex/j<",
        "TT;>;TS;>;"
    }
.end annotation


# instance fields
.field final a:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "Lio/reactivex/j<",
            "TT;>;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lt7/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/g<",
            "Lio/reactivex/j<",
            "TT;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$l;->a:Lt7/g;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;Lio/reactivex/j;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TS;",
            "Lio/reactivex/j<",
            "TT;>;)TS;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$l;->a:Lt7/g;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    invoke-interface {v0, p2}, Lt7/g;->accept(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    check-cast p2, Lio/reactivex/j;

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/m1$l;->a(Ljava/lang/Object;Lio/reactivex/j;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method
