.class final Lio/reactivex/internal/operators/flowable/g4$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/g4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x20d478356927aeadL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field final bufferSize:I

.field done:Z

.field index:J

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field s:Lja/d;

.field final size:J

.field window:Lio/reactivex/processors/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/processors/g<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;JI)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;JI)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->actual:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/g4$a;->size:J

    const/4 v2, 0x2

    const/4 v1, 0x5

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p4, p0, Lio/reactivex/internal/operators/flowable/g4$a;->bufferSize:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s Sb@ Mi ~ lf@@~@o4~~~a@  ~roi~~~o@od@@b~~s~.bK~ @-lm~y   f@@n @@~ui~1/@ot~v  @ ~~~@@/~@  oc@t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/g4$a;->run()V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->done:Z

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-eqz v0, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->index:J

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x3

    cmp-long v5, v0, v3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-nez v5, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget v2, p0, Lio/reactivex/internal/operators/flowable/g4$a;->bufferSize:I

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v2, p0}, Lio/reactivex/processors/g;->g8(ILjava/lang/Runnable;)Lio/reactivex/processors/g;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput-object v2, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/g4$a;->actual:Lja/c;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v5, v2}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x3

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    add-long/2addr v0, v5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v2, p1}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/g4$a;->size:J

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    cmp-long p1, v0, v5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-nez p1, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput-wide v3, p0, Lio/reactivex/internal/operators/flowable/g4$a;->index:J

    const/4 p1, 0x0

    xor-int/2addr v8, p1

    move v7, p1

    move v7, p1

    const/4 v8, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v7, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    goto :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x7

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->index:J

    :goto_0
    const/4 v8, 0x0

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->size:J

    const/4 v3, 0x3

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->s:Lja/d;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x0

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->done:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->window:Lio/reactivex/processors/g;

    const/4 v2, 0x4

    move v3, v2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->actual:Lja/c;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->s:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->s:Lja/d;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/g4$a;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public run()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/g4$a;->s:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method
