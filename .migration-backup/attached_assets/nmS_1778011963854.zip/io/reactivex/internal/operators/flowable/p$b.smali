.class final Lio/reactivex/internal/operators/flowable/p$b;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/c;
.implements Lja/d;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;TU;TU;>;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final A0:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TB;>;"
        }
    .end annotation
.end field

.field B0:Lja/d;

.field C0:Lio/reactivex/disposables/c;

.field D0:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TU;"
        }
    .end annotation
.end field

.field final k0:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Ljava/util/concurrent/Callable;Lja/b;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;",
            "Lja/b<",
            "TB;>;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/p$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/p$b;->A0:Lja/b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c~s ~.t~ tS@@@~~~@oau@@ b@/  n ~~@@~/~~@ io~ ~~l~o-~~@ y@~r os ~K1Mi~@  @oo@bl~@m@  ff @b@ v4@di"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    move v2, v1

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->C0:Lio/reactivex/disposables/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->B0:Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Lu7/o;->clear()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p$b;->cancel()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->D0:Ljava/util/Collection;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    monitor-exit p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    throw p1
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method

.method public bridge synthetic k(Lja/c;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    check-cast p2, Ljava/util/Collection;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/p$b;->t(Lja/c;Ljava/util/Collection;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->D0:Ljava/util/Collection;

    const/4 v4, 0x1

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/p$b;->D0:Ljava/util/Collection;

    const/4 v4, 0x5

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v1, v0}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0, v1, v2, p0, p0}, Lio/reactivex/internal/util/u;->f(Lu7/o;Lja/c;ZLio/reactivex/disposables/c;Lio/reactivex/internal/util/t;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    throw v0
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p$b;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->B0:Lja/d;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p$b;->B0:Lja/d;

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, "rlsmpdTlebufhus  e epfuli i"

    const-string v1, "The buffer supplied is null"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->D0:Ljava/util/Collection;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Lio/reactivex/internal/operators/flowable/p$a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/flowable/p$a;-><init>(Lio/reactivex/internal/operators/flowable/p$b;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->C0:Lio/reactivex/disposables/c;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v1, p0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v4, 0x4

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-interface {p1, v1, v2}, Lja/d;->g(J)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p$b;->A0:Lja/b;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    return-void
.end method

.method public t(Lja/c;Ljava/util/Collection;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;TU;)Z"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget-object p1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-interface {p1, p2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method

.method u()V
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, "l rsoledufsuh lTpibsepf ni "

    const-string v1, "ersniplilsTu fpbf du lehes "

    const/4 v3, 0x2

    const-string/jumbo v1, "ulnl bT p pfissbul euhredei"

    const-string v1, "The buffer supplied is null"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    monitor-enter p0

    :try_start_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/p$b;->D0:Ljava/util/Collection;

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p$b;->D0:Ljava/util/Collection;

    const/4 v2, 0x0

    move v3, v2

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, v1, v0, p0}, Lio/reactivex/internal/subscribers/n;->p(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw v0

    :catchall_1
    move-exception v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/p$b;->cancel()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method
