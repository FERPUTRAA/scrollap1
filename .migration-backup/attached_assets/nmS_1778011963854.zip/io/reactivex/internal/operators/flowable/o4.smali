.class public final Lio/reactivex/internal/operators/flowable/o4;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/o4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TV;>;"
    }
.end annotation


# instance fields
.field final b:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "TU;>;"
        }
    .end annotation
.end field

.field final d:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT;-TU;+TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/lang/Iterable;Lt7/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+TT;>;",
            "Ljava/lang/Iterable<",
            "TU;>;",
            "Lt7/c<",
            "-TT;-TU;+TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o4;->b:Lja/b;

    const/4 v1, 0x6

    const/4 v0, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o4;->c:Ljava/lang/Iterable;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/o4;->d:Lt7/c;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TV;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "casK@@ 4doi@f@ oo M@no@~~@~~~ /@s1/o~@@tbS@~ u~~~@~l   .y @~i@-r~l bm@  ~~~~  f~@@~@ @t @~ ~ib~o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o4;->c:Ljava/lang/Iterable;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, "soim hltrtsyt riroaehtd  bnrenr  eulee"

    const-string v1, "ensTiuortb l ernhrrath   yireeteldst o"

    const/4 v5, 0x7

    const-string v1, "nrTtoabeode etir sil ltuyh t ohru rrne"

    const-string v1, "The iterator returned by other is null"

    const/4 v4, 0x5

    move v5, v4

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast v0, Ljava/util/Iterator;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/g;->a(Lja/c;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o4;->b:Lja/b;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v2, Lio/reactivex/internal/operators/flowable/o4$a;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/o4;->d:Lt7/c;

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v2, p1, v0, v3}, Lio/reactivex/internal/operators/flowable/o4$a;-><init>(Lja/c;Ljava/util/Iterator;Lt7/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :catchall_1
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void
.end method
