.class public final Lio/reactivex/internal/operators/flowable/h;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/h$b;,
        Lio/reactivex/internal/operators/flowable/h$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:[Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lja/b<",
            "+TT;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>([Lja/b;Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lja/b<",
            "+TT;>;",
            "Ljava/lang/Iterable<",
            "+",
            "Lja/b<",
            "+TT;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h;->b:[Lja/b;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h;->c:Ljava/lang/Iterable;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " ys@ ~K fb~b@~@/~@ to~o@b@~~ @o  ~av~~~@i~nr.~fs l mMu@i ~@@ ~o-o@ @o S@@~t~1c~ ~ l4~ @@~@di@~ @"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h;->b:[Lja/b;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez v0, :cond_2

    const/4 v7, 0x3

    const/16 v0, 0x8

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-array v0, v0, [Lja/b;

    :try_start_0
    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/h;->c:Ljava/lang/Iterable;

    const/4 v6, 0x1

    move v7, v6

    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    move v3, v1

    move v3, v1

    const/4 v7, 0x0

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v4, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    check-cast v4, Lja/b;

    const/4 v7, 0x4

    if-nez v4, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string v1, "n  m slelthucoO srsuenf oi"

    const-string v1, "cls nu Ot eiofsn sul herso"

    const/4 v7, 0x2

    const-string v1, "noeeou  ei hcls sOnruotsfl"

    const-string v1, "One of the sources is null"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    array-length v5, v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne v3, v5, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    shr-int/lit8 v5, v3, 0x2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    add-int/2addr v5, v3

    const/4 v7, 0x6

    new-array v5, v5, [Lja/b;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v0, v1, v5, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    move-object v0, v5

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    add-int/lit8 v5, v3, 0x1

    const/4 v7, 0x1

    aput-object v4, v0, v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v3, v5

    move v3, v5

    move v3, v5

    move v3, v5

    const/4 v6, 0x1

    move v7, v6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-void

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    array-length v3, v0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-nez v3, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/g;->a(Lja/c;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    return-void

    :cond_4
    const/4 v6, 0x3

    move v7, v6

    const/4 v2, 0x1

    move v7, v2

    const/4 v6, 0x5

    and-int/2addr v7, v6

    if-ne v3, v2, :cond_5

    const/4 v7, 0x1

    aget-object v0, v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-interface {v0, p1}, Lja/b;->j(Lja/c;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    return-void

    :cond_5
    const/4 v7, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/h$a;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {v1, p1, v3}, Lio/reactivex/internal/operators/flowable/h$a;-><init>(Lja/c;I)V

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v1, v0}, Lio/reactivex/internal/operators/flowable/h$a;->a([Lja/b;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    return-void
.end method
