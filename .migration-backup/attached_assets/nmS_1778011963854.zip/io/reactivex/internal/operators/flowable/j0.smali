.class public final Lio/reactivex/internal/operators/flowable/j0;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/j0$a;,
        Lio/reactivex/internal/operators/flowable/j0$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "K:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;TK;>;"
        }
    .end annotation
.end field

.field final d:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-TK;-TK;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lt7/o;Lt7/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/o<",
            "-TT;TK;>;",
            "Lt7/d<",
            "-TK;-TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/j0;->c:Lt7/o;

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/j0;->d:Lt7/d;

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    instance-of v0, p1, Lu7/a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    check-cast p1, Lu7/a;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Lio/reactivex/internal/operators/flowable/j0$a;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j0;->c:Lt7/o;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/j0;->d:Lt7/d;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v1, p1, v2, v3}, Lio/reactivex/internal/operators/flowable/j0$a;-><init>(Lu7/a;Lt7/o;Lt7/d;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v1, Lio/reactivex/internal/operators/flowable/j0$b;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j0;->c:Lt7/o;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/j0;->d:Lt7/d;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v1, p1, v2, v3}, Lio/reactivex/internal/operators/flowable/j0$b;-><init>(Lja/c;Lt7/o;Lt7/d;)V

    const/4 v4, 0x6

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void
.end method
