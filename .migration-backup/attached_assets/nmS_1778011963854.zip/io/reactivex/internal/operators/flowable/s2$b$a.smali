.class Lio/reactivex/internal/operators/flowable/s2$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Lt7/g;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/s2$b;->j(Lja/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lt7/g<",
        "Lio/reactivex/disposables/c;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/internal/subscribers/u;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/s2$b;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/s2$b;Lio/reactivex/internal/subscribers/u;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$b$a;->b:Lio/reactivex/internal/operators/flowable/s2$b;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s2$b$a;->a:Lio/reactivex/internal/subscribers/u;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@ .~@i ~b ~so~iiod4c~ K1M @ @@y~@tbl ~@ouf@a~fl~o~o @~ t~ @~b ~ ~m~-@@n  o~S@~@@~  v@ ~@@r@~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$b$a;->a:Lio/reactivex/internal/subscribers/u;

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscribers/u;->b(Lio/reactivex/disposables/c;)V

    const/4 v1, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic accept(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    check-cast p1, Lio/reactivex/disposables/c;

    const/4 v0, 0x4

    move v1, v0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/s2$b$a;->a(Lio/reactivex/disposables/c;)V

    const/4 v1, 0x6

    return-void
.end method
