.class public final Lio/reactivex/internal/operators/flowable/b1;
.super Lio/reactivex/k;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/k<",
        "TT;>;",
        "Ljava/util/concurrent/Callable<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b1;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~vsM~~ @b@~/ufm@ ~o@@@S~ @b y@~rl~to.o is@ @~@~o~@ i~b1~~ i@@ ~~@ ld~@~@@@t /   ~fo4  ~c-on~a ~K"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lio/reactivex/internal/subscriptions/f;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/b1;->b:Ljava/util/concurrent/Callable;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v2, "T  mnurhetlc ee daealulueallalvs n"

    const-string v2, "lusv al  urahal ee elltndcuTerlean"

    const/4 v4, 0x6

    const-string v2, "Taa oeervul  caetl dnhrlaneuelul l"

    const-string v2, "The callable returned a null value"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method public call()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b1;->b:Ljava/util/concurrent/Callable;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "av  ublae l lmde eraelTlcnuaelnurt"

    const-string v1, "lalmu c elll neeve arteT aduuarlbn"

    const/4 v3, 0x4

    const-string v1, "rteabeul uvh elTcllnuu aerl dnaa e"

    const-string v1, "The callable returned a null value"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method
