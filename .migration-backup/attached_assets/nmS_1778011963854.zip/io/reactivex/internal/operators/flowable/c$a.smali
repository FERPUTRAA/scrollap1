.class final Lio/reactivex/internal/operators/flowable/c$a;
.super Lio/reactivex/subscribers/b;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "Lio/reactivex/w<",
        "TT;>;>;",
        "Ljava/util/Iterator<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final b:Ljava/util/concurrent/Semaphore;

.field final c:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/w<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field d:Lio/reactivex/w;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/w<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->b:Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public bridge synthetic f(Ljava/lang/Object;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " msa @  y~@r ob@M/@~i@@@~@di4@~~~tuc/@~ ~@S~~l @~ ~~~-@ ~@~ ~@ @v1oo.@l ~  fo~i@~tf s~o@~@Kbob  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p1, Lio/reactivex/w;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/c$a;->g(Lio/reactivex/w;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public g(Lio/reactivex/w;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/w<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/c$a;->b:Ljava/util/concurrent/Semaphore;

    invoke-virtual {p1}, Ljava/util/concurrent/Semaphore;->release()V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public hasNext()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Lio/reactivex/w;->g()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lio/reactivex/w;->d()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw v0

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/reactivex/w;->h()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_4

    :cond_2
    const/4 v2, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x3

    if-nez v0, :cond_4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lio/reactivex/internal/util/e;->b()V

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->b:Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->c:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Lio/reactivex/w;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/reactivex/w;->g()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v1, :cond_3

    goto :goto_1

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/reactivex/w;->d()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    throw v0

    :catch_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lio/reactivex/subscribers/b;->e()V

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0}, Lio/reactivex/w;->b(Ljava/lang/Throwable;)Lio/reactivex/w;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw v0

    :cond_4
    :goto_1
    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lio/reactivex/w;->h()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v0
.end method

.method public next()Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/c$a;->hasNext()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-virtual {v0}, Lio/reactivex/w;->h()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Lio/reactivex/w;->e()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/c$a;->d:Lio/reactivex/w;

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x3

    throw v0
.end method

.method public onComplete()V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v0, 0x5

    or-int/2addr v1, v0

    return-void
.end method

.method public remove()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v1, "rRamelsne-td.i yaro"

    const-string v1, "atsr Ryaneo-edoi.rl"

    const/4 v3, 0x1

    const-string v1, "t.-lodiReaonretyoa "

    const-string v1, "Read-only iterator."

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v0
.end method
