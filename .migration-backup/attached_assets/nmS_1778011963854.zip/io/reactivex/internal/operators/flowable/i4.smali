.class public final Lio/reactivex/internal/operators/flowable/i4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/i4$a;,
        Lio/reactivex/internal/operators/flowable/i4$b;,
        Lio/reactivex/internal/operators/flowable/i4$d;,
        Lio/reactivex/internal/operators/flowable/i4$c;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;",
        "Lio/reactivex/k<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final c:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TB;>;"
        }
    .end annotation
.end field

.field final d:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TB;+",
            "Lja/b<",
            "TV;>;>;"
        }
    .end annotation
.end field

.field final e:I


# direct methods
.method public constructor <init>(Lja/b;Lja/b;Lt7/o;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "TB;>;",
            "Lt7/o<",
            "-TB;+",
            "Lja/b<",
            "TV;>;>;I)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i4;->c:Lja/b;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/i4;->d:Lt7/o;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p4, p0, Lio/reactivex/internal/operators/flowable/i4;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "r~s i.nt ~ @~a@ l o@@ @@m@b4@@@/@ ~ ~ ob@i v o@~@@s~b~@~~@~S @  ofo~~~~~-o@/1lyu~ d M@K i~~~~fc~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i4;->c:Lja/b;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/i4;->d:Lt7/o;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v4, p0, Lio/reactivex/internal/operators/flowable/i4;->e:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v1, v2, p1, v3, v4}, Lio/reactivex/internal/operators/flowable/i4$c;-><init>(Lja/c;Lja/b;Lt7/o;I)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x2

    const/4 v5, 0x5

    return-void
.end method
