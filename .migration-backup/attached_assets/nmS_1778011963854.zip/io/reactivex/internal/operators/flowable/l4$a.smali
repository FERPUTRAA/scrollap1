.class Lio/reactivex/internal/operators/flowable/l4$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/l4;->H5(Lja/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lja/c<",
        "TU;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/internal/operators/flowable/l4$b;

.field final synthetic b:Lio/reactivex/internal/operators/flowable/l4;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/l4;Lio/reactivex/internal/operators/flowable/l4$b;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l4$a;->b:Lio/reactivex/internal/operators/flowable/l4;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l4$a;->a:Lio/reactivex/internal/operators/flowable/l4$b;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@d~@~~ ~.~1 - ~@ i~~ o @@@@@@ i ~My@4 @S@/ @tv ~ ~lo~@o@@@of @~i~lt~a~b~fn@b~ocm @rKb/s o~u~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$a;->a:Lio/reactivex/internal/operators/flowable/l4$b;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->lazySet(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$a;->a:Lio/reactivex/internal/operators/flowable/l4$b;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/l4$b;->a(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$a;->a:Lio/reactivex/internal/operators/flowable/l4$b;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/l4$b;->b(Lja/d;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method
