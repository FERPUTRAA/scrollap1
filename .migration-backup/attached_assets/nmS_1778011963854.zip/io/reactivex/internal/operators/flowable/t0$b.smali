.class final Lio/reactivex/internal/operators/flowable/t0$b;
.super Lio/reactivex/internal/subscribers/b;

# interfaces
.implements Lu7/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/t0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/b<",
        "TT;TT;>;",
        "Lu7/a<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final f:Lt7/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/r<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/r;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/r<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/b;-><init>(Lja/c;)V

    const/4 v0, 0x3

    shr-int/2addr v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/t0$b;->f:Lt7/r;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~asfb@~Sl~ ~@vb @f . ~~Ko~d~~~~ ru@4@M  @ ~~/ol@@~   @@cio~y~-@m@@1bio~ o@  /@@~n~@@s@o~  t@ti~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/t0$b;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p0, Lio/reactivex/internal/subscribers/b;->b:Lja/d;

    const/4 v2, 0x7

    move v3, v2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->d(I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p1
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v3, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    return p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return v1

    :cond_1
    :try_start_0
    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/t0$b;->f:Lt7/r;

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lt7/r;->test(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v1, p1}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->c(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v1
.end method

.method public poll()Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->c:Lu7/l;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/t0$b;->f:Lt7/r;

    :cond_0
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x7

    return-object v0

    :cond_1
    const/4 v4, 0x4

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Lt7/r;->test(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v3, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object v2

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v2, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-ne v2, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v0, v2, v3}, Lja/d;->g(J)V

    const/4 v5, 0x2

    goto :goto_0
.end method
