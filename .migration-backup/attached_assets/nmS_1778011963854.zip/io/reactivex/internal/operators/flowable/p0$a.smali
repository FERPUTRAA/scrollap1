.class final Lio/reactivex/internal/operators/flowable/p0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/p0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/r<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:J

.field c:Lja/d;

.field d:J

.field e:Z


# direct methods
.method constructor <init>(Lio/reactivex/r;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/r<",
            "-TT;>;J)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p0$a;->a:Lio/reactivex/r;

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/p0$a;->b:J

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~su@1@~~~mo@@f~~n@co@@@o @@s MS~ /v @t l/ bi d~l~~@~ @~a ~ ~-~.@@~ o@~@ b@@  ~to~4r ifyi~ K @o~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v1, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->e:Z

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->d:J

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/p0$a;->b:J

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    cmp-long v2, v0, v2

    const/4 v5, 0x2

    if-nez v2, :cond_1

    const/4 v5, 0x5

    const/4 v0, 0x7

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->e:Z

    const/4 v5, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v5, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->a:Lio/reactivex/r;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v0, p1}, Lio/reactivex/r;->onSuccess(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v5, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x0

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-long/2addr v0, v2

    const/4 v5, 0x5

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->d:J

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->e:Z

    const/4 v1, 0x3

    move v2, v1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->e:Z

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->a:Lio/reactivex/r;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/r;->onComplete()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lio/reactivex/internal/subscriptions/p;->a:Lio/reactivex/internal/subscriptions/p;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->a:Lio/reactivex/r;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lio/reactivex/r;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p0$a;->c:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p0$a;->a:Lio/reactivex/r;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {v0, p0}, Lio/reactivex/r;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x4

    return-void
.end method
