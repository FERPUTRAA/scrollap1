.class public final Lio/reactivex/internal/operators/flowable/e2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/e2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+",
            "Lja/b<",
            "+TT;>;>;"
        }
    .end annotation
.end field

.field final d:Z


# direct methods
.method public constructor <init>(Lja/b;Lt7/o;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+",
            "Lja/b<",
            "+TT;>;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/e2;->c:Lt7/o;

    const/4 v1, 0x1

    const/4 v0, 0x1

    iput-boolean p3, p0, Lio/reactivex/internal/operators/flowable/e2;->d:Z

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "t4so@@~@@/@ ~i~~t~@o ~ ~ @v~~K~@@@m1@@/duyi~ @f  ~ i@bbnb@ s@S r -.~~~o~ @ll ~ ~aoc@f~M~@@ ~oo  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lio/reactivex/internal/operators/flowable/e2$a;

    const/4 v3, 0x3

    or-int/2addr v4, v3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/e2;->c:Lt7/o;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/e2;->d:Z

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {v0, p1, v1, v2}, Lio/reactivex/internal/operators/flowable/e2$a;-><init>(Lja/c;Lt7/o;Z)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/e2$a;->d:Lio/reactivex/internal/subscriptions/o;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method
