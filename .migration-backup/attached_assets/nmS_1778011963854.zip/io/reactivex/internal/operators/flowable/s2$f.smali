.class final Lio/reactivex/internal/operators/flowable/s2$f;
.super Ljava/lang/Object;

# interfaces
.implements Lja/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/s2;->h8(Lja/b;Ljava/util/concurrent/Callable;)Lio/reactivex/flowables/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lja/b<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/atomic/AtomicReference;

.field final synthetic b:Ljava/util/concurrent/Callable;


# direct methods
.method constructor <init>(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/Callable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$f;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s2$f;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public j(Lja/c;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    :goto_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "l s ~@m @@@ /@ ~-S n~o@ ~ i ~@~~io~u~l@t@4 bM@~bf~@@ ~   1~@odo ~r@@/~@@~y~~ f@.~c~oaK@~si bto@v"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$f;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    check-cast v0, Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_1

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$f;->b:Ljava/util/concurrent/Callable;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v0, Lio/reactivex/internal/operators/flowable/s2$j;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/s2$k;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1, v0}, Lio/reactivex/internal/operators/flowable/s2$k;-><init>(Lio/reactivex/internal/operators/flowable/s2$j;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$f;->a:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0, v2, v1}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    move-object v0, v1

    move-object v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {p1}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw p1

    :cond_1
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/s2$h;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v1, v0, p1}, Lio/reactivex/internal/operators/flowable/s2$h;-><init>(Lio/reactivex/internal/operators/flowable/s2$k;Lja/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/s2$k;->b(Lio/reactivex/internal/operators/flowable/s2$h;)Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Lio/reactivex/internal/operators/flowable/s2$h;->a()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lio/reactivex/internal/operators/flowable/s2$k;->d(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/s2$k;->c()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object p1, v0, Lio/reactivex/internal/operators/flowable/s2$k;->a:Lio/reactivex/internal/operators/flowable/s2$j;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {p1, v1}, Lio/reactivex/internal/operators/flowable/s2$j;->e(Lio/reactivex/internal/operators/flowable/s2$h;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void
.end method
