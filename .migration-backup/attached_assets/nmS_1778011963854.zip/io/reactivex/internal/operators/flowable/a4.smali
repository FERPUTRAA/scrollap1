.class public final Lio/reactivex/internal/operators/flowable/a4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/a4$c;,
        Lio/reactivex/internal/operators/flowable/a4$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# static fields
.field static final g:Lio/reactivex/disposables/c;


# instance fields
.field final c:J

.field final d:Ljava/util/concurrent/TimeUnit;

.field final e:Lio/reactivex/e0;

.field final f:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Lio/reactivex/internal/operators/flowable/a4$a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-direct {v0}, Lio/reactivex/internal/operators/flowable/a4$a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    sput-object v0, Lio/reactivex/internal/operators/flowable/a4;->g:Lio/reactivex/disposables/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Lja/b;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x4

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/a4;->c:J

    const/4 v1, 0x5

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/a4;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/a4;->e:Lio/reactivex/e0;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/a4;->f:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "n~s@d~~~@o~M~ tfilS   @~@oy i/~m~@@  ~~@@ ~~  @@.~@u~ a~@t~s@vr@~o@  b@o@ c1Klf  -4~@@i@b/bo~ ~~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a4;->f:Lja/b;

    const/4 v10, 0x3

    if-nez v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v10, 0x3

    const/4 v9, 0x6

    new-instance v7, Lio/reactivex/internal/operators/flowable/a4$c;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/a4;->c:J

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/a4;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a4;->e:Lio/reactivex/e0;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p1}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v6

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct/range {v1 .. v6}, Lio/reactivex/internal/operators/flowable/a4$c;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-interface {v0, v7}, Lja/b;->j(Lja/c;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v10, 0x2

    const/4 v9, 0x5

    new-instance v8, Lio/reactivex/internal/operators/flowable/a4$b;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/a4;->c:J

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/a4;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v10, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a4;->e:Lio/reactivex/e0;

    const/4 v9, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v1}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v6

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/a4;->f:Lja/b;

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-direct/range {v1 .. v7}, Lio/reactivex/internal/operators/flowable/a4$b;-><init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;Lja/b;)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-interface {v0, v8}, Lja/b;->j(Lja/c;)V

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    return-void
.end method
