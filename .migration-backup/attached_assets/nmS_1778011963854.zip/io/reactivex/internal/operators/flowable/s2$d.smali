.class final Lio/reactivex/internal/operators/flowable/s2$d;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/s2;->e8(Lja/b;I)Lio/reactivex/flowables/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable<",
        "Lio/reactivex/internal/operators/flowable/s2$j<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:I


# direct methods
.method constructor <init>(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lio/reactivex/internal/operators/flowable/s2$d;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public a()Lio/reactivex/internal/operators/flowable/s2$j;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lio/reactivex/internal/operators/flowable/s2$j<",
            "TT;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "o s@ na @~S~@b-fy ~@~o@ r@M@ ~@d ~@@~co~b~@ o~ /v~ ~s1@o4~ u@@  tK@~tm/~~ bo~i@@  .~l~@ ~ii~@l~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    new-instance v0, Lio/reactivex/internal/operators/flowable/s2$m;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, p0, Lio/reactivex/internal/operators/flowable/s2$d;->a:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, v1}, Lio/reactivex/internal/operators/flowable/s2$m;-><init>(I)V

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method public bridge synthetic call()Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/s2$d;->a()Lio/reactivex/internal/operators/flowable/s2$j;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method
