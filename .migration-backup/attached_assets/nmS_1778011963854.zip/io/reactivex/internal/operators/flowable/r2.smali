.class public final Lio/reactivex/internal/operators/flowable/r2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/r2$a;,
        Lio/reactivex/internal/operators/flowable/r2$c;,
        Lio/reactivex/internal/operators/flowable/r2$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-",
            "Lio/reactivex/k<",
            "Ljava/lang/Object;",
            ">;+",
            "Lja/b<",
            "*>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/o<",
            "-",
            "Lio/reactivex/k<",
            "Ljava/lang/Object;",
            ">;+",
            "Lja/b<",
            "*>;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/r2;->c:Lt7/o;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "i@soo4SyKs@ ~r~@a~@~ @~  @  t~~@b~i~ t~1@@@~o~@@ M@  @ l-b~ /v~.@bo@~u lo~ ~@id@co/~@ ~@~n  ~m~f"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    new-instance v0, Lio/reactivex/subscribers/e;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {v0, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v1, 0x8

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v1}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Lio/reactivex/processors/c;->c8()Lio/reactivex/processors/c;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/r2;->c:Lt7/o;

    const/4 v6, 0x3

    invoke-interface {v2, v1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v3, "slumhe uratees Puhlrnrna b ndrdll"

    const-string/jumbo v3, "uasnude r eub  rrnethalhldnPlirsl"

    const-string v3, "handler returned a null Publisher"

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-static {v2, v3}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    check-cast v2, Lja/b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v3, Lio/reactivex/internal/operators/flowable/r2$b;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v3, v4}, Lio/reactivex/internal/operators/flowable/r2$b;-><init>(Lja/b;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v4, Lio/reactivex/internal/operators/flowable/r2$a;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v4, v0, v1, v3}, Lio/reactivex/internal/operators/flowable/r2$a;-><init>(Lja/c;Lio/reactivex/processors/c;Lja/d;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    iput-object v4, v3, Lio/reactivex/internal/operators/flowable/r2$b;->subscriber:Lio/reactivex/internal/operators/flowable/r2$c;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {p1, v4}, Lja/c;->q(Lja/d;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v2, v3}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 p1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3, p1}, Lio/reactivex/internal/operators/flowable/r2$b;->f(Ljava/lang/Object;)V

    const/4 v5, 0x1

    and-int/2addr v6, v5

    return-void

    :catchall_0
    move-exception v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void
.end method
