.class final Lio/reactivex/internal/operators/flowable/k4$b;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/c;
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;",
        "Ljava/lang/Object;",
        "Lio/reactivex/k<",
        "TT;>;>;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# static fields
.field static final H0:Ljava/lang/Object;


# instance fields
.field final A0:Ljava/util/concurrent/TimeUnit;

.field final B0:Lio/reactivex/e0;

.field final C0:I

.field D0:Lja/d;

.field E0:Lio/reactivex/processors/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/processors/g<",
            "TT;>;"
        }
    .end annotation
.end field

.field final F0:Lio/reactivex/internal/disposables/k;

.field volatile G0:Z

.field final k0:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    sput-object v0, Lio/reactivex/internal/operators/flowable/k4$b;->H0:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x2

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p1, Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p1}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k4$b;->F0:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/k4$b;->k0:J

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/k4$b;->A0:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/k4$b;->B0:Lio/reactivex/e0;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput p6, p0, Lio/reactivex/internal/operators/flowable/k4$b;->C0:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@l~~@~ ~ @ yf~ -c@ .ivMo/d@ @~o @s @ S~ @ ~t@/ibb @ua~ @@o4r@@i@~@fo~~~K o~~o1  tm~@b~~@n~@~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->F0:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->G0:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->n()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 p1, -0x1

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez p1, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1}, Lio/reactivex/internal/util/p;->s(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez p1, :cond_2

    const/4 v2, 0x4

    return-void

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->t()V

    const/4 v2, 0x7

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->t()V

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->e()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->t()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 14

    const/4 v13, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->D0:Lja/d;

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-eqz v0, :cond_2

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k4$b;->D0:Lja/d;

    const/4 v13, 0x1

    const/4 v12, 0x4

    iget v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->C0:I

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-static {v0}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v0

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v1

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v13, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x6

    cmp-long v3, v1, v3

    const/4 v13, 0x7

    if-eqz v3, :cond_1

    const/4 v13, 0x4

    const/4 v12, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-interface {v0, v3}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x0

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    const/4 v13, 0x1

    const-wide v3, 0x7fffffffffffffffL

    const-wide v3, 0x7fffffffffffffffL

    const/4 v13, 0x1

    const/4 v12, 0x6

    cmp-long v0, v1, v3

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x0

    if-eqz v0, :cond_0

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x5

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v13, 0x3

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v13, 0x4

    const/4 v12, 0x1

    invoke-virtual {p0, v0, v1}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_0
    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x1

    if-nez v0, :cond_2

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->F0:Lio/reactivex/internal/disposables/k;

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x4

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/k4$b;->B0:Lio/reactivex/e0;

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x2

    iget-wide v9, p0, Lio/reactivex/internal/operators/flowable/k4$b;->k0:J

    const/4 v13, 0x3

    const/4 v12, 0x4

    iget-object v11, p0, Lio/reactivex/internal/operators/flowable/k4$b;->A0:Ljava/util/concurrent/TimeUnit;

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-wide v7, v9

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-virtual/range {v5 .. v11}, Lio/reactivex/e0;->h(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object v1

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-virtual {v0, v1}, Lio/reactivex/internal/disposables/k;->b(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x3

    if-eqz v0, :cond_2

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-interface {p1, v3, v4}, Lja/d;->g(J)V

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x5

    goto :goto_0

    :cond_1
    const/4 v13, 0x3

    const/4 v1, 0x6

    const/4 v13, 0x6

    const/4 v1, 0x1

    iput-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x7

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x7

    const-string v1, "kltmito dsw etuqlouw sf ouitror.ddsvcrdenia n l feso e "

    const-string v1, "o s   er kctdisfonswaldo.uweritequ t urtfnseiedolvo l d"

    const/4 v13, 0x7

    const-string v1, " u ko rofteeww d  oadsoolutc.qolt eurndsirt ev lediinfC"

    const-string v1, "Could not deliver first window due to lack of requests."

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-direct {p1, v1}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_2
    :goto_0
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x4

    return-void
.end method

.method public run()V
    .locals 4

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->G0:Z

    const/4 v3, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->e()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v1, Lio/reactivex/internal/operators/flowable/k4$b;->H0:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->t()V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method t()V
    .locals 12

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v3, 0x1

    :cond_0
    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/k4$b;->G0:Z

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v11, 0x0

    invoke-interface {v0}, Lu7/n;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v7, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v5, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    if-eqz v6, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x2

    sget-object v5, Lio/reactivex/internal/operators/flowable/k4$b;->H0:Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x3

    if-ne v6, v5, :cond_3

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    iput-object v7, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v11, 0x1

    invoke-interface {v0}, Lu7/o;->clear()V

    const/4 v11, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->e()V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v11, 0x3

    const/4 v10, 0x4

    if-eqz v0, :cond_2

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v2, v0}, Lio/reactivex/processors/g;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    goto :goto_1

    :cond_2
    const/4 v11, 0x5

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    :goto_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    return-void

    :cond_3
    const/4 v10, 0x6

    const/4 v11, 0x1

    if-nez v6, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    neg-int v3, v3

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p0, v3}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result v3

    const/4 v11, 0x4

    const/4 v10, 0x6

    if-nez v3, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    return-void

    :cond_4
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    sget-object v5, Lio/reactivex/internal/operators/flowable/k4$b;->H0:Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-ne v6, v5, :cond_7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-nez v4, :cond_6

    const/4 v11, 0x2

    iget v2, p0, Lio/reactivex/internal/operators/flowable/k4$b;->C0:I

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v2}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    iput-object v2, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v4

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    cmp-long v6, v4, v8

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-eqz v6, :cond_5

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-interface {v1, v2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const/4 v11, 0x2

    const-wide v6, 0x7fffffffffffffffL

    const-wide v6, 0x7fffffffffffffffL

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    cmp-long v4, v4, v6

    if-eqz v4, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x6

    invoke-virtual {p0, v4, v5}, Lio/reactivex/internal/subscribers/n;->l(J)J

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    iput-object v7, p0, Lio/reactivex/internal/operators/flowable/k4$b;->E0:Lio/reactivex/processors/g;

    const/4 v11, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-interface {v0}, Lu7/o;->clear()V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k4$b;->D0:Lja/d;

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v11, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/k4$b;->e()V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v0, Lio/reactivex/exceptions/c;

    const-string v2, "ltteebtr e kl do vddsoui .Cnwuts o ilfeusirdemcafwnroq "

    const-string v2, " enmf twr.itCds kiun  tstedcew l voq rflruloe eoaisdudo"

    const/4 v11, 0x5

    const-string v2, "Could not deliver first window due to lack of requests."

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-direct {v0, v2}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    return-void

    :cond_6
    const/4 v11, 0x0

    const/4 v10, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/k4$b;->D0:Lja/d;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-interface {v4}, Lja/d;->cancel()V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    goto/16 :goto_0

    :cond_7
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-static {v6}, Lio/reactivex/internal/util/p;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v2, v4}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto/16 :goto_0
.end method
