.class final Lio/reactivex/internal/operators/flowable/q$c;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;TU;TU;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# instance fields
.field final A0:J

.field final B0:J

.field final C0:Ljava/util/concurrent/TimeUnit;

.field final D0:Lio/reactivex/e0$c;

.field final E0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "TU;>;"
        }
    .end annotation
.end field

.field F0:Lja/d;

.field final k0:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Ljava/util/concurrent/Callable;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0$c;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/q$c;->k0:Ljava/util/concurrent/Callable;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-wide p3, p0, Lio/reactivex/internal/operators/flowable/q$c;->A0:J

    const/4 v2, 0x0

    const/4 v1, 0x4

    iput-wide p5, p0, Lio/reactivex/internal/operators/flowable/q$c;->B0:J

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p7, p0, Lio/reactivex/internal/operators/flowable/q$c;->C0:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p8, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Ljava/util/LinkedList;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p1}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method static synthetic u(Lio/reactivex/internal/operators/flowable/q$c;Ljava/lang/Object;ZLio/reactivex/disposables/c;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s lKi@f@@/t@ @/i f@~~ ~u@ ~~~~~vo.i@@~~m ~ ~~ @ @~br@S@~c@@@boo ~n@  tb oo s~ ~~-1y~ 4 al@oM@d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lio/reactivex/internal/subscribers/n;->r(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic v(Lio/reactivex/internal/operators/flowable/q$c;Ljava/lang/Object;ZLio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Lio/reactivex/internal/subscribers/n;->r(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$c;->w()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->F0:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v2, 0x3

    or-int/2addr v3, v2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v1, Ljava/util/Collection;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v1, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p1
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public bridge synthetic k(Lja/c;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p2, Ljava/util/Collection;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/q$c;->t(Lja/c;Ljava/util/Collection;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/List;->clear()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    check-cast v1, Ljava/util/Collection;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v2, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v2, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v5, 0x1

    invoke-static {v0, v1, v2, v3, p0}, Lio/reactivex/internal/util/u;->f(Lu7/o;Lja/c;ZLio/reactivex/disposables/c;Lio/reactivex/internal/util/t;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    throw v0
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v1, 0x7

    move v2, v1

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$c;->w()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public q(Lja/d;)V
    .locals 12

    const/4 v10, 0x1

    move v11, v10

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->F0:Lja/d;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-nez v0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    return-void

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$c;->F0:Lja/d;

    :try_start_0
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->k0:Ljava/util/concurrent/Callable;

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string v1, "fplmisenTeheuu psslldu  fib"

    const-string v1, "eussbneuslulppelfi hTdfi   "

    const/4 v11, 0x7

    const-string v1, "n hfodsuie sp rulelpeTu ibl"

    const-string v1, "The supplied buffer is null"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-interface {v1, p0}, Lja/c;->q(Lja/d;)V

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-wide v1, 0x7fffffffffffffffL

    const-wide v1, 0x7fffffffffffffffL

    const/4 v11, 0x5

    const-wide v1, 0x7fffffffffffffffL

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-interface {p1, v1, v2}, Lja/d;->g(J)V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-wide v7, p0, Lio/reactivex/internal/operators/flowable/q$c;->B0:J

    const/4 v10, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x4

    iget-object v9, p0, Lio/reactivex/internal/operators/flowable/q$c;->C0:Ljava/util/concurrent/TimeUnit;

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-wide v5, v7

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual/range {v3 .. v9}, Lio/reactivex/e0$c;->f(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance v1, Lio/reactivex/internal/operators/flowable/q$c$a;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-direct {v1, p0, v0}, Lio/reactivex/internal/operators/flowable/q$c$a;-><init>(Lio/reactivex/internal/operators/flowable/q$c;Ljava/util/Collection;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/q$c;->A0:J

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->C0:Ljava/util/concurrent/TimeUnit;

    const/4 v11, 0x0

    invoke-virtual {p1, v1, v2, v3, v0}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-interface {v1}, Lio/reactivex/disposables/c;->e()V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object p1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    return-void
.end method

.method public run()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->k0:Ljava/util/concurrent/Callable;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v1, "pl hibuTu esbfpsefd inlrlum"

    const-string v1, "fllmusdhr i ibuseeefl uTnpp"

    const/4 v6, 0x2

    const-string v1, "iuelnTupeu shfplfebs  iu rd"

    const-string v1, "The supplied buffer is null"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    monitor-enter p0

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v6, 0x5

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    monitor-exit p0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x4

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$c;->D0:Lio/reactivex/e0$c;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v2, Lio/reactivex/internal/operators/flowable/q$c$b;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v2, p0, v0}, Lio/reactivex/internal/operators/flowable/q$c$b;-><init>(Lio/reactivex/internal/operators/flowable/q$c;Ljava/util/Collection;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/q$c;->A0:J

    const/4 v6, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->C0:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v3, v4, v0}, Lio/reactivex/e0$c;->d(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw v0

    :catchall_1
    move-exception v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$c;->cancel()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void
.end method

.method public t(Lja/c;Ljava/util/Collection;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;TU;)Z"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x1

    invoke-interface {p1, p2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p1
.end method

.method w()V
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$c;->E0:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    throw v0
.end method
