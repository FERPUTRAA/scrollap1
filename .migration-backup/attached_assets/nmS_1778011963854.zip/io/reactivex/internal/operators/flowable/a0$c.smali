.class final Lio/reactivex/internal/operators/flowable/a0$c;
.super Lio/reactivex/internal/operators/flowable/a0$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a0$b<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x21aef8f9f7f1cbc3L


# instance fields
.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "TT;>;"
        }
    .end annotation
.end field

.field final wip:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lja/c;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;-><init>(Lja/c;)V

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$c;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method e()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ". sb/f@ ~~ ~  ~~bv~~Kt~ ~/@t -@1oo~ua  l@~fi @ro@ @oy @~c~@@~~  s~ ~d4@lbm  Mo~~@~i@@~So@i~@@@@n"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$c;->i()V

    const/4 v1, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "tdemn.xsuto saantlp illlwra. seraxarsuNao lnrw dyls nlougo t rlolell od  ecceea .2v neneNuh "

    const-string v0, " ass lwclreaoor u  luoxett ot. lr.e.Nldavupla2nwsitrh e en lneeciolsdyaN llxosgdl  nreauan n"

    const/4 v2, 0x5

    const-string/jumbo v0, "tawloe d.elnaunixl2NalsultNe exyruisdhaoatclu wdloos a  e elotan eoerr lvoesn.lg nrl c.r  np"

    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/internal/queue/c;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$c;->i()V

    :cond_2
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method h()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method i()V
    .locals 15

    const/4 v14, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v14, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v14, 0x4

    if-eqz v0, :cond_0

    const/4 v14, 0x0

    return-void

    :cond_0
    const/4 v14, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    const/4 v14, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a0$c;->queue:Lio/reactivex/internal/queue/c;

    const/4 v14, 0x7

    const/4 v2, 0x1

    const/4 v14, 0x2

    move v3, v2

    move v3, v2

    :cond_1
    const/4 v14, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v4

    const/4 v14, 0x6

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    move-wide v8, v6

    :goto_0
    const/4 v14, 0x2

    cmp-long v10, v8, v4

    const/4 v14, 0x7

    if-eqz v10, :cond_7

    const/4 v14, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v11

    const/4 v14, 0x3

    if-eqz v11, :cond_2

    const/4 v14, 0x7

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v14, 0x2

    return-void

    :cond_2
    const/4 v14, 0x2

    iget-boolean v11, p0, Lio/reactivex/internal/operators/flowable/a0$c;->done:Z

    const/4 v14, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x0

    if-nez v12, :cond_3

    const/4 v14, 0x0

    move v13, v2

    move v13, v2

    move v13, v2

    move v13, v2

    const/4 v14, 0x5

    goto :goto_1

    :cond_3
    const/4 v14, 0x7

    const/4 v13, 0x0

    :goto_1
    const/4 v14, 0x2

    if-eqz v11, :cond_5

    if-eqz v13, :cond_5

    const/4 v14, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->error:Ljava/lang/Throwable;

    const/4 v14, 0x4

    if-eqz v0, :cond_4

    const/4 v14, 0x1

    invoke-super {p0, v0}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    const/4 v14, 0x1

    goto :goto_2

    :cond_4
    invoke-super {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->onComplete()V

    :goto_2
    const/4 v14, 0x1

    return-void

    :cond_5
    const/4 v14, 0x4

    if-eqz v13, :cond_6

    const/4 v14, 0x2

    goto :goto_3

    :cond_6
    const/4 v14, 0x2

    invoke-interface {v0, v12}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v14, 0x4

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const/4 v14, 0x0

    add-long/2addr v8, v10

    const/4 v14, 0x4

    goto :goto_0

    :cond_7
    :goto_3
    const/4 v14, 0x3

    if-nez v10, :cond_a

    const/4 v14, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v4

    const/4 v14, 0x0

    if-eqz v4, :cond_8

    const/4 v14, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v14, 0x0

    return-void

    :cond_8
    const/4 v14, 0x2

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/a0$c;->done:Z

    const/4 v14, 0x1

    invoke-virtual {v1}, Lio/reactivex/internal/queue/c;->isEmpty()Z

    move-result v5

    const/4 v14, 0x4

    if-eqz v4, :cond_a

    const/4 v14, 0x3

    if-eqz v5, :cond_a

    const/4 v14, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->error:Ljava/lang/Throwable;

    const/4 v14, 0x2

    if-eqz v0, :cond_9

    const/4 v14, 0x6

    invoke-super {p0, v0}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    goto :goto_4

    :cond_9
    const/4 v14, 0x7

    invoke-super {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->onComplete()V

    :goto_4
    const/4 v14, 0x3

    return-void

    :cond_a
    const/4 v14, 0x6

    cmp-long v4, v8, v6

    const/4 v14, 0x0

    if-eqz v4, :cond_b

    const/4 v14, 0x6

    invoke-static {p0, v8, v9}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_b
    const/4 v14, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/a0$c;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v14, 0x0

    neg-int v3, v3

    invoke-virtual {v4, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v3

    const/4 v14, 0x4

    if-nez v3, :cond_1

    const/4 v14, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->done:Z

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$c;->i()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a0$c;->done:Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    if-nez p1, :cond_1

    const/4 v1, 0x6

    move v2, v1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "lph ebsln uor ai  vinddwue. wgt laNnlre.acrror.oeleo ldesltaarsxrlEoo a eluynnr  lsneau 2loct"

    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a0$c;->error:Ljava/lang/Throwable;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/a0$c;->done:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$c;->i()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :cond_2
    :goto_0
    const/4 v2, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method
