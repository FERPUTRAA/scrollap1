.class final Lio/reactivex/internal/operators/flowable/m3$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x44a0454d820bd1c8L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile done:Z

.field final error:Lio/reactivex/internal/util/c;

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final s:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->actual:Lja/c;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p1, Lio/reactivex/internal/util/c;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p1}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v0, 0x4

    and-int/2addr v1, v0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s@ f    .~~i @ooK@i1~ ~@@i~@@~~@~@ yt~f ~~-o  b@M@~~b@@a~lrum@o~~S~@ ~@ovt ~ b4d~ @ /@cls@~o~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, p1, p0, v1}, Lio/reactivex/internal/util/k;->f(Lja/c;Ljava/lang/Object;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public g(J)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    cmp-long v0, p1, v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-gtz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m3$a;->cancel()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v2, "d0imouoei vebat sloess0ruist iuu wnv 9aet:ed3tri  qarqum ./e7tat"

    const-string v2, "prsutruo3.drotd 0  liivi  qe esi umtse wuaeitat09qnaao:7/evutebs"

    const/4 v4, 0x1

    const-string v2, "aer o ues: ti v/ adlanseev  rqeuoarsw7 b0.t9itutmiuputeoiiqdo03t"

    const-string/jumbo v2, "\u00a73.9 violated: positive request amount required but it was "

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/flowable/m3$a;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x0

    const/4 v0, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->actual:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p0, v1}, Lio/reactivex/internal/util/k;->b(Lja/c;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->actual:Lja/c;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, p1, p0, v1}, Lio/reactivex/internal/util/k;->d(Lja/c;Ljava/lang/Throwable;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    const/4 v3, 0x0

    move v4, v3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m3$a;->cancel()V

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v0, " centbvmacb0im 0 t u7b se/1 l:smdacoodSbr2etosuuaeo.2iean ll"

    const-string v0, " b.m1usr   ol 2mt/2ucnetoo0loia0 casddtueveesic bbS:ln7emata"

    const/4 v4, 0x3

    const-string v0, "ia71eeu aude0etuco smdb.bcn moli o0t no:etr ca avtssb2ullS 2"

    const-string/jumbo v0, "\u00a72.12 violated: onSubscribe must be called at most once"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m3$a;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x6

    return-void
.end method
