.class final Lio/reactivex/internal/operators/flowable/l2$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/l2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/r<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "TT;TT;TT;>;"
        }
    .end annotation
.end field

.field c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field d:Lja/d;

.field e:Z


# direct methods
.method constructor <init>(Lio/reactivex/r;Lt7/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/r<",
            "-TT;>;",
            "Lt7/c<",
            "TT;TT;TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l2$a;->a:Lio/reactivex/r;

    const/4 v0, 0x5

    move v1, v0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l2$a;->b:Lt7/c;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@sn@ 4 S~o~~o@@rdoyf ~l~@-lotK b~~o~ ~ o  v  s@~~@ic/~iu@@ ~@@@fb~~@ ~ @/.iMatm @ ~ ~~ @@~~1@~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->d:Lja/d;

    const/4 v1, 0x5

    move v2, v1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->c:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l2$a;->c:Ljava/lang/Object;

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l2$a;->b:Lt7/c;

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-interface {v1, v0, p1}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const-string v0, "e sluuerd teh cu aeeT urdlarvrlne"

    const/4 v3, 0x2

    const-string v0, "crvm  uuu nn derarledeaur etlTehe"

    const-string v0, "The reducer returned a null value"

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l2$a;->c:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->d:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/l2$a;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->c:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l2$a;->a:Lio/reactivex/r;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v1, v0}, Lio/reactivex/r;->onSuccess(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->a:Lio/reactivex/r;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0}, Lio/reactivex/r;->onComplete()V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->e:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->a:Lio/reactivex/r;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lio/reactivex/r;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->d:Lja/d;

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l2$a;->d:Lja/d;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l2$a;->a:Lio/reactivex/r;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {v0, p0}, Lio/reactivex/r;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method
