.class public final Lio/reactivex/internal/operators/flowable/b4;
.super Lio/reactivex/k;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/b4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/k<",
        "Ljava/lang/Long;",
        ">;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/e0;

.field final c:J

.field final d:Ljava/util/concurrent/TimeUnit;


# direct methods
.method public constructor <init>(JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x3

    iput-wide p1, p0, Lio/reactivex/internal/operators/flowable/b4;->c:J

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/b4;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/b4;->b:Lio/reactivex/e0;

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~s oi ~ ob@@ @ @M@@@tK1 @~o@@~4b~~~@s@/~~c l mt ru. of ~~@ ~@vln/@o ~~@~o ~~y~-f~Sa~dbi@ ~ @~i "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/b4$a;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v0, p1}, Lio/reactivex/internal/operators/flowable/b4$a;-><init>(Lja/c;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/b4;->b:Lio/reactivex/e0;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-wide v1, p0, Lio/reactivex/internal/operators/flowable/b4;->c:J

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/b4;->d:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1, v2, v3}, Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/b4$a;->a(Lio/reactivex/disposables/c;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method
