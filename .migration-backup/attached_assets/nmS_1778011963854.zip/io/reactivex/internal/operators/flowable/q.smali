.class public final Lio/reactivex/internal/operators/flowable/q;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/q$a;,
        Lio/reactivex/internal/operators/flowable/q$c;,
        Lio/reactivex/internal/operators/flowable/q$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TU;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:J

.field final e:Ljava/util/concurrent/TimeUnit;

.field final f:Lio/reactivex/e0;

.field final g:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field

.field final h:I

.field final i:Z


# direct methods
.method public constructor <init>(Lja/b;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;Ljava/util/concurrent/Callable;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;JJ",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;IZ)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/q;->c:J

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/q;->d:J

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/q;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x4

    const/4 v0, 0x4

    iput-object p7, p0, Lio/reactivex/internal/operators/flowable/q;->f:Lio/reactivex/e0;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p8, p0, Lio/reactivex/internal/operators/flowable/q;->g:Ljava/util/concurrent/Callable;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p9, p0, Lio/reactivex/internal/operators/flowable/q;->h:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    iput-boolean p10, p0, Lio/reactivex/internal/operators/flowable/q;->i:Z

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;)V"
        }
    .end annotation

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v11, "~@s @i@~~ o@~f~@~o~iutd@m M y1~~~ @.Sa -~@on~sK/ l~@  ~b t@~~/i@4~~@r@bcl  ~ oo ~~ @@@@v@fo@@b  "

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v12, 0x0

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/q;->c:J

    const/4 v11, 0x0

    move v12, v11

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/q;->d:J

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x4

    cmp-long v0, v0, v2

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-nez v0, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x6

    iget v0, p0, Lio/reactivex/internal/operators/flowable/q;->h:I

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    const v1, 0x7fffffff

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x1

    if-ne v0, v1, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x5

    new-instance v8, Lio/reactivex/internal/operators/flowable/q$b;

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/q;->g:Ljava/util/concurrent/Callable;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/q;->c:J

    const/4 v11, 0x1

    move v12, v11

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/q;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/q;->f:Lio/reactivex/e0;

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-direct/range {v1 .. v7}, Lio/reactivex/internal/operators/flowable/q$b;-><init>(Lja/c;Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-interface {v0, v8}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    return-void

    :cond_0
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q;->f:Lio/reactivex/e0;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v0}, Lio/reactivex/e0;->c()Lio/reactivex/e0$c;

    move-result-object v9

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/q;->c:J

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x6

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/q;->d:J

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    cmp-long v0, v0, v2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    if-nez v0, :cond_1

    const/4 v12, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x0

    const/4 v11, 0x7

    new-instance v10, Lio/reactivex/internal/operators/flowable/q$a;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v12, 0x3

    const/4 v11, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/q;->g:Ljava/util/concurrent/Callable;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/q;->c:J

    const/4 v11, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v6, p0, Lio/reactivex/internal/operators/flowable/q;->e:Ljava/util/concurrent/TimeUnit;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    iget v7, p0, Lio/reactivex/internal/operators/flowable/q;->h:I

    const/4 v11, 0x3

    and-int/2addr v12, v11

    iget-boolean v8, p0, Lio/reactivex/internal/operators/flowable/q;->i:Z

    move-object v1, v10

    move-object v1, v10

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-direct/range {v1 .. v9}, Lio/reactivex/internal/operators/flowable/q$a;-><init>(Lja/c;Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;IZLio/reactivex/e0$c;)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-interface {v0, v10}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    return-void

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    new-instance v10, Lio/reactivex/internal/operators/flowable/q$c;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/q;->g:Ljava/util/concurrent/Callable;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/q;->c:J

    const/4 v12, 0x5

    const/4 v11, 0x5

    iget-wide v6, p0, Lio/reactivex/internal/operators/flowable/q;->d:J

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-object v8, p0, Lio/reactivex/internal/operators/flowable/q;->e:Ljava/util/concurrent/TimeUnit;

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    move-object v1, v10

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-direct/range {v1 .. v9}, Lio/reactivex/internal/operators/flowable/q$c;-><init>(Lja/c;Ljava/util/concurrent/Callable;JJLjava/util/concurrent/TimeUnit;Lio/reactivex/e0$c;)V

    const/4 v12, 0x1

    const/4 v11, 0x5

    invoke-interface {v0, v10}, Lja/b;->j(Lja/c;)V

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    return-void
.end method
