.class final Lio/reactivex/internal/operators/flowable/o1$a;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/d;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/o1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x26fd42ce5a1686a7L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field count:J

.field final end:J

.field final resource:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;JJ)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Long;",
            ">;JJ)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/o1$a;->actual:Lja/c;

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/o1$a;->count:J

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/o1$a;->end:J

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method


# virtual methods
.method public a(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~vsKo  @ nt~@@@b/ @@ao@u@~o~~y@Sm l~~o~~i @ri@.@ ~ @@~~b  ~b @~/ t4~c@f1~ o ~f- ~@ld@~ @~M@oi ~s"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->h(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x5

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public run()V
    .locals 10

    const/4 v9, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eq v0, v1, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    cmp-long v0, v2, v4

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eqz v0, :cond_2

    const/4 v9, 0x4

    iget-wide v4, p0, Lio/reactivex/internal/operators/flowable/o1$a;->count:J

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->actual:Lja/c;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x7

    invoke-interface {v0, v6}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-wide v6, p0, Lio/reactivex/internal/operators/flowable/o1$a;->end:J

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    cmp-long v0, v4, v6

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-nez v0, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eq v0, v1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->actual:Lja/c;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    :cond_0
    const/4 v9, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-void

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v9, 0x5

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-long/2addr v4, v0

    const/4 v9, 0x3

    iput-wide v4, p0, Lio/reactivex/internal/operators/flowable/o1$a;->count:J

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v9, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    cmp-long v0, v2, v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eqz v0, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->actual:Lja/c;

    const/4 v8, 0x2

    move v9, v8

    new-instance v1, Lio/reactivex/exceptions/c;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string v3, " e/mdltalanCv/  svuie"

    const-string v3, "Casielndtver/ l/v  ua"

    const/4 v9, 0x4

    const-string v3, " nedoal/eev  uratilCv"

    const-string v3, "Can\'t deliver value "

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/o1$a;->count:J

    const/4 v9, 0x3

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string v3, "e tmubs fcdtaoos  e kqeu"

    const-string v3, "q ems asotod  eultekc fu"

    const/4 v9, 0x3

    const-string v3, " faq eultudo o  uessrckt"

    const-string v3, " due to lack of requests"

    const/4 v9, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-direct {v1, v2}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    move v9, v8

    invoke-interface {v0, v1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/o1$a;->resource:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    :cond_3
    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    return-void
.end method
