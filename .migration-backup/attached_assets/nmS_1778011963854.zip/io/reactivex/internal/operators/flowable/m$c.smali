.class final Lio/reactivex/internal/operators/flowable/m$c;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "C::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4df0a4abec27f371L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TC;>;"
        }
    .end annotation
.end field

.field buffer:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TC;"
        }
    .end annotation
.end field

.field final bufferSupplier:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TC;>;"
        }
    .end annotation
.end field

.field done:Z

.field index:I

.field s:Lja/d;

.field final size:I

.field final skip:I


# direct methods
.method constructor <init>(Lja/c;IILjava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TC;>;II",
            "Ljava/util/concurrent/Callable<",
            "TC;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$c;->actual:Lja/c;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p2, p0, Lio/reactivex/internal/operators/flowable/m$c;->size:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p3, p0, Lio/reactivex/internal/operators/flowable/m$c;->skip:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/m$c;->bufferSupplier:Ljava/util/concurrent/Callable;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ss@~~ a//@@4ro @@lK~M@u~@  ~o~~~t~ ~ bm~ ~cf 1 ~~@So@f  ot@@b@-~@~@iyoi @i@@o~.bn @~l@~ @~~vd~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->s:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->done:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->buffer:Ljava/util/Collection;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m$c;->index:I

    const/4 v4, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v1, :cond_1

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->bufferSupplier:Ljava/util/concurrent/Callable;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, "lTfmldhruu  selebSrrueafuft inuere rn peb"

    const-string/jumbo v1, "uus  duieSnetpurl lTlefahubrrnefrrefeb  f"

    const/4 v4, 0x5

    const-string/jumbo v1, "uealorehub prplffTu reeeurndu Slter inff "

    const-string v1, "The bufferSupplier returned a null buffer"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->buffer:Ljava/util/Collection;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/m$c;->cancel()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m$c;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->size()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m$c;->size:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p1, v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$c;->buffer:Ljava/util/Collection;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m$c;->actual:Lja/c;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_2
    const/4 v4, 0x0

    iget p1, p0, Lio/reactivex/internal/operators/flowable/m$c;->skip:I

    const/4 v3, 0x2

    move v4, v3

    if-ne v2, p1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v2, p0, Lio/reactivex/internal/operators/flowable/m$c;->index:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method public g(J)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->size:I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    int-to-long v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p1, p2, v0, v1}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget v2, p0, Lio/reactivex/internal/operators/flowable/m$c;->skip:I

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget v3, p0, Lio/reactivex/internal/operators/flowable/m$c;->size:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    sub-int/2addr v2, v3

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    int-to-long v2, v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x6

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    sub-long/2addr p1, v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v2, v3, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/m$c;->s:Lja/d;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/util/d;->c(JJ)J

    move-result-wide p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    invoke-interface {v2, p1, p2}, Lja/d;->g(J)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->s:Lja/d;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v1, p0, Lio/reactivex/internal/operators/flowable/m$c;->skip:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    int-to-long v1, v1

    const/4 v7, 0x0

    invoke-static {v1, v2, p1, p2}, Lio/reactivex/internal/util/d;->d(JJ)J

    move-result-wide p1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    :cond_1
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->done:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->done:Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->buffer:Ljava/util/Collection;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/m$c;->buffer:Ljava/util/Collection;

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/m$c;->actual:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->actual:Lja/c;

    const/4 v3, 0x6

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->buffer:Ljava/util/Collection;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->actual:Lja/c;

    const/4 v1, 0x5

    move v2, v1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m$c;->s:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m$c;->s:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/m$c;->actual:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method
