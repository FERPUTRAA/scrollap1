.class public final Lio/reactivex/internal/operators/flowable/r0;
.super Lio/reactivex/k;

# interfaces
.implements Lu7/m;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/k<",
        "Ljava/lang/Object;",
        ">;",
        "Lu7/m<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field public static final b:Lio/reactivex/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/k<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    new-instance v0, Lio/reactivex/internal/operators/flowable/r0;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Lio/reactivex/internal/operators/flowable/r0;-><init>()V

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    sput-object v0, Lio/reactivex/internal/operators/flowable/r0;->b:Lio/reactivex/k;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/reactivex/k;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~stfon4 l ~ ~.oK~@s  /@i~   m~u@@~M/lb@d @~i~1@@@~@~~~oi ~ @@@f ~~~vo@ @  o b~yo@- ~bt~@a@cSr~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-static {p1}, Lio/reactivex/internal/subscriptions/g;->a(Lja/c;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public call()Ljava/lang/Object;
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    const/4 v0, 0x0

    move v2, v0

    return-object v0
.end method
