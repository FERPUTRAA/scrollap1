.class abstract Lio/reactivex/internal/operators/flowable/a0$h;
.super Lio/reactivex/internal/operators/flowable/a0$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a0$b<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x3948ba7d6479d0d1L


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;-><init>(Lja/c;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " osy   ~~~bt~.1@~~ @~b@ M@fi@~ s~@ @~bclr~aK~~ i~~~@@d4f @ Soovt@l@@~ @@@o@/~uo@   n  @-o/~~m~i@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez p1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    const-string v0, "rl m uare ilwexeoleselts.  u decutcsaaex. a t.noNlosdlnw2tdr nalee rp iul vr hnaoosollN nngy"

    const-string v0, "csser.l2wd  toulixxo. rdto  i.nyaleeoeunvrllaraeshe cunolaltelrus dllte    on sapN gn Newanl"

    const/4 v5, 0x6

    const-string v0, "lri oas.tgch awoel.erx nlslsdtei teNo nluewl ve a a lo oalNdcxup  a.yldeur2tee nlanorrsonlun"

    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-wide/16 v0, 0x1

    const/4 v5, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0, v0, v1}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$h;->i()V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-void
.end method

.method abstract i()V
.end method
