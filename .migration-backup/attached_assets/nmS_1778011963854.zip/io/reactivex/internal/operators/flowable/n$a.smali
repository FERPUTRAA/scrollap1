.class final Lio/reactivex/internal/operators/flowable/n$a;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;Open:",
        "Ljava/lang/Object;",
        "Close:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;TU;TU;>;",
        "Lja/d;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final A0:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TOpen;+",
            "Lja/b<",
            "+TClose;>;>;"
        }
    .end annotation
.end field

.field final B0:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field

.field final C0:Lio/reactivex/disposables/b;

.field D0:Lja/d;

.field final E0:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "TU;>;"
        }
    .end annotation
.end field

.field final F0:Ljava/util/concurrent/atomic/AtomicInteger;

.field final k0:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TOpen;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lja/b;Lt7/o;Ljava/util/concurrent/Callable;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;",
            "Lja/b<",
            "+TOpen;>;",
            "Lt7/o<",
            "-TOpen;+",
            "Lja/b<",
            "+TClose;>;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;)V"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->F0:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n$a;->k0:Lja/b;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/n$a;->A0:Lt7/o;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/n$a;->B0:Ljava/util/concurrent/Callable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-instance p1, Ljava/util/LinkedList;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/util/LinkedList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p1, Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p1}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~fsc b@~@@v    //l@@ S@i@o~~o~~M  ~@o~y~~ ~b@d@K  tn~@~~~~~@~imis o-@t@@~~1 ~f@@aoo@@4@ u~b   .l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/n$a;->e()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v1, 0x5

    move v2, v1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v1, Ljava/util/Collection;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v1, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    throw p1
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public bridge synthetic k(Lja/c;Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    check-cast p2, Ljava/util/Collection;

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/n$a;->t(Lja/c;Ljava/util/Collection;)Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->F0:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/n$a;->v()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/n$a;->cancel()V

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x6

    or-int/2addr v1, v0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    throw p1
.end method

.method public q(Lja/d;)V
    .locals 5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->D0:Lja/d;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->D0:Lja/d;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Lio/reactivex/internal/operators/flowable/n$c;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/flowable/n$c;-><init>(Lio/reactivex/internal/operators/flowable/n$a;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x1

    invoke-interface {v1, p0}, Lja/c;->q(Lja/d;)V

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->F0:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;->lazySet(I)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->k0:Lja/b;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v4, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v4, 0x0

    return-void
.end method

.method public t(Lja/c;Ljava/util/Collection;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;TU;)Z"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-interface {p1, p2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p1
.end method

.method u(Ljava/util/Collection;Lio/reactivex/disposables/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;",
            "Lio/reactivex/disposables/c;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    move v1, v0

    move v1, v0

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0, p0}, Lio/reactivex/internal/subscribers/n;->r(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Lio/reactivex/disposables/b;->b(Lio/reactivex/disposables/c;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->F0:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/n$a;->v()V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    throw p1
.end method

.method v()V
    .locals 5

    const/4 v4, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/List;->clear()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    check-cast v2, Ljava/util/Collection;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v1, v2}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x0

    xor-int/2addr v4, v2

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v1, v0, v2, p0, p0}, Lio/reactivex/internal/util/u;->f(Lu7/o;Lja/c;ZLio/reactivex/disposables/c;Lio/reactivex/internal/util/t;)V

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    throw v0
.end method

.method w(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TOpen;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->B0:Ljava/util/concurrent/Callable;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, "r fmpusebf  u nildspeuelhTi"

    const-string v1, "The buffer supplied is null"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->A0:Lt7/o;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v1, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v1, "hlbgo  isi ussefsobur nl unlpfhrTilc"

    const-string v1, "n suh ub bufh elnpTsl rgelscolrsifii"

    const/4 v3, 0x2

    const-string v1, "lsplubTubigeun lrhsf  senbii fclr he"

    const-string v1, "The buffer closing publisher is null"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast p1, Lja/b;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x4

    monitor-enter p0

    :try_start_2
    const/4 v3, 0x7

    iget-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/n$a;->E0:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    move v3, v2

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v1, Lio/reactivex/internal/operators/flowable/n$b;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v1, v0, p0}, Lio/reactivex/internal/operators/flowable/n$b;-><init>(Ljava/util/Collection;Lio/reactivex/internal/operators/flowable/n$a;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->F0:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {p1, v1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception p1

    :try_start_3
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-exit p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    throw p1

    :catchall_1
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/n$a;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :catchall_2
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/n$a;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    return-void
.end method

.method x(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n$a;->C0:Lio/reactivex/disposables/b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->b(Lio/reactivex/disposables/c;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n$a;->F0:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/n$a;->v()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method
