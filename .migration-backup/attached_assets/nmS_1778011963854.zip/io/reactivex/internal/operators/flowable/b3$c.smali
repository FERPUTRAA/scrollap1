.class final Lio/reactivex/internal/operators/flowable/b3$c;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/b3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x42abb13cc59281abL


# instance fields
.field volatile done:Z

.field final limit:I

.field final parent:Lio/reactivex/internal/operators/flowable/b3$b;

.field final prefetch:I

.field produced:J

.field volatile queue:Lu7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/o<",
            "TT;>;"
        }
    .end annotation
.end field

.field sourceMode:I


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/b3$b;I)V
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->parent:Lio/reactivex/internal/operators/flowable/b3$b;

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    shr-int/lit8 p1, p2, 0x2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    sub-int p1, p2, p1

    const/4 v1, 0x4

    iput p1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->limit:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    iput p2, p0, Lio/reactivex/internal/operators/flowable/b3$c;->prefetch:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "fos tb@4~ o~@~@~/@@Sioi~o@M~f@  @ ~ m orn @ @s l@@~~bd/~~out ~~~@~ K@@ ~i@av1@c~-y~ @ @ ~~l@b.~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method b()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Lu7/o;->clear()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public c()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->sourceMode:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eq v0, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->produced:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-long/2addr v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v2, p0, Lio/reactivex/internal/operators/flowable/b3$c;->limit:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    int-to-long v2, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    cmp-long v2, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ltz v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-wide v2, p0, Lio/reactivex/internal/operators/flowable/b3$c;->produced:J

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast v2, Lja/d;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-interface {v2, v0, v1}, Lja/d;->g(J)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-wide v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->produced:J

    :cond_1
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x2

    iget v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->sourceMode:I

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p1}, Lio/reactivex/exceptions/c;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/b3$c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->parent:Lio/reactivex/internal/operators/flowable/b3$b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p1}, Lio/reactivex/internal/operators/flowable/b3$b;->c()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->done:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->parent:Lio/reactivex/internal/operators/flowable/b3$b;

    invoke-interface {v0}, Lio/reactivex/internal/operators/flowable/b3$b;->c()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->parent:Lio/reactivex/internal/operators/flowable/b3$b;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/internal/operators/flowable/b3$b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    instance-of v0, p1, Lu7/l;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v0, Lu7/l;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Lu7/k;->l(I)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-ne v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput v1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->sourceMode:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-boolean v2, p0, Lio/reactivex/internal/operators/flowable/b3$c;->done:Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->parent:Lio/reactivex/internal/operators/flowable/b3$b;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p1}, Lio/reactivex/internal/operators/flowable/b3$b;->c()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ne v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    iput v1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->sourceMode:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->prefetch:I

    const/4 v4, 0x7

    int-to-long v0, v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Lio/reactivex/internal/queue/b;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lio/reactivex/internal/operators/flowable/b3$c;->prefetch:I

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Lio/reactivex/internal/queue/b;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->queue:Lu7/o;

    const/4 v4, 0x7

    iget v0, p0, Lio/reactivex/internal/operators/flowable/b3$c;->prefetch:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    int-to-long v0, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method
