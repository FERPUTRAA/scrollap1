.class final Lio/reactivex/internal/operators/flowable/a0$g;
.super Lio/reactivex/internal/operators/flowable/a0$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "g"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a0$b<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x34699b00190316f1L


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;-><init>(Lja/c;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "cys ~vodi@oo@ ff @  K~ ~o@@~~@@ u1~@@ o @~~ti@ ~il/ s M @@bS~@@ -@o~~.~ am~b~ 4~~@ bt~r@~/@~~@l~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/a0$b;->isCancelled()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a0$b;->actual:Lja/c;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    cmp-long p1, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    sub-long v2, v0, v2

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {p0, v0, v1, v2, v3}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    :cond_2
    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string v0, "rcnm gxtlil rN alse.roelole.r oNt n sutydow olnhlsledlatovaail slrxauuapc   ane n eesud.een2"

    const-string/jumbo v0, "uls olcryu  srndno.an aNdtwoeclltl  xsxlleein. n uew o vae luls rdearpolg2eirhs at.aelaentoN"

    const-string v0, "eelcoyelin lgiva o ll rul noltwantolnert.puxalscaaNode lt ld  ho nno ers.2ax e .rduNwuresesa"

    const-string v0, "onNext called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/a0$b;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method
