.class final Lio/reactivex/internal/operators/flowable/j0$b;
.super Lio/reactivex/internal/subscribers/b;

# interfaces
.implements Lu7/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "K:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/b<",
        "TT;TT;>;",
        "Lu7/a<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final f:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;TK;>;"
        }
    .end annotation
.end field

.field final g:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-TK;-TK;>;"
        }
    .end annotation
.end field

.field h:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TK;"
        }
    .end annotation
.end field

.field i:Z


# direct methods
.method constructor <init>(Lja/c;Lt7/o;Lt7/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/o<",
            "-TT;TK;>;",
            "Lt7/d<",
            "-TK;-TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/b;-><init>(Lja/c;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/j0$b;->f:Lt7/o;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/j0$b;->g:Lt7/d;

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " -s bi@l~~ @@~~@u~@@~@ao yim M t b~/t/@f~@@@@~ ~~K@@~~~sl f@c i.rS~~~o ~ @ vd@b 1@~o4o~o@ ~o ~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/j0$b;->o(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/subscribers/b;->b:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x3

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->d(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method

.method public o(Ljava/lang/Object;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x7

    move v6, v5

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v1

    :cond_0
    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget v0, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x1

    move v6, v2

    const/4 v5, 0x6

    and-int/2addr v6, v5

    if-eqz v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    return v2

    :cond_1
    :try_start_0
    const/4 v6, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j0$b;->f:Lt7/o;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-boolean v3, p0, Lio/reactivex/internal/operators/flowable/j0$b;->i:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/j0$b;->g:Lt7/d;

    const/4 v6, 0x4

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v3, v4, v0}, Lt7/d;->test(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v3, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    return v1

    :cond_2
    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-boolean v2, p0, Lio/reactivex/internal/operators/flowable/j0$b;->i:Z

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    const/4 v6, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    return v2

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->c(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v2
.end method

.method public poll()Ljava/lang/Object;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    :cond_0
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->c:Lu7/l;

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-object v0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/j0$b;->f:Lt7/o;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v1, v0}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-boolean v2, p0, Lio/reactivex/internal/operators/flowable/j0$b;->i:Z

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v3, 0x1

    or-int/2addr v6, v3

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v2, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-boolean v3, p0, Lio/reactivex/internal/operators/flowable/j0$b;->i:Z

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object v0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j0$b;->g:Lt7/d;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v2, v4, v1}, Lt7/d;->test(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-nez v2, :cond_3

    const/4 v6, 0x0

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x0

    return-object v0

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/j0$b;->h:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget v0, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eq v0, v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->b:Lja/d;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v6, 0x7

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v0, v1, v2}, Lja/d;->g(J)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto/16 :goto_0
.end method
