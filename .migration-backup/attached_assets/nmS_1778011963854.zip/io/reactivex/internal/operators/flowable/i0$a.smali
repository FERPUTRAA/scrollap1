.class final Lio/reactivex/internal/operators/flowable/i0$a;
.super Lio/reactivex/internal/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "K:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/b<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final f:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Collection<",
            "-TK;>;"
        }
    .end annotation
.end field

.field final g:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;TK;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/o;Ljava/util/Collection;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/o<",
            "-TT;TK;>;",
            "Ljava/util/Collection<",
            "-TK;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscribers/b;-><init>(Lja/c;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/i0$a;->g:Lt7/o;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/i0$a;->f:Ljava/util/Collection;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~isuo~@f~~s1 oba~~@ ~@@f@ b~l .~rt@/@ @M~Sy@@@Ko@ ~o c~ ~~  @~/ 4~@  @~~   v~b~oi~~ @m-i@dt@@lo@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i0$a;->f:Ljava/util/Collection;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Collection;->clear()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-super {p0}, Lio/reactivex/internal/subscribers/b;->clear()V

    const/4 v2, 0x7

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v0, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_2

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i0$a;->g:Lt7/o;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v1, "eetmorSnlnht ay lelkrTeuukceyeesrd "

    const-string v1, "TrsordtSre neleay eeuetl lk unykhce"

    const/4 v3, 0x3

    const-string v1, " dt otlre kecreTnSyleohakeyuuer le "

    const-string v1, "The keySelector returned a null key"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i0$a;->f:Ljava/util/Collection;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v1, v0}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    and-int/2addr v3, v2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lio/reactivex/internal/subscribers/b;->b:Lja/d;

    const/4 v2, 0x3

    and-int/2addr v3, v2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x3

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->c(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Lja/c;->f(Ljava/lang/Object;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public l(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/b;->d(I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p1
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i0$a;->f:Ljava/util/Collection;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Collection;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/b;->d:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i0$a;->f:Ljava/util/Collection;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/Collection;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->a:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public poll()Ljava/lang/Object;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    :cond_0
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->c:Lu7/l;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/i0$a;->f:Ljava/util/Collection;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/i0$a;->g:Lt7/o;

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v2, v0}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v3, "kdSr beeeehnolteayc  r keumtlTer ny"

    const-string v3, "oekmtTaSek  nueenleue ytey  lrdcrhr"

    const/4 v5, 0x5

    const-string v3, "reT  uulue nlec ekryoeSedyetnlah rt"

    const-string v3, "The keySelector returned a null key"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v2, v3}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v1, v2}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget v0, p0, Lio/reactivex/internal/subscribers/b;->e:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/b;->b:Lja/d;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v5, 0x3

    const-wide/16 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {v0, v1, v2}, Lja/d;->g(J)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object v0
.end method
