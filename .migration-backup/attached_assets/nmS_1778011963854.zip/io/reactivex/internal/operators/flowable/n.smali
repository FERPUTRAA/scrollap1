.class public final Lio/reactivex/internal/operators/flowable/n;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/n$b;,
        Lio/reactivex/internal/operators/flowable/n$c;,
        Lio/reactivex/internal/operators/flowable/n$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;Open:",
        "Ljava/lang/Object;",
        "Close:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TU;>;"
    }
.end annotation


# instance fields
.field final c:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field

.field final d:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TOpen;>;"
        }
    .end annotation
.end field

.field final e:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TOpen;+",
            "Lja/b<",
            "+TClose;>;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lja/b;Lt7/o;Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "+TOpen;>;",
            "Lt7/o<",
            "-TOpen;+",
            "Lja/b<",
            "+TClose;>;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n;->d:Lja/b;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/n;->e:Lt7/o;

    const/4 v0, 0x1

    move v1, v0

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/n;->c:Ljava/util/concurrent/Callable;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " msib~@ ~~nMl Sf@@t~@@~~a/  ~bd~~@s@ 1 K   @-@~b~ @ y~i@ o@c@~~o~@@@@t  .4~o ~/~r~i~@vl~oo~ o@fu"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/n$a;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v2, Lio/reactivex/subscribers/e;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v2, p1}, Lio/reactivex/subscribers/e;-><init>(Lja/c;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n;->d:Lja/b;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/n;->e:Lt7/o;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v4, p0, Lio/reactivex/internal/operators/flowable/n;->c:Ljava/util/concurrent/Callable;

    const/4 v6, 0x6

    invoke-direct {v1, v2, p1, v3, v4}, Lio/reactivex/internal/operators/flowable/n$a;-><init>(Lja/c;Lja/b;Lt7/o;Ljava/util/concurrent/Callable;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v6, 0x4

    return-void
.end method
