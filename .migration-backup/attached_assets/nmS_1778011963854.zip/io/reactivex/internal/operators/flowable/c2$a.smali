.class final Lio/reactivex/internal/operators/flowable/c2$a;
.super Ljava/util/concurrent/atomic/AtomicLong;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/c2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicLong;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x2c15206b10a3577aL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field done:Z

.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c2$a;->actual:Lja/c;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s/~bo@ tu@a ~~@~.@lK @mo   @ @   vc@~@fo ny~1S@@ti~ oo@~/~r~~M@~~@@@~fl@ s~i o d4  @b~~~~b-i~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->s:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->done:Z

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->actual:Lja/c;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v5, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0, v0, v1}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v5, 0x3

    const-string/jumbo v0, "uttmuo ldcuras tltooiko elms s unc  feqee ev"

    const-string v0, " esnoe ctqa m  veatf tskiollcdesuoetlo uruu "

    const/4 v5, 0x0

    const-string/jumbo v0, "u tuodi u eons elesvcd  qm tef tlocrkaouoate"

    const-string v0, "could not emit value due to lack of requests"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p1, v0}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/c2$a;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-static {p0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->done:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->done:Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->actual:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->done:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->done:Z

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/c2$a;->s:Lja/d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/c2$a;->actual:Lja/c;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method
