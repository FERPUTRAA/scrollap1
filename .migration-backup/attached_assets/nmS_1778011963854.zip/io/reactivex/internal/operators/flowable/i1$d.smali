.class final Lio/reactivex/internal/operators/flowable/i1$d;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "Ljava/lang/Object;",
        ">;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1a24ec53e2780a15L


# instance fields
.field final isLeft:Z

.field final parent:Lio/reactivex/internal/operators/flowable/i1$b;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/i1$b;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i1$d;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-boolean p2, p0, Lio/reactivex/internal/operators/flowable/i1$d;->isLeft:Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S.s @ ~  ~@ @~ @~@ @c~f K @m ~ nbal@ob@@ot ~  ~~1~i~o~@M/i@i~@f~~~b@ro@- ~~~o4us ~~dy@v@l/ ~@@to"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast v0, Lja/d;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->d(Lja/d;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x0

    invoke-static {p0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$d;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-boolean v1, p0, Lio/reactivex/internal/operators/flowable/i1$d;->isLeft:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-interface {v0, v1, p1}, Lio/reactivex/internal/operators/flowable/i1$b;->c(ZLjava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$d;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Lio/reactivex/internal/operators/flowable/i1$b;->f(Lio/reactivex/internal/operators/flowable/i1$d;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i1$d;->parent:Lio/reactivex/internal/operators/flowable/i1$b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lio/reactivex/internal/operators/flowable/i1$b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
