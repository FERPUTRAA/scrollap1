.class public final Lio/reactivex/internal/operators/flowable/t2;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/t2$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lt7/d;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/d<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lt7/d;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lt7/d<",
            "-",
            "Ljava/lang/Integer;",
            "-",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/t2;->c:Lt7/d;

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~s y~K/~@b@~SmM@ ~ob ~~ c@ ~~ @~ l@~aiu/@@~~ t@ @4o f-f~otvr~s@o  ~ @~ l@~~@~~o@@o. id ~@i1@b@n"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lio/reactivex/internal/subscriptions/o;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0}, Lio/reactivex/internal/subscriptions/o;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p1, v0}, Lja/c;->q(Lja/d;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    new-instance v1, Lio/reactivex/internal/operators/flowable/t2$a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/t2;->c:Lt7/d;

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, p1, v2, v0, v3}, Lio/reactivex/internal/operators/flowable/t2$a;-><init>(Lja/c;Lt7/d;Lio/reactivex/internal/subscriptions/o;Lja/b;)V

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/operators/flowable/t2$a;->a()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method
