.class final Lio/reactivex/internal/operators/flowable/p$a;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/p;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TB;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/p$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/p$b<",
            "TT;TU;TB;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/p$b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/p$b<",
            "TT;TU;TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/p$a;->b:Lio/reactivex/internal/operators/flowable/p$b;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TB;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~cs u ~ ~.oi~@@~~@i@s -bo @ ~@@~~@Km~to@n~@@  Mv~ /@~~ f@br @ ~b@@ l/oiS~tdo@ ~ @a@~y 14@~f ~~o~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/p$a;->b:Lio/reactivex/internal/operators/flowable/p$b;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/p$b;->u()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$a;->b:Lio/reactivex/internal/operators/flowable/p$b;

    const/4 v2, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/p$b;->onComplete()V

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/p$a;->b:Lio/reactivex/internal/operators/flowable/p$b;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/p$b;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
