.class final Lio/reactivex/internal/operators/flowable/m1$h;
.super Ljava/lang/Object;

# interfaces
.implements Lt7/o;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/m1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lt7/o<",
        "TT;",
        "Lja/b<",
        "TR;>;>;"
    }
.end annotation


# instance fields
.field private final a:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT;-TU;+TR;>;"
        }
    .end annotation
.end field

.field private final b:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TT;+",
            "Lja/b<",
            "+TU;>;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lt7/c;Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/c<",
            "-TT;-TU;+TR;>;",
            "Lt7/o<",
            "-TT;+",
            "Lja/b<",
            "+TU;>;>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/m1$h;->a:Lt7/c;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/m1$h;->b:Lt7/o;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;)Lja/b;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)",
            "Lja/b<",
            "TR;>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/m1$h;->b:Lt7/o;

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v0, Lja/b;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v1, Lio/reactivex/internal/operators/flowable/u1;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    new-instance v2, Lio/reactivex/internal/operators/flowable/m1$g;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/m1$h;->a:Lt7/c;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v2, v3, p1}, Lio/reactivex/internal/operators/flowable/m1$g;-><init>(Lt7/c;Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-direct {v1, v0, v2}, Lio/reactivex/internal/operators/flowable/u1;-><init>(Lja/b;Lt7/o;)V

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object v1
.end method

.method public bridge synthetic apply(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/flowable/m1$h;->a(Ljava/lang/Object;)Lja/b;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method
