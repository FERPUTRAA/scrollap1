.class final Lio/reactivex/internal/operators/flowable/n0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/n0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# instance fields
.field final a:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field final b:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field

.field final c:Lt7/q;

.field final d:Lt7/a;

.field e:Lja/d;


# direct methods
.method constructor <init>(Lja/c;Lt7/g;Lt7/q;Lt7/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;",
            "Lt7/g<",
            "-",
            "Lja/d;",
            ">;",
            "Lt7/q;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n0$a;->a:Lja/c;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/n0$a;->b:Lt7/g;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/n0$a;->d:Lt7/a;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/n0$a;->c:Lt7/q;

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s @1o~@@~- ~~~@Ksroio/u ~y l t@~.  @~/~@@i  @@@~~ @@@  b@o~~a~~fb@bd f~ m~o~@lSM~@n4v~ @ ~c io"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->d:Lt7/a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->e:Lja/d;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->a:Lja/c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public g(J)V
    .locals 3

    :try_start_0
    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->c:Lt7/q;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1, p2}, Lt7/q;->accept(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->e:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v1, 0x2

    or-int/2addr v2, v1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->a:Lja/c;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->a:Lja/c;

    const/4 v1, 0x4

    and-int/2addr v2, v1

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->b:Lt7/g;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/n0$a;->e:Lja/d;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/n0$a;->e:Lja/d;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n0$a;->a:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/n0$a;->a:Lja/c;

    const/4 v2, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method
