.class final Lio/reactivex/internal/operators/flowable/j4$a;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TB;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/j4$b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/j4$b<",
            "TT;TB;>;"
        }
    .end annotation
.end field

.field c:Z


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/j4$b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/j4$b<",
            "TT;TB;>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j4$a;->b:Lio/reactivex/internal/operators/flowable/j4$b;

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TB;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "S s~o@y @ ~@f@~~~~1~ b-~M ~@ ~@ @K @~/u@.~~o~l~i ~to@lrao@@~ i4m@b~v~@   ~ @c~ @~to@os@@b/@ nf i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/j4$a;->c:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/j4$a;->c:Z

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lio/reactivex/subscribers/b;->b()V

    const/4 v0, 0x4

    or-int/2addr v1, v0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/j4$a;->b:Lio/reactivex/internal/operators/flowable/j4$b;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Lio/reactivex/internal/operators/flowable/j4$b;->u()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j4$a;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j4$a;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$a;->b:Lio/reactivex/internal/operators/flowable/j4$b;

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/j4$b;->onComplete()V

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j4$a;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j4$a;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j4$a;->b:Lio/reactivex/internal/operators/flowable/j4$b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/j4$b;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method
