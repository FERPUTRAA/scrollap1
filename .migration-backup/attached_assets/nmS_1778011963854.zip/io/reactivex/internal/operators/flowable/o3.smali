.class public final Lio/reactivex/internal/operators/flowable/o3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/o3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/o3;->c:Lja/b;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~sd@@~@/to~fs@~ n@ ~o4@Kab~  ~r~t o fm @ iS@~-@ uiv@~o@ @~@@@~lo~ ~1b o@@c ~@~.y/~~@~i~M l~b@  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Lio/reactivex/internal/operators/flowable/o3$a;

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/o3;->c:Lja/b;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, p1, v1}, Lio/reactivex/internal/operators/flowable/o3$a;-><init>(Lja/c;Lja/b;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/o3$a;->c:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p1, v1}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method
