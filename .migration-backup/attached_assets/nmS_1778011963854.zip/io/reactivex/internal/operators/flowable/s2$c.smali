.class final Lio/reactivex/internal/operators/flowable/s2$c;
.super Lio/reactivex/flowables/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/s2;->k8(Lio/reactivex/flowables/a;Lio/reactivex/e0;)Lio/reactivex/flowables/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lio/reactivex/flowables/a<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final synthetic b:Lio/reactivex/flowables/a;

.field final synthetic c:Lio/reactivex/k;


# direct methods
.method constructor <init>(Lio/reactivex/flowables/a;Lio/reactivex/k;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/s2$c;->b:Lio/reactivex/flowables/a;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s2$c;->c:Lio/reactivex/k;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/flowables/a;-><init>()V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@cs  @/@~o@a@@~~f ~v o4i1 .o o~~y~ i~@@@t~@~us lb ~b@m~ @~ o ~M~@ K@~l@i~-~fo@@~~tnS~~  d@r/b @@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$c;->c:Lio/reactivex/k;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/k;->j(Lja/c;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public c8(Lt7/g;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s2$c;->b:Lio/reactivex/flowables/a;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/flowables/a;->c8(Lt7/g;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method
