.class final Lio/reactivex/internal/operators/flowable/i3$a;
.super Ljava/util/ArrayDeque;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/ArrayDeque<",
        "TT;>;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x34d6eda843bdac95L


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field s:Lja/d;

.field final skip:I


# direct methods
.method constructor <init>(Lja/c;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p2}, Ljava/util/ArrayDeque;-><init>(I)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i3$a;->actual:Lja/c;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p2, p0, Lio/reactivex/internal/operators/flowable/i3$a;->skip:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s sy~ ~r @ /f/fomil b M~ @@b@@  ~@@~o  @o ~~@~~~~~ 1i@@do~K@l.~uto~i~S@b@~v~ o~@ @@ cta4@~- n~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->s:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->skip:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/util/AbstractCollection;->size()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->actual:Lja/c;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->s:Lja/d;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v4, 0x2

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Lja/d;->g(J)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->s:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2}, Lja/d;->g(J)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->actual:Lja/c;

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->actual:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    return-void
.end method

.method public q(Lja/d;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i3$a;->s:Lja/d;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i3$a;->s:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/i3$a;->actual:Lja/c;

    const/4 v1, 0x5

    move v2, v1

    invoke-interface {p1, p0}, Lja/c;->q(Lja/d;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
