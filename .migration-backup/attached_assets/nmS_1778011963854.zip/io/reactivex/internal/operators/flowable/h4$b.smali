.class final Lio/reactivex/internal/operators/flowable/h4$b;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/h4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;",
        "Ljava/lang/Object;",
        "Lio/reactivex/k<",
        "TT;>;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field static final F0:Ljava/lang/Object;


# instance fields
.field final A0:I

.field B0:Lja/d;

.field final C0:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field D0:Lio/reactivex/processors/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/processors/g<",
            "TT;>;"
        }
    .end annotation
.end field

.field final E0:Ljava/util/concurrent/atomic/AtomicLong;

.field final k0:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TB;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Lio/reactivex/internal/operators/flowable/h4$b;->F0:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(Lja/c;Lja/b;I)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;",
            "Lja/b<",
            "TB;>;I)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p1, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x7

    move v2, v1

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/h4$b;->k0:Lja/b;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput p3, p0, Lio/reactivex/internal/operators/flowable/h4$b;->A0:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-wide/16 p2, 0x1

    const-wide/16 p2, 0x1

    const/4 v2, 0x7

    const-wide/16 p2, 0x1

    const-wide/16 p2, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, p2, p3}, Ljava/util/concurrent/atomic/AtomicLong;->lazySet(J)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~bs@obm~So@o@ci/a-@@u@@ @~ y@~4t @iin~ @o@@@~ ~~~ 1  Ko l~@~ /v~~~  ~@@~.~@t~r~o d @ M @~~~ fslf"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v2, 0x1

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->n()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->D0:Lio/reactivex/processors/g;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    if-nez p1, :cond_1

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v1, 0x5

    and-int/2addr v2, v1

    invoke-static {p1}, Lio/reactivex/internal/util/p;->s(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h4$b;->t()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public k(Lja/c;Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p1
.end method

.method public onComplete()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h4$b;->t()V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v4, 0x6

    move v5, v4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object p1, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v5, 0x3

    const/4 v0, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v5, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h4$b;->t()V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->B0:Lja/d;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_3

    const/4 v7, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->B0:Lja/d;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-boolean v1, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget v1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->A0:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    cmp-long v4, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v4, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {v0, v1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const/4 v7, 0x6

    const-wide v4, 0x7fffffffffffffffL

    const-wide v4, 0x7fffffffffffffffL

    const/4 v7, 0x1

    cmp-long v0, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0, v2, v3}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->D0:Lio/reactivex/processors/g;

    const/4 v7, 0x0

    new-instance v0, Lio/reactivex/internal/operators/flowable/h4$a;

    const/4 v6, 0x3

    or-int/2addr v7, v6

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/flowable/h4$a;-><init>(Lio/reactivex/internal/operators/flowable/h4$b;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v1, v2, v0}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {p1, v4, v5}, Lja/d;->g(J)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/h4$b;->k0:Lja/b;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string v1, "rs mtktcui l dfotdnwltr eooofCdwreeeanou sss  qi videu"

    const-string v1, "e saqrktnd dt Cowlwrsudif eonirlets deiv foouoct  s ue"

    const/4 v7, 0x4

    const-string v1, "  eio re eu  w qed oadctwlkoledvtloirifsnur tCdtoosfsu"

    const-string v1, "Could not deliver first window due to lack of requests"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {p1, v1}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-void
.end method

.method t()V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/h4$b;->D0:Lio/reactivex/processors/g;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v3, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    move v4, v3

    move v4, v3

    const/4 v10, 0x1

    move v4, v3

    move v4, v3

    :cond_0
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    invoke-interface {v0}, Lu7/n;->poll()Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-nez v6, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    move v7, v3

    move v7, v3

    const/4 v10, 0x2

    move v7, v3

    move v7, v3

    const/4 v10, 0x1

    goto :goto_1

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v7, 0x0

    :goto_1
    const/4 v10, 0x7

    const/4 v9, 0x7

    if-eqz v5, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eqz v7, :cond_3

    const/4 v10, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->Z:Ljava/lang/Throwable;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v0, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v2, v0}, Lio/reactivex/processors/g;->onError(Ljava/lang/Throwable;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_2

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    :goto_2
    const/4 v9, 0x0

    move v10, v9

    return-void

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v7, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    neg-int v4, v4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0, v4}, Lio/reactivex/internal/subscribers/n;->b(I)I

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez v4, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    return-void

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    sget-object v5, Lio/reactivex/internal/operators/flowable/h4$b;->F0:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-ne v6, v5, :cond_9

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v2}, Lio/reactivex/processors/g;->onComplete()V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v5, p0, Lio/reactivex/internal/operators/flowable/h4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v5}, Ljava/util/concurrent/atomic/AtomicLong;->decrementAndGet()J

    move-result-wide v5

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x6

    const-wide/16 v7, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    cmp-long v5, v5, v7

    const/4 v10, 0x6

    const/4 v9, 0x6

    if-nez v5, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/h4$b;->C0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    return-void

    :cond_5
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-boolean v5, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eqz v5, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto/16 :goto_0

    :cond_6
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget v2, p0, Lio/reactivex/internal/operators/flowable/h4$b;->A0:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v2}, Lio/reactivex/processors/g;->f8(I)Lio/reactivex/processors/g;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->d()J

    move-result-wide v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    cmp-long v7, v5, v7

    const/4 v10, 0x7

    if-eqz v7, :cond_8

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object v7, p0, Lio/reactivex/internal/operators/flowable/h4$b;->E0:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicLong;->getAndIncrement()J

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {v1, v2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide v7, 0x7fffffffffffffffL

    const-wide v7, 0x7fffffffffffffffL

    const/4 v10, 0x6

    const-wide v7, 0x7fffffffffffffffL

    const-wide v7, 0x7fffffffffffffffL

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    cmp-long v5, v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz v5, :cond_7

    const/4 v10, 0x0

    const/4 v9, 0x0

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v10, 0x3

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p0, v5, v6}, Lio/reactivex/internal/subscribers/n;->l(J)J

    :cond_7
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    iput-object v2, p0, Lio/reactivex/internal/operators/flowable/h4$b;->D0:Lio/reactivex/processors/g;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_8
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    iput-boolean v3, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v10, 0x7

    new-instance v5, Lio/reactivex/exceptions/c;

    const/4 v10, 0x7

    const-string v6, "Could not deliver new window due to lack of requests"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {v5, v6}, Lio/reactivex/exceptions/c;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x7

    invoke-interface {v1, v5}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v9, 0x2

    or-int/2addr v10, v9

    goto/16 :goto_0

    :cond_9
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v6}, Lio/reactivex/internal/util/p;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v2, v5}, Lio/reactivex/processors/g;->f(Ljava/lang/Object;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto/16 :goto_0
.end method

.method u()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Lio/reactivex/internal/operators/flowable/h4$b;->F0:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/h4$b;->t()V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method
