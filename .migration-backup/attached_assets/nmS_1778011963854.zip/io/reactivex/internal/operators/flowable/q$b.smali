.class final Lio/reactivex/internal/operators/flowable/q$b;
.super Lio/reactivex/internal/subscribers/n;

# interfaces
.implements Lja/d;
.implements Ljava/lang/Runnable;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/q;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U::",
        "Ljava/util/Collection<",
        "-TT;>;>",
        "Lio/reactivex/internal/subscribers/n<",
        "TT;TU;TU;>;",
        "Lja/d;",
        "Ljava/lang/Runnable;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# instance fields
.field final A0:J

.field final B0:Ljava/util/concurrent/TimeUnit;

.field final C0:Lio/reactivex/e0;

.field D0:Lja/d;

.field E0:Ljava/util/Collection;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TU;"
        }
    .end annotation
.end field

.field final F0:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field final k0:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TU;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Ljava/util/concurrent/Callable;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;",
            "Ljava/util/concurrent/Callable<",
            "TU;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Lio/reactivex/internal/queue/a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Lio/reactivex/internal/queue/a;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lio/reactivex/internal/subscribers/n;-><init>(Lja/c;Lu7/n;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/q$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    iput-wide p3, p0, Lio/reactivex/internal/operators/flowable/q$b;->A0:J

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/q$b;->B0:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p6, p0, Lio/reactivex/internal/operators/flowable/q$b;->C0:Lio/reactivex/e0;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@4s/~@~~/cS~  t~on~l@ @~~b~i~@ s@~@  @~fbuiM~oabo  @lo 1@f@  @m@r ~~i@ ~~-K~o@~~  d@~ vt.@y@ ~@o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v0
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->D0:Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$b;->cancel()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    throw p1
.end method

.method public g(J)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/subscribers/n;->s(J)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic k(Lja/c;Ljava/lang/Object;)Z
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x1

    check-cast p2, Ljava/util/Collection;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lio/reactivex/internal/operators/flowable/q$b;->t(Lja/c;Ljava/util/Collection;)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p1
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v4, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v1, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v1, v0}, Lu7/o;->offer(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->Y:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/subscribers/n;->c()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->W:Lu7/n;

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v0, v1, v2, p0, p0}, Lio/reactivex/internal/util/u;->f(Lu7/o;Lja/c;ZLio/reactivex/disposables/c;Lio/reactivex/internal/util/t;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x6

    throw v0
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    monitor-enter p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    throw p1
.end method

.method public q(Lja/d;)V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->D0:Lja/d;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-eqz v0, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/q$b;->D0:Lja/d;

    :try_start_0
    const/4 v10, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-string v1, "ildmel Tbluu  esfpnhus iefr"

    const-string v1, "nrs hlufeiuulTep  pbdlif es"

    const/4 v10, 0x6

    const-string v1, " ihpop ibesufr u flsuTdnlee"

    const-string v1, "The supplied buffer is null"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    const/4 v9, 0x2

    move v10, v9

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/subscribers/n;->X:Z

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-nez v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/q$b;->C0:Lio/reactivex/e0;

    const/4 v10, 0x6

    const/4 v9, 0x6

    iget-wide v6, p0, Lio/reactivex/internal/operators/flowable/q$b;->A0:J

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v8, p0, Lio/reactivex/internal/operators/flowable/q$b;->B0:Ljava/util/concurrent/TimeUnit;

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-wide v4, v6

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual/range {v2 .. v8}, Lio/reactivex/e0;->h(Ljava/lang/Runnable;JJLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v0, v1, p1}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-nez v0, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-interface {p1}, Lio/reactivex/disposables/c;->e()V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$b;->cancel()V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v10, 0x0

    const/4 v9, 0x5

    invoke-static {p1, v0}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    :cond_0
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    return-void
.end method

.method public run()V
    .locals 4

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->k0:Ljava/util/concurrent/Callable;

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v1, "fulesbls  phTnpiu lm bfdire"

    const-string v1, "  fmuse lnpuTrsliefdh ebipl"

    const/4 v3, 0x7

    const-string v1, "The supplied buffer is null"

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    check-cast v0, Ljava/util/Collection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-enter p0

    :try_start_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->E0:Ljava/util/Collection;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/q$b;->F0:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1, v0, p0}, Lio/reactivex/internal/subscribers/n;->p(Ljava/lang/Object;ZLio/reactivex/disposables/c;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v3, 0x7

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw v0

    :catchall_1
    move-exception v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/q$b;->cancel()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v3, 0x0

    invoke-interface {v1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public t(Lja/c;Ljava/util/Collection;)Z
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;TU;)Z"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iget-object p1, p0, Lio/reactivex/internal/subscribers/n;->V:Lja/c;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-interface {p1, p2}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p1
.end method
