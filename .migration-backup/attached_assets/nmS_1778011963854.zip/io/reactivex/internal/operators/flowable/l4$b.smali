.class final Lio/reactivex/internal/operators/flowable/l4$b;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/l4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "TU;>;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x455524b80cbc46bL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TR;>;"
        }
    .end annotation
.end field

.field final combiner:Lt7/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/c<",
            "-TT;-TU;+TR;>;"
        }
    .end annotation
.end field

.field final other:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field final s:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "Lja/d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lja/c;Lt7/c;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TR;>;",
            "Lt7/c<",
            "-TT;-TU;+TR;>;)V"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->other:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/l4$b;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/l4$b;->combiner:Lt7/c;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Throwable;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->actual:Lja/c;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public b(Lja/d;)Z
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->other:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1
.end method

.method public cancel()V
    .locals 3

    const/4 v1, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->other:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l4$b;->combiner:Lt7/c;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v1, p1, v0}, Lt7/c;->apply(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v0, " bs laeedolleanme etuirnc rsnurhuT"

    const-string v0, "l sureer nratnoieehndT lea uucbl m"

    const-string v0, "n im uudheeleTlr ame rbvr ntuoceln"

    const-string v0, "The combiner returned a null value"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p1, v0}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->actual:Lja/c;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lja/c;->f(Ljava/lang/Object;)V

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/l4$b;->cancel()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->actual:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public g(J)V
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0, v1, p1, p2}, Lio/reactivex/internal/subscriptions/p;->b(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;J)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->other:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->actual:Lja/c;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->other:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->actual:Lja/c;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/l4$b;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/l4$b;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, v1, p1}, Lio/reactivex/internal/subscriptions/p;->c(Ljava/util/concurrent/atomic/AtomicReference;Ljava/util/concurrent/atomic/AtomicLong;Lja/d;)Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method
