.class public final Lio/reactivex/internal/operators/flowable/s;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/s$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "U:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TU;>;"
    }
.end annotation


# instance fields
.field final c:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+TU;>;"
        }
    .end annotation
.end field

.field final d:Lt7/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/b<",
            "-TU;-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;Ljava/util/concurrent/Callable;Lt7/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;",
            "Ljava/util/concurrent/Callable<",
            "+TU;>;",
            "Lt7/b<",
            "-TU;-TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/s;->c:Ljava/util/concurrent/Callable;

    const/4 v0, 0x1

    and-int/2addr v1, v0

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/s;->d:Lt7/b;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TU;>;)V"
        }
    .end annotation

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@s~@@l@~~~~    b~~o~ @o/~  bSf.Mfu~Krn~@c~@i @1~ 4@ @@@o@vt  lb~~i@ d@@@o~s/ -a@ t~m y~ ~~o@~o~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/s;->c:Ljava/util/concurrent/Callable;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v1, "i umaielpelslh ulnuT asislditpinv "

    const-string v1, "iusululslp i sai depiniTan vhletl "

    const/4 v5, 0x0

    const-string v1, "niaiols u  upahetillnlvli deT pise"

    const-string v1, "The initial value supplied is null"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v5, 0x4

    const/4 v4, 0x3

    new-instance v2, Lio/reactivex/internal/operators/flowable/s$a;

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/s;->d:Lt7/b;

    const/4 v4, 0x7

    move v5, v4

    invoke-direct {v2, p1, v0, v3}, Lio/reactivex/internal/operators/flowable/s$a;-><init>(Lja/c;Ljava/lang/Object;Lt7/b;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v1, v2}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/g;->b(Ljava/lang/Throwable;Lja/c;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void
.end method
