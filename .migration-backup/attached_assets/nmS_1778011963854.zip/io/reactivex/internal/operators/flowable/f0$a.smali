.class Lio/reactivex/internal/operators/flowable/f0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/flowable/f0;->H5(Lja/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lja/c<",
        "TU;>;"
    }
.end annotation


# instance fields
.field a:Z

.field final synthetic b:Lio/reactivex/internal/subscriptions/o;

.field final synthetic c:Lja/c;

.field final synthetic d:Lio/reactivex/internal/operators/flowable/f0;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/f0;Lio/reactivex/internal/subscriptions/o;Lja/c;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/f0$a;->d:Lio/reactivex/internal/operators/flowable/f0;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/f0$a;->b:Lio/reactivex/internal/subscriptions/o;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p3, p0, Lio/reactivex/internal/operators/flowable/f0$a;->c:Lja/c;

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TU;)V"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "1@sm~@~ ~M.@~@ oi @@~ @~o@oti~ sl y@ ~S @~ua b~K@~ d @/ @~@~~~ @~o~nb4@~~to-fv/c@~ f~@l~ r@ob@ i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/f0$a;->onComplete()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->a:Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x5

    move v3, v2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->a:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->d:Lio/reactivex/internal/operators/flowable/f0;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/f0;->b:Lja/b;

    const/4 v3, 0x7

    new-instance v1, Lio/reactivex/internal/operators/flowable/f0$a$b;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v1, p0}, Lio/reactivex/internal/operators/flowable/f0$a$b;-><init>(Lio/reactivex/internal/operators/flowable/f0$a;)V

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->a:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->a:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->c:Lja/c;

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/f0$a;->b:Lio/reactivex/internal/subscriptions/o;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v1, Lio/reactivex/internal/operators/flowable/f0$a$a;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/flowable/f0$a$a;-><init>(Lio/reactivex/internal/operators/flowable/f0$a;Lja/d;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lio/reactivex/internal/subscriptions/o;->h(Lja/d;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method
