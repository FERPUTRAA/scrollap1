.class final Lio/reactivex/internal/operators/flowable/a1$a;
.super Lio/reactivex/internal/operators/flowable/a1$c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/a1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a1$c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x23e7f25903d0c345L


# instance fields
.field final actual:Lu7/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/a<",
            "-TT;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lu7/a;[Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lu7/a<",
            "-TT;>;[TT;)V"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-direct {p0, p2}, Lio/reactivex/internal/operators/flowable/a1$c;-><init>([Ljava/lang/Object;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/a1$a;->actual:Lu7/a;

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method a()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " rso@@@@bbnioS ~@ ~ -@c . / @@o~~ l~@oo@ti~~ft@f@~~/~ ~  @ 1luy@~@ ~~si  d~~@v~ m~ @K@@b4@~~a~Mo"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    array-length v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/a1$a;->actual:Lu7/a;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget v3, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eq v3, v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-boolean v4, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    aget-object v4, v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    if-nez v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v1, "srsmertieumaye lnl n "

    const-string/jumbo v1, "u silntnrsl eayea rem"

    const/4 v6, 0x5

    const-string v1, "elnro runemlsl aie ty"

    const-string v1, "array element is null"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v2, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    return-void

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v2, v4}, Lu7/a;->o(Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v6, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x0

    return-void

    :cond_3
    const/4 v6, 0x4

    invoke-interface {v2}, Lja/c;->onComplete()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void
.end method

.method b(J)V
    .locals 12

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a1$c;->array:[Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    array-length v1, v0

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget v2, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    iget-object v3, p0, Lio/reactivex/internal/operators/flowable/a1$a;->actual:Lu7/a;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    :cond_0
    move-wide v6, v4

    :cond_1
    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x3

    cmp-long v8, v6, p1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz v8, :cond_5

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eq v2, v1, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-boolean v8, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v10, 0x6

    shl-int/2addr v11, v10

    if-eqz v8, :cond_2

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    return-void

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    aget-object v8, v0, v2

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-nez v8, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string p2, "n eyebam arlslm ulnti"

    const-string p2, "ir mlurmtllans aeney "

    const/4 v11, 0x3

    const-string p2, "array element is null"

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    invoke-interface {v3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    return-void

    :cond_3
    const/4 v10, 0x0

    move v11, v10

    invoke-interface {v3, v8}, Lu7/a;->o(Ljava/lang/Object;)Z

    move-result v8

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz v8, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    const/4 v11, 0x3

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    add-long/2addr v6, v8

    :cond_4
    const/4 v10, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    goto :goto_0

    :cond_5
    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-ne v2, v1, :cond_7

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-boolean p1, p0, Lio/reactivex/internal/operators/flowable/a1$c;->cancelled:Z

    const/4 v11, 0x7

    const/4 v10, 0x4

    if-nez p1, :cond_6

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-interface {v3}, Lja/c;->onComplete()V

    :cond_6
    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    return-void

    :cond_7
    const/4 v11, 0x1

    const/4 v10, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide p1

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    cmp-long v8, v6, p1

    const/4 v10, 0x0

    or-int/2addr v11, v10

    if-nez v8, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    iput v2, p0, Lio/reactivex/internal/operators/flowable/a1$c;->index:I

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    neg-long p1, v6

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {p0, p1, p2}, Ljava/util/concurrent/atomic/AtomicLong;->addAndGet(J)J

    move-result-wide p1

    const/4 v11, 0x0

    cmp-long v6, p1, v4

    const/4 v11, 0x1

    if-nez v6, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    return-void
.end method
