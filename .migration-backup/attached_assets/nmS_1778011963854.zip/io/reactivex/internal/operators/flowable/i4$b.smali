.class final Lio/reactivex/internal/operators/flowable/i4$b;
.super Lio/reactivex/subscribers/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/i4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        "B:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/subscribers/b<",
        "TB;>;"
    }
.end annotation


# instance fields
.field final b:Lio/reactivex/internal/operators/flowable/i4$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/operators/flowable/i4$c<",
            "TT;TB;*>;"
        }
    .end annotation
.end field

.field c:Z


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/i4$c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/internal/operators/flowable/i4$c<",
            "TT;TB;*>;)V"
        }
    .end annotation

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Lio/reactivex/subscribers/b;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/i4$b;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TB;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f~s o@b@a c ~o~f@nt@  ~~@@ ~@i  vio~. o@r/is@~o~ t~-@ M@@l@~~uyl~1@/@K~ @@o@~ ~@ b~b@~S4 ~~~d~m "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/i4$c;->w(Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->c:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v2, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/operators/flowable/i4$c;->onComplete()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->c:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/i4$b;->b:Lio/reactivex/internal/operators/flowable/i4$c;

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/flowable/i4$c;->v(Ljava/lang/Throwable;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method
