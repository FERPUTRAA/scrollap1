.class public final Lio/reactivex/internal/operators/flowable/g4;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/g4$b;,
        Lio/reactivex/internal/operators/flowable/g4$c;,
        Lio/reactivex/internal/operators/flowable/g4$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;",
        "Lio/reactivex/k<",
        "TT;>;>;"
    }
.end annotation


# instance fields
.field final c:J

.field final d:J

.field final e:I


# direct methods
.method public constructor <init>(Lja/b;JJI)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;JJI)V"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x1

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/g4;->c:J

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-wide p4, p0, Lio/reactivex/internal/operators/flowable/g4;->d:J

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p6, p0, Lio/reactivex/internal/operators/flowable/g4;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public H5(Lja/c;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-",
            "Lio/reactivex/k<",
            "TT;>;>;)V"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "/ s~~ @f~tb~id~1o@~~@ ncuK~r@~ba~@ / ~l@@o o~ mlo4v~@ . y@~~~S~ @M to@ @~~ -~@s bf@@ ~i@@o i@ @~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    iget-wide v0, p0, Lio/reactivex/internal/operators/flowable/g4;->d:J

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/g4;->c:J

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    cmp-long v4, v0, v2

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-nez v4, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-instance v1, Lio/reactivex/internal/operators/flowable/g4$a;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/g4;->c:J

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget v4, p0, Lio/reactivex/internal/operators/flowable/g4;->e:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct {v1, p1, v2, v3, v4}, Lio/reactivex/internal/operators/flowable/g4$a;-><init>(Lja/c;JI)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    cmp-long v0, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-lez v0, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v10, 0x6

    new-instance v8, Lio/reactivex/internal/operators/flowable/g4$c;

    const/4 v10, 0x6

    const/4 v9, 0x3

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/g4;->c:J

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/g4;->d:J

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget v7, p0, Lio/reactivex/internal/operators/flowable/g4;->e:I

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-direct/range {v1 .. v7}, Lio/reactivex/internal/operators/flowable/g4$c;-><init>(Lja/c;JJI)V

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v0, v8}, Lja/b;->j(Lja/c;)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    goto :goto_0

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    new-instance v8, Lio/reactivex/internal/operators/flowable/g4$b;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-wide v3, p0, Lio/reactivex/internal/operators/flowable/g4;->c:J

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-wide v5, p0, Lio/reactivex/internal/operators/flowable/g4;->d:J

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget v7, p0, Lio/reactivex/internal/operators/flowable/g4;->e:I

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-direct/range {v1 .. v7}, Lio/reactivex/internal/operators/flowable/g4$b;-><init>(Lja/c;JJI)V

    invoke-interface {v0, v8}, Lja/b;->j(Lja/c;)V

    :goto_0
    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    return-void
.end method
