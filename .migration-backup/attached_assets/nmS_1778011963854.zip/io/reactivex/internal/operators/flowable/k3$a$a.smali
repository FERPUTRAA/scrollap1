.class final Lio/reactivex/internal/operators/flowable/k3$a$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/k3$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lja/d;",
        ">;",
        "Lja/c<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4d9aed7319193fc1L


# instance fields
.field final synthetic this$0:Lio/reactivex/internal/operators/flowable/k3$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/flowable/k3$a;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a$a;->this$0:Lio/reactivex/internal/operators/flowable/k3$a;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method


# virtual methods
.method public f(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "l1s~~K@i-~d ~  b @  l4  f~ @f~@ @@@@ bro/@@@o.mM~iSt~~~ou ~i@~@~~n@oo  b/@@~y~@ @~a~~@v  @co~s~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/k3$a$a;->this$0:Lio/reactivex/internal/operators/flowable/k3$a;

    const/4 v2, 0x0

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-boolean v0, p1, Lio/reactivex/internal/operators/flowable/k3$a;->gate:Z

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p1, Lja/d;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a$a;->this$0:Lio/reactivex/internal/operators/flowable/k3$a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-boolean v1, v0, Lio/reactivex/internal/operators/flowable/k3$a;->gate:Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a$a;->this$0:Lio/reactivex/internal/operators/flowable/k3$a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    iget-object v0, v0, Lio/reactivex/internal/operators/flowable/k3$a;->s:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Lio/reactivex/internal/subscriptions/p;->a(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/k3$a$a;->this$0:Lio/reactivex/internal/operators/flowable/k3$a;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/k3$a;->actual:Lja/c;

    const/4 v4, 0x1

    iget-object v2, v0, Lio/reactivex/internal/operators/flowable/k3$a;->error:Lio/reactivex/internal/util/c;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1, p1, v0, v2}, Lio/reactivex/internal/util/k;->d(Lja/c;Ljava/lang/Throwable;Ljava/util/concurrent/atomic/AtomicInteger;Lio/reactivex/internal/util/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lio/reactivex/internal/subscriptions/p;->j(Ljava/util/concurrent/atomic/AtomicReference;Lja/d;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method
