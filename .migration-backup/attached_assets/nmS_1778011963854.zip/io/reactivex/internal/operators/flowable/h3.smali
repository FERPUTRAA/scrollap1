.class public final Lio/reactivex/internal/operators/flowable/h3;
.super Lio/reactivex/internal/operators/flowable/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/flowable/h3$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/operators/flowable/a<",
        "TT;TT;>;"
    }
.end annotation


# instance fields
.field final c:J


# direct methods
.method public constructor <init>(Lja/b;J)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;J)V"
        }
    .end annotation

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lio/reactivex/internal/operators/flowable/a;-><init>(Lja/b;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/h3;->c:J

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected H5(Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ sSic~r abo~ ~~t@Kn ms@M/ di t @@v@o@@  ~~@@@y~~~@ou@~~@~l@ /~ b ~  ~f~i~~b @ @o@.-41@lo~~o@~~f"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/a;->b:Lja/b;

    const/4 v4, 0x5

    move v5, v4

    new-instance v1, Lio/reactivex/internal/operators/flowable/h3$a;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v2, p0, Lio/reactivex/internal/operators/flowable/h3;->c:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v1, p1, v2, v3}, Lio/reactivex/internal/operators/flowable/h3$a;-><init>(Lja/c;J)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method
