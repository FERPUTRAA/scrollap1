.class final Lio/reactivex/internal/operators/flowable/e3$a;
.super Lio/reactivex/internal/subscriptions/f;

# interfaces
.implements Lja/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/e3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/internal/subscriptions/f<",
        "TT;>;",
        "Lja/c<",
        "TT;>;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4cb078945f01c821L


# instance fields
.field final defaultValue:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field

.field done:Z

.field s:Lja/d;


# direct methods
.method constructor <init>(Lja/c;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;TT;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lio/reactivex/internal/subscriptions/f;-><init>(Lja/c;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/flowable/e3$a;->defaultValue:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public cancel()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@~ti~b~yitni~~@~~ M~- 1@~o~@ 4f~@S.~ls  f@ d@@ ub v/@ @~ml  ~ao~ @co~@ ~~@  @o@ o/@@br~ @@K~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-super {p0}, Lio/reactivex/internal/subscriptions/f;->cancel()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->s:Lja/d;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->done:Z

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x2

    move v2, p1

    move v2, p1

    const/4 v3, 0x3

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/e3$a;->done:Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/e3$a;->s:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, "etsetanc eSlenqnotonmecso!nnre u e  imeh"

    const/4 v3, 0x4

    const-string v1, " iemmlestunqna mnnoeceetotecora hnn !eSe"

    const-string v1, "Sequence contains more than one element!"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object p1, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->done:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->done:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lio/reactivex/internal/subscriptions/f;->value:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->defaultValue:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x5

    invoke-interface {v0}, Lja/c;->onComplete()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Lio/reactivex/internal/subscriptions/f;->a(Ljava/lang/Object;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->done:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/e3$a;->s:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/e3$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/subscriptions/f;->actual:Lja/c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x2

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method
