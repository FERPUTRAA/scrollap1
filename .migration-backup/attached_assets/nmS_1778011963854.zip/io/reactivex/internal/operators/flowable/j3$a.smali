.class final Lio/reactivex/internal/operators/flowable/j3$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lja/d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/flowable/j3;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "TT;>;",
        "Lja/d;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x4eca0434695949bbL


# instance fields
.field final actual:Lja/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/c<",
            "-TT;>;"
        }
    .end annotation
.end field

.field volatile cancelled:Z

.field final delayError:Z

.field volatile done:Z

.field error:Ljava/lang/Throwable;

.field final queue:Lio/reactivex/internal/queue/c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lio/reactivex/internal/queue/c<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final requested:Ljava/util/concurrent/atomic/AtomicLong;

.field s:Lja/d;

.field final scheduler:Lio/reactivex/e0;

.field final time:J

.field final unit:Ljava/util/concurrent/TimeUnit;


# direct methods
.method constructor <init>(Lja/c;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/c<",
            "-TT;>;J",
            "Ljava/util/concurrent/TimeUnit;",
            "Lio/reactivex/e0;",
            "IZ)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicLong;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->actual:Lja/c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-wide p2, p0, Lio/reactivex/internal/operators/flowable/j3$a;->time:J

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p4, p0, Lio/reactivex/internal/operators/flowable/j3$a;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p5, p0, Lio/reactivex/internal/operators/flowable/j3$a;->scheduler:Lio/reactivex/e0;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Lio/reactivex/internal/queue/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p1, p6}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->queue:Lio/reactivex/internal/queue/c;

    iput-boolean p7, p0, Lio/reactivex/internal/operators/flowable/j3$a;->delayError:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method a(ZZLja/c;Z)Z
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZZ",
            "Lja/c<",
            "-TT;>;Z)Z"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s fs@@ ct@~ ~ @@~/i/@@m@l~  KS b ~i ~~@~@iy~d@f@v 4@@~t -~l ro~a~M@ @@b~o. ~1~~o~@@bon~ u @~~o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->cancelled:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-eqz p4, :cond_2

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p2, :cond_4

    const/4 v2, 0x7

    move v3, v2

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->error:Ljava/lang/Throwable;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p3}, Lja/c;->onComplete()V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->error:Ljava/lang/Throwable;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object p2, p0, Lio/reactivex/internal/operators/flowable/j3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p2}, Lio/reactivex/internal/queue/c;->clear()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p3, p1}, Lja/c;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v1

    :cond_3
    const/4 v2, 0x2

    move v3, v2

    if-eqz p2, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p3}, Lja/c;->onComplete()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    return v1

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    return p1
.end method

.method b()V
    .locals 23

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    iget-object v1, v0, Lio/reactivex/internal/operators/flowable/j3$a;->actual:Lja/c;

    iget-object v2, v0, Lio/reactivex/internal/operators/flowable/j3$a;->queue:Lio/reactivex/internal/queue/c;

    iget-boolean v3, v0, Lio/reactivex/internal/operators/flowable/j3$a;->delayError:Z

    iget-object v4, v0, Lio/reactivex/internal/operators/flowable/j3$a;->unit:Ljava/util/concurrent/TimeUnit;

    iget-object v5, v0, Lio/reactivex/internal/operators/flowable/j3$a;->scheduler:Lio/reactivex/e0;

    iget-wide v6, v0, Lio/reactivex/internal/operators/flowable/j3$a;->time:J

    const/4 v9, 0x1

    :cond_1
    iget-object v10, v0, Lio/reactivex/internal/operators/flowable/j3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v10

    const-wide/16 v14, 0x0

    const-wide/16 v14, 0x0

    const-wide/16 v14, 0x0

    const-wide/16 v14, 0x0

    :goto_0
    cmp-long v16, v14, v10

    if-eqz v16, :cond_6

    iget-boolean v8, v0, Lio/reactivex/internal/operators/flowable/j3$a;->done:Z

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->peek()Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/lang/Long;

    if-nez v17, :cond_2

    const/16 v18, 0x1

    goto :goto_1

    :cond_2
    const/16 v18, 0x0

    :goto_1
    invoke-virtual {v5, v4}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v19

    if-nez v18, :cond_3

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Long;->longValue()J

    move-result-wide v21

    sub-long v19, v19, v6

    cmp-long v17, v21, v19

    if-lez v17, :cond_3

    const/4 v12, 0x1

    goto :goto_2

    :cond_3
    move/from16 v12, v18

    move/from16 v12, v18

    move/from16 v12, v18

    move/from16 v12, v18

    :goto_2
    invoke-virtual {v0, v8, v12, v1, v3}, Lio/reactivex/internal/operators/flowable/j3$a;->a(ZZLja/c;Z)Z

    move-result v8

    if-eqz v8, :cond_4

    return-void

    :cond_4
    if-eqz v12, :cond_5

    goto :goto_3

    :cond_5
    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    invoke-virtual {v2}, Lio/reactivex/internal/queue/c;->poll()Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v1, v8}, Lja/c;->f(Ljava/lang/Object;)V

    const-wide/16 v12, 0x1

    const-wide/16 v12, 0x1

    const-wide/16 v12, 0x1

    const-wide/16 v12, 0x1

    add-long/2addr v14, v12

    goto :goto_0

    :cond_6
    :goto_3
    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    cmp-long v8, v14, v10

    if-eqz v8, :cond_7

    iget-object v8, v0, Lio/reactivex/internal/operators/flowable/j3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    invoke-static {v8, v14, v15}, Lio/reactivex/internal/util/d;->e(Ljava/util/concurrent/atomic/AtomicLong;J)J

    :cond_7
    neg-int v8, v9

    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicInteger;->addAndGet(I)I

    move-result v9

    if-nez v9, :cond_1

    return-void
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->cancelled:Z

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->cancelled:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->s:Lja/d;

    const/4 v2, 0x4

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/queue/c;->clear()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->scheduler:Lio/reactivex/e0;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->unit:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lio/reactivex/e0;->d(Ljava/util/concurrent/TimeUnit;)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/flowable/j3$a;->queue:Lio/reactivex/internal/queue/c;

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v2, v0, p1}, Lio/reactivex/internal/queue/c;->p(Ljava/lang/Object;Ljava/lang/Object;)Z

    const/4 v4, 0x7

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j3$a;->b()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method

.method public g(J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lio/reactivex/internal/subscriptions/p;->l(J)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->requested:Ljava/util/concurrent/atomic/AtomicLong;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0, p1, p2}, Lio/reactivex/internal/util/d;->a(Ljava/util/concurrent/atomic/AtomicLong;J)J

    const/4 v2, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j3$a;->b()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->done:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j3$a;->b()V

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->error:Ljava/lang/Throwable;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-boolean p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->done:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/flowable/j3$a;->b()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->s:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/flowable/j3$a;->s:Lja/d;

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/flowable/j3$a;->actual:Lja/c;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Lja/c;->q(Lja/d;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x4

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    return-void
.end method
