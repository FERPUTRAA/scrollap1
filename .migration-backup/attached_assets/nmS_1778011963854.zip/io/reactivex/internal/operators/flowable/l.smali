.class public final Lio/reactivex/internal/operators/flowable/l;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, "sasoneNi !scs"

    const-string v1, "nNs sencaos!i"

    const/4 v3, 0x7

    const-string v1, "n omcitNas!en"

    const-string v1, "No instances!"

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw v0
.end method

.method public static a(Lja/b;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "+TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "c ~lo-~~ l@dv@ b@~~/  y~@@~@s@@4.@o @ M@t~~1 ir~a~@~@ooif@~S ~~~~ib~@   o/K~o~ @o nt fm@@b ~@~@u"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    new-instance v0, Lio/reactivex/internal/util/f;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v0}, Lio/reactivex/internal/util/f;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v1, Lio/reactivex/internal/subscribers/m;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Lio/reactivex/internal/functions/a;->g()Lt7/g;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v3, Lio/reactivex/internal/functions/a;->k:Lt7/g;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v1, v2, v0, v0, v3}, Lio/reactivex/internal/subscribers/m;-><init>(Lt7/g;Lt7/g;Lt7/a;Lt7/g;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {p0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lio/reactivex/internal/util/e;->a(Ljava/util/concurrent/CountDownLatch;Lio/reactivex/disposables/c;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p0, v0, Lio/reactivex/internal/util/f;->a:Ljava/lang/Throwable;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0}, Lio/reactivex/internal/util/j;->d(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw p0
.end method

.method public static b(Lja/b;Lja/c;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "+TT;>;",
            "Lja/c<",
            "-TT;>;)V"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v0, Ljava/util/concurrent/LinkedBlockingQueue;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v1, Lio/reactivex/internal/subscribers/f;

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    invoke-direct {v1, v0}, Lio/reactivex/internal/subscribers/f;-><init>(Ljava/util/Queue;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {p0, v1}, Lja/b;->j(Lja/c;)V

    :cond_0
    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1}, Lio/reactivex/internal/subscribers/f;->a()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/subscribers/f;->a()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {}, Lio/reactivex/internal/util/e;->b()V

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/concurrent/BlockingQueue;->take()Ljava/lang/Object;

    move-result-object v2

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1}, Lio/reactivex/internal/subscribers/f;->a()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v3, :cond_4

    const/4 v5, 0x0

    goto :goto_0

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v3, Lio/reactivex/internal/subscribers/f;->a:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eq p0, v3, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {v2, p1}, Lio/reactivex/internal/util/p;->d(Ljava/lang/Object;Lja/c;)Z

    move-result v2
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1}, Lio/reactivex/internal/subscribers/f;->cancel()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {p1, p0}, Lja/c;->onError(Ljava/lang/Throwable;)V

    :cond_5
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method public static c(Lja/b;Lt7/g;Lt7/g;Lt7/a;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lja/b<",
            "+TT;>;",
            "Lt7/g<",
            "-TT;>;",
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x0

    new-instance v0, Lio/reactivex/internal/subscribers/m;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object v1, Lio/reactivex/internal/functions/a;->k:Lt7/g;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, p1, p2, p3, v1}, Lio/reactivex/internal/subscribers/m;-><init>(Lt7/g;Lt7/g;Lt7/a;Lt7/g;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p0, v0}, Lio/reactivex/internal/operators/flowable/l;->b(Lja/b;Lja/c;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method
