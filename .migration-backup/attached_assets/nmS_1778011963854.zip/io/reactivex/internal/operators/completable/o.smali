.class public final Lio/reactivex/internal/operators/completable/o;
.super Lio/reactivex/c;


# instance fields
.field final a:Lt7/a;


# direct methods
.method public constructor <init>(Lt7/a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/o;->a:Lt7/a;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "1ysfo ob @nb @@~~ /~S@l@@~~~ ~~ t~~c@iKs@ @4~rd@o~l~ o  @~t. ~ f @a@/~ovb i~i~   @@M@@~@~m@~u-o@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    invoke-static {}, Lio/reactivex/disposables/d;->b()Lio/reactivex/disposables/c;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :try_start_0
    iget-object v1, p0, Lio/reactivex/internal/operators/completable/o;->a:Lt7/a;

    const/4 v3, 0x0

    invoke-interface {v1}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p1, v1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method
