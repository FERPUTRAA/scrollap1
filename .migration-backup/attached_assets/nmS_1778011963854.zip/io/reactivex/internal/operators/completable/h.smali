.class public final Lio/reactivex/internal/operators/completable/h;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:J

.field final c:Ljava/util/concurrent/TimeUnit;

.field final d:Lio/reactivex/e0;

.field final e:Z


# direct methods
.method public constructor <init>(Lio/reactivex/h;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h;->a:Lio/reactivex/h;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-wide p2, p0, Lio/reactivex/internal/operators/completable/h;->b:J

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p4, p0, Lio/reactivex/internal/operators/completable/h;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p5, p0, Lio/reactivex/internal/operators/completable/h;->d:Lio/reactivex/e0;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-boolean p6, p0, Lio/reactivex/internal/operators/completable/h;->e:Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ s~-ou~K.s~Mi@~t ~@o l~@ ~cob@o@4~~@@ @~i~@~~ ~@@~ /fob@@ ~@  1m ~ l @~b/@to @rv~@~ fSin y ~@d~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/h;->a:Lio/reactivex/h;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v2, Lio/reactivex/internal/operators/completable/h$a;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v2, p0, v0, p1}, Lio/reactivex/internal/operators/completable/h$a;-><init>(Lio/reactivex/internal/operators/completable/h;Lio/reactivex/disposables/b;Lio/reactivex/e;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-interface {v1, v2}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method
