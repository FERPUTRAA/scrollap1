.class final Lio/reactivex/internal/operators/completable/n0$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lio/reactivex/e;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/n0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Ljava/lang/Object;",
        ">;",
        "Lio/reactivex/e;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x95bf75d78cfb0efL


# instance fields
.field final actual:Lio/reactivex/e;

.field d:Lio/reactivex/disposables/c;

.field final disposer:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TR;>;"
        }
    .end annotation
.end field

.field final eager:Z


# direct methods
.method constructor <init>(Lio/reactivex/e;Ljava/lang/Object;Lt7/g;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/e;",
            "TR;",
            "Lt7/g<",
            "-TR;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/n0$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/n0$a;->disposer:Lt7/g;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-boolean p4, p0, Lio/reactivex/internal/operators/completable/n0$a;->eager:Z

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ so ~d~~oomrn @@y~@1/o~~~cvt@@~~@~ ~ba@fi ~-~ @@~ @~bs4@Slot o@  ~@~u@b~~K@@  ~@i@ /~fi  M  ~l@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    return v0
.end method

.method b()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-eq v0, p0, :cond_0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/n0$a;->disposer:Lt7/g;

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-interface {v1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->j(Lio/reactivex/disposables/c;Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/n0$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {p1, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v1, 0x6

    move v2, v1

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/n0$a;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->eager:Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eq v0, p0, :cond_0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/n0$a;->disposer:Lt7/g;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/n0$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->eager:Z

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/n0$a;->b()V

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    sget-object v0, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->d:Lio/reactivex/disposables/c;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->eager:Z

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, p0}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eq v0, p0, :cond_0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/n0$a;->disposer:Lt7/g;

    const/4 v4, 0x0

    move v5, v4

    invoke-interface {v1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v1, Lio/reactivex/exceptions/a;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-array v2, v2, [Ljava/lang/Throwable;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    aput-object p1, v2, v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 p1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    aput-object v0, v2, p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v1, v2}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/n0$a;->actual:Lio/reactivex/e;

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    move v5, v4

    iget-boolean p1, p0, Lio/reactivex/internal/operators/completable/n0$a;->eager:Z

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez p1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/n0$a;->b()V

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method
