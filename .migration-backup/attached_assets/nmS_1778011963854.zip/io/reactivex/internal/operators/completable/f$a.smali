.class final Lio/reactivex/internal/operators/completable/f$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lio/reactivex/d;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lio/reactivex/disposables/c;",
        ">;",
        "Lio/reactivex/d;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x223dd198233781a4L


# instance fields
.field final actual:Lio/reactivex/e;


# direct methods
.method constructor <init>(Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/f$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~sdbb  @r@ @o  ~~@M@@cl ~Kli@@@t 1@~~o  mSy~i~  ~@  ~~o.~~/ ~@@  ~~o~@@sv@ff~bo /4~@i@a@un~@t~-"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->c(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public b(Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lio/reactivex/internal/disposables/d;->g(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public c(Lt7/f;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lio/reactivex/internal/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lio/reactivex/internal/disposables/b;-><init>(Lt7/f;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/completable/f$a;->b(Lio/reactivex/disposables/c;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x1

    invoke-static {p0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eq v0, v1, :cond_1

    :try_start_0
    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/f$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v1}, Lio/reactivex/e;->onComplete()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw v1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v3, 0x3

    const-string v0, "lnnmlsc nuesaaetlsx sn  lg eyhwEdalt vr.o.uroaudasrrior iea  olw lroc   .retunlepnl2ldeNorelo"

    const-string v0, "eosew  nlsllraiu  elrllanhteo  seoacssdouep ot.r tednoru2a. a gelrynnllNardx  oE r.nclr ivuwl"

    const-string v0, "atdrorll.viea trnynsaa n scel owihdlrr oruue o aco. eo l .o nlnxe enus deolNeslatlw2uEgllprr "

    const-string v0, "onError called with null. Null values are generally not allowed in 2.x operators and sources."

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v1, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eq v0, v1, :cond_3

    invoke-virtual {p0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eq v0, v1, :cond_3

    :try_start_0
    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/f$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x1

    move v3, v2

    invoke-interface {v1, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    :cond_1
    const/4 v2, 0x5

    move v3, v2

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    throw p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method
