.class public final Lio/reactivex/internal/operators/completable/u;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;


# direct methods
.method public constructor <init>(Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/u;->a:Lio/reactivex/h;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "o s-~@io ~lb~.@o@@o@~d~~@lb~ @r@vM  @~@4~SK~n~ /@o@m t@ac@ @~@yoi~/ui~ s~  @ @@~  ~ ~~~@fb  ~~f1"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/u;->a:Lio/reactivex/h;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v2, 0x4

    return-void
.end method
