.class public final Lio/reactivex/internal/operators/completable/w;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lio/reactivex/g;


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lio/reactivex/g;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/w;->a:Lio/reactivex/h;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/w;->b:Lio/reactivex/g;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sct~b@~ ~ 4i@ ~~~@ K~~~~~f~oblSm~@l@@s~  ~on@~@@M@ /f@  ~@ ao@@i @  o~v ~u y/t~~@r@@o1@ dbo .i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/w;->b:Lio/reactivex/g;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lio/reactivex/g;->a(Lio/reactivex/e;)Lio/reactivex/e;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/w;->a:Lio/reactivex/h;

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V
    :try_end_0
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p1
.end method
