.class Lio/reactivex/internal/operators/completable/k$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/k;->C0(Lio/reactivex/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/e;

.field final synthetic b:Lio/reactivex/internal/operators/completable/k;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/k;Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/k$a;->b:Lio/reactivex/internal/operators/completable/k;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/k$a;->a:Lio/reactivex/e;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    or-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~sMf-/r~Sn@~ i @yl o~@  @@@tlo~cm   @.K@~o v  ~~~ti @~o@~~afb@~~uo@~@@/1i~@b~ ~ s @@~b ~ ~o@4d@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/k$a;->a:Lio/reactivex/e;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    return-void
.end method

.method public onComplete()V
    .locals 4

    :try_start_0
    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/k$a;->b:Lio/reactivex/internal/operators/completable/k;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/k;->b:Lt7/g;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/k$a;->a:Lio/reactivex/e;

    const/4 v3, 0x5

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/k$a;->a:Lio/reactivex/e;

    const/4 v2, 0x7

    move v3, v2

    invoke-interface {v1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    :try_start_0
    const/4 v5, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/k$a;->b:Lio/reactivex/internal/operators/completable/k;

    const/4 v5, 0x6

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/k;->b:Lt7/g;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v1, Lio/reactivex/exceptions/a;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x2

    move v5, v4

    new-array v2, v2, [Ljava/lang/Throwable;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object p1, v2, v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 p1, 0x1

    move v5, p1

    const/4 v4, 0x6

    and-int/2addr v5, v4

    aput-object v0, v2, p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1, v2}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/k$a;->a:Lio/reactivex/e;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-void
.end method
