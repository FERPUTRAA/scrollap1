.class public final Lio/reactivex/internal/operators/completable/z;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/z$a;
    }
.end annotation


# instance fields
.field final a:[Lio/reactivex/h;


# direct methods
.method public constructor <init>([Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/z;->a:[Lio/reactivex/h;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "f@s~~sa4 ~~ io @@~~~~~~v-or b K@@il i@~~t @@o ~@~  @@ @ d~/oo~cfu~~~/@@ @bm@ o~@S bM~ ~@tny@1l. "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x4

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/z;->a:[Lio/reactivex/h;

    const/4 v9, 0x2

    const/4 v8, 0x5

    array-length v2, v2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {v1, v2}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-instance v2, Lio/reactivex/internal/util/c;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct {v2}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v3, p0, Lio/reactivex/internal/operators/completable/z;->a:[Lio/reactivex/h;

    const/4 v9, 0x4

    const/4 v8, 0x4

    array-length v4, v3

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v5, 0x0

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    if-ge v5, v4, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    aget-object v6, v3, v5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v7

    const/4 v9, 0x7

    const/4 v8, 0x7

    if-eqz v7, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-void

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-nez v6, :cond_1

    const/4 v8, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    new-instance v6, Ljava/lang/NullPointerException;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string v7, "bremlcAspou utsseelc in om l"

    const-string v7, "lnseielllmctrosu oc b  eusAp"

    const/4 v9, 0x0

    const-string v7, "A completable source is null"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-direct {v6, v7}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v2, v6}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto :goto_1

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    new-instance v7, Lio/reactivex/internal/operators/completable/z$a;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {v7, p1, v0, v2, v1}, Lio/reactivex/internal/operators/completable/z$a;-><init>(Lio/reactivex/e;Lio/reactivex/disposables/b;Lio/reactivex/internal/util/c;Ljava/util/concurrent/atomic/AtomicInteger;)V

    const/4 v8, 0x2

    or-int/2addr v9, v8

    invoke-interface {v6, v7}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto :goto_0

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v0, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-virtual {v2}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v0, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_2

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    :cond_4
    :goto_2
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    return-void
.end method
