.class public final Lio/reactivex/internal/operators/completable/e;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/e$a;
    }
.end annotation


# instance fields
.field final a:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/e;->a:Ljava/lang/Iterable;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~Ssi@~@ ~~asd~ m~~~~~ ~-@ @ @o ~@  ~ lo~ vc@b~@4@r  ob~n@~f~. @~iK@@ u@fo~b~ /o /@t@ y@@tl@Mi~1@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e;->a:Ljava/lang/Iterable;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v1, " stmlaudti  Trenriueht nelosr"

    const-string v1, "dtsrs n ht lieutTlura eeorirn"

    const/4 v3, 0x0

    const-string/jumbo v1, "uheio rlue on teaTsderltn tir"

    const-string v1, "The iterator returned is null"

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    check-cast v0, Ljava/util/Iterator;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v1, Lio/reactivex/internal/operators/completable/e$a;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v1, p1, v0}, Lio/reactivex/internal/operators/completable/e$a;-><init>(Lio/reactivex/e;Ljava/util/Iterator;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    iget-object v0, v1, Lio/reactivex/internal/operators/completable/e$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/operators/completable/e$a;->a()V

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method
