.class Lio/reactivex/internal/operators/completable/h$a$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/h$a;->onError(Ljava/lang/Throwable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Throwable;

.field final synthetic b:Lio/reactivex/internal/operators/completable/h$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/h$a;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h$a$b;->b:Lio/reactivex/internal/operators/completable/h$a;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/h$a$b;->a:Ljava/lang/Throwable;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    shr-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i s@~ ~~o u@ ~sl @~~@@b~ad@ m.b~o~ o @~~~@o ~~/~S@oK@v@~@r~ i@@-@@1~cy@lf  ~fn/~@M @@~i o  4t~bt"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h$a$b;->b:Lio/reactivex/internal/operators/completable/h$a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/h$a;->b:Lio/reactivex/e;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/h$a$b;->a:Ljava/lang/Throwable;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method
