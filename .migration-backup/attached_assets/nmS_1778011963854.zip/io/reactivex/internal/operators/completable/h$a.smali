.class Lio/reactivex/internal/operators/completable/h$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/h;->C0(Lio/reactivex/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/disposables/b;

.field final synthetic b:Lio/reactivex/e;

.field final synthetic c:Lio/reactivex/internal/operators/completable/h;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/h;Lio/reactivex/disposables/b;Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h$a;->c:Lio/reactivex/internal/operators/completable/h;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/h$a;->a:Lio/reactivex/disposables/b;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/h$a;->b:Lio/reactivex/e;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "1 s@@f n i@s~@ o~~~-K   ~v@~@~~M~@@~ ~i~a@~ bt~ ~ b @/ fd @S@loo@~m ~~o~@t~y /r~@bi~@@@o@4coul ."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h$a;->a:Lio/reactivex/disposables/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/h$a;->b:Lio/reactivex/e;

    const/4 v1, 0x4

    or-int/2addr v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h$a;->a:Lio/reactivex/disposables/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h$a;->a:Lio/reactivex/disposables/b;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/h$a;->c:Lio/reactivex/internal/operators/completable/h;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v1, v1, Lio/reactivex/internal/operators/completable/h;->d:Lio/reactivex/e0;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-instance v2, Lio/reactivex/internal/operators/completable/h$a$a;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v2, p0}, Lio/reactivex/internal/operators/completable/h$a$a;-><init>(Lio/reactivex/internal/operators/completable/h$a;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/completable/h$a;->c:Lio/reactivex/internal/operators/completable/h;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-wide v4, v3, Lio/reactivex/internal/operators/completable/h;->b:J

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v3, v3, Lio/reactivex/internal/operators/completable/h;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, v2, v4, v5, v3}, Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h$a;->a:Lio/reactivex/disposables/b;

    const/4 v6, 0x7

    const/4 v5, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/h$a;->c:Lio/reactivex/internal/operators/completable/h;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, v1, Lio/reactivex/internal/operators/completable/h;->d:Lio/reactivex/e0;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Lio/reactivex/internal/operators/completable/h$a$b;

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-direct {v2, p0, p1}, Lio/reactivex/internal/operators/completable/h$a$b;-><init>(Lio/reactivex/internal/operators/completable/h$a;Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/h$a;->c:Lio/reactivex/internal/operators/completable/h;

    const/4 v5, 0x1

    move v6, v5

    iget-boolean v3, p1, Lio/reactivex/internal/operators/completable/h;->e:Z

    const/4 v6, 0x3

    if-eqz v3, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-wide v3, p1, Lio/reactivex/internal/operators/completable/h;->b:J

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x7

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p1, Lio/reactivex/internal/operators/completable/h;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v3, v4, p1}, Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void
.end method
