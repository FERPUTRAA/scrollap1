.class public final Lio/reactivex/internal/operators/completable/j0;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/j0$a;
    }
.end annotation


# instance fields
.field final a:J

.field final b:Ljava/util/concurrent/TimeUnit;

.field final c:Lio/reactivex/e0;


# direct methods
.method public constructor <init>(JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-wide p1, p0, Lio/reactivex/internal/operators/completable/j0;->a:J

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/j0;->b:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p4, p0, Lio/reactivex/internal/operators/completable/j0;->c:Lio/reactivex/e0;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    new-instance v0, Lio/reactivex/internal/operators/completable/j0$a;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Lio/reactivex/internal/operators/completable/j0$a;-><init>(Lio/reactivex/e;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/j0;->c:Lio/reactivex/e0;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-wide v1, p0, Lio/reactivex/internal/operators/completable/j0;->a:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v3, p0, Lio/reactivex/internal/operators/completable/j0;->b:Ljava/util/concurrent/TimeUnit;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v0, v1, v2, v3}, Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/completable/j0$a;->b(Lio/reactivex/disposables/c;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method
