.class public final Lio/reactivex/internal/operators/completable/c;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/c$a;
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field

.field final b:I


# direct methods
.method public constructor <init>(Lja/b;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+",
            "Lio/reactivex/h;",
            ">;I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/c;->a:Lja/b;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p2, p0, Lio/reactivex/internal/operators/completable/c;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~os ~ ~~-@l~ @t~aM@@@b 4@/@1.fs@~c~~  ~@~Ko n ti@ m~bibv~o@@ @d o~~~@o~o@ @~  ~~S fu/  ~li@y@r~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c;->a:Lja/b;

    const/4 v4, 0x7

    new-instance v1, Lio/reactivex/internal/operators/completable/c$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget v2, p0, Lio/reactivex/internal/operators/completable/c;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/completable/c$a;-><init>(Lio/reactivex/e;I)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    return-void
.end method
