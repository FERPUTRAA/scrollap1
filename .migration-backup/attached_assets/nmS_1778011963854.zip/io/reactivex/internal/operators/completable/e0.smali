.class public final Lio/reactivex/internal/operators/completable/e0;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lt7/r;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/r<",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lt7/r;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h;",
            "Lt7/r<",
            "-",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/e0;->a:Lio/reactivex/h;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/e0;->b:Lt7/r;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "o/s@~  try~ ~~4~ ~@ono   M~bi s~ ~~~  bt@~@~ u~@@vdofo@o@@@.@ll~~@@ ~~@ 1 ~S/c~@@@~@f-K@b@ai  ~i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e0;->a:Lio/reactivex/h;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Lio/reactivex/internal/operators/completable/e0$a;

    const/4 v2, 0x7

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/completable/e0$a;-><init>(Lio/reactivex/internal/operators/completable/e0;Lio/reactivex/e;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
