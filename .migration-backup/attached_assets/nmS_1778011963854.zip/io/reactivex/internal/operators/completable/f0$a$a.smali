.class Lio/reactivex/internal/operators/completable/f0$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/f0$a;->d(Lio/reactivex/disposables/c;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/disposables/c;

.field final synthetic b:Lio/reactivex/internal/operators/completable/f0$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/f0$a;Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/f0$a$a;->b:Lio/reactivex/internal/operators/completable/f0$a;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/f0$a$a;->a:Lio/reactivex/disposables/c;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s1~s@ @@b~ b@~cio@@ b ~y  o4v @f@~n~@~@~l~@~~ @~@rK~@ ia@ ~/  i@m@.-~~do tu~~oSlf@M@  o @~ot~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a$a;->b:Lio/reactivex/internal/operators/completable/f0$a;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->g:Lt7/a;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a$a;->a:Lio/reactivex/disposables/c;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
