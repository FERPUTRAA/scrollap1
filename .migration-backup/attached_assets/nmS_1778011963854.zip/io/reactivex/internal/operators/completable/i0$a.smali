.class Lio/reactivex/internal/operators/completable/i0$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/i0;->C0(Lio/reactivex/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final synthetic b:Lio/reactivex/disposables/b;

.field final synthetic c:Lio/reactivex/e;

.field final synthetic d:Lio/reactivex/internal/operators/completable/i0;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/i0;Ljava/util/concurrent/atomic/AtomicBoolean;Lio/reactivex/disposables/b;Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/i0$a;->d:Lio/reactivex/internal/operators/completable/i0;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/i0$a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/i0$a;->b:Lio/reactivex/disposables/b;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p4, p0, Lio/reactivex/internal/operators/completable/i0$a;->c:Lio/reactivex/e;

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ so @c ~omfv@@ b@ yu@~ @~i~n@~ ~o.  l@o  ~f S~~aM~@~@ /~t ~-4i1Kd@~~@oti @ s~~~@@ol@~bb@@@~ @r~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a;->b:Lio/reactivex/disposables/b;

    const/4 v4, 0x2

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->g()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a;->d:Lio/reactivex/internal/operators/completable/i0;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/i0;->e:Lio/reactivex/h;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a;->c:Lio/reactivex/e;

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/util/concurrent/TimeoutException;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/util/concurrent/TimeoutException;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v0, v1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v1, Lio/reactivex/internal/operators/completable/i0$a$a;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1, p0}, Lio/reactivex/internal/operators/completable/i0$a$a;-><init>(Lio/reactivex/internal/operators/completable/i0$a;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    :cond_1
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method
