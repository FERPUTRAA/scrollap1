.class public final Lio/reactivex/internal/operators/completable/k;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lt7/g;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h;",
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/k;->a:Lio/reactivex/h;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/k;->b:Lt7/g;

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@oso ~m~4 r~  ~b~@@K@c@ fn~~~/~S@~oi l.@ l ~o@v@ /~ f@is@ ~b~t@ ~bad~1y i@ @~~@@~- too@~ @~u@M~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/k;->a:Lio/reactivex/h;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v1, Lio/reactivex/internal/operators/completable/k$a;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/completable/k$a;-><init>(Lio/reactivex/internal/operators/completable/k;Lio/reactivex/e;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method
