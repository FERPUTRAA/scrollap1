.class public final Lio/reactivex/internal/operators/completable/b0;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/b0$a;
    }
.end annotation


# instance fields
.field final a:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b0;->a:Ljava/lang/Iterable;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "i s ~@@ bo1@lt-~@  o @dv~ ~@ ~@y@ @~lb@~@  @~ o~@@~@~t@o~ os4@fKa~@.obf@~i i~u~/~/~ r mS~~Mc~~n "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/b0;->a:Ljava/lang/Iterable;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v2, "lcnmoe ertusslr reeutdh Toratun rsie"

    const-string v2, "n sisure holl aroe  rretceuretdTutsn"

    const/4 v6, 0x6

    const-string v2, "cnduo il irorotereulu ate rntheTs se"

    const-string v2, "The source iterator returned is null"

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    check-cast v1, Ljava/util/Iterator;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v2, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v3, Lio/reactivex/internal/operators/completable/b0$a;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v3, p1, v0, v2}, Lio/reactivex/internal/operators/completable/b0$a;-><init>(Lio/reactivex/e;Lio/reactivex/disposables/b;Ljava/util/concurrent/atomic/AtomicInteger;)V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz p1, :cond_0

    const/4 v6, 0x1

    return-void

    :cond_0
    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    if-nez p1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v3}, Lio/reactivex/internal/operators/completable/b0$a;->onComplete()V

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void

    :cond_1
    const/4 v6, 0x3

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz p1, :cond_2

    const/4 v6, 0x4

    return-void

    :cond_2
    :try_start_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v4, "trll breTurh reol ttb capCoaaSuedneeuoiemnrlet"

    const-string v4, "eeamd nerteucrSu ltrhm tobunteapCiroToe alllre"

    const/4 v6, 0x5

    const-string/jumbo v4, "uretleu  olt ltnCaitan SrbuelrdueToh paecmeroe"

    const-string v4, "The iterator returned a null CompletableSource"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1, v4}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    check-cast p1, Lio/reactivex/h;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x4

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v4, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-interface {p1, v3}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3, p1}, Lio/reactivex/internal/operators/completable/b0$a;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-void

    :catchall_1
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-virtual {v3, p1}, Lio/reactivex/internal/operators/completable/b0$a;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void

    :catchall_2
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void
.end method
