.class public final Lio/reactivex/internal/operators/completable/g0;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lt7/o;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h;",
            "Lt7/o<",
            "-",
            "Ljava/lang/Throwable;",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/g0;->a:Lio/reactivex/h;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/g0;->b:Lt7/o;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s ~n rl~~ @~@@-1v@~@~d~ ~~@@ @f t.@of@ua ~s ot bm ~i ~~K b~@@y@~i@c~@oo l/o4i@~@/~S  ~@@ bo ~M"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    new-instance v0, Lio/reactivex/internal/disposables/k;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/g0;->a:Lio/reactivex/h;

    const/4 v3, 0x0

    move v4, v3

    new-instance v2, Lio/reactivex/internal/operators/completable/g0$a;

    const/4 v4, 0x2

    invoke-direct {v2, p0, p1, v0}, Lio/reactivex/internal/operators/completable/g0$a;-><init>(Lio/reactivex/internal/operators/completable/g0;Lio/reactivex/e;Lio/reactivex/internal/disposables/k;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {v1, v2}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method
