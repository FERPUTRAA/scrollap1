.class public final Lio/reactivex/internal/operators/completable/a;
.super Lio/reactivex/c;


# instance fields
.field private final a:[Lio/reactivex/h;

.field private final b:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>([Lio/reactivex/h;Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lio/reactivex/h;",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/a;->a:[Lio/reactivex/h;

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/a;->b:Ljava/lang/Iterable;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v10, "uSso@o@~ /~ y@o@@@o@i@b~ m@~t~r~i~~n~ MK~s /o v@~~@ i~1-t~b @ ~c~ @fb~~@@ @ ~.@ @a d@f~lol  4 @~"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/a;->a:[Lio/reactivex/h;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v1, " usOrho tus lnleo  eesinsc"

    const/4 v11, 0x7

    const-string/jumbo v1, "tnumoOs oesec  lsnuirl h f"

    const-string v1, "One of the sources is null"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v2, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-nez v0, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    const/16 v0, 0x8

    const/4 v11, 0x2

    const/4 v10, 0x1

    new-array v0, v0, [Lio/reactivex/h;

    :try_start_0
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-object v3, p0, Lio/reactivex/internal/operators/completable/a;->b:Ljava/lang/Iterable;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x7

    move v4, v2

    const/4 v11, 0x2

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eqz v5, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    check-cast v5, Lio/reactivex/h;

    const/4 v11, 0x3

    if-nez v5, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v11, 0x6

    return-void

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    array-length v6, v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-ne v4, v6, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    shr-int/lit8 v6, v4, 0x2

    const/4 v11, 0x2

    add-int/2addr v6, v4

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    new-array v6, v6, [Lio/reactivex/h;

    const/4 v11, 0x6

    const/4 v10, 0x0

    invoke-static {v0, v2, v6, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    add-int/lit8 v6, v4, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    aput-object v5, v0, v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    move v4, v6

    move v4, v6

    const/4 v11, 0x0

    move v4, v6

    move v4, v6

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    return-void

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    array-length v4, v0

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-instance v3, Lio/reactivex/disposables/b;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-direct {v3}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-interface {p1, v3}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-instance v5, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-direct {v5}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v11, 0x6

    new-instance v6, Lio/reactivex/internal/operators/completable/a$a;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-direct {v6, p0, v5, v3, p1}, Lio/reactivex/internal/operators/completable/a$a;-><init>(Lio/reactivex/internal/operators/completable/a;Ljava/util/concurrent/atomic/AtomicBoolean;Lio/reactivex/disposables/b;Lio/reactivex/e;)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    move v7, v2

    move v7, v2

    const/4 v11, 0x7

    move v7, v2

    move v7, v2

    :goto_1
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-ge v7, v4, :cond_7

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    aget-object v8, v0, v7

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v3}, Lio/reactivex/disposables/b;->a()Z

    move-result v9

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-eqz v9, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    return-void

    :cond_4
    const/4 v10, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-nez v8, :cond_6

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    const/4 v1, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v5, v2, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    if-eqz v1, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v3}, Lio/reactivex/disposables/b;->e()V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v11, 0x1

    goto :goto_2

    :cond_5
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_2
    const/4 v11, 0x5

    return-void

    :cond_6
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-interface {v8, v6}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_7
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-nez v4, :cond_8

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    :cond_8
    const/4 v10, 0x7

    move v11, v10

    return-void
.end method
