.class public final Lio/reactivex/internal/operators/completable/b;
.super Lio/reactivex/c;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/b$a;
    }
.end annotation

.annotation build Ls7/e;
.end annotation


# static fields
.field static final e:[Lio/reactivex/internal/operators/completable/b$a;

.field static final f:[Lio/reactivex/internal/operators/completable/b$a;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Ljava/util/concurrent/atomic/AtomicReference;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/atomic/AtomicReference<",
            "[",
            "Lio/reactivex/internal/operators/completable/b$a;",
            ">;"
        }
    .end annotation
.end field

.field final c:Ljava/util/concurrent/atomic/AtomicBoolean;

.field d:Ljava/lang/Throwable;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-array v1, v0, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    sput-object v1, Lio/reactivex/internal/operators/completable/b;->e:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v3, 0x7

    new-array v0, v0, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput-object v0, Lio/reactivex/internal/operators/completable/b;->f:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>(Lio/reactivex/h;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b;->a:Lio/reactivex/h;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lio/reactivex/internal/operators/completable/b;->e:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ sm@~~b@t~o~~i~v@ .l ~ u/@dSMo-~~~i@@~o@    1 ~ ~@@~i~b ~@n@@by oco f ~~at~@/@4@ol @@ K~fs@~@ r"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    new-instance v0, Lio/reactivex/internal/operators/completable/b$a;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0, p0, p1}, Lio/reactivex/internal/operators/completable/b$a;-><init>(Lio/reactivex/internal/operators/completable/b;Lio/reactivex/e;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/completable/b;->a1(Lio/reactivex/internal/operators/completable/b$a;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Lio/reactivex/internal/operators/completable/b$a;->a()Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/completable/b;->b1(Lio/reactivex/internal/operators/completable/b$a;)V

    :cond_0
    const/4 v3, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/b;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    if-eqz p1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/b;->a:Lio/reactivex/h;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1, p0}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b;->d:Ljava/lang/Throwable;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    :cond_3
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method a1(Lio/reactivex/internal/operators/completable/b$a;)Z
    .locals 6

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    check-cast v0, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v1, Lio/reactivex/internal/operators/completable/b;->f:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ne v0, v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v2

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    array-length v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/lit8 v3, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-array v3, v3, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v0, v2, v3, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object p1, v3, v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v1, v0, v3}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    return p1
.end method

.method b1(Lio/reactivex/internal/operators/completable/b$a;)V
    .locals 8

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    check-cast v0, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v7, 0x0

    array-length v1, v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    if-nez v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-void

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ge v3, v1, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    aget-object v4, v0, v3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-ne v4, p1, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_0

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v3, -0x1

    :goto_1
    if-gez v3, :cond_4

    const/4 v6, 0x5

    const/4 v6, 0x7

    return-void

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ne v1, v4, :cond_5

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget-object v1, Lio/reactivex/internal/operators/completable/b;->e:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v7, 0x6

    goto :goto_2

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x6

    add-int/lit8 v5, v1, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-array v5, v5, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0, v2, v5, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x6

    move v7, v6

    add-int/lit8 v2, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    sub-int/2addr v1, v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    sub-int/2addr v1, v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, v2, v5, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    :goto_2
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v2, v0, v1}, Landroidx/lifecycle/f0;->a(Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget-object v1, Lio/reactivex/internal/operators/completable/b;->f:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v0, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    array-length v1, v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ge v2, v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    aget-object v3, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, v3, Lio/reactivex/internal/operators/completable/b$a;->actual:Lio/reactivex/e;

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v3}, Lio/reactivex/e;->onComplete()V

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b;->d:Ljava/lang/Throwable;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b;->b:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v5, 0x5

    move v6, v5

    sget-object v1, Lio/reactivex/internal/operators/completable/b;->f:[Lio/reactivex/internal/operators/completable/b$a;

    const/4 v5, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast v0, [Lio/reactivex/internal/operators/completable/b$a;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    array-length v1, v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-ge v2, v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    aget-object v3, v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, v3, Lio/reactivex/internal/operators/completable/b$a;->actual:Lio/reactivex/e;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v3, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    return-void
.end method
