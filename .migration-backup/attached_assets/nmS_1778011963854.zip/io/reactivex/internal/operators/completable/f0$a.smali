.class Lio/reactivex/internal/operators/completable/f0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/f0;->C0(Lio/reactivex/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/e;

.field final synthetic b:Lio/reactivex/internal/operators/completable/f0;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/f0;Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/f0$a;->a:Lio/reactivex/e;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method a()V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " us@~~~~@~l@b ~~@ ~ oM/ ~s   r~@~@@@@obt~1@ .f ~@yn K~~oa~tii@/4mc do@~  @ifo@l b@ o@~@S ~v@-~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->f:Lt7/a;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->b:Lt7/g;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->a:Lio/reactivex/e;

    const/4 v3, 0x3

    const/4 v2, 0x1

    new-instance v1, Lio/reactivex/internal/operators/completable/f0$a$a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/completable/f0$a$a;-><init>(Lio/reactivex/internal/operators/completable/f0$a;Lio/reactivex/disposables/c;)V

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    invoke-static {v1}, Lio/reactivex/disposables/d;->f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p1}, Lio/reactivex/disposables/c;->e()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/f0$a;->a:Lio/reactivex/e;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 4

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->d:Lt7/a;

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-interface {v0}, Lt7/a;->run()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v3, 0x0

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->e:Lt7/a;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->a:Lio/reactivex/e;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/f0$a;->a()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/f0$a;->a:Lio/reactivex/e;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {v1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 6

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v5, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->c:Lt7/g;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v0, p1}, Lt7/g;->accept(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->b:Lio/reactivex/internal/operators/completable/f0;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/f0;->e:Lt7/a;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v1, Lio/reactivex/exceptions/a;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-array v2, v2, [Ljava/lang/Throwable;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    aput-object p1, v2, v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    aput-object v0, v2, p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0$a;->a:Lio/reactivex/e;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/f0$a;->a()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void
.end method
