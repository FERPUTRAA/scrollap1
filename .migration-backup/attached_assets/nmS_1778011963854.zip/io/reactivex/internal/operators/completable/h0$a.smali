.class final Lio/reactivex/internal/operators/completable/h0$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lio/reactivex/e;
.implements Lio/reactivex/disposables/c;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/h0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lio/reactivex/disposables/c;",
        ">;",
        "Lio/reactivex/e;",
        "Lio/reactivex/disposables/c;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x61283b9e254a3eafL


# instance fields
.field final actual:Lio/reactivex/e;

.field final source:Lio/reactivex/h;

.field final task:Lio/reactivex/internal/disposables/k;


# direct methods
.method constructor <init>(Lio/reactivex/e;Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h0$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/h0$a;->source:Lio/reactivex/h;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    new-instance p1, Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p1}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h0$a;->task:Lio/reactivex/internal/disposables/k;

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s/ KooM~otbc 1lo@~o~ ~b@@@~~ r/@  s@f @v@lfa@~~.~ m~~ii~t~b~ ~o@~ @@  ud~@iy-@ ~@ n~ S @~~@~@4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->c(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lio/reactivex/internal/disposables/d;->h(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h0$a;->task:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->e()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h0$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h0$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public run()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h0$a;->source:Lio/reactivex/h;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method
