.class public final Lio/reactivex/internal/operators/completable/y;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/y$a;
    }
.end annotation


# instance fields
.field final a:[Lio/reactivex/h;


# direct methods
.method public constructor <init>([Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/y;->a:[Lio/reactivex/h;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance v2, Lio/reactivex/internal/operators/completable/y$a;

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v3, p0, Lio/reactivex/internal/operators/completable/y;->a:[Lio/reactivex/h;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    array-length v3, v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {v2, p1, v1, v0, v3}, Lio/reactivex/internal/operators/completable/y$a;-><init>(Lio/reactivex/e;Ljava/util/concurrent/atomic/AtomicBoolean;Lio/reactivex/disposables/b;I)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v7, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/y;->a:[Lio/reactivex/h;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    array-length v1, p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-ge v3, v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    aget-object v4, p1, v3

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v5, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-nez v4, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v0, "l saclum t esl oeboAcupissrn"

    const-string v0, "alsrblc pn tAoeiulo eml cuss"

    const/4 v7, 0x0

    const-string v0, "A completable source is null"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v2, p1}, Lio/reactivex/internal/operators/completable/y$a;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-void

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-interface {v4, v2}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2}, Lio/reactivex/internal/operators/completable/y$a;->onComplete()V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-void
.end method
