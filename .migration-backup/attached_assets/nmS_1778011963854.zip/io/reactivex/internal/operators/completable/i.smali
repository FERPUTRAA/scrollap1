.class public final Lio/reactivex/internal/operators/completable/i;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/i$a;
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lio/reactivex/e0;


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/i;->a:Lio/reactivex/h;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/i;->b:Lio/reactivex/e0;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ soi~@o.~b @@@4~@1@~ o@@o~ @o@S-K~c~ oi~~~~fn/~~y@~@ a   l   ~t@ M~ l@sm@ @ ri/~dvu~~@@fbt@~ @~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i;->a:Lio/reactivex/h;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v1, Lio/reactivex/internal/operators/completable/i$a;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/i;->b:Lio/reactivex/e0;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/completable/i$a;-><init>(Lio/reactivex/e;Lio/reactivex/e0;)V

    const/4 v4, 0x6

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method
