.class final Lio/reactivex/internal/operators/completable/b0$a;
.super Ljava/util/concurrent/atomic/AtomicBoolean;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/b0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x6b4850cfa68eb5b8L


# instance fields
.field final actual:Lio/reactivex/e;

.field final set:Lio/reactivex/disposables/b;

.field final wip:Ljava/util/concurrent/atomic/AtomicInteger;


# direct methods
.method constructor <init>(Lio/reactivex/e;Lio/reactivex/disposables/b;Ljava/util/concurrent/atomic/AtomicInteger;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b0$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/b0$a;->set:Lio/reactivex/disposables/b;

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/b0$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s~ ~sK@~r@@/o~ f@a~l uml@b@ i@~~ @   @d f@ob~ovoi@.4 t~@~M @@ @1~@~o~bn~@~~  c~@Sy~oi   ~-@/t@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b0$a;->set:Lio/reactivex/disposables/b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b0$a;->wip:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x7

    shr-int/2addr v2, v1

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b0$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b0$a;->set:Lio/reactivex/disposables/b;

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b0$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
