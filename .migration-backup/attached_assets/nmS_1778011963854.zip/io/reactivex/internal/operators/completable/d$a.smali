.class final Lio/reactivex/internal/operators/completable/d$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x6e8ac9652ad7cd50L


# instance fields
.field final actual:Lio/reactivex/e;

.field index:I

.field final sd:Lio/reactivex/internal/disposables/k;

.field final sources:[Lio/reactivex/h;


# direct methods
.method constructor <init>(Lio/reactivex/e;[Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/d$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/d$a;->sources:[Lio/reactivex/h;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    new-instance p1, Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p1}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/d$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "bls@ ~oy~@o/K r4 @@@@t~l~@u@  ~in/  ~a@~Mi~@oo f1i@~~~@~b@   ~ ~o.f c ~b@~-@ d~~@sm~@ S@ ~o@~v~t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/d$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->a()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/d$a;->sources:[Lio/reactivex/h;

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/d$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v4, 0x3

    invoke-virtual {v1}, Lio/reactivex/internal/disposables/k;->a()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void

    :cond_3
    const/4 v4, 0x4

    iget v1, p0, Lio/reactivex/internal/operators/completable/d$a;->index:I

    const/4 v3, 0x6

    move v4, v3

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v2, p0, Lio/reactivex/internal/operators/completable/d$a;->index:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length v2, v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne v1, v2, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/d$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void

    :cond_4
    const/4 v4, 0x2

    aget-object v1, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v1, p0}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_2

    const/4 v4, 0x3

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/d$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/disposables/k;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x0

    return-void
.end method

.method public onComplete()V
    .locals 2

    const/4 v1, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/d$a;->a()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/d$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method
