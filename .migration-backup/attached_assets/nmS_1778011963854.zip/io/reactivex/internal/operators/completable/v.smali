.class public final Lio/reactivex/internal/operators/completable/v;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/v$a;
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/h;


# direct methods
.method public constructor <init>(Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/v;->a:Lio/reactivex/h;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "lmsfl~/~nto~@ia~o1@o @s~~y~r  b @ @~~f@b ~@4~K~~@@o ~ SM~c~o@ @idu/ @@@ @@v  @o-b t~~ @~i. @~~@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/v;->a:Lio/reactivex/h;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v1, Lio/reactivex/internal/operators/completable/v$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v1, p1}, Lio/reactivex/internal/operators/completable/v$a;-><init>(Lio/reactivex/e;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v2, 0x3

    move v3, v2

    return-void
.end method
