.class public final Lio/reactivex/internal/operators/completable/n0;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/n0$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<R:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/c;"
    }
.end annotation


# instance fields
.field final a:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "TR;>;"
        }
    .end annotation
.end field

.field final b:Lt7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/o<",
            "-TR;+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field

.field final c:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-TR;>;"
        }
    .end annotation
.end field

.field final d:Z


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;Lt7/o;Lt7/g;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "TR;>;",
            "Lt7/o<",
            "-TR;+",
            "Lio/reactivex/h;",
            ">;",
            "Lt7/g<",
            "-TR;>;Z)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/n0;->a:Ljava/util/concurrent/Callable;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/n0;->b:Lt7/o;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/n0;->c:Lt7/g;

    const/4 v1, 0x3

    iput-boolean p4, p0, Lio/reactivex/internal/operators/completable/n0;->d:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "irsb  a~ i~SMvou@@  @n@@~~~o @~~~b@@oy f~ t~@~ ~~.i~o@/d-@ 41 o@ @c~o~sK@@~ ~~l@@  ~m@/~@b ~l @t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/n0;->a:Ljava/util/concurrent/Callable;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/n0;->b:Lt7/o;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v1, v0}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v2, "ib mnlncleCr mSuosuTrleoleont caepeura ecmbt putFtlleendh"

    const-string v2, "alse TroupbreroSlettln C tcaelennulbecchmmiaeuloe un dFpt"

    const/4 v6, 0x4

    const-string v2, "elTbouuaporcc Fe tuomr hinepuleetoeleotbecrndtlCmalnanl  "

    const-string v2, "The completableFunction returned a null CompletableSource"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v1, Lio/reactivex/h;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Lio/reactivex/internal/operators/completable/n0$a;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v3, p0, Lio/reactivex/internal/operators/completable/n0;->c:Lt7/g;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean v4, p0, Lio/reactivex/internal/operators/completable/n0;->d:Z

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v2, p1, v0, v3, v4}, Lio/reactivex/internal/operators/completable/n0$a;-><init>(Lio/reactivex/e;Ljava/lang/Object;Lt7/g;Z)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-interface {v1, v2}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    iget-boolean v2, p0, Lio/reactivex/internal/operators/completable/n0;->d:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_0

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/n0;->c:Lt7/g;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v2, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :catchall_1
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v2, Lio/reactivex/exceptions/a;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-array v3, v3, [Ljava/lang/Throwable;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    aput-object v1, v3, v4

    const/4 v5, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    aput-object v0, v3, v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v2, v3}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v2, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void

    :cond_0
    :goto_0
    const/4 v6, 0x4

    invoke-static {v1, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean p1, p0, Lio/reactivex/internal/operators/completable/n0;->d:Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    if-nez p1, :cond_1

    :try_start_3
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/n0;->c:Lt7/g;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {p1, v0}, Lt7/g;->accept(Ljava/lang/Object;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_1

    :catchall_2
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void

    :catchall_3
    move-exception v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-void
.end method
