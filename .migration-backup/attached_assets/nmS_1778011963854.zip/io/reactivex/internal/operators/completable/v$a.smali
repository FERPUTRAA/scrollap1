.class final Lio/reactivex/internal/operators/completable/v$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/v;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field final a:Lio/reactivex/e;

.field b:Lio/reactivex/disposables/c;


# direct methods
.method constructor <init>(Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/v$a;->a:Lio/reactivex/e;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s~K a~o~f@bivi.t o~@@b f  @@@oo@  @~~~@@ @@ n@~~@~/@@tM4 ~   Sl-/y o1d~s@ ~~~~~ @ umli~r@~c~ob"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/v$a;->b:Lio/reactivex/disposables/c;

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/v$a;->b:Lio/reactivex/disposables/c;

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->j(Lio/reactivex/disposables/c;Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/v$a;->b:Lio/reactivex/disposables/c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/v$a;->a:Lio/reactivex/e;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {p1, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/v$a;->b:Lio/reactivex/disposables/c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/v$a;->b:Lio/reactivex/disposables/c;

    const/4 v2, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/v$a;->a:Lio/reactivex/e;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/v$a;->a:Lio/reactivex/e;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method
