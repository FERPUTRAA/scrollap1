.class final Lio/reactivex/internal/operators/completable/y$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/y;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x7406a1ef165c572aL


# instance fields
.field final actual:Lio/reactivex/e;

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final set:Lio/reactivex/disposables/b;


# direct methods
.method constructor <init>(Lio/reactivex/e;Ljava/util/concurrent/atomic/AtomicBoolean;Lio/reactivex/disposables/b;I)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/y$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/y$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/y$a;->set:Lio/reactivex/disposables/b;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p4}, Ljava/util/concurrent/atomic/AtomicInteger;->lazySet(I)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "d svbsnit~otu~ f4 r  .~lio~@-~i @@~o@~@l~@1@~cb~o@@S o ~KM@ @~@@@~~o~~/@   ~m @~ ~@@y~@@ ~f/  b~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/y$a;->set:Lio/reactivex/disposables/b;

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/y$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/y$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    :cond_0
    const/4 v4, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/y$a;->set:Lio/reactivex/disposables/b;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/y$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/y$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    return-void
.end method
