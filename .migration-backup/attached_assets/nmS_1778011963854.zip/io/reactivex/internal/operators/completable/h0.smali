.class public final Lio/reactivex/internal/operators/completable/h0;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/h0$a;
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lio/reactivex/e0;


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lio/reactivex/e0;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h0;->a:Lio/reactivex/h;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/h0;->b:Lio/reactivex/e0;

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bts o@o~@@tsM ~@ @u~vro  @~@~  @@o~1bi@i  i 4fn@~Kc~/.f~~~l@@ d@~@ S~/~@o~y~o   ~  -@ml~a~@@~~~b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    new-instance v0, Lio/reactivex/internal/operators/completable/h0$a;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/h0;->a:Lio/reactivex/h;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Lio/reactivex/internal/operators/completable/h0$a;-><init>(Lio/reactivex/e;Lio/reactivex/h;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/h0;->b:Lio/reactivex/e0;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Lio/reactivex/e0;->f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/h0$a;->task:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/internal/disposables/k;->b(Lio/reactivex/disposables/c;)Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-void
.end method
