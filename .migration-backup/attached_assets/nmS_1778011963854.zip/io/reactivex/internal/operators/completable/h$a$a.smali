.class Lio/reactivex/internal/operators/completable/h$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/h$a;->onComplete()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/internal/operators/completable/h$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/h$a;)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/h$a$a;->a:Lio/reactivex/internal/operators/completable/h$a;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ts~@~/s@o ~~@a~l@~~~@mMo i il ~ 4 ~-o  S /rdfo@~~@~c@@b@o  @~~ bf~@Kb y. ~@ @@1@~@nou v~ @it@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/h$a$a;->a:Lio/reactivex/internal/operators/completable/h$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/h$a;->b:Lio/reactivex/e;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x6

    return-void
.end method
