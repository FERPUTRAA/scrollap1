.class final Lio/reactivex/internal/operators/completable/j$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lio/reactivex/e;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/j;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x3907ba0b13897e3dL


# instance fields
.field final actual:Lio/reactivex/e;

.field d:Lio/reactivex/disposables/c;

.field final onFinally:Lt7/a;


# direct methods
.method constructor <init>(Lio/reactivex/e;Lt7/a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/j$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/j$a;->onFinally:Lt7/a;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/disposables/c;->a()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method b()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j$a;->onFinally:Lt7/a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0}, Lt7/a;->run()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->j(Lio/reactivex/disposables/c;Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/j$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/j$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x2

    invoke-interface {p1, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j$a;->d:Lio/reactivex/disposables/c;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/j$a;->b()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x7

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/j$a;->b()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/j$a;->b()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method
