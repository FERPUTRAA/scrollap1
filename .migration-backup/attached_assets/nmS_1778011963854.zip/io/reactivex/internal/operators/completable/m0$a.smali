.class Lio/reactivex/internal/operators/completable/m0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/m0;->K0(Lio/reactivex/h0;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/h0;

.field final synthetic b:Lio/reactivex/internal/operators/completable/m0;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/m0;Lio/reactivex/h0;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/m0$a;->b:Lio/reactivex/internal/operators/completable/m0;

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/m0$a;->a:Lio/reactivex/h0;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s~r~@ ~@ily@ ooab-n@t  1@~@f@dM~~t  s@4~@~~ b~~~@@m o /~~~lS@~ .@ovf~ ~ ~i@K@boi@~/~@u o@ ~ c "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/m0$a;->a:Lio/reactivex/h0;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lio/reactivex/h0;->d(Lio/reactivex/disposables/c;)V

    const/4 v2, 0x6

    return-void
.end method

.method public onComplete()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/m0$a;->b:Lio/reactivex/internal/operators/completable/m0;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v1, v0, Lio/reactivex/internal/operators/completable/m0;->b:Ljava/util/concurrent/Callable;

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v3, 0x1

    move v4, v3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/m0$a;->a:Lio/reactivex/h0;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v1, v0}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/m0;->c:Ljava/lang/Object;

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/m0$a;->a:Lio/reactivex/h0;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/NullPointerException;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, " sdmuspsl hnTlveulieiau  p"

    const-string v2, "spsi v uu lelnlhdeeT uispa"

    const/4 v4, 0x5

    const-string v2, "lae ouu pl s hlnTepldseuii"

    const-string v2, "The value supplied is null"

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    move v4, v3

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/m0$a;->a:Lio/reactivex/h0;

    const/4 v4, 0x0

    invoke-interface {v1, v0}, Lio/reactivex/h0;->onSuccess(Ljava/lang/Object;)V

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/m0$a;->a:Lio/reactivex/h0;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Lio/reactivex/h0;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method
