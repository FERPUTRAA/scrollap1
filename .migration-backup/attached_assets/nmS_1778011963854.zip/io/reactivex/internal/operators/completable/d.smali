.class public final Lio/reactivex/internal/operators/completable/d;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/d$a;
    }
.end annotation


# instance fields
.field final a:[Lio/reactivex/h;


# direct methods
.method public constructor <init>([Lio/reactivex/h;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/d;->a:[Lio/reactivex/h;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lio/reactivex/internal/operators/completable/d$a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/d;->a:[Lio/reactivex/h;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, p1, v1}, Lio/reactivex/internal/operators/completable/d$a;-><init>(Lio/reactivex/e;[Lio/reactivex/h;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, v0, Lio/reactivex/internal/operators/completable/d$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1, v1}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Lio/reactivex/internal/operators/completable/d$a;->a()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method
