.class Lio/reactivex/internal/operators/completable/e0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/e0;->C0(Lio/reactivex/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/e;

.field final synthetic b:Lio/reactivex/internal/operators/completable/e0;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/e0;Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/e0$a;->b:Lio/reactivex/internal/operators/completable/e0;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/e0$a;->a:Lio/reactivex/e;

    const/4 v1, 0x5

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@cs~yr~@~t /~n~@  @~@S~@t 4lisoo@@i -~a@b ~ @@i~ b1@v~/@@ @o o o  ~K~@~flbu~d~  m@M ~~@~~~~.@fo "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e0$a;->a:Lio/reactivex/e;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e0$a;->a:Lio/reactivex/e;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 7

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e0$a;->b:Lio/reactivex/internal/operators/completable/e0;

    const/4 v6, 0x2

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/e0;->b:Lt7/r;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {v0, p1}, Lt7/r;->test(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/e0$a;->a:Lio/reactivex/e;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e0$a;->a:Lio/reactivex/e;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v5, 0x0

    xor-int/2addr v6, v5

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/e0$a;->a:Lio/reactivex/e;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v2, Lio/reactivex/exceptions/a;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v3, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-array v3, v3, [Ljava/lang/Throwable;

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    move v6, v5

    aput-object p1, v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 p1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    aput-object v0, v3, p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v2, v3}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v1, v2}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void
.end method
