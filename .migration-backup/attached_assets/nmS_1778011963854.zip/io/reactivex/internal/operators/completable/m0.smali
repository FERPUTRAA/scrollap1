.class public final Lio/reactivex/internal/operators/completable/m0;
.super Lio/reactivex/f0;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/f0<",
        "TT;>;"
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+TT;>;"
        }
    .end annotation
.end field

.field final c:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TT;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lio/reactivex/h;Ljava/util/concurrent/Callable;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h;",
            "Ljava/util/concurrent/Callable<",
            "+TT;>;TT;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Lio/reactivex/f0;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/m0;->a:Lio/reactivex/h;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/m0;->c:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/m0;->b:Ljava/util/concurrent/Callable;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected K0(Lio/reactivex/h0;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h0<",
            "-TT;>;)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "t~s~@@fubi~b~fa~@@Ml1o ~4~ mo td@@~~ @~~ ~ S~ i @@@@~ ~   y~@@@K~@  ~o @vlboir./@~~@~s@o c /n-o~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/m0;->a:Lio/reactivex/h;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance v1, Lio/reactivex/internal/operators/completable/m0$a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/completable/m0$a;-><init>(Lio/reactivex/internal/operators/completable/m0;Lio/reactivex/h0;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method
