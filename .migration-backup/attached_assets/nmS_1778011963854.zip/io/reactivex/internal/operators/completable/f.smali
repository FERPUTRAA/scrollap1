.class public final Lio/reactivex/internal/operators/completable/f;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/f$a;
    }
.end annotation


# instance fields
.field final a:Lio/reactivex/f;


# direct methods
.method public constructor <init>(Lio/reactivex/f;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/f;->a:Lio/reactivex/f;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " fsi s ~~~ @@ ~~v S@t~ @@@b.@yco/lni  ~ ~@~a@~4~M~@~~@ o-@~fdb~~o@@~u@lt@~1@o r~~@  K io@ o@/m~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lio/reactivex/internal/operators/completable/f$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Lio/reactivex/internal/operators/completable/f$a;-><init>(Lio/reactivex/e;)V

    const/4 v1, 0x7

    move v2, v1

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/f;->a:Lio/reactivex/f;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-interface {p1, v0}, Lio/reactivex/f;->a(Lio/reactivex/d;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p1}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/internal/operators/completable/f$a;->onError(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
