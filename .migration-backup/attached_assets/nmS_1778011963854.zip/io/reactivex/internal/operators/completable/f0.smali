.class public final Lio/reactivex/internal/operators/completable/f0;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;"
        }
    .end annotation
.end field

.field final c:Lt7/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;"
        }
    .end annotation
.end field

.field final d:Lt7/a;

.field final e:Lt7/a;

.field final f:Lt7/a;

.field final g:Lt7/a;


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lt7/g;Lt7/g;Lt7/a;Lt7/a;Lt7/a;Lt7/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/h;",
            "Lt7/g<",
            "-",
            "Lio/reactivex/disposables/c;",
            ">;",
            "Lt7/g<",
            "-",
            "Ljava/lang/Throwable;",
            ">;",
            "Lt7/a;",
            "Lt7/a;",
            "Lt7/a;",
            "Lt7/a;",
            ")V"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/f0;->a:Lio/reactivex/h;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/f0;->b:Lt7/g;

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/f0;->c:Lt7/g;

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    iput-object p4, p0, Lio/reactivex/internal/operators/completable/f0;->d:Lt7/a;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p5, p0, Lio/reactivex/internal/operators/completable/f0;->e:Lt7/a;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p6, p0, Lio/reactivex/internal/operators/completable/f0;->f:Lt7/a;

    const/4 v1, 0x7

    iput-object p7, p0, Lio/reactivex/internal/operators/completable/f0;->g:Lt7/a;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sb@ s   ~~obi~  t@o~@ y@~n~@M@-f l@um@~l~i~ K~@Sf@~o@@ro~ovd.i~ 14~~   /oa@@ ~  b@@~@t~~c~ ~@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/f0;->a:Lio/reactivex/h;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v1, Lio/reactivex/internal/operators/completable/f0$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1, p0, p1}, Lio/reactivex/internal/operators/completable/f0$a;-><init>(Lio/reactivex/internal/operators/completable/f0;Lio/reactivex/e;)V

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method
