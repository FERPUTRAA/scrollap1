.class public final Lio/reactivex/internal/operators/completable/i0;
.super Lio/reactivex/c;


# instance fields
.field final a:Lio/reactivex/h;

.field final b:J

.field final c:Ljava/util/concurrent/TimeUnit;

.field final d:Lio/reactivex/e0;

.field final e:Lio/reactivex/h;


# direct methods
.method public constructor <init>(Lio/reactivex/h;JLjava/util/concurrent/TimeUnit;Lio/reactivex/e0;Lio/reactivex/h;)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/i0;->a:Lio/reactivex/h;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-wide p2, p0, Lio/reactivex/internal/operators/completable/i0;->b:J

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p4, p0, Lio/reactivex/internal/operators/completable/i0;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p5, p0, Lio/reactivex/internal/operators/completable/i0;->d:Lio/reactivex/e0;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p6, p0, Lio/reactivex/internal/operators/completable/i0;->e:Lio/reactivex/h;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~Ms@~n~ c ~@db oo ~~ /@~f sS @o~~~/~@ o@@b~@@ i btum@ylK4.~@@1-a@@r~@~t@i@~i@ olv  ~~@~~@   ~o~f"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/i0;->d:Lio/reactivex/e0;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v3, Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v3, p0, v1, v0, p1}, Lio/reactivex/internal/operators/completable/i0$a;-><init>(Lio/reactivex/internal/operators/completable/i0;Ljava/util/concurrent/atomic/AtomicBoolean;Lio/reactivex/disposables/b;Lio/reactivex/e;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    iget-wide v4, p0, Lio/reactivex/internal/operators/completable/i0;->b:J

    const/4 v8, 0x1

    const/4 v7, 0x0

    iget-object v6, p0, Lio/reactivex/internal/operators/completable/i0;->c:Ljava/util/concurrent/TimeUnit;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v2, v3, v4, v5, v6}, Lio/reactivex/e0;->g(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Lio/reactivex/disposables/c;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v0, v2}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v7, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/i0;->a:Lio/reactivex/h;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    new-instance v3, Lio/reactivex/internal/operators/completable/i0$b;

    const/4 v8, 0x4

    invoke-direct {v3, p0, v0, v1, p1}, Lio/reactivex/internal/operators/completable/i0$b;-><init>(Lio/reactivex/internal/operators/completable/i0;Lio/reactivex/disposables/b;Ljava/util/concurrent/atomic/AtomicBoolean;Lio/reactivex/e;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-interface {v2, v3}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v8, 0x1

    return-void
.end method
