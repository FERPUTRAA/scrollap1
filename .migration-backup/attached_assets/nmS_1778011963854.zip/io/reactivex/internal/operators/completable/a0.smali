.class public final Lio/reactivex/internal/operators/completable/a0;
.super Lio/reactivex/c;


# instance fields
.field final a:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/Iterable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/a0;->a:Ljava/lang/Iterable;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "/ s@ ~~ ~tob~b@K~~t~@~f~@~-~nf~@m@ol~ @~  @@S  4@s @@  @ @u@oy~ivM la~@.@o/~bi~@1d~~~c i  o@@r o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    new-instance v0, Lio/reactivex/disposables/b;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v0}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {p1, v0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/a0;->a:Ljava/lang/Iterable;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v2, " s m l uurratunhcisee stdoetrrTnlree"

    const-string v2, "lesordisnel ur ettciun t  Trurahrsee"

    const/4 v7, 0x4

    const-string v2, "iudeoieh Tn au rorc rlr strotusteenl"

    const-string v2, "The source iterator returned is null"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    check-cast v1, Ljava/util/Iterator;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v2, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v3, Lio/reactivex/internal/util/c;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v3}, Lio/reactivex/internal/util/c;-><init>()V

    :goto_0
    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v4, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void

    :cond_0
    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez v4, :cond_1

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-void

    :cond_2
    :try_start_2
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v5, "odlrhbipl uueoeae  eaurrnlbSte mtr ecamrCeoTnt"

    const-string/jumbo v5, "u nmroieeetdloST rneb teutmlruChltapra ceero a"

    const/4 v7, 0x1

    const-string v5, "Srrloeuoecb Tlr ruttaltuu eleaeh t anCdpirnoee"

    const-string v5, "The iterator returned a null CompletableSource"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v4, v5}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    check-cast v4, Lio/reactivex/h;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v5, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x0

    return-void

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v5, Lio/reactivex/internal/operators/completable/z$a;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {v5, p1, v0, v3, v2}, Lio/reactivex/internal/operators/completable/z$a;-><init>(Lio/reactivex/e;Lio/reactivex/disposables/b;Lio/reactivex/internal/util/c;Ljava/util/concurrent/atomic/AtomicInteger;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v4, v5}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v3, v0}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :catchall_1
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v3, v0}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    :goto_1
    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v0, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v3}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-nez v0, :cond_4

    const/4 v6, 0x0

    move v7, v6

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_2

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    :cond_5
    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void

    :catchall_2
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    return-void
.end method
