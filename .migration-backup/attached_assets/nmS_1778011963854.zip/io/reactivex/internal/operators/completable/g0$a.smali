.class Lio/reactivex/internal/operators/completable/g0$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/g0;->C0(Lio/reactivex/e;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/e;

.field final synthetic b:Lio/reactivex/internal/disposables/k;

.field final synthetic c:Lio/reactivex/internal/operators/completable/g0;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/g0;Lio/reactivex/e;Lio/reactivex/internal/disposables/k;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/g0$a;->c:Lio/reactivex/internal/operators/completable/g0;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/g0$a;->a:Lio/reactivex/e;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p3, p0, Lio/reactivex/internal/operators/completable/g0$a;->b:Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y@s@~ ~n@s @ ~M~~1@~  u@oo~t@@d/ ~  i/~@~ib@bbom@ -  c4~ltvl~@rSo~  @~~@af~o@o~@@~~@ .i@ f ~~K@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g0$a;->b:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Lio/reactivex/internal/disposables/k;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g0$a;->a:Lio/reactivex/e;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 7

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g0$a;->c:Lio/reactivex/internal/operators/completable/g0;

    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/g0;->b:Lt7/o;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0, p1}, Lt7/o;->apply(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v0, Lio/reactivex/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string v1, "etamrelslbdrmtnome blCin  puousehnlleCTeu "

    const-string v1, "pbsdhCseemilltousr ulnalenu meboT rnetelC "

    const/4 v6, 0x4

    const-string v1, "ibreouhlnblo seuteTrpuedalsCn mtlloa Cnem "

    const-string v1, "The CompletableConsumable returned is null"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/g0$a;->a:Lio/reactivex/e;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance p1, Lio/reactivex/internal/operators/completable/g0$a$a;

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-direct {p1, p0}, Lio/reactivex/internal/operators/completable/g0$a$a;-><init>(Lio/reactivex/internal/operators/completable/g0$a;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v6, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/g0$a;->a:Lio/reactivex/e;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v2, Lio/reactivex/exceptions/a;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v3, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-array v3, v3, [Ljava/lang/Throwable;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    aput-object v0, v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    aput-object p1, v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v2, v3}, Lio/reactivex/exceptions/a;-><init>([Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v1, v2}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void
.end method
