.class public final Lio/reactivex/internal/operators/completable/g;
.super Lio/reactivex/c;


# instance fields
.field final a:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/util/concurrent/Callable;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/concurrent/Callable<",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/g;->a:Ljava/util/concurrent/Callable;

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g;->a:Ljava/util/concurrent/Callable;

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "l srdtbarulbnttrplempllnuSeShcou eaeumlieeTc oorap eleCse"

    const-string v1, "oas lebtrllui urd cmeeelaTrepocturSb nllhnCauoeeptSmle pe"

    const/4 v3, 0x1

    const-string v1, " nomrll ahtclee proSe ubrreaeplCcoenSembTutmeleutpl upild"

    const-string v1, "The completableSupplier returned a null CompletableSource"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Lio/reactivex/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/e;->f(Ljava/lang/Throwable;Lio/reactivex/e;)V

    return-void
.end method
