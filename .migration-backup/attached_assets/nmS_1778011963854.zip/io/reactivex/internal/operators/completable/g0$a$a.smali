.class Lio/reactivex/internal/operators/completable/g0$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/g0$a;->onError(Ljava/lang/Throwable;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/internal/operators/completable/g0$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/g0$a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/g0$a$a;->a:Lio/reactivex/internal/operators/completable/g0$a;

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@is4~@ ~o~i@f@@1~@d@ o~ba~ ~@@~l~bt y@S@ ~-r~ ti~@f/n~~@@m~/  cbo so@ @u.~  ~ol  @~  v~oK~~~@@@M"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g0$a$a;->a:Lio/reactivex/internal/operators/completable/g0$a;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/g0$a;->b:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lio/reactivex/internal/disposables/k;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g0$a$a;->a:Lio/reactivex/internal/operators/completable/g0$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/g0$a;->a:Lio/reactivex/e;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/g0$a$a;->a:Lio/reactivex/internal/operators/completable/g0$a;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/g0$a;->a:Lio/reactivex/e;

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method
