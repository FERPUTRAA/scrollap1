.class final Lio/reactivex/internal/operators/completable/x$a$a;
.super Ljava/util/concurrent/atomic/AtomicReference;

# interfaces
.implements Lio/reactivex/e;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/x$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicReference<",
        "Lio/reactivex/disposables/c;",
        ">;",
        "Lio/reactivex/e;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x37ce7cbca0ace5dL


# instance fields
.field final synthetic this$0:Lio/reactivex/internal/operators/completable/x$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/x$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/x$a$a;->this$0:Lio/reactivex/internal/operators/completable/x$a;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s ~i~~f@~y~@b@M~@@o~@@4r@a/~ o  lb@ i u~  @@bv@mo~f  -.to@1@o @~~~c @tlo/@~ ~@~~ni~ Ks Sd  @~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->c(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lio/reactivex/internal/disposables/d;->h(Ljava/util/concurrent/atomic/AtomicReference;Lio/reactivex/disposables/c;)Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a$a;->this$0:Lio/reactivex/internal/operators/completable/x$a;

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Lio/reactivex/internal/operators/completable/x$a;->b(Lio/reactivex/internal/operators/completable/x$a$a;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a$a;->this$0:Lio/reactivex/internal/operators/completable/x$a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p0, p1}, Lio/reactivex/internal/operators/completable/x$a;->c(Lio/reactivex/internal/operators/completable/x$a$a;Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method
