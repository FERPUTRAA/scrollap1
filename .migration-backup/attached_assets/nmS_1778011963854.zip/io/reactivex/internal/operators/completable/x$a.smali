.class final Lio/reactivex/internal/operators/completable/x$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/x$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "Lio/reactivex/h;",
        ">;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x1d42b216fe3a6372L


# instance fields
.field final actual:Lio/reactivex/e;

.field final delayErrors:Z

.field final error:Lio/reactivex/internal/util/c;

.field final maxConcurrency:I

.field s:Lja/d;

.field final set:Lio/reactivex/disposables/b;


# direct methods
.method constructor <init>(Lio/reactivex/e;IZ)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p2, p0, Lio/reactivex/internal/operators/completable/x$a;->maxConcurrency:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p3, p0, Lio/reactivex/internal/operators/completable/x$a;->delayErrors:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p1, Lio/reactivex/disposables/b;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p1}, Lio/reactivex/disposables/b;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    new-instance p1, Lio/reactivex/internal/util/c;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p1}, Lio/reactivex/internal/util/c;-><init>()V

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->lazySet(I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4ds@-@/b~o~~1bli @f@@@r@ t@~~i  @~@~n@ ~i~y~o. mv c  l ~ t@@@@@~@Kfo s~~@~~@ /o~~~~oo   ~@~baMS "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->a()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method b(Lio/reactivex/internal/operators/completable/x$a$a;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->d(Lio/reactivex/disposables/c;)Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast p1, Ljava/lang/Throwable;

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-interface {p1}, Lio/reactivex/e;->onComplete()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget p1, p0, Lio/reactivex/internal/operators/completable/x$a;->maxConcurrency:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    const v0, 0x7fffffff

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eq p1, v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->s:Lja/d;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-wide/16 v0, 0x1

    const/4 v3, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method c(Lio/reactivex/internal/operators/completable/x$a$a;Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->d(Lio/reactivex/disposables/c;)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget-boolean p1, p0, Lio/reactivex/internal/operators/completable/x$a;->delayErrors:Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->s:Lja/d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p1}, Lja/d;->cancel()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1}, Lio/reactivex/disposables/b;->e()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndSet(I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-lez p1, :cond_4

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x6

    const/4 v2, 0x6

    iget-object p2, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p2}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {p1, p2}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p2}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz p1, :cond_3

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object p2, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x3

    invoke-virtual {p2}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {p1, p2}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    iget p1, p0, Lio/reactivex/internal/operators/completable/x$a;->maxConcurrency:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    const p2, 0x7fffffff

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-eq p1, p2, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->s:Lja/d;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x0

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p2}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_4
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public d(Lio/reactivex/h;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Lio/reactivex/internal/operators/completable/x$a$a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lio/reactivex/internal/operators/completable/x$a$a;-><init>(Lio/reactivex/internal/operators/completable/x$a;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p1, v0}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v3, 0x7

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->s:Lja/d;

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v2, 0x5

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public bridge synthetic f(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    check-cast p1, Lio/reactivex/h;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/completable/x$a;->d(Lio/reactivex/h;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/Throwable;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v1}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/x$a;->delayErrors:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->set:Lio/reactivex/disposables/b;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndSet(I)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-lez p1, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lio/reactivex/internal/util/c;->a(Ljava/lang/Throwable;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez p1, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->error:Lio/reactivex/internal/util/c;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Lio/reactivex/internal/util/c;->c()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    const/4 v2, 0x2

    return-void
.end method

.method public q(Lja/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->s:Lja/d;

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/x$a;->s:Lja/d;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/x$a;->actual:Lio/reactivex/e;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v0, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, p0, Lio/reactivex/internal/operators/completable/x$a;->maxConcurrency:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const v1, 0x7fffffff

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x0

    const-wide v0, 0x7fffffffffffffffL

    const-wide v0, 0x7fffffffffffffffL

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    int-to-long v0, v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1, v0, v1}, Lja/d;->g(J)V

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method
