.class public final Lio/reactivex/internal/operators/completable/x;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/x$a;
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field

.field final b:I

.field final c:Z


# direct methods
.method public constructor <init>(Lja/b;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "+",
            "Lio/reactivex/h;",
            ">;IZ)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/x;->a:Lja/b;

    const/4 v1, 0x4

    iput p2, p0, Lio/reactivex/internal/operators/completable/x;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-boolean p3, p0, Lio/reactivex/internal/operators/completable/x;->c:Z

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public C0(Lio/reactivex/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~fs@id4~~t~  b ~ ac@@~o@nvi ~@ @.uS@@l ~~@-@~m~ ~@@ o~ s @/@~K@ ~~i@y~ ~@b o~@o@ro/l Mo~1f ~ @bt"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Lio/reactivex/internal/operators/completable/x$a;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v1, p0, Lio/reactivex/internal/operators/completable/x;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-boolean v2, p0, Lio/reactivex/internal/operators/completable/x;->c:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0, p1, v1, v2}, Lio/reactivex/internal/operators/completable/x$a;-><init>(Lio/reactivex/e;IZ)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/x;->a:Lja/b;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Lja/b;->j(Lja/c;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method
