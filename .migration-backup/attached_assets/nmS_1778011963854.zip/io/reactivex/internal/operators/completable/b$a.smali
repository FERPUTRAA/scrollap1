.class final Lio/reactivex/internal/operators/completable/b$a;
.super Ljava/util/concurrent/atomic/AtomicBoolean;

# interfaces
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x7c1c7632007db36cL


# instance fields
.field final actual:Lio/reactivex/e;

.field final synthetic this$0:Lio/reactivex/internal/operators/completable/b;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/b;Lio/reactivex/e;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/b$a;->this$0:Lio/reactivex/internal/operators/completable/b;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/b$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public e()V
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/b$a;->this$0:Lio/reactivex/internal/operators/completable/b;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Lio/reactivex/internal/operators/completable/b;->b1(Lio/reactivex/internal/operators/completable/b$a;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method
