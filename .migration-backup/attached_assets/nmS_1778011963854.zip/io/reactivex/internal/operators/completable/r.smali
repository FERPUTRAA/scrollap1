.class public final Lio/reactivex/internal/operators/completable/r;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/r$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Lio/reactivex/c;"
    }
.end annotation


# instance fields
.field final a:Lja/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lja/b<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lja/b;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lja/b<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/r;->a:Lja/b;

    const/4 v0, 0x5

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " bs@~@@ v~~~@fi i o bo@~ b~~~ odr .-f@M4~~o~1~s@/ y@  @~@@~@@li@@l oS~o~@ u~  t~~~ ncaK@~m@ ~/t@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/r;->a:Lja/b;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v1, Lio/reactivex/internal/operators/completable/r$a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-direct {v1, p1}, Lio/reactivex/internal/operators/completable/r$a;-><init>(Lio/reactivex/e;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Lja/b;->j(Lja/c;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
