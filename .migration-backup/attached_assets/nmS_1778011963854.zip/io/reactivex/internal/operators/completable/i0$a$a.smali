.class Lio/reactivex/internal/operators/completable/i0$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lio/reactivex/internal/operators/completable/i0$a;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lio/reactivex/internal/operators/completable/i0$a;


# direct methods
.method constructor <init>(Lio/reactivex/internal/operators/completable/i0$a;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/i0$a$a;->a:Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f~sna  oMl fyu4~tv~c@~@@@s@o/1~@ ~@ ~@d@~o~i~~S@   m ~~ib@b@@o@r~ io l@ t~@@~/ ~ .~K~@~~@ ob-~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a$a;->a:Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/i0$a;->b:Lio/reactivex/disposables/b;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lio/reactivex/disposables/b;->c(Lio/reactivex/disposables/c;)Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a$a;->a:Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/i0$a;->b:Lio/reactivex/disposables/b;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a$a;->a:Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/i0$a;->c:Lio/reactivex/e;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a$a;->a:Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/i0$a;->b:Lio/reactivex/disposables/b;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Lio/reactivex/disposables/b;->e()V

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i0$a$a;->a:Lio/reactivex/internal/operators/completable/i0$a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, v0, Lio/reactivex/internal/operators/completable/i0$a;->c:Lio/reactivex/e;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method
