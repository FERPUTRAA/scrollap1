.class final Lio/reactivex/internal/operators/completable/e$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lio/reactivex/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x6e8ac9652ad7cd50L


# instance fields
.field final actual:Lio/reactivex/e;

.field final sd:Lio/reactivex/internal/disposables/k;

.field final sources:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "+",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lio/reactivex/e;Ljava/util/Iterator;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lio/reactivex/e;",
            "Ljava/util/Iterator<",
            "+",
            "Lio/reactivex/h;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/e$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x3

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/e$a;->sources:Ljava/util/Iterator;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    new-instance p1, Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p1}, Lio/reactivex/internal/disposables/k;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/e$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Lio/reactivex/internal/disposables/k;->a()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e$a;->sources:Ljava/util/Iterator;

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/e$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Lio/reactivex/internal/disposables/k;->a()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    return-void

    :cond_3
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_4
    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, "ensupcs eslrurti lhbolTte amdSeeCelr u"

    const-string/jumbo v2, "tlsudC otrumil eeTeellrSr ehspuaeb ocn"

    const/4 v4, 0x4

    const-string v2, "lrametuo urthne ecnu eemselbTr oliSdpl"

    const-string v2, "The CompletableSource returned is null"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1, v2}, Lio/reactivex/internal/functions/b;->f(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    check-cast v1, Lio/reactivex/h;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v1, p0}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/e$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :catchall_1
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/e$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {v1, v0}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e$a;->sd:Lio/reactivex/internal/disposables/k;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lio/reactivex/internal/disposables/k;->c(Lio/reactivex/disposables/c;)Z

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public onComplete()V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/e$a;->a()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/e$a;->actual:Lio/reactivex/e;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
