.class final Lio/reactivex/internal/operators/completable/i$a;
.super Ljava/lang/Object;

# interfaces
.implements Lio/reactivex/e;
.implements Lio/reactivex/disposables/c;
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field final a:Lio/reactivex/e;

.field final b:Lio/reactivex/e0;

.field c:Lio/reactivex/disposables/c;

.field volatile d:Z


# direct methods
.method constructor <init>(Lio/reactivex/e;Lio/reactivex/e0;)V
    .locals 2

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/i$a;->a:Lio/reactivex/e;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/i$a;->b:Lio/reactivex/e0;

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " os  ~ fym ~~-  ~~ bn/@~~.o@a@~~iv@~@dS l4rt @~@i~@~@i@ b ~@@o@  ~1@ ~~K~tc@ @u~Ms@~lo @o@fb/~~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/i$a;->d:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public d(Lio/reactivex/disposables/c;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i$a;->c:Lio/reactivex/disposables/c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lio/reactivex/internal/disposables/d;->j(Lio/reactivex/disposables/c;Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/i$a;->c:Lio/reactivex/disposables/c;

    const/4 v2, 0x6

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/i$a;->a:Lio/reactivex/e;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {p1, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    iput-boolean v0, p0, Lio/reactivex/internal/operators/completable/i$a;->d:Z

    const/4 v2, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i$a;->b:Lio/reactivex/e0;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lio/reactivex/e0;->f(Ljava/lang/Runnable;)Lio/reactivex/disposables/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/i$a;->d:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i$a;->a:Lio/reactivex/e;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/i$a;->d:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i$a;->a:Lio/reactivex/e;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public run()V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/i$a;->c:Lio/reactivex/disposables/c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lio/reactivex/disposables/c;->e()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lio/reactivex/internal/disposables/d;->a:Lio/reactivex/internal/disposables/d;

    const/4 v2, 0x3

    const/4 v1, 0x6

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/i$a;->c:Lio/reactivex/disposables/c;

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-void
.end method
