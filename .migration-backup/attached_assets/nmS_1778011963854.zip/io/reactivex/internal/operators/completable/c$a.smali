.class final Lio/reactivex/internal/operators/completable/c$a;
.super Ljava/util/concurrent/atomic/AtomicInteger;

# interfaces
.implements Lja/c;
.implements Lio/reactivex/disposables/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lio/reactivex/internal/operators/completable/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/c$a$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/util/concurrent/atomic/AtomicInteger;",
        "Lja/c<",
        "Lio/reactivex/h;",
        ">;",
        "Lio/reactivex/disposables/c;"
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x7d58c452a57faa4cL


# instance fields
.field volatile active:Z

.field final actual:Lio/reactivex/e;

.field consumed:I

.field volatile done:Z

.field final inner:Lio/reactivex/internal/operators/completable/c$a$a;

.field final limit:I

.field final once:Ljava/util/concurrent/atomic/AtomicBoolean;

.field final prefetch:I

.field queue:Lu7/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lu7/o<",
            "Lio/reactivex/h;",
            ">;"
        }
    .end annotation
.end field

.field s:Lja/d;

.field sourceFused:I


# direct methods
.method constructor <init>(Lio/reactivex/e;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p2, p0, Lio/reactivex/internal/operators/completable/c$a;->prefetch:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    new-instance p1, Lio/reactivex/internal/operators/completable/c$a$a;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p1, p0}, Lio/reactivex/internal/operators/completable/c$a$a;-><init>(Lio/reactivex/internal/operators/completable/c$a;)V

    const/4 v0, 0x7

    xor-int/2addr v1, v0

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/c$a;->inner:Lio/reactivex/internal/operators/completable/c$a$a;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/c$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    const/4 v0, 0x0

    shr-int/lit8 p1, p2, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    sub-int/2addr p2, p1

    const/4 v1, 0x6

    iput p2, p0, Lio/reactivex/internal/operators/completable/c$a;->limit:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@~~@~ s ~~@ lb@@~m~t    o@@~-@/ @ @t~ y @ ~oflou@oS.~o   v~ni~1~f4cr@ @~ o@Mi~~/ad@bK~@@~b@@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->inner:Lio/reactivex/internal/operators/completable/c$a$a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast v0, Lio/reactivex/disposables/c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->c(Lio/reactivex/disposables/c;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method b()V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    return-void

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/c$a;->a()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/c$a;->active:Z

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v0, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-boolean v0, p0, Lio/reactivex/internal/operators/completable/c$a;->done:Z

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/c$a;->queue:Lu7/o;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v1}, Lu7/o;->poll()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v1, Lio/reactivex/h;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    move v4, v3

    move v4, v3

    const/4 v6, 0x0

    move v4, v3

    move v4, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    move v4, v2

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v4, :cond_4

    const/4 v6, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v0}, Lio/reactivex/e;->onComplete()V

    :cond_3
    const/4 v6, 0x4

    return-void

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput-boolean v3, p0, Lio/reactivex/internal/operators/completable/c$a;->active:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->inner:Lio/reactivex/internal/operators/completable/c$a$a;

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-interface {v1, v0}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/c$a;->h()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0}, Lio/reactivex/exceptions/b;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0, v0}, Lio/reactivex/internal/operators/completable/c$a;->d(Ljava/lang/Throwable;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void

    :cond_5
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-void
.end method

.method c()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-boolean v0, p0, Lio/reactivex/internal/operators/completable/c$a;->active:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/c$a;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method d(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->s:Lja/d;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->s:Lja/d;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0}, Lja/d;->cancel()V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->inner:Lio/reactivex/internal/operators/completable/c$a$a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public bridge synthetic f(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    check-cast p1, Lio/reactivex/h;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/completable/c$a;->g(Lio/reactivex/h;)V

    const/4 v1, 0x2

    return-void
.end method

.method public g(Lio/reactivex/h;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lio/reactivex/internal/operators/completable/c$a;->sourceFused:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->queue:Lu7/o;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lu7/o;->offer(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    if-nez p1, :cond_0

    new-instance p1, Lio/reactivex/exceptions/c;

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p1}, Lio/reactivex/exceptions/c;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lio/reactivex/internal/operators/completable/c$a;->onError(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/c$a;->b()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method h()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget v0, p0, Lio/reactivex/internal/operators/completable/c$a;->sourceFused:I

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x0

    move v5, v4

    if-eq v0, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v0, p0, Lio/reactivex/internal/operators/completable/c$a;->consumed:I

    const/4 v4, 0x2

    move v5, v4

    add-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v1, p0, Lio/reactivex/internal/operators/completable/c$a;->limit:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v1, p0, Lio/reactivex/internal/operators/completable/c$a;->consumed:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lio/reactivex/internal/operators/completable/c$a;->s:Lja/d;

    const/4 v4, 0x3

    or-int/2addr v5, v4

    int-to-long v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v1, v2, v3}, Lja/d;->g(J)V

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    iput v0, p0, Lio/reactivex/internal/operators/completable/c$a;->consumed:I

    :cond_1
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method

.method public onComplete()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-boolean v0, p0, Lio/reactivex/internal/operators/completable/c$a;->done:Z

    const/4 v1, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/c$a;->b()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->once:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->inner:Lio/reactivex/internal/operators/completable/c$a$a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lio/reactivex/internal/disposables/d;->b(Ljava/util/concurrent/atomic/AtomicReference;)Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v4, 0x1

    invoke-interface {v0, p1}, Lio/reactivex/e;->onError(Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1}, Lio/reactivex/plugins/a;->V(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public q(Lja/d;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->s:Lja/d;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v0, p1}, Lio/reactivex/internal/subscriptions/p;->m(Lja/d;Lja/d;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/c$a;->s:Lja/d;

    const/4 v7, 0x7

    iget v0, p0, Lio/reactivex/internal/operators/completable/c$a;->prefetch:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    const v1, 0x7fffffff

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-ne v0, v1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const-wide v2, 0x7fffffffffffffffL

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    int-to-long v2, v0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    instance-of v0, p1, Lu7/l;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_2

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    check-cast v0, Lu7/l;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v4, 0x3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v0, v4}, Lu7/k;->l(I)I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v5, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ne v4, v5, :cond_1

    const/4 v7, 0x7

    iput v4, p0, Lio/reactivex/internal/operators/completable/c$a;->sourceFused:I

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->queue:Lu7/o;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-boolean v5, p0, Lio/reactivex/internal/operators/completable/c$a;->done:Z

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object p1, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {p1, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0}, Lio/reactivex/internal/operators/completable/c$a;->b()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-void

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v5, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ne v4, v5, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput v4, p0, Lio/reactivex/internal/operators/completable/c$a;->sourceFused:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->queue:Lu7/o;

    const/4 v6, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {v0, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-interface {p1, v2, v3}, Lja/d;->g(J)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget v0, p0, Lio/reactivex/internal/operators/completable/c$a;->prefetch:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-ne v0, v1, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x3

    new-instance v0, Lio/reactivex/internal/queue/c;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {}, Lio/reactivex/k;->V()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct {v0, v1}, Lio/reactivex/internal/queue/c;-><init>(I)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->queue:Lu7/o;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v0, Lio/reactivex/internal/queue/b;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget v1, p0, Lio/reactivex/internal/operators/completable/c$a;->prefetch:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {v0, v1}, Lio/reactivex/internal/queue/b;-><init>(I)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    iput-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->queue:Lu7/o;

    :goto_1
    const/4 v7, 0x6

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/c$a;->actual:Lio/reactivex/e;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-interface {v0, p0}, Lio/reactivex/e;->d(Lio/reactivex/disposables/c;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {p1, v2, v3}, Lja/d;->g(J)V

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-void
.end method
