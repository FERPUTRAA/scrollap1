.class public final Lio/reactivex/internal/operators/completable/j;
.super Lio/reactivex/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lio/reactivex/internal/operators/completable/j$a;
    }
.end annotation

.annotation build Ls7/e;
.end annotation


# instance fields
.field final a:Lio/reactivex/h;

.field final b:Lt7/a;


# direct methods
.method public constructor <init>(Lio/reactivex/h;Lt7/a;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lio/reactivex/c;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lio/reactivex/internal/operators/completable/j;->a:Lio/reactivex/h;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p2, p0, Lio/reactivex/internal/operators/completable/j;->b:Lt7/a;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected C0(Lio/reactivex/e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s~bo S~utM @~ lf or~@b  ~~~~@K~~.@~ysvc@@~@~~ @i@ ~@~@na i @o/o @o~@t ~@~ 4 ~ ~ldi/@@bm@-o  1f"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lio/reactivex/internal/operators/completable/j;->a:Lio/reactivex/h;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Lio/reactivex/internal/operators/completable/j$a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Lio/reactivex/internal/operators/completable/j;->b:Lt7/a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v1, p1, v2}, Lio/reactivex/internal/operators/completable/j$a;-><init>(Lio/reactivex/e;Lt7/a;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Lio/reactivex/h;->a(Lio/reactivex/e;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method
