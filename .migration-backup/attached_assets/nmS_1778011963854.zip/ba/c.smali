.class public interface abstract annotation Lba/c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime Lga/b0;
    value = {
        .enum Lga/s;->a:Lga/s;
    }
.end annotation

.annotation runtime Lga/e;
    value = {
        .enum Lga/i0;->i:Lga/i0;
    }
.end annotation

.annotation runtime Lga/f0;
    value = {}
.end annotation

.annotation runtime Lga/h;
.end annotation

.annotation runtime Lga/q;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->RUNTIME:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {
        .enum Ljava/lang/annotation/ElementType;->TYPE_USE:Ljava/lang/annotation/ElementType;,
        .enum Ljava/lang/annotation/ElementType;->TYPE_PARAMETER:Ljava/lang/annotation/ElementType;
    }
.end annotation
