.class public La9/a;
.super Ljava/lang/Object;


# instance fields
.field public a:I

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public h:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "o~s@@ @~  b ~~ @ @bK M @@@olu~4~a~oo/f~/  i~@1~ m-~i ni~ @~~@ @dt@lt@f @ @~@.orco@~y ~s@~~v~~@b~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget v0, p0, La9/a;->h:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, p0, La9/a;->f:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public b()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v0, p0, La9/a;->g:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, La9/a;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0
.end method

.method public c()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v0, p0, La9/a;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, p0, La9/a;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0
.end method

.method public d()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, La9/a;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, La9/a;->f()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    div-int/lit8 v1, v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v0
.end method

.method public e()I
    .locals 4

    const/4 v3, 0x2

    iget v0, p0, La9/a;->b:I

    const/4 v3, 0x1

    invoke-virtual {p0}, La9/a;->c()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    div-int/lit8 v1, v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public f()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v0, p0, La9/a;->c:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, p0, La9/a;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0
.end method
