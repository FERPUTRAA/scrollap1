.class public final enum Lh9/c;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lh9/c;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum a:Lh9/c;

.field public static final enum b:Lh9/c;

.field public static final enum c:Lh9/c;

.field public static final enum d:Lh9/c;

.field public static final enum e:Lh9/c;

.field public static final enum f:Lh9/c;

.field public static final enum g:Lh9/c;

.field public static final enum h:Lh9/c;

.field public static final enum i:Lh9/c;

.field private static final j:[Lh9/c;

.field private static final k:[Lh9/c;

.field private static final l:[Lh9/c;

.field private static final synthetic m:[Lh9/c;


# instance fields
.field public final chars:Ljava/lang/String;

.field public final types:[Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "[",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lh9/c;

    const-string v1, "RGsEALN"

    const-string v1, "GENERAL"

    const/4 v2, 0x0

    const-string v3, "hBSmbs"

    const-string v3, "hbsBSs"

    const-string v3, "bBhHsS"

    const/4 v4, 0x0

    invoke-direct {v0, v1, v2, v3, v4}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v0, Lh9/c;->a:Lh9/c;

    new-instance v1, Lh9/c;

    const/4 v3, 0x4

    new-array v5, v3, [Ljava/lang/Class;

    const-class v6, Ljava/lang/Character;

    const-class v6, Ljava/lang/Character;

    const-class v6, Ljava/lang/Character;

    const-class v6, Ljava/lang/Character;

    aput-object v6, v5, v2

    const/4 v6, 0x1

    const-class v7, Ljava/lang/Byte;

    const-class v7, Ljava/lang/Byte;

    const-class v7, Ljava/lang/Byte;

    const-class v7, Ljava/lang/Byte;

    aput-object v7, v5, v6

    const/4 v8, 0x2

    const-class v9, Ljava/lang/Short;

    const-class v9, Ljava/lang/Short;

    const-class v9, Ljava/lang/Short;

    aput-object v9, v5, v8

    const/4 v10, 0x3

    const-class v11, Ljava/lang/Integer;

    const-class v11, Ljava/lang/Integer;

    const-class v11, Ljava/lang/Integer;

    const-class v11, Ljava/lang/Integer;

    aput-object v11, v5, v10

    const-string v12, "HRAC"

    const-string v12, "AHCR"

    const-string v12, "RHCA"

    const-string v12, "CHAR"

    const-string v13, "Cc"

    const-string v13, "cC"

    const-string v13, "cC"

    invoke-direct {v1, v12, v6, v13, v5}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v1, Lh9/c;->b:Lh9/c;

    new-instance v5, Lh9/c;

    const/4 v12, 0x5

    new-array v13, v12, [Ljava/lang/Class;

    aput-object v7, v13, v2

    aput-object v9, v13, v6

    aput-object v11, v13, v8

    const-class v14, Ljava/lang/Long;

    const-class v14, Ljava/lang/Long;

    const-class v14, Ljava/lang/Long;

    const-class v14, Ljava/lang/Long;

    aput-object v14, v13, v10

    const-class v15, Ljava/math/BigInteger;

    const-class v15, Ljava/math/BigInteger;

    const-class v15, Ljava/math/BigInteger;

    const-class v15, Ljava/math/BigInteger;

    aput-object v15, v13, v3

    const-string v15, "TNI"

    const-string v15, "INT"

    const-string v15, "NIT"

    const-string v15, "INT"

    const-string v4, "Xdox"

    const-string/jumbo v4, "xXod"

    const-string v4, "doxX"

    invoke-direct {v5, v15, v8, v4, v13}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v5, Lh9/c;->c:Lh9/c;

    new-instance v4, Lh9/c;

    new-array v13, v10, [Ljava/lang/Class;

    const-class v15, Ljava/lang/Float;

    const-class v15, Ljava/lang/Float;

    const-class v15, Ljava/lang/Float;

    const-class v15, Ljava/lang/Float;

    aput-object v15, v13, v2

    const-class v15, Ljava/lang/Double;

    const-class v15, Ljava/lang/Double;

    const-class v15, Ljava/lang/Double;

    const-class v15, Ljava/lang/Double;

    aput-object v15, v13, v6

    const-class v15, Ljava/math/BigDecimal;

    const-class v15, Ljava/math/BigDecimal;

    const-class v15, Ljava/math/BigDecimal;

    aput-object v15, v13, v8

    const-string v15, "LOTmo"

    const-string v15, "TFOmL"

    const-string v15, "bALFT"

    const-string v15, "FLOAT"

    const-string v12, "AoaGfgu"

    const-string v12, "gAfGoea"

    const-string v12, "eEfgGaA"

    invoke-direct {v4, v15, v10, v12, v13}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v4, Lh9/c;->d:Lh9/c;

    new-instance v12, Lh9/c;

    new-array v13, v10, [Ljava/lang/Class;

    aput-object v14, v13, v2

    const-class v15, Ljava/util/Calendar;

    const-class v15, Ljava/util/Calendar;

    const-class v15, Ljava/util/Calendar;

    const-class v15, Ljava/util/Calendar;

    aput-object v15, v13, v6

    const-class v15, Ljava/util/Date;

    const-class v15, Ljava/util/Date;

    const-class v15, Ljava/util/Date;

    const-class v15, Ljava/util/Date;

    aput-object v15, v13, v8

    const-string v15, "TEIM"

    const-string v15, "IMET"

    const-string v15, "TEMI"

    const-string v15, "TIME"

    const-string v8, "tT"

    const-string v8, "tT"

    const-string v8, "tT"

    const-string v8, "tT"

    invoke-direct {v12, v15, v3, v8, v13}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v12, Lh9/c;->e:Lh9/c;

    new-instance v8, Lh9/c;

    new-array v13, v10, [Ljava/lang/Class;

    aput-object v7, v13, v2

    aput-object v9, v13, v6

    const/4 v7, 0x2

    aput-object v11, v13, v7

    const-string v7, "NAH_bRIpTA_N"

    const-string v7, "A_DRHbINTA_N"

    const-string v7, "T_NDA_NRqCAI"

    const-string v7, "CHAR_AND_INT"

    const/4 v9, 0x0

    const/4 v11, 0x5

    invoke-direct {v8, v7, v11, v9, v13}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v8, Lh9/c;->f:Lh9/c;

    new-instance v7, Lh9/c;

    new-array v11, v6, [Ljava/lang/Class;

    aput-object v14, v11, v2

    const-string v13, "N_sNuMTDE_IT"

    const-string v13, "NDM_NTu_IEAT"

    const-string v13, "TDNmTIINEM_A"

    const-string v13, "INT_AND_TIME"

    const/4 v14, 0x6

    invoke-direct {v7, v13, v14, v9, v11}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v7, Lh9/c;->g:Lh9/c;

    new-instance v11, Lh9/c;

    new-array v13, v2, [Ljava/lang/Class;

    const-string v15, "LUNL"

    const-string v15, "NLLU"

    const-string v15, "NULL"

    const/4 v14, 0x7

    invoke-direct {v11, v15, v14, v9, v13}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v11, Lh9/c;->h:Lh9/c;

    new-instance v13, Lh9/c;

    const-string v15, "EDUSop"

    const-string v15, "SpDUUE"

    const-string v15, "UNUSED"

    const/16 v14, 0x8

    invoke-direct {v13, v15, v14, v9, v9}, Lh9/c;-><init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V

    sput-object v13, Lh9/c;->i:Lh9/c;

    invoke-static {}, Lh9/c;->a()[Lh9/c;

    move-result-object v9

    sput-object v9, Lh9/c;->m:[Lh9/c;

    const/4 v9, 0x5

    new-array v13, v9, [Lh9/c;

    aput-object v0, v13, v2

    aput-object v1, v13, v6

    const/4 v0, 0x2

    aput-object v5, v13, v0

    aput-object v4, v13, v10

    aput-object v12, v13, v3

    sput-object v13, Lh9/c;->j:[Lh9/c;

    const/4 v9, 0x7

    new-array v13, v9, [Lh9/c;

    aput-object v1, v13, v2

    aput-object v5, v13, v6

    aput-object v4, v13, v0

    aput-object v12, v13, v10

    aput-object v8, v13, v3

    const/4 v14, 0x5

    aput-object v7, v13, v14

    const/4 v15, 0x6

    aput-object v11, v13, v15

    sput-object v13, Lh9/c;->k:[Lh9/c;

    new-array v9, v9, [Lh9/c;

    aput-object v11, v9, v2

    aput-object v8, v9, v6

    aput-object v7, v9, v0

    aput-object v1, v9, v10

    aput-object v5, v9, v3

    aput-object v4, v9, v14

    aput-object v12, v9, v15

    sput-object v9, Lh9/c;->l:[Lh9/c;

    return-void
.end method

.method private varargs constructor <init>(Ljava/lang/String;ILjava/lang/String;[Ljava/lang/Class;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/Class<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object p3, p0, Lh9/c;->chars:Ljava/lang/String;

    const/4 v2, 0x3

    if-nez p4, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p4, p0, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_1

    :cond_0
    const/4 v2, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    array-length p2, p4

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p1, p2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    array-length p2, p4

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p3, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v2, 0x1

    if-ge p3, p2, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    aget-object v0, p4, p3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Lh9/c;->h(Ljava/lang/Class;)Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    add-int/lit8 p3, p3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-array p2, p2, [Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {p1, p2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p1, [Ljava/lang/Class;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lh9/c;->types:[Ljava/lang/Class;

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method private static synthetic a()[Lh9/c;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@ 4rb~~oo@v~@ fK~l@@t~/by@@t a-.i  @o@~~@@1~@~~@ m~~~sc~ o~i  @i@~  d@@@ bSMn~ ~~ ~luf@ @/ o~ o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const/16 v0, 0x9

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-array v0, v0, [Lh9/c;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x0

    sget-object v2, Lh9/c;->a:Lh9/c;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    sget-object v2, Lh9/c;->b:Lh9/c;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget-object v2, Lh9/c;->c:Lh9/c;

    const/4 v3, 0x6

    move v4, v3

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v2, Lh9/c;->d:Lh9/c;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v2, Lh9/c;->e:Lh9/c;

    const/4 v4, 0x2

    const/4 v3, 0x2

    aput-object v2, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    sget-object v2, Lh9/c;->f:Lh9/c;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x6

    const/4 v3, 0x1

    move v4, v3

    sget-object v2, Lh9/c;->g:Lh9/c;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x7

    const/4 v4, 0x0

    const/4 v3, 0x5

    sget-object v2, Lh9/c;->h:Lh9/c;

    const/4 v4, 0x6

    aput-object v2, v0, v1

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    const/16 v1, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v2, Lh9/c;->i:Lh9/c;

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object v0
.end method

.method private static b([Ljava/lang/Object;)Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Object;",
            ">([TE;)",
            "Ljava/util/Set<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public static c(C)Lh9/c;
    .locals 8

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v0, Lh9/c;->j:[Lh9/c;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    array-length v1, v0

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x4

    move v6, v2

    move v6, v2

    :goto_0
    const/4 v7, 0x7

    if-ge v2, v1, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    aget-object v3, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v4, v3, Lh9/c;->chars:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p0}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v4, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-object v3

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const-string v2, "nh ianuoaoe dBsrect ccraq"

    const-string v2, "hcaoca eqnc raonteB dsrir"

    const/4 v7, 0x5

    const-string v2, "ce ravepnhcsorait dcnBora"

    const-string v2, "Bad conversion character "

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw v0
.end method

.method public static d(Lh9/c;Lh9/c;)Lh9/c;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget-object v0, Lh9/c;->i:Lh9/c;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ne p0, v0, :cond_0

    const/4 v5, 0x1

    return-object p1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-ne p1, v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget-object v0, Lh9/c;->a:Lh9/c;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne p0, v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x0

    return-object p1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ne p1, v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x0

    return-object p0

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object p0, p0, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v5, 0x1

    invoke-static {p0}, Lh9/c;->b([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object p1, p1, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Lh9/c;->b([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p0, p1}, Ljava/util/Set;->retainAll(Ljava/util/Collection;)Z

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget-object p1, Lh9/c;->k:[Lh9/c;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    array-length v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ge v1, v0, :cond_5

    const/4 v5, 0x2

    aget-object v2, p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v3, v2, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v3}, Lh9/c;->b([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v3, p0}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v3, :cond_4

    const/4 v4, 0x1

    move v5, v4

    return-object v2

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    throw p0
.end method

.method public static f(Lh9/c;Lh9/c;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh9/c;->d(Lh9/c;Lh9/c;)Lh9/c;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-ne p1, p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 p0, 0x1

    move v1, p0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 p0, 0x6

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method public static g(Lh9/c;Lh9/c;)Lh9/c;
    .locals 6

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v0, Lh9/c;->i:Lh9/c;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq p0, v0, :cond_7

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ne p1, v0, :cond_0

    const/4 v4, 0x2

    move v5, v4

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object v0, Lh9/c;->a:Lh9/c;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eq p0, v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-ne p1, v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto/16 :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v0, Lh9/c;->f:Lh9/c;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne p0, v0, :cond_2

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    sget-object v1, Lh9/c;->g:Lh9/c;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq p1, v1, :cond_3

    :cond_2
    sget-object v1, Lh9/c;->g:Lh9/c;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne p0, v1, :cond_4

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ne p1, v0, :cond_4

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-object p0, Lh9/c;->c:Lh9/c;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object p0

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object p0, p0, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v5, 0x1

    invoke-static {p0}, Lh9/c;->b([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    iget-object p1, p1, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1}, Lh9/c;->b([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-interface {p0, p1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    sget-object p1, Lh9/c;->l:[Lh9/c;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    array-length v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ge v1, v0, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    aget-object v2, p1, v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    iget-object v3, v2, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v5, 0x4

    invoke-static {v3}, Lh9/c;->b([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v3, p0}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v3, :cond_5

    const/4 v4, 0x3

    const/4 v4, 0x1

    return-object v2

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object p0, Lh9/c;->a:Lh9/c;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object p0

    :cond_7
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    return-object v0
.end method

.method private static h(Ljava/lang/Class;)Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/Class<",
            "+",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const/4 v2, 0x0

    const-class v0, Ljava/lang/Byte;

    const-class v0, Ljava/lang/Byte;

    const/4 v2, 0x0

    if-ne p0, v0, :cond_0

    const/4 v2, 0x5

    sget-object p0, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-class v0, Ljava/lang/Character;

    const-class v0, Ljava/lang/Character;

    const/4 v2, 0x5

    const-class v0, Ljava/lang/Character;

    const-class v0, Ljava/lang/Character;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-ne p0, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object p0, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-class v0, Ljava/lang/Short;

    const-class v0, Ljava/lang/Short;

    const/4 v2, 0x2

    const-class v0, Ljava/lang/Short;

    const-class v0, Ljava/lang/Short;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-ne p0, v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object p0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v1, 0x3

    const/4 v1, 0x5

    return-object p0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const/4 v2, 0x5

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ne p0, v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object p0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const/4 v2, 0x6

    const-class v0, Ljava/lang/Long;

    const-class v0, Ljava/lang/Long;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ne p0, v0, :cond_4

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object p0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x7

    return-object p0

    :cond_4
    const/4 v2, 0x1

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const/4 v2, 0x0

    const-class v0, Ljava/lang/Float;

    const-class v0, Ljava/lang/Float;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-ne p0, v0, :cond_5

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object p0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0

    :cond_5
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-class v0, Ljava/lang/Double;

    const-class v0, Ljava/lang/Double;

    const/4 v2, 0x5

    const-class v0, Ljava/lang/Double;

    const-class v0, Ljava/lang/Double;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-ne p0, v0, :cond_6

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object p0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_6
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-class v0, Ljava/lang/Boolean;

    const-class v0, Ljava/lang/Boolean;

    const/4 v2, 0x5

    const-class v0, Ljava/lang/Boolean;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-ne p0, v0, :cond_7

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object p0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0

    :cond_7
    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x4

    move v1, p0

    move v1, p0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lh9/c;
    .locals 3

    const/4 v2, 0x6

    const-class v0, Lh9/c;

    const-class v0, Lh9/c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lh9/c;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lh9/c;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lh9/c;->m:[Lh9/c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lh9/c;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, [Lh9/c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public e(Ljava/lang/Class;)Z
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)Z"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v0, p0, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    return v1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    sget-object v2, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ne p1, v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    return v1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    array-length v2, v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v4, v3

    move v4, v3

    const/4 v7, 0x6

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    if-ge v4, v2, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    aget-object v5, v0, v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v5, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v5, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    return v1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_3
    return v3
.end method

.method public toString()Ljava/lang/String;
    .locals 8
    .annotation runtime Lfa/b;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const-string v1, "riorvotcq soesey ngn"

    const-string v1, "nesogvce ynosrticr o"

    const-string/jumbo v1, "tesne ocyrorcvoi nsg"

    const-string v1, " conversion category"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v1, p0, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    array-length v1, v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez v1, :cond_0

    const/4 v7, 0x0

    goto :goto_1

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const-string v1, "e(nm: om "

    const-string v1, ":( m feon"

    const-string v1, "f ono: (o"

    const-string v1, "(one of: "

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v2, ")"

    const-string v2, ")"

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string v3, ", "

    const-string v3, ", "

    const/4 v7, 0x4

    const-string v3, ", "

    const-string v3, ", "

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v3, v1, v2}, Lh9/b;->a(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/util/StringJoiner;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v2, p0, Lh9/c;->types:[Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    array-length v3, v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v4, 0x0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    if-ge v4, v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    aget-object v5, v2, v4

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v5}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v1, v5}, Lh9/a;->a(Ljava/util/StringJoiner;Ljava/lang/CharSequence;)Ljava/util/StringJoiner;

    const/4 v6, 0x0

    and-int/2addr v7, v6

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v2, " "

    const-string v2, " "

    const/4 v7, 0x7

    const-string v2, " "

    const-string v2, " "

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-object v0

    :cond_2
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    return-object v0
.end method
