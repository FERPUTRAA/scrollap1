.class public interface abstract annotation Lh9/i;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime Lga/f0;
    value = {}
.end annotation

.annotation runtime Lga/g0;
    value = {
        .enum Lga/i0;->j:Lga/i0;,
        .enum Lga/i0;->m:Lga/i0;
    }
.end annotation

.annotation runtime Lga/h;
.end annotation

.annotation runtime Lga/q;
.end annotation

.annotation runtime Ljava/lang/annotation/Documented;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->RUNTIME:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {
        .enum Ljava/lang/annotation/ElementType;->TYPE_USE:Ljava/lang/annotation/ElementType;,
        .enum Ljava/lang/annotation/ElementType;->TYPE_PARAMETER:Ljava/lang/annotation/ElementType;
    }
.end annotation
