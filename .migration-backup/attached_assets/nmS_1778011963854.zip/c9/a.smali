.class public Lc9/a;
.super Ljava/lang/Object;

# interfaces
.implements Lc9/b;


# instance fields
.field private a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lorg/ahocorasick/trie/a;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lc9/a;->a:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a(Lorg/ahocorasick/trie/a;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sl  M/@ b t~i@~@~@~rb @o ~@  o~~~S~oys4~i@i~d@/ ~@@ a~~~~@K umocbof@@ @@vt f~ n@~-~@@ @~ @lo1."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lc9/a;->a:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public b()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lorg/ahocorasick/trie/a;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lc9/a;->a:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method
