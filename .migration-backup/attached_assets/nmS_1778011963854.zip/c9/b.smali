.class public interface abstract Lc9/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lorg/ahocorasick/trie/a;)V
.end method
