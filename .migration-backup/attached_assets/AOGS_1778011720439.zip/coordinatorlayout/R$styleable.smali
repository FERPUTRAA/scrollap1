.class public final Landroidx/coordinatorlayout/R$styleable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static final ColorStateListItem:[I

.field public static final ColorStateListItem_alpha:I = 0x3

.field public static final ColorStateListItem_android_alpha:I = 0x1

.field public static final ColorStateListItem_android_color:I = 0x0

.field public static final ColorStateListItem_android_lStar:I = 0x2

.field public static final ColorStateListItem_lStar:I = 0x4

.field public static final CoordinatorLayout:[I

.field public static final CoordinatorLayout_Layout:[I

.field public static final CoordinatorLayout_Layout_android_layout_gravity:I = 0x0

.field public static final CoordinatorLayout_Layout_layout_anchor:I = 0x1

.field public static final CoordinatorLayout_Layout_layout_anchorGravity:I = 0x2

.field public static final CoordinatorLayout_Layout_layout_behavior:I = 0x3

.field public static final CoordinatorLayout_Layout_layout_dodgeInsetEdges:I = 0x4

.field public static final CoordinatorLayout_Layout_layout_insetEdge:I = 0x5

.field public static final CoordinatorLayout_Layout_layout_keyline:I = 0x6

.field public static final CoordinatorLayout_keylines:I = 0x0

.field public static final CoordinatorLayout_statusBarBackground:I = 0x1

.field public static final FontFamily:[I

.field public static final FontFamilyFont:[I

.field public static final FontFamilyFont_android_font:I = 0x0

.field public static final FontFamilyFont_android_fontStyle:I = 0x2

.field public static final FontFamilyFont_android_fontVariationSettings:I = 0x4

.field public static final FontFamilyFont_android_fontWeight:I = 0x1

.field public static final FontFamilyFont_android_ttcIndex:I = 0x3

.field public static final FontFamilyFont_font:I = 0x5

.field public static final FontFamilyFont_fontStyle:I = 0x6

.field public static final FontFamilyFont_fontVariationSettings:I = 0x7

.field public static final FontFamilyFont_fontWeight:I = 0x8

.field public static final FontFamilyFont_ttcIndex:I = 0x9

.field public static final FontFamily_fontProviderAuthority:I = 0x0

.field public static final FontFamily_fontProviderCerts:I = 0x1

.field public static final FontFamily_fontProviderFetchStrategy:I = 0x2

.field public static final FontFamily_fontProviderFetchTimeout:I = 0x3

.field public static final FontFamily_fontProviderPackage:I = 0x4

.field public static final FontFamily_fontProviderQuery:I = 0x5

.field public static final FontFamily_fontProviderSystemFontFamily:I = 0x6

.field public static final GradientColor:[I

.field public static final GradientColorItem:[I

.field public static final GradientColorItem_android_color:I = 0x0

.field public static final GradientColorItem_android_offset:I = 0x1

.field public static final GradientColor_android_centerColor:I = 0x7

.field public static final GradientColor_android_centerX:I = 0x3

.field public static final GradientColor_android_centerY:I = 0x4

.field public static final GradientColor_android_endColor:I = 0x1

.field public static final GradientColor_android_endX:I = 0xa

.field public static final GradientColor_android_endY:I = 0xb

.field public static final GradientColor_android_gradientRadius:I = 0x5

.field public static final GradientColor_android_startColor:I = 0x0

.field public static final GradientColor_android_startX:I = 0x8

.field public static final GradientColor_android_startY:I = 0x9

.field public static final GradientColor_android_tileMode:I = 0x6

.field public static final GradientColor_android_type:I = 0x2


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    const v0, 0x7f040031

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    const v1, 0x7f04028e

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    const v2, 0x10101a5

    const/4 v6, 0x1

    const/4 v5, 0x6

    const v3, 0x101031f

    const/4 v6, 0x1

    const/4 v5, 0x1

    const v4, 0x1010647

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    filled-new-array {v2, v3, v4, v0, v1}, [I

    move-result-object v0

    const/4 v5, 0x4

    move v6, v5

    sput-object v0, Landroidx/coordinatorlayout/R$styleable;->ColorStateListItem:[I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const v0, 0x7f04028d

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const v1, 0x7f0404b4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    sput-object v0, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout:[I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v0, 0x7

    const/4 v5, 0x0

    const/4 v5, 0x4

    new-array v1, v0, [I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    fill-array-data v1, :array_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    sput-object v1, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout:[I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-array v0, v0, [I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    fill-array-data v0, :array_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    sput-object v0, Landroidx/coordinatorlayout/R$styleable;->FontFamily:[I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/16 v0, 0xa

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-array v0, v0, [I

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    fill-array-data v0, :array_2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    sput-object v0, Landroidx/coordinatorlayout/R$styleable;->FontFamilyFont:[I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v0, 0xc

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-array v0, v0, [I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    fill-array-data v0, :array_3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    sput-object v0, Landroidx/coordinatorlayout/R$styleable;->GradientColor:[I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const v0, 0x1010514

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    filled-new-array {v2, v0}, [I

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    sput-object v0, Landroidx/coordinatorlayout/R$styleable;->GradientColorItem:[I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void

    :array_0
    .array-data 4
        0x10100b3
        0x7f04029a
        0x7f04029b
        0x7f04029c
        0x7f0402cd
        0x7f0402db
        0x7f0402dc
    .end array-data

    :array_1
    .array-data 4
        0x7f040211
        0x7f040212
        0x7f040213
        0x7f040214
        0x7f040215
        0x7f040216
        0x7f040217
    .end array-data

    :array_2
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f04020f
        0x7f040218
        0x7f040219
        0x7f04021a
        0x7f04057d
    .end array-data

    :array_3
    .array-data 4
        0x101019d
        0x101019e
        0x10101a1
        0x10101a2
        0x10101a3
        0x10101a4
        0x1010201
        0x101020b
        0x1010510
        0x1010511
        0x1010512
        0x1010513
    .end array-data
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method
