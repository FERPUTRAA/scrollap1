.class public final Landroidx/coordinatorlayout/widget/b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private final a:Landroidx/core/util/p$a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/core/util/p$a<",
            "Ljava/util/ArrayList<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field private final b:Landroidx/collection/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/m<",
            "TT;",
            "Ljava/util/ArrayList<",
            "TT;>;>;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "TT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Landroidx/core/util/p$b;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v1, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroidx/core/util/p$b;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/b;->a:Landroidx/core/util/p$a;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Landroidx/collection/m;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Landroidx/collection/m;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/b;->c:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/util/HashSet;

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/b;->d:Ljava/util/HashSet;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method private e(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Ljava/util/ArrayList<",
            "TT;>;",
            "Ljava/util/HashSet<",
            "TT;>;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@sd4  ~~@b@t~~~ yi.  M@~@~r@  m-@~t@b@i~ ~@i@ a@@ @~o  1olbuv~/@/~co~nKo oS~sl~~~o @ @f@~ ~f ~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {p3, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p3, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    check-cast v0, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ge v2, v1, :cond_1

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0, v3, p2, p3}, Landroidx/coordinatorlayout/widget/b;->e(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p3, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo p2, "octmlaicpdn  T cspgeeidisehshiynnnascc "

    const-string/jumbo p2, "snscetcya eiccnadiehlcnp ssp dhiTrgin o"

    const/4 v5, 0x5

    const-string/jumbo p2, "nagio ay renecsdchctTshpcicnneeolsidi  "

    const-string p2, "This graph contains cyclic dependencies"

    const/4 v5, 0x2

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    throw p1
.end method

.method private f()Ljava/util/ArrayList;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->a:Landroidx/core/util/p$a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Landroidx/core/util/p$a;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method private k(Ljava/util/ArrayList;)V
    .locals 3
    .param p1    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->a:Landroidx/core/util/p$a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Landroidx/core/util/p$a;->a(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;TT;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroidx/collection/m;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v3, 0x1

    invoke-virtual {v0, p2}, Landroidx/collection/m;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Landroidx/coordinatorlayout/widget/b;->f()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v1, p1, v0}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const-string p2, " elgbbreee sse  motp  nesape dddetbahleindrb u rgAndiseanohte n  ag "

    const-string p2, "All nodes must be present in the graph before being added as an edge"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw p1
.end method

.method public b(Ljava/lang/Object;)V
    .locals 4
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v0, p1}, Landroidx/collection/m;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p1, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public c()V
    .locals 5

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroidx/collection/m;->size()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ge v1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v2, v1}, Landroidx/collection/m;->p(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v2, Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, v2}, Landroidx/coordinatorlayout/widget/b;->k(Ljava/util/ArrayList;)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/collection/m;->clear()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method public d(Ljava/lang/Object;)Z
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/collection/m;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p1
.end method

.method public g(Ljava/lang/Object;)Ljava/util/List;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)",
            "Ljava/util/List;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p1, Ljava/util/List;

    const/4 v1, 0x5

    move v2, v1

    return-object p1
.end method

.method public h(Ljava/lang/Object;)Ljava/util/List;
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)",
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroidx/collection/m;->size()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ge v2, v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v3, v2}, Landroidx/collection/m;->p(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    check-cast v3, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v3, v2}, Landroidx/collection/m;->i(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v1
.end method

.method public i()Ljava/util/ArrayList;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->c:Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->d:Ljava/util/HashSet;

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/util/HashSet;->clear()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroidx/collection/m;->size()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-ge v1, v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Landroidx/collection/m;->i(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v3, p0, Landroidx/coordinatorlayout/widget/b;->c:Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v4, p0, Landroidx/coordinatorlayout/widget/b;->d:Ljava/util/HashSet;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {p0, v2, v3, v4}, Landroidx/coordinatorlayout/widget/b;->e(Ljava/lang/Object;Ljava/util/ArrayList;Ljava/util/HashSet;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->c:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-object v0
.end method

.method public j(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroidx/collection/m;->size()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-ge v2, v0, :cond_1

    const/4 v5, 0x2

    iget-object v3, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v3, v2}, Landroidx/collection/m;->p(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    check-cast v3, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 p1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    return p1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    return v1
.end method

.method l()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/b;->b:Landroidx/collection/m;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/collection/m;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method
