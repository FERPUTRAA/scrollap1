.class public final synthetic Landroidx/coordinatorlayout/widget/a;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "bosfio~@~~@o~r t4@1 f ~@~ i@yK~~ u@ /~ @i~  ~-nb @d~ ~~@ @@b@a o@@o~ c@ @ol~/lv@~@~S~~ ~t~@. sMm"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual/range {p0 .. p6}, Landroid/view/ViewGroup;->saveAttributeDataForStyleable(Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method
