.class Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Comparator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "i"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Comparator<",
        "Landroid/view/View;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Landroid/view/View;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~.tdi@u@~~  oml ~~@ @~f@~~  o@@~4b-v ~~o~c r ~@Mo~si n@ia@~ /@o~o/@K1bt @yb@@flS~  @~~@ @~@ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {p1}, Landroidx/core/view/k1;->F0(Landroid/view/View;)F

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p2}, Landroidx/core/view/k1;->F0(Landroid/view/View;)F

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    cmpl-float v0, p1, p2

    const/4 v2, 0x6

    const/4 v1, 0x3

    if-lez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    return p1

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    cmpg-float p1, p1, p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-gez p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1
.end method

.method public bridge synthetic compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    check-cast p1, Landroid/view/View;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    check-cast p2, Landroid/view/View;

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$i;->a(Landroid/view/View;Landroid/view/View;)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p1
.end method
