.class public Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;
.super Landroid/view/ViewGroup$MarginLayoutParams;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/widget/CoordinatorLayout;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "g"
.end annotation


# instance fields
.field a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

.field b:Z

.field public c:I

.field public d:I

.field public e:I

.field f:I

.field public g:I

.field public h:I

.field i:I

.field j:I

.field k:Landroid/view/View;

.field l:Landroid/view/View;

.field private m:Z

.field private n:Z

.field private o:Z

.field private p:Z

.field final q:Landroid/graphics/Rect;

.field r:Ljava/lang/Object;


# direct methods
.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(II)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 p1, 0x0

    shl-int/2addr v1, p1

    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p2, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    new-instance p1, Landroid/graphics/Rect;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x1

    move v5, v4

    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v2, Landroid/graphics/Rect;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-object v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-object v2, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout:[I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1, p2, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget v3, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_android_layout_gravity:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2, v3, v0}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget v3, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_layout_anchor:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v2, v3, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget v3, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_layout_anchorGravity:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, v3, v0}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput v3, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    sget v3, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_layout_keyline:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2, v3, v1}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget v1, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_layout_insetEdge:I

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, v1, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    sget v1, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_layout_dodgeInsetEdges:I

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v1, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget v0, Landroidx/coordinatorlayout/R$styleable;->CoordinatorLayout_Layout_layout_behavior:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-boolean v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1, p2, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout;->J(Landroid/content/Context;Landroid/util/AttributeSet;Ljava/lang/String;)Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    const/4 v5, 0x3

    invoke-virtual {p1, p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onAttachedToLayoutParams(Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p1, Landroid/graphics/Rect;

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p1, Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;)V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v0, -0x1

    move v2, v0

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->e:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v1, 0x0

    move v2, v1

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Landroid/graphics/Rect;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p1}, Landroid/graphics/Rect;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private o(Landroid/view/View;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "u@s  K~bi~@l ~ ~4~@~~of~s  @@oid-~Ml~c@ ~1S @ a~@/~m@~t@.or @@@~b@of@/b ~ @yno ~@~ v~@~~ o~@@  i"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_6

    if-ne v0, p2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2}, Landroid/view/View;->isInEditMode()Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo p2, "orst tceote oiyrheotdwtainnLn ahon  aea boh  eutaVCnertpcord"

    const/4 v5, 0x7

    const-string p2, "a nmtrahhoan nt o oLcd i yVcateo eroohptweeCtbnuaoi  tntdrer"

    const-string p2, "View can not be anchored to the the parent CoordinatorLayout"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    throw p1

    :cond_1
    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eq v2, p2, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v2, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne v2, p1, :cond_3

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-virtual {p2}, Landroid/view/View;->isInEditMode()Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo p2, "r onooa sonAon d eitte  sedeamccwth bvnt h narehcmfu"

    const-string p2, "d nmtnobaew th sefsvniAd er hceotun ca mhn a eooetcr"

    const/4 v5, 0x7

    const-string/jumbo p2, "reehebt soenan demseoa  hn tt wA vhcobn tncdua cdrif"

    const-string p2, "Anchor must not be a descendant of the anchored view"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    throw p1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    instance-of v3, v2, Landroid/view/View;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v3, :cond_4

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    check-cast v0, Landroid/view/View;

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v2}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void

    :cond_6
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p2}, Landroid/view/View;->isInEditMode()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_7

    const/4 v5, 0x1

    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void

    :cond_7
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v2, " dtdrouno ouoi e fitdaeitnvcdwlrn  dintse nthuLoaoyCCw da"

    const-string/jumbo v2, "wtoioioufyddd ovantoCnaLdsdhoncdennr riaCu l  e oewt i tt"

    const/4 v5, 0x2

    const-string/jumbo v2, "n dutodpe  oia ou Cdrtnylcitsih vitnnodwLnado tweadrCeif "

    const-string v2, "Could not find CoordinatorLayout descendant view with id "

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p2}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p2, v2}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo p2, "o ihaetoq wb rcn"

    const-string/jumbo p2, "n oiwbvtreoc  ha"

    const/4 v5, 0x3

    const-string/jumbo p2, "rcs   eav hitown"

    const-string p2, " to anchor view "

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    throw v0
.end method

.method private u(Landroid/view/View;I)Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;

    const/4 v2, 0x2

    iget p1, p1, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1, p2}, Landroidx/core/view/b0;->d(II)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    iget v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->h:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p2}, Landroidx/core/view/b0;->d(II)I

    move-result p2

    const/4 v2, 0x3

    and-int/2addr p2, p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-ne p2, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p1
.end method

.method private v(Landroid/view/View;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Z
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    return v2

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq v1, p2, :cond_4

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    if-eqz v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne v1, p1, :cond_1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    instance-of v3, v1, Landroid/view/View;

    const/4 v4, 0x2

    move v5, v4

    if-eqz v3, :cond_2

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    check-cast v0, Landroid/view/View;

    :cond_2
    const/4 v5, 0x2

    invoke-interface {v1}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v2

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return p1
.end method


# virtual methods
.method a()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v1, -0x1

    move v3, v1

    const/4 v2, 0x3

    move v3, v2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0
.end method

.method b(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eq p3, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, p3, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->u(Landroid/view/View;I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {v0, p1, p2, p3}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->layoutDependsOn(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p1
.end method

.method c()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->m:Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->m:Z

    const/4 v2, 0x0

    return v0
.end method

.method d(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Landroid/view/View;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    iget v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    invoke-direct {p0, p2, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->v(Landroid/view/View;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_2

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0, p2, p1}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->o(Landroid/view/View;Landroidx/coordinatorlayout/widget/CoordinatorLayout;)V

    :cond_2
    const/4 v3, 0x7

    iget-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p1
.end method

.method public e()I
    .locals 3
    .annotation build Landroidx/annotation/d0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public f()Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v2, 0x7

    return-object v0
.end method

.method g()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->p:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method h()Landroid/graphics/Rect;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object v0
.end method

.method i()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->l:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->k:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method j(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->m:Z

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v1, p1, p2}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->blocksInteractionBelow(Landroidx/coordinatorlayout/widget/CoordinatorLayout;Landroid/view/View;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    or-int/2addr p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->m:Z

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return p1
.end method

.method k(I)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x6

    return p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->o:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->n:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p1
.end method

.method l()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->p:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method m(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->t(IZ)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method n()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->m:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public p(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->i()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->f:I

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public q(Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;)V
    .locals 3
    .param p1    # Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eq v0, p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onDetachedFromLayoutParams()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->a:Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->r:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    iput-boolean v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->b:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1, p0}, Landroidx/coordinatorlayout/widget/CoordinatorLayout$c;->onAttachedToLayoutParams(Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method r(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p1, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->p:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method s(Landroid/graphics/Rect;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->q:Landroid/graphics/Rect;

    invoke-virtual {v0, p1}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method t(IZ)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eq p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-boolean p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->o:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    iput-boolean p2, p0, Landroidx/coordinatorlayout/widget/CoordinatorLayout$g;->n:Z

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method
