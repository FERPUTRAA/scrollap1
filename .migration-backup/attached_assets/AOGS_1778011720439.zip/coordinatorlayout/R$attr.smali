.class public final Landroidx/coordinatorlayout/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/coordinatorlayout/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final alpha:I = 0x7f040031

.field public static final coordinatorLayoutStyle:I = 0x7f040155

.field public static final font:I = 0x7f04020f

.field public static final fontProviderAuthority:I = 0x7f040211

.field public static final fontProviderCerts:I = 0x7f040212

.field public static final fontProviderFetchStrategy:I = 0x7f040213

.field public static final fontProviderFetchTimeout:I = 0x7f040214

.field public static final fontProviderPackage:I = 0x7f040215

.field public static final fontProviderQuery:I = 0x7f040216

.field public static final fontStyle:I = 0x7f040218

.field public static final fontVariationSettings:I = 0x7f040219

.field public static final fontWeight:I = 0x7f04021a

.field public static final keylines:I = 0x7f04028d

.field public static final layout_anchor:I = 0x7f04029a

.field public static final layout_anchorGravity:I = 0x7f04029b

.field public static final layout_behavior:I = 0x7f04029c

.field public static final layout_dodgeInsetEdges:I = 0x7f0402cd

.field public static final layout_insetEdge:I = 0x7f0402db

.field public static final layout_keyline:I = 0x7f0402dc

.field public static final statusBarBackground:I = 0x7f0404b4

.field public static final ttcIndex:I = 0x7f04057d


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
