.class public final Landroidx/core/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final androidx_core_ripple_material_light:I = 0x7f06001f

.field public static final androidx_core_secondary_text_default_material_light:I = 0x7f060020

.field public static final notification_action_color_filter:I = 0x7f060283

.field public static final notification_icon_bg_color:I = 0x7f060284


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method
