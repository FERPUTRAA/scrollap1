.class public final Landroidx/core/animation/a$l;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/Animator$AnimatorListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/animation/a;->h(Landroid/animation/Animator;Li8/l;)Landroid/animation/Animator$AnimatorListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnimator.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Animator.kt\nandroidx/core/animation/AnimatorKt$addListener$listener$1\n+ 2 Animator.kt\nandroidx/core/animation/AnimatorKt$addListener$1\n+ 3 Animator.kt\nandroidx/core/animation/AnimatorKt$addListener$3\n+ 4 Animator.kt\nandroidx/core/animation/AnimatorKt$addListener$2\n*L\n1#1,127:1\n95#2:128\n97#3:129\n96#4:130\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Li8/l;


# direct methods
.method public constructor <init>(Li8/l;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput-object p1, p0, Landroidx/core/animation/a$l;->a:Li8/l;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ds@~m~tuy@~~~ M cv@ Kbb  @@o@14o ~o@os@@ ~~/@ ~~oi@@@o  ~ ~~t@f@~ ~. ll@i~ @b/~ @- S~n@i~@ a~fr"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const-string/jumbo v0, "tammiosa"

    const-string/jumbo v0, "itsoaarm"

    const/4 v2, 0x6

    const-string v0, "araoomit"

    const-string v0, "animator"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo v0, "nmamrbit"

    const-string/jumbo v0, "riomnatm"

    const/4 v2, 0x2

    const-string/jumbo v0, "riatnaum"

    const-string v0, "animator"

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public onAnimationRepeat(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const-string/jumbo v0, "irtoomap"

    const-string/jumbo v0, "itaoomrn"

    const/4 v2, 0x6

    const-string/jumbo v0, "qrtnaimo"

    const-string v0, "animator"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/animation/a$l;->a:Li8/l;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x2

    move v2, v1

    const-string/jumbo v0, "nasitbmo"

    const-string/jumbo v0, "tormibna"

    const/4 v2, 0x7

    const-string/jumbo v0, "oaimanrt"

    const-string v0, "animator"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
