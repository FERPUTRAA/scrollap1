.class public final Landroidx/core/animation/a$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/Animator$AnimatorListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/animation/a;->a(Landroid/animation/Animator;Li8/l;Li8/l;Li8/l;Li8/l;)Landroid/animation/Animator$AnimatorListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnimator.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Animator.kt\nandroidx/core/animation/AnimatorKt$addListener$listener$1\n*L\n1#1,127:1\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic b:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic c:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic d:Li8/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Li8/l<",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Li8/l;Li8/l;Li8/l;Li8/l;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;",
            "Li8/l<",
            "-",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;",
            "Li8/l<",
            "-",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;",
            "Li8/l<",
            "-",
            "Landroid/animation/Animator;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/animation/a$e;->a:Li8/l;

    const/4 v0, 0x1

    move v1, v0

    iput-object p2, p0, Landroidx/core/animation/a$e;->b:Li8/l;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p3, p0, Landroidx/core/animation/a$e;->c:Li8/l;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p4, p0, Landroidx/core/animation/a$e;->d:Li8/l;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~is@~~~ ~@t~t~/@ i@~~b@y~v~sa1o  ~@@@.  @@i  l o~M@@~ @  ~/@ oS-~  ~@@r~flfbo@b@ uK~no@c~~om~d @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "rmsmoian"

    const-string/jumbo v0, "ntsrmoia"

    const/4 v2, 0x0

    const-string/jumbo v0, "mnraoaot"

    const-string v0, "animator"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/animation/a$e;->c:Li8/l;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "minotbrm"

    const-string/jumbo v0, "nrammtio"

    const/4 v2, 0x3

    const-string/jumbo v0, "nmaitaur"

    const-string v0, "animator"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/animation/a$e;->b:Li8/l;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public onAnimationRepeat(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "naaomrtp"

    const-string v0, "amnooart"

    const-string/jumbo v0, "qiromaat"

    const-string v0, "animator"

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/animation/a$e;->a:Li8/l;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string v0, "bosnmrat"

    const-string/jumbo v0, "omitnbra"

    const/4 v2, 0x6

    const-string/jumbo v0, "inrmtaam"

    const-string v0, "animator"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/animation/a$e;->d:Li8/l;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
