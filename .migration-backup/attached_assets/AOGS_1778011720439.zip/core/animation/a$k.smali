.class public final Landroidx/core/animation/a$k;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/Animator$AnimatorPauseListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/animation/a;->g(Landroid/animation/Animator;Li8/l;)Landroid/animation/Animator$AnimatorPauseListener;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnimator.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Animator.kt\nandroidx/core/animation/AnimatorKt$addPauseListener$listener$1\n+ 2 Animator.kt\nandroidx/core/animation/AnimatorKt$addPauseListener$1\n*L\n1#1,127:1\n117#2:128\n*E\n"
.end annotation


# instance fields
.field final synthetic a:Li8/l;


# direct methods
.method public constructor <init>(Li8/l;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/animation/a$k;->a:Li8/l;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onAnimationPause(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "i s@o ~fo~/ctf@ ~ ~~dt@S ~ l/   @ ~nvK@~@M~ bo  moula@i ~@@.o~@@~bo@1~@~  @-@~~@~@b~@i~~~rs@~4y "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-string/jumbo v0, "stnmmiro"

    const-string/jumbo v0, "rnsmatio"

    const/4 v2, 0x3

    const-string/jumbo v0, "niaoortm"

    const-string v0, "animator"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Landroidx/core/animation/a$k;->a:Li8/l;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public onAnimationResume(Landroid/animation/Animator;)V
    .locals 3
    .param p1    # Landroid/animation/Animator;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo v0, "maiambnt"

    const-string/jumbo v0, "raamtimn"

    const/4 v2, 0x5

    const-string/jumbo v0, "mionaaut"

    const-string v0, "animator"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method
