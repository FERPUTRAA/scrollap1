.class public final Landroidx/core/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/R$attr;,
        Landroidx/core/R$color;,
        Landroidx/core/R$dimen;,
        Landroidx/core/R$drawable;,
        Landroidx/core/R$id;,
        Landroidx/core/R$integer;,
        Landroidx/core/R$layout;,
        Landroidx/core/R$string;,
        Landroidx/core/R$style;,
        Landroidx/core/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
