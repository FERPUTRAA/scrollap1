.class Landroidx/core/app/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/app/b;->m(Landroid/app/Activity;[Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/String;

.field final synthetic b:Landroid/app/Activity;

.field final synthetic c:I


# direct methods
.method constructor <init>([Ljava/lang/String;Landroid/app/Activity;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/b$a;->a:[Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput-object p2, p0, Landroidx/core/app/b$a;->b:Landroid/app/Activity;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p3, p0, Landroidx/core/app/b$a;->c:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@ sv @@ @~@ ~K~@~@l~cuii o /@@r@M  ~~bl 4~s@y@~~ botnf ~ @~@~@~~o@~.@1@~~@of /~ o@doam~i~ t S- b"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    iget-object v0, p0, Landroidx/core/app/b$a;->a:[Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x2

    array-length v0, v0

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-array v0, v0, [I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Landroidx/core/app/b$a;->b:Landroid/app/Activity;

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v2, p0, Landroidx/core/app/b$a;->b:Landroid/app/Activity;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v3, p0, Landroidx/core/app/b$a;->a:[Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    array-length v3, v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v4, 0x0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ge v4, v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v5, p0, Landroidx/core/app/b$a;->a:[Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    aget-object v5, v5, v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v1, v5, v2}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    aput v5, v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v6, 0x4

    move v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v1, p0, Landroidx/core/app/b$a;->b:Landroid/app/Activity;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    check-cast v1, Landroidx/core/app/b$i;

    const/4 v7, 0x4

    iget v2, p0, Landroidx/core/app/b$a;->c:I

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v3, p0, Landroidx/core/app/b$a;->a:[Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-interface {v1, v2, v3, v0}, Landroidx/core/app/b$i;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void
.end method
