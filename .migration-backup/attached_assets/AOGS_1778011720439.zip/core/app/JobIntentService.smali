.class public abstract Landroidx/core/app/JobIntentService;
.super Landroid/app/Service;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/JobIntentService$a;,
        Landroidx/core/app/JobIntentService$d;,
        Landroidx/core/app/JobIntentService$e;,
        Landroidx/core/app/JobIntentService$g;,
        Landroidx/core/app/JobIntentService$f;,
        Landroidx/core/app/JobIntentService$c;,
        Landroidx/core/app/JobIntentService$b;,
        Landroidx/core/app/JobIntentService$h;
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field static final h:Ljava/lang/String; = "JobIntentService"

.field static final i:Z

.field static final j:Ljava/lang/Object;

.field static final k:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Landroid/content/ComponentName;",
            "Landroidx/core/app/JobIntentService$h;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field a:Landroidx/core/app/JobIntentService$b;

.field b:Landroidx/core/app/JobIntentService$h;

.field c:Landroidx/core/app/JobIntentService$a;

.field d:Z

.field e:Z

.field f:Z

.field final g:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/core/app/JobIntentService$d;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput-object v0, Landroidx/core/app/JobIntentService;->j:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Landroidx/core/app/JobIntentService;->k:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService;->d:Z

    const/4 v3, 0x0

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService;->e:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService;->f:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/16 v1, 0x1a

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-lt v0, v1, :cond_0

    const/4 v2, 0x4

    move v3, v2

    const/4 v0, 0x0

    shr-int/2addr v3, v0

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public static c(Landroid/content/Context;Landroid/content/ComponentName;ILandroid/content/Intent;)V
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "1~s~~~fy~b @@a@l @~ @   /@t o@o@~@@@b@ o~~S~@.@~~ ~@fni~o~~~~ ~~ -l @ s4m@MKi@ ~t v u crdio/o@b@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    if-eqz p3, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Landroidx/core/app/JobIntentService;->j:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-enter v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    :try_start_0
    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, p1, v1, p2}, Landroidx/core/app/JobIntentService;->f(Landroid/content/Context;Landroid/content/ComponentName;ZI)Landroidx/core/app/JobIntentService$h;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Landroidx/core/app/JobIntentService$h;->b(I)V

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0, p3}, Landroidx/core/app/JobIntentService$h;->a(Landroid/content/Intent;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    throw p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const-string/jumbo p1, "senmk us twllrnmobu t"

    const-string/jumbo p1, "tbslmn oswutk nr u el"

    const/4 v3, 0x6

    const-string/jumbo p1, "ukswo  oub ne onrlttm"

    const-string/jumbo p1, "work must not be null"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/Class;ILandroid/content/Intent;)V
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/Class<",
            "*>;I",
            "Landroid/content/Intent;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Landroid/content/ComponentName;

    const/4 v1, 0x3

    move v2, v1

    invoke-direct {v0, p0, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0, p2, p3}, Landroidx/core/app/JobIntentService;->c(Landroid/content/Context;Landroid/content/ComponentName;ILandroid/content/Intent;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method static f(Landroid/content/Context;Landroid/content/ComponentName;ZI)Landroidx/core/app/JobIntentService$h;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v0, Landroidx/core/app/JobIntentService;->k:Ljava/util/HashMap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    check-cast v1, Landroidx/core/app/JobIntentService$h;

    const/4 v4, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v2, 0x1a

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-lt v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz p2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance p2, Landroidx/core/app/JobIntentService$g;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-direct {p2, p0, p1, p3}, Landroidx/core/app/JobIntentService$g;-><init>(Landroid/content/Context;Landroid/content/ComponentName;I)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const-string/jumbo p1, "iuat b/Cj/bt hotbieermn  adw oh"

    const-string p1, "etnm uiaij  w  trdeobe/Cbhthoa/"

    const/4 v4, 0x0

    const-string p1, "hraeo uboautwtn Cet j i de b//i"

    const-string p1, "Can\'t be here without a job id"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    throw p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance p2, Landroidx/core/app/JobIntentService$c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p2, p0, p1}, Landroidx/core/app/JobIntentService$c;-><init>(Landroid/content/Context;Landroid/content/ComponentName;)V

    :goto_0
    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-object v1
.end method


# virtual methods
.method a()Landroidx/core/app/JobIntentService$e;
    .locals 5

    const/4 v3, 0x0

    move v4, v3

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->a:Landroidx/core/app/JobIntentService$b;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {v0}, Landroidx/core/app/JobIntentService$b;->b()Landroidx/core/app/JobIntentService$e;

    move-result-object v0

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-lez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast v1, Landroidx/core/app/JobIntentService$e;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object v1

    :cond_1
    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0

    :catchall_0
    move-exception v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw v1
.end method

.method b()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->c:Landroidx/core/app/JobIntentService$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-boolean v1, p0, Landroidx/core/app/JobIntentService;->d:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->cancel(Z)Z

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService;->e:Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroidx/core/app/JobIntentService;->i()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method e(Z)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->c:Landroidx/core/app/JobIntentService$a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Landroidx/core/app/JobIntentService$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Landroidx/core/app/JobIntentService$a;-><init>(Landroidx/core/app/JobIntentService;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/core/app/JobIntentService;->c:Landroidx/core/app/JobIntentService$a;

    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->b:Landroidx/core/app/JobIntentService$h;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroidx/core/app/JobIntentService$h;->d()V

    :cond_0
    const/4 v3, 0x0

    iget-object p1, p0, Landroidx/core/app/JobIntentService;->c:Landroidx/core/app/JobIntentService$a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Landroid/os/AsyncTask;->THREAD_POOL_EXECUTOR:Ljava/util/concurrent/Executor;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-array v1, v1, [Ljava/lang/Void;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/AsyncTask;->executeOnExecutor(Ljava/util/concurrent/Executor;[Ljava/lang/Object;)Landroid/os/AsyncTask;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/core/app/JobIntentService;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method protected abstract h(Landroid/content/Intent;)V
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public i()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method j()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    monitor-enter v0

    const/4 v3, 0x3

    const/4 v1, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v1, p0, Landroidx/core/app/JobIntentService;->c:Landroidx/core/app/JobIntentService$a;

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Landroidx/core/app/JobIntentService;->e(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-boolean v1, p0, Landroidx/core/app/JobIntentService;->f:Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/core/app/JobIntentService;->b:Landroidx/core/app/JobIntentService$h;

    const/4 v3, 0x0

    invoke-virtual {v1}, Landroidx/core/app/JobIntentService$h;->c()V

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw v1

    :cond_2
    :goto_1
    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public k(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/core/app/JobIntentService;->d:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iget-object p1, p0, Landroidx/core/app/JobIntentService;->a:Landroidx/core/app/JobIntentService$b;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-interface {p1}, Landroidx/core/app/JobIntentService$b;->a()Landroid/os/IBinder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1

    :cond_0
    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public onCreate()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/16 v1, 0x1a

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-lt v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Landroidx/core/app/JobIntentService$f;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0, p0}, Landroidx/core/app/JobIntentService$f;-><init>(Landroidx/core/app/JobIntentService;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, p0, Landroidx/core/app/JobIntentService;->a:Landroidx/core/app/JobIntentService$b;

    const/4 v3, 0x5

    and-int/2addr v4, v3

    iput-object v2, p0, Landroidx/core/app/JobIntentService;->b:Landroidx/core/app/JobIntentService$h;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v2, p0, Landroidx/core/app/JobIntentService;->a:Landroidx/core/app/JobIntentService$b;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Landroid/content/ComponentName;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, p0, v1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0, v0, v1, v1}, Landroidx/core/app/JobIntentService;->f(Landroid/content/Context;Landroid/content/ComponentName;ZI)Landroidx/core/app/JobIntentService$h;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object v0, p0, Landroidx/core/app/JobIntentService;->b:Landroidx/core/app/JobIntentService$h;

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method public onDestroy()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    monitor-enter v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x1

    :try_start_0
    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-boolean v1, p0, Landroidx/core/app/JobIntentService;->f:Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/JobIntentService;->b:Landroidx/core/app/JobIntentService$h;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroidx/core/app/JobIntentService$h;->c()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    throw v1

    :cond_0
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 4
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p2, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x5

    if-eqz p2, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p2, p0, Landroidx/core/app/JobIntentService;->b:Landroidx/core/app/JobIntentService$h;

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroidx/core/app/JobIntentService$h;->e()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object p2, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    monitor-enter p2

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/JobIntentService;->g:Ljava/util/ArrayList;

    const/4 v3, 0x2

    new-instance v1, Landroidx/core/app/JobIntentService$d;

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v1, p0, p1, p3}, Landroidx/core/app/JobIntentService$d;-><init>(Landroidx/core/app/JobIntentService;Landroid/content/Intent;I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    invoke-virtual {p0, p1}, Landroidx/core/app/JobIntentService;->e(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p1, 0x3

    const/4 v3, 0x2

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    throw p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1
.end method
