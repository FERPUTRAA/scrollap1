.class Landroidx/core/app/x1$d$c;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1f
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1$d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "c"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method static a(Landroid/app/Notification$BigPictureStyle;Ljava/lang/CharSequence;)V
    .locals 2
    .annotation build Landroidx/annotation/w0;
        value = 0x1f
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ sn~~dtm@ c   ~ l@s.1@@~b~ @r@ou ~S- ~~ft~~v@ a@@@4~y  bl/fo~ oo~ ~b@ @~@~@~@ i@@~o@o@/K~ i@i~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Landroid/app/Notification$BigPictureStyle;->setContentDescription(Ljava/lang/CharSequence;)Landroid/app/Notification$BigPictureStyle;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method static b(Landroid/app/Notification$BigPictureStyle;Z)V
    .locals 2
    .annotation build Landroidx/annotation/w0;
        value = 0x1f
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/Notification$BigPictureStyle;->showBigPictureWhenCollapsed(Z)Landroid/app/Notification$BigPictureStyle;

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method
