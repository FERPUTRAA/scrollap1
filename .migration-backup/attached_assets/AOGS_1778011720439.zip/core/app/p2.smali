.class public final synthetic Landroidx/core/app/p2;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/lang/Class;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ois / c~~@@o@@~@~~a~vy@@~ ~@ o~.~ @@ @~~Mf r/4b~-~  @f~1 ~lu  @@ ~obi@t @@o~nd~ ~ K~@S@o~tm lbi@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-class v0, Landroid/app/Notification$MessagingStyle;

    const-class v0, Landroid/app/Notification$MessagingStyle;

    const/4 v2, 0x4

    const-class v0, Landroid/app/Notification$MessagingStyle;

    const-class v0, Landroid/app/Notification$MessagingStyle;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method
