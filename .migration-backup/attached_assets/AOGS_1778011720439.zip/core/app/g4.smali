.class public final Landroidx/core/app/g4;
.super Ljava/lang/Object;


# instance fields
.field private final a:Z

.field private final b:Landroid/content/res/Configuration;


# direct methods
.method public constructor <init>(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-boolean p1, p0, Landroidx/core/app/g4;->a:Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/g4;->b:Landroid/content/res/Configuration;

    return-void
.end method

.method public constructor <init>(ZLandroid/content/res/Configuration;)V
    .locals 2
    .param p2    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-boolean p1, p0, Landroidx/core/app/g4;->a:Z

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p2, p0, Landroidx/core/app/g4;->b:Landroid/content/res/Configuration;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a()Landroid/content/res/Configuration;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v3, 0x0

    const-string/jumbo v2, "~~s oo@S-.~i@f ~@@/@nf@bc  s@~tla@io  r~~1~@K~t oy@ @@o@m@o~@@b~ 4 bM  ~~@~@d/v   @i~@~~ ~~~u~l~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/g4;->b:Landroid/content/res/Configuration;

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, " aAmobiethnknooMrfoh.ttn PC itenushnuifrl aku   )eoIlctog utwiircPg oednhcmtolvvceshnarlnnt Pba?des tineto tttnt(ssaAf emyctaah geC erugaoCeruoi  iIotdis recr6 saaeeagcuwninoog Iti   endh ira2Nuafe mht rin  t"

    const-string v1, "gnsditetc ntyouowf   aieitnehinlPnkf6hvllar.hiaoitic uvdAunf a nc2ngar(o gtbeerckfouoegcnaicnwomi  sr atirrt autr  erm CebotonthiCn?e e otnsshhoroa i iMnt)edanreutsm ttl AeogPatPg sIecuNoI dtC e theh sacI u a"

    const/4 v3, 0x3

    const-string v1, "PictureInPictureModeChangedInfo must be constructed with the constructor that takes a Configuration to call getNewConfig(). Are you running on an API 26 or higher device that makes this information available?"

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    throw v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/core/app/g4;->a:Z

    const/4 v2, 0x1

    return v0
.end method
