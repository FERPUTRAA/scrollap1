.class public final Landroidx/core/app/x1$h;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/x1$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/x1$h$a;
    }
.end annotation


# static fields
.field static final d:Ljava/lang/String; = "android.car.EXTENSIONS"
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation
.end field

.field private static final e:Ljava/lang/String; = "large_icon"

.field private static final f:Ljava/lang/String; = "car_conversation"

.field private static final g:Ljava/lang/String; = "app_color"

.field static final h:Ljava/lang/String; = "invisible_actions"
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation
.end field

.field private static final i:Ljava/lang/String; = "author"

.field private static final j:Ljava/lang/String; = "text"

.field private static final k:Ljava/lang/String; = "messages"

.field private static final l:Ljava/lang/String; = "remote_input"

.field private static final m:Ljava/lang/String; = "on_reply"

.field private static final n:Ljava/lang/String; = "on_read"

.field private static final o:Ljava/lang/String; = "participants"

.field private static final p:Ljava/lang/String; = "timestamp"


# instance fields
.field private a:Landroid/graphics/Bitmap;

.field private b:Landroidx/core/app/x1$h$a;

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    iput v0, p0, Landroidx/core/app/x1$h;->c:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/app/Notification;)V
    .locals 4
    .param p1    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v0, p0, Landroidx/core/app/x1$h;->c:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1}, Landroidx/core/app/x1;->n(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Landroidx/core/app/x1;->n(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v1, "OcsENrrNn.S.STiasoXaEd"

    const-string v1, "ErsOraEiSSn.IcdaoN.XTN"

    const/4 v3, 0x6

    const-string v1, "OdomENiaE.nNT.drXSarcI"

    const-string v1, "android.car.EXTENSIONS"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string/jumbo v1, "la_gonmorc"

    const-string v1, "eromc_algn"

    const/4 v3, 0x1

    const-string v1, "elao_bcing"

    const-string/jumbo v1, "large_icon"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast v1, Landroid/graphics/Bitmap;

    const/4 v3, 0x2

    const/4 v2, 0x5

    iput-object v1, p0, Landroidx/core/app/x1$h;->a:Landroid/graphics/Bitmap;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v1, "oa_pcluoo"

    const-string v1, "al_oopcor"

    const/4 v3, 0x2

    const-string v1, "_lpapcrpo"

    const-string v1, "app_color"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput v0, p0, Landroidx/core/app/x1$h;->c:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v0, "io_cvbcstnaaerrn"

    const/4 v3, 0x0

    const-string/jumbo v0, "rcraeo_sqnicatvn"

    const-string v0, "car_conversation"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p1}, Landroidx/core/app/x1$h;->f(Landroid/os/Bundle;)Landroidx/core/app/x1$h$a;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, p0, Landroidx/core/app/x1$h;->b:Landroidx/core/app/x1$h$a;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private static b(Landroidx/core/app/x1$h$a;)Landroid/os/Bundle;
    .locals 10
    .param p0    # Landroidx/core/app/x1$h$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, " .s@ bio~@v l ~b@bK @1@-~ri/~  ~S@ ff@ di~@~  yoo~M@~s o~@n@mc/@l 4o @~a@@@~@ @~u~~t~~@~  ~~@t~~"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x0

    new-instance v0, Landroid/os/Bundle;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->d()[Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz v1, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->d()[Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    array-length v1, v1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v3, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-le v1, v3, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->d()[Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    aget-object v1, v1, v2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->b()[Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    array-length v3, v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    new-array v4, v3, [Landroid/os/Parcelable;

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-ge v2, v3, :cond_1

    const/4 v8, 0x2

    and-int/2addr v9, v8

    new-instance v5, Landroid/os/Bundle;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {v5}, Landroid/os/Bundle;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->b()[Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    aget-object v6, v6, v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string/jumbo v7, "txet"

    const-string/jumbo v7, "xtte"

    const/4 v9, 0x2

    const-string/jumbo v7, "tetx"

    const-string/jumbo v7, "text"

    invoke-virtual {v5, v7, v6}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string/jumbo v6, "trumua"

    const-string/jumbo v6, "uuthra"

    const/4 v9, 0x2

    const-string v6, "auroot"

    const-string v6, "author"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v5, v6, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    aput-object v5, v4, v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x6

    move v9, v8

    goto :goto_1

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string/jumbo v1, "sgeeabss"

    const-string/jumbo v1, "messages"

    const/4 v9, 0x3

    invoke-virtual {v0, v1, v4}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->f()Landroidx/core/app/h4;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-eqz v1, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v2, Landroid/app/RemoteInput$Builder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1}, Landroidx/core/app/h4;->o()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {v2, v3}, Landroid/app/RemoteInput$Builder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v1}, Landroidx/core/app/h4;->n()Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-virtual {v2, v3}, Landroid/app/RemoteInput$Builder;->setLabel(Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v1}, Landroidx/core/app/h4;->h()[Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v2, v3}, Landroid/app/RemoteInput$Builder;->setChoices([Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x2

    invoke-virtual {v1}, Landroidx/core/app/h4;->f()Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v2, v3}, Landroid/app/RemoteInput$Builder;->setAllowFreeFormInput(Z)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v1}, Landroidx/core/app/h4;->m()Landroid/os/Bundle;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v2, v1}, Landroid/app/RemoteInput$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/RemoteInput$Builder;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v1}, Landroid/app/RemoteInput$Builder;->build()Landroid/app/RemoteInput;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string/jumbo v2, "op_unmuettrp"

    const-string/jumbo v2, "proett_pmnue"

    const/4 v9, 0x7

    const-string/jumbo v2, "remote_input"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v1, "eln_porp"

    const-string/jumbo v1, "qoerpln_"

    const/4 v9, 0x1

    const-string/jumbo v1, "qlr_npyo"

    const-string/jumbo v1, "on_reply"

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->g()Landroid/app/PendingIntent;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v1, "nosrsde"

    const-string/jumbo v1, "ors_nde"

    const/4 v9, 0x6

    const-string v1, "ar_moen"

    const-string/jumbo v1, "on_read"

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->e()Landroid/app/PendingIntent;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string/jumbo v1, "scriopaamnit"

    const-string v1, "cspmptnaiair"

    const/4 v9, 0x3

    const-string/jumbo v1, "ptapnbiscrti"

    const-string/jumbo v1, "participants"

    const/4 v9, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->d()[Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string/jumbo v1, "mopasiutm"

    const-string/jumbo v1, "itsmoamep"

    const/4 v9, 0x1

    const-string/jumbo v1, "mmaipstpe"

    const-string/jumbo v1, "timestamp"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroidx/core/app/x1$h$a;->a()J

    move-result-wide v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    return-object v0
.end method

.method private static f(Landroid/os/Bundle;)Landroidx/core/app/x1$h$a;
    .locals 21
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    const-string/jumbo v2, "qembsseg"

    const-string v2, "emsesbsg"

    const-string/jumbo v2, "mssesega"

    const-string/jumbo v2, "messages"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getParcelableArray(Ljava/lang/String;)[Landroid/os/Parcelable;

    move-result-object v2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_5

    array-length v5, v2

    new-array v6, v5, [Ljava/lang/String;

    move v7, v4

    move v7, v4

    move v7, v4

    move v7, v4

    :goto_0
    if-ge v7, v5, :cond_3

    aget-object v8, v2, v7

    instance-of v9, v8, Landroid/os/Bundle;

    if-nez v9, :cond_1

    :goto_1
    move v2, v4

    move v2, v4

    move v2, v4

    move v2, v4

    goto :goto_2

    :cond_1
    check-cast v8, Landroid/os/Bundle;

    const-string v9, "extt"

    const-string v9, "etxt"

    const-string v9, "extt"

    const-string/jumbo v9, "text"

    invoke-virtual {v8, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v6, v7

    if-nez v8, :cond_2

    goto :goto_1

    :cond_2
    add-int/lit8 v7, v7, 0x1

    goto :goto_0

    :cond_3
    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :goto_2
    if-eqz v2, :cond_4

    move-object v8, v6

    move-object v8, v6

    move-object v8, v6

    goto :goto_3

    :cond_4
    return-object v1

    :cond_5
    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    :goto_3
    const-string/jumbo v2, "reamdun"

    const-string/jumbo v2, "reonadu"

    const-string v2, "_donore"

    const-string/jumbo v2, "on_read"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v2

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    move-object v11, v2

    check-cast v11, Landroid/app/PendingIntent;

    const-string/jumbo v2, "nle_pboy"

    const-string/jumbo v2, "on_reply"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v2

    move-object v10, v2

    move-object v10, v2

    check-cast v10, Landroid/app/PendingIntent;

    const-string v2, "ernmotut_upp"

    const-string/jumbo v2, "t_mroutpeinp"

    const-string/jumbo v2, "iprtne_pmuet"

    const-string/jumbo v2, "remote_input"

    invoke-virtual {v0, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v2

    check-cast v2, Landroid/app/RemoteInput;

    const-string/jumbo v5, "pqaipartqcti"

    const-string v5, "acipittnqpra"

    const-string/jumbo v5, "icsatatpnsrp"

    const-string/jumbo v5, "participants"

    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_9

    array-length v5, v12

    if-eq v5, v3, :cond_6

    goto :goto_4

    :cond_6
    if-eqz v2, :cond_8

    new-instance v1, Landroidx/core/app/h4;

    invoke-virtual {v2}, Landroid/app/RemoteInput;->getResultKey()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v2}, Landroid/app/RemoteInput;->getLabel()Ljava/lang/CharSequence;

    move-result-object v15

    invoke-virtual {v2}, Landroid/app/RemoteInput;->getChoices()[Ljava/lang/CharSequence;

    move-result-object v16

    invoke-virtual {v2}, Landroid/app/RemoteInput;->getAllowFreeFormInput()Z

    move-result v17

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1d

    if-lt v3, v5, :cond_7

    invoke-static {v2}, Landroidx/core/app/u1;->a(Landroid/app/RemoteInput;)I

    move-result v4

    :cond_7
    move/from16 v18, v4

    move/from16 v18, v4

    move/from16 v18, v4

    move/from16 v18, v4

    invoke-virtual {v2}, Landroid/app/RemoteInput;->getExtras()Landroid/os/Bundle;

    move-result-object v19

    const/16 v20, 0x0

    move-object v13, v1

    move-object v13, v1

    move-object v13, v1

    invoke-direct/range {v13 .. v20}, Landroidx/core/app/h4;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZILandroid/os/Bundle;Ljava/util/Set;)V

    :cond_8
    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    new-instance v1, Landroidx/core/app/x1$h$a;

    const-string/jumbo v2, "mmemsstti"

    const-string/jumbo v2, "mpsmsiett"

    const-string/jumbo v2, "tsmpoteim"

    const-string/jumbo v2, "timestamp"

    invoke-virtual {v0, v2}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v13

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    invoke-direct/range {v7 .. v14}, Landroidx/core/app/x1$h$a;-><init>([Ljava/lang/String;Landroidx/core/app/h4;Landroid/app/PendingIntent;Landroid/app/PendingIntent;[Ljava/lang/String;J)V

    :cond_9
    :goto_4
    return-object v1
.end method


# virtual methods
.method public a(Landroidx/core/app/x1$g;)Landroidx/core/app/x1$g;
    .locals 5
    .param p1    # Landroidx/core/app/x1$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$h;->a:Landroid/graphics/Bitmap;

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "i_nogbcmrl"

    const-string/jumbo v2, "o_lmiragnc"

    const-string/jumbo v2, "niaogeur_c"

    const-string/jumbo v2, "large_icon"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Landroidx/core/app/x1$h;->c:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const-string v2, "_lpropcpo"

    const-string v2, "app_color"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/core/app/x1$h;->b:Landroidx/core/app/x1$h$a;

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1}, Landroidx/core/app/x1$h;->b(Landroidx/core/app/x1$h$a;)Landroid/os/Bundle;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const-string/jumbo v2, "i_sctaroqanecrov"

    const-string/jumbo v2, "r_stocavonaenric"

    const-string/jumbo v2, "ovss_iarrecotnna"

    const-string v2, "car_conversation"

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroidx/core/app/x1$g;->t()Landroid/os/Bundle;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v2, "bdNmdocEXSnSrraNiTEIO."

    const-string/jumbo v2, "n.N.rbEdSXrNdiScOIaToE"

    const/4 v4, 0x5

    const-string v2, "TISroXNadariE.OEcSNnod"

    const-string v2, "android.car.EXTENSIONS"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object p1
.end method

.method public c()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Landroidx/core/app/x1$h;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public d()Landroid/graphics/Bitmap;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$h;->a:Landroid/graphics/Bitmap;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public e()Landroidx/core/app/x1$h$a;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$h;->b:Landroidx/core/app/x1$h$a;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    return-object v0
.end method

.method public g(I)Landroidx/core/app/x1$h;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Landroidx/core/app/x1$h;->c:I

    const/4 v1, 0x4

    return-object p0
.end method

.method public h(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$h;
    .locals 2
    .param p1    # Landroid/graphics/Bitmap;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-object p1, p0, Landroidx/core/app/x1$h;->a:Landroid/graphics/Bitmap;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method public i(Landroidx/core/app/x1$h$a;)Landroidx/core/app/x1$h;
    .locals 2
    .param p1    # Landroidx/core/app/x1$h$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/core/app/x1$h;->b:Landroidx/core/app/x1$h$a;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method
