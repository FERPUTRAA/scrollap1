.class public Landroidx/core/app/RemoteActionCompatParcelizer;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static read(Landroidx/versionedparcelable/e;)Landroidx/core/app/RemoteActionCompat;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "o s  b@@/v~sy~@ @@i @ ~@bc~ ~@@o~/@~o~@f 1~~~@- @@ d~u~.to  bM@@ir~ mf oS ~~@~4i~~ onla@~@~ @lK~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    new-instance v0, Landroidx/core/app/RemoteActionCompat;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0}, Landroidx/core/app/RemoteActionCompat;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->a:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Landroidx/versionedparcelable/e;->h0(Landroidx/versionedparcelable/h;I)Landroidx/versionedparcelable/h;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast v1, Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->a:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->b:Ljava/lang/CharSequence;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Landroidx/versionedparcelable/e;->w(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->b:Ljava/lang/CharSequence;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->c:Ljava/lang/CharSequence;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Landroidx/versionedparcelable/e;->w(Ljava/lang/CharSequence;I)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->c:Ljava/lang/CharSequence;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, v0, Landroidx/core/app/RemoteActionCompat;->d:Landroid/app/PendingIntent;

    const/4 v3, 0x2

    move v4, v3

    const/4 v2, 0x4

    or-int/2addr v4, v2

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Landroidx/versionedparcelable/e;->W(Landroid/os/Parcelable;I)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast v1, Landroid/app/PendingIntent;

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-object v1, v0, Landroidx/core/app/RemoteActionCompat;->d:Landroid/app/PendingIntent;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->e:Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x5

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, v1, v2}, Landroidx/versionedparcelable/e;->m(ZI)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    iput-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->e:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-boolean v1, v0, Landroidx/core/app/RemoteActionCompat;->f:Z

    const/4 v4, 0x7

    const/4 v2, 0x6

    const/4 v4, 0x7

    move v3, v2

    move v3, v2

    const/4 v4, 0x0

    invoke-virtual {p0, v1, v2}, Landroidx/versionedparcelable/e;->m(ZI)Z

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-boolean p0, v0, Landroidx/core/app/RemoteActionCompat;->f:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method public static write(Landroidx/core/app/RemoteActionCompat;Landroidx/versionedparcelable/e;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v0}, Landroidx/versionedparcelable/e;->j0(ZZ)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/RemoteActionCompat;->a:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroidx/versionedparcelable/e;->m1(Landroidx/versionedparcelable/h;I)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/RemoteActionCompat;->b:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroidx/versionedparcelable/e;->z0(Ljava/lang/CharSequence;I)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/RemoteActionCompat;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v1, 0x3

    or-int/2addr v2, v1

    invoke-virtual {p1, v0, v1}, Landroidx/versionedparcelable/e;->z0(Ljava/lang/CharSequence;I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/RemoteActionCompat;->d:Landroid/app/PendingIntent;

    const/4 v1, 0x4

    and-int/2addr v3, v1

    and-int/2addr v2, v1

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroidx/versionedparcelable/e;->X0(Landroid/os/Parcelable;I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-boolean v0, p0, Landroidx/core/app/RemoteActionCompat;->e:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroidx/versionedparcelable/e;->n0(ZI)V

    const/4 v2, 0x2

    move v3, v2

    iget-boolean p0, p0, Landroidx/core/app/RemoteActionCompat;->f:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x6

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1, p0, v0}, Landroidx/versionedparcelable/e;->n0(ZI)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-void
.end method
