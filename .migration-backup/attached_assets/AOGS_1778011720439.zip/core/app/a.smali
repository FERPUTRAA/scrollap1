.class public final synthetic Landroidx/core/app/a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/a;->a:Landroid/app/Activity;

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "MKsb@@ oito~l~b @ ~@~@ ~us@1~ ~va/@o@  l m@4@/no~f~t@  r @y@~~~@@.~~c@ ~@b~ ~i-@~~ o  @S~f~ ~dio"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/core/app/a;->a:Landroid/app/Activity;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0}, Landroidx/core/app/b;->b(Landroid/app/Activity;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method
