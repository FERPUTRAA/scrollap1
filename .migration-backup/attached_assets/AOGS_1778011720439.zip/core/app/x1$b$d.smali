.class public final Landroidx/core/app/x1$b$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/x1$b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# static fields
.field private static final e:Ljava/lang/String; = "android.wearable.EXTENSIONS"

.field private static final f:Ljava/lang/String; = "flags"

.field private static final g:Ljava/lang/String; = "inProgressLabel"

.field private static final h:Ljava/lang/String; = "confirmLabel"

.field private static final i:Ljava/lang/String; = "cancelLabel"

.field private static final j:I = 0x1

.field private static final k:I = 0x2

.field private static final l:I = 0x4

.field private static final m:I = 0x1


# instance fields
.field private a:I

.field private b:Ljava/lang/CharSequence;

.field private c:Ljava/lang/CharSequence;

.field private d:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroidx/core/app/x1$b;)V
    .locals 4
    .param p1    # Landroidx/core/app/x1$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v0, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v0, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "dasosrb.IerXwneNENdiSTSOaa."

    const-string/jumbo v1, "iTsXNaO.aerSdNbnEwEa.IoSred"

    const/4 v3, 0x6

    const-string v1, "bONmTioNe.e.ESIdaarrwadSXlE"

    const-string v1, "android.wearable.EXTENSIONS"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v1, "lmsgo"

    const-string/jumbo v1, "lgsmf"

    const/4 v3, 0x7

    const-string v1, "blgfa"

    const-string v1, "flags"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v0, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v0, "LesarruesPbnloo"

    const-string v0, "LrseobreloagnPs"

    const/4 v3, 0x6

    const-string/jumbo v0, "nslLeirpgobesaP"

    const-string/jumbo v0, "inProgressLabel"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/core/app/x1$b$d;->b:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v0, "imefLbbrqcoa"

    const-string v0, "abcLrbfomiel"

    const/4 v3, 0x4

    const-string/jumbo v0, "mfsbrlioeaLn"

    const-string v0, "confirmLabel"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Landroidx/core/app/x1$b$d;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v0, "elnmcbuLaae"

    const-string v0, "balelcuanLe"

    const/4 v3, 0x6

    const-string/jumbo v0, "neeboclLlca"

    const-string v0, "cancelLabel"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$b$d;->d:Ljava/lang/CharSequence;

    :cond_0
    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method private l(IZ)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @~~ b ~too d@ @fmb~ @K @ -~~~f@b ~/~~vo.1~@ @@i~@@@r@~y~sl c~i@~~@ioo~ t 4@~anSu@~b  /@o~l M @~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    if-eqz p2, :cond_0

    const/4 v1, 0x3

    iget p2, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    or-int/2addr p1, p2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p1, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iget p2, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    not-int p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    and-int/2addr p1, p2

    const/4 v1, 0x7

    const/4 v0, 0x5

    iput p1, p0, Landroidx/core/app/x1$b$d;->a:I

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(Landroidx/core/app/x1$b$a;)Landroidx/core/app/x1$b$a;
    .locals 5
    .param p1    # Landroidx/core/app/x1$b$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v1, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eq v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "gulsf"

    const-string v2, "gfpls"

    const/4 v4, 0x1

    const-string v2, "agpfs"

    const-string v2, "flags"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$b$d;->b:Ljava/lang/CharSequence;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v2, "lsPrLobiqaseern"

    const/4 v4, 0x1

    const-string/jumbo v2, "rLnsialbqsregoe"

    const-string/jumbo v2, "inProgressLabel"

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$b$d;->c:Ljava/lang/CharSequence;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, "Lfsarlnemsbo"

    const-string v2, "acsnLmorflbe"

    const/4 v4, 0x5

    const-string v2, "confirmLabel"

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_2
    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/core/app/x1$b$d;->d:Ljava/lang/CharSequence;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v2, "lcameLblman"

    const-string v2, "aLlmnecalbc"

    const/4 v4, 0x0

    const-string/jumbo v2, "lalcoeLcneb"

    const-string v2, "cancelLabel"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroidx/core/app/x1$b$a;->g()Landroid/os/Bundle;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v2, "lTiErbEr.aInSOeS.XNdaaoNewb"

    const-string v2, "EaowoeiOI.rnXrS.baNEdNTealS"

    const/4 v4, 0x6

    const-string v2, "bSnrwaueSdTdEaerXiI..lEaNNo"

    const-string v2, "android.wearable.EXTENSIONS"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    return-object p1
.end method

.method public b()Landroidx/core/app/x1$b$d;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Landroidx/core/app/x1$b$d;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Landroidx/core/app/x1$b$d;-><init>()V

    const/4 v3, 0x5

    iget v1, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput v1, v0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$b$d;->b:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v1, v0, Landroidx/core/app/x1$b$d;->b:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$b$d;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v1, v0, Landroidx/core/app/x1$b$d;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$b$d;->d:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    iput-object v1, v0, Landroidx/core/app/x1$b$d;->d:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method

.method public c()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$b$d;->d:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/core/app/x1$b$d;->b()Landroidx/core/app/x1$b$d;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public d()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$b$d;->c:Ljava/lang/CharSequence;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public e()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x4

    const/4 v1, 0x4

    move v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v0, 0x1

    move v1, v0

    move v1, v0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public g()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$b$d;->b:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public h()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Landroidx/core/app/x1$b$d;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v1
.end method

.method public i(Z)Landroidx/core/app/x1$b$d;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$b$d;->l(IZ)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public j(Ljava/lang/CharSequence;)Landroidx/core/app/x1$b$d;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/x1$b$d;->d:Ljava/lang/CharSequence;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p0
.end method

.method public k(Ljava/lang/CharSequence;)Landroidx/core/app/x1$b$d;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/x1$b$d;->c:Ljava/lang/CharSequence;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method public m(Z)Landroidx/core/app/x1$b$d;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$b$d;->l(IZ)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p0
.end method

.method public n(Z)Landroidx/core/app/x1$b$d;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$b$d;->l(IZ)V

    const/4 v2, 0x7

    return-object p0
.end method

.method public o(Ljava/lang/CharSequence;)Landroidx/core/app/x1$b$d;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/x1$b$d;->b:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method
