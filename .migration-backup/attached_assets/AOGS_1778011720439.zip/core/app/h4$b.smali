.class Landroidx/core/app/h4$b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x14
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/h4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    return-void
.end method

.method static a(Ljava/lang/Object;Landroid/content/Intent;Landroid/os/Bundle;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s o~so@@ @m@  /bo i@~ ~@ @tt~ aKyb~~o~@v @~@f@@~- ~ ~Mndl@~ bi@~  .i@~r~~~ /@S@o4@ ~~~f@~oulc~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    check-cast p0, [Landroid/app/RemoteInput;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Landroid/app/RemoteInput;->addResultsToIntent([Landroid/app/RemoteInput;Landroid/content/Intent;Landroid/os/Bundle;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static b(Landroidx/core/app/h4;)Landroid/app/RemoteInput;
    .locals 6

    const/4 v5, 0x6

    new-instance v0, Landroid/app/RemoteInput$Builder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroidx/core/app/h4;->o()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v0, v1}, Landroid/app/RemoteInput$Builder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroidx/core/app/h4;->n()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->setLabel(Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/core/app/h4;->h()[Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->setChoices([Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/core/app/h4;->f()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->setAllowFreeFormInput(Z)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroidx/core/app/h4;->m()Landroid/os/Bundle;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/app/RemoteInput$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/RemoteInput$Builder;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x4

    const/16 v2, 0x1a

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-lt v1, v2, :cond_0

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {p0}, Landroidx/core/app/h4;->g()Ljava/util/Set;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v0, v2, v3}, Landroidx/core/app/h4$c;->d(Landroid/app/RemoteInput$Builder;Ljava/lang/String;Z)Landroid/app/RemoteInput$Builder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/16 v2, 0x1d

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-lt v1, v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroidx/core/app/h4;->k()I

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, p0}, Landroidx/core/app/h4$e;->b(Landroid/app/RemoteInput$Builder;I)Landroid/app/RemoteInput$Builder;

    :cond_1
    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/app/RemoteInput$Builder;->build()Landroid/app/RemoteInput;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object p0
.end method

.method static c(Ljava/lang/Object;)Landroidx/core/app/h4;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    check-cast p0, Landroid/app/RemoteInput;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v0, Landroidx/core/app/h4$f;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getResultKey()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Landroidx/core/app/h4$f;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getLabel()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroidx/core/app/h4$f;->h(Ljava/lang/CharSequence;)Landroidx/core/app/h4$f;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getChoices()[Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroidx/core/app/h4$f;->f([Ljava/lang/CharSequence;)Landroidx/core/app/h4$f;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getAllowFreeFormInput()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroidx/core/app/h4$f;->e(Z)Landroidx/core/app/h4$f;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getExtras()Landroid/os/Bundle;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroidx/core/app/h4$f;->a(Landroid/os/Bundle;)Landroidx/core/app/h4$f;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/16 v2, 0x1a

    const/4 v5, 0x4

    if-lt v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p0}, Landroidx/core/app/h4$c;->b(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v2, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v3}, Landroidx/core/app/h4$f;->d(Ljava/lang/String;Z)Landroidx/core/app/h4$f;

    const/4 v5, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v2, 0x1d

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-lt v1, v2, :cond_1

    const/4 v4, 0x4

    or-int/2addr v5, v4

    invoke-static {p0}, Landroidx/core/app/h4$e;->a(Ljava/lang/Object;)I

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, p0}, Landroidx/core/app/h4$f;->g(I)Landroidx/core/app/h4$f;

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroidx/core/app/h4$f;->b()Landroidx/core/app/h4;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    return-object p0
.end method

.method static d(Landroid/content/Intent;)Landroid/os/Bundle;
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0}, Landroid/app/RemoteInput;->getResultsFromIntent(Landroid/content/Intent;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method
