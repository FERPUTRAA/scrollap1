.class public Landroidx/core/app/f4$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/f4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field a:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field b:Landroidx/core/graphics/drawable/IconCompat;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field c:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field d:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field e:Z

.field f:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method constructor <init>(Landroidx/core/app/f4;)V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    iget-object v0, p1, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    move v2, v1

    iput-object v0, p0, Landroidx/core/app/f4$c;->a:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p1, Landroidx/core/app/f4;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/f4$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p1, Landroidx/core/app/f4;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/core/app/f4$c;->c:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p1, Landroidx/core/app/f4;->d:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Landroidx/core/app/f4$c;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p1, Landroidx/core/app/f4;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Landroidx/core/app/f4$c;->e:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean p1, p1, Landroidx/core/app/f4;->f:Z

    const/4 v1, 0x6

    move v2, v1

    iput-boolean p1, p0, Landroidx/core/app/f4$c;->f:Z

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()Landroidx/core/app/f4;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@sm@~/s/i@4 y t ~ uo-1.~n@b~@t~~@ioof~~a i@~@ bd@~v ~   @@~@~@b@@or~@@~~ f @~M oo~~l~ K cS  @~l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    new-instance v0, Landroidx/core/app/f4;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Landroidx/core/app/f4;-><init>(Landroidx/core/app/f4$c;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public b(Z)Landroidx/core/app/f4$c;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/core/app/f4$c;->e:Z

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method public c(Landroidx/core/graphics/drawable/IconCompat;)Landroidx/core/app/f4$c;
    .locals 2
    .param p1    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/f4$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method public d(Z)Landroidx/core/app/f4$c;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/core/app/f4$c;->f:Z

    const/4 v1, 0x4

    return-object p0
.end method

.method public e(Ljava/lang/String;)Landroidx/core/app/f4$c;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/f4$c;->d:Ljava/lang/String;

    const/4 v1, 0x4

    return-object p0
.end method

.method public f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/f4$c;->a:Ljava/lang/CharSequence;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p0
.end method

.method public g(Ljava/lang/String;)Landroidx/core/app/f4$c;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/f4$c;->c:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method
