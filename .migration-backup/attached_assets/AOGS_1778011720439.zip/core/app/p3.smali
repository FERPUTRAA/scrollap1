.class public final synthetic Landroidx/core/app/p3;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationManager;Ljava/util/List;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " as~  it@  /@o~i@ y~t@li r~@/m~~4 ~@dvb @l~@  1 ~c~ ou~o~ ~@ n@@@@o~@@o-M~~K.~of@@~fs@~~@~S@ b ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1}, Landroid/app/NotificationManager;->createNotificationChannels(Ljava/util/List;)V

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
