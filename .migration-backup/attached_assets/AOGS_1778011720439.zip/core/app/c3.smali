.class public final synthetic Landroidx/core/app/c3;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s @ id  @af~ / @o~rvmo@@~ ~~ ~b~@4~sM~~~@~cy@ @n  K ~S~@b@toi~~@o~t ~@u @i@l 1@~@lf .ob~@o~-~/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Landroid/app/Notification$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method
