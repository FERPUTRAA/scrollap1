.class public Landroidx/core/app/x1;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/x1$f;,
        Landroidx/core/app/x1$h;,
        Landroidx/core/app/x1$r;,
        Landroidx/core/app/x1$j;,
        Landroidx/core/app/x1$b;,
        Landroidx/core/app/x1$i;,
        Landroidx/core/app/x1$l;,
        Landroidx/core/app/x1$m;,
        Landroidx/core/app/x1$e;,
        Landroidx/core/app/x1$d;,
        Landroidx/core/app/x1$q;,
        Landroidx/core/app/x1$g;,
        Landroidx/core/app/x1$o;,
        Landroidx/core/app/x1$k;,
        Landroidx/core/app/x1$c;,
        Landroidx/core/app/x1$n;,
        Landroidx/core/app/x1$p;
    }
.end annotation


# static fields
.field public static final A:Ljava/lang/String; = "android.title"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final A0:Ljava/lang/String; = "sys"

.field public static final B:Ljava/lang/String; = "android.title.big"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final B0:Ljava/lang/String; = "service"

.field public static final C:Ljava/lang/String; = "android.text"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final C0:Ljava/lang/String; = "reminder"

.field public static final D:Ljava/lang/String; = "android.subText"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final D0:Ljava/lang/String; = "recommendation"

.field public static final E:Ljava/lang/String; = "android.remoteInputHistory"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final E0:Ljava/lang/String; = "status"

.field public static final F:Ljava/lang/String; = "android.infoText"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final F0:Ljava/lang/String; = "workout"

.field public static final G:Ljava/lang/String; = "android.summaryText"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final G0:Ljava/lang/String; = "location_sharing"

.field public static final H:Ljava/lang/String; = "android.bigText"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final H0:Ljava/lang/String; = "stopwatch"

.field public static final I:Ljava/lang/String; = "android.icon"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final I0:Ljava/lang/String; = "missed_call"

.field public static final J:Ljava/lang/String; = "android.largeIcon"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final J0:I = 0x0

.field public static final K:Ljava/lang/String; = "android.largeIcon.big"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final K0:I = 0x1

.field public static final L:Ljava/lang/String; = "android.progress"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final L0:I = 0x2

.field public static final M:Ljava/lang/String; = "android.progressMax"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final M0:I = 0x0

.field public static final N:Ljava/lang/String; = "android.progressIndeterminate"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final N0:I = 0x1

.field public static final O:Ljava/lang/String; = "android.showChronometer"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final O0:I = 0x2

.field public static final P:Ljava/lang/String; = "android.chronometerCountDown"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final P0:Ljava/lang/String; = "silent"

.field public static final Q:Ljava/lang/String; = "android.colorized"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final Q0:I = 0x0

.field public static final R:Ljava/lang/String; = "android.showWhen"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final R0:I = 0x1

.field public static final S:Ljava/lang/String; = "android.picture"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final S0:I = 0x2

.field public static final T:Ljava/lang/String; = "android.pictureContentDescription"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final U:Ljava/lang/String; = "android.showBigPictureWhenCollapsed"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final V:Ljava/lang/String; = "android.textLines"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final W:Ljava/lang/String; = "android.template"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final X:Ljava/lang/String; = "androidx.core.app.extra.COMPAT_TEMPLATE"

.field public static final Y:Ljava/lang/String; = "android.people"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final Z:Ljava/lang/String; = "android.people.list"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final a:Ljava/lang/String; = "android.intent.category.NOTIFICATION_PREFERENCES"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final a0:Ljava/lang/String; = "android.backgroundImageUri"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "android.intent.extra.CHANNEL_ID"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final b0:Ljava/lang/String; = "android.mediaSession"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "android.intent.extra.CHANNEL_GROUP_ID"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final c0:Ljava/lang/String; = "android.compactActions"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "android.intent.extra.NOTIFICATION_TAG"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final d0:Ljava/lang/String; = "android.selfDisplayName"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final e:Ljava/lang/String; = "android.intent.extra.NOTIFICATION_ID"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final e0:Ljava/lang/String; = "android.messagingStyleUser"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final f:I = -0x1

.field public static final f0:Ljava/lang/String; = "android.conversationTitle"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final g:I = 0x1

.field public static final g0:Ljava/lang/String; = "android.messages"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final h:I = 0x2

.field public static final h0:Ljava/lang/String; = "android.messages.historic"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final i:I = 0x4

.field public static final i0:Ljava/lang/String; = "android.isGroupConversation"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final j:I = -0x1

.field public static final j0:Ljava/lang/String; = "android.hiddenConversationTitle"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final k:I = 0x1

.field public static final k0:Ljava/lang/String; = "android.audioContents"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final l:I = 0x2

.field public static final l0:I = 0x0
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field public static final m:I = 0x4

.field public static final m0:I = 0x1

.field public static final n:I = 0x8

.field public static final n0:I = 0x0

.field public static final o:I = 0x10

.field public static final o0:I = -0x1

.field public static final p:I = 0x20

.field public static final p0:Ljava/lang/String; = "call"

.field public static final q:I = 0x40

.field public static final q0:Ljava/lang/String; = "navigation"

.field public static final r:I = 0x80
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final r0:Ljava/lang/String; = "msg"

.field public static final s:I = 0x100

.field public static final s0:Ljava/lang/String; = "email"

.field public static final t:I = 0x200

.field public static final t0:Ljava/lang/String; = "event"

.field public static final u:I = 0x1000

.field public static final u0:Ljava/lang/String; = "promo"

.field public static final v:I = 0x0

.field public static final v0:Ljava/lang/String; = "alarm"

.field public static final w:I = -0x1

.field public static final w0:Ljava/lang/String; = "progress"

.field public static final x:I = -0x2

.field public static final x0:Ljava/lang/String; = "social"

.field public static final y:I = 0x1

.field public static final y0:Ljava/lang/String; = "err"

.field public static final z:I = 0x2

.field public static final z0:Ljava/lang/String; = "transport"


# direct methods
.method public constructor <init>()V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static A(Landroid/app/Notification;)Ljava/lang/String;
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~fs~-~l t~@u1s ~S o ~o@.a~@~ @~@ b @n@@M~dy @ @/b~m@~~@@~~ ~i~o@~o~ Kl@ o@o @c i r @it@~4/@vbf~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x1a

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/core/app/p1;->a(Landroid/app/Notification;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0
.end method

.method public static B(Landroid/app/Notification;)Z
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "rw.mdohanesioWnh"

    const-string v0, "a.shrsWdwienohon"

    const/4 v2, 0x4

    const-string v0, "eiWwohno.rhodand"

    const-string v0, "android.showWhen"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p0
.end method

.method public static C(Landroid/app/Notification;)Ljava/lang/String;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-virtual {p0}, Landroid/app/Notification;->getSortKey()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public static D(Landroid/app/Notification;)Ljava/lang/CharSequence;
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v2, 0x0

    const-string/jumbo v0, "somdab.uxbTneti"

    const-string/jumbo v0, "raumniTxoedbt.s"

    const/4 v2, 0x7

    const-string v0, "ati.dxubTsreudn"

    const-string v0, "android.subText"

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public static E(Landroid/app/Notification;)J
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v1, 0x1a

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0}, Landroidx/core/app/n1;->a(Landroid/app/Notification;)J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-wide v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-wide v0
.end method

.method public static F(Landroid/app/Notification;)Z
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x2

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "nnedomar.witCoorhsedoro"

    const/4 v2, 0x7

    const-string v0, "erhsrawpnddCohmn.roeioo"

    const-string v0, "android.showChronometer"

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p0
.end method

.method public static G(Landroid/app/Notification;)I
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget p0, p0, Landroid/app/Notification;->visibility:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method public static H(Landroid/app/Notification;)Z
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget p0, p0, Landroid/app/Notification;->flags:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    and-int/lit16 p0, p0, 0x200

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 p0, 0x4

    const/4 v1, 0x4

    const/4 p0, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    move v1, v0

    const/4 p0, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p0
.end method

.method public static a(Landroid/app/Notification;I)Landroidx/core/app/x1$b;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    iget-object p0, p0, Landroid/app/Notification;->actions:[Landroid/app/Notification$Action;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    aget-object p0, p0, p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p0}, Landroidx/core/app/x1;->b(Landroid/app/Notification$Action;)Landroidx/core/app/x1$b;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method static b(Landroid/app/Notification$Action;)Landroidx/core/app/x1$b;
    .locals 19
    .param p0    # Landroid/app/Notification$Action;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x14
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getRemoteInputs()[Landroid/app/RemoteInput;

    move-result-object v1

    const/16 v2, 0x1d

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez v1, :cond_0

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    goto :goto_2

    :cond_0
    array-length v5, v1

    new-array v5, v5, [Landroidx/core/app/h4;

    move v6, v4

    move v6, v4

    move v6, v4

    :goto_0
    array-length v7, v1

    if-ge v6, v7, :cond_2

    aget-object v7, v1, v6

    new-instance v16, Landroidx/core/app/h4;

    invoke-virtual {v7}, Landroid/app/RemoteInput;->getResultKey()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v7}, Landroid/app/RemoteInput;->getLabel()Ljava/lang/CharSequence;

    move-result-object v10

    invoke-virtual {v7}, Landroid/app/RemoteInput;->getChoices()[Ljava/lang/CharSequence;

    move-result-object v11

    invoke-virtual {v7}, Landroid/app/RemoteInput;->getAllowFreeFormInput()Z

    move-result v12

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v8, v2, :cond_1

    invoke-static {v7}, Landroidx/core/app/u1;->a(Landroid/app/RemoteInput;)I

    move-result v8

    move v13, v8

    move v13, v8

    goto :goto_1

    :cond_1
    move v13, v4

    move v13, v4

    move v13, v4

    :goto_1
    invoke-virtual {v7}, Landroid/app/RemoteInput;->getExtras()Landroid/os/Bundle;

    move-result-object v14

    const/4 v15, 0x0

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    invoke-direct/range {v8 .. v15}, Landroidx/core/app/h4;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZILandroid/os/Bundle;Ljava/util/Set;)V

    aput-object v16, v5, v6

    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_2
    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    :goto_2
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x18

    const-string/jumbo v6, "pdnnGdstqeiRawdleborp.eaaoelrlpuries."

    const-string/jumbo v6, "laeeebnlrrisuoaoGprdps.oedawidtR.penl"

    const-string/jumbo v6, "ldsoll.t.ieeutirnoppsrsepanoaeawedRrd"

    const-string v6, "android.support.allowGeneratedReplies"

    const/4 v7, 0x1

    if-lt v1, v5, :cond_5

    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getExtras()Landroid/os/Bundle;

    move-result-object v5

    invoke-virtual {v5, v6}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_4

    invoke-static/range {p0 .. p0}, Landroidx/core/app/v1;->a(Landroid/app/Notification$Action;)Z

    move-result v5

    if-eqz v5, :cond_3

    goto :goto_3

    :cond_3
    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    goto :goto_4

    :cond_4
    :goto_3
    move v5, v7

    move v5, v7

    move v5, v7

    move v5, v7

    goto :goto_4

    :cond_5
    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getExtras()Landroid/os/Bundle;

    move-result-object v5

    invoke-virtual {v5, v6}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    :goto_4
    move v14, v5

    move v14, v5

    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getExtras()Landroid/os/Bundle;

    move-result-object v5

    const-string/jumbo v6, "wdomr.hsins.sprnrauptueidaIercot.nfaoctoe"

    const-string v6, "ItrUtdu.osrrpaonidrcshctnafeen.aou.iwspoe"

    const-string/jumbo v6, "sreooaotecsonfrtpwdrsnhptaUcoI.snua.erd.i"

    const-string v6, "android.support.action.showsUserInterface"

    invoke-virtual {v5, v6, v7}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v16

    const/16 v5, 0x1c

    if-lt v1, v5, :cond_6

    invoke-static/range {p0 .. p0}, Landroidx/core/app/w1;->a(Landroid/app/Notification$Action;)I

    move-result v5

    goto :goto_5

    :cond_6
    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getExtras()Landroid/os/Bundle;

    move-result-object v5

    const-string/jumbo v6, "nAttpbaa.sccoo.iprrtepunmtonianc.osdi"

    const-string v6, "csimrs.pirpoutot.iotcepa.Adnninacnato"

    const-string/jumbo v6, "rt.ctsunnAaodaooeutpct..aoirsicdpniim"

    const-string v6, "android.support.action.semanticAction"

    invoke-virtual {v5, v6, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v5

    :goto_5
    move v15, v5

    move v15, v5

    move v15, v5

    if-lt v1, v2, :cond_7

    invoke-static/range {p0 .. p0}, Landroidx/core/app/j1;->a(Landroid/app/Notification$Action;)Z

    move-result v2

    move/from16 v17, v2

    move/from16 v17, v2

    move/from16 v17, v2

    goto :goto_6

    :cond_7
    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    :goto_6
    const/16 v2, 0x1f

    if-lt v1, v2, :cond_8

    invoke-static/range {p0 .. p0}, Landroidx/core/app/k1;->a(Landroid/app/Notification$Action;)Z

    move-result v4

    :cond_8
    move/from16 v18, v4

    move/from16 v18, v4

    move/from16 v18, v4

    move/from16 v18, v4

    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getIcon()Landroid/graphics/drawable/Icon;

    move-result-object v1

    if-nez v1, :cond_9

    iget v8, v0, Landroid/app/Notification$Action;->icon:I

    if-eqz v8, :cond_9

    new-instance v1, Landroidx/core/app/x1$b;

    iget-object v9, v0, Landroid/app/Notification$Action;->title:Ljava/lang/CharSequence;

    iget-object v10, v0, Landroid/app/Notification$Action;->actionIntent:Landroid/app/PendingIntent;

    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getExtras()Landroid/os/Bundle;

    move-result-object v11

    const/4 v13, 0x0

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    invoke-direct/range {v7 .. v18}, Landroidx/core/app/x1$b;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V

    return-object v1

    :cond_9
    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getIcon()Landroid/graphics/drawable/Icon;

    move-result-object v1

    if-nez v1, :cond_a

    goto :goto_7

    :cond_a
    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getIcon()Landroid/graphics/drawable/Icon;

    move-result-object v1

    invoke-static {v1}, Landroidx/core/graphics/drawable/IconCompat;->o(Landroid/graphics/drawable/Icon;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v3

    :goto_7
    move-object v8, v3

    move-object v8, v3

    move-object v8, v3

    move-object v8, v3

    new-instance v1, Landroidx/core/app/x1$b;

    iget-object v9, v0, Landroid/app/Notification$Action;->title:Ljava/lang/CharSequence;

    iget-object v10, v0, Landroid/app/Notification$Action;->actionIntent:Landroid/app/PendingIntent;

    invoke-virtual/range {p0 .. p0}, Landroid/app/Notification$Action;->getExtras()Landroid/os/Bundle;

    move-result-object v11

    const/4 v13, 0x0

    move-object v7, v1

    invoke-direct/range {v7 .. v18}, Landroidx/core/app/x1$b;-><init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V

    return-object v1
.end method

.method public static c(Landroid/app/Notification;)I
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget-object p0, p0, Landroid/app/Notification;->actions:[Landroid/app/Notification$Action;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    array-length p0, p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 p0, 0x0

    const/4 v1, 0x0

    move v0, p0

    move v0, p0

    :goto_0
    const/4 v1, 0x0

    return p0
.end method

.method public static d(Landroid/app/Notification;)Z
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v1, 0x1d

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/app/i1;->a(Landroid/app/Notification;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p0

    :cond_0
    const/4 v3, 0x6

    const/4 p0, 0x7

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return p0
.end method

.method public static e(Landroid/app/Notification;)Z
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget p0, p0, Landroid/app/Notification;->flags:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    and-int/lit8 p0, p0, 0x10

    const/4 v1, 0x5

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 p0, 0x2

    const/4 p0, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v0, 0x2

    return p0
.end method

.method public static f(Landroid/app/Notification;)I
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/16 v1, 0x1a

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/app/l1;->a(Landroid/app/Notification;)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    return p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p0
.end method

.method public static g(Landroid/app/Notification;)Landroidx/core/app/x1$f;
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0x1d

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0}, Landroidx/core/app/q1;->a(Landroid/app/Notification;)Landroid/app/Notification$BubbleMetadata;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/app/x1$f;->a(Landroid/app/Notification$BubbleMetadata;)Landroidx/core/app/x1$f;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0
.end method

.method public static h(Landroid/app/Notification;)Ljava/lang/String;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p0, p0, Landroid/app/Notification;->category:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p0
.end method

.method public static i(Landroid/app/Notification;)Ljava/lang/String;
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/16 v1, 0x1a

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/app/t1;->a(Landroid/app/Notification;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    return-object p0
.end method

.method public static j(Landroid/app/Notification;)I
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p0, p0, Landroid/app/Notification;->color:I

    const/4 v1, 0x6

    return p0
.end method

.method public static k(Landroid/app/Notification;)Ljava/lang/CharSequence;
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, ".andfoTpoxreiqin"

    const-string/jumbo v0, "xfnotTinqo.eradi"

    const/4 v2, 0x3

    const-string/jumbo v0, "neridodtqnaT.fix"

    const-string v0, "android.infoText"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public static l(Landroid/app/Notification;)Ljava/lang/CharSequence;
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const-string/jumbo v0, "t.ssaoxrdnid"

    const-string v0, "disexr.doant"

    const-string/jumbo v0, "tixmdd.atone"

    const-string v0, "android.text"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static m(Landroid/app/Notification;)Ljava/lang/CharSequence;
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x13
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v2, 0x4

    const-string v0, ".ltmdendraoti"

    const/4 v2, 0x3

    const-string/jumbo v0, "oltnoiirded.t"

    const-string v0, "android.title"

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static n(Landroid/app/Notification;)Landroid/os/Bundle;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method public static o(Landroid/app/Notification;)Ljava/lang/String;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/app/Notification;->getGroup()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public static p(Landroid/app/Notification;)I
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 v1, 0x1a

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/app/r1;->a(Landroid/app/Notification;)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x2

    return p0
.end method

.method static q(Landroid/app/Notification;)Z
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget p0, p0, Landroid/app/Notification;->flags:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    and-int/lit16 p0, p0, 0x80

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p0, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x2

    move v0, p0

    move v0, p0

    :goto_0
    return p0
.end method

.method public static r(Landroid/app/Notification;)Ljava/util/List;
    .locals 5
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Notification;",
            ")",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$b;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "rSdXodr.aSiIEcTEoNa.nN"

    const/4 v4, 0x5

    const-string/jumbo v1, "oIErabcXSEnad.d.ONrSTi"

    const-string v1, "android.car.EXTENSIONS"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x2

    move v4, v3

    return-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const-string v1, "coiastusvnlii_bib"

    const-string/jumbo v1, "nlsiib_bnstvioaci"

    const/4 v4, 0x6

    const-string v1, "ailntnspobcseviii"

    const-string/jumbo v1, "invisible_actions"

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/os/BaseBundle;->size()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-ge v1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v2}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v2}, Landroidx/core/app/o3;->g(Landroid/os/Bundle;)Landroidx/core/app/x1$b;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v0
.end method

.method public static s(Landroid/app/Notification;)Z
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget p0, p0, Landroid/app/Notification;->flags:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    and-int/lit16 p0, p0, 0x100

    const/4 v0, 0x6

    or-int/2addr v1, v0

    if-eqz p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p0
.end method

.method public static t(Landroid/app/Notification;)Landroidx/core/content/g;
    .locals 5
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x3

    move v4, v3

    const/16 v1, 0x1d

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x7

    if-lt v0, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p0}, Landroidx/core/app/o1;->a(Landroid/app/Notification;)Landroid/content/LocusId;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p0}, Landroidx/core/content/g;->d(Landroid/content/LocusId;)Landroidx/core/content/g;

    move-result-object v2

    :cond_1
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v2
.end method

.method static u(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/app/Notification;
    .locals 6
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getParcelableArray(Ljava/lang/String;)[Landroid/os/Parcelable;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    instance-of v1, v0, [Landroid/app/Notification;

    const/4 v5, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x7

    or-int/2addr v5, v4

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    array-length v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-array v1, v1, [Landroid/app/Notification;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    array-length v3, v0

    const/4 v5, 0x0

    if-ge v2, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    aget-object v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v3, Landroid/app/Notification;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    aput-object v3, v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x6

    or-int/2addr v5, v4

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    invoke-virtual {p0, p1, v1}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v1

    :cond_2
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast v0, [Landroid/app/Notification;

    const/4 v5, 0x1

    return-object v0
.end method

.method public static v(Landroid/app/Notification;)Z
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iget p0, p0, Landroid/app/Notification;->flags:I

    const/4 v0, 0x7

    const/4 v1, 0x6

    and-int/lit8 p0, p0, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    const/4 p0, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 p0, 0x1

    const/4 p0, 0x0

    move v1, p0

    :goto_0
    const/4 v0, 0x1

    move v1, v0

    return p0
.end method

.method public static w(Landroid/app/Notification;)Z
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget p0, p0, Landroid/app/Notification;->flags:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    and-int/lit8 p0, p0, 0x8

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p0, 0x1

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p0
.end method

.method public static x(Landroid/app/Notification;)Ljava/util/List;
    .locals 7
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/app/Notification;",
            ")",
            "Ljava/util/List<",
            "Landroidx/core/app/f4;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/16 v2, 0x1c

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-lt v1, v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v1, ".oestedaql.dliornup"

    const-string/jumbo v1, "iidot.und.alleoepsr"

    const/4 v6, 0x6

    const-string v1, ".lsso.piraiteddepln"

    const-string v1, "android.people.list"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz p0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v1}, Landroidx/core/app/m1;->a(Ljava/lang/Object;)Landroid/app/Person;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-static {v1}, Landroidx/core/app/f4;->a(Landroid/app/Person;)Landroidx/core/app/f4;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object p0, p0, Landroid/app/Notification;->extras:Landroid/os/Bundle;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v1, "raimoep.plnepd"

    const-string v1, "dl.pidapeeronp"

    const/4 v6, 0x7

    const-string/jumbo v1, "oeldodepo.ipnr"

    const-string v1, "android.people"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getStringArray(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz p0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    array-length v1, p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    move v6, v5

    array-length v1, p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ge v2, v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    aget-object v3, p0, v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v4, Landroidx/core/app/f4$c;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v4}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-virtual {v4, v3}, Landroidx/core/app/f4$c;->g(Ljava/lang/String;)Landroidx/core/app/f4$c;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object v0
.end method

.method public static y(Landroid/app/Notification;)Landroid/app/Notification;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Landroid/app/Notification;->publicVersion:Landroid/app/Notification;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static z(Landroid/app/Notification;)Ljava/lang/CharSequence;
    .locals 4
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/16 v1, 0x1a

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/app/s1;->a(Landroid/app/Notification;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0
.end method
