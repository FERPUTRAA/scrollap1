.class final Landroidx/core/app/JobIntentService$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/JobIntentService$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "d"
.end annotation


# instance fields
.field final a:Landroid/content/Intent;

.field final b:I

.field final synthetic c:Landroidx/core/app/JobIntentService;


# direct methods
.method constructor <init>(Landroidx/core/app/JobIntentService;Landroid/content/Intent;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/JobIntentService$d;->c:Landroidx/core/app/JobIntentService;

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p2, p0, Landroidx/core/app/JobIntentService$d;->a:Landroid/content/Intent;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p3, p0, Landroidx/core/app/JobIntentService$d;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s. @b@@@@ @y4 oim~~t v@d@- @i@~f~~@o b  @o~@crl~s~S@o~ ~@i~/@  ~o~u~~~f@ ~ol~a@ n M@bK ~~@t/~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/core/app/JobIntentService$d;->c:Landroidx/core/app/JobIntentService;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v1, p0, Landroidx/core/app/JobIntentService$d;->b:I

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0, v1}, Landroid/app/Service;->stopSelf(I)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/JobIntentService$d;->a:Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method
