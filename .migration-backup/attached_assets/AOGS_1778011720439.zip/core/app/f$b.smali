.class Landroidx/core/app/f$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/app/f;->i(Landroid/app/Activity;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/app/Application;

.field final synthetic b:Landroidx/core/app/f$d;


# direct methods
.method constructor <init>(Landroid/app/Application;Landroidx/core/app/f$d;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/core/app/f$b;->a:Landroid/app/Application;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Landroidx/core/app/f$b;->b:Landroidx/core/app/f$d;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~sSot@ @~s~@ @- yi4~@ @ /~@o. bb ou~ ~   ~@tl~Molm~/c@@~i~~~ @d~~@f~@@b in a@vK f~@r~1~@@o~~ @ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/f$b;->a:Landroid/app/Application;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/f$b;->b:Landroidx/core/app/f$d;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/app/Application;->unregisterActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method
