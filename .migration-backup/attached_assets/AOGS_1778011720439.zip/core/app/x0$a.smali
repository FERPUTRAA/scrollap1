.class public Landroidx/core/app/x0$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/core/app/x0;


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance v0, Landroidx/core/app/x0;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0, p1, p2}, Landroidx/core/app/x0;-><init>(Ljava/lang/String;I)V

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public a()Landroidx/core/app/x0;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "ois@ s~o~@@~~ b@ co ~ /~ @-~ 1b/ n@ @@~4ou@ lK~@y@Mto  a~@r@ @~ @~~~doi@tvl f .~ b~S~~@i@~@~~m~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public b(Ljava/lang/String;Ljava/lang/String;)Landroidx/core/app/x0$a;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v1, 0x1e

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v3, 0x3

    const/4 v2, 0x4

    iput-object p1, v0, Landroidx/core/app/x0;->m:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object p2, v0, Landroidx/core/app/x0;->n:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x7

    return-object p0
.end method

.method public c(Ljava/lang/String;)Landroidx/core/app/x0$a;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, v0, Landroidx/core/app/x0;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public d(Ljava/lang/String;)Landroidx/core/app/x0$a;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x1

    const/4 v1, 0x3

    iput-object p1, v0, Landroidx/core/app/x0;->e:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0
.end method

.method public e(I)Landroidx/core/app/x0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p1, v0, Landroidx/core/app/x0;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public f(I)Landroidx/core/app/x0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p1, v0, Landroidx/core/app/x0;->j:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public g(Z)Landroidx/core/app/x0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-boolean p1, v0, Landroidx/core/app/x0;->i:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public h(Ljava/lang/CharSequence;)Landroidx/core/app/x0$a;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, v0, Landroidx/core/app/x0;->b:Ljava/lang/CharSequence;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public i(Z)Landroidx/core/app/x0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean p1, v0, Landroidx/core/app/x0;->f:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    return-object p0
.end method

.method public j(Landroid/net/Uri;Landroid/media/AudioAttributes;)Landroidx/core/app/x0$a;
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/media/AudioAttributes;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, v0, Landroidx/core/app/x0;->g:Landroid/net/Uri;

    const/4 v1, 0x4

    move v2, v1

    iput-object p2, v0, Landroidx/core/app/x0;->h:Landroid/media/AudioAttributes;

    const/4 v2, 0x4

    return-object p0
.end method

.method public k(Z)Landroidx/core/app/x0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-boolean p1, v0, Landroidx/core/app/x0;->k:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public l([J)Landroidx/core/app/x0$a;
    .locals 4
    .param p1    # [J
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/x0$a;->a:Landroidx/core/app/x0;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    array-length v1, p1

    const/4 v2, 0x7

    move v3, v2

    if-lez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-boolean v1, v0, Landroidx/core/app/x0;->k:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object p1, v0, Landroidx/core/app/x0;->l:[J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0
.end method
