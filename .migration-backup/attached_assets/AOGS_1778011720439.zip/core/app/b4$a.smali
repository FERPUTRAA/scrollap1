.class Landroidx/core/app/b4$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/b4$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/b4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field final a:Ljava/lang/String;

.field final b:I

.field final c:Ljava/lang/String;

.field final d:Z


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/core/app/b4$a;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Landroidx/core/app/b4$a;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/b4$a;->c:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p1, p0, Landroidx/core/app/b4$a;->d:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    return-void
.end method

.method constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/b4$a;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p2, p0, Landroidx/core/app/b4$a;->b:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p3, p0, Landroidx/core/app/b4$a;->c:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v0, 0x2

    move v1, v0

    iput-boolean p1, p0, Landroidx/core/app/b4$a;->d:Z

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v4/app/INotificationSideChannel;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  s~~@  Mb~c@o~tb ~i @@l/@mr s~@ou~a~~~o@ ~n ~ /-@i  @~.@o1b~~~d otl~~o@S~@v  f~~4 @@@i@@f@ K@y~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-boolean v0, p0, Landroidx/core/app/b4$a;->d:Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/core/app/b4$a;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Landroid/support/v4/app/INotificationSideChannel;->cancelAll(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/core/app/b4$a;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Landroidx/core/app/b4$a;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v2, p0, Landroidx/core/app/b4$a;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {p1, v0, v1, v2}, Landroid/support/v4/app/INotificationSideChannel;->cancel(Ljava/lang/String;ILjava/lang/String;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const-string v1, "aCTmesknlac"

    const-string v1, "CancelTask["

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "gase:cemNapk"

    const/4 v3, 0x1

    const-string/jumbo v1, "packageName:"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/core/app/b4$a;->a:Ljava/lang/String;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v1, "im: o"

    const-string v1, ",i:m "

    const/4 v3, 0x2

    const-string v1, "b, i:"

    const-string v1, ", id:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v1, p0, Landroidx/core/app/b4$a;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    move v3, v2

    const-string/jumbo v1, "ut,ago"

    const-string v1, "a:tgo,"

    const/4 v3, 0x0

    const-string v1, "gpat :"

    const-string v1, ", tag:"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/core/app/b4$a;->c:Ljava/lang/String;

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, " lqa:l"

    const-string v1, ":ll ab"

    const/4 v3, 0x4

    const-string v1, ",ls l:"

    const-string v1, ", all:"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-boolean v1, p0, Landroidx/core/app/b4$a;->d:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-string v1, "]"

    const-string v1, "]"

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method
