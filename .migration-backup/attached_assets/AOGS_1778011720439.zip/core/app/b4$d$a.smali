.class Landroidx/core/app/b4$d$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/b4$d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field final a:Landroid/content/ComponentName;

.field b:Z

.field c:Landroid/support/v4/app/INotificationSideChannel;

.field d:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Landroidx/core/app/b4$e;",
            ">;"
        }
    .end annotation
.end field

.field e:I


# direct methods
.method constructor <init>(Landroid/content/ComponentName;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    move v3, v2

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-boolean v0, p0, Landroidx/core/app/b4$d$a;->b:Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Ljava/util/ArrayDeque;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/util/ArrayDeque;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v1, p0, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput v0, p0, Landroidx/core/app/b4$d$a;->e:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p1, p0, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method
