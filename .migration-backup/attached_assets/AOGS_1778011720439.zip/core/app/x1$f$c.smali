.class public final Landroidx/core/app/x1$f$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1$f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field private a:Landroid/app/PendingIntent;

.field private b:Landroidx/core/graphics/drawable/IconCompat;

.field private c:I

.field private d:I
    .annotation build Landroidx/annotation/q;
    .end annotation
.end field

.field private e:I

.field private f:Landroid/app/PendingIntent;

.field private g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/app/PendingIntent;Landroidx/core/graphics/drawable/IconCompat;)V
    .locals 2
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-eqz p1, :cond_1

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$f$c;->a:Landroid/app/PendingIntent;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Landroidx/core/app/x1$f$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void

    :cond_0
    const/4 v0, 0x2

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    const-string p2, "ensBeniuuc bronni-bsqour l ls"

    const-string/jumbo p2, "rusnliu leocbq esnuinr Bl-nbo"

    const/4 v1, 0x0

    const-string p2, "Bubbles require non-null icon"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    throw p1

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string p2, "dnum lu meip re gqnnluls-eberbttneniBoi"

    const-string p2, "-ptmnsue  ugulenn rnelnqebb oiiBnitlred"

    const/4 v1, 0x6

    const-string/jumbo p2, "nn-po nii iebnnrnboe Blgteluuulsdteeqrn"

    const-string p2, "Bubble requires non-null pending intent"

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    throw p1
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1e
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    iput-object p1, p0, Landroidx/core/app/x1$f$c;->g:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "n serblqnucBr eaoltruiub hbid- oes lnu"

    const-string/jumbo v0, "lcBro rou a ud-tbbsnnluiu qihn eoeeslr"

    const/4 v2, 0x1

    const-string/jumbo v0, "iltbaeu lruunl no udsoi-q nBe surhectr"

    const-string v0, "Bubble requires a non-null shortcut id"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    throw p1
.end method

.method private f(IZ)Landroidx/core/app/x1$f$c;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@~~lb~pa b~~~m ~ @ 4t@s-~ ~~S~bi1@@@ no @~@t@/@  ~  o~~i~ @M ~o @i~l@K@ c /~@@ovf@~~@.d@u ro~oy"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    if-eqz p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget p2, p0, Landroidx/core/app/x1$f$c;->e:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    or-int/2addr p1, p2

    const/4 v1, 0x1

    const/4 v0, 0x7

    iput p1, p0, Landroidx/core/app/x1$f$c;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget p2, p0, Landroidx/core/app/x1$f$c;->e:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    not-int p1, p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    and-int/2addr p1, p2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Landroidx/core/app/x1$f$c;->e:I

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p0
.end method


# virtual methods
.method public a()Landroidx/core/app/x1$f;
    .locals 12
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "SyntheticAccessor"
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object v7, p0, Landroidx/core/app/x1$f$c;->g:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-nez v7, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$f$c;->a:Landroid/app/PendingIntent;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-eqz v0, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    goto :goto_0

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string v1, "cMeboiynq gb ie uhurnrslt esopbtpp  unttton stbl"

    const-string/jumbo v1, "s obibptle etnlirMetnn gpttunoo  rusph yu sbbutc"

    const/4 v11, 0x0

    const-string/jumbo v1, "utsts eeyblopr uuM spietp n iosh nbrucolnttd gnb"

    const-string v1, "Must supply pending intent or shortcut to bubble"

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    throw v0

    :cond_1
    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x1

    if-nez v7, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$f$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-eqz v0, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_1

    :cond_2
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    new-instance v0, Ljava/lang/NullPointerException;

    const/4 v11, 0x7

    const-string/jumbo v1, "ichmtootnu ybpptbu eur hs nrb eulMrsoualf ots "

    const-string/jumbo v1, "sp aMru i oe urepstlforo b unhbtlsch obtutny u"

    const/4 v11, 0x1

    const-string v1, "eop or onhulbotpue tl  rbuc iyf btuhtcs oMsasn"

    const-string v1, "Must supply an icon or shortcut for the bubble"

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    throw v0

    :cond_3
    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v9, Landroidx/core/app/x1$f;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v1, p0, Landroidx/core/app/x1$f$c;->a:Landroid/app/PendingIntent;

    const/4 v10, 0x7

    shr-int/2addr v11, v10

    iget-object v2, p0, Landroidx/core/app/x1$f$c;->f:Landroid/app/PendingIntent;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-object v3, p0, Landroidx/core/app/x1$f$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget v4, p0, Landroidx/core/app/x1$f$c;->c:I

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget v5, p0, Landroidx/core/app/x1$f$c;->d:I

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget v6, p0, Landroidx/core/app/x1$f$c;->e:I

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x2

    const/4 v8, 0x0

    move-object v0, v9

    move-object v0, v9

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct/range {v0 .. v8}, Landroidx/core/app/x1$f;-><init>(Landroid/app/PendingIntent;Landroid/app/PendingIntent;Landroidx/core/graphics/drawable/IconCompat;IIILjava/lang/String;Landroidx/core/app/x1$a;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget v0, p0, Landroidx/core/app/x1$f$c;->e:I

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v9, v0}, Landroidx/core/app/x1$f;->j(I)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    return-object v9
.end method

.method public b(Z)Landroidx/core/app/x1$f$c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$f$c;->f(IZ)Landroidx/core/app/x1$f$c;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public c(Landroid/app/PendingIntent;)Landroidx/core/app/x1$f$c;
    .locals 2
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/app/x1$f$c;->f:Landroid/app/PendingIntent;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public d(I)Landroidx/core/app/x1$f$c;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/r;
            unit = 0x0
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x0

    shl-int/2addr v2, v0

    const/4 v1, 0x6

    move v2, v1

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, p0, Landroidx/core/app/x1$f$c;->c:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput v0, p0, Landroidx/core/app/x1$f$c;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public e(I)Landroidx/core/app/x1$f$c;
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Landroidx/core/app/x1$f$c;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Landroidx/core/app/x1$f$c;->c:I

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public g(Landroidx/core/graphics/drawable/IconCompat;)Landroidx/core/app/x1$f$c;
    .locals 3
    .param p1    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$f$c;->g:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/core/app/x1$f$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v1, 0x1

    move v2, v1

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "usu  bBonlup bic-nrlqnbnreloe"

    const-string/jumbo v0, "qib-ulnpll noncs rnBuiroeeu b"

    const/4 v2, 0x1

    const-string/jumbo v0, "ln orsuuBourlu ncnbeilq-nieeb"

    const-string v0, "Bubbles require non-null icon"

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw p1

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string v0, "antt s(p bdnhMula  nutBbuea,.lnq   ooutni tcbaads dactIieIt.e nsiCe)ner.lrCiguIetsnrtgn PbiaBceea ods,ntnncoeadeeros"

    const-string v0, "ItltManlqttluh non t  tnnoCacuieegegttubbrerorodcnCtcaud ts n,iauaee,iscniBne Ii sdaB)dsa dsb(bIeea.ne d.orna. sne P"

    const/4 v2, 0x1

    const-string v0, "eegIaiCnqttnn  et e n,et sbI.rlnMddgut uB)boltC.ooeeranto rnaciaeiincsrluP uInsa,htddbeb necabds suan  ien.actoBdtas"

    const-string v0, "Created as a shortcut bubble, cannot set an Icon. Consider using BubbleMetadata.Builder(PendingIntent,Icon) instead."

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw p1
.end method

.method public h(Landroid/app/PendingIntent;)Landroidx/core/app/x1$f$c;
    .locals 3
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$f$c;->g:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$f$c;->a:Landroid/app/PendingIntent;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v2, 0x3

    const-string/jumbo v0, "ndstnbr -eubgil inele nusneln qntpiorBu"

    const/4 v2, 0x1

    const-string v0, "iBsune-nebestu qugbrenpoi  nnnl ldlreti"

    const-string v0, "Bubble requires non-null pending intent"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "nCsmtB trtetr,unee.,nidnnn InMsabtaniiCue alngueadi lhsiPtaas.roonng)eosstnd(ctBc eeubdbc arnditI bPtoe  eatgbddI le.nute a "

    const-string v0, "Created as a shortcut bubble, cannot set a PendingIntent. Consider using BubbleMetadata.Builder(PendingIntent,Icon) instead."

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    throw p1
.end method

.method public i(Z)Landroidx/core/app/x1$f$c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$f$c;->f(IZ)Landroidx/core/app/x1$f$c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method
