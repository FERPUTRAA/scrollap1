.class public final synthetic Landroidx/core/app/u3;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Landroid/app/NotificationChannelGroup;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "4~s@@@@o~o~f~~ ~r/o1   @y~ ~@   ~~~@ vd @Sum@s@Mb .~i~l~~~~ @tofK@ac@@t@o~@@oi~~ b @/@~bl  ~ n@-"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    check-cast p0, Landroid/app/NotificationChannelGroup;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method
