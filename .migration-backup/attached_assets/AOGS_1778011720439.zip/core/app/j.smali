.class public final Landroidx/core/app/j;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/j$a;,
        Landroidx/core/app/j$b;,
        Landroidx/core/app/j$c;
    }
.end annotation


# static fields
.field public static final a:I = 0x0

.field public static final b:I = 0x1

.field public static final c:I = 0x2

.field public static final d:I = 0x3


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o sc~r/~ oS~o@@ ~.it@  ~   b ~@@ @~@~@yM~1K@~dvb@/~i~~~  @~if@@ sfa4@loto@@o@  l@~~~~u~@~-n ~ bm"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/16 v1, 0x1d

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-lt v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/app/j$c;->c(Landroid/content/Context;)Landroid/app/AppOpsManager;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, p2, v1, p3}, Landroidx/core/app/j$c;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p3, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return p3

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0}, Landroidx/core/app/j$c;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-static {v0, p2, p1, p0}, Landroidx/core/app/j$c;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    const/4 v2, 0x6

    move v3, v2

    return p0

    :cond_1
    const/4 v3, 0x4

    invoke-static {p0, p2, p3}, Landroidx/core/app/j;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "popmss"

    const-string/jumbo v0, "ossppp"

    const-string/jumbo v0, "popsop"

    const-string v0, "appops"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Landroid/app/AppOpsManager;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p0, p1, p2, p3}, Landroidx/core/app/j$a;->a(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    return p0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo v0, "mspaob"

    const-string/jumbo v0, "osampp"

    const/4 v2, 0x5

    const-string/jumbo v0, "upppoa"

    const-string v0, "appops"

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    check-cast p0, Landroid/app/AppOpsManager;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-static {p0, p1, p2, p3}, Landroidx/core/app/j$a;->b(Landroid/app/AppOpsManager;Ljava/lang/String;ILjava/lang/String;)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p0
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-class v0, Landroid/app/AppOpsManager;

    const-class v0, Landroid/app/AppOpsManager;

    const/4 v2, 0x3

    const-class v0, Landroid/app/AppOpsManager;

    const-class v0, Landroid/app/AppOpsManager;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, v0}, Landroidx/core/app/j$b;->a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast p0, Landroid/app/AppOpsManager;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1, p2}, Landroidx/core/app/j$b;->b(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p0
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-class v0, Landroid/app/AppOpsManager;

    const-class v0, Landroid/app/AppOpsManager;

    const/4 v2, 0x4

    const-class v0, Landroid/app/AppOpsManager;

    const-class v0, Landroid/app/AppOpsManager;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, v0}, Landroidx/core/app/j$b;->a(Landroid/content/Context;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Landroid/app/AppOpsManager;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0, p1, p2}, Landroidx/core/app/j$b;->c(Landroid/app/AppOpsManager;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    return p0
.end method

.method public static f(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0}, Landroidx/core/app/j$b;->d(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method
