.class public abstract Landroidx/core/app/NotificationCompatSideChannelService;
.super Landroid/app/Service;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/NotificationCompatSideChannelService$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public abstract a(Ljava/lang/String;ILjava/lang/String;)V
.end method

.method public abstract b(Ljava/lang/String;)V
.end method

.method c(ILjava/lang/String;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~sb   ~@ b@@@~  uyo@f4~~@otlf~m@1M l~~~@ ~@i-@~~~o@~~ ~@/~@ d ~vt @i co/s@S~ ~K@.b n  i@o~@@oar"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    array-length v1, v0

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x3

    shr-int/2addr v4, v2

    :goto_0
    const/4 v5, 0x1

    if-ge v2, v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    aget-object v3, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v3, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/SecurityException;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v2, "inrmflhe aSdenad: ScitUieCnivoNcsoti"

    const-string v2, "Cisnirtid dlh U:nSeiNneacSvtfcioeaoi"

    const/4 v5, 0x6

    const-string/jumbo v2, "neSro ionttncihSlCieeiidi NcadvaU:of"

    const-string v2, "NotificationSideChannelService: Uid "

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo p1, "irfctbaanm toged s o  kairouezh"

    const-string p1, " apmroinehcokaadefusztgtio  r  "

    const/4 v5, 0x0

    const-string/jumbo p1, "rrniaou f aih s gezoetuao cd pk"

    const-string p1, " is not authorized for package "

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    and-int/2addr v5, v4

    throw v0
.end method

.method public abstract d(Ljava/lang/String;ILjava/lang/String;Landroid/app/Notification;)V
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "OOA_NINpN_BuaDH.DrioSNNEoII_sr.tpEddIoACTCTLnp"

    const-string v0, ".TNAoSOn_NuNA_TNrBEH.daIoOLpIdoItFiNI_CDCrEpDs"

    const/4 v2, 0x2

    const-string v0, "OAISptanqoIs.NINdODd.NDNBrEHF_CpTINLT_IuCrAo_i"

    const-string v0, "android.support.BIND_NOTIFICATION_SIDE_CHANNEL"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p1
.end method
