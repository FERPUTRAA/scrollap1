.class public final synthetic Landroidx/core/app/i3;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;Landroid/content/LocusId;)Landroid/app/Notification$Builder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sS4~ t~ @@~lm~~i@~@/ ~fobf @n o~~@ s@bvoM@~@@  o~ ~Kc@ ~~r.ii1 @@o~~@~@d ~@ /@~~oy@-u@bt a ~l@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/Notification$Builder;->setLocusId(Landroid/content/LocusId;)Landroid/app/Notification$Builder;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method
