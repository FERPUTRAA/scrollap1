.class public final synthetic Landroidx/core/app/f1;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/app/NotificationChannelGroup;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " fs~so@~~@o ~K @l/o@~ c@b~@ M@ @~o~~~@ bv @ i~@~b@ yuoft~mni~aS@~t  1@ r 4.d~~o@ / ~i@~@ ~l@@~~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Landroid/app/NotificationChannelGroup;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Landroid/app/NotificationChannelGroup;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v2, 0x7

    return-object v0
.end method
