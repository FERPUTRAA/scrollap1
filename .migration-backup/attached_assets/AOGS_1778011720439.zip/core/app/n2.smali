.class public final synthetic Landroidx/core/app/n2;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "m-sooff @u  i~l ~d~l@@@1 @~  4tt~~n~ac~ My@~~ r@~v~b@K.~~@~~S ~obio~@o  ~o@~ @@/i@  @@@@~b s~@/ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Landroid/app/Notification$MessagingStyle$Message;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
