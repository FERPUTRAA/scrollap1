.class public Landroidx/core/app/ComponentActivity;
.super Landroid/app/Activity;

# interfaces
.implements Landroidx/lifecycle/i0;
.implements Landroidx/core/view/d0$a;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/ComponentActivity$a;
    }
.end annotation


# instance fields
.field private mExtraDataMap:Landroidx/collection/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/m<",
            "Ljava/lang/Class<",
            "+",
            "Landroidx/core/app/ComponentActivity$a;",
            ">;",
            "Landroidx/core/app/ComponentActivity$a;",
            ">;"
        }
    .end annotation
.end field

.field private mLifecycleRegistry:Landroidx/lifecycle/k0;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Landroidx/collection/m;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Landroidx/collection/m;-><init>()V

    const/4 v1, 0x4

    and-int/2addr v2, v1

    iput-object v0, p0, Landroidx/core/app/ComponentActivity;->mExtraDataMap:Landroidx/collection/m;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance v0, Landroidx/lifecycle/k0;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    invoke-direct {v0, p0}, Landroidx/lifecycle/k0;-><init>(Landroidx/lifecycle/i0;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/ComponentActivity;->mLifecycleRegistry:Landroidx/lifecycle/k0;

    return-void
.end method

.method private static a([Ljava/lang/String;)Z
    .locals 6
    .param p0    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ssKo 1-~a@ @@@m@u~@@o@ /  btM @i .~~~~loy~cor ~iS@n@~~~d~~@@~~@b~l  4  fivo/~@@@~~ @bt  ~~~f o "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    if-eqz p0, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    array-length v1, p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-lez v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    aget-object p0, p0, v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x3

    move v5, v4

    const/4 v3, -0x1

    xor-int/2addr v5, v3

    const/4 v4, 0x3

    move v5, v4

    sparse-switch v1, :sswitch_data_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :sswitch_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v1, "ot-mia-lfu"

    const-string/jumbo v1, "uts-liofa-"

    const-string v1, "--autofill"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v3, 0x2

    move v4, v3

    move v4, v3

    const/4 v5, 0x3

    goto :goto_0

    :sswitch_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v1, "tomco-un-acerptt"

    const-string v1, "-rtmunecptt-acoe"

    const/4 v5, 0x5

    const-string/jumbo v1, "ntu-tbccernoptae"

    const-string v1, "--contentcapture"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez p0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    move v3, v2

    move v3, v2

    const/4 v5, 0x4

    move v3, v2

    move v3, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :sswitch_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v1, "t-naonoitals-"

    const/4 v5, 0x1

    const-string/jumbo v1, "s-taa-uloirnt"

    const-string v1, "--translation"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez p0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    move v3, v0

    const/4 v5, 0x4

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    packed-switch v3, :pswitch_data_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :pswitch_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 v1, 0x1a

    const/4 v4, 0x7

    move v5, v4

    if-lt p0, v1, :cond_3

    const/4 v4, 0x7

    move v5, v4

    move v0, v2

    move v0, v2

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v0

    :pswitch_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v1, 0x1d

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-lt p0, v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x5

    move v0, v2

    move v0, v2

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v0

    :pswitch_2
    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v1, 0x1f

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-lt p0, v1, :cond_5

    const/4 v4, 0x5

    const/4 v5, 0x2

    move v0, v2

    move v0, v2

    const/4 v5, 0x4

    move v0, v2

    move v0, v2

    :cond_5
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x2673d6ef -> :sswitch_2
        0x4519f64d -> :sswitch_1
        0x56b9c952 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, p1}, Landroidx/core/view/d0;->d(Landroid/view/View;Landroid/view/KeyEvent;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x4

    return p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, v0, p0, p1}, Landroidx/core/view/d0;->e(Landroidx/core/view/d0$a;Landroid/view/View;Landroid/view/Window$Callback;Landroid/view/KeyEvent;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return p1
.end method

.method public dispatchKeyShortcutEvent(Landroid/view/KeyEvent;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p1}, Landroidx/core/view/d0;->d(Landroid/view/View;Landroid/view/KeyEvent;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    const/4 p1, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyShortcutEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return p1
.end method

.method public getExtraData(Ljava/lang/Class;)Landroidx/core/app/ComponentActivity$a;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroidx/core/app/ComponentActivity$a;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)TT;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/core/app/ComponentActivity;->mExtraDataMap:Landroidx/collection/m;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    check-cast p1, Landroidx/core/app/ComponentActivity$a;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method public getLifecycle()Landroidx/lifecycle/y;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/ComponentActivity;->mLifecycleRegistry:Landroidx/lifecycle/k0;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "RestrictedApi"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0}, Landroidx/lifecycle/ReportFragment;->g(Landroid/app/Activity;)V

    const/4 v1, 0x4

    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/ComponentActivity;->mLifecycleRegistry:Landroidx/lifecycle/k0;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v1, Landroidx/lifecycle/y$b;->c:Landroidx/lifecycle/y$b;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroidx/lifecycle/k0;->n(Landroidx/lifecycle/y$b;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public putExtraData(Landroidx/core/app/ComponentActivity$a;)V
    .locals 4
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/ComponentActivity;->mExtraDataMap:Landroidx/collection/m;

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method protected final shouldDumpInternalState([Ljava/lang/String;)Z
    .locals 2
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p1}, Landroidx/core/app/ComponentActivity;->a([Ljava/lang/String;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    xor-int/lit8 p1, p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1
.end method

.method public superDispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 2
    .param p1    # Landroid/view/KeyEvent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method
