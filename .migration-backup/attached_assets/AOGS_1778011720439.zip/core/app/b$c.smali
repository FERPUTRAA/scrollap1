.class Landroidx/core/app/b$c;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method static a(Landroid/app/Activity;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~ti o~i@@~u .~~m@s~@@ofa@@yo  ~@~K - ~ ~~@f@ @l~~Sb @M d@~ ~c@ bv@~i 1/~b o@~t@@l  n4oor/@~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->finishAfterTransition()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method static b(Landroid/app/Activity;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->postponeEnterTransition()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method static c(Landroid/app/Activity;Landroid/app/SharedElementCallback;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setEnterSharedElementCallback(Landroid/app/SharedElementCallback;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static d(Landroid/app/Activity;Landroid/app/SharedElementCallback;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setExitSharedElementCallback(Landroid/app/SharedElementCallback;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method static e(Landroid/app/Activity;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->startPostponedEnterTransition()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method
