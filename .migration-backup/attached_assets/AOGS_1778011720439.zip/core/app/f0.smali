.class public final synthetic Landroidx/core/app/f0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~so@ ~l~tr~ M @ d~~@o  ~-i@ ~  o~Sm~~@~@f~/~a@@ii@o/ ~K b4@~b@~ o~@uc@f s.@@@1@vbl  @@t~o~y n@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroid/app/NotificationChannel;->setGroup(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
