.class final Landroidx/core/app/JobIntentService$f;
.super Landroid/app/job/JobServiceEngine;

# interfaces
.implements Landroidx/core/app/JobIntentService$b;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1a
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "f"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/JobIntentService$f$a;
    }
.end annotation


# static fields
.field static final d:Ljava/lang/String; = "JobServiceEngineImpl"

.field static final e:Z


# instance fields
.field final a:Landroidx/core/app/JobIntentService;

.field final b:Ljava/lang/Object;

.field c:Landroid/app/job/JobParameters;


# direct methods
.method constructor <init>(Landroidx/core/app/JobIntentService;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Landroid/app/job/JobServiceEngine;-><init>(Landroid/app/Service;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/JobIntentService$f;->b:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/core/app/JobIntentService$f;->a:Landroidx/core/app/JobIntentService;

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a()Landroid/os/IBinder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @st ~o i@@~n~i@@~@Ko@/@S~vM  @@ f~~1 f~s  b~~~~~~@@@~u 4@-y l@~b@@~c m~/r~~l@ ~~ o.abo @ d@oo i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    invoke-static {p0}, Landroidx/core/app/n;->a(Landroidx/core/app/JobIntentService$f;)Landroid/os/IBinder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()Landroidx/core/app/JobIntentService$e;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/JobIntentService$f;->b:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Landroidx/core/app/JobIntentService$f;->c:Landroid/app/job/JobParameters;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v1, :cond_0

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v2

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1}, Landroidx/core/app/o;->a(Landroid/app/job/JobParameters;)Landroid/app/job/JobWorkItem;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v1}, Landroidx/core/app/p;->a(Landroid/app/job/JobWorkItem;)Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Landroidx/core/app/JobIntentService$f;->a:Landroidx/core/app/JobIntentService;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v2}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setExtrasClassLoader(Ljava/lang/ClassLoader;)V

    const/4 v4, 0x6

    new-instance v0, Landroidx/core/app/JobIntentService$f$a;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0, p0, v1}, Landroidx/core/app/JobIntentService$f$a;-><init>(Landroidx/core/app/JobIntentService$f;Landroid/app/job/JobWorkItem;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v2

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    throw v1
.end method

.method public onStartJob(Landroid/app/job/JobParameters;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Landroidx/core/app/JobIntentService$f;->c:Landroid/app/job/JobParameters;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/core/app/JobIntentService$f;->a:Landroidx/core/app/JobIntentService;

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p1, v0}, Landroidx/core/app/JobIntentService;->e(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method

.method public onStopJob(Landroid/app/job/JobParameters;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object p1, p0, Landroidx/core/app/JobIntentService$f;->a:Landroidx/core/app/JobIntentService;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroidx/core/app/JobIntentService;->b()Z

    move-result p1

    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Landroidx/core/app/JobIntentService$f;->b:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    monitor-enter v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v1, p0, Landroidx/core/app/JobIntentService$f;->c:Landroid/app/job/JobParameters;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw p1
.end method
