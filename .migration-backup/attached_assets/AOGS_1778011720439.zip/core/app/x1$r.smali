.class public final Landroidx/core/app/x1$r;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/x1$j;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "r"
.end annotation


# static fields
.field private static final A:Ljava/lang/String; = "displayIntent"

.field private static final B:Ljava/lang/String; = "pages"

.field private static final C:Ljava/lang/String; = "background"

.field private static final D:Ljava/lang/String; = "contentIcon"

.field private static final E:Ljava/lang/String; = "contentIconGravity"

.field private static final F:Ljava/lang/String; = "contentActionIndex"

.field private static final G:Ljava/lang/String; = "customSizePreset"

.field private static final H:Ljava/lang/String; = "customContentHeight"

.field private static final I:Ljava/lang/String; = "gravity"

.field private static final J:Ljava/lang/String; = "hintScreenTimeout"

.field private static final K:Ljava/lang/String; = "dismissalId"

.field private static final L:Ljava/lang/String; = "bridgeTag"

.field private static final M:I = 0x1

.field private static final N:I = 0x2

.field private static final O:I = 0x4

.field private static final P:I = 0x8

.field private static final Q:I = 0x10

.field private static final R:I = 0x20

.field private static final S:I = 0x40

.field private static final T:I = 0x1

.field private static final U:I = 0x800005

.field private static final V:I = 0x50

.field public static final o:I = -0x1

.field public static final p:I = 0x0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final q:I = 0x1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final r:I = 0x2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final s:I = 0x3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final t:I = 0x4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final u:I = 0x5
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final v:I = 0x0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final w:I = -0x1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final x:Ljava/lang/String; = "android.wearable.EXTENSIONS"

.field private static final y:Ljava/lang/String; = "actions"

.field private static final z:Ljava/lang/String; = "flags"


# instance fields
.field private a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/core/app/x1$b;",
            ">;"
        }
    .end annotation
.end field

.field private b:I

.field private c:Landroid/app/PendingIntent;

.field private d:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/app/Notification;",
            ">;"
        }
    .end annotation
.end field

.field private e:Landroid/graphics/Bitmap;

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:I

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    iput v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    const v0, 0x800005

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput v0, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, -0x1

    iput v0, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/16 v0, 0x50

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput v0, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/app/Notification;)V
    .locals 12
    .param p1    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v11, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    iput-object v0, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v0, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    iput v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    new-instance v1, Ljava/util/ArrayList;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x2

    iput-object v1, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    const v1, 0x800005

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    iput v1, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v2, -0x1

    or-int/2addr v11, v2

    const/4 v10, 0x4

    move v11, v10

    iput v2, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v3, 0x0

    move v11, v3

    const/4 v10, 0x1

    move v11, v10

    iput v3, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    const/16 v4, 0x50

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    iput v4, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v11, 0x1

    const/4 v10, 0x2

    invoke-static {p1}, Landroidx/core/app/x1;->n(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-eqz p1, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string v5, ".asoTbSEa.sdSNIrewNOalEXidr"

    const-string v5, "SoswdESelTaerdIarN.NaiE.bXO"

    const/4 v11, 0x1

    const-string v5, "android.wearable.EXTENSIONS"

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    goto :goto_0

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-eqz p1, :cond_4

    const/4 v10, 0x6

    move v11, v10

    const-string v5, "atcmnis"

    const-string/jumbo v5, "nscmiat"

    const/4 v11, 0x0

    const-string/jumbo v5, "taoiocn"

    const-string v5, "actions"

    const/4 v11, 0x2

    invoke-virtual {p1, v5}, Landroid/os/Bundle;->getParcelableArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v5

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-eqz v5, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    new-array v7, v6, [Landroidx/core/app/x1$b;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    move v8, v3

    move v8, v3

    const/4 v11, 0x6

    move v8, v3

    move v8, v3

    :goto_1
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-ge v8, v6, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v5, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    check-cast v9, Landroid/app/Notification$Action;

    const/4 v11, 0x5

    const/4 v10, 0x4

    invoke-static {v9}, Landroidx/core/app/x1;->b(Landroid/app/Notification$Action;)Landroidx/core/app/x1$b;

    move-result-object v9

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    aput-object v9, v7, v8

    const/4 v11, 0x5

    const/4 v10, 0x5

    add-int/lit8 v8, v8, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto :goto_1

    :cond_1
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v5, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {v5, v7}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x0

    const-string/jumbo v5, "lagso"

    const/4 v11, 0x7

    const-string v5, "flags"

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p1, v5, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v10, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    iput v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-string v0, "enpabbdtInilt"

    const-string/jumbo v0, "ndeItbtnlayip"

    const/4 v11, 0x1

    const-string v0, "eiandnustytIl"

    const-string v0, "displayIntent"

    const/4 v10, 0x6

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    check-cast v0, Landroid/app/PendingIntent;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    iput-object v0, p0, Landroidx/core/app/x1$r;->c:Landroid/app/PendingIntent;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string/jumbo v0, "sepag"

    const-string/jumbo v0, "suega"

    const/4 v11, 0x2

    const-string/jumbo v0, "pagqe"

    const-string/jumbo v0, "pages"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {p1, v0}, Landroidx/core/app/x1;->u(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/app/Notification;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz v0, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x4

    iget-object v5, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-static {v5, v0}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string/jumbo v0, "odsgbcnurp"

    const-string/jumbo v0, "ocbragupnd"

    const/4 v11, 0x2

    const-string/jumbo v0, "onamgcrkud"

    const-string v0, "background"

    const/4 v10, 0x0

    move v11, v10

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    check-cast v0, Landroid/graphics/Bitmap;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    iput-object v0, p0, Landroidx/core/app/x1$r;->e:Landroid/graphics/Bitmap;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v0, "neqnooItoct"

    const-string v0, "etcocInnqot"

    const-string v0, "ecnnobttnco"

    const-string v0, "contentIcon"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x6

    iput v0, p0, Landroidx/core/app/x1$r;->f:I

    const/4 v11, 0x5

    const-string/jumbo v0, "nGrtccusateonIiony"

    const-string/jumbo v0, "nrsycecioonttIGtna"

    const/4 v11, 0x7

    const-string/jumbo v0, "tavocnyptnnrctGeIi"

    const-string v0, "contentIconGravity"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    iput v0, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v11, 0x1

    const-string/jumbo v0, "otemenicAotcndnIxn"

    const/4 v11, 0x7

    const-string v0, "IiAttenoqnocntxdec"

    const-string v0, "contentActionIndex"

    const/4 v10, 0x3

    move v11, v10

    invoke-virtual {p1, v0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    iput v0, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string v0, "essoPeittezrmcus"

    const-string/jumbo v0, "zrteooPuctsmiese"

    const/4 v11, 0x2

    const-string v0, "customSizePreset"

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p1, v0, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v10, 0x7

    move v11, v10

    iput v0, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-string/jumbo v0, "omumgthHittebCsneoc"

    const-string/jumbo v0, "thsimbteeoungoCcttH"

    const-string/jumbo v0, "ttcCoionthsmunotHge"

    const-string v0, "customContentHeight"

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x5

    iput v0, p0, Landroidx/core/app/x1$r;->j:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string/jumbo v0, "yuivgbt"

    const-string v0, "gtrvyiu"

    const/4 v11, 0x7

    const-string v0, "gvityru"

    const-string v0, "gravity"

    const/4 v11, 0x7

    invoke-virtual {p1, v0, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    iput v0, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string v0, "SicremhponnieuteT"

    const-string v0, "hintScreenTimeout"

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    iput v0, p0, Landroidx/core/app/x1$r;->l:I

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string/jumbo v0, "imssldsiqdI"

    const-string/jumbo v0, "missIdlpsid"

    const/4 v11, 0x6

    const-string/jumbo v0, "sisdamdIlis"

    const-string v0, "dismissalId"

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    iput-object v0, p0, Landroidx/core/app/x1$r;->m:Ljava/lang/String;

    const/4 v11, 0x2

    const-string/jumbo v0, "qdrmiTeba"

    const-string v0, "Trdegbiaq"

    const/4 v11, 0x4

    const-string v0, "egabodriT"

    const-string v0, "bridgeTag"

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    iput-object p1, p0, Landroidx/core/app/x1$r;->n:Ljava/lang/String;

    :cond_4
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    return-void
.end method

.method private N(IZ)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@@~ bb~-~ b @/@ou@  r~iot~n@of iim~a~@c~ @   l~~ 1S~v.@/K@to4l~~~ @d ~os~f@~o@b~@ ~@@ ~@y  M~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    if-eqz p2, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget p2, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    or-int/2addr p1, p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    iput p1, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget p2, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    not-int p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    and-int/2addr p1, p2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Landroidx/core/app/x1$r;->b:I

    :goto_0
    const/4 v1, 0x3

    return-void
.end method

.method private static i(Landroidx/core/app/x1$b;)Landroid/app/Notification$Action;
    .locals 7
    .annotation build Landroidx/annotation/w0;
        value = 0x14
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->f()Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    new-instance v2, Landroid/app/Notification$Action$Builder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    if-nez v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1}, Landroidx/core/graphics/drawable/IconCompat;->L()Landroid/graphics/drawable/Icon;

    move-result-object v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->j()Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->a()Landroid/app/PendingIntent;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v2, v1, v3, v4}, Landroid/app/Notification$Action$Builder;-><init>(Landroid/graphics/drawable/Icon;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v1, Landroid/os/Bundle;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v1, v3}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v6, 0x6

    new-instance v1, Landroid/os/Bundle;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v3, "edpGspuirlndilea.lraunotepRawodsese.t"

    const-string/jumbo v3, "wpspnrseela.ioeleRetlntpraadddruio.Gs"

    const/4 v6, 0x5

    const-string/jumbo v3, "ptlwpnepeteaenaduospaiolGedsRr.rlidro"

    const-string v3, "android.support.allowGeneratedReplies"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->b()Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, v3, v4}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/16 v3, 0x18

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-lt v0, v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->b()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v2, v3}, Landroidx/core/app/r2;->a(Landroid/app/Notification$Action$Builder;Z)Landroid/app/Notification$Action$Builder;

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/16 v3, 0x1f

    const/4 v6, 0x2

    if-lt v0, v3, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->k()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v2, v0}, Landroidx/core/app/s2;->a(Landroid/app/Notification$Action$Builder;Z)Landroid/app/Notification$Action$Builder;

    :cond_3
    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Landroid/app/Notification$Action$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/Notification$Action$Builder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->g()[Landroidx/core/app/h4;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    if-eqz p0, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p0}, Landroidx/core/app/h4;->d([Landroidx/core/app/h4;)[Landroid/app/RemoteInput;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    array-length v0, p0

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    const/4 v1, 0x0

    xor-int/2addr v6, v1

    :goto_2
    const/4 v5, 0x3

    const/4 v5, 0x1

    if-ge v1, v0, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x2

    aget-object v3, p0, v1

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Landroid/app/Notification$Action$Builder;->addRemoteInput(Landroid/app/RemoteInput;)Landroid/app/Notification$Action$Builder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_2

    :cond_4
    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2}, Landroid/app/Notification$Action$Builder;->build()Landroid/app/Notification$Action;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-object p0
.end method


# virtual methods
.method public A()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public B()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/app/Notification;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public C()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x8

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public D(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$r;
    .locals 2
    .param p1    # Landroid/graphics/Bitmap;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/x1$r;->e:Landroid/graphics/Bitmap;

    const/4 v1, 0x2

    return-object p0
.end method

.method public E(Ljava/lang/String;)Landroidx/core/app/x1$r;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/x1$r;->n:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public F(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method public G(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Landroidx/core/app/x1$r;->f:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method public H(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public I(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public J(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p1, p0, Landroidx/core/app/x1$r;->j:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method public K(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p1, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public L(Ljava/lang/String;)Landroidx/core/app/x1$r;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/x1$r;->m:Ljava/lang/String;

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    return-object p0
.end method

.method public M(Landroid/app/PendingIntent;)Landroidx/core/app/x1$r;
    .locals 2
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/x1$r;->c:Landroid/app/PendingIntent;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public O(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p1, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public P(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/16 v0, 0x20

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v2, 0x5

    return-object p0
.end method

.method public Q(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/16 v0, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public R(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v0, 0x40

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public S(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public T(I)Landroidx/core/app/x1$r;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput p1, p0, Landroidx/core/app/x1$r;->l:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method public U(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v1, 0x4

    move v2, v1

    return-object p0
.end method

.method public V(Z)Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/16 v0, 0x8

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, v0, p1}, Landroidx/core/app/x1$r;->N(IZ)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0
.end method

.method public a(Landroidx/core/app/x1$g;)Landroidx/core/app/x1$g;
    .locals 6
    .param p1    # Landroidx/core/app/x1$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v5, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x1

    move v5, v4

    iget-object v1, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v2, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast v3, Landroidx/core/app/x1$b;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v3}, Landroidx/core/app/x1$r;->i(Landroidx/core/app/x1$b;)Landroid/app/Notification$Action;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "iqmocna"

    const-string v2, "canmsio"

    const/4 v5, 0x5

    const-string v2, "ctssani"

    const-string v2, "actions"

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelableArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    iget v1, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eq v1, v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v2, "asgmf"

    const-string v2, "fgaso"

    const/4 v5, 0x4

    const-string/jumbo v2, "lfgso"

    const-string v2, "flags"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_2
    const/4 v5, 0x7

    iget-object v1, p0, Landroidx/core/app/x1$r;->c:Landroid/app/PendingIntent;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v2, "tIepnbtayilns"

    const-string/jumbo v2, "sntiIbantyple"

    const/4 v5, 0x0

    const-string v2, "enInsyutalipt"

    const-string v2, "displayIntent"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-array v2, v2, [Landroid/app/Notification;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast v1, [Landroid/os/Parcelable;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "eppag"

    const-string v2, "eugap"

    const/4 v5, 0x2

    const-string v2, "gpsqe"

    const-string/jumbo v2, "pages"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Landroidx/core/app/x1$r;->e:Landroid/graphics/Bitmap;

    const/4 v5, 0x6

    if-eqz v1, :cond_5

    const/4 v5, 0x5

    const-string/jumbo v2, "nusdcobprg"

    const-string v2, "gbcrudapno"

    const/4 v5, 0x6

    const-string v2, "gndmckuaro"

    const-string v2, "background"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v1, p0, Landroidx/core/app/x1$r;->f:I

    const/4 v5, 0x6

    if-eqz v1, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v2, "cocnntonqeI"

    const/4 v5, 0x2

    const-string v2, "ctcnoIeoton"

    const-string v2, "contentIcon"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v1, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const v2, 0x800005

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eq v1, v2, :cond_7

    const/4 v5, 0x5

    const/4 v4, 0x0

    const-string v2, "Gcontbcynternotaiv"

    const-string v2, "contentIconGravity"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget v1, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eq v1, v2, :cond_8

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "AcnidsutceoxentIon"

    const-string v2, "AosdeIintnotetxccn"

    const/4 v5, 0x5

    const-string v2, "Itnxccopttednnenoi"

    const-string v2, "contentActionIndex"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_8
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v1, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_9

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v2, "emieteosqtzmcSsr"

    const-string/jumbo v2, "seemitotscPrSmez"

    const/4 v5, 0x1

    const-string v2, "ezsSsituosemcePr"

    const-string v2, "customSizePreset"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_9
    const/4 v5, 0x6

    const/4 v4, 0x5

    iget v1, p0, Landroidx/core/app/x1$r;->j:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v1, :cond_a

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v2, "ettmoomesnuhHgcttio"

    const-string/jumbo v2, "uthtogceHsCitoetmno"

    const/4 v5, 0x4

    const-string v2, "etonoumCgHttnihesoc"

    const-string v2, "customContentHeight"

    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_a
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget v1, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v2, 0x50

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eq v1, v2, :cond_b

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v2, "ybvigbt"

    const-string/jumbo v2, "vtigaby"

    const/4 v5, 0x4

    const-string/jumbo v2, "ivrgatu"

    const-string v2, "gravity"

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_b
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v1, p0, Landroidx/core/app/x1$r;->l:I

    const/4 v4, 0x6

    move v5, v4

    if-eqz v1, :cond_c

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v2, "hTeSoreptunnumeic"

    const-string v2, "chtSiruuetnTnmoee"

    const/4 v5, 0x2

    const-string v2, "hunmSnecqitoteTri"

    const-string v2, "hintScreenTimeout"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_c
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$r;->m:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_d

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v2, "smslsdIpasi"

    const-string v2, "dsmsilapIds"

    const/4 v5, 0x7

    const-string/jumbo v2, "sdimaIssilm"

    const-string v2, "dismissalId"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_d
    const/4 v5, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Landroidx/core/app/x1$r;->n:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x3

    if-eqz v1, :cond_e

    const/4 v5, 0x0

    const-string v2, "ggdTorbea"

    const-string v2, "gdrageTbq"

    const/4 v5, 0x1

    const-string v2, "bridgeTag"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_e
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroidx/core/app/x1$g;->t()Landroid/os/Bundle;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v2, "TdOwbboasXdlrEniaSN.ENeaeI."

    const-string/jumbo v2, "n.s.redbioaIdEelarESwNONTaX"

    const/4 v5, 0x1

    const-string v2, "dniwrOurIalXTedNaeSbS..NoEa"

    const-string v2, "android.wearable.EXTENSIONS"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v2, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object p1
.end method

.method public b(Landroidx/core/app/x1$b;)Landroidx/core/app/x1$r;
    .locals 3
    .param p1    # Landroidx/core/app/x1$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public c(Ljava/util/List;)Landroidx/core/app/x1$r;
    .locals 3
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$b;",
            ">;)",
            "Landroidx/core/app/x1$r;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/CloneNotSupportedException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/core/app/x1$r;->h()Landroidx/core/app/x1$r;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public d(Landroid/app/Notification;)Landroidx/core/app/x1$r;
    .locals 3
    .param p1    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object p0
.end method

.method public e(Ljava/util/List;)Landroidx/core/app/x1$r;
    .locals 3
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/app/Notification;",
            ">;)",
            "Landroidx/core/app/x1$r;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public f()Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method

.method public g()Landroidx/core/app/x1$r;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public h()Landroidx/core/app/x1$r;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v0, Landroidx/core/app/x1$r;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0}, Landroidx/core/app/x1$r;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v1, v0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v3, 0x4

    move v4, v3

    iget v1, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v1, v0, Landroidx/core/app/x1$r;->b:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/core/app/x1$r;->c:Landroid/app/PendingIntent;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v1, v0, Landroidx/core/app/x1$r;->c:Landroid/app/PendingIntent;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance v1, Ljava/util/ArrayList;

    iget-object v2, p0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object v1, v0, Landroidx/core/app/x1$r;->d:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Landroidx/core/app/x1$r;->e:Landroid/graphics/Bitmap;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v1, v0, Landroidx/core/app/x1$r;->e:Landroid/graphics/Bitmap;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v1, p0, Landroidx/core/app/x1$r;->f:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput v1, v0, Landroidx/core/app/x1$r;->f:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v1, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v1, v0, Landroidx/core/app/x1$r;->g:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v1, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v1, v0, Landroidx/core/app/x1$r;->h:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v1, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v1, v0, Landroidx/core/app/x1$r;->i:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v1, p0, Landroidx/core/app/x1$r;->j:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v1, v0, Landroidx/core/app/x1$r;->j:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget v1, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v1, v0, Landroidx/core/app/x1$r;->k:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Landroidx/core/app/x1$r;->l:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput v1, v0, Landroidx/core/app/x1$r;->l:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Landroidx/core/app/x1$r;->m:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object v1, v0, Landroidx/core/app/x1$r;->m:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$r;->n:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v1, v0, Landroidx/core/app/x1$r;->n:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method public j()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$b;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$r;->a:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public k()Landroid/graphics/Bitmap;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$r;->e:Landroid/graphics/Bitmap;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public l()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$r;->n:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public m()I
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/app/x1$r;->h:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public n()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget v0, p0, Landroidx/core/app/x1$r;->f:I

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public o()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, p0, Landroidx/core/app/x1$r;->g:I

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public p()Z
    .locals 4

    const/4 v3, 0x1

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v1
.end method

.method public q()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Landroidx/core/app/x1$r;->j:I

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public r()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Landroidx/core/app/x1$r;->i:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public s()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/x1$r;->m:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public t()Landroid/app/PendingIntent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$r;->c:Landroid/app/PendingIntent;

    const/4 v1, 0x2

    or-int/2addr v2, v1

    return-object v0
.end method

.method public u()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Landroidx/core/app/x1$r;->k:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public v()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public w()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x6

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public x()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public y()Z
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/app/x1$r;->b:I

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x5

    return v0
.end method

.method public z()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Landroidx/core/app/x1$r;->l:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method
