.class public Landroidx/core/app/x1$m;
.super Landroidx/core/app/x1$q;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "m"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/x1$m$a;
    }
.end annotation


# static fields
.field private static final j:Ljava/lang/String; = "androidx.core.app.NotificationCompat$MessagingStyle"

.field public static final k:I = 0x19


# instance fields
.field private final e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/core/app/x1$m$a;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/core/app/x1$m$a;",
            ">;"
        }
    .end annotation
.end field

.field private g:Landroidx/core/app/f4;

.field private h:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private i:Ljava/lang/Boolean;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Landroidx/core/app/f4;)V
    .locals 3
    .param p1    # Landroidx/core/app/f4;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p1, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo v0, "oss  s /u.ermbsUm spmatent/nt e"

    const-string v0, "ersbe.aosuym pt t /sne Umstn /m"

    const/4 v2, 0x2

    const-string/jumbo v0, "yeum sstrn/bU.ea /osnt mpmm ee "

    const-string v0, "User\'s name must not be empty."

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw p1
.end method

.method public constructor <init>(Ljava/lang/CharSequence;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Landroidx/core/app/f4$c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public static E(Landroid/app/Notification;)Landroidx/core/app/x1$m;
    .locals 3
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "K~~@o /~t@~M@@ @@~/b~~nS.  i@~ @oc~ i@@l@  lou i4 fr~o~1 @s@m@~t~-~@@~ @o~~o yof ~ ~@~~@~abb@  v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-static {p0}, Landroidx/core/app/x1$q;->s(Landroid/app/Notification;)Landroidx/core/app/x1$q;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    instance-of v0, p0, Landroidx/core/app/x1$m;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    check-cast p0, Landroidx/core/app/x1$m;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 p0, 0x4

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method private F()Landroidx/core/app/x1$m$a;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-ltz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast v1, Landroidx/core/app/x1$m$a;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v2, :cond_0

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-virtual {v1}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v2}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v4, 0x3

    if-nez v0, :cond_2

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    add-int/lit8 v1, v1, -0x1

    const/4 v4, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v0, Landroidx/core/app/x1$m$a;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object v0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object v0
.end method

.method private L()Z
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    sub-int/2addr v0, v1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-ltz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v2, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    check-cast v2, Landroidx/core/app/x1$m$a;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {v2}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x7

    return v0
.end method

.method private N(I)Landroid/text/style/TextAppearanceSpan;
    .locals 9
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x4

    new-instance v6, Landroid/text/style/TextAppearanceSpan;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v1, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v3, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {p1}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct/range {v0 .. v5}, Landroid/text/style/TextAppearanceSpan;-><init>(Ljava/lang/String;IILandroid/content/res/ColorStateList;Landroid/content/res/ColorStateList;)V

    const/4 v7, 0x0

    or-int/2addr v8, v7

    return-object v6
.end method

.method private O(Landroidx/core/app/x1$m$a;)Ljava/lang/CharSequence;
    .locals 9
    .param p1    # Landroidx/core/app/x1$m$a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {}, Landroidx/core/text/a;->c()Landroidx/core/text/a;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance v1, Landroid/text/SpannableStringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v1}, Landroid/text/SpannableStringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v3, ""

    const-string v3, ""

    const/4 v8, 0x2

    const-string v3, ""

    const-string v3, ""

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-nez v2, :cond_0

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v2}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v2

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/high16 v5, -0x1000000

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz v4, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v2, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v2}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v4, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v4}, Landroidx/core/app/x1$g;->r()I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v4, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v4, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v4}, Landroidx/core/app/x1$g;->r()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    move v5, v4

    move v5, v4

    const/4 v8, 0x4

    move v5, v4

    move v5, v4

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, v2}, Landroidx/core/text/a;->m(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, v2}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {p0, v5}, Landroidx/core/app/x1$m;->N(I)Landroid/text/style/TextAppearanceSpan;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    sub-int/2addr v5, v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1}, Landroid/text/SpannableStringBuilder;->length()I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/16 v6, 0x21

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v1, v4, v5, v2, v6}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroidx/core/app/x1$m$a;->i()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-nez v2, :cond_2

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    goto :goto_1

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroidx/core/app/x1$m$a;->i()Ljava/lang/CharSequence;

    move-result-object v3

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string p1, "  "

    const-string p1, "  "

    const/4 v8, 0x7

    const-string p1, "  "

    const-string p1, "  "

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1, p1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v0, v3}, Landroidx/core/text/a;->m(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p1, v0}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-object v1
.end method


# virtual methods
.method public A(Landroidx/core/app/x1$m$a;)Landroidx/core/app/x1$m;
    .locals 3
    .param p1    # Landroidx/core/app/x1$m$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x1

    move v2, v1

    iget-object p1, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/16 v0, 0x19

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-le p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public B(Landroidx/core/app/x1$m$a;)Landroidx/core/app/x1$m;
    .locals 3
    .param p1    # Landroidx/core/app/x1$m$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/16 v0, 0x19

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-le p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    iget-object p1, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p0
.end method

.method public C(Ljava/lang/CharSequence;JLandroidx/core/app/f4;)Landroidx/core/app/x1$m;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroidx/core/app/f4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    new-instance v0, Landroidx/core/app/x1$m$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {v0, p1, p2, p3, p4}, Landroidx/core/app/x1$m$a;-><init>(Ljava/lang/CharSequence;JLandroidx/core/app/f4;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroidx/core/app/x1$m;->B(Landroidx/core/app/x1$m$a;)Landroidx/core/app/x1$m;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public D(Ljava/lang/CharSequence;JLjava/lang/CharSequence;)Landroidx/core/app/x1$m;
    .locals 5
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Landroidx/core/app/x1$m$a;

    const/4 v4, 0x1

    new-instance v2, Landroidx/core/app/f4$c;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {v2}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2, p4}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object p4

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p4}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object p4

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1, p1, p2, p3, p4}, Landroidx/core/app/x1$m$a;-><init>(Ljava/lang/CharSequence;JLandroidx/core/app/f4;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p1, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/16 p2, 0x19

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-le p1, p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 p2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p1, p2}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p0
.end method

.method public G()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public H()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$m$a;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public I()Ljava/util/List;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$m$a;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public J()Landroidx/core/app/f4;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public K()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public M()Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, v0, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 v2, 0x1c

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v0, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v1
.end method

.method public P(Ljava/lang/CharSequence;)Landroidx/core/app/x1$m;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method public Q(Z)Landroidx/core/app/x1$m;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v0, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public a(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->a(Landroid/os/Bundle;)V

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v1, "apDlmbddsn.slyiNamaorfe"

    const-string/jumbo v1, "iammyorlNedsD.aneldafps"

    const/4 v3, 0x4

    const-string v1, "aidfpNumas.laiedoeDrsyl"

    const-string v1, "android.selfDisplayName"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroidx/core/app/f4;->m()Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "yaSdsgeporeiUsieonm.tlrgsd"

    const-string/jumbo v1, "oasto.dneSslgidsUeirgmarye"

    const/4 v3, 0x2

    const-string v1, ".dslennaqeyamiggSersrotdUs"

    const-string v1, "android.messagingStyleUser"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v0, "hrseiTneaibensl.vnrdCtdnadooidt"

    const-string/jumbo v0, "ni.onbaeTddselvotitrCienonhradd"

    const/4 v3, 0x6

    const-string v0, "evamTddin.ohiadCdnorereltintnio"

    const-string v0, "android.hiddenConversationTitle"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const-string v0, "deenocnr.uaitolivasidrooT"

    const-string/jumbo v0, "iiorvTudletsanoetrc.ainod"

    const/4 v3, 0x0

    const-string v0, "e.acrboniiToindodterlasnt"

    const-string v0, "android.conversationTitle"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Landroidx/core/app/x1$m$a;->a(Ljava/util/List;)[Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "sa.gindprdmeoess"

    const/4 v3, 0x2

    const-string v1, "grs.doudsnmeiaas"

    const-string v1, "android.messages"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Landroidx/core/app/x1$m$a;->a(Ljava/util/List;)[Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "ndsaacdp.irshmtgeooqsis.e"

    const-string v1, "es.ctndgqrho.sdaosaeiisim"

    const/4 v3, 0x3

    const-string v1, "gmei.adcqohrtsisasro.ndei"

    const-string v1, "android.messages.historic"

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, "Grso.oerinCnsprsavndiuiotao"

    const-string v1, "android.isGroupConversation"

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public b(Landroidx/core/app/v;)V
    .locals 9
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p0}, Landroidx/core/app/x1$m;->M()Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p0, v0}, Landroidx/core/app/x1$m;->Q(Z)Landroidx/core/app/x1$m;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/16 v1, 0x18

    const/4 v8, 0x1

    if-lt v0, v1, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/16 v1, 0x1c

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-lt v0, v1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x7

    invoke-static {}, Landroidx/core/app/j2;->a()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v8, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroidx/core/app/f4;->k()Landroid/app/Person;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-static {v0}, Landroidx/core/app/i2;->a(Landroid/app/Person;)Landroid/app/Notification$MessagingStyle;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    invoke-static {}, Landroidx/core/app/j2;->a()V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v0}, Landroidx/core/app/h2;->a(Ljava/lang/CharSequence;)Landroid/app/Notification$MessagingStyle;

    move-result-object v0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object v2, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v8, 0x1

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v3, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    check-cast v3, Landroidx/core/app/x1$m$a;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v3}, Landroidx/core/app/x1$m$a;->l()Landroid/app/Notification$MessagingStyle$Message;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v0, v3}, Landroidx/core/app/c2;->a(Landroid/app/Notification$MessagingStyle;Landroid/app/Notification$MessagingStyle$Message;)Landroid/app/Notification$MessagingStyle;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/16 v3, 0x1a

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-lt v2, v3, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v2, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-eqz v3, :cond_2

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    check-cast v3, Landroidx/core/app/x1$m$a;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v3}, Landroidx/core/app/x1$m$a;->l()Landroid/app/Notification$MessagingStyle$Message;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {v0, v3}, Landroidx/core/app/d2;->a(Landroid/app/Notification$MessagingStyle;Landroid/app/Notification$MessagingStyle$Message;)Landroid/app/Notification$MessagingStyle;

    const/4 v8, 0x5

    const/4 v7, 0x0

    goto :goto_2

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v2, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-nez v2, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-lt v2, v1, :cond_4

    :cond_3
    const/4 v8, 0x1

    iget-object v2, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v0, v2}, Landroidx/core/app/e2;->a(Landroid/app/Notification$MessagingStyle;Ljava/lang/CharSequence;)Landroid/app/Notification$MessagingStyle;

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-lt v2, v1, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {v0, v1}, Landroidx/core/app/f2;->a(Landroid/app/Notification$MessagingStyle;Z)Landroid/app/Notification$MessagingStyle;

    :cond_5
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v0, p1}, Landroidx/core/app/g2;->a(Landroid/app/Notification$MessagingStyle;Landroid/app/Notification$Builder;)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto/16 :goto_9

    :cond_6
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {p0}, Landroidx/core/app/x1$m;->F()Landroidx/core/app/x1$m$a;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v1, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-object v1, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v1, :cond_7

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x0

    iget-object v2, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    goto :goto_3

    :cond_7
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v0, :cond_8

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x4

    const-string v2, ""

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v1, :cond_8

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v2}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :cond_8
    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v0, :cond_a

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v2, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v7, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v2, :cond_9

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {p0, v0}, Landroidx/core/app/x1$m;->O(Landroidx/core/app/x1$m$a;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto :goto_4

    :cond_9
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0}, Landroidx/core/app/x1$m$a;->i()Ljava/lang/CharSequence;

    move-result-object v0

    :goto_4
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1, v0}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :cond_a
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-instance v0, Landroid/text/SpannableStringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {v0}, Landroid/text/SpannableStringBuilder;-><init>()V

    const/4 v7, 0x1

    xor-int/2addr v8, v7

    iget-object v1, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v2, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v3, 0x1

    const/4 v8, 0x6

    if-nez v1, :cond_c

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {p0}, Landroidx/core/app/x1$m;->L()Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v1, :cond_b

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_5

    :cond_b
    const/4 v8, 0x7

    move v1, v2

    move v1, v2

    const/4 v8, 0x1

    move v1, v2

    move v1, v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto :goto_6

    :cond_c
    :goto_5
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    move v1, v3

    move v1, v3

    const/4 v8, 0x3

    move v1, v3

    move v1, v3

    :goto_6
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v4, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    sub-int/2addr v4, v3

    :goto_7
    const/4 v8, 0x4

    if-ltz v4, :cond_f

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v5, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {v5, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast v5, Landroidx/core/app/x1$m$a;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eqz v1, :cond_d

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p0, v5}, Landroidx/core/app/x1$m;->O(Landroidx/core/app/x1$m$a;)Ljava/lang/CharSequence;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x6

    goto :goto_8

    :cond_d
    const/4 v8, 0x6

    const/4 v7, 0x6

    invoke-virtual {v5}, Landroidx/core/app/x1$m$a;->i()Ljava/lang/CharSequence;

    move-result-object v5

    :goto_8
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v6, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    sub-int/2addr v6, v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-eq v4, v6, :cond_e

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v6, "/n"

    const-string v6, "/n"

    const-string v6, "/n"

    const-string v6, "\n"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v2, v6}, Landroid/text/SpannableStringBuilder;->insert(ILjava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    :cond_e
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0, v2, v5}, Landroid/text/SpannableStringBuilder;->insert(ILjava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    add-int/lit8 v4, v4, -0x1

    const/4 v7, 0x1

    move v8, v7

    goto :goto_7

    :cond_f
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v1, Landroid/app/Notification$BigTextStyle;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {v1, p1}, Landroid/app/Notification$BigTextStyle;-><init>(Landroid/app/Notification$Builder;)V

    const/4 v7, 0x2

    move v8, v7

    const/4 p1, 0x0

    xor-int/2addr v8, p1

    const/4 v7, 0x6

    move v8, v7

    invoke-virtual {v1, p1}, Landroid/app/Notification$BigTextStyle;->setBigContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    :goto_9
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-void
.end method

.method protected g(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->g(Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const-string v0, "android.messagingStyleUser"

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string/jumbo v0, "pnamdyleosNsaDmdilfiera"

    const-string v0, "android.selfDisplayName"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "tssT.niorvadnoreicidolnet"

    const/4 v2, 0x5

    const-string v0, ".aTrordiionesintlndooatce"

    const-string v0, "android.conversationTitle"

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string v0, "etoavbnnidstdTrnloCmrnoiahid.id"

    const-string/jumbo v0, "isimednoaTdvtnCietodraondnlhr.i"

    const/4 v2, 0x7

    const-string/jumbo v0, "nnhodaulrCdoeadiodtTieevsr.tnin"

    const-string v0, "android.hiddenConversationTitle"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "arn.saspismgoedd"

    const-string v0, "adsaosdrsmegn.ei"

    const/4 v2, 0x7

    const-string v0, "dsrdnesgqeiaaos."

    const-string v0, "android.messages"

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string v0, "dnssmeosatrsir.gobiisecha"

    const-string v0, "hrardbm.sesii.sitosaenogc"

    const/4 v2, 0x0

    const-string v0, "a.amoetsgsnism.crsriiddeh"

    const-string v0, "android.messages.historic"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "tonpdsua.oGrvanseiinurCodor"

    const/4 v2, 0x4

    const-string/jumbo v0, "rrusoiivodeadrniansnt.Coopo"

    const-string v0, "android.isGroupConversation"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method protected t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "goctfb.ieappSMnydao$nidl.oe.mxpseittaapNtooCaincrsr"

    const-string/jumbo v0, "potossepcoNt.nctyiiriSxopfMC$ge..teaoaailnamidrdnap"

    const/4 v2, 0x7

    const-string v0, "etidiaurtnacorSolanCt.daogs.sNpxepioc.iainMg$omftey"

    const-string v0, "androidx.core.app.NotificationCompat$MessagingStyle"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method protected y(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->y(Landroid/os/Bundle;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v0, "eoaqsaipntgslrmUysSdg.iden"

    const-string/jumbo v0, "ml.drteeqnagsoiaedisUnSgsy"

    const/4 v3, 0x6

    const-string v0, "android.messagingStyleUser"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Landroidx/core/app/f4;->b(Landroid/os/Bundle;)Landroidx/core/app/f4;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Landroidx/core/app/f4$c;

    const/4 v3, 0x7

    invoke-direct {v0}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "Desniiafqapmdro.yNasedl"

    const-string/jumbo v1, "ilsemDlynpaN.dfioardsae"

    const/4 v3, 0x4

    const-string/jumbo v1, "iyss.fmnpNoeiDadlsadalr"

    const-string v1, "android.selfDisplayName"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Landroidx/core/app/x1$m;->g:Landroidx/core/app/f4;

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v0, "Tcvmtotenidlenoniors.aari"

    const-string v0, "diem.Tnovarslnaieotocrtin"

    const/4 v3, 0x6

    const-string v0, "arrToleaiodnnivsdn.toecto"

    const-string v0, "android.conversationTitle"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "iivdeb.ornaltoCieenndhdoosTianr"

    const-string v0, "ehdioianeneTtvaodriridno.Cndslo"

    const/4 v3, 0x4

    const-string v0, "dnnr.eutaeadTdotlvendinoCihisor"

    const-string v0, "android.hiddenConversationTitle"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Landroidx/core/app/x1$m;->h:Ljava/lang/CharSequence;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v0, "meiagrepnsd.oasb"

    const-string/jumbo v0, "sem.abesinardosg"

    const/4 v3, 0x4

    const-string/jumbo v0, "msdgsdeeqnaroia."

    const-string v0, "android.messages"

    const/4 v2, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelableArray(Ljava/lang/String;)[Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/core/app/x1$m;->e:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Landroidx/core/app/x1$m$a;->f([Landroid/os/Parcelable;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, "hasseimdogasrnciesoutid.."

    const-string/jumbo v0, "sasgosu.tdecim.oieahindrr"

    const/4 v3, 0x7

    const-string v0, "dadmssrsoca.heeoiigr.intm"

    const-string v0, "android.messages.historic"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelableArray(Ljava/lang/String;)[Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/core/app/x1$m;->f:Ljava/util/List;

    const/4 v3, 0x2

    invoke-static {v0}, Landroidx/core/app/x1$m$a;->f([Landroid/os/Parcelable;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v1, v0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v0, "CnuootvpioeGasi.ndoaodrnirs"

    const-string v0, "CnusoropdnovdiotpiGraieasn."

    const/4 v3, 0x0

    const-string/jumbo v0, "roodtbrpoGiiudaanesno.nCvir"

    const-string v0, "android.isGroupConversation"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$m;->i:Ljava/lang/Boolean;

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method
