.class public final synthetic Landroidx/core/app/l1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s @@t~~~f/ m~ici~r@@@vb o@os@ ~ooi~o ~~ yMub@~l~@~~1b l/~4 fd Sa  ~@~@n@ ~@K@  @@@~-~~@to~. @ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/Notification;->getBadgeIconType()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x4

    return p0
.end method
