.class public final synthetic Landroidx/core/app/z2;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;J)Landroid/app/Notification$Builder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s@~ ~@nu@@ ~~i~~cd@ ~ l m ~/t  @o~~@@b@@ a@1@o~tyv f~ @~i~ f4iol S @~~@/or~Mb~~b@s - oo ~~~@K."

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Landroid/app/Notification$Builder;->setTimeoutAfter(J)Landroid/app/Notification$Builder;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method
