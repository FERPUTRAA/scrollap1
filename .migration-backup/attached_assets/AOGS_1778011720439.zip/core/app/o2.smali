.class public final synthetic Landroidx/core/app/o2;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/widget/RemoteViews;IZ)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "sds~@i~~vc@@~@@M  ~@~  @n/tb~~@lo@ ~~  b@@@oio~~K ~f@yo~al@/ .@ ~b ~m@o@o-@ ~fuS1~ @r~~ ~ @~ti4 "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Landroid/widget/RemoteViews;->setChronometerCountDown(IZ)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
