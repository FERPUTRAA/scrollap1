.class public final synthetic Landroidx/core/app/l2;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Ljava/lang/CharSequence;JLjava/lang/CharSequence;)Landroid/app/Notification$MessagingStyle$Message;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s@ f@~ M~~  vb@a~.l~@o/ls@m ~@~  ~-r~@@b ~~~ob~@@y@~1S~K@ o@t~ 4~~f o@~@i   @ ~it@ no@@odu/@ci"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, Landroid/app/Notification$MessagingStyle$Message;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1, p2, p3}, Landroid/app/Notification$MessagingStyle$Message;-><init>(Ljava/lang/CharSequence;JLjava/lang/CharSequence;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method
