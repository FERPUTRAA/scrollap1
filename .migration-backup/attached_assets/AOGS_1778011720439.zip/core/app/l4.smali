.class public final Landroidx/core/app/l4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Iterable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/l4$a;,
        Landroidx/core/app/l4$b;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Iterable<",
        "Landroid/content/Intent;",
        ">;"
    }
.end annotation


# static fields
.field private static final c:Ljava/lang/String; = "TaskStackBuilder"


# instance fields
.field private final a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Landroid/content/Context;


# direct methods
.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    iput-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public static g(Landroid/content/Context;)Landroidx/core/app/l4;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@/S@~@4y~@M@o ~~~i@i t @ftm/~o ~vron~@@  uc~@@Kl.~~  @@@  dl~s  o~~@~ ~b bf~-b@~ a~ ooi~~@@ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Landroidx/core/app/l4;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Landroidx/core/app/l4;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public static i(Landroid/content/Context;)Landroidx/core/app/l4;
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0}, Landroidx/core/app/l4;->g(Landroid/content/Context;)Landroidx/core/app/l4;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public a(Landroid/content/Intent;)Landroidx/core/app/l4;
    .locals 3
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public b(Landroid/content/Intent;)Landroidx/core/app/l4;
    .locals 3
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroidx/core/app/l4;->e(Landroid/content/ComponentName;)Landroidx/core/app/l4;

    :cond_1
    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroidx/core/app/l4;->a(Landroid/content/Intent;)Landroidx/core/app/l4;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method

.method public d(Landroid/app/Activity;)Landroidx/core/app/l4;
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    instance-of v0, p1, Landroidx/core/app/l4$b;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast v0, Landroidx/core/app/l4$b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-interface {v0}, Landroidx/core/app/l4$b;->getSupportParentActivityIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Landroidx/core/app/u;->a(Landroid/app/Activity;)Landroid/content/Intent;

    move-result-object v0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object p1

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroidx/core/app/l4;->e(Landroid/content/ComponentName;)Landroidx/core/app/l4;

    invoke-virtual {p0, v0}, Landroidx/core/app/l4;->a(Landroid/content/Intent;)Landroidx/core/app/l4;

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public e(Landroid/content/ComponentName;)Landroidx/core/app/l4;
    .locals 4
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v1, p1}, Landroidx/core/app/u;->b(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, v0, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v1, p1}, Landroidx/core/app/u;->b(Landroid/content/Context;Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object p1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    return-object p0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v0, "BukmislsTadektac"

    const-string/jumbo v0, "ruslkisdetTBcaka"

    const/4 v3, 0x0

    const-string v0, "TaskStackBuilder"

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "a N ommeta ewepttatyhvicldntdepoBnCtaearv sna o agmiiinrtar"

    const-string v1, "Bad ComponentName while traversing activity parent metadata"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    move v3, v2

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw v0
.end method

.method public f(Ljava/lang/Class;)Landroidx/core/app/l4;
    .locals 4
    .param p1    # Ljava/lang/Class;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Landroidx/core/app/l4;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Landroid/content/ComponentName;

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1, p1}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroidx/core/app/l4;->e(Landroid/content/ComponentName;)Landroidx/core/app/l4;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p1
.end method

.method public h(I)Landroid/content/Intent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p1, Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public j(I)Landroid/content/Intent;
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroidx/core/app/l4;->h(I)Landroid/content/Intent;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method

.method public k()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public l()[Landroid/content/Intent;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-array v1, v0, [Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    return-object v1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x3

    move v6, v5

    iget-object v3, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    check-cast v3, Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    const v3, 0x1000c000

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    aput-object v2, v1, v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x1

    :goto_0
    const/4 v6, 0x2

    if-ge v2, v0, :cond_1

    const/4 v5, 0x2

    move v6, v5

    new-instance v3, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v4, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    check-cast v4, Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    aput-object v3, v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object v1
.end method

.method public m(II)Landroid/app/PendingIntent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2, v0}, Landroidx/core/app/l4;->n(IILandroid/os/Bundle;)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p1
.end method

.method public n(IILandroid/os/Bundle;)Landroid/app/PendingIntent;
    .locals 6
    .param p3    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    new-array v2, v1, [Landroid/content/Intent;

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v0, [Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    aget-object v3, v0, v1

    const/4 v4, 0x4

    const/4 v4, 0x0

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v5, 0x3

    const v3, 0x1000c000

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    aput-object v2, v0, v1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v5, 0x3

    invoke-static {v1, p1, v0, p2, p3}, Landroidx/core/app/l4$a;->a(Landroid/content/Context;I[Landroid/content/Intent;ILandroid/os/Bundle;)Landroid/app/PendingIntent;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object p1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string p2, "TnteIb oead nokiaterdt;dnBd   mgNttSencndnolsgkainePc etiatnt"

    const-string/jumbo p2, "ntemoPane odtnit;aNkk  ndsBteneo dtdne gttagaiedclruncn IiTSt"

    const/4 v5, 0x6

    const-string p2, "ditudtus  ttt; eTcItdncodnBls akngnie a SeinroetnetagkPanondN"

    const-string p2, "No intents added to TaskStackBuilder; cannot getPendingIntent"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    throw p1
.end method

.method public o()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroidx/core/app/l4;->p(Landroid/os/Bundle;)V

    const/4 v2, 0x5

    return-void
.end method

.method public p(Landroid/os/Bundle;)V
    .locals 6
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/core/app/l4;->a:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-array v2, v1, [Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast v0, [Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    aget-object v3, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const v3, 0x1000c000

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    aput-object v2, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v1, v0, p1}, Landroidx/core/content/d;->startActivities(Landroid/content/Context;[Landroid/content/Intent;Landroid/os/Bundle;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance p1, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    array-length v1, v0

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/lit8 v1, v1, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    aget-object v0, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {p1, v0}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/high16 v0, 0x10000000

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Landroidx/core/app/l4;->b:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v0, "scttoeopnTtiAeu Snt drava ceacai ksodtti ;iiatdrBtteoNnsln k"

    const-string/jumbo v0, "teeeoTclsid ct tinNti tirnttsaoaaetds dio Snckod; atuarnBAvk"

    const/4 v5, 0x7

    const-string/jumbo v0, "t cetsaAqtonin trinvladeuiskcBN ta Toctstandioas;edteik tdSr"

    const-string v0, "No intents added to TaskStackBuilder; cannot startActivities"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    throw p1
.end method
