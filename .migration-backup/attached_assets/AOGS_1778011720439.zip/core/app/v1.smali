.class public final synthetic Landroidx/core/app/v1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Action;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "lfsn~~~M@ @oy bi~1@. @~~@s @~ ~b@o S-v@b io/fcm@@~@ ~l~@ a~/o~~u~  o~@~~~@@K   ~r @it@@4@o~~ @ t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/app/Notification$Action;->getAllowGeneratedReplies()Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p0
.end method
