.class public final synthetic Landroidx/core/app/a2;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;)Landroid/widget/RemoteViews;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " osbl ~@@@m  ~ir~y  @@c~@o@ @~M~ ftl@t~4~o~@ ~f@~~ o~. @~ ib/@ @~~vn~@-o/~@~@~uK @a i@ s~@d b1oS"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/app/Notification$Builder;->createContentView()Landroid/widget/RemoteViews;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method
