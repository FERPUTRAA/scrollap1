.class public final synthetic Landroidx/core/app/u1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/RemoteInput;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b@s i@ l@~m   s~ ~ov@~~~~@~o~S~@1~troo~.~o/@t @y~ @ K da~n@~@~~@ f @@ ~Mbob@ @@ci@~-4~i ~@/l@uf "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/app/RemoteInput;->getEditChoicesBeforeSending()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method
