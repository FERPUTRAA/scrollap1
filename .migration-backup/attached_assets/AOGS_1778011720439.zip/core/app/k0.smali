.class public final synthetic Landroidx/core/app/k0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~Mso~@ l~t~  @ms~S@~  @~  @@ ~@i~~n@oar-b~o t@v1/~~ o@~fd@o@@ifi/@~ ~Kyl.@  b4@@c~~ b @o~@ @ u~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/NotificationChannel;->setLightColor(I)V

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
