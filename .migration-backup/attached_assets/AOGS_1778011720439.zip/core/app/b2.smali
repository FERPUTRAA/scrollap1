.class public final synthetic Landroidx/core/app/b2;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()Landroid/app/Notification$DecoratedCustomViewStyle;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@fs@@ bK@l 1~~-c~~ ~o~o@r@  /t @ 4o  bad~ ~f @n~@oi~@M@y@t@S o@~m @~@s~/~~li~ @ ~@.@~ @v~ ~~bi~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    new-instance v0, Landroid/app/Notification$DecoratedCustomViewStyle;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Landroid/app/Notification$DecoratedCustomViewStyle;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method
