.class public Landroidx/core/app/i;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "PrivateConstructorForUtilityClass"
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "android.support.AppLaunchChecker"

.field private static final b:Ljava/lang/String; = "startedFromLauncher"


# direct methods
.method public constructor <init>()V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@s@f @c@K@@~@@~~@i~o~vnf1~~i o ~oS@ @ / Mt o~b ty~~ @ b  b@~~am/@. ~~id@@~l ~-@l~~o@@ ~~ r~s@ 4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    const-string/jumbo v0, "prdmpornecCdpkuhe.psaihrnLuatcA."

    const-string v0, "crsApptupaunkandhpio.eheCdrLsc.r"

    const-string/jumbo v0, "periopdepcrponChsau..rLkhutonAca"

    const-string v0, "android.support.AppLaunchChecker"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v0, "armhsbcdFartmeoeurt"

    const-string/jumbo v0, "sremeFmornhdurtatca"

    const/4 v3, 0x3

    const-string/jumbo v0, "raechtumorsFruedtna"

    const-string/jumbo v0, "startedFromLauncher"

    const/4 v3, 0x6

    invoke-interface {p0, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p0
.end method

.method public static b(Landroid/app/Activity;)V
    .locals 6
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v0, ".rauLodpsohirnaopkdu.ptpcerncChp"

    const-string/jumbo v0, "strdoruonorLcn.uAeapac.Ckhpdiphp"

    const/4 v5, 0x6

    const-string/jumbo v0, "oi.urLapqrhkpsnhdeptecA.cCarnuod"

    const-string v0, "android.support.AppLaunchChecker"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v2, "FtshseaberudcLomanr"

    const-string v2, "etnLobuFdrhsrarmace"

    const/4 v5, 0x6

    const-string v2, "eatmuLrernscarmoFht"

    const-string/jumbo v2, "startedFromLauncher"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0, v2, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void

    :cond_0
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez p0, :cond_1

    const/4 v5, 0x1

    return-void

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v1, "iAItoaouictN.dndnaoneirMtn"

    const-string v1, "Atniriuteda.MnoaidI.tNonnc"

    const/4 v5, 0x2

    const-string/jumbo v1, "otn.Nb.an.daMoincteitnIdri"

    const-string v1, "android.intent.action.MAIN"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "ret..ruo.ARLdanHattgyicipCnUndNe"

    const-string v1, ".e.idonptrtCacUynntdirAHg.RaoNeL"

    const/4 v5, 0x2

    const-string/jumbo v1, "ndgLntepiCy.tad.EcUoa.rHANenoRit"

    const-string v1, "android.intent.category.LAUNCHER"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Intent;->hasCategory(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v1, "ELCBrCUoqH.e.ALEiyoq_aANrn.tttnaKgcAdRedi"

    const-string v1, "ALonay.cqgoi_Uden.ACKet.HrNAtatrRLEiEdnBC"

    const-string/jumbo v1, "tosKgLNCoiiAL.AACnNnete_rB.UcaEdynEr.RdaH"

    const-string v1, "android.intent.category.LEANBACK_LAUNCHER"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Intent;->hasCategory(Ljava/lang/String;)Z

    move-result p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz p0, :cond_3

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {p0, v2, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method
