.class Landroidx/core/app/m3;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/v;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/app/Notification$Builder;

.field private final c:Landroidx/core/app/x1$g;

.field private d:Landroid/widget/RemoteViews;

.field private e:Landroid/widget/RemoteViews;

.field private final f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroid/os/Bundle;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Landroid/os/Bundle;

.field private h:I

.field private i:Landroid/widget/RemoteViews;


# direct methods
.method constructor <init>(Landroidx/core/app/x1$g;)V
    .locals 14

    const/4 v13, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v13, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v13, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v13, 0x7

    iput-object v0, p0, Landroidx/core/app/m3;->f:Ljava/util/List;

    const/4 v13, 0x3

    new-instance v0, Landroid/os/Bundle;

    const/4 v13, 0x2

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v13, 0x3

    iput-object v0, p0, Landroidx/core/app/m3;->g:Landroid/os/Bundle;

    const/4 v13, 0x5

    iput-object p1, p0, Landroidx/core/app/m3;->c:Landroidx/core/app/x1$g;

    const/4 v13, 0x4

    iget-object v0, p1, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v13, 0x6

    iput-object v0, p0, Landroidx/core/app/m3;->a:Landroid/content/Context;

    const/4 v13, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v13, 0x1

    const/16 v1, 0x1a

    const/4 v13, 0x5

    if-lt v0, v1, :cond_0

    const/4 v13, 0x4

    invoke-static {}, Landroidx/core/app/c3;->a()V

    const/4 v13, 0x1

    iget-object v0, p1, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v13, 0x6

    iget-object v2, p1, Landroidx/core/app/x1$g;->L:Ljava/lang/String;

    const/4 v13, 0x3

    invoke-static {v0, v2}, Landroidx/core/app/b3;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v0

    const/4 v13, 0x5

    iput-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x7

    goto :goto_0

    :cond_0
    const/4 v13, 0x3

    new-instance v0, Landroid/app/Notification$Builder;

    const/4 v13, 0x4

    iget-object v2, p1, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v13, 0x0

    invoke-direct {v0, v2}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    const/4 v13, 0x3

    iput-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    :goto_0
    const/4 v13, 0x4

    iget-object v0, p1, Landroidx/core/app/x1$g;->U:Landroid/app/Notification;

    const/4 v13, 0x2

    iget-object v2, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    iget-wide v3, v0, Landroid/app/Notification;->when:J

    const/4 v13, 0x3

    invoke-virtual {v2, v3, v4}, Landroid/app/Notification$Builder;->setWhen(J)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x6

    iget v3, v0, Landroid/app/Notification;->icon:I

    const/4 v13, 0x4

    iget v4, v0, Landroid/app/Notification;->iconLevel:I

    const/4 v13, 0x6

    invoke-virtual {v2, v3, v4}, Landroid/app/Notification$Builder;->setSmallIcon(II)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x3

    iget-object v3, v0, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    const/4 v13, 0x3

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContent(Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x5

    iget-object v3, v0, Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;

    const/4 v13, 0x7

    iget-object v4, p1, Landroidx/core/app/x1$g;->i:Landroid/widget/RemoteViews;

    const/4 v13, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x4

    iget-object v3, v0, Landroid/app/Notification;->vibrate:[J

    const/4 v13, 0x6

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x3

    iget v3, v0, Landroid/app/Notification;->ledARGB:I

    const/4 v13, 0x2

    iget v4, v0, Landroid/app/Notification;->ledOnMS:I

    const/4 v13, 0x1

    iget v5, v0, Landroid/app/Notification;->ledOffMS:I

    const/4 v13, 0x1

    invoke-virtual {v2, v3, v4, v5}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x6

    iget v3, v0, Landroid/app/Notification;->flags:I

    const/4 v13, 0x4

    const/4 v4, 0x2

    and-int/2addr v3, v4

    const/4 v13, 0x4

    const/4 v5, 0x1

    const/4 v13, 0x6

    const/4 v6, 0x0

    const/4 v13, 0x4

    if-eqz v3, :cond_1

    const/4 v13, 0x2

    move v3, v5

    move v3, v5

    const/4 v13, 0x6

    goto :goto_1

    :cond_1
    const/4 v13, 0x2

    move v3, v6

    move v3, v6

    move v3, v6

    move v3, v6

    :goto_1
    const/4 v13, 0x4

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x6

    iget v3, v0, Landroid/app/Notification;->flags:I

    const/4 v13, 0x5

    and-int/lit8 v3, v3, 0x8

    const/4 v13, 0x0

    if-eqz v3, :cond_2

    const/4 v13, 0x1

    move v3, v5

    move v3, v5

    move v3, v5

    move v3, v5

    goto :goto_2

    :cond_2
    move v3, v6

    move v3, v6

    move v3, v6

    move v3, v6

    :goto_2
    const/4 v13, 0x0

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setOnlyAlertOnce(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x0

    iget v3, v0, Landroid/app/Notification;->flags:I

    const/4 v13, 0x0

    and-int/lit8 v3, v3, 0x10

    const/4 v13, 0x6

    if-eqz v3, :cond_3

    const/4 v13, 0x1

    move v3, v5

    move v3, v5

    move v3, v5

    move v3, v5

    const/4 v13, 0x3

    goto :goto_3

    :cond_3
    const/4 v13, 0x2

    move v3, v6

    move v3, v6

    move v3, v6

    move v3, v6

    :goto_3
    const/4 v13, 0x2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x0

    iget v3, v0, Landroid/app/Notification;->defaults:I

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x7

    iget-object v3, p1, Landroidx/core/app/x1$g;->e:Ljava/lang/CharSequence;

    const/4 v13, 0x5

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x0

    iget-object v3, p1, Landroidx/core/app/x1$g;->f:Ljava/lang/CharSequence;

    const/4 v13, 0x0

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x4

    iget-object v3, p1, Landroidx/core/app/x1$g;->k:Ljava/lang/CharSequence;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentInfo(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x3

    iget-object v3, p1, Landroidx/core/app/x1$g;->g:Landroid/app/PendingIntent;

    const/4 v13, 0x2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x0

    iget-object v3, v0, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    const/4 v13, 0x5

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setDeleteIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x6

    iget-object v3, p1, Landroidx/core/app/x1$g;->h:Landroid/app/PendingIntent;

    const/4 v13, 0x2

    iget v7, v0, Landroid/app/Notification;->flags:I

    const/4 v13, 0x3

    and-int/lit16 v7, v7, 0x80

    const/4 v13, 0x1

    if-eqz v7, :cond_4

    const/4 v13, 0x7

    move v7, v5

    move v7, v5

    move v7, v5

    move v7, v5

    const/4 v13, 0x7

    goto :goto_4

    :cond_4
    const/4 v13, 0x3

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    :goto_4
    const/4 v13, 0x4

    invoke-virtual {v2, v3, v7}, Landroid/app/Notification$Builder;->setFullScreenIntent(Landroid/app/PendingIntent;Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x6

    iget-object v3, p1, Landroidx/core/app/x1$g;->j:Landroid/graphics/Bitmap;

    const/4 v13, 0x6

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x7

    iget v3, p1, Landroidx/core/app/x1$g;->l:I

    const/4 v13, 0x0

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setNumber(I)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x2

    iget v3, p1, Landroidx/core/app/x1$g;->u:I

    iget v7, p1, Landroidx/core/app/x1$g;->v:I

    const/4 v13, 0x3

    iget-boolean v8, p1, Landroidx/core/app/x1$g;->w:Z

    const/4 v13, 0x5

    invoke-virtual {v2, v3, v7, v8}, Landroid/app/Notification$Builder;->setProgress(IIZ)Landroid/app/Notification$Builder;

    const/4 v13, 0x1

    iget-object v2, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x6

    iget-object v3, p1, Landroidx/core/app/x1$g;->r:Ljava/lang/CharSequence;

    const/4 v13, 0x2

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setSubText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x7

    iget-boolean v3, p1, Landroidx/core/app/x1$g;->o:Z

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setUsesChronometer(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v13, 0x1

    iget v3, p1, Landroidx/core/app/x1$g;->m:I

    const/4 v13, 0x5

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    const/4 v13, 0x6

    iget-object v2, p1, Landroidx/core/app/x1$g;->b:Ljava/util/ArrayList;

    const/4 v13, 0x6

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_5
    const/4 v13, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v13, 0x0

    if-eqz v3, :cond_5

    const/4 v13, 0x7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v13, 0x5

    check-cast v3, Landroidx/core/app/x1$b;

    const/4 v13, 0x7

    invoke-direct {p0, v3}, Landroidx/core/app/m3;->b(Landroidx/core/app/x1$b;)V

    const/4 v13, 0x1

    goto :goto_5

    :cond_5
    const/4 v13, 0x0

    iget-object v2, p1, Landroidx/core/app/x1$g;->E:Landroid/os/Bundle;

    const/4 v13, 0x0

    if-eqz v2, :cond_6

    const/4 v13, 0x0

    iget-object v3, p0, Landroidx/core/app/m3;->g:Landroid/os/Bundle;

    const/4 v13, 0x3

    invoke-virtual {v3, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    :cond_6
    const/4 v13, 0x3

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v13, 0x1

    iget-object v3, p1, Landroidx/core/app/x1$g;->I:Landroid/widget/RemoteViews;

    iput-object v3, p0, Landroidx/core/app/m3;->d:Landroid/widget/RemoteViews;

    const/4 v13, 0x0

    iget-object v3, p1, Landroidx/core/app/x1$g;->J:Landroid/widget/RemoteViews;

    const/4 v13, 0x0

    iput-object v3, p0, Landroidx/core/app/m3;->e:Landroid/widget/RemoteViews;

    const/4 v13, 0x4

    iget-object v3, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x4

    iget-boolean v7, p1, Landroidx/core/app/x1$g;->n:Z

    const/4 v13, 0x1

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    iget-object v3, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x5

    iget-boolean v7, p1, Landroidx/core/app/x1$g;->A:Z

    const/4 v13, 0x7

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setLocalOnly(Z)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x7

    iget-object v7, p1, Landroidx/core/app/x1$g;->x:Ljava/lang/String;

    const/4 v13, 0x0

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setGroup(Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x5

    iget-boolean v7, p1, Landroidx/core/app/x1$g;->y:Z

    const/4 v13, 0x0

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setGroupSummary(Z)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x1

    iget-object v7, p1, Landroidx/core/app/x1$g;->z:Ljava/lang/String;

    const/4 v13, 0x0

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setSortKey(Ljava/lang/String;)Landroid/app/Notification$Builder;

    const/4 v13, 0x1

    iget v3, p1, Landroidx/core/app/x1$g;->Q:I

    const/4 v13, 0x7

    iput v3, p0, Landroidx/core/app/m3;->h:I

    const/4 v13, 0x5

    iget-object v3, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x7

    iget-object v7, p1, Landroidx/core/app/x1$g;->D:Ljava/lang/String;

    const/4 v13, 0x1

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x2

    iget v7, p1, Landroidx/core/app/x1$g;->F:I

    const/4 v13, 0x0

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setColor(I)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x5

    iget v7, p1, Landroidx/core/app/x1$g;->G:I

    const/4 v13, 0x3

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setVisibility(I)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x5

    iget-object v7, p1, Landroidx/core/app/x1$g;->H:Landroid/app/Notification;

    const/4 v13, 0x0

    invoke-virtual {v3, v7}, Landroid/app/Notification$Builder;->setPublicVersion(Landroid/app/Notification;)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v13, 0x5

    iget-object v7, v0, Landroid/app/Notification;->sound:Landroid/net/Uri;

    const/4 v13, 0x4

    iget-object v8, v0, Landroid/app/Notification;->audioAttributes:Landroid/media/AudioAttributes;

    const/4 v13, 0x4

    invoke-virtual {v3, v7, v8}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)Landroid/app/Notification$Builder;

    const/4 v13, 0x3

    const/16 v3, 0x1c

    if-ge v2, v3, :cond_7

    iget-object v2, p1, Landroidx/core/app/x1$g;->c:Ljava/util/ArrayList;

    const/4 v13, 0x6

    invoke-static {v2}, Landroidx/core/app/m3;->g(Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    const/4 v13, 0x2

    iget-object v7, p1, Landroidx/core/app/x1$g;->X:Ljava/util/ArrayList;

    const/4 v13, 0x0

    invoke-static {v2, v7}, Landroidx/core/app/m3;->e(Ljava/util/List;Ljava/util/List;)Ljava/util/List;

    move-result-object v2

    const/4 v13, 0x4

    goto :goto_6

    :cond_7
    const/4 v13, 0x1

    iget-object v2, p1, Landroidx/core/app/x1$g;->X:Ljava/util/ArrayList;

    :goto_6
    const/4 v13, 0x3

    if-eqz v2, :cond_8

    const/4 v13, 0x5

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v7

    const/4 v13, 0x2

    if-nez v7, :cond_8

    const/4 v13, 0x1

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_7
    const/4 v13, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    const/4 v13, 0x4

    if-eqz v7, :cond_8

    const/4 v13, 0x6

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    const/4 v13, 0x4

    check-cast v7, Ljava/lang/String;

    const/4 v13, 0x1

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x5

    invoke-virtual {v8, v7}, Landroid/app/Notification$Builder;->addPerson(Ljava/lang/String;)Landroid/app/Notification$Builder;

    const/4 v13, 0x6

    goto :goto_7

    :cond_8
    const/4 v13, 0x6

    iget-object v2, p1, Landroidx/core/app/x1$g;->K:Landroid/widget/RemoteViews;

    const/4 v13, 0x7

    iput-object v2, p0, Landroidx/core/app/m3;->i:Landroid/widget/RemoteViews;

    const/4 v13, 0x5

    iget-object v2, p1, Landroidx/core/app/x1$g;->d:Ljava/util/ArrayList;

    const/4 v13, 0x2

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v13, 0x0

    if-lez v2, :cond_b

    const/4 v13, 0x2

    invoke-virtual {p1}, Landroidx/core/app/x1$g;->t()Landroid/os/Bundle;

    move-result-object v2

    const-string v7, "IEsrSaNnocTOXdi.SasEr."

    const-string v7, "XEsoOTa.icSanNrEISN.rd"

    const-string/jumbo v7, "raomNdTdNcEnSISO.iEr.a"

    const-string v7, "android.car.EXTENSIONS"

    const/4 v13, 0x5

    invoke-virtual {v2, v7}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    const/4 v13, 0x6

    if-nez v2, :cond_9

    const/4 v13, 0x1

    new-instance v2, Landroid/os/Bundle;

    const/4 v13, 0x3

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    :cond_9
    const/4 v13, 0x3

    new-instance v8, Landroid/os/Bundle;

    const/4 v13, 0x5

    invoke-direct {v8, v2}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v13, 0x6

    new-instance v9, Landroid/os/Bundle;

    const/4 v13, 0x2

    invoke-direct {v9}, Landroid/os/Bundle;-><init>()V

    const/4 v13, 0x3

    move v10, v6

    move v10, v6

    move v10, v6

    move v10, v6

    :goto_8
    iget-object v11, p1, Landroidx/core/app/x1$g;->d:Ljava/util/ArrayList;

    const/4 v13, 0x4

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v11

    const/4 v13, 0x0

    if-ge v10, v11, :cond_a

    const/4 v13, 0x1

    invoke-static {v10}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v13, 0x7

    iget-object v12, p1, Landroidx/core/app/x1$g;->d:Ljava/util/ArrayList;

    const/4 v13, 0x3

    invoke-virtual {v12, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    const/4 v13, 0x1

    check-cast v12, Landroidx/core/app/x1$b;

    const/4 v13, 0x5

    invoke-static {v12}, Landroidx/core/app/o3;->j(Landroidx/core/app/x1$b;)Landroid/os/Bundle;

    move-result-object v12

    const/4 v13, 0x6

    invoke-virtual {v9, v11, v12}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v13, 0x0

    add-int/lit8 v10, v10, 0x1

    const/4 v13, 0x3

    goto :goto_8

    :cond_a
    const/4 v13, 0x2

    const-string/jumbo v10, "nelboiniaviotsmsc"

    const-string v10, "cs_mtainenoiisvlb"

    const-string/jumbo v10, "ibevnblcis_ointai"

    const-string/jumbo v10, "invisible_actions"

    const/4 v13, 0x5

    invoke-virtual {v2, v10, v9}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v13, 0x1

    invoke-virtual {v8, v10, v9}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v13, 0x2

    invoke-virtual {p1}, Landroidx/core/app/x1$g;->t()Landroid/os/Bundle;

    move-result-object v9

    const/4 v13, 0x0

    invoke-virtual {v9, v7, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v13, 0x5

    iget-object v2, p0, Landroidx/core/app/m3;->g:Landroid/os/Bundle;

    const/4 v13, 0x3

    invoke-virtual {v2, v7, v8}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_b
    const/4 v13, 0x0

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v13, 0x3

    iget-object v7, p1, Landroidx/core/app/x1$g;->W:Landroid/graphics/drawable/Icon;

    const/4 v13, 0x5

    if-eqz v7, :cond_c

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x1

    invoke-virtual {v8, v7}, Landroid/app/Notification$Builder;->setSmallIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Notification$Builder;

    :cond_c
    const/4 v13, 0x0

    const/16 v7, 0x18

    const/4 v13, 0x7

    if-lt v2, v7, :cond_f

    const/4 v13, 0x7

    iget-object v7, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x6

    iget-object v8, p1, Landroidx/core/app/x1$g;->E:Landroid/os/Bundle;

    const/4 v13, 0x2

    invoke-virtual {v7, v8}, Landroid/app/Notification$Builder;->setExtras(Landroid/os/Bundle;)Landroid/app/Notification$Builder;

    move-result-object v7

    const/4 v13, 0x5

    iget-object v8, p1, Landroidx/core/app/x1$g;->t:[Ljava/lang/CharSequence;

    const/4 v13, 0x3

    invoke-static {v7, v8}, Landroidx/core/app/e3;->a(Landroid/app/Notification$Builder;[Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    const/4 v13, 0x6

    iget-object v7, p1, Landroidx/core/app/x1$g;->I:Landroid/widget/RemoteViews;

    const/4 v13, 0x3

    if-eqz v7, :cond_d

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x2

    invoke-static {v8, v7}, Landroidx/core/app/l3;->a(Landroid/app/Notification$Builder;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    :cond_d
    const/4 v13, 0x4

    iget-object v7, p1, Landroidx/core/app/x1$g;->J:Landroid/widget/RemoteViews;

    const/4 v13, 0x2

    if-eqz v7, :cond_e

    const/4 v13, 0x2

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x2

    invoke-static {v8, v7}, Landroidx/core/app/u2;->a(Landroid/app/Notification$Builder;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    :cond_e
    const/4 v13, 0x4

    iget-object v7, p1, Landroidx/core/app/x1$g;->K:Landroid/widget/RemoteViews;

    const/4 v13, 0x0

    if-eqz v7, :cond_f

    const/4 v13, 0x3

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x0

    invoke-static {v8, v7}, Landroidx/core/app/v2;->a(Landroid/app/Notification$Builder;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    :cond_f
    const/4 v13, 0x4

    const/4 v7, 0x0

    const/4 v13, 0x6

    if-lt v2, v1, :cond_11

    const/4 v13, 0x0

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x3

    iget v9, p1, Landroidx/core/app/x1$g;->M:I

    const/4 v13, 0x3

    invoke-static {v8, v9}, Landroidx/core/app/w2;->a(Landroid/app/Notification$Builder;I)Landroid/app/Notification$Builder;

    move-result-object v8

    const/4 v13, 0x2

    iget-object v9, p1, Landroidx/core/app/x1$g;->s:Ljava/lang/CharSequence;

    const/4 v13, 0x4

    invoke-static {v8, v9}, Landroidx/core/app/x2;->a(Landroid/app/Notification$Builder;Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    const/4 v13, 0x0

    iget-object v9, p1, Landroidx/core/app/x1$g;->N:Ljava/lang/String;

    const/4 v13, 0x3

    invoke-static {v8, v9}, Landroidx/core/app/y2;->a(Landroid/app/Notification$Builder;Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v8

    const/4 v13, 0x5

    iget-wide v9, p1, Landroidx/core/app/x1$g;->P:J

    const/4 v13, 0x5

    invoke-static {v8, v9, v10}, Landroidx/core/app/z2;->a(Landroid/app/Notification$Builder;J)Landroid/app/Notification$Builder;

    move-result-object v8

    const/4 v13, 0x2

    iget v9, p1, Landroidx/core/app/x1$g;->Q:I

    const/4 v13, 0x3

    invoke-static {v8, v9}, Landroidx/core/app/k3;->a(Landroid/app/Notification$Builder;I)Landroid/app/Notification$Builder;

    const/4 v13, 0x2

    iget-boolean v8, p1, Landroidx/core/app/x1$g;->C:Z

    const/4 v13, 0x3

    if-eqz v8, :cond_10

    const/4 v13, 0x7

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x1

    iget-boolean v9, p1, Landroidx/core/app/x1$g;->B:Z

    const/4 v13, 0x7

    invoke-static {v8, v9}, Landroidx/core/app/a3;->a(Landroid/app/Notification$Builder;Z)Landroid/app/Notification$Builder;

    :cond_10
    const/4 v13, 0x4

    iget-object v8, p1, Landroidx/core/app/x1$g;->L:Ljava/lang/String;

    const/4 v13, 0x4

    invoke-static {v8}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v13, 0x0

    if-nez v8, :cond_11

    const/4 v13, 0x2

    iget-object v8, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x1

    invoke-virtual {v8, v7}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;)Landroid/app/Notification$Builder;

    move-result-object v8

    const/4 v13, 0x1

    invoke-virtual {v8, v6}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v8

    const/4 v13, 0x0

    invoke-virtual {v8, v6, v6, v6}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;

    move-result-object v6

    const/4 v13, 0x7

    invoke-virtual {v6, v7}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    :cond_11
    const/4 v13, 0x7

    if-lt v2, v3, :cond_12

    iget-object v2, p1, Landroidx/core/app/x1$g;->c:Ljava/util/ArrayList;

    const/4 v13, 0x6

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_9
    const/4 v13, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v13, 0x7

    if-eqz v3, :cond_12

    const/4 v13, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v13, 0x7

    check-cast v3, Landroidx/core/app/f4;

    const/4 v13, 0x5

    iget-object v6, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x5

    invoke-virtual {v3}, Landroidx/core/app/f4;->k()Landroid/app/Person;

    move-result-object v3

    const/4 v13, 0x2

    invoke-static {v6, v3}, Landroidx/core/app/f3;->a(Landroid/app/Notification$Builder;Landroid/app/Person;)Landroid/app/Notification$Builder;

    goto :goto_9

    :cond_12
    const/4 v13, 0x7

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v13, 0x7

    const/16 v3, 0x1d

    const/4 v13, 0x3

    if-lt v2, v3, :cond_13

    const/4 v13, 0x6

    iget-object v3, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x7

    iget-boolean v6, p1, Landroidx/core/app/x1$g;->S:Z

    const/4 v13, 0x4

    invoke-static {v3, v6}, Landroidx/core/app/g3;->a(Landroid/app/Notification$Builder;Z)Landroid/app/Notification$Builder;

    const/4 v13, 0x5

    iget-object v3, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x0

    iget-object v6, p1, Landroidx/core/app/x1$g;->T:Landroidx/core/app/x1$f;

    const/4 v13, 0x3

    invoke-static {v6}, Landroidx/core/app/x1$f;->k(Landroidx/core/app/x1$f;)Landroid/app/Notification$BubbleMetadata;

    move-result-object v6

    const/4 v13, 0x5

    invoke-static {v3, v6}, Landroidx/core/app/h3;->a(Landroid/app/Notification$Builder;Landroid/app/Notification$BubbleMetadata;)Landroid/app/Notification$Builder;

    const/4 v13, 0x7

    iget-object v3, p1, Landroidx/core/app/x1$g;->O:Landroidx/core/content/g;

    const/4 v13, 0x4

    if-eqz v3, :cond_13

    const/4 v13, 0x6

    iget-object v6, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x3

    invoke-virtual {v3}, Landroidx/core/content/g;->c()Landroid/content/LocusId;

    move-result-object v3

    const/4 v13, 0x4

    invoke-static {v6, v3}, Landroidx/core/app/i3;->a(Landroid/app/Notification$Builder;Landroid/content/LocusId;)Landroid/app/Notification$Builder;

    :cond_13
    const/4 v13, 0x6

    const/16 v3, 0x1f

    const/4 v13, 0x7

    if-lt v2, v3, :cond_14

    const/4 v13, 0x4

    iget v3, p1, Landroidx/core/app/x1$g;->R:I

    const/4 v13, 0x5

    if-eqz v3, :cond_14

    iget-object v6, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x2

    invoke-static {v6, v3}, Landroidx/core/app/j3;->a(Landroid/app/Notification$Builder;I)Landroid/app/Notification$Builder;

    :cond_14
    iget-boolean p1, p1, Landroidx/core/app/x1$g;->V:Z

    const/4 v13, 0x3

    if-eqz p1, :cond_17

    const/4 v13, 0x6

    iget-object p1, p0, Landroidx/core/app/m3;->c:Landroidx/core/app/x1$g;

    const/4 v13, 0x1

    iget-boolean p1, p1, Landroidx/core/app/x1$g;->y:Z

    const/4 v13, 0x2

    if-eqz p1, :cond_15

    iput v4, p0, Landroidx/core/app/m3;->h:I

    goto :goto_a

    :cond_15
    const/4 v13, 0x6

    iput v5, p0, Landroidx/core/app/m3;->h:I

    :goto_a
    const/4 v13, 0x5

    iget-object p1, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x0

    invoke-virtual {p1, v7}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    const/4 v13, 0x6

    iget-object p1, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x1

    invoke-virtual {p1, v7}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;)Landroid/app/Notification$Builder;

    const/4 v13, 0x3

    iget p1, v0, Landroid/app/Notification;->defaults:I

    const/4 v13, 0x5

    and-int/lit8 p1, p1, -0x2

    const/4 v13, 0x5

    and-int/lit8 p1, p1, -0x3

    iput p1, v0, Landroid/app/Notification;->defaults:I

    const/4 v13, 0x2

    iget-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x3

    invoke-virtual {v0, p1}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    const/4 v13, 0x7

    if-lt v2, v1, :cond_17

    const/4 v13, 0x1

    iget-object p1, p0, Landroidx/core/app/m3;->c:Landroidx/core/app/x1$g;

    const/4 v13, 0x4

    iget-object p1, p1, Landroidx/core/app/x1$g;->x:Ljava/lang/String;

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v13, 0x1

    if-eqz p1, :cond_16

    iget-object p1, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v13, 0x3

    const-string/jumbo v0, "usinlo"

    const-string/jumbo v0, "nlisot"

    const-string/jumbo v0, "spentl"

    const-string/jumbo v0, "silent"

    const/4 v13, 0x1

    invoke-virtual {p1, v0}, Landroid/app/Notification$Builder;->setGroup(Ljava/lang/String;)Landroid/app/Notification$Builder;

    :cond_16
    iget-object p1, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    iget v0, p0, Landroidx/core/app/m3;->h:I

    const/4 v13, 0x3

    invoke-static {p1, v0}, Landroidx/core/app/k3;->a(Landroid/app/Notification$Builder;I)Landroid/app/Notification$Builder;

    :cond_17
    const/4 v13, 0x2

    return-void
.end method

.method private b(Landroidx/core/app/x1$b;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~ cy@@@ q@~@oK @@o~ b.@4 M@~t~@@t@lbf-du@ ~ minr~S~@oi~/~ /ol@b@ v~~@~ ~ so~@~~@ ~o @ if~~~a ~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->f()Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v1, Landroid/app/Notification$Action$Builder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroidx/core/graphics/drawable/IconCompat;->L()Landroid/graphics/drawable/Icon;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    move v6, v5

    const/4 v0, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->j()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->a()Landroid/app/PendingIntent;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v1, v0, v2, v3}, Landroid/app/Notification$Action$Builder;-><init>(Landroid/graphics/drawable/Icon;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->g()[Landroidx/core/app/h4;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->g()[Landroidx/core/app/h4;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0}, Landroidx/core/app/h4;->d([Landroidx/core/app/h4;)[Landroid/app/RemoteInput;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    array-length v2, v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v3, 0x0

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ge v3, v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    aget-object v4, v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v4}, Landroid/app/Notification$Action$Builder;->addRemoteInput(Landroid/app/RemoteInput;)Landroid/app/Notification$Action$Builder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, v2}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_2

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v0, Landroid/os/Bundle;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v2, "lesprdiwotoasspdpo.ientaGbeRrl.lrunda"

    const-string/jumbo v2, "tsnorbelrdRpnawuaetiodiledGe..lpospar"

    const/4 v6, 0x3

    const-string/jumbo v2, "oaGmoRltwrntrpneapdplsroel.i.suadedei"

    const-string v2, "android.support.allowGeneratedReplies"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->b()Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x5

    move v6, v5

    const/16 v3, 0x18

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-lt v2, v3, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->b()Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v3}, Landroidx/core/app/r2;->a(Landroid/app/Notification$Action$Builder;Z)Landroid/app/Notification$Action$Builder;

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v3, "pctnoonerdini.iAooaucaoistttcna.rumdp"

    const-string/jumbo v3, "ondinau.cdooipnmccetuisAttrnpot.riaas"

    const/4 v6, 0x3

    const-string v3, "adt.obp.mntcironstdureotaincc.iAnsaoi"

    const-string v3, "android.support.action.semanticAction"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->h()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v3, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/16 v3, 0x1c

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-lt v2, v3, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->h()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v1, v3}, Landroidx/core/app/t2;->a(Landroid/app/Notification$Action$Builder;I)Landroid/app/Notification$Action$Builder;

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/16 v3, 0x1d

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-lt v2, v3, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->l()Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v1, v3}, Landroidx/core/app/d3;->a(Landroid/app/Notification$Action$Builder;Z)Landroid/app/Notification$Action$Builder;

    :cond_5
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/16 v3, 0x1f

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    if-lt v2, v3, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->k()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v1, v2}, Landroidx/core/app/s2;->a(Landroid/app/Notification$Action$Builder;Z)Landroid/app/Notification$Action$Builder;

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x0

    const-string v2, "dUs.nruwophu.sctod.rranosfoipniarescIttpe"

    const-string/jumbo v2, "o.enapppdfiswoiosetrt.tcnIrs.oUruharcdsne"

    const/4 v6, 0x7

    const-string/jumbo v2, "tpId.rcpntwes.ooruedesr.oatrsinapscaioUfh"

    const-string v2, "android.support.action.showsUserInterface"

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->i()Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v2, p1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v6, 0x4

    invoke-virtual {v1, v0}, Landroid/app/Notification$Action$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/Notification$Action$Builder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object p1, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/app/Notification$Action$Builder;->build()Landroid/app/Notification$Action;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Landroid/app/Notification$Builder;->addAction(Landroid/app/Notification$Action;)Landroid/app/Notification$Builder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-void
.end method

.method private static e(Ljava/util/List;Ljava/util/List;)Ljava/util/List;
    .locals 5
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez p0, :cond_0

    const/4 v4, 0x1

    return-object p1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Landroidx/collection/c;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    add-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroidx/collection/c;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Landroidx/collection/c;->addAll(Ljava/util/Collection;)Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Landroidx/collection/c;->addAll(Ljava/util/Collection;)Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance p0, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x1

    return-object p0
.end method

.method private static g(Ljava/util/List;)Ljava/util/List;
    .locals 4
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/core/app/f4;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v1, Landroidx/core/app/f4;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v1}, Landroidx/core/app/f4;->j()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method private h(Landroid/app/Notification;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p1, Landroid/app/Notification;->sound:Landroid/net/Uri;

    const/4 v2, 0x5

    iput-object v0, p1, Landroid/app/Notification;->vibrate:[J

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    iget v0, p1, Landroid/app/Notification;->defaults:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p1, Landroid/app/Notification;->defaults:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()Landroid/app/Notification$Builder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public c()Landroid/app/Notification;
    .locals 5

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/core/app/m3;->c:Landroidx/core/app/x1$g;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, v0, Landroidx/core/app/x1$g;->q:Landroidx/core/app/x1$q;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$q;->b(Landroidx/core/app/v;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$q;->w(Landroidx/core/app/v;)Landroid/widget/RemoteViews;

    move-result-object v1

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    move v4, v1

    :goto_0
    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p0}, Landroidx/core/app/m3;->d()Landroid/app/Notification;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v1, v2, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Landroidx/core/app/m3;->c:Landroidx/core/app/x1$g;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, v1, Landroidx/core/app/x1$g;->I:Landroid/widget/RemoteViews;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v1, v2, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    :cond_3
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$q;->v(Landroidx/core/app/v;)Landroid/widget/RemoteViews;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v1, :cond_4

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v1, v2, Landroid/app/Notification;->bigContentView:Landroid/widget/RemoteViews;

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Landroidx/core/app/m3;->c:Landroidx/core/app/x1$g;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, v1, Landroidx/core/app/x1$g;->q:Landroidx/core/app/x1$q;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Landroidx/core/app/x1$q;->x(Landroidx/core/app/v;)Landroid/widget/RemoteViews;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v1, :cond_5

    const/4 v3, 0x6

    const/4 v3, 0x5

    iput-object v1, v2, Landroid/app/Notification;->headsUpContentView:Landroid/widget/RemoteViews;

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v2}, Landroidx/core/app/x1;->n(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroidx/core/app/x1$q;->a(Landroid/os/Bundle;)V

    :cond_6
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v2
.end method

.method protected d()Landroid/app/Notification;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/16 v1, 0x1a

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-lt v0, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/16 v1, 0x18

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v3, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-lt v0, v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v1, p0, Landroidx/core/app/m3;->h:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/app/Notification;->getGroup()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v1, v0, Landroid/app/Notification;->flags:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    and-int/lit16 v1, v1, 0x200

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v1, p0, Landroidx/core/app/m3;->h:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    if-ne v1, v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0, v0}, Landroidx/core/app/m3;->h(Landroid/app/Notification;)V

    :cond_1
    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/app/Notification;->getGroup()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    iget v1, v0, Landroid/app/Notification;->flags:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-int/lit16 v1, v1, 0x200

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget v1, p0, Landroidx/core/app/m3;->h:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-ne v1, v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, v0}, Landroidx/core/app/m3;->h(Landroid/app/Notification;)V

    :cond_2
    const/4 v5, 0x2

    return-object v0

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Landroidx/core/app/m3;->g:Landroid/os/Bundle;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setExtras(Landroid/os/Bundle;)Landroid/app/Notification$Builder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/core/app/m3;->b:Landroid/app/Notification$Builder;

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Landroidx/core/app/m3;->d:Landroid/widget/RemoteViews;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-object v1, v0, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Landroidx/core/app/m3;->e:Landroid/widget/RemoteViews;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iput-object v1, v0, Landroid/app/Notification;->bigContentView:Landroid/widget/RemoteViews;

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, p0, Landroidx/core/app/m3;->i:Landroid/widget/RemoteViews;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v1, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v1, v0, Landroid/app/Notification;->headsUpContentView:Landroid/widget/RemoteViews;

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v1, p0, Landroidx/core/app/m3;->h:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v1, :cond_8

    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/app/Notification;->getGroup()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v1, :cond_7

    const/4 v4, 0x6

    move v5, v4

    iget v1, v0, Landroid/app/Notification;->flags:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    and-int/lit16 v1, v1, 0x200

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v1, p0, Landroidx/core/app/m3;->h:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ne v1, v3, :cond_7

    const/4 v5, 0x5

    invoke-direct {p0, v0}, Landroidx/core/app/m3;->h(Landroid/app/Notification;)V

    :cond_7
    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v0}, Landroid/app/Notification;->getGroup()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x0

    iget v1, v0, Landroid/app/Notification;->flags:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    and-int/lit16 v1, v1, 0x200

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v1, p0, Landroidx/core/app/m3;->h:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ne v1, v2, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p0, v0}, Landroidx/core/app/m3;->h(Landroid/app/Notification;)V

    :cond_8
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object v0
.end method

.method f()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/m3;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method
