.class public final synthetic Landroidx/core/app/i2;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Landroid/app/Person;)Landroid/app/Notification$MessagingStyle;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "cos@~~b u~tf~@ ~@S~oiio @@-~/~~~@sK@oa@ v~  m~ ~4~~~@@~ M@@~   @@fob@~@ ~d @l.oi~@y/n1b@ @   ltr"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Landroid/app/Notification$MessagingStyle;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Landroid/app/Notification$MessagingStyle;-><init>(Landroid/app/Person;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method
