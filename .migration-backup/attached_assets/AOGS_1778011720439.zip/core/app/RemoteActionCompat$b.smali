.class Landroidx/core/app/RemoteActionCompat$b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1c
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/RemoteActionCompat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method static a(Landroid/app/RemoteAction;Z)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b s~~~-@drl~ @4Ki ~~@fom @~Mb~~~~~~~@~1 o@oo ul ~ s@yo~@ S @ @a@@ic~~~@i~fn@/   @@  @@/o@~t@. bt"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0, p1}, Landroid/app/RemoteAction;->setShouldShowIcon(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method static b(Landroid/app/RemoteAction;)Z
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/RemoteAction;->shouldShowIcon()Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p0
.end method
