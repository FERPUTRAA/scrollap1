.class public final synthetic Landroidx/core/app/u0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/~s cif@@@~K~.~tl @-~@4@~avyb@io@~ @   ~~otn@~@  ~~~@~~o1m~f S/ b so~@d  oi@u o@~@ ~~@~@@ lb ~Mr"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->canBubble()Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return p0
.end method
