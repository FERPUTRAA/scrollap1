.class public final synthetic Landroidx/core/app/p0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)[J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s~1@b@~~@~~ t@dn@S~ ~ t io ~o@~K~oy/ i.o fil~~ lou @@@~b@b/~~@-~o @@s@@~ @ a @ ~~M@~f4~@ ~vrm@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->getVibrationPattern()[J

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method
