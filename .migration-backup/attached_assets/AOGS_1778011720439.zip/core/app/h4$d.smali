.class Landroidx/core/app/h4$d;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1c
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/h4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "d"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    return-void
.end method

.method static a(Landroid/content/Intent;)I
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i@sb@f@~cv@o@ oiK~~~ ~~~ud@io  lo  @~ @14@~o @t@s@~nb r-@~~@ l@~~my ~~@~/@ @ tf~M.   /a ~~S@~o@b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0}, Landroid/app/RemoteInput;->getResultsSource(Landroid/content/Intent;)I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p0
.end method

.method static b(Landroid/content/Intent;I)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0, p1}, Landroid/app/RemoteInput;->setResultsSource(Landroid/content/Intent;I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
