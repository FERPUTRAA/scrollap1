.class final Landroidx/core/app/JobIntentService$f$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/JobIntentService$e;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService$f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x10
    name = "a"
.end annotation


# instance fields
.field final a:Landroid/app/job/JobWorkItem;

.field final synthetic b:Landroidx/core/app/JobIntentService$f;


# direct methods
.method constructor <init>(Landroidx/core/app/JobIntentService$f;Landroid/app/job/JobWorkItem;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/JobIntentService$f$a;->b:Landroidx/core/app/JobIntentService$f;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Landroidx/core/app/JobIntentService$f$a;->a:Landroid/app/job/JobWorkItem;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " tsl~~~ovicy@a .  @ @@b~s@~~~@@-b~o~M@nu bt@@  iK1dm@~ f4@~fo@@~~o@~o ~i~/ro ~/@@~ @l~@   S~ @~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/core/app/JobIntentService$f$a;->b:Landroidx/core/app/JobIntentService$f;

    const/4 v4, 0x6

    const/4 v3, 0x2

    iget-object v0, v0, Landroidx/core/app/JobIntentService$f;->b:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    move v4, v3

    iget-object v1, p0, Landroidx/core/app/JobIntentService$f$a;->b:Landroidx/core/app/JobIntentService$f;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v1, v1, Landroidx/core/app/JobIntentService$f;->c:Landroid/app/job/JobParameters;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    move v4, v3

    iget-object v2, p0, Landroidx/core/app/JobIntentService$f$a;->a:Landroid/app/job/JobWorkItem;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v1, v2}, Landroidx/core/app/q;->a(Landroid/app/job/JobParameters;Landroid/app/job/JobWorkItem;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit v0

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw v1
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/JobIntentService$f$a;->a:Landroid/app/job/JobWorkItem;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Landroidx/core/app/p;->a(Landroid/app/job/JobWorkItem;)Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object v0
.end method
