.class Landroidx/core/app/g$a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method

.method static a(Landroid/app/AlarmManager;IJLandroid/app/PendingIntent;)V
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~st~i  o n @~tu~~ @@l@yl~ ~@@ ob @ @~~~M@~ of/@vc K@m~  ~1@~i@s@~@foSa i@ -@~/~~@o@ .d~b~4r ~@b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3, p4}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
