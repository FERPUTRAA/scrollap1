.class public Landroidx/core/app/h1$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/h1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field final a:Landroidx/core/app/h1;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Landroidx/core/app/h1;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Landroidx/core/app/h1;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/h1$a;->a:Landroidx/core/app/h1;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a()Landroidx/core/app/h1;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/core/app/h1$a;->a:Landroidx/core/app/h1;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object v0
.end method

.method public b(Ljava/lang/String;)Landroidx/core/app/h1$a;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/h1$a;->a:Landroidx/core/app/h1;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, v0, Landroidx/core/app/h1;->c:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public c(Ljava/lang/CharSequence;)Landroidx/core/app/h1$a;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/h1$a;->a:Landroidx/core/app/h1;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, v0, Landroidx/core/app/h1;->b:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method
