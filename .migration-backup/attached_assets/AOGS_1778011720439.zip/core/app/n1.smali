.class public final synthetic Landroidx/core/app/n1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification;)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ts@~io mn@~ @~@~ i~y~@~~l@ u~o~o @v~i@S@ ~@b@~ @.@@Mbfdc    1~l@o~-@r~ ofo~@ ~@a~s @@4~K ~/bt/ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/app/Notification;->getTimeoutAfter()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-wide v0
.end method
