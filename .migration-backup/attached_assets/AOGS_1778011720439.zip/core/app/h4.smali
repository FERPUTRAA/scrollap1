.class public final Landroidx/core/app/h4;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/h4$d;,
        Landroidx/core/app/h4$e;,
        Landroidx/core/app/h4$a;,
        Landroidx/core/app/h4$b;,
        Landroidx/core/app/h4$c;,
        Landroidx/core/app/h4$f;,
        Landroidx/core/app/h4$g;,
        Landroidx/core/app/h4$h;
    }
.end annotation


# static fields
.field public static final h:Ljava/lang/String; = "android.remoteinput.results"

.field public static final i:Ljava/lang/String; = "android.remoteinput.resultsData"

.field private static final j:Ljava/lang/String; = "android.remoteinput.dataTypeResultsData"

.field private static final k:Ljava/lang/String; = "android.remoteinput.resultsSource"

.field public static final l:I = 0x0

.field public static final m:I = 0x1

.field public static final n:I = 0x0

.field public static final o:I = 0x1

.field public static final p:I = 0x2


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/lang/CharSequence;

.field private final c:[Ljava/lang/CharSequence;

.field private final d:Z

.field private final e:I

.field private final f:Landroid/os/Bundle;

.field private final g:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZILandroid/os/Bundle;Ljava/util/Set;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/CharSequence;",
            "[",
            "Ljava/lang/CharSequence;",
            "ZI",
            "Landroid/os/Bundle;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/h4;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Landroidx/core/app/h4;->b:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    const/4 v0, 0x4

    iput-object p3, p0, Landroidx/core/app/h4;->c:[Ljava/lang/CharSequence;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-boolean p4, p0, Landroidx/core/app/h4;->d:Z

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p5, p0, Landroidx/core/app/h4;->e:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p6, p0, Landroidx/core/app/h4;->f:Landroid/os/Bundle;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p7, p0, Landroidx/core/app/h4;->g:Ljava/util/Set;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroidx/core/app/h4;->k()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p2, 0x2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-ne p1, p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroidx/core/app/h4;->f()Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    const-string/jumbo p2, "setEditChoicesBeforeSending requires setAllowFreeFormInput"

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    throw p1

    :cond_1
    :goto_0
    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public static a(Landroidx/core/app/h4;Landroid/content/Intent;Ljava/util/Map;)V
    .locals 7
    .param p0    # Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/core/app/h4;",
            "Landroid/content/Intent;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/net/Uri;",
            ">;)V"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~~s@t  @ ~ do~@~o~ o @@l.b@ fo ~m@u~1v~  M@~f ~ y~~a~@ i i@sSb@@~ @r@o~c@~ @~to~l~@@bi ~K~n4-/@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/16 v1, 0x1a

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-lt v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p0, p1, p2}, Landroidx/core/app/h4$c;->a(Landroidx/core/app/h4;Landroid/content/Intent;Ljava/util/Map;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto/16 :goto_1

    :cond_0
    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {p1}, Landroidx/core/app/h4;->i(Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {p2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    check-cast v1, Landroid/net/Uri;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2}, Landroidx/core/app/h4;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez v3, :cond_3

    const/4 v6, 0x0

    new-instance v3, Landroid/os/Bundle;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroidx/core/app/h4;->o()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v3, v4, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2}, Landroidx/core/app/h4;->l(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string p0, "annmr.ddteomssir.tpluesrtio"

    const-string p0, ".osupetsmasdttrineoinrr.uld"

    const/4 v6, 0x7

    const-string p0, "edoeomutioutidrrlsper..ntns"

    const-string p0, "android.remoteinput.results"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p0, v0}, Landroid/content/ClipData;->newIntent(Ljava/lang/CharSequence;Landroid/content/Intent;)Landroid/content/ClipData;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p1, p0}, Landroidx/core/app/h4$a;->b(Landroid/content/Intent;Landroid/content/ClipData;)V

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void
.end method

.method public static b([Landroidx/core/app/h4;Landroid/content/Intent;Landroid/os/Bundle;)V
    .locals 9
    .param p0    # [Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/16 v1, 0x1a

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-lt v0, v1, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p0}, Landroidx/core/app/h4;->d([Landroidx/core/app/h4;)[Landroid/app/RemoteInput;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {p0, p1, p2}, Landroidx/core/app/h4$b;->a(Ljava/lang/Object;Landroid/content/Intent;Landroid/os/Bundle;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto :goto_2

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {p1}, Landroidx/core/app/h4;->p(Landroid/content/Intent;)Landroid/os/Bundle;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p1}, Landroidx/core/app/h4;->q(Landroid/content/Intent;)I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-nez v0, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0, p2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    array-length v0, p0

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x7

    move v7, v2

    const/4 v8, 0x6

    move v3, v2

    move v3, v2

    const/4 v8, 0x0

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-ge v3, v0, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    aget-object v4, p0, v3

    const/4 v7, 0x6

    const/4 v7, 0x0

    invoke-virtual {v4}, Landroidx/core/app/h4;->o()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p1, v5}, Landroidx/core/app/h4;->j(Landroid/content/Intent;Ljava/lang/String;)Ljava/util/Map;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    move v8, v7

    new-array v6, v6, [Landroidx/core/app/h4;

    aput-object v4, v6, v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v6}, Landroidx/core/app/h4;->d([Landroidx/core/app/h4;)[Landroid/app/RemoteInput;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v6, p1, p2}, Landroidx/core/app/h4$b;->a(Ljava/lang/Object;Landroid/content/Intent;Landroid/os/Bundle;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v5, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {v4, p1, v5}, Landroidx/core/app/h4;->a(Landroidx/core/app/h4;Landroid/content/Intent;Ljava/util/Map;)V

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_1

    :cond_3
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {p1, v1}, Landroidx/core/app/h4;->s(Landroid/content/Intent;I)V

    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-void
.end method

.method static c(Landroidx/core/app/h4;)Landroid/app/RemoteInput;
    .locals 2
    .annotation build Landroidx/annotation/w0;
        value = 0x14
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p0}, Landroidx/core/app/h4$b;->b(Landroidx/core/app/h4;)Landroid/app/RemoteInput;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method static d([Landroidx/core/app/h4;)[Landroid/app/RemoteInput;
    .locals 5
    .annotation build Landroidx/annotation/w0;
        value = 0x14
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v4, 0x2

    array-length v0, p0

    const/4 v4, 0x3

    new-array v0, v0, [Landroid/app/RemoteInput;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    array-length v2, p0

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    if-ge v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    aget-object v2, p0, v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v2}, Landroidx/core/app/h4;->c(Landroidx/core/app/h4;)Landroid/app/RemoteInput;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    aput-object v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0
.end method

.method static e(Landroid/app/RemoteInput;)Landroidx/core/app/h4;
    .locals 2
    .annotation build Landroidx/annotation/w0;
        value = 0x14
    .end annotation

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p0}, Landroidx/core/app/h4$b;->c(Ljava/lang/Object;)Landroidx/core/app/h4;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    return-object p0
.end method

.method private static i(Landroid/content/Intent;)Landroid/content/Intent;
    .locals 5
    .annotation build Landroidx/annotation/w0;
        value = 0x10
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p0}, Landroidx/core/app/h4$a;->a(Landroid/content/Intent;)Landroid/content/ClipData;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/ClipData;->getDescription()Landroid/content/ClipDescription;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "xvad.bnntdnod/e.rittitn"

    const-string/jumbo v2, "text/vnd.android.intent"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/content/ClipDescription;->hasMimeType(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/content/ClipDescription;->getLabel()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const-string/jumbo v2, "mrnldeuioi.otdapemrnst.retu"

    const-string/jumbo v2, "upemendredsiaotlittm..uronr"

    const/4 v4, 0x4

    const-string/jumbo v2, "r.trnsnpelpaued.rioiusoedmt"

    const-string v2, "android.remoteinput.results"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->contentEquals(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v1, :cond_2

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    return-object v0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/ClipData$Item;->getIntent()Landroid/content/Intent;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p0
.end method

.method public static j(Landroid/content/Intent;Ljava/lang/String;)Ljava/util/Map;
    .locals 8
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v1, 0x1a

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-lt v0, v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p0, p1}, Landroidx/core/app/h4$c;->c(Landroid/content/Intent;Ljava/lang/String;)Ljava/util/Map;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-object p0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p0}, Landroidx/core/app/h4;->i(Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-nez p0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object v0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance v1, Ljava/util/HashMap;

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v3, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v4, "rasnladuqRopadueDrtayttsei.miee.otpdoTt"

    const-string/jumbo v4, "puepomseeDsorR.tlaarteodn.daTtatiitundy"

    const/4 v7, 0x5

    const-string/jumbo v4, "rTsRtuainsttyeeoDodaapuspn.mtetldd.aare"

    const-string v4, "android.remoteinput.dataTypeResultsData"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v4, :cond_2

    const/4 v7, 0x3

    const/16 v4, 0x27

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v5, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0, v3}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v3, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v3, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v5

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v5, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v1, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x1

    goto :goto_0

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    if-eqz p0, :cond_6

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_1

    :cond_6
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-object v0
.end method

.method private static l(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v1, "Rreml.neieaitnbtdtootdsaatrDsmdpuu.Taep"

    const-string/jumbo v1, "umetnbs.elatiRpap.oDotnidtuetsaTdraread"

    const/4 v3, 0x1

    const-string/jumbo v1, "saDaodaoRspurpattomieiynedlteruT.t.ante"

    const-string v1, "android.remoteinput.dataTypeResultsData"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p0
.end method

.method public static p(Landroid/content/Intent;)Landroid/os/Bundle;
    .locals 2
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0}, Landroidx/core/app/h4$b;->d(Landroid/content/Intent;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public static q(Landroid/content/Intent;)I
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/16 v1, 0x1c

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/app/h4$d;->a(Landroid/content/Intent;)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return p0

    :cond_0
    const/4 v3, 0x0

    invoke-static {p0}, Landroidx/core/app/h4;->i(Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v1, "eupmrbdti.uoor.ltnecuiodneusrtsra"

    const-string v1, "enuopsun.dtrrudireocsteoraimSt.lu"

    const/4 v3, 0x7

    const-string/jumbo v1, "urStoeurdedutrm.tlcaiieno.ueosnrp"

    const-string v1, "android.remoteinput.resultsSource"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static s(Landroid/content/Intent;I)V
    .locals 4
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v1, 0x1c

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0, p1}, Landroidx/core/app/h4$d;->b(Landroid/content/Intent;I)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0}, Landroidx/core/app/h4;->i(Landroid/content/Intent;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "oisc.arpurnlotpuuSnesope.rdmtitre"

    const-string/jumbo v1, "srucroapuoreuen.ielptriSme.tsondt"

    const/4 v3, 0x2

    const-string v1, "ed.re.tmqrtacetnsusuplroneSuidoir"

    const-string v1, "android.remoteinput.resultsSource"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo p1, "sds.dm.nortiitrptuloaernseu"

    const-string p1, "android.remoteinput.results"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, v0}, Landroid/content/ClipData;->newIntent(Ljava/lang/CharSequence;Landroid/content/Intent;)Landroid/content/ClipData;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p0, p1}, Landroidx/core/app/h4$a;->b(Landroid/content/Intent;Landroid/content/ClipData;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public f()Z
    .locals 3

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/core/app/h4;->d:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public g()Ljava/util/Set;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object v0, p0, Landroidx/core/app/h4;->g:Ljava/util/Set;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public h()[Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/h4;->c:[Ljava/lang/CharSequence;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public k()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Landroidx/core/app/h4;->e:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public m()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/h4;->f:Landroid/os/Bundle;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public n()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/h4;->b:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public o()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/h4;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public r()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroidx/core/app/h4;->f()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroidx/core/app/h4;->h()[Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroidx/core/app/h4;->h()[Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    array-length v0, v0

    const/4 v2, 0x5

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p0}, Landroidx/core/app/h4;->g()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/core/app/h4;->g()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method
