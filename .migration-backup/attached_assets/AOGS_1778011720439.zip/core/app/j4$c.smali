.class public Landroidx/core/app/j4$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/j4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# static fields
.field private static final f:Ljava/lang/String; = "IntentReader"


# instance fields
.field private final a:Landroid/content/Context;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Landroid/content/Intent;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final c:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final d:Landroid/content/ComponentName;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private e:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    invoke-static {p1}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, Landroid/content/Context;

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, v0, p1}, Landroidx/core/app/j4$c;-><init>(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    check-cast p1, Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/j4$c;->a:Landroid/content/Context;

    const/4 v0, 0x2

    move v1, v0

    invoke-static {p2}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    check-cast p1, Landroid/content/Intent;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v0, 0x7

    move v1, v0

    invoke-static {p2}, Landroidx/core/app/j4;->f(Landroid/content/Intent;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/j4$c;->c:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p2}, Landroidx/core/app/j4;->d(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/j4$c;->d:Landroid/content/ComponentName;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/app/Activity;)Landroidx/core/app/j4$c;
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Landroidx/core/app/j4$c;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Landroidx/core/app/j4$c;-><init>(Landroid/app/Activity;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method private static t(Ljava/lang/StringBuilder;Ljava/lang/CharSequence;II)V
    .locals 5

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ge p2, p3, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/16 v1, 0x3c

    const/4 v3, 0x7

    move v4, v3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const-string v0, "&lt;"

    const-string/jumbo v0, "t;&l"

    const/4 v4, 0x3

    const-string v0, "&tl;"

    const-string v0, "&lt;"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto/16 :goto_3

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/16 v1, 0x3e

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-ne v0, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v0, ";gt&"

    const-string v0, ";&tg"

    const-string v0, ";t&g"

    const-string v0, "&gt;"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto/16 :goto_3

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/16 v1, 0x26

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ne v0, v1, :cond_2

    const/4 v4, 0x6

    const-string/jumbo v0, "s&sa;"

    const-string v0, ";as&p"

    const-string v0, "a&;mp"

    const-string v0, "&amp;"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    goto/16 :goto_3

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/16 v1, 0x7e

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-gt v0, v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/16 v1, 0x20

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ge v0, v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_2

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-ne v0, v1, :cond_5

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    add-int/lit8 v0, p2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v0, p3, :cond_4

    const/4 v4, 0x1

    invoke-interface {p1, v0}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne v2, v1, :cond_4

    const/4 v3, 0x6

    move v4, v3

    const-string/jumbo p2, "pbm;o&"

    const-string/jumbo p2, "p&;msb"

    const/4 v4, 0x4

    const-string p2, "bs&;nb"

    const-string p2, "&nbsp;"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    move p2, v0

    move p2, v0

    const/4 v4, 0x1

    move p2, v0

    move p2, v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_1

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_3

    :cond_5
    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_3

    :cond_6
    :goto_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v1, "&#"

    const-string v1, "#&"

    const/4 v4, 0x3

    const-string v1, "&#"

    const-string v1, "&#"

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v0, ";"

    const-string v0, ";"

    const/4 v4, 0x5

    const-string v0, ";"

    const-string v0, ";"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_3
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/lit8 p2, p2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto/16 :goto_0

    :cond_7
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method public b()Landroid/content/ComponentName;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$c;->d:Landroid/content/ComponentName;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public c()Landroid/graphics/drawable/Drawable;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$c;->d:Landroid/content/ComponentName;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    if-nez v0, :cond_0

    const/4 v5, 0x7

    return-object v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$c;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v2, p0, Landroidx/core/app/j4$c;->d:Landroid/content/ComponentName;

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getActivityIcon(Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const-string v2, "darteRuIteen"

    const-string v2, "IntentReader"

    const/4 v5, 0x5

    const-string v3, "e voniopoC ircvllg tniireoa e fuaclydiorttnt"

    const-string/jumbo v3, "roivolCtivagloin l uoyet cicef dror  ttainen"

    const/4 v5, 0x1

    const-string v3, "aft tivrqolivilrdeuo niit e r eCglconyan tco"

    const-string v3, "Could not retrieve icon for calling activity"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object v1
.end method

.method public d()Landroid/graphics/drawable/Drawable;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/core/app/j4$c;->c:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-object v1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/core/app/j4$c;->a:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v2, p0, Landroidx/core/app/j4$c;->c:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getApplicationIcon(Ljava/lang/String;)Landroid/graphics/drawable/Drawable;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v2, "tIsneRnbdate"

    const-string v2, "dtIeRbanenet"

    const/4 v5, 0x6

    const-string v2, "RtnmneerdtIa"

    const-string v2, "IntentReader"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v3, "lp  o roilliieenincaou tfeoltapodovc  rgarnitnC"

    const-string v3, "Could not retrieve icon for calling application"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v1
.end method

.method public e()Ljava/lang/CharSequence;
    .locals 6
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$c;->c:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    return-object v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$c;->a:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Landroidx/core/app/j4$c;->c:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v3}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v0
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v2, "RtautbdeerIe"

    const-string/jumbo v2, "rtedRtuIeaen"

    const/4 v5, 0x3

    const-string/jumbo v2, "tedeatuernRI"

    const-string v2, "IntentReader"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v3, "volailepodatitnnrCloagell l iceabout  ni refrcpp"

    const/4 v5, 0x1

    const-string v3, " ero aapoglebpnitCcirvtriluliofn pl edoeal ctal "

    const-string v3, "Could not retrieve label for calling application"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v1
.end method

.method public f()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/j4$c;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public g()[Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v1, "qdnCCo..qirxntenrd.iteaB"

    const-string/jumbo v1, "nodtntexqrCCi.Btean..rdi"

    const/4 v3, 0x0

    const-string v1, "edsBneC.otatCrdari.tin.x"

    const-string v1, "android.intent.extra.BCC"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public h()[Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo v1, "n.amodaCrtsixtr.eCnd.ni"

    const-string/jumbo v1, "nosa.Cn.tixrtdeaniCr.dt"

    const/4 v3, 0x4

    const-string/jumbo v1, "xe.eoartd.Cniditnnaro.C"

    const-string v1, "android.intent.extra.CC"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public i()[Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x7

    const-string v1, "Ed.ribdneoxnaInmtetaMrLiAt"

    const-string/jumbo v1, "xtnmarot.raA.LtMneindideEI"

    const/4 v3, 0x1

    const-string v1, "..ainAueentnLIatdrEM.ioxrt"

    const-string v1, "android.intent.extra.EMAIL"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public j()Ljava/lang/String;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "e.EXM_TpnTtnTnaixeHooaLr.r.ddi"

    const-string v1, "Tn.ModrErnHTT_e.Xi.titnLxeadao"

    const/4 v4, 0x0

    const-string v1, "LdiTrndnqxtiHo.tMTE.rT.eXan_te"

    const-string v1, "android.intent.extra.HTML_TEXT"

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/core/app/j4$c;->o()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    instance-of v2, v1, Landroid/text/Spanned;

    const/4 v4, 0x7

    if-eqz v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    check-cast v1, Landroid/text/Spanned;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Landroid/text/Html;->toHtml(Landroid/text/Spanned;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    invoke-static {v1}, Landroidx/core/app/j4$a;->a(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0
.end method

.method public k()Landroid/net/Uri;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x6

    const-string v1, ".estRnTtSAeaitMn.adiErrxdo."

    const-string v1, "Mx.rAbtrnaiaSd..EntoiTRdete"

    const/4 v3, 0x5

    const-string/jumbo v1, "xRrm.edadEneatASnMnT.i.itor"

    const-string v1, "android.intent.extra.STREAM"

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast v0, Landroid/net/Uri;

    const/4 v3, 0x3

    return-object v0
.end method

.method public l(I)Landroid/net/Uri;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/core/app/j4$c;->e:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "xnrTouA.adiStntd.MereEtinRo"

    const-string/jumbo v1, "reexi.utMtrtTERn.ndnSiaAoad"

    const/4 v4, 0x5

    const-string v1, "SitrobteRdxe..ianErTn.ndtaA"

    const-string v1, "android.intent.extra.STREAM"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/core/app/j4$c;->q()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    move v4, v3

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object v0, p0, Landroidx/core/app/j4$c;->e:Ljava/util/ArrayList;

    :cond_0
    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$c;->e:Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast p1, Landroid/net/Uri;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-nez p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object p1, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast p1, Landroid/net/Uri;

    const/4 v3, 0x6

    move v4, v3

    return-object p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, "ap ibeu ttasemalr ilve:a"

    const-string v2, "era  iepaltal:iavmbet sm"

    const/4 v4, 0x7

    const-string v2, "ermlbaepaslvit:maStiae  "

    const-string v2, "Stream items available: "

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/core/app/j4$c;->m()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v2, "drt:  qiqe xsendeu"

    const-string/jumbo v2, "t ude esq eqinxdr:"

    const-string/jumbo v2, "qdsie:esn erdex  u"

    const-string v2, " index requested: "

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw v0
.end method

.method public m()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$c;->e:Ljava/util/ArrayList;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    const-string/jumbo v1, "iaxmderSnRttnnaoTdAMtri.eEs"

    const-string v1, "MTsSdiRtnrtieetAaxadEn..ron"

    const/4 v3, 0x5

    const-string v1, "dSadornEnnierAa.ttRi.M.tTxo"

    const-string v1, "android.intent.extra.STREAM"

    const/4 v3, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/core/app/j4$c;->q()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getParcelableArrayListExtra(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Landroidx/core/app/j4$c;->e:Ljava/util/ArrayList;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$c;->e:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v0

    :cond_1
    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method public n()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "mS.JUb.darnx.noCrTattEeBietd"

    const-string v1, "UaJmnSrei.dEdCBxn.tit.Ttoare"

    const/4 v3, 0x5

    const-string v1, "dE.oa.unaixCdnJrt.itenSrTBeU"

    const-string v1, "android.intent.extra.SUBJECT"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method

.method public o()Ljava/lang/CharSequence;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, "etoidTopta.rd.annTretEXnx"

    const-string/jumbo v1, "nXTnoatr..xondiated.TtrEe"

    const/4 v3, 0x3

    const-string v1, ".teXraddqTxreo.nit.ntTEin"

    const-string v1, "android.intent.extra.TEXT"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getCharSequenceExtra(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public p()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public q()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, "ersNtIitn_idSndUtLLTDaEoi.ncnP.Mao."

    const-string v1, "android.intent.action.SEND_MULTIPLE"

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return v0
.end method

.method public r()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v1, "dnimbtartnDooEti.n.ai.eScN"

    const-string v1, "EetciboNndr.SatntniDo.ni.a"

    const/4 v3, 0x3

    const-string/jumbo v1, "ncododSDrnaN..aEntiiotn.ti"

    const-string v1, "android.intent.action.SEND"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v1, "ScrddbL.nP_ianT.iuoIenMNEtotELaDit."

    const-string/jumbo v1, "nN.DE_uctiLInUTnEPiStaLdarooiMde.t."

    const/4 v3, 0x3

    const-string/jumbo v1, "rdItnLuinttdieUTn.ENPS_LociEanDM..a"

    const-string v1, "android.intent.action.SEND_MULTIPLE"

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v3, v2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return v0
.end method

.method public s()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/j4$c;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "SoinipcpoNn.EtrDdtnatdea.n"

    const-string/jumbo v1, "nadnS..poNcdntiiatntEoDrei"

    const/4 v3, 0x3

    const-string/jumbo v1, "ioDntNneqdtSdn.a.in.tEarci"

    const-string v1, "android.intent.action.SEND"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    return v0
.end method
