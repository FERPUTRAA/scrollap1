.class public final synthetic Landroidx/core/app/q2;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/lang/Class;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s@t~ b  ll@~ c~@i/K~.@~@ o ftm@~~~~~o  1s/~@   ~@yn~ o @4~rd~~~@@-@Mu@b @~v@ @o@~oaif@~b S~~ i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-class v0, Landroid/app/Notification$DecoratedCustomViewStyle;

    const-class v0, Landroid/app/Notification$DecoratedCustomViewStyle;

    const/4 v2, 0x6

    const-class v0, Landroid/app/Notification$DecoratedCustomViewStyle;

    const-class v0, Landroid/app/Notification$DecoratedCustomViewStyle;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method
