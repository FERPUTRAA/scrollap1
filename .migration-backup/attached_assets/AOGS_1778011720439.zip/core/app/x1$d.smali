.class public Landroidx/core/app/x1$d;
.super Landroidx/core/app/x1$q;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/x1$d$c;,
        Landroidx/core/app/x1$d$b;,
        Landroidx/core/app/x1$d$a;
    }
.end annotation


# static fields
.field private static final j:Ljava/lang/String; = "androidx.core.app.NotificationCompat$BigPictureStyle"


# instance fields
.field private e:Landroid/graphics/Bitmap;

.field private f:Landroidx/core/graphics/drawable/IconCompat;

.field private g:Z

.field private h:Ljava/lang/CharSequence;

.field private i:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroidx/core/app/x1$g;)V
    .locals 2
    .param p1    # Landroidx/core/app/x1$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Landroidx/core/app/x1$q;->z(Landroidx/core/app/x1$g;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method private static A(Landroid/os/Parcelable;)Landroidx/core/graphics/drawable/IconCompat;
    .locals 3
    .param p0    # Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s@@o/c~d  ~~ K~ @@l~i/ uv1@-~M~~@ @b@r o@@@@~y o.b~i@ ~t~~ n@ma~of~ sb @~o~~@4~o@ @i~ @ l S~ t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    if-eqz p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    instance-of v0, p0, Landroid/graphics/drawable/Icon;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p0, Landroid/graphics/drawable/Icon;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0}, Landroidx/core/graphics/drawable/IconCompat;->n(Landroid/graphics/drawable/Icon;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x3

    instance-of v0, p0, Landroid/graphics/Bitmap;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Landroid/graphics/Bitmap;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0}, Landroidx/core/graphics/drawable/IconCompat;->t(Landroid/graphics/Bitmap;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method


# virtual methods
.method public B(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$d;
    .locals 2
    .param p1    # Landroid/graphics/Bitmap;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x0

    move v0, p1

    move v0, p1

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1}, Landroidx/core/graphics/drawable/IconCompat;->t(Landroid/graphics/Bitmap;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object p1

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/app/x1$d;->f:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v0, 0x4

    shl-int/2addr v1, v0

    iput-boolean p1, p0, Landroidx/core/app/x1$d;->g:Z

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public C(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$d;
    .locals 2
    .param p1    # Landroid/graphics/Bitmap;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/x1$d;->e:Landroid/graphics/Bitmap;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public D(Ljava/lang/CharSequence;)Landroidx/core/app/x1$d;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public E(Ljava/lang/CharSequence;)Landroidx/core/app/x1$d;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1f
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$d;->h:Ljava/lang/CharSequence;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public F(Ljava/lang/CharSequence;)Landroidx/core/app/x1$d;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-boolean p1, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public G(Z)Landroidx/core/app/x1$d;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1f
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/core/app/x1$d;->i:Z

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public b(Landroidx/core/app/v;)V
    .locals 6
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v1, Landroid/app/Notification$BigPictureStyle;

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v1, v2}, Landroid/app/Notification$BigPictureStyle;-><init>(Landroid/app/Notification$Builder;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/app/Notification$BigPictureStyle;->setBigContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$BigPictureStyle;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Landroidx/core/app/x1$d;->e:Landroid/graphics/Bitmap;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Landroid/app/Notification$BigPictureStyle;->bigPicture(Landroid/graphics/Bitmap;)Landroid/app/Notification$BigPictureStyle;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-boolean v2, p0, Landroidx/core/app/x1$d;->g:Z

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v2, p0, Landroidx/core/app/x1$d;->f:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v1, v3}, Landroidx/core/app/x1$d$a;->a(Landroid/app/Notification$BigPictureStyle;Landroid/graphics/Bitmap;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    instance-of v2, p1, Landroidx/core/app/m3;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast p1, Landroidx/core/app/m3;

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroidx/core/app/m3;->f()Landroid/content/Context;

    move-result-object v3

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Landroidx/core/app/x1$d;->f:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1, v3}, Landroidx/core/graphics/drawable/IconCompat;->M(Landroid/content/Context;)Landroid/graphics/drawable/Icon;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v1, p1}, Landroidx/core/app/x1$d$b;->a(Landroid/app/Notification$BigPictureStyle;Landroid/graphics/drawable/Icon;)V

    :cond_2
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    iget-boolean p1, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v5, 0x4

    const/4 v4, 0x5

    if-eqz p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v1, p1}, Landroidx/core/app/x1$d$a;->b(Landroid/app/Notification$BigPictureStyle;Ljava/lang/CharSequence;)V

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/16 p1, 0x1f

    const/4 v5, 0x0

    const/4 v4, 0x1

    if-lt v0, p1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-boolean p1, p0, Landroidx/core/app/x1$d;->i:Z

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1, p1}, Landroidx/core/app/x1$d$c;->b(Landroid/app/Notification$BigPictureStyle;Z)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p1, p0, Landroidx/core/app/x1$d;->h:Ljava/lang/CharSequence;

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, p1}, Landroidx/core/app/x1$d$c;->a(Landroid/app/Notification$BigPictureStyle;Ljava/lang/CharSequence;)V

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void
.end method

.method protected g(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->g(Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "iasmgcrdobiaonIdr..en"

    const-string/jumbo v0, "nns.ibg.roaiedgrcaIod"

    const/4 v2, 0x5

    const-string v0, "baogor.i.oIdcirgdnnae"

    const-string v0, "android.largeIcon.big"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, "dpcenbtu.aodmri"

    const-string v0, "dpnmeoctaii.dur"

    const/4 v2, 0x2

    const-string v0, "cp.detuonrruidi"

    const-string v0, "android.picture"

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, "daen.gepleCsocodrshwWPtlaoBioipnuhd"

    const-string/jumbo v0, "nlahocotdedsnsowi.oehBderWglPiuraCp"

    const/4 v2, 0x3

    const-string v0, ".iiBgidPqtnadhrldhnlpcCsowseraoeWuo"

    const-string v0, "android.showBigPictureWhenCollapsed"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method protected t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "ues$ceaxpbPyoodtiNt.onltiroSidaic.mpBnft.irCgotraica"

    const-string/jumbo v0, "puidebCoitdctfiocpgncoaioxrPaaN.tli$mo.e.rSyttnrpaiB"

    const/4 v2, 0x7

    const-string v0, "atamdtmritaxi.t.tfcPuedSBnppicoocrn$i.oeyopraCeliNgo"

    const-string v0, "androidx.core.app.NotificationCompat$BigPictureStyle"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method protected y(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->y(Landroid/os/Bundle;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v0, "ldbaon.grogeucidaIro."

    const-string v0, "cairaIui.ndlgo.rgbode"

    const/4 v3, 0x1

    const-string/jumbo v0, "re.dibgcgdnblI.aroioa"

    const-string v0, "android.largeIcon.big"

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0}, Landroidx/core/app/x1$d;->A(Landroid/os/Parcelable;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/core/app/x1$d;->f:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-boolean v0, p0, Landroidx/core/app/x1$d;->g:Z

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v0, "piaeonuciurddp."

    const-string v0, "a.rpodiprunceid"

    const/4 v3, 0x1

    const-string/jumbo v0, "rutd.paprdcieio"

    const-string v0, "android.picture"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Landroid/graphics/Bitmap;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/core/app/x1$d;->e:Landroid/graphics/Bitmap;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "rpotCWilqnegdhhdolwBeP.oiinusdaaerc"

    const-string v0, "android.showBigPictureWhenCollapsed"

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-boolean p1, p0, Landroidx/core/app/x1$d;->i:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
