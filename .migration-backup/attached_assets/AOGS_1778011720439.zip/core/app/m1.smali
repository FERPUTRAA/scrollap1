.class public final synthetic Landroidx/core/app/m1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Landroid/app/Person;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    check-cast p0, Landroid/app/Person;

    const/4 v1, 0x2

    return-object p0
.end method
