.class public final synthetic Landroidx/core/app/z1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;)Landroid/widget/RemoteViews;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "yosuvK~@~@  @ @~- @ao~b@ob@~/ ~b~@~@l ~~t~iM inl@i  @ ~@.~1@t@~S/c~@~ @@@doof4fo rm~ ~  s ~~~~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/app/Notification$Builder;->createHeadsUpContentView()Landroid/widget/RemoteViews;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method
