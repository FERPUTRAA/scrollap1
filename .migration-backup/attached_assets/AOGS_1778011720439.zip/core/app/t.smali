.class public final Landroidx/core/app/t;
.super Ljava/lang/Object;


# instance fields
.field private final a:Z

.field private final b:Landroid/content/res/Configuration;


# direct methods
.method public constructor <init>(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-boolean p1, p0, Landroidx/core/app/t;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v0, 0x0

    shl-int/2addr v1, v0

    iput-object p1, p0, Landroidx/core/app/t;->b:Landroid/content/res/Configuration;

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-void
.end method

.method public constructor <init>(ZLandroid/content/res/Configuration;)V
    .locals 2
    .param p2    # Landroid/content/res/Configuration;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-boolean p1, p0, Landroidx/core/app/t;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    iput-object p2, p0, Landroidx/core/app/t;->b:Landroid/content/res/Configuration;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()Landroid/content/res/Configuration;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/t;->b:Landroid/content/res/Configuration;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v1, "ussrtthdessntoa oct.le iohP vngt Aitmido M glaoabaesaryta u ttdf geiImoe   nneisk rghhhCg nonigbflede uo2narrtvo nohNne u Iwasfh  6eecraitc nduco cfa()whiWCt lak?e tninrocnAiwtMi oseaoerCilmnutr  tatiout"

    const-string/jumbo v1, "uesiC rCscs? disthoodgeoroniohMnn ttahi scn i6wcoee  stfPtgeoaIetemirtn)vuoodnubltriIt hnMvaWuccdk nfyfCioinlheaaenmgtuttwt ot ua n rua2oaalgec b aa tA roghn n ri Ndge.rmnl(tiow s kli aehorhfi  na tetAe "

    const/4 v3, 0x2

    const-string/jumbo v1, "nkWmnAcdsIt lseieitoot  oitldtheCaswht lefgirnCgne r aocu ihIeafhaynoPer nob  et?lgiuNriCvh     m ulrnuoasevg io mt.e  khrdgctwn6ea2ntr(Mrnwtafns dnugocAno totitc eianaaeoiMmdutoi) ttha n aao hrs tiecfou"

    const-string v1, "MultiWindowModeChangedInfo must be constructed with the constructor that takes a Configuration to call getNewConfig(). Are you running on an API 26 or higher device that makes this information available?"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/core/app/t;->a:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method
