.class public final synthetic Landroidx/core/app/b1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannelGroup;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i s  ~f-@~t@~o~~ @4M  u~@t/ ~o~.~~@bo@  ~o~o@~1llS@@~a@K@onis ~@@b@dvrb~i@  / @m   ~y~~c~ @@f~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/NotificationChannelGroup;->isBlocked()Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    return p0
.end method
