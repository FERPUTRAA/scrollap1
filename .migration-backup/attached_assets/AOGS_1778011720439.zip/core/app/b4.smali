.class public final Landroidx/core/app/b4;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/b4$a;,
        Landroidx/core/app/b4$b;,
        Landroidx/core/app/b4$e;,
        Landroidx/core/app/b4$c;,
        Landroidx/core/app/b4$d;
    }
.end annotation


# static fields
.field private static final c:Ljava/lang/String; = "NotifManCompat"

.field private static final d:Ljava/lang/String; = "checkOpNoThrow"

.field private static final e:Ljava/lang/String; = "OP_POST_NOTIFICATION"

.field public static final f:Ljava/lang/String; = "android.support.useSideChannel"

.field public static final g:Ljava/lang/String; = "android.support.BIND_NOTIFICATION_SIDE_CHANNEL"

.field static final h:I = 0x13

.field private static final i:I = 0x3e8

.field private static final j:I = 0x6

.field private static final k:Ljava/lang/String; = "enabled_notification_listeners"

.field private static final l:Ljava/lang/Object;

.field private static m:Ljava/lang/String; = null
    .annotation build Landroidx/annotation/b0;
        value = "sEnabledNotificationListenersLock"
    .end annotation
.end field

.field private static n:Ljava/util/Set; = null
    .annotation build Landroidx/annotation/b0;
        value = "sEnabledNotificationListenersLock"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final o:Ljava/lang/Object;

.field private static p:Landroidx/core/app/b4$d; = null
    .annotation build Landroidx/annotation/b0;
        value = "sLock"
    .end annotation
.end field

.field public static final q:I = -0x3e8

.field public static final r:I = 0x0

.field public static final s:I = 0x1

.field public static final t:I = 0x2

.field public static final u:I = 0x3

.field public static final v:I = 0x4

.field public static final w:I = 0x5


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/app/NotificationManager;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Landroidx/core/app/b4;->l:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-object v0, Landroidx/core/app/b4;->n:Ljava/util/Set;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    sput-object v0, Landroidx/core/app/b4;->o:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/core/app/b4;->a:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const-string/jumbo v0, "onstfnoiitai"

    const-string/jumbo v0, "iasfnttoiino"

    const/4 v2, 0x4

    const-string/jumbo v0, "iifmotnctnoi"

    const-string/jumbo v0, "notification"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p1, Landroid/app/NotificationManager;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method private E(Landroidx/core/app/b4$e;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "t@ @o1@/~i.~ @f~~@@/4u n@ MKoiol lo~~  a @t~@bdcb ~~~~@~o~m@obs @ ~@@ v~@ @ ~ ~oi~- y ~~S~~@r@@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    sget-object v0, Landroidx/core/app/b4;->o:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x4

    sget-object v1, Landroidx/core/app/b4;->p:Landroidx/core/app/b4$d;

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v1, Landroidx/core/app/b4$d;

    const/4 v3, 0x0

    move v4, v3

    iget-object v2, p0, Landroidx/core/app/b4;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Landroidx/core/app/b4$d;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    sput-object v1, Landroidx/core/app/b4;->p:Landroidx/core/app/b4$d;

    :cond_0
    const/4 v4, 0x4

    sget-object v1, Landroidx/core/app/b4;->p:Landroidx/core/app/b4$d;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Landroidx/core/app/b4$d;->h(Landroidx/core/app/b4$e;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    throw p1
.end method

.method private static F(Landroid/app/Notification;)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0}, Landroidx/core/app/x1;->n(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const-string/jumbo v0, "ouaadbemii.lrdpCnso.Shnrsptdeu"

    const-string/jumbo v0, "sCamre.aoSiopspudlr.nhuedeintd"

    const/4 v2, 0x4

    const-string/jumbo v0, "ineeh.urSoentopilCpnardsua.uds"

    const-string v0, "android.support.useSideChannel"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x1

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return p0
.end method

.method public static p(Landroid/content/Context;)Landroidx/core/app/b4;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Landroidx/core/app/b4;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0, p0}, Landroidx/core/app/b4;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public static q(Landroid/content/Context;)Ljava/util/Set;
    .locals 8
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v0, "lstntiipefibnnctdanleooieseor_"

    const-string/jumbo v0, "loaeoti_rnnlenebestsici_otndfi"

    const/4 v7, 0x6

    const-string/jumbo v0, "ietacn_aqsiieifdllbrtnsnonte_e"

    const-string v0, "enabled_notification_listeners"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {p0, v0}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v0, Landroidx/core/app/b4;->l:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    monitor-enter v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    if-eqz p0, :cond_2

    :try_start_0
    const/4 v7, 0x0

    sget-object v1, Landroidx/core/app/b4;->m:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez v1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string v1, ":"

    const-string v1, ":"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v2, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0, v1, v2}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v2, Ljava/util/HashSet;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    array-length v3, v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-direct {v2, v3}, Ljava/util/HashSet;-><init>(I)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    array-length v3, v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v4, 0x0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-ge v4, v3, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    aget-object v5, v1, v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {v5}, Landroid/content/ComponentName;->unflattenFromString(Ljava/lang/String;)Landroid/content/ComponentName;

    move-result-object v5

    const/4 v7, 0x1

    if-eqz v5, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    invoke-virtual {v5}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface {v2, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    sput-object v2, Landroidx/core/app/b4;->n:Ljava/util/Set;

    const/4 v7, 0x3

    const/4 v6, 0x7

    sput-object p0, Landroidx/core/app/b4;->m:Ljava/lang/String;

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget-object p0, Landroidx/core/app/b4;->n:Ljava/util/Set;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    monitor-exit v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    throw p0
.end method


# virtual methods
.method public A()Ljava/util/List;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/app/NotificationChannel;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Landroidx/core/app/s3;->a(Landroid/app/NotificationManager;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method

.method public B()Ljava/util/List;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/core/app/x0;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x2

    const/16 v1, 0x1a

    const/4 v5, 0x1

    if-lt v0, v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroidx/core/app/b4;->A()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    move v5, v4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {v2}, Landroidx/core/app/e1;->a(Ljava/lang/Object;)Landroid/app/NotificationChannel;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v3, Landroidx/core/app/x0;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v3, v2}, Landroidx/core/app/x0;-><init>(Landroid/app/NotificationChannel;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object v1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object v0
.end method

.method public C(ILandroid/app/Notification;)V
    .locals 3
    .param p2    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, v0, p1, p2}, Landroidx/core/app/b4;->D(Ljava/lang/String;ILandroid/app/Notification;)V

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public D(Ljava/lang/String;ILandroid/app/Notification;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x0

    invoke-static {p3}, Landroidx/core/app/b4;->F(Landroid/app/Notification;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Landroidx/core/app/b4$b;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/core/app/b4;->a:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1, p2, p1, p3}, Landroidx/core/app/b4$b;-><init>(Ljava/lang/String;ILjava/lang/String;Landroid/app/Notification;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Landroidx/core/app/b4;->E(Landroidx/core/app/b4$e;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object p3, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p3, p1, p2}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p2, p3}, Landroid/app/NotificationManager;->notify(Ljava/lang/String;ILandroid/app/Notification;)V

    :goto_0
    const/4 v3, 0x1

    return-void
.end method

.method public a()Z
    .locals 13

    const/4 v12, 0x1

    const/4 v11, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v12, 0x7

    const/16 v1, 0x18

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-lt v0, v1, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-static {v0}, Landroidx/core/app/y3;->a(Landroid/app/NotificationManager;)Z

    move-result v0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x3

    return v0

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v0, p0, Landroidx/core/app/b4;->a:Landroid/content/Context;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string/jumbo v1, "psspbp"

    const-string/jumbo v1, "poppsb"

    const/4 v12, 0x6

    const-string/jumbo v1, "popmsp"

    const-string v1, "appops"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    check-cast v0, Landroid/app/AppOpsManager;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v1, p0, Landroidx/core/app/b4;->a:Landroid/content/Context;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v2, p0, Landroidx/core/app/b4;->a:Landroid/content/Context;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x7

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    const/4 v3, 0x1

    :try_start_0
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-class v4, Landroid/app/AppOpsManager;

    const-class v4, Landroid/app/AppOpsManager;

    const/4 v12, 0x1

    const-class v4, Landroid/app/AppOpsManager;

    const-class v4, Landroid/app/AppOpsManager;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v5, "TorhoccOokehuN"

    const-string v5, "hOhTeoupNrccok"

    const/4 v12, 0x0

    const-string v5, "eoThcbpkNhOcow"

    const-string v5, "checkOpNoThrow"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    const/4 v6, 0x3

    const/4 v12, 0x0

    new-array v7, v6, [Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v9, 0x3

    const/4 v12, 0x1

    const/4 v9, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    aput-object v8, v7, v9

    aput-object v8, v7, v3

    const/4 v12, 0x0

    const-class v8, Ljava/lang/String;

    const-class v8, Ljava/lang/String;

    const/4 v12, 0x0

    const-class v8, Ljava/lang/String;

    const-class v8, Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    const/4 v10, 0x2

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    aput-object v8, v7, v10

    const/4 v12, 0x6

    invoke-virtual {v4, v5, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    const-string v7, "COOIPOu_ATNp_TPFINIT"

    const-string v7, "ICOOTNSpN_TTI_OIFPPA"

    const-string v7, "OONF_IPp_SANTTCITIOO"

    const-string v7, "OP_POST_NOTIFICATION"

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v4, v7}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    const-class v7, Ljava/lang/Integer;

    const-class v7, Ljava/lang/Integer;

    const/4 v12, 0x0

    const-class v7, Ljava/lang/Integer;

    const-class v7, Ljava/lang/Integer;

    const/4 v12, 0x1

    invoke-virtual {v4, v7}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x0

    check-cast v4, Ljava/lang/Integer;

    const/4 v12, 0x3

    const/4 v11, 0x3

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v12, 0x7

    const/4 v11, 0x5

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    aput-object v4, v6, v9

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v12, 0x4

    const/4 v11, 0x4

    aput-object v1, v6, v3

    const/4 v12, 0x6

    aput-object v2, v6, v10

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v5, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x3

    check-cast v0, Ljava/lang/Integer;

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-nez v0, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x4

    goto :goto_0

    :cond_1
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    move v3, v9

    move v3, v9

    const/4 v12, 0x4

    move v3, v9

    move v3, v9

    :catch_0
    :goto_0
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    return v3
.end method

.method public b(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, v0, p1}, Landroidx/core/app/b4;->c(Ljava/lang/String;I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public c(Ljava/lang/String;I)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Landroid/app/NotificationManager;->cancel(Ljava/lang/String;I)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/app/NotificationManager;->cancelAll()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public e(Landroid/app/NotificationChannel;)V
    .locals 4
    .param p1    # Landroid/app/NotificationChannel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/16 v1, 0x1a

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p1}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    :cond_0
    const/4 v3, 0x4

    return-void
.end method

.method public f(Landroidx/core/app/x0;)V
    .locals 2
    .param p1    # Landroidx/core/app/x0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    invoke-virtual {p1}, Landroidx/core/app/x0;->m()Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroidx/core/app/b4;->e(Landroid/app/NotificationChannel;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    return-void
.end method

.method public g(Landroid/app/NotificationChannelGroup;)V
    .locals 4
    .param p1    # Landroid/app/NotificationChannelGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/16 v1, 0x1a

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, p1}, Landroidx/core/app/x3;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannelGroup;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method public h(Landroidx/core/app/h1;)V
    .locals 2
    .param p1    # Landroidx/core/app/h1;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroidx/core/app/h1;->f()Landroid/app/NotificationChannelGroup;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroidx/core/app/b4;->g(Landroid/app/NotificationChannelGroup;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    return-void
.end method

.method public i(Ljava/util/List;)V
    .locals 4
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/app/NotificationChannelGroup;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/16 v1, 0x1a

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0, p1}, Landroidx/core/app/w3;->a(Landroid/app/NotificationManager;Ljava/util/List;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public j(Ljava/util/List;)V
    .locals 4
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/core/app/h1;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 v1, 0x1a

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-lt v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v1, Landroidx/core/app/h1;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroidx/core/app/h1;->f()Landroid/app/NotificationChannelGroup;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    iget-object p1, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0}, Landroidx/core/app/w3;->a(Landroid/app/NotificationManager;Ljava/util/List;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public k(Ljava/util/List;)V
    .locals 4
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/app/NotificationChannel;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/16 v1, 0x1a

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v2, 0x1

    move v3, v2

    invoke-static {v0, p1}, Landroidx/core/app/p3;->a(Landroid/app/NotificationManager;Ljava/util/List;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method public l(Ljava/util/List;)V
    .locals 4
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/core/app/x0;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/16 v1, 0x1a

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-lt v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    move v3, v2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x0

    move v3, v2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v1, Landroidx/core/app/x0;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1}, Landroidx/core/app/x0;->m()Landroid/app/NotificationChannel;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1, v0}, Landroidx/core/app/p3;->a(Landroid/app/NotificationManager;Ljava/util/List;)V

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public m(Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/16 v1, 0x1a

    const/4 v2, 0x1

    move v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, p1}, Landroidx/core/app/q3;->a(Landroid/app/NotificationManager;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public n(Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, p1}, Landroidx/core/app/t3;->a(Landroid/app/NotificationManager;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public o(Ljava/util/Collection;)V
    .locals 6
    .param p1    # Ljava/util/Collection;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/16 v1, 0x1a

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-lt v0, v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Landroidx/core/app/s3;->a(Landroid/app/NotificationManager;)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v1}, Landroidx/core/app/e1;->a(Ljava/lang/Object;)Landroid/app/NotificationChannel;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v1}, Landroidx/core/app/w;->a(Landroid/app/NotificationChannel;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {p1, v2}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/16 v3, 0x1e

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-lt v2, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1}, Landroidx/core/app/q0;->a(Landroid/app/NotificationChannel;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p1, v2}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {v1}, Landroidx/core/app/w;->a(Landroid/app/NotificationChannel;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v2, v1}, Landroidx/core/app/q3;->a(Landroid/app/NotificationManager;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    return-void
.end method

.method public r()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/16 v1, 0x18

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Landroidx/core/app/z3;->a(Landroid/app/NotificationManager;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v0, -0x3e8

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return v0
.end method

.method public s(Ljava/lang/String;)Landroid/app/NotificationChannel;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x1a

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, p1}, Landroidx/browser/trusted/f;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x0

    return-object p1
.end method

.method public t(Ljava/lang/String;Ljava/lang/String;)Landroid/app/NotificationChannel;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/16 v1, 0x1e

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, p1, p2}, Landroidx/core/app/v3;->a(Landroid/app/NotificationManager;Ljava/lang/String;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroidx/core/app/b4;->s(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p1
.end method

.method public u(Ljava/lang/String;)Landroidx/core/app/x0;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/16 v1, 0x1a

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroidx/core/app/b4;->s(Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance v0, Landroidx/core/app/x0;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, p1}, Landroidx/core/app/x0;-><init>(Landroid/app/NotificationChannel;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method

.method public v(Ljava/lang/String;Ljava/lang/String;)Landroidx/core/app/x0;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x5

    move v3, v2

    const/16 v1, 0x1a

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    if-lt v0, v1, :cond_0

    const/4 v3, 0x4

    invoke-virtual {p0, p1, p2}, Landroidx/core/app/b4;->t(Ljava/lang/String;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    new-instance p2, Landroidx/core/app/x0;

    const/4 v3, 0x7

    invoke-direct {p2, p1}, Landroidx/core/app/x0;-><init>(Landroid/app/NotificationChannel;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    return-object p2

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p1
.end method

.method public w(Ljava/lang/String;)Landroid/app/NotificationChannelGroup;
    .locals 6
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/16 v1, 0x1c

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-lt v0, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0, p1}, Landroidx/core/app/r3;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannelGroup;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-object p1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v1, 0x1a

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-lt v0, v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroidx/core/app/b4;->y()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1}, Landroidx/core/app/u3;->a(Ljava/lang/Object;)Landroid/app/NotificationChannelGroup;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Landroidx/core/app/y0;->a(Landroid/app/NotificationChannelGroup;)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v1

    :cond_2
    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object v2
.end method

.method public x(Ljava/lang/String;)Landroidx/core/app/h1;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 v1, 0x1c

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Landroidx/core/app/b4;->w(Ljava/lang/String;)Landroid/app/NotificationChannelGroup;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Landroidx/core/app/h1;

    invoke-direct {v0, p1}, Landroidx/core/app/h1;-><init>(Landroid/app/NotificationChannelGroup;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/16 v1, 0x1a

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-lt v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0, p1}, Landroidx/core/app/b4;->w(Ljava/lang/String;)Landroid/app/NotificationChannelGroup;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Landroidx/core/app/h1;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroidx/core/app/b4;->A()Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0, p1, v1}, Landroidx/core/app/h1;-><init>(Landroid/app/NotificationChannelGroup;Ljava/util/List;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    return-object p1
.end method

.method public y()Ljava/util/List;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroid/app/NotificationChannelGroup;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x3

    move v3, v2

    const/16 v1, 0x1a

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/b4;->b:Landroid/app/NotificationManager;

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/app/a4;->a(Landroid/app/NotificationManager;)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public z()Ljava/util/List;
    .locals 8
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Landroidx/core/app/h1;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/16 v1, 0x1a

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-lt v0, v1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroidx/core/app/b4;->y()Ljava/util/List;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/16 v2, 0x1c

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-lt v0, v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroidx/core/app/b4;->A()Ljava/util/List;

    move-result-object v0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v3, Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x7

    if-eqz v4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v4}, Landroidx/core/app/u3;->a(Ljava/lang/Object;)Landroid/app/NotificationChannelGroup;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-lt v5, v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v5, Landroidx/core/app/h1;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v5, v4}, Landroidx/core/app/h1;-><init>(Landroid/app/NotificationChannelGroup;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v5, Landroidx/core/app/h1;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v5, v4, v0}, Landroidx/core/app/h1;-><init>(Landroid/app/NotificationChannelGroup;Ljava/util/List;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-object v3

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object v0
.end method
