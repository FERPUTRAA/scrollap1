.class Landroidx/core/app/j4$a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/j4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method static a(Ljava/lang/CharSequence;)Ljava/lang/String;
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "c@s~to ~~~i @  @4~f ~@v  @~ ./@@@@~o~s@M@b~~oKS~-  ~ ~l~l/ @@i~o ao@~@@1rnb~u ~@@d m~~ify o@t~@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0}, Landroid/text/Html;->escapeHtml(Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method static b(Landroid/content/Intent;Ljava/util/ArrayList;)V
    .locals 9
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/ArrayList;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/u;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Intent;",
            "Ljava/util/ArrayList<",
            "Landroid/net/Uri;",
            ">;)V"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v0, "nanmniseox.XTrtdiEeta.rtT"

    const-string/jumbo v0, "r.seiTtnnxtoaEner.daXti.T"

    const-string v0, "android.intent.extra.TEXT"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getCharSequenceExtra(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string v1, "HEeXo.dM.tedaTiTor.trnTtiL_man"

    const-string/jumbo v1, "nn.m.LXe.onETaeTii_taHrtMdrdtT"

    const/4 v8, 0x2

    const-string v1, "a.Tnnbdri.at.ixTMHntTderXeELot"

    const-string v1, "android.intent.extra.HTML_TEXT"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance v2, Landroid/content/ClipData;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    new-instance v4, Landroid/content/ClipData$Item;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast v5, Landroid/net/Uri;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v6, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {v4, v0, v1, v6, v5}, Landroid/content/ClipData$Item;-><init>(Ljava/lang/CharSequence;Ljava/lang/String;Landroid/content/Intent;Landroid/net/Uri;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v2, v6, v3, v4}, Landroid/content/ClipData;-><init>(Ljava/lang/CharSequence;[Ljava/lang/String;Landroid/content/ClipData$Item;)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v1, 0x1

    const/4 v8, 0x7

    move v3, v1

    move v3, v1

    const/4 v8, 0x6

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-ge v3, v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    check-cast v4, Landroid/net/Uri;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance v5, Landroid/content/ClipData$Item;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {v5, v4}, Landroid/content/ClipData$Item;-><init>(Landroid/net/Uri;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v2, v5}, Landroid/content/ClipData;->addItem(Landroid/content/ClipData$Item;)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0, v2}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    return-void
.end method

.method static c(Landroid/content/Intent;)V
    .locals 3
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x1

    move v2, v1

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Intent;->setClipData(Landroid/content/ClipData;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/Intent;->getFlags()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-void
.end method
