.class public final synthetic Landroidx/core/app/i1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os/vl @~~ft~i b1s KS.~u~t~~ a~~oMo4@ /~ @f@@@ ~@~i @~~~i~-@~o  @dc@ no@@~r@@~@mo@~  b @@y   bl~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/app/Notification;->getAllowSystemGeneratedContextualActions()Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p0
.end method
