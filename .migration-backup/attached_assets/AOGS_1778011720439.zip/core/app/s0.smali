.class public final synthetic Landroidx/core/app/s0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~fsar1 ~~~@~ co@i iv@ ~M@ yl@ ~t@.@l~@~~ @~/~@~to@  ~ ~/@~@s@ @ @b~-bS on@~Kodom  ~~@~ fbi@~ u4@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->canBypassDnd()Z

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    return p0
.end method
