.class public Landroidx/core/app/x1$h$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1$h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/x1$h$a$a;
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# instance fields
.field private final a:[Ljava/lang/String;

.field private final b:Landroidx/core/app/h4;

.field private final c:Landroid/app/PendingIntent;

.field private final d:Landroid/app/PendingIntent;

.field private final e:[Ljava/lang/String;

.field private final f:J


# direct methods
.method constructor <init>([Ljava/lang/String;Landroidx/core/app/h4;Landroid/app/PendingIntent;Landroid/app/PendingIntent;[Ljava/lang/String;J)V
    .locals 2
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$h$a;->a:[Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Landroidx/core/app/x1$h$a;->b:Landroidx/core/app/h4;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p4, p0, Landroidx/core/app/x1$h$a;->d:Landroid/app/PendingIntent;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p3, p0, Landroidx/core/app/x1$h$a;->c:Landroid/app/PendingIntent;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p5, p0, Landroidx/core/app/x1$h$a;->e:[Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-wide p6, p0, Landroidx/core/app/x1$h$a;->f:J

    const/4 v0, 0x0

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public a()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l1s~ ~ ~ ~@~ @.r~@yc@ K @nfi~~@ S@  @@~  ~~~@@@otiid@ o~~@@ b ~4/~~ @vu~~bsMo@~ofa-@@~ @t~ol o/m"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-wide v0, p0, Landroidx/core/app/x1$h$a;->f:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-wide v0
.end method

.method public b()[Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$h$a;->a:[Ljava/lang/String;

    const/4 v2, 0x7

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$h$a;->e:[Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    array-length v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-lez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    aget-object v0, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public d()[Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$h$a;->e:[Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public e()Landroid/app/PendingIntent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$h$a;->d:Landroid/app/PendingIntent;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public f()Landroidx/core/app/h4;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$h$a;->b:Landroidx/core/app/h4;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public g()Landroid/app/PendingIntent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/x1$h$a;->c:Landroid/app/PendingIntent;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method
