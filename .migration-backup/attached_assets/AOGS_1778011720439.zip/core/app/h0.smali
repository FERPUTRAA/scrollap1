.class public final synthetic Landroidx/core/app/h0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "ais~@@@o    ~oi@f~b~@~v/1~@y r@~/ ~M~Kb@@os@4~~t~l @@ t  cdo@~~S~~ @@@.~i l@ -b m~~u@~@ f ~ o@n~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->shouldVibrate()Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method
