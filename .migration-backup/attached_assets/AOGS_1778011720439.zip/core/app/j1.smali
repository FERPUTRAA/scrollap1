.class public final synthetic Landroidx/core/app/j1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Action;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@s@tm@@@ ~ni@~~oov@S @  @fs.@ f~ ~~ orl i@/@@@dbt@b-~ ~bl~~u@a y~~ ~o ~~co ~~ ~~1@~@ ~  ~@iK@/M"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/app/Notification$Action;->isContextual()Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p0
.end method
