.class public final synthetic Landroidx/core/app/g1;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s~@@~@/ 4~~os~ui/  dto @ -ily b@a@r~m@@~bM@~t~o~~@@@Sni@   ~~  ~~@ 1of~@ @vlb@~@Kf~.~~@@~oo~c "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Landroid/app/NotificationChannelGroup;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method
