.class public final synthetic Landroidx/core/app/c0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "f@s@ ~d@~  o@b 1 @ b~uK~~/m~ctb o-~@@ ra@v y@  @~~i~@Ss~o~o@o@~  /@~~~o@~~l@ti~l  ~@.M n4i ~f@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->shouldShowLights()Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method
