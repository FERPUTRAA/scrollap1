.class Landroidx/core/app/e$a;
.super Landroidx/core/app/e;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field private final c:Landroid/app/ActivityOptions;


# direct methods
.method constructor <init>(Landroid/app/ActivityOptions;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Landroidx/core/app/e;-><init>()V

    const/4 v0, 0x2

    and-int/2addr v1, v0

    iput-object p1, p0, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()Landroid/graphics/Rect;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x3

    move v3, v2

    const/16 v1, 0x18

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ge v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    invoke-static {v0}, Landroidx/core/app/e$e;->a(Landroid/app/ActivityOptions;)Landroid/graphics/Rect;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public j(Landroid/app/PendingIntent;)V
    .locals 3
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    const/4 v2, 0x1

    invoke-static {v0, p1}, Landroidx/core/app/e$d;->c(Landroid/app/ActivityOptions;Landroid/app/PendingIntent;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public k(Landroid/graphics/Rect;)Landroidx/core/app/e;
    .locals 4
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 v1, 0x18

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ge v0, v1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v0, Landroidx/core/app/e$a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    const/4 v3, 0x3

    invoke-static {v1, p1}, Landroidx/core/app/e$e;->b(Landroid/app/ActivityOptions;Landroid/graphics/Rect;)Landroid/app/ActivityOptions;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Landroidx/core/app/e$a;-><init>(Landroid/app/ActivityOptions;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public l()Landroid/os/Bundle;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public m(Landroidx/core/app/e;)V
    .locals 3
    .param p1    # Landroidx/core/app/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    instance-of v0, p1, Landroidx/core/app/e$a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p1, Landroidx/core/app/e$a;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p1, Landroidx/core/app/e$a;->c:Landroid/app/ActivityOptions;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Landroid/app/ActivityOptions;->update(Landroid/app/ActivityOptions;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method
