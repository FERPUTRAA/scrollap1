.class public final synthetic Landroidx/core/app/n;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroidx/core/app/JobIntentService$f;)Landroid/os/IBinder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s i@~ vM @.scim@ -~b~n@ ao ~~@o~ @tdy@@f @~o~l@o@@~~/~~@~o~ ~S/b~tur@of ~ ~K41@~b@l~@@@~  i  @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/app/job/JobServiceEngine;->getBinder()Landroid/os/IBinder;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-object p0
.end method
