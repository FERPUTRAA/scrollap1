.class public Landroidx/core/app/l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/l$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Landroid/app/Dialog;I)Landroid/view/View;
    .locals 4
    .param p0    # Landroid/app/Dialog;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~s~~ @~~SM~@t@s~/ i~ @lr~m @v @~@@ bolo ~b @@@@f@n-~@i~d~@.~  y~~@f ~i o1~o4tb ~@  o aK~@@u@ c~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v1, 0x1c

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, p1}, Landroidx/core/app/l$a;->a(Landroid/app/Dialog;I)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    check-cast p0, Landroid/view/View;

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Landroid/app/Dialog;->findViewById(I)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x0

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0

    :cond_1
    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const-string p1, "Dndmeins   hedleitc etn  IoDorees esrfiaowiisaV"

    const-string p1, "eesIen seDr  n  ior iltd eestownVdacsifD aohiei"

    const/4 v3, 0x4

    const-string p1, "ID does not reference a View inside this Dialog"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw p0
.end method
