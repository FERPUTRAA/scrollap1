.class final Landroidx/core/app/JobIntentService$c;
.super Landroidx/core/app/JobIntentService$h;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "c"
.end annotation


# instance fields
.field private final d:Landroid/content/Context;

.field private final e:Landroid/os/PowerManager$WakeLock;

.field private final f:Landroid/os/PowerManager$WakeLock;

.field g:Z

.field h:Z


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/content/ComponentName;)V
    .locals 5

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {p0, p2}, Landroidx/core/app/JobIntentService$h;-><init>(Landroid/content/ComponentName;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object v0, p0, Landroidx/core/app/JobIntentService$c;->d:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v0, "srsew"

    const-string/jumbo v0, "pwsre"

    const/4 v4, 0x1

    const-string/jumbo v0, "poemr"

    const-string/jumbo v0, "power"

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast p1, Landroid/os/PowerManager;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string v1, ":aumlnc"

    const/4 v4, 0x3

    const-string v1, "hncloau"

    const-string v1, ":launch"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v0}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v0, p0, Landroidx/core/app/JobIntentService$c;->e:Landroid/os/PowerManager$WakeLock;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v2}, Landroid/os/PowerManager$WakeLock;->setReferenceCounted(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const-string/jumbo p2, "unr:"

    const-string/jumbo p2, "ur:n"

    const/4 v4, 0x6

    const-string p2, ":run"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v1, p2}, Landroid/os/PowerManager;->newWakeLock(ILjava/lang/String;)Landroid/os/PowerManager$WakeLock;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object p1, p0, Landroidx/core/app/JobIntentService$c;->f:Landroid/os/PowerManager$WakeLock;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v2}, Landroid/os/PowerManager$WakeLock;->setReferenceCounted(Z)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method


# virtual methods
.method a(Landroid/content/Intent;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object p1, p0, Landroidx/core/app/JobIntentService$h;->a:Landroid/content/ComponentName;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Landroidx/core/app/JobIntentService$c;->d:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-boolean p1, p0, Landroidx/core/app/JobIntentService$c;->g:Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-boolean p1, p0, Landroidx/core/app/JobIntentService$c;->g:Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-boolean p1, p0, Landroidx/core/app/JobIntentService$c;->h:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p1, p0, Landroidx/core/app/JobIntentService$c;->e:Landroid/os/PowerManager$WakeLock;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-wide/32 v0, 0xea60

    const-wide/32 v0, 0xea60

    const/4 v3, 0x6

    const-wide/32 v0, 0xea60

    const-wide/32 v0, 0xea60

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public c()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x1

    iget-boolean v0, p0, Landroidx/core/app/JobIntentService$c;->h:Z

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-boolean v0, p0, Landroidx/core/app/JobIntentService$c;->g:Z

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/core/app/JobIntentService$c;->e:Landroid/os/PowerManager$WakeLock;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-wide/32 v1, 0xea60

    const-wide/32 v1, 0xea60

    const/4 v4, 0x4

    const-wide/32 v1, 0xea60

    const-wide/32 v1, 0xea60

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    :cond_0
    const/4 v3, 0x0

    const/4 v0, 0x0

    move v4, v0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService$c;->h:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/core/app/JobIntentService$c;->f:Landroid/os/PowerManager$WakeLock;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    throw v0
.end method

.method public d()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-boolean v0, p0, Landroidx/core/app/JobIntentService$c;->h:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v0, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService$c;->h:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/core/app/JobIntentService$c;->f:Landroid/os/PowerManager$WakeLock;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-wide/32 v1, 0x927c0

    const-wide/32 v1, 0x927c0

    const/4 v4, 0x7

    const-wide/32 v1, 0x927c0

    const-wide/32 v1, 0x927c0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/os/PowerManager$WakeLock;->acquire(J)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/core/app/JobIntentService$c;->e:Landroid/os/PowerManager$WakeLock;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/os/PowerManager$WakeLock;->release()V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    monitor-enter p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService$c;->g:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw v0
.end method
