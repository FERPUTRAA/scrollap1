.class public final Landroidx/core/app/d;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/app/ActivityManager;)Z
    .locals 2
    .param p0    # Landroid/app/ActivityManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s @t@i~S~f@ K@@~@o@ ~~o l~~o ~@~/b~mtM@ 4 @ib~yla/d@~@b1i@  ruoo @~of ~@@ ~ v ~~~ ~~snc-@  @@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/app/ActivityManager;->isLowRamDevice()Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p0
.end method
