.class Landroidx/core/app/b4$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/b4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/b4$d$a;
    }
.end annotation


# static fields
.field private static final h:I = 0x0

.field private static final i:I = 0x1

.field private static final j:I = 0x2

.field private static final k:I = 0x3


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroid/os/HandlerThread;

.field private final c:Landroid/os/Handler;

.field private final f:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Landroid/content/ComponentName;",
            "Landroidx/core/app/b4$d$a;",
            ">;"
        }
    .end annotation
.end field

.field private g:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/b4$d;->g:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object p1, p0, Landroidx/core/app/b4$d;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Landroid/os/HandlerThread;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, "emsiCintcNaaaaogitMoorfsp"

    const-string v0, "NgsaMCcirtaaoemnnoftoiipa"

    const/4 v2, 0x6

    const-string v0, "NogmnrotMiniacopfttaaemai"

    const-string v0, "NotificationManagerCompat"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Landroidx/core/app/b4$d;->b:Landroid/os/HandlerThread;

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/lang/Thread;->start()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    new-instance v0, Landroid/os/Handler;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, p1, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;Landroid/os/Handler$Callback;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private a(Landroidx/core/app/b4$d$a;)Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@lio  ~oo~o~M~@K yv~of@ b-~4@i@. ~~@@@~d @/Som ~a~ ~~~@f@ @1 ~b@@  ~@ @~@to~cb~t@n ru~ is l~/~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-boolean v0, p1, Landroidx/core/app/b4$d$a;->b:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x5

    move v4, v3

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, "ABImSoADsIIp_CanpOdoDEHCrt_.NEITdTOiI._rNFNNuN"

    const/4 v4, 0x1

    const-string v1, "EHISIbr.dTNLIupONC_FEApBI_.DtNaroNo_dTCsDNAniI"

    const-string v1, "android.support.BIND_NOTIFICATION_SIDE_CHANNEL"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Landroidx/core/app/b4$d;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/16 v2, 0x21

    const/4 v4, 0x1

    invoke-virtual {v1, v0, p0, v2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-boolean v0, p1, Landroidx/core/app/b4$d$a;->b:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput v0, p1, Landroidx/core/app/b4$d$a;->e:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v1, "l  enouoindase eo  bnbitttl"

    const-string v1, "elito ba  Uetndl isto bnnoe"

    const/4 v4, 0x2

    const-string v1, "elsdra pnne  ilUionbob tt t"

    const-string v1, "Unable to bind to listener "

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v1, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v1, "faMtonbpqCotia"

    const-string/jumbo v1, "matpCbtfnoMoai"

    const/4 v4, 0x7

    const-string v1, "ftsoamCptaonMN"

    const-string v1, "NotifManCompat"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/core/app/b4$d;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-boolean p1, p1, Landroidx/core/app/b4$d$a;->b:Z

    const/4 v4, 0x5

    return p1
.end method

.method private b(Landroidx/core/app/b4$d$a;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-boolean v0, p1, Landroidx/core/app/b4$d$a;->b:Z

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    iget-object v0, p0, Landroidx/core/app/b4$d;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean v0, p1, Landroidx/core/app/b4$d$a;->b:Z

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p1, Landroidx/core/app/b4$d$a;->c:Landroid/support/v4/app/INotificationSideChannel;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method private c(Landroidx/core/app/b4$e;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0}, Landroidx/core/app/b4$d;->j()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    check-cast v1, Landroidx/core/app/b4$d$a;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v2, v1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0, v1}, Landroidx/core/app/b4$d;->g(Landroidx/core/app/b4$d$a;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method private d(Landroid/content/ComponentName;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p1, Landroidx/core/app/b4$d$a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->g(Landroidx/core/app/b4$d$a;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private e(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Landroidx/core/app/b4$d$a;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-static {p2}, Landroid/support/v4/app/INotificationSideChannel$Stub;->asInterface(Landroid/os/IBinder;)Landroid/support/v4/app/INotificationSideChannel;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p2, p1, Landroidx/core/app/b4$d$a;->c:Landroid/support/v4/app/INotificationSideChannel;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p2, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput p2, p1, Landroidx/core/app/b4$d$a;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->g(Landroidx/core/app/b4$d$a;)V

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method private f(Landroid/content/ComponentName;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p1, Landroidx/core/app/b4$d$a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->b(Landroidx/core/app/b4$d$a;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method private g(Landroidx/core/app/b4$d$a;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v0, "iaCtamuoMoftpN"

    const/4 v6, 0x7

    const-string/jumbo v0, "mMampCtatifnoN"

    const-string v0, "NotifManCompat"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v1, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    move v6, v5

    const-string/jumbo v3, "pe notpicrssenoPcomng"

    const-string/jumbo v3, "so Poegpmsrcenntcnopi"

    const/4 v6, 0x4

    const-string/jumbo v3, "somrsbno cei Ppnntoeg"

    const-string v3, "Processing component "

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v3, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const-string v3, ", "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v3, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v3}, Ljava/util/ArrayDeque;->size()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v3, "t asd uqueeus"

    const-string v3, "dka esueqt su"

    const/4 v6, 0x7

    const-string/jumbo v3, "skeu qtpeads "

    const-string v3, " queued tasks"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->a(Landroidx/core/app/b4$d$a;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v2, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v2, p1, Landroidx/core/app/b4$d$a;->c:Landroid/support/v4/app/INotificationSideChannel;

    const/4 v5, 0x6

    or-int/2addr v6, v5

    if-nez v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto/16 :goto_2

    :cond_2
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v2, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->peek()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v2, Landroidx/core/app/b4$e;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto/16 :goto_1

    :cond_3
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v3, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v4, "ksdtnS aqieng"

    const-string/jumbo v4, "tSsagnknseid "

    const-string v4, "Ssseadgnki tn"

    const-string v4, "Sending task "

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-static {v0, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v3, p1, Landroidx/core/app/b4$d$a;->c:Landroid/support/v4/app/INotificationSideChannel;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {v2, v3}, Landroidx/core/app/b4$e;->a(Landroid/support/v4/app/INotificationSideChannel;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->remove()Ljava/lang/Object;
    :try_end_0
    .catch Landroid/os/DeadObjectException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v3, "itomog Renmmixeim cnuhwm tnetocEitp"

    const-string v3, "hetmogwicxmoi tencieomtRcumt iE nnp"

    const-string v3, "RemoteException communicating with "

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v3, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_1

    :catch_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v1, :cond_5

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v2, "eee ohiovsdaeRsr tm cei:d"

    const-string v2, "Remote service has died: "

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v2, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v0, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->isEmpty()Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v0, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->i(Landroidx/core/app/b4$d$a;)V

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-void

    :cond_7
    :goto_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->i(Landroidx/core/app/b4$d$a;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-void
.end method

.method private i(Landroidx/core/app/b4$d$a;)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v6, 0x5

    const/4 v2, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/os/Handler;->hasMessages(ILjava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget v0, p1, Landroidx/core/app/b4$d$a;->e:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/2addr v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v0, p1, Landroidx/core/app/b4$d$a;->e:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v6, 0x4

    const-string/jumbo v4, "ipafmbMtntaCoo"

    const-string v4, "afnCoMtpmotioa"

    const/4 v6, 0x3

    const-string/jumbo v4, "pftCaouoMNnmat"

    const-string v4, "NotifManCompat"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-le v0, v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    move v6, v5

    const-string/jumbo v1, "ign dgrpvie i veiGl noup"

    const-string v1, "Giving up on delivering "

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/util/ArrayDeque;->size()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v1, "otstkb  a "

    const/4 v6, 0x3

    const-string/jumbo v1, "ot ks s qa"

    const-string v1, " tasks to "

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object v1, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v1, " ter fu"

    const/4 v6, 0x4

    const-string v1, "eas fr "

    const-string v1, " after "

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v1, p1, Landroidx/core/app/b4$d$a;->e:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v1, "eipmert "

    const-string v1, "e striep"

    const-string v1, "esrioter"

    const-string v1, " retries"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p1, p1, Landroidx/core/app/b4$d$a;->d:Ljava/util/ArrayDeque;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/util/ArrayDeque;->clear()V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    sub-int/2addr v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    shl-int v0, v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    mul-int/lit16 v0, v0, 0x3e8

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v4, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_2

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v3, "yni  brlgtrfrqeuc Shd"

    const-string v3, " u rhcedqlrtriySen gf"

    const/4 v6, 0x3

    const-string v3, " greehut ucnoSi dfrry"

    const-string v3, "Scheduling retry for "

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    const-string v3, " ms"

    const-string/jumbo v3, "ms "

    const/4 v6, 0x5

    const-string/jumbo v3, "ms "

    const-string v3, " ms"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v4, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object p1, p1, Landroidx/core/app/b4$d$a;->a:Landroid/content/ComponentName;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v2, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    int-to-long v2, v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1, p1, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-void
.end method

.method private j()V
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v0, p0, Landroidx/core/app/b4$d;->a:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v0}, Landroidx/core/app/b4;->q(Landroid/content/Context;)Ljava/util/Set;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v1, p0, Landroidx/core/app/b4$d;->g:Ljava/util/Set;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v0, v1}, Ljava/util/Set;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x1

    if-eqz v1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    return-void

    :cond_0
    const/4 v9, 0x6

    iput-object v0, p0, Landroidx/core/app/b4$d;->g:Ljava/util/Set;

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v1, p0, Landroidx/core/app/b4$d;->a:Landroid/content/Context;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-instance v2, Landroid/content/Intent;

    const/4 v9, 0x3

    const/4 v8, 0x0

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v3, "AOCDoLspCNN.Ir_dppaID_NtBSAOdENHIToNsE_iITu.rF"

    const-string v3, "Iisrp_DdIuI.ET_NNopdEt.ATSaCoB_LNIHFCsnrONNDAO"

    const/4 v9, 0x2

    const-string/jumbo v3, "onHICTN_qCDI.DpLE.ANrNTN_aFudrpdtIEIBOASioNsO_"

    const-string v3, "android.support.BIND_NOTIFICATION_SIDE_CHANNEL"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x3

    new-instance v2, Ljava/util/HashSet;

    const/4 v9, 0x6

    const/4 v8, 0x0

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v4, "posaMfamitNCnm"

    const-string v4, "fammtaiMpNoCno"

    const/4 v9, 0x6

    const-string/jumbo v4, "mMpmCaaionttoN"

    const-string v4, "NotifManCompat"

    const/4 v9, 0x2

    const/4 v8, 0x3

    if-eqz v3, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    check-cast v3, Landroid/content/pm/ResolveInfo;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v5, v3, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    const/4 v8, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v5, v5, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-interface {v0, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-nez v5, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance v5, Landroid/content/ComponentName;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v6, v3, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v7, v6, Landroid/content/pm/ServiceInfo;->packageName:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x4

    iget-object v6, v6, Landroid/content/pm/ServiceInfo;->name:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {v5, v7, v6}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v3, v3, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v3, v3, Landroid/content/pm/ServiceInfo;->permission:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz v3, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const-string/jumbo v6, "o oeoPtnoot  enprsseionmcenpm nr"

    const-string/jumbo v6, "oentoporeipnn oP nmro eesnt csms"

    const/4 v9, 0x4

    const-string/jumbo v6, "trmopb ptonn esesii osnecenrnPm "

    const-string v6, "Permission present on component "

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string/jumbo v5, "r,a odurnedoli. nseb rtgdec t"

    const-string/jumbo v5, "rndrgb,e tdisieoletad ron .c "

    const/4 v9, 0x1

    const-string v5, " eenid.p dotl sondtra, gcnrei"

    const-string v5, ", not adding listener record."

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v4, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {v2, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_4
    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v3, 0x3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v1, :cond_6

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    check-cast v1, Landroid/content/ComponentName;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v5, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {v5, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-nez v5, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {v4, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-eqz v3, :cond_5

    const/4 v9, 0x5

    const/4 v8, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string/jumbo v5, "iofreeosq ndugeddnlrr r Ait"

    const-string/jumbo v5, "orenoiu itd Anldsdr crrgfee"

    const/4 v9, 0x2

    const-string v5, "Alsrg  cstfdedrrio edonnr i"

    const-string v5, "Adding listener record for "

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {v4, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v3, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-instance v5, Landroidx/core/app/b4$d$a;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v5, v1}, Landroidx/core/app/b4$d$a;-><init>(Landroid/content/ComponentName;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-interface {v3, v1, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto/16 :goto_1

    :cond_6
    const/4 v9, 0x3

    const/4 v8, 0x6

    iget-object v0, p0, Landroidx/core/app/b4$d;->f:Ljava/util/Map;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_7
    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-eqz v1, :cond_9

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v2, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v5, :cond_7

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v4, v3}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eqz v5, :cond_8

    const/4 v9, 0x5

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v6, "rlo Rerpeesof dir inmtonvrec "

    const-string/jumbo v6, "rnrmde t  nismfl goireRoceero"

    const-string v6, "Removing listener record for "

    const/4 v9, 0x2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v4, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_8
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x0

    check-cast v1, Landroidx/core/app/b4$d$a;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {p0, v1}, Landroidx/core/app/b4$d;->b(Landroidx/core/app/b4$d$a;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    goto/16 :goto_2

    :cond_9
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    return-void
.end method


# virtual methods
.method public h(Landroidx/core/app/b4$e;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public handleMessage(Landroid/os/Message;)Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v3, 0x1

    move v4, v3

    const/4 v1, 0x1

    xor-int/2addr v4, v1

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eq v0, v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eq v0, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v0, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    return p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast p1, Landroid/content/ComponentName;

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->d(Landroid/content/ComponentName;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    check-cast p1, Landroid/content/ComponentName;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->f(Landroid/content/ComponentName;)V

    const/4 v3, 0x6

    xor-int/2addr v4, v3

    return v1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast p1, Landroidx/core/app/b4$c;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p1, Landroidx/core/app/b4$c;->a:Landroid/content/ComponentName;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p1, Landroidx/core/app/b4$c;->b:Landroid/os/IBinder;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, v0, p1}, Landroidx/core/app/b4$d;->e(Landroid/content/ComponentName;Landroid/os/IBinder;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return v1

    :cond_3
    const/4 v4, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast p1, Landroidx/core/app/b4$e;

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Landroidx/core/app/b4$d;->c(Landroidx/core/app/b4$e;)V

    const/4 v3, 0x1

    or-int/2addr v4, v3

    return v1
.end method

.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v1, "NnptoomaqMoifC"

    const-string v1, "aopMaNomqfCnti"

    const/4 v4, 0x4

    const-string v1, "NnitobpaftoaCM"

    const-string v1, "NotifManCompat"

    const/4 v4, 0x6

    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v2, "ee  ntuitood esrsvCec"

    const-string/jumbo v2, "s svorCee en edicottc"

    const/4 v4, 0x4

    const-string/jumbo v2, "tnrseccpeCdi t o eoev"

    const-string v2, "Connected to service "

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v3, 0x2

    move v4, v3

    iget-object v0, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v1, Landroidx/core/app/b4$c;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1, p1, p2}, Landroidx/core/app/b4$c;-><init>(Landroid/content/ComponentName;Landroid/os/IBinder;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, p1, v1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "tfmnCiaMqmpota"

    const-string/jumbo v1, "pfNmatCnotmaiM"

    const-string v1, "aNsfipoMtaoCtn"

    const-string v1, "NotifManCompat"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v2, "fsDm irtcvode ec oiemnosrn"

    const-string/jumbo v2, "tDreo vcnosdcfsr miece ion"

    const/4 v4, 0x3

    const-string v2, "ccdeo icnsremso eofeiDrn v"

    const-string v2, "Disconnected from service "

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/core/app/b4$d;->c:Landroid/os/Handler;

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/os/Message;->sendToTarget()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method
