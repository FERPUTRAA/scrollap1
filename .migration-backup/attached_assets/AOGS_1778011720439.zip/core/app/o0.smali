.class public final synthetic Landroidx/core/app/o0;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sfo@tu~@~ ni@~@f~@M ~~ly@~@ 4~~  t1~~ ~@K ~S@.@~@m~  l -@@d  o@a~~icbo~//~@ o@sb@~@b  ~oo@@iv "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Landroid/app/NotificationChannel;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method
