.class public final synthetic Landroidx/core/app/z0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannelGroup;)Ljava/lang/CharSequence;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s@~ ~ o~~@~~a@~l@@si d ~@~y @o@ibSKf-@~ @t t~~@b@cbo  @v@@o mr n~i@~4o~/1l~ @ uf~~@~~o /~~.  M"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/app/NotificationChannelGroup;->getName()Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method
