.class Landroidx/core/app/unusedapprestrictions/a$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/unusedapprestrictions/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/unusedapprestrictions/a$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field public static b:Landroidx/core/app/unusedapprestrictions/a;


# instance fields
.field private a:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/unusedapprestrictions/a$b$a;->a:Landroid/os/IBinder;

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@~vl~~t tS@/~~   . ~@~y~b-@~om ~ ~ ~i co~ un~s4 o @l@1~@@~ @ ~@@~~@@@o@@ @fdir@aiMo~f/Kb@~b~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/unusedapprestrictions/a$b$a;->a:Landroid/os/IBinder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string v0, "eaRmcUspooC.eulpstaeeiptiItosnud.acktcar.tBisrdskAnrusoppndaroinbcrppea.scnldr"

    const-string/jumbo v0, "rusetBtcaounlkeanspAeolioporksI.icaRiapi.tcus.aoasnrptrrpcpr.deptcsddbdseCninU"

    const/4 v2, 0x7

    const-string/jumbo v0, "raadociasepersciAeiarsp.onbdtpekoliipBonntcUoutradx.popenctkncsupurRlsaCIr.tsd"

    const-string v0, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public w(ZZ)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "pcmrebiplaetscatai.ittbdrcnpis.cRplsnuenrnaaodpkxposeraouuk.CrsrsBUIcptieonoAd"

    const-string v1, "dosmirensdt.drupoateIudpcioap.laUkt.sprteCcsbBaoiaocrpAcksinnpnaRcinrpxesrtuel"

    const/4 v5, 0x6

    const-string v1, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    move v3, v2

    move v3, v2

    const/4 v5, 0x0

    move v3, v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    move v3, v1

    move v3, v1

    const/4 v5, 0x2

    move v3, v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    if-eqz p2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    move v1, v2

    move v1, v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/core/app/unusedapprestrictions/a$b$a;->a:Landroid/os/IBinder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v1, v2, v0, v3, v2}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    if-nez v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Landroidx/core/app/unusedapprestrictions/a$b;->c()Landroidx/core/app/unusedapprestrictions/a;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {}, Landroidx/core/app/unusedapprestrictions/a$b;->c()Landroidx/core/app/unusedapprestrictions/a;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v1, p1, p2}, Landroidx/core/app/unusedapprestrictions/a;->w(ZZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    throw p1
.end method
