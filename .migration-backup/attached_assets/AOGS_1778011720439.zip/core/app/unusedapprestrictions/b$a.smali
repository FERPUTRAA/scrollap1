.class public Landroidx/core/app/unusedapprestrictions/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/unusedapprestrictions/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/unusedapprestrictions/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public P(Landroidx/core/app/unusedapprestrictions/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@.s@ b ~~u @~  m@~ 4 t@~/bl@oMvo@i@t@ ~ a@~~n y~@~~~oS f ~d@oKo @blci @@@~~fr@~@~ s~~1@i  o~/~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    return-void
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    return-object v0
.end method
