.class public abstract Landroidx/core/app/unusedapprestrictions/a$b;
.super Landroid/os/Binder;

# interfaces
.implements Landroidx/core/app/unusedapprestrictions/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/unusedapprestrictions/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/unusedapprestrictions/a$b$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback"

.field static final b:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const-string/jumbo v0, "scsaucdop..aodstatndCsp.RaspuirkasIltpneercUneAcestaorkesbunrBippircdopxrntli."

    const-string/jumbo v0, "ssslnpiuRtos.cedp.eprtcebclrsadtc.tdoIppeioeiUiBps.urikadpoCanscnauAknxtaarnrr"

    const/4 v2, 0x5

    const-string v0, ".nemtdpeBssxUbIacnossoppaCrlpindrsoinccAdcaitktctupekpa.rrdeaaRuio.pr.soeiltur"

    const-string v0, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public static X(Landroidx/core/app/unusedapprestrictions/a;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Landroidx/core/app/unusedapprestrictions/a$b$a;->b:Landroidx/core/app/unusedapprestrictions/a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object p0, Landroidx/core/app/unusedapprestrictions/a$b$a;->b:Landroidx/core/app/unusedapprestrictions/a;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "paD)oal(lsmmce tletle dwtIiuc"

    const-string v0, "e)fm(lstdi clw IualplmcDetate"

    const-string/jumbo v0, "tIe(ebdlslacepl) etmcfwt Dlua"

    const-string/jumbo v0, "setDefaultImpl() called twice"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    throw p0
.end method

.method public static a(Landroid/os/IBinder;)Landroidx/core/app/unusedapprestrictions/a;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v0, "pppirducosisr.npauepste.unitrdiolrksaopandRnlBeaxcascdcUbrCiIsettkupAton.a.eor"

    const-string/jumbo v0, "poluoprdptnpksArsatnscrar.e.soCiRrkaepaI.leBpdtdoaiin.rdnciiutssucetUpeooncaxb"

    const/4 v3, 0x5

    const-string/jumbo v0, "rsepraipetaaepdAd.tptnarxranntuar..ntsobCi.sulduscdcckoposiccBreipRselnIpkpioo"

    const-string v0, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    instance-of v1, v0, Landroidx/core/app/unusedapprestrictions/a;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    check-cast v0, Landroidx/core/app/unusedapprestrictions/a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Landroidx/core/app/unusedapprestrictions/a$b$a;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Landroidx/core/app/unusedapprestrictions/a$b$a;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public static c()Landroidx/core/app/unusedapprestrictions/a;
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    sget-object v0, Landroidx/core/app/unusedapprestrictions/a$b$a;->b:Landroidx/core/app/unusedapprestrictions/a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    const-string v1, "eodu.iudqAnnicoaucelrlntptpdactUI.Rairiatxrsper.abnpCsoekbncpssrkdB.poserpcoat"

    const-string/jumbo v1, "pnatcbduxdcreopereou.usIsasaiconaaorpltrbpetnBiialdeCcptr.knkdRi.snr.stpsAocUp"

    const/4 v4, 0x5

    const-string v1, "aosrtkpu.idcrRuiU.ls.aaecaptnddxslceBrookctsrpeb.esdtoCesitpnupcnoaaniArspriIp"

    const-string v1, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportCallback"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eq p1, v0, :cond_1

    const/4 v3, 0x7

    and-int/2addr v4, v3

    const v2, 0x5f4e5446

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eq p1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 p3, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    move p1, v0

    move p1, v0

    const/4 v4, 0x3

    move p1, v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    move p1, p3

    move p1, p3

    const/4 v4, 0x2

    move p1, p3

    move p1, p3

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz p2, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    move p3, v0

    move p3, v0

    const/4 v4, 0x6

    move p3, v0

    move p3, v0

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {p0, p1, p3}, Landroidx/core/app/unusedapprestrictions/a;->w(ZZ)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v0
.end method
