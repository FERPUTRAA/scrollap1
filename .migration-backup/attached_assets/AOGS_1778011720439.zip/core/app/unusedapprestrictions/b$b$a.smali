.class Landroidx/core/app/unusedapprestrictions/b$b$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/unusedapprestrictions/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/unusedapprestrictions/b$b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field public static b:Landroidx/core/app/unusedapprestrictions/b;


# instance fields
.field private a:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/unusedapprestrictions/b$b$a;->a:Landroid/os/IBinder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public P(Landroidx/core/app/unusedapprestrictions/a;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~s/~@ Sro  @/~~c1~  b~ ~Mo@@@  ~ ni ~@@~~@ bioll~~ba f~uvt@~@@~@.@-~ Ko f@t~ ~~@m@o@dy@@4~s ~i@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "soamnBrsdvnecekteucitooUreaaec.Sncouiriopcrtdepsp.daixstIrunsdrAi.ppserps.Rpn"

    const-string v1, "c.si..niccotsearpoeppnvrpBxsSuaetseudonUipteiRrpdsAnu.danctcoprkdarreiiroesIs"

    const/4 v5, 0x6

    const-string v1, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v4, 0x5

    move v5, v4

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {p1}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v2, p0, Landroidx/core/app/unusedapprestrictions/b$b$a;->a:Landroid/os/IBinder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v2, v3, v0, v1, v3}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-nez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {}, Landroidx/core/app/unusedapprestrictions/b$b;->c()Landroidx/core/app/unusedapprestrictions/b;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Landroidx/core/app/unusedapprestrictions/b$b;->c()Landroidx/core/app/unusedapprestrictions/b;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v1, p1}, Landroidx/core/app/unusedapprestrictions/b;->P(Landroidx/core/app/unusedapprestrictions/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x1

    move v5, v4

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    throw p1
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/unusedapprestrictions/b$b$a;->a:Landroid/os/IBinder;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, "crrSouRdrnpr..ntsirscdcooernurspiinmsoaoUsidst.oppeeaApeancIcidtaxiptBpve.uke"

    const-string v0, "RrnmopopcdiuecieSepi.tUvipn.rsd.tpaxaItAosiBepasnuncrur.aorropecnetkdsrcdstsi"

    const/4 v2, 0x2

    const-string/jumbo v0, "onrtubSR.apapcdpuiiUIaicnsoptdcse.t.sie.risoeprndBeitecetspkreuvcxAdonrprrons"

    const-string v0, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
