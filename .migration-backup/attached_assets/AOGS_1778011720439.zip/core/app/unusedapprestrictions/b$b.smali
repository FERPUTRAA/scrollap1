.class public abstract Landroidx/core/app/unusedapprestrictions/b$b;
.super Landroid/os/Binder;

# interfaces
.implements Landroidx/core/app/unusedapprestrictions/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/unusedapprestrictions/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/unusedapprestrictions/b$b$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"

.field static final b:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "cisn.ddiicnSsrddoenvkteupppreuiappaIxUrroRoAteccuneBrsosats.sreortpp..eaicsts"

    const-string v0, "aksccIatcStoposBrinrirrs.eepvdeepntttrorpeeiapcUrsRucxnpndsdnoue.opais..iAuds"

    const/4 v2, 0x1

    const-string v0, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public static X(Landroidx/core/app/unusedapprestrictions/b;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~rm~@~@@of~//m-~~@~ i~@on@@ f@ l~@~  K@~ ~@~sl c@ @@o~db  v. iS4au ~~~~@o1ooM@ ~b~y~b@@it  t@~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Landroidx/core/app/unusedapprestrictions/b$b$a;->b:Landroidx/core/app/unusedapprestrictions/b;

    const/4 v2, 0x6

    const/4 v1, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    sput-object p0, Landroidx/core/app/unusedapprestrictions/b$b$a;->b:Landroidx/core/app/unusedapprestrictions/b;

    const/4 v1, 0x3

    move v2, v1

    const/4 p0, 0x1

    move v2, p0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "seeuoflIapl)lm(mlDet dwtcic e"

    const-string v0, "a)lmceiftdeIlsaueemlcDt (wpl "

    const-string/jumbo v0, "ttdclbemDa uflsaet(lIile)pwe "

    const-string/jumbo v0, "setDefaultImpl() called twice"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p0
.end method

.method public static a(Landroid/os/IBinder;)Landroidx/core/app/unusedapprestrictions/b;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x6

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "doxvkpuurs.rocSnpatroi.utBpppceancnueptsidieaeoar.rsrcInseisRidicntoprsdAteUe"

    const-string v0, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    instance-of v1, v0, Landroidx/core/app/unusedapprestrictions/b;

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    check-cast v0, Landroidx/core/app/unusedapprestrictions/b;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x0

    new-instance v0, Landroidx/core/app/unusedapprestrictions/b$b$a;

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Landroidx/core/app/unusedapprestrictions/b$b$a;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method

.method public static c()Landroidx/core/app/unusedapprestrictions/b;
    .locals 3

    const/4 v1, 0x6

    sget-object v0, Landroidx/core/app/unusedapprestrictions/b$b$a;->b:Landroidx/core/app/unusedapprestrictions/b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "teatsippiatSoxnoapcrcdsscpi.rRrpeer.eritiuekvonpspnA.seBacsu.drIntoreipocundU"

    const-string v1, "androidx.core.app.unusedapprestrictions.IUnusedAppRestrictionsBackportService"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq p1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const v2, 0x5f4e5446

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eq p1, v2, :cond_0

    const/4 v4, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    return p1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1}, Landroidx/core/app/unusedapprestrictions/a$b;->a(Landroid/os/IBinder;)Landroidx/core/app/unusedapprestrictions/a;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p0, p1}, Landroidx/core/app/unusedapprestrictions/b;->P(Landroidx/core/app/unusedapprestrictions/a;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    return v0
.end method
