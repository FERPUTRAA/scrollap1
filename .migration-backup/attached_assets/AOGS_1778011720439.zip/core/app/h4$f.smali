.class public final Landroidx/core/app/h4$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/h4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Landroid/os/Bundle;

.field private d:Ljava/lang/CharSequence;

.field private e:[Ljava/lang/CharSequence;

.field private f:Z

.field private g:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Ljava/util/HashSet;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Landroidx/core/app/h4$f;->b:Ljava/util/Set;

    const/4 v2, 0x4

    const/4 v1, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/h4$f;->c:Landroid/os/Bundle;

    const/4 v1, 0x6

    move v2, v1

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p0, Landroidx/core/app/h4$f;->f:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Landroidx/core/app/h4$f;->g:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/core/app/h4$f;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "/useelnn ba kctyR/lssulet"

    const-string/jumbo v0, "uts lle/asn bcnye etluRk/"

    const/4 v2, 0x7

    const-string v0, " elmen/n  etklu tlc/byuas"

    const-string v0, "Result key can\'t be null"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    throw p1
.end method


# virtual methods
.method public a(Landroid/os/Bundle;)Landroidx/core/app/h4$f;
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "s/ oo@@ ~~~ ~@ @ftf@@y~~@.~4~@  @bS~ o rMo~ ~i@l bKlo~~a/~~t@oi@b~~ @@@~@1v @n~@   @~o~-dci~m @u"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/h4$f;->c:Landroid/os/Bundle;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public b()Landroidx/core/app/h4;
    .locals 11
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v9, 0x5

    move v10, v9

    new-instance v8, Landroidx/core/app/h4;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v1, p0, Landroidx/core/app/h4$f;->a:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v2, p0, Landroidx/core/app/h4$f;->d:Ljava/lang/CharSequence;

    const/4 v10, 0x0

    iget-object v3, p0, Landroidx/core/app/h4$f;->e:[Ljava/lang/CharSequence;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-boolean v4, p0, Landroidx/core/app/h4$f;->f:Z

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget v5, p0, Landroidx/core/app/h4$f;->g:I

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v6, p0, Landroidx/core/app/h4$f;->c:Landroid/os/Bundle;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v7, p0, Landroidx/core/app/h4$f;->b:Ljava/util/Set;

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-direct/range {v0 .. v7}, Landroidx/core/app/h4;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZILandroid/os/Bundle;Ljava/util/Set;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    return-object v8
.end method

.method public c()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/h4$f;->c:Landroid/os/Bundle;

    const/4 v2, 0x4

    return-object v0
.end method

.method public d(Ljava/lang/String;Z)Landroidx/core/app/h4$f;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p2, p0, Landroidx/core/app/h4$f;->b:Ljava/util/Set;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-interface {p2, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget-object p2, p0, Landroidx/core/app/h4$f;->b:Ljava/util/Set;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-interface {p2, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    :goto_0
    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p0
.end method

.method public e(Z)Landroidx/core/app/h4$f;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-boolean p1, p0, Landroidx/core/app/h4$f;->f:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method public f([Ljava/lang/CharSequence;)Landroidx/core/app/h4$f;
    .locals 2
    .param p1    # [Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/core/app/h4$f;->e:[Ljava/lang/CharSequence;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public g(I)Landroidx/core/app/h4$f;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p1, p0, Landroidx/core/app/h4$f;->g:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p0
.end method

.method public h(Ljava/lang/CharSequence;)Landroidx/core/app/h4$f;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/app/h4$f;->d:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method
