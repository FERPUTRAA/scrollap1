.class public abstract Landroidx/core/app/k4;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/k4$a;
    }
.end annotation


# static fields
.field private static final b:I = 0x100000

.field private static final c:Ljava/lang/String; = "sharedElement:snapshot:bitmap"

.field private static final d:Ljava/lang/String; = "sharedElement:snapshot:imageScaleType"

.field private static final e:Ljava/lang/String; = "sharedElement:snapshot:imageMatrix"


# instance fields
.field private a:Landroid/graphics/Matrix;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    return-void
.end method

.method private static a(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "@~s@/ ~~~f~i @~o1 K@@/@ io4 ~ co.l~ t@~b~~@@@bb  ~@ ~M~~fn sa~~@oo~ im~u S@y d@@~@~to r-v@ @@~@l"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-lez v0, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-gtz v1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    mul-int v2, v0, v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    int-to-float v2, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/high16 v3, 0x49800000    # 1048576.0f

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    div-float/2addr v3, v2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    instance-of v4, p0, Landroid/graphics/drawable/BitmapDrawable;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz v4, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    cmpl-float v2, v3, v2

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-nez v2, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    check-cast p0, Landroid/graphics/drawable/BitmapDrawable;

    const/4 v10, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    return-object p0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x1

    int-to-float v0, v0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    mul-float/2addr v0, v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    float-to-int v0, v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    int-to-float v1, v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    mul-float/2addr v1, v3

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    float-to-int v1, v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    sget-object v2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {v0, v1, v2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance v3, Landroid/graphics/Canvas;

    const/4 v9, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-direct {v3, v2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget v5, v4, Landroid/graphics/Rect;->left:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    iget v6, v4, Landroid/graphics/Rect;->top:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget v7, v4, Landroid/graphics/Rect;->right:I

    const/4 v10, 0x3

    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x1

    invoke-virtual {p0, v8, v8, v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p0, v3}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p0, v5, v6, v7, v4}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    return-object v2

    :cond_2
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 p0, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    return-object p0
.end method


# virtual methods
.method public b(Landroid/view/View;Landroid/graphics/Matrix;Landroid/graphics/RectF;)Landroid/os/Parcelable;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    instance-of v0, p1, Landroid/widget/ImageView;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    check-cast v0, Landroid/widget/ImageView;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v1}, Landroidx/core/app/k4;->a(Landroid/graphics/drawable/Drawable;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance p1, Landroid/os/Bundle;

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string p2, "hpsmtneaEtp:thsmr:sedonmiasla"

    const-string/jumbo p2, "thsar:Eesimtlmn:aaodstheespnp"

    const/4 v5, 0x4

    const-string p2, "Ehpeolthamsbpnaea:toemirsntsd"

    const-string/jumbo p2, "sharedElement:snapshot:bitmap"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1, p2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/widget/ImageView;->getScaleType()Landroid/widget/ImageView$ScaleType;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo p3, "stpy:bnmaecmeoilemehdpeshlrsa:gtSTaae"

    const-string p3, "cmamtSeldeeeaeht:ipsgonT:ylaphssaremn"

    const/4 v5, 0x4

    const-string/jumbo p3, "tSa:tcumTlElnsarsedhegy:oeshanpieeeap"

    const-string/jumbo p3, "sharedElement:snapshot:imageScaleType"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, p3, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/widget/ImageView;->getScaleType()Landroid/widget/ImageView$ScaleType;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object p3, Landroid/widget/ImageView$ScaleType;->MATRIX:Landroid/widget/ImageView$ScaleType;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-ne p2, p3, :cond_0

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/widget/ImageView;->getImageMatrix()Landroid/graphics/Matrix;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 p3, 0x9

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-array p3, p3, [F

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p2, p3}, Landroid/graphics/Matrix;->getValues([F)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string p2, "haoMEioperrxhead:ntaegassitt:psmne"

    const-string/jumbo p2, "soniolaserMeemnh:a:xdpgetthEsirata"

    const/4 v5, 0x1

    const-string/jumbo p2, "ro:slemaqrExdiheMtgiapnmsantsae:ht"

    const-string/jumbo p2, "sharedElement:snapshot:imageMatrix"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1, p2, p3}, Landroid/os/Bundle;->putFloatArray(Ljava/lang/String;[F)V

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object p1

    :cond_1
    const/4 v4, 0x1

    invoke-virtual {p3}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p3}, Landroid/graphics/RectF;->height()F

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    if-lez v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-lez v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    mul-int v2, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    int-to-float v2, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/high16 v3, 0x49800000    # 1048576.0f

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    div-float/2addr v3, v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v2, v3}, Ljava/lang/Math;->min(FF)F

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    int-to-float v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    mul-float/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    float-to-int v0, v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    int-to-float v1, v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    mul-float/2addr v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    float-to-int v1, v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v3, p0, Landroidx/core/app/k4;->a:Landroid/graphics/Matrix;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v3, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v3, Landroid/graphics/Matrix;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v3}, Landroid/graphics/Matrix;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-object v3, p0, Landroidx/core/app/k4;->a:Landroid/graphics/Matrix;

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v3, p0, Landroidx/core/app/k4;->a:Landroid/graphics/Matrix;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v3, p2}, Landroid/graphics/Matrix;->set(Landroid/graphics/Matrix;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p2, p0, Landroidx/core/app/k4;->a:Landroid/graphics/Matrix;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v3, p3, Landroid/graphics/RectF;->left:F

    const/4 v5, 0x6

    const/4 v4, 0x6

    neg-float v3, v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget p3, p3, Landroid/graphics/RectF;->top:F

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    neg-float p3, p3

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    invoke-virtual {p2, v3, p3}, Landroid/graphics/Matrix;->postTranslate(FF)Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    iget-object p2, p0, Landroidx/core/app/k4;->a:Landroid/graphics/Matrix;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p2, v2, v2}, Landroid/graphics/Matrix;->postScale(FF)Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget-object p2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v0, v1, p2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p3, Landroid/graphics/Canvas;

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p3, p2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/core/app/k4;->a:Landroid/graphics/Matrix;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p3, v0}, Landroid/graphics/Canvas;->concat(Landroid/graphics/Matrix;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1, p3}, Landroid/view/View;->draw(Landroid/graphics/Canvas;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 p2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p2
.end method

.method public c(Landroid/content/Context;Landroid/os/Parcelable;)Landroid/view/View;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    instance-of v0, p2, Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p2, Landroid/os/Bundle;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v0, "eassonahsEnp:mrdtela:emhisbtb"

    const-string v0, "a:eeabpstrnmmshpbahdoelE:nits"

    const/4 v3, 0x1

    const-string/jumbo v0, "tammdhbsiaoe:tp:rslnmeansEthe"

    const-string/jumbo v0, "sharedElement:snapshot:bitmap"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Landroid/graphics/Bitmap;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    new-instance v1, Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v1, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string p1, "edpeoimrTssnpSaesmltoac:lghnhe:utyeae"

    const-string p1, "gaarp:ueeedSmTatetily:smnnecphssEhleo"

    const/4 v3, 0x5

    const-string/jumbo p1, "nesrlbesEo:SacayheppdeeimnTalastmeght"

    const-string/jumbo p1, "sharedElement:snapshot:imageScaleType"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p2, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Landroid/widget/ImageView$ScaleType;->valueOf(Ljava/lang/String;)Landroid/widget/ImageView$ScaleType;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Landroid/widget/ImageView;->setScaleType(Landroid/widget/ImageView$ScaleType;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroid/widget/ImageView;->getScaleType()Landroid/widget/ImageView$ScaleType;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v0, Landroid/widget/ImageView$ScaleType;->MATRIX:Landroid/widget/ImageView$ScaleType;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne p1, v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string p1, "elni:musapMaeoti:pamngetxsshdteEra"

    const-string/jumbo p1, "xsatrnrpeEi:d:mgsoheenliMamtatasep"

    const/4 v3, 0x3

    const-string/jumbo p1, "niamtoEppehasihtsmerrnMltxseaedg::"

    const-string/jumbo p1, "sharedElement:snapshot:imageMatrix"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2, p1}, Landroid/os/Bundle;->getFloatArray(Ljava/lang/String;)[F

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance p2, Landroid/graphics/Matrix;

    const/4 v3, 0x7

    invoke-direct {p2}, Landroid/graphics/Matrix;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Landroid/graphics/Matrix;->setValues([F)V

    const/4 v3, 0x7

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setImageMatrix(Landroid/graphics/Matrix;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    instance-of v0, p2, Landroid/graphics/Bitmap;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    check-cast p2, Landroid/graphics/Bitmap;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v1, Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v1, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, p2}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    :cond_2
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v1
.end method

.method public d(Ljava/util/List;Ljava/util/Map;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/view/View;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public e(Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method

.method public f(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public g(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    return-void
.end method

.method public h(Ljava/util/List;Ljava/util/List;Landroidx/core/app/k4$a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Landroid/view/View;",
            ">;",
            "Landroidx/core/app/k4$a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-interface {p3}, Landroidx/core/app/k4$a;->a()V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
