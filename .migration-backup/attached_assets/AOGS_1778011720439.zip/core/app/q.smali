.class public final synthetic Landroidx/core/app/q;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/job/JobParameters;Landroid/app/job/JobWorkItem;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@s- tv@bbo c~@.~~@lf4u~~@~K ~@@f~o i /n~@~@@@ t  o@ @m ~ M~ @y~d~~o@@~il~@/@ria~os~S~  ~@ b ~1 "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/app/job/JobParameters;->completeWork(Landroid/app/job/JobWorkItem;)V

    const/4 v1, 0x6

    return-void
.end method
