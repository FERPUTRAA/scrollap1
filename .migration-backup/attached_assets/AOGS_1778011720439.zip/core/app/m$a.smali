.class Landroidx/core/app/m$a;
.super Landroidx/core/app/m$b;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x18
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field private static final e:I = 0xf4240

.field private static final f:I = 0x7a120

.field private static g:Landroid/os/HandlerThread;

.field private static h:Landroid/os/Handler;


# instance fields
.field a:I

.field b:[Landroid/util/SparseIntArray;

.field private final c:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/ref/WeakReference<",
            "Landroid/app/Activity;",
            ">;>;"
        }
    .end annotation
.end field

.field d:Landroid/view/Window$OnFrameMetricsAvailableListener;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    return-void
.end method

.method constructor <init>(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Landroidx/core/app/m$b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 v0, 0x9

    const/4 v2, 0x6

    new-array v0, v0, [Landroid/util/SparseIntArray;

    const/4 v2, 0x0

    const/4 v1, 0x2

    iput-object v0, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance v0, Landroidx/core/app/m$a$a;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Landroidx/core/app/m$a$a;-><init>(Landroidx/core/app/m$a;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/m$a;->d:Landroid/view/Window$OnFrameMetricsAvailableListener;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Landroidx/core/app/m$a;->a:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a(Landroid/app/Activity;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s i@f4o@o@c@@~~Sb@/~  l  @ m@oMu ~o 1~ ts@i~@roio /d~@~@l~~ty~ @- K @~~ ~@n@f ab~~.@b~ @~~v~@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    sget-object v0, Landroidx/core/app/m$a;->g:Landroid/os/HandlerThread;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v0, Landroid/os/HandlerThread;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v1, "MFemrgAsggratioamcstre"

    const-string v1, "agsgoercirsaremtgetFAM"

    const/4 v5, 0x6

    const-string v1, "gtmrogeoFtrraesegrAiac"

    const-string v1, "FrameMetricsAggregator"

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v0, v1}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    sput-object v0, Landroidx/core/app/m$a;->g:Landroid/os/HandlerThread;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Landroid/os/Handler;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-object v1, Landroidx/core/app/m$a;->g:Landroid/os/HandlerThread;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    sput-object v0, Landroidx/core/app/m$a;->h:Landroid/os/Handler;

    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/16 v1, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-gt v0, v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    aget-object v2, v1, v0

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    if-nez v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget v2, p0, Landroidx/core/app/m$a;->a:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    shl-int/2addr v3, v0

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    and-int/2addr v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    new-instance v2, Landroid/util/SparseIntArray;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v2}, Landroid/util/SparseIntArray;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x6

    aput-object v2, v1, v0

    :cond_1
    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v1, p0, Landroidx/core/app/m$a;->d:Landroid/view/Window$OnFrameMetricsAvailableListener;

    const/4 v5, 0x5

    const/4 v4, 0x7

    sget-object v2, Landroidx/core/app/m$a;->h:Landroid/os/Handler;

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    invoke-virtual {v0, v1, v2}, Landroid/view/Window;->addOnFrameMetricsAvailableListener(Landroid/view/Window$OnFrameMetricsAvailableListener;Landroid/os/Handler;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v4, 0x5

    move v5, v4

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x7

    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method public b()[Landroid/util/SparseIntArray;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public c(Landroid/app/Activity;)[Landroid/util/SparseIntArray;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    check-cast v1, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ne v2, p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    :cond_1
    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/core/app/m$a;->d:Landroid/view/Window$OnFrameMetricsAvailableListener;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Landroid/view/Window;->removeOnFrameMetricsAvailableListener(Landroid/view/Window$OnFrameMetricsAvailableListener;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p1
.end method

.method public d()[Landroid/util/SparseIntArray;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v3, 0x3

    const/16 v1, 0x9

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-array v1, v1, [Landroid/util/SparseIntArray;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v1, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method public e()[Landroid/util/SparseIntArray;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-ltz v0, :cond_1

    const/4 v4, 0x2

    iget-object v1, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v1, Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast v2, Landroid/app/Activity;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Landroidx/core/app/m$a;->d:Landroid/view/Window$OnFrameMetricsAvailableListener;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Landroid/view/Window;->removeOnFrameMetricsAvailableListener(Landroid/view/Window$OnFrameMetricsAvailableListener;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/core/app/m$a;->c:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/core/app/m$a;->b:[Landroid/util/SparseIntArray;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object v0
.end method

.method f(Landroid/util/SparseIntArray;J)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-wide/32 v0, 0x7a120

    const-wide/32 v0, 0x7a120

    const/4 v5, 0x5

    const-wide/32 v0, 0x7a120

    const-wide/32 v0, 0x7a120

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    add-long/2addr v0, p2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-wide/32 v2, 0xf4240

    const-wide/32 v2, 0xf4240

    const/4 v5, 0x4

    const-wide/32 v2, 0xf4240

    const-wide/32 v2, 0xf4240

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    div-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    long-to-int v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    cmp-long p2, p2, v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ltz p2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/util/SparseIntArray;->get(I)I

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x3

    add-int/lit8 p2, p2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1, v0, p2}, Landroid/util/SparseIntArray;->put(II)V

    :cond_0
    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method
