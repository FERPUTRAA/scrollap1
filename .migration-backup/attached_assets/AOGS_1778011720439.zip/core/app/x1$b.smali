.class public Landroidx/core/app/x1$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/x1$b$c;,
        Landroidx/core/app/x1$b$d;,
        Landroidx/core/app/x1$b$b;,
        Landroidx/core/app/x1$b$a;
    }
.end annotation


# static fields
.field public static final m:I = 0x0

.field public static final n:I = 0x1

.field public static final o:I = 0x2

.field public static final p:I = 0x3

.field public static final q:I = 0x4

.field public static final r:I = 0x5

.field public static final s:I = 0x6

.field public static final t:I = 0x7

.field public static final u:I = 0x8

.field public static final v:I = 0x9

.field public static final w:I = 0xa

.field static final x:Ljava/lang/String; = "android.support.action.showsUserInterface"

.field static final y:Ljava/lang/String; = "android.support.action.semanticAction"


# instance fields
.field final a:Landroid/os/Bundle;

.field private b:Landroidx/core/graphics/drawable/IconCompat;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private final c:[Landroidx/core/app/h4;

.field private final d:[Landroidx/core/app/h4;

.field private e:Z

.field f:Z

.field private final g:I

.field private final h:Z

.field public i:I
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public j:Ljava/lang/CharSequence;

.field public k:Landroid/app/PendingIntent;

.field private l:Z


# direct methods
.method public constructor <init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V
    .locals 4
    .param p2    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x0

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0, v1, p1}, Landroidx/core/graphics/drawable/IconCompat;->y(Landroid/content/res/Resources;Ljava/lang/String;I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, v0, p2, p3}, Landroidx/core/app/x1$b;-><init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method constructor <init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V
    .locals 14
    .param p2    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # [Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p6    # [Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    move v0, p1

    move v0, p1

    const/4 v1, 0x0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    const-string v2, ""

    const-string v2, ""

    invoke-static {v1, v2, p1}, Landroidx/core/graphics/drawable/IconCompat;->y(Landroid/content/res/Resources;Ljava/lang/String;I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v1

    :goto_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v5, p3

    move-object/from16 v6, p4

    move-object/from16 v6, p4

    move-object/from16 v6, p4

    move-object/from16 v6, p4

    move-object/from16 v7, p5

    move-object/from16 v7, p5

    move-object/from16 v7, p5

    move-object/from16 v7, p5

    move-object/from16 v8, p6

    move-object/from16 v8, p6

    move-object/from16 v8, p6

    move-object/from16 v8, p6

    move/from16 v9, p7

    move/from16 v9, p7

    move/from16 v9, p7

    move/from16 v9, p7

    move/from16 v10, p8

    move/from16 v10, p8

    move/from16 v10, p8

    move/from16 v10, p8

    move/from16 v11, p9

    move/from16 v11, p9

    move/from16 v11, p9

    move/from16 v11, p9

    move/from16 v12, p10

    move/from16 v12, p10

    move/from16 v13, p11

    move/from16 v13, p11

    move/from16 v13, p11

    invoke-direct/range {v2 .. v13}, Landroidx/core/app/x1$b;-><init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V

    return-void
.end method

.method public constructor <init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V
    .locals 12
    .param p1    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    new-instance v4, Landroid/os/Bundle;

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    invoke-direct/range {v0 .. v11}, Landroidx/core/app/x1$b;-><init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V

    return-void
.end method

.method constructor <init>(Landroidx/core/graphics/drawable/IconCompat;Ljava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V
    .locals 4
    .param p1    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # [Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p6    # [Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x6

    iput-boolean v0, p0, Landroidx/core/app/x1$b;->f:Z

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroidx/core/graphics/drawable/IconCompat;->D()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroidx/core/graphics/drawable/IconCompat;->A()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput p1, p0, Landroidx/core/app/x1$b;->i:I

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p2}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$b;->j:Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p3, p0, Landroidx/core/app/x1$b;->k:Landroid/app/PendingIntent;

    const/4 v3, 0x5

    const/4 v2, 0x4

    if-eqz p4, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p4, Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p4}, Landroid/os/Bundle;-><init>()V

    :goto_0
    const/4 v3, 0x4

    iput-object p4, p0, Landroidx/core/app/x1$b;->a:Landroid/os/Bundle;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object p5, p0, Landroidx/core/app/x1$b;->c:[Landroidx/core/app/h4;

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p6, p0, Landroidx/core/app/x1$b;->d:[Landroidx/core/app/h4;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-boolean p7, p0, Landroidx/core/app/x1$b;->e:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput p8, p0, Landroidx/core/app/x1$b;->g:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-boolean p9, p0, Landroidx/core/app/x1$b;->f:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-boolean p10, p0, Landroidx/core/app/x1$b;->h:Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-boolean p11, p0, Landroidx/core/app/x1$b;->l:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public a()Landroid/app/PendingIntent;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ".os~  ~Ko@ibl@@u/fnvS@l ~t @o@  M@ f~  o@to~@@ r @~@~@ ~~~a@~s  d/ ~@~~@@~m~ yi@~-~o@~~1c~b@b4~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$b;->k:Landroid/app/PendingIntent;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/core/app/x1$b;->e:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public c()[Landroidx/core/app/h4;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/x1$b;->d:[Landroidx/core/app/h4;

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-object v0
.end method

.method public d()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$b;->a:Landroid/os/Bundle;

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public e()I
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Landroidx/core/app/x1$b;->i:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public f()Landroidx/core/graphics/drawable/IconCompat;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x1

    iget v0, p0, Landroidx/core/app/x1$b;->i:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Landroidx/core/graphics/drawable/IconCompat;->y(Landroid/content/res/Resources;Ljava/lang/String;I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Landroidx/core/app/x1$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$b;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method

.method public g()[Landroidx/core/app/h4;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/app/x1$b;->c:[Landroidx/core/app/h4;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public h()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    iget v0, p0, Landroidx/core/app/x1$b;->g:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    return v0
.end method

.method public i()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/core/app/x1$b;->f:Z

    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public j()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$b;->j:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    return-object v0
.end method

.method public k()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/core/app/x1$b;->l:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public l()Z
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Landroidx/core/app/x1$b;->h:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method
