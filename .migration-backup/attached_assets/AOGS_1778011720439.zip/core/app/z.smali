.class public final synthetic Landroidx/core/app/z;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~@bfs@~@@~@b~v ~ l @~ @~o@@~~iS@r@4   @~K~~i~1  yo~at@~ l M~~d~i@~ @@fnoc oom ~~/.  t~o /b@u@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->canShowBadge()Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p0
.end method
