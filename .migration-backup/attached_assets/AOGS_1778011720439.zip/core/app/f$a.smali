.class Landroidx/core/app/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/app/f;->i(Landroid/app/Activity;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/core/app/f$d;

.field final synthetic b:Ljava/lang/Object;


# direct methods
.method constructor <init>(Landroidx/core/app/f$d;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/f$a;->a:Landroidx/core/app/f$d;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Landroidx/core/app/f$a;->b:Ljava/lang/Object;

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s@bM~@o a@Si~v  l~~@n@@~ ~@~@/@o r~K@o~~f@o @l~   @ cm ~-~id@o @/@f  ~b@~~@toyb@i~1~ ~4~u~s.@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/f$a;->a:Landroidx/core/app/f$d;

    const/4 v3, 0x5

    const/4 v2, 0x2

    iget-object v1, p0, Landroidx/core/app/f$a;->b:Ljava/lang/Object;

    const/4 v3, 0x4

    iput-object v1, v0, Landroidx/core/app/f$d;->a:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method
