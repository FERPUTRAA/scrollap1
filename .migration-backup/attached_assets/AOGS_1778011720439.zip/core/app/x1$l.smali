.class public Landroidx/core/app/x1$l;
.super Landroidx/core/app/x1$q;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "l"
.end annotation


# static fields
.field private static final f:Ljava/lang/String; = "androidx.core.app.NotificationCompat$InboxStyle"


# instance fields
.field private e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/CharSequence;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/x1$l;->e:Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Landroidx/core/app/x1$g;)V
    .locals 3
    .param p1    # Landroidx/core/app/x1$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    iput-object v0, p0, Landroidx/core/app/x1$l;->e:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroidx/core/app/x1$q;->z(Landroidx/core/app/x1$g;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public A(Ljava/lang/CharSequence;)Landroidx/core/app/x1$l;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@1s@/~@ ~y~~Mid~@o@K @ bb@@~t@~c @~~~ l   ~u  s~to@@~~~ oii~/~~b4ln@@a~~@oSf~o@ @f  @@ ~m  -or@."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$l;->e:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public B(Ljava/lang/CharSequence;)Landroidx/core/app/x1$l;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method public C(Ljava/lang/CharSequence;)Landroidx/core/app/x1$l;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p1, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 p1, 0x1

    move v1, p1

    iput-boolean p1, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public b(Landroidx/core/app/v;)V
    .locals 4
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Landroid/app/Notification$InboxStyle;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, p1}, Landroid/app/Notification$InboxStyle;-><init>(Landroid/app/Notification$Builder;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p1, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/app/Notification$InboxStyle;->setBigContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$InboxStyle;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-boolean v0, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/app/Notification$InboxStyle;->setSummaryText(Ljava/lang/CharSequence;)Landroid/app/Notification$InboxStyle;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/x1$l;->e:Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/CharSequence;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v1}, Landroid/app/Notification$InboxStyle;->addLine(Ljava/lang/CharSequence;)Landroid/app/Notification$InboxStyle;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method protected g(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->g(Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string/jumbo v0, "idnm.eeaLitrsdosn"

    const-string/jumbo v0, "tosnti.ddrnisaLee"

    const/4 v2, 0x0

    const-string v0, ".nsnoeierxdttadLo"

    const-string v0, "android.textLines"

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x7

    return-void
.end method

.method protected t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, ".Soeabotm.oaxpdeipoylritNIc.xiamfCntnoiar$pcdbo"

    const-string v0, "baimomdtad.opxetpaenrr$oiInxlftc.oaiooCtNSyic.p"

    const/4 v2, 0x3

    const-string/jumbo v0, "x$fetruomoaoainlSdNycptidnbpxpoo.oiacrenI.Ctia."

    const-string v0, "androidx.core.app.NotificationCompat$InboxStyle"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method protected y(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->y(Landroid/os/Bundle;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$l;->e:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v3, 0x2

    const-string v0, "Lnide.xprsotoinea"

    const-string v0, ".iidoteLrasoexdnn"

    const-string v0, "aLsendd.qeinttior"

    const-string v0, "android.textLines"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/core/app/x1$l;->e:Ljava/util/ArrayList;

    const/4 v2, 0x2

    or-int/2addr v3, v2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequenceArray(Ljava/lang/String;)[Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v1, p1}, Ljava/util/Collections;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method
