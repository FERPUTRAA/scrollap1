.class public final synthetic Landroidx/core/app/o1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification;)Landroid/content/LocusId;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~vst/~bilu~~ l  @.Kb@@i@os~ @~n ~@@/@ m@@~rM -~~1yo o c@ ~d@ @~@@@~b tS~@~ a  f~~~~~ @i@@o~of~o "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/app/Notification;->getLocusId()Landroid/content/LocusId;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method
