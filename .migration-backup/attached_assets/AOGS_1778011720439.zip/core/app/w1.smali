.class public final synthetic Landroidx/core/app/w1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Action;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@is ~~~nv t~ @ o  @a~/@~o~@@~@Ko@m@tc~s@~@@b @@i@~~l@1@~ ~@~ di/r~ @Sl~ o-o~M  ~~ ~ubof~y 4b  f@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/app/Notification$Action;->getSemanticAction()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p0
.end method
