.class public final synthetic Landroidx/core/app/s;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Landroid/content/Intent;)Landroid/app/job/JobWorkItem;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@@ob d~@ /c @.~ o@/ ua~o~@@@@o~b4mi~ ~M@i~v ~i@~bo~~ @l S r @K~ f~~-@o yft@@@l1~~@~n @~ s~ ~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Landroid/app/job/JobWorkItem;

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Landroid/app/job/JobWorkItem;-><init>(Landroid/content/Intent;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method
