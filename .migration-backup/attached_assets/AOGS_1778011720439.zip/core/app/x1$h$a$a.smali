.class public Landroidx/core/app/x1$h$a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1$h$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/lang/String;

.field private c:Landroidx/core/app/h4;

.field private d:Landroid/app/PendingIntent;

.field private e:Landroid/app/PendingIntent;

.field private f:J


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/x1$h$a$a;->a:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/core/app/x1$h$a$a;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Landroidx/core/app/x1$h$a$a;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ls@ m ~ d ~ ~ /yl~ @~ @ @@a@ v~u~oc@~@~~~ n~K~@~fit@ i@rof~M~ bt-@~ @o@@@1~@~4 o~so .@b~oiSb /@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$h$a$a;->a:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public b()Landroidx/core/app/x1$h$a;
    .locals 11
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$h$a$a;->a:Ljava/util/List;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-array v1, v1, [Ljava/lang/String;

    const/4 v10, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    check-cast v2, [Ljava/lang/String;

    const/4 v10, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$h$a$a;->b:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    new-instance v0, Landroidx/core/app/x1$h$a;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v3, p0, Landroidx/core/app/x1$h$a$a;->c:Landroidx/core/app/h4;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object v4, p0, Landroidx/core/app/x1$h$a$a;->e:Landroid/app/PendingIntent;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v5, p0, Landroidx/core/app/x1$h$a$a;->d:Landroid/app/PendingIntent;

    const/4 v10, 0x2

    const/4 v9, 0x6

    iget-wide v7, p0, Landroidx/core/app/x1$h$a$a;->f:J

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct/range {v1 .. v8}, Landroidx/core/app/x1$h$a;-><init>([Ljava/lang/String;Landroidx/core/app/h4;Landroid/app/PendingIntent;Landroid/app/PendingIntent;[Ljava/lang/String;J)V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    return-object v0
.end method

.method public c(J)Landroidx/core/app/x1$h$a$a;
    .locals 2
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-wide p1, p0, Landroidx/core/app/x1$h$a$a;->f:J

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public d(Landroid/app/PendingIntent;)Landroidx/core/app/x1$h$a$a;
    .locals 2
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/core/app/x1$h$a$a;->d:Landroid/app/PendingIntent;

    const/4 v0, 0x4

    shl-int/2addr v1, v0

    return-object p0
.end method

.method public e(Landroid/app/PendingIntent;Landroidx/core/app/h4;)Landroidx/core/app/x1$h$a$a;
    .locals 2
    .param p1    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroidx/core/app/h4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p2, p0, Landroidx/core/app/x1$h$a$a;->c:Landroidx/core/app/h4;

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$h$a$a;->e:Landroid/app/PendingIntent;

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-object p0
.end method
