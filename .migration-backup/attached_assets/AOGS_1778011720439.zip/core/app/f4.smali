.class public Landroidx/core/app/f4;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/f4$b;,
        Landroidx/core/app/f4$a;,
        Landroidx/core/app/f4$c;
    }
.end annotation


# static fields
.field private static final g:Ljava/lang/String; = "name"

.field private static final h:Ljava/lang/String; = "icon"

.field private static final i:Ljava/lang/String; = "uri"

.field private static final j:Ljava/lang/String; = "key"

.field private static final k:Ljava/lang/String; = "isBot"

.field private static final l:Ljava/lang/String; = "isImportant"


# instance fields
.field a:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field b:Landroidx/core/graphics/drawable/IconCompat;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field c:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field d:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field e:Z

.field f:Z


# direct methods
.method constructor <init>(Landroidx/core/app/f4$c;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    iget-object v0, p1, Landroidx/core/app/f4$c;->a:Ljava/lang/CharSequence;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p1, Landroidx/core/app/f4$c;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/f4;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x7

    iget-object v0, p1, Landroidx/core/app/f4$c;->c:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/core/app/f4;->c:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object v0, p1, Landroidx/core/app/f4$c;->d:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/f4;->d:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean v0, p1, Landroidx/core/app/f4$c;->e:Z

    const/4 v2, 0x5

    iput-boolean v0, p0, Landroidx/core/app/f4;->e:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-boolean p1, p1, Landroidx/core/app/f4$c;->f:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-boolean p1, p0, Landroidx/core/app/f4;->f:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public static a(Landroid/app/Person;)Landroidx/core/app/f4;
    .locals 2
    .param p0    # Landroid/app/Person;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1c
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {p0}, Landroidx/core/app/f4$b;->a(Landroid/app/Person;)Landroidx/core/app/f4;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public static b(Landroid/os/Bundle;)Landroidx/core/app/f4;
    .locals 5
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    move v4, v3

    const-string v0, "cnio"

    const/4 v4, 0x3

    const-string v0, "cino"

    const-string/jumbo v0, "icon"

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v1, Landroidx/core/app/f4$c;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v2, "naem"

    const-string/jumbo v2, "name"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, v2}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0}, Landroidx/core/graphics/drawable/IconCompat;->l(Landroid/os/Bundle;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Landroidx/core/app/f4$c;->c(Landroidx/core/graphics/drawable/IconCompat;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v1, "riu"

    const-string/jumbo v1, "iur"

    const/4 v4, 0x0

    const-string/jumbo v1, "rui"

    const-string/jumbo v1, "uri"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->g(Ljava/lang/String;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v1, "yke"

    const-string/jumbo v1, "key"

    const/4 v4, 0x1

    const-string/jumbo v1, "key"

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->e(Ljava/lang/String;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "sssBt"

    const-string v1, "Bssit"

    const/4 v4, 0x1

    const-string/jumbo v1, "sBomt"

    const-string/jumbo v1, "isBot"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->b(Z)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v1, "mmasotpiIot"

    const-string/jumbo v1, "rsamoIpittm"

    const/4 v4, 0x7

    const-string/jumbo v1, "rottibsnamI"

    const-string/jumbo v1, "isImportant"

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Landroidx/core/app/f4$c;->d(Z)Landroidx/core/app/f4$c;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object p0
.end method

.method public static c(Landroid/os/PersistableBundle;)Landroidx/core/app/f4;
    .locals 2
    .param p0    # Landroid/os/PersistableBundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x16
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-static {p0}, Landroidx/core/app/f4$a;->a(Landroid/os/PersistableBundle;)Landroidx/core/app/f4;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public d()Landroidx/core/graphics/drawable/IconCompat;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/f4;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/f4;->d:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public f()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/f4;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public h()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    iget-boolean v0, p0, Landroidx/core/app/f4;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public i()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/core/app/f4;->f:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public j()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/f4;->c:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "nuaem"

    const-string/jumbo v1, "name:"

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0
.end method

.method public k()Landroid/app/Person;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1c
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-static {p0}, Landroidx/core/app/f4$b;->b(Landroidx/core/app/f4;)Landroid/app/Person;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public l()Landroidx/core/app/f4$c;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Landroidx/core/app/f4$c;

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-direct {v0, p0}, Landroidx/core/app/f4$c;-><init>(Landroidx/core/app/f4;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public m()Landroid/os/Bundle;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "eanm"

    const-string/jumbo v1, "nmea"

    const/4 v4, 0x7

    const-string v1, "eman"

    const-string/jumbo v1, "name"

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Landroidx/core/app/f4;->b:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroidx/core/graphics/drawable/IconCompat;->a()Landroid/os/Bundle;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v2, "iocn"

    const-string/jumbo v2, "icno"

    const/4 v4, 0x5

    const-string/jumbo v2, "icon"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "riu"

    const/4 v4, 0x2

    const-string/jumbo v1, "uri"

    const-string/jumbo v1, "uri"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Landroidx/core/app/f4;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const-string/jumbo v1, "kye"

    const-string v1, "eky"

    const/4 v4, 0x7

    const-string/jumbo v1, "kye"

    const-string/jumbo v1, "key"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, p0, Landroidx/core/app/f4;->d:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v1, "itpBo"

    const-string/jumbo v1, "itBoo"

    const/4 v4, 0x5

    const-string v1, "Bioqs"

    const-string/jumbo v1, "isBot"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-boolean v2, p0, Landroidx/core/app/f4;->e:Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "tasnribosIt"

    const-string/jumbo v1, "tioatbrmnsI"

    const/4 v4, 0x2

    const-string v1, "ainmIostpmr"

    const-string/jumbo v1, "isImportant"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-boolean v2, p0, Landroidx/core/app/f4;->f:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0
.end method

.method public n()Landroid/os/PersistableBundle;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x16
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p0}, Landroidx/core/app/f4$a;->b(Landroidx/core/app/f4;)Landroid/os/PersistableBundle;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method
