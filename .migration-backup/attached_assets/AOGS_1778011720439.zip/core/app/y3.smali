.class public final synthetic Landroidx/core/app/y3;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationManager;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s @~u~~~- @@~@~c  4@ybmK~~ @o~@@ v~ l@ @   o~ S ~.bo @i doba ~ t@o@i@r1i~/~no@/~f~M~f~@l~s~@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/app/NotificationManager;->areNotificationsEnabled()Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method
