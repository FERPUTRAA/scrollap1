.class abstract Landroidx/core/app/JobIntentService$h;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/JobIntentService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "h"
.end annotation


# instance fields
.field final a:Landroid/content/ComponentName;

.field b:Z

.field c:I


# direct methods
.method constructor <init>(Landroid/content/ComponentName;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/JobIntentService$h;->a:Landroid/content/ComponentName;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method abstract a(Landroid/content/Intent;)V
.end method

.method b(I)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@s~~oo~@ m~@c.~@~ @ o~  t it@K@~@S~dno~  rf~bf~-i@vb~ @y~ @ @@~ o/sl ~M  @ob4~l/@~@~u~@ @~~1i@ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-boolean v0, p0, Landroidx/core/app/JobIntentService$h;->b:Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x7

    iput-boolean v0, p0, Landroidx/core/app/JobIntentService$h;->b:Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput p1, p0, Landroidx/core/app/JobIntentService$h;->c:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, p0, Landroidx/core/app/JobIntentService$h;->c:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-ne v0, p1, :cond_1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, " DemvobGs n I"

    const-string/jumbo v2, "vGs n  bIeDio"

    const/4 v4, 0x3

    const-string v2, "Given job ID "

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string p1, "enfeoth   dsrfeasriiu nvopmt"

    const-string p1, " vpmhnfstf r i diesuta oneer"

    const/4 v4, 0x0

    const-string/jumbo p1, "osnedbt e ifrse ih tn pfiauv"

    const-string p1, " is different than previous "

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget p1, p0, Landroidx/core/app/JobIntentService$h;->c:I

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    throw v0
.end method

.method public c()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public d()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public e()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
