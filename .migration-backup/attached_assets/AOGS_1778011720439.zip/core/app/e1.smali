.class public final synthetic Landroidx/core/app/e1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Landroid/app/NotificationChannel;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s~i/@@bf l ~ o~~-~~  i/t@o4~ f~ l@S@~ b@@@@ dy@@@@s@1@@. @~ ~~otM~o~~@~nv~i ~@ uo~~K@ao rb c~m"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    check-cast p0, Landroid/app/NotificationChannel;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method
