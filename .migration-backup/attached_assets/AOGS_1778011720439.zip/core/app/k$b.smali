.class Landroidx/core/app/k$b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "BanUncheckedReflection"
    }
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "BundleCompatBaseImpl"

.field private static b:Ljava/lang/reflect/Method;

.field private static c:Z

.field private static d:Ljava/lang/reflect/Method;

.field private static e:Z


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method

.method public static a(Landroid/os/Bundle;Ljava/lang/String;)Landroid/os/IBinder;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "ous~  ~oob@~K~ @~~o /oS~ 4@@@n~l i~ @/  o1@@av~M@~ f @~yf@ b~it@.l~~@~m~@~@~~ ~ sb ~@ @ i@cdrt@-"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    sget-boolean v0, Landroidx/core/app/k$b;->c:Z

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v2, "deemosaBumCanIBlstmp"

    const-string v2, "emsIapBaCnBmtolupsed"

    const/4 v8, 0x2

    const-string/jumbo v2, "pmosopBulnaBCaetldem"

    const-string v2, "BundleCompatBaseImpl"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v3, 0x1

    or-int/2addr v8, v3

    const/4 v7, 0x5

    move v8, v7

    if-nez v0, :cond_0

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-class v0, Landroid/os/Bundle;

    const-class v0, Landroid/os/Bundle;

    const/4 v8, 0x3

    const-class v0, Landroid/os/Bundle;

    const-class v0, Landroid/os/Bundle;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v4, "itemgbedrn"

    const-string v4, "dntmegreiI"

    const/4 v8, 0x2

    const-string/jumbo v4, "redBntuIgi"

    const-string v4, "getIBinder"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-array v5, v3, [Ljava/lang/Class;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    const/4 v8, 0x6

    const-class v6, Ljava/lang/String;

    const-class v6, Ljava/lang/String;

    aput-object v6, v5, v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, v4, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    sput-object v0, Landroidx/core/app/k$b;->b:Ljava/lang/reflect/Method;

    const/4 v8, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v4, "Feedtaipe IeBilnvgeeoot emdodrhr i t"

    const-string/jumbo v4, "mFahotr t iBrgediniteeeeIl ord edeov"

    const/4 v8, 0x4

    const-string v4, "htnvmd  qegord eB eetlFtitedeoraeirI"

    const-string v4, "Failed to retrieve getIBinder method"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v2, v4, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    sput-boolean v3, Landroidx/core/app/k$b;->c:Z

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    sget-object v0, Landroidx/core/app/k$b;->b:Ljava/lang/reflect/Method;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v7, 0x4

    move v8, v7

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    aput-object p1, v3, v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0, p0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    check-cast p0, Landroid/os/IBinder;
    :try_end_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    return-object p0

    :catch_1
    move-exception p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    goto :goto_1

    :catch_2
    move-exception p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_1

    :catch_3
    move-exception p0

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo p1, "l seieidbrogoe tni nke feFlvIodt iecvBinaa"

    const-string p1, " ar vbkd giieneorlveiefcnotaton eBiliIF de"

    const/4 v8, 0x1

    const-string/jumbo p1, "iaemeBe ikeee rov iIglrdtvcdinif olno natt"

    const-string p1, "Failed to invoke getIBinder via reflection"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v2, p1, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    sput-object v4, Landroidx/core/app/k$b;->b:Ljava/lang/reflect/Method;

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-object v4
.end method

.method public static b(Landroid/os/Bundle;Ljava/lang/String;Landroid/os/IBinder;)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    sget-boolean v0, Landroidx/core/app/k$b;->e:Z

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    const/4 v1, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string v2, "depIolmomaBspaBluCut"

    const-string v2, "allBmputsueCaeoBIdmp"

    const/4 v9, 0x5

    const-string v2, "BllnebamBatoIsudmppC"

    const-string v2, "BundleCompatBaseImpl"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v3, 0x2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v4, 0x1

    move v9, v4

    const/4 v8, 0x0

    move v9, v8

    if-nez v0, :cond_0

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-class v0, Landroid/os/Bundle;

    const-class v0, Landroid/os/Bundle;

    const/4 v9, 0x5

    const-class v0, Landroid/os/Bundle;

    const-class v0, Landroid/os/Bundle;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo v5, "upedIrupnB"

    const-string v5, "denBtIppru"

    const/4 v9, 0x1

    const-string/jumbo v5, "iIpurtnpde"

    const-string/jumbo v5, "putIBinder"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-array v6, v3, [Ljava/lang/Class;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const/4 v9, 0x7

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const/4 v9, 0x4

    aput-object v7, v6, v1

    const/4 v9, 0x5

    const-class v7, Landroid/os/IBinder;

    const-class v7, Landroid/os/IBinder;

    const/4 v9, 0x1

    aput-object v7, v6, v4

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v0, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    sput-object v0, Landroidx/core/app/k$b;->d:Ljava/lang/reflect/Method;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v5, "  tiart qenedIoBeteprdFeoeihrtul dvi"

    const/4 v9, 0x1

    const-string v5, "e p ie eqrrioveiaroulmdddeBettnhtI t"

    const-string v5, "Failed to retrieve putIBinder method"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static {v2, v5, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    sput-boolean v4, Landroidx/core/app/k$b;->e:Z

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    sget-object v0, Landroidx/core/app/k$b;->d:Ljava/lang/reflect/Method;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    aput-object p1, v3, v1

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    aput-object p2, v3, v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v0, p0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_2

    :catch_1
    move-exception p0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :catch_2
    move-exception p0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    goto :goto_1

    :catch_3
    move-exception p0

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string p1, "eIspaaeoe   rietcvvoFlknisdtnutinBio file "

    const-string/jumbo p1, "orseiIan u ratvlkBe ltdfo o tFnpineeeiivci"

    const/4 v9, 0x4

    const-string/jumbo p1, "kBemoie nltardtie f taveFnvin ordcilpo uIe"

    const-string p1, "Failed to invoke putIBinder via reflection"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v2, p1, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 p0, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    sput-object p0, Landroidx/core/app/k$b;->d:Ljava/lang/reflect/Method;

    :cond_1
    :goto_2
    const/4 v9, 0x4

    return-void
.end method
