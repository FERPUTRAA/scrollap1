.class public final Landroidx/core/app/j4;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/j4$a;,
        Landroidx/core/app/j4$c;,
        Landroidx/core/app/j4$b;
    }
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "androidx.core.app.EXTRA_CALLING_PACKAGE"

.field public static final b:Ljava/lang/String; = "android.support.v4.app.EXTRA_CALLING_PACKAGE"

.field public static final c:Ljava/lang/String; = "androidx.core.app.EXTRA_CALLING_ACTIVITY"

.field public static final d:Ljava/lang/String; = "android.support.v4.app.EXTRA_CALLING_ACTIVITY"

.field private static final e:Ljava/lang/String; = ".sharecompat_"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/view/Menu;ILandroidx/core/app/j4$b;)V
    .locals 3
    .param p0    # Landroid/view/Menu;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/d0;
        .end annotation
    .end param
    .param p2    # Landroidx/core/app/j4$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4 s~@-a t ~ t~i@~io@ ~o@ld b~vu @ b~/ @~@ r@ffoM  @  @@@@~@ybK ~~@mc~~o  ~@S1@~~/~l.~~i~@@~n@~os"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-interface {p0, p1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, p2}, Landroidx/core/app/j4;->b(Landroid/view/MenuItem;Landroidx/core/app/j4$b;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    const-string/jumbo v0, "tC mdsim dieinedt  n itmlh nof wu"

    const-string v0, "desttdtln o  i mwifunimC iu d ehn"

    const/4 v2, 0x1

    const-string v0, "hi doudnt   ete mwolidionu mntiCf"

    const-string v0, "Could not find menu item with id "

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const-string p1, " pndlbueshinep i  met"

    const-string/jumbo p1, "pmlme u senh pi dniet"

    const/4 v2, 0x5

    const-string/jumbo p1, "nppdl u ust euiehinm "

    const-string p1, " in the supplied menu"

    const/4 v2, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    throw p0
.end method

.method public static b(Landroid/view/MenuItem;Landroidx/core/app/j4$b;)V
    .locals 5
    .param p0    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroidx/core/app/j4$b;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {p0}, Landroid/view/MenuItem;->getActionProvider()Landroid/view/ActionProvider;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    instance-of v1, v0, Landroid/widget/ShareActionProvider;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-nez v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v0, Landroid/widget/ShareActionProvider;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroidx/core/app/j4$b;->l()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Landroid/widget/ShareActionProvider;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v0, Landroid/widget/ShareActionProvider;

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v2, "porahoepamt._"

    const-string/jumbo v2, "rp.ooceth_maa"

    const/4 v4, 0x2

    const-string v2, ".ethrsamqopac"

    const-string v2, ".sharecompat_"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroidx/core/app/j4$b;->l()Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/widget/ShareActionProvider;->setShareHistoryFileName(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroidx/core/app/j4$b;->m()Landroid/content/Intent;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/ShareActionProvider;->setShareIntent(Landroid/content/Intent;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {p0, v0}, Landroid/view/MenuItem;->setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method public static c(Landroid/app/Activity;)Landroid/content/ComponentName;
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getCallingActivity()Landroid/content/ComponentName;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/app/j4;->d(Landroid/content/Intent;)Landroid/content/ComponentName;

    move-result-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0
.end method

.method static d(Landroid/content/Intent;)Landroid/content/ComponentName;
    .locals 3
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const-string v0, "TrsI.aoG_eTRAVidcITA_INXrpdopA.YCnC.LbLa"

    const-string v0, "NIRIibrA.A_dCxaoCTadcVpIATXpo..L_GeLnTrY"

    const/4 v2, 0x5

    const-string v0, "e.LmGNaAdRxTrIc_iooaT.IEL.Vp_XrdAnIpTCAC"

    const-string v0, "androidx.core.app.EXTRA_CALLING_ACTIVITY"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, Landroid/content/ComponentName;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, "YdAposXtpIunTCI_TGNra4oopdAILV.Lipr.T.aA.RuEv"

    const-string v0, "a.CILpuuCvNTAE_GnXspoLoTYdrprAVRd..4AtIpia.IT"

    const/4 v2, 0x4

    const-string v0, "_pVYab.rLTnAoTdI.aosNiGdvpuTrCRA4CEAI_XpLtp.I"

    const-string v0, "android.support.v4.app.EXTRA_CALLING_ACTIVITY"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, Landroid/content/ComponentName;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public static e(Landroid/app/Activity;)Ljava/lang/String;
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v1, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getCallingPackage()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/app/j4;->f(Landroid/content/Intent;)Ljava/lang/String;

    move-result-object p0

    :cond_0
    const/4 v2, 0x5

    return-object p0
.end method

.method static f(Landroid/content/Intent;)Ljava/lang/String;
    .locals 3
    .param p0    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const-string v0, ".PERnIup_ALr_r.ALp.dCdoicGAxCTGXEANeKap"

    const-string v0, ".A.ACTNpE_AxaCLGeic.AadERXrGI_pPopndrLK"

    const/4 v2, 0x1

    const-string/jumbo v0, "xioRNdLppCaEA.AnrrcXPeE.T.aKLoIpCdA_GAG"

    const-string v0, "androidx.core.app.EXTRA_CALLING_PACKAGE"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "dR.XaKICqGvnAuEANpa.q_dTripP4AAp._LEtosG.orp"

    const-string v0, "avAGpTIiqC_GoEtPoAXrsrApA.aEd_..nuCN4KppL.Rd"

    const/4 v2, 0x4

    const-string v0, "ATs_CorP.drvENip.IAotK_C4E..RGLXaunApapdpLsA"

    const-string v0, "android.support.v4.app.EXTRA_CALLING_PACKAGE"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method
