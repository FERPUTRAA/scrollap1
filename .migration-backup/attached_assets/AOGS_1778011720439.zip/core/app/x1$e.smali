.class public Landroidx/core/app/x1$e;
.super Landroidx/core/app/x1$q;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# static fields
.field private static final f:Ljava/lang/String; = "androidx.core.app.NotificationCompat$BigTextStyle"


# instance fields
.field private e:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroidx/core/app/x1$g;)V
    .locals 2
    .param p1    # Landroidx/core/app/x1$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Landroidx/core/app/x1$q;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroidx/core/app/x1$q;->z(Landroidx/core/app/x1$g;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public A(Ljava/lang/CharSequence;)Landroidx/core/app/x1$e;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ".as@~if~~l@ ~@~/~dt ~u~ m@@@~~@l~tbno ~oi1b@s   v~bM~ @@~~~ ~@f@@oo~ r   @~~oio @yS  @~ @c4-K@@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$e;->e:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    return-object p0
.end method

.method public B(Ljava/lang/CharSequence;)Landroidx/core/app/x1$e;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public C(Ljava/lang/CharSequence;)Landroidx/core/app/x1$e;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-static {p1}, Landroidx/core/app/x1$g;->A(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    const/4 p1, 0x2

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public a(Landroid/os/Bundle;)V
    .locals 2
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->a(Landroid/os/Bundle;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public b(Landroidx/core/app/v;)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance v0, Landroid/app/Notification$BigTextStyle;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {p1}, Landroidx/core/app/v;->a()Landroid/app/Notification$Builder;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Landroid/app/Notification$BigTextStyle;-><init>(Landroid/app/Notification$Builder;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/app/Notification$BigTextStyle;->setBigContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$e;->e:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/app/Notification$BigTextStyle;->setSummaryText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method protected g(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->g(Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string v0, "dTnmbas.toridxi"

    const-string v0, "Txsnidrdei.abto"

    const/4 v2, 0x0

    const-string/jumbo v0, "rdi.oexoatngTid"

    const-string v0, "android.bigText"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method protected t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "pCdonbiptpmiaetex.glimdBocrctar.eix$oStyNoio.anft"

    const-string v0, "en$m.typctidoxNidorclgf.a.iStieBpaxrmtpiootneoCaa"

    const/4 v2, 0x5

    const-string v0, "$oxNnfumri.etBTtparc.noo.oextpdtiSgaaiCiotayeicdl"

    const-string v0, "androidx.core.app.NotificationCompat$BigTextStyle"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method protected y(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroidx/core/app/x1$q;->y(Landroid/os/Bundle;)V

    const/4 v2, 0x4

    const-string/jumbo v0, "o.edTgaptibrdox"

    const-string v0, "Tgxrodii.ebdaot"

    const/4 v2, 0x1

    const-string/jumbo v0, "r.degTbiqxtdaon"

    const-string v0, "android.bigText"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/core/app/x1$e;->e:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method
