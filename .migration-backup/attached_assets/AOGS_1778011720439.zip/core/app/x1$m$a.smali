.class public final Landroidx/core/app/x1$m$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1$m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field static final g:Ljava/lang/String; = "text"

.field static final h:Ljava/lang/String; = "time"

.field static final i:Ljava/lang/String; = "sender"

.field static final j:Ljava/lang/String; = "type"

.field static final k:Ljava/lang/String; = "uri"

.field static final l:Ljava/lang/String; = "extras"

.field static final m:Ljava/lang/String; = "person"

.field static final n:Ljava/lang/String; = "sender_person"


# instance fields
.field private final a:Ljava/lang/CharSequence;

.field private final b:J

.field private final c:Landroidx/core/app/f4;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Landroid/os/Bundle;

.field private e:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private f:Landroid/net/Uri;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;JLandroidx/core/app/f4;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Landroidx/core/app/f4;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/core/app/x1$m$a;->d:Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/core/app/x1$m$a;->a:Ljava/lang/CharSequence;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-wide p2, p0, Landroidx/core/app/x1$m$a;->b:J

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p4, p0, Landroidx/core/app/x1$m$a;->c:Landroidx/core/app/f4;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/CharSequence;JLjava/lang/CharSequence;)V
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Landroidx/core/app/f4$c;

    const/4 v2, 0x6

    invoke-direct {v0}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v2, 0x7

    invoke-virtual {v0, p4}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object p4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p4}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object p4

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Landroidx/core/app/x1$m$a;-><init>(Ljava/lang/CharSequence;JLandroidx/core/app/f4;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method static a(Ljava/util/List;)[Landroid/os/Bundle;
    .locals 6
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$m$a;",
            ">;)[",
            "Landroid/os/Bundle;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-array v0, v0, [Landroid/os/Bundle;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-ge v2, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    check-cast v3, Landroidx/core/app/x1$m$a;

    const/4 v5, 0x3

    invoke-direct {v3}, Landroidx/core/app/x1$m$a;->m()Landroid/os/Bundle;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    aput-object v3, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object v0
.end method

.method static e(Landroid/os/Bundle;)Landroidx/core/app/x1$m$a;
    .locals 12
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v0, "uir"

    const-string/jumbo v0, "iur"

    const/4 v11, 0x6

    const-string/jumbo v0, "iru"

    const-string/jumbo v0, "uri"

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string v1, "arssse"

    const-string/jumbo v1, "rasxse"

    const/4 v11, 0x2

    const-string v1, "earmsx"

    const-string v1, "extras"

    const/4 v10, 0x5

    move v11, v10

    const-string v2, "epty"

    const-string/jumbo v2, "tpey"

    const/4 v11, 0x2

    const-string/jumbo v2, "yetp"

    const-string/jumbo v2, "type"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v3, "desmnr"

    const/4 v11, 0x2

    const-string/jumbo v3, "rensod"

    const-string/jumbo v3, "sender"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string/jumbo v4, "soeeorsedn_rn"

    const/4 v11, 0x3

    const-string/jumbo v4, "per_dbonsesrn"

    const-string/jumbo v4, "sender_person"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string/jumbo v5, "urpeso"

    const-string/jumbo v5, "seropb"

    const/4 v11, 0x0

    const-string/jumbo v5, "rponps"

    const-string/jumbo v5, "person"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string/jumbo v6, "meti"

    const/4 v11, 0x6

    const-string/jumbo v6, "time"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v7, "extt"

    const-string v7, "etxt"

    const/4 v11, 0x6

    const-string/jumbo v7, "text"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    const/4 v8, 0x0

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {p0, v7}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v9

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eqz v9, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p0, v6}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v9

    const/4 v11, 0x4

    const/4 v10, 0x7

    if-nez v9, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p0, v5}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v9

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-eqz v9, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p0, v5}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {v3}, Landroidx/core/app/f4;->b(Landroid/os/Bundle;)Landroidx/core/app/f4;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    goto :goto_0

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {p0, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v5

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-eqz v5, :cond_2

    const/4 v11, 0x1

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v11, 0x3

    const/16 v9, 0x1c

    const/4 v11, 0x0

    const/4 v10, 0x4

    if-lt v5, v9, :cond_2

    const/4 v11, 0x1

    const/4 v10, 0x6

    invoke-virtual {p0, v4}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v3

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {v3}, Landroidx/core/app/m1;->a(Ljava/lang/Object;)Landroid/app/Person;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v3}, Landroidx/core/app/f4;->a(Landroid/app/Person;)Landroidx/core/app/f4;

    move-result-object v3

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto :goto_0

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p0, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-eqz v4, :cond_3

    const/4 v10, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    new-instance v4, Landroidx/core/app/f4$c;

    const/4 v10, 0x2

    move v11, v10

    invoke-direct {v4}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v11, 0x6

    invoke-virtual {p0, v3}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v4, v3}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v3}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto :goto_0

    :cond_3
    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    new-instance v4, Landroidx/core/app/x1$m$a;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p0, v7}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v5

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p0, v6}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v6

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-direct {v4, v5, v6, v7, v3}, Landroidx/core/app/x1$m$a;-><init>(Ljava/lang/CharSequence;JLandroidx/core/app/f4;)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-eqz v3, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const/4 v11, 0x3

    const/4 v10, 0x3

    if-eqz v3, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    check-cast v0, Landroid/net/Uri;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v4, v2, v0}, Landroidx/core/app/x1$m$a;->k(Ljava/lang/String;Landroid/net/Uri;)Landroidx/core/app/x1$m$a;

    :cond_4
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-eqz v0, :cond_5

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v4}, Landroidx/core/app/x1$m$a;->d()Landroid/os/Bundle;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v0, p0}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_5
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    return-object v4

    :catch_0
    :cond_6
    :goto_1
    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    return-object v8
.end method

.method static f([Landroid/os/Parcelable;)Ljava/util/List;
    .locals 6
    .param p0    # [Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Landroid/os/Parcelable;",
            ")",
            "Ljava/util/List<",
            "Landroidx/core/app/x1$m$a;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x0

    array-length v1, p0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v5, 0x7

    const/4 v1, 0x6

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    array-length v2, p0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ge v1, v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    aget-object v2, p0, v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    instance-of v3, v2, Landroid/os/Bundle;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v2, Landroid/os/Bundle;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v2}, Landroidx/core/app/x1$m$a;->e(Landroid/os/Bundle;)Landroidx/core/app/x1$m$a;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-object v0
.end method

.method private m()Landroid/os/Bundle;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->a:Ljava/lang/CharSequence;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v2, "etxt"

    const-string/jumbo v2, "text"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v1, "tmie"

    const-string/jumbo v1, "temi"

    const/4 v5, 0x1

    const-string/jumbo v1, "tiem"

    const-string/jumbo v1, "time"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-wide v2, p0, Landroidx/core/app/x1$m$a;->b:J

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->c:Landroidx/core/app/f4;

    const/4 v5, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v2, "ndqrue"

    const-string/jumbo v2, "udrnee"

    const/4 v5, 0x7

    const-string/jumbo v2, "neseds"

    const-string/jumbo v2, "sender"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/16 v2, 0x1c

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-lt v1, v2, :cond_1

    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->c:Landroidx/core/app/f4;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroidx/core/app/f4;->k()Landroid/app/Person;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "snpme_opseenr"

    const-string/jumbo v2, "ndes_esppnroe"

    const/4 v5, 0x3

    const-string v2, "enneos_pdoers"

    const-string/jumbo v2, "sender_person"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->c:Landroidx/core/app/f4;

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1}, Landroidx/core/app/f4;->m()Landroid/os/Bundle;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v2, "opqser"

    const/4 v5, 0x7

    const-string/jumbo v2, "psneob"

    const-string/jumbo v2, "person"

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->e:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v2, "ypet"

    const-string v2, "eypt"

    const/4 v5, 0x3

    const-string v2, "etyp"

    const-string/jumbo v2, "type"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->f:Landroid/net/Uri;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v2, "uir"

    const-string/jumbo v2, "iru"

    const-string/jumbo v2, "uir"

    const-string/jumbo v2, "uri"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_4
    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/core/app/x1$m$a;->d:Landroid/os/Bundle;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v2, "xrseat"

    const/4 v5, 0x2

    const-string/jumbo v2, "ursxat"

    const-string v2, "extras"

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object v0
.end method


# virtual methods
.method public b()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$m$a;->e:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public c()Landroid/net/Uri;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/x1$m$a;->f:Landroid/net/Uri;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public d()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$m$a;->d:Landroid/os/Bundle;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public g()Landroidx/core/app/f4;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$m$a;->c:Landroidx/core/app/f4;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method public h()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$m$a;->c:Landroidx/core/app/f4;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public i()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/x1$m$a;->a:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public j()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-wide v0, p0, Landroidx/core/app/x1$m$a;->b:J

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-wide v0
.end method

.method public k(Ljava/lang/String;Landroid/net/Uri;)Landroidx/core/app/x1$m$a;
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/core/app/x1$m$a;->e:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p2, p0, Landroidx/core/app/x1$m$a;->f:Landroid/net/Uri;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method l()Landroid/app/Notification$MessagingStyle$Message;
    .locals 8
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x18
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->g()Landroidx/core/app/f4;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/16 v2, 0x1c

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-lt v1, v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-static {}, Landroidx/core/app/n2;->a()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->i()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->j()J

    move-result-wide v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x6

    or-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroidx/core/app/f4;->k()Landroid/app/Person;

    move-result-object v3

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v1, v4, v5, v3}, Landroidx/core/app/m2;->a(Ljava/lang/CharSequence;JLandroid/app/Person;)Landroid/app/Notification$MessagingStyle$Message;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_2

    :cond_1
    const/4 v7, 0x1

    invoke-static {}, Landroidx/core/app/n2;->a()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->i()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->j()J

    move-result-wide v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez v0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroidx/core/app/f4;->f()Ljava/lang/CharSequence;

    move-result-object v3

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v1, v4, v5, v3}, Landroidx/core/app/l2;->a(Ljava/lang/CharSequence;JLjava/lang/CharSequence;)Landroid/app/Notification$MessagingStyle$Message;

    move-result-object v0

    :goto_2
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroidx/core/app/x1$m$a;->c()Landroid/net/Uri;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0, v1, v2}, Landroidx/core/app/k2;->a(Landroid/app/Notification$MessagingStyle$Message;Ljava/lang/String;Landroid/net/Uri;)Landroid/app/Notification$MessagingStyle$Message;

    :cond_3
    const/4 v6, 0x2

    move v7, v6

    return-object v0
.end method
