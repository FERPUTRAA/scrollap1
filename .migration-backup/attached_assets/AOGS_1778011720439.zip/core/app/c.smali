.class public final synthetic Landroidx/core/app/c;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/app/k4$a;


# instance fields
.field public final synthetic a:Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;


# direct methods
.method public synthetic constructor <init>(Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;)V
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/app/c;->a:Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@sr b@  i~o~d@~@~~o~ 4mt~o@bS ~~@~o. a~ v~~s @t~iy ~@@ -~ l~@@l ib/c/@~ @u1~@Kof@ @ @f~M@o ~n@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/c;->a:Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {v0}, Landroidx/core/app/b$l;->a(Landroid/app/SharedElementCallback$OnSharedElementsReadyListener;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method
