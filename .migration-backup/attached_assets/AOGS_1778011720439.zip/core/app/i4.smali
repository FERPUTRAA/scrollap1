.class public final Landroidx/core/app/i4;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/app/i4$a;,
        Landroidx/core/app/i4$b;
    }
.end annotation


# static fields
.field public static final a:I = 0x1

.field public static final b:I = 0x1

.field public static final c:I = 0x2


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/app/Service;I)V
    .locals 4
    .param p0    # Landroid/app/Service;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~so@b~~- oc~~o i~t ~   @~~@~@/@M~~Sid~r .~o fm~ t 1i b~~@@ a y @bKnu@@s~@~fl@~~4@@ @v/o@ @@@o~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x2

    move v3, v2

    const/16 v1, 0x18

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0, p1}, Landroidx/core/app/i4$a;->a(Landroid/app/Service;I)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    and-int/2addr p1, v0

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/app/Service;->stopForeground(Z)V

    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method
