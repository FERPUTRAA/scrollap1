.class public final synthetic Landroidx/core/app/b3;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$Builder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s~@~@s lbt4 -~bf c~@@~@~uv~@bo~@i@l@@Sy@ @d/K@f@ ~@~ ~o~i1@  ~noo@@t / ~~~ @a  .r o ~o~~@~iMm~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Landroid/app/Notification$Builder;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method
