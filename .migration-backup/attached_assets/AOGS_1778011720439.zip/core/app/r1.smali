.class public final synthetic Landroidx/core/app/r1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s/c@~~ ~r  @ -~f i ~1 o~4~@v@@@~M@~@.~@@~@@@l@~/ f uo~iK@i@d~ o a @@~m notSlo@ sb~@oybt~ ~~ ~b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/app/Notification;->getGroupAlertBehavior()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p0
.end method
