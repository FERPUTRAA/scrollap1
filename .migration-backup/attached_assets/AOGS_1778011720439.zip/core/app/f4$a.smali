.class Landroidx/core/app/f4$a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x16
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/f4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method static a(Landroid/os/PersistableBundle;)Landroidx/core/app/f4;
    .locals 4
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~~~@~u sM@@b~ t ~ ~ n@bifS~.m  @io @@ ~ cK ~o~@@~ i1@o~~@/@@o@~yv ~r ~@/o-4ftl@~@ ~ab~do@@~@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    new-instance v0, Landroidx/core/app/f4$c;

    const/4 v2, 0x1

    move v3, v2

    invoke-direct {v0}, Landroidx/core/app/f4$c;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "emna"

    const-string v1, "eanm"

    const/4 v3, 0x1

    const-string/jumbo v1, "mnea"

    const-string/jumbo v1, "name"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->f(Ljava/lang/CharSequence;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v1, "iur"

    const-string/jumbo v1, "rui"

    const/4 v3, 0x5

    const-string/jumbo v1, "iur"

    const-string/jumbo v1, "uri"

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->g(Ljava/lang/String;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v1, "key"

    const-string/jumbo v1, "key"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->e(Ljava/lang/String;)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const-string v1, "Bstmi"

    const-string/jumbo v1, "sistB"

    const/4 v3, 0x1

    const-string v1, "Boito"

    const-string/jumbo v1, "isBot"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroidx/core/app/f4$c;->b(Z)Landroidx/core/app/f4$c;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v1, "ntmaobstIir"

    const-string/jumbo v1, "soImtitramn"

    const/4 v3, 0x6

    const-string/jumbo v1, "nmtIosuaitr"

    const-string/jumbo v1, "isImportant"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Landroidx/core/app/f4$c;->d(Z)Landroidx/core/app/f4$c;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/core/app/f4$c;->a()Landroidx/core/app/f4;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0
.end method

.method static b(Landroidx/core/app/f4;)Landroid/os/PersistableBundle;
    .locals 5
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    new-instance v0, Landroid/os/PersistableBundle;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-direct {v0}, Landroid/os/PersistableBundle;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Landroidx/core/app/f4;->a:Ljava/lang/CharSequence;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "mnae"

    const-string/jumbo v2, "mane"

    const/4 v4, 0x3

    const-string/jumbo v2, "neam"

    const-string/jumbo v2, "name"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "riu"

    const-string/jumbo v1, "iur"

    const/4 v4, 0x7

    const-string/jumbo v1, "iur"

    const-string/jumbo v1, "uri"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Landroidx/core/app/f4;->c:Ljava/lang/String;

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    const-string/jumbo v1, "key"

    const-string/jumbo v1, "yek"

    const/4 v4, 0x7

    const-string v1, "eyk"

    const-string/jumbo v1, "key"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v2, p0, Landroidx/core/app/f4;->d:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "itBoo"

    const/4 v4, 0x1

    const-string/jumbo v1, "tipsB"

    const-string/jumbo v1, "isBot"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-boolean v2, p0, Landroidx/core/app/f4;->e:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v1, "ttIoabminsp"

    const/4 v4, 0x7

    const-string/jumbo v1, "tsartpioqmn"

    const-string/jumbo v1, "isImportant"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-boolean p0, p0, Landroidx/core/app/f4;->f:Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0
.end method
