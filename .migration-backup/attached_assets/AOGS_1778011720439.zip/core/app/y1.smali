.class public final synthetic Landroidx/core/app/y1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;)Landroid/widget/RemoteViews;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s @  ci@~b@~l~~K @~~t  db~1/@~~@ySn~~oo b @l~ @@~-@~oi @@~oMo@@~mra~t ~@fsf~~@/o4 ~@  u@. @ i@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/app/Notification$Builder;->createBigContentView()Landroid/widget/RemoteViews;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-object p0
.end method
