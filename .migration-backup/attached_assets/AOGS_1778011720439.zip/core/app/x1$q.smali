.class public abstract Landroidx/core/app/x1$q;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/x1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "q"
.end annotation


# instance fields
.field protected a:Landroidx/core/app/x1$g;
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation
.end field

.field b:Ljava/lang/CharSequence;

.field c:Ljava/lang/CharSequence;

.field d:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    move v2, v1

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean v0, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method private f()I
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~Ss @@diiu  c~to~@@~@~  v~rf @at ~ @@~~b4 1 ~~@o@@~~@.n@ ~ob~@si/~@@-~ ~of M@ K~my ~/~l@o@ olb@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v0, v0, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget v1, Landroidx/core/R$dimen;->notification_top_pad:I

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget v2, Landroidx/core/R$dimen;->notification_top_pad_large_text:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v0, v0, Landroid/content/res/Configuration;->fontScale:F

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    const v3, 0x3fa66666    # 1.3f

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v4, v3}, Landroidx/core/app/x1$q;->h(FFF)F

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    sub-float/2addr v0, v4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    const v3, 0x3e999998    # 0.29999995f

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    div-float/2addr v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    sub-float/2addr v4, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    int-to-float v1, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    mul-float/2addr v4, v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    int-to-float v1, v2

    mul-float/2addr v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    add-float/2addr v4, v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    return v0
.end method

.method private static h(FFF)F
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    cmpg-float v0, p0, p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-gez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    move p0, p1

    const/4 v2, 0x0

    move p0, p1

    move p0, p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    cmpl-float p1, p0, p2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-lez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    move p0, p2

    move p0, p2

    const/4 v2, 0x4

    move p0, p2

    move p0, p2

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return p0
.end method

.method static i(Ljava/lang/String;)Landroidx/core/app/x1$q;
    .locals 4
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    sparse-switch v0, :sswitch_data_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto/16 :goto_0

    :sswitch_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v0, "rgMmsnait.osocpflxmeadid$CyenSiprtoeioNasiont.tcpa."

    const-string v0, "gostmcsrneiaonoiixNc.a$CS.pttrpiltfaMopyde.danoeias"

    const/4 v3, 0x5

    const-string/jumbo v0, "ipsaorgtiepiiCtddestaxgotnai$of.aeonaopcmSNync..lMr"

    const-string v0, "androidx.core.app.NotificationCompat$MessagingStyle"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v1, 0x4

    move v3, v1

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto/16 :goto_0

    :sswitch_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "i.ytnbeipt.ooaeSToBpmrnxoaacigf.tidl$aotmcpxdtNCr"

    const-string v0, "NfomaCto.eptiidoByctoecxpoarmlSgt.e$tdaTnnpr.ixia"

    const/4 v3, 0x5

    const-string/jumbo v0, "lryCo.u$ttpNoTetodontdBaeamigniirtfxaaxpiopcei..c"

    const-string v0, "androidx.core.app.NotificationCompat$BigTextStyle"

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :sswitch_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v0, "dripnytpcfoSpIitdoaiexta.aCioo.otNrlocmeaopxbn$"

    const-string/jumbo v0, "pleaoiieoipana$.mItaoSttodxfo.NocnnctdiCyrrxobp"

    const/4 v3, 0x7

    const-string/jumbo v0, "xmaooponqldtaonntxt.eopyrCofc.eiaI.t$iicabSNrip"

    const-string v0, "androidx.core.app.NotificationCompat$InboxStyle"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :sswitch_3
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "posaiNt$moBapynpietPdalxo.iieCcu.fSooinirbc.aterdttg"

    const-string/jumbo v0, "inpfPbtntBNotocyeCuiotepcaiiio.eS.$amrolcid.arpxagtd"

    const/4 v3, 0x7

    const-string/jumbo v0, "yBamocPaipadrxiuCeripf.ipaooitttNoin.e$ccS.tntodlmre"

    const-string v0, "androidx.core.app.NotificationCompat$BigPictureStyle"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    if-nez p0, :cond_3

    const/4 v2, 0x0

    and-int/2addr v3, v2

    goto :goto_0

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :sswitch_4
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "ero.ondcouoaDmeCtSuedi.fotpl$rmoVaicCseda.cnNietitytpatoxpiwo"

    const-string/jumbo v0, "oapdcxuNpatir$eoeaouCmiVrtctoCoecemwsnldtriDfdn.iSeyoopat.t.i"

    const/4 v3, 0x5

    const-string/jumbo v0, "riatibramodaaenodCDpe$tNletuSiVrtpoCo.ansieecopyitdcwc.ofxm.o"

    const-string v0, "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    packed-switch v1, :pswitch_data_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    goto :goto_1

    :pswitch_0
    const/4 v3, 0x1

    new-instance p0, Landroidx/core/app/x1$m;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Landroidx/core/app/x1$m;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0

    :pswitch_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance p0, Landroidx/core/app/x1$e;

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Landroidx/core/app/x1$e;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0

    :pswitch_2
    const/4 v3, 0x7

    const/4 v2, 0x3

    new-instance p0, Landroidx/core/app/x1$l;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0}, Landroidx/core/app/x1$l;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :pswitch_3
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p0, Landroidx/core/app/x1$d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Landroidx/core/app/x1$d;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0

    :pswitch_4
    const/4 v3, 0x0

    const/4 v2, 0x3

    new-instance p0, Landroidx/core/app/x1$i;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Landroidx/core/app/x1$i;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p0

    :cond_5
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x3

    and-int/2addr v3, v2

    return-object p0

    :sswitch_data_0
    .sparse-switch
        -0x2ab80d9c -> :sswitch_4
        -0xa3fb04d -> :sswitch_3
        0x366a678b -> :sswitch_2
        0x36cfe824 -> :sswitch_1
        0x7c9f11cd -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static j(Ljava/lang/String;)Landroidx/core/app/x1$q;
    .locals 5
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-class v2, Landroid/app/Notification$BigPictureStyle;

    const-class v2, Landroid/app/Notification$BigPictureStyle;

    const-class v2, Landroid/app/Notification$BigPictureStyle;

    const-class v2, Landroid/app/Notification$BigPictureStyle;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v2, :cond_1

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    new-instance p0, Landroidx/core/app/x1$d;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {p0}, Landroidx/core/app/x1$d;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object p0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-class v2, Landroid/app/Notification$BigTextStyle;

    const-class v2, Landroid/app/Notification$BigTextStyle;

    const/4 v4, 0x7

    const-class v2, Landroid/app/Notification$BigTextStyle;

    const-class v2, Landroid/app/Notification$BigTextStyle;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    if-eqz v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p0, Landroidx/core/app/x1$e;

    const/4 v4, 0x5

    invoke-direct {p0}, Landroidx/core/app/x1$e;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-class v2, Landroid/app/Notification$InboxStyle;

    const-class v2, Landroid/app/Notification$InboxStyle;

    const/4 v4, 0x0

    const-class v2, Landroid/app/Notification$InboxStyle;

    const-class v2, Landroid/app/Notification$InboxStyle;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance p0, Landroidx/core/app/x1$l;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0}, Landroidx/core/app/x1$l;-><init>()V

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/16 v2, 0x18

    const/4 v4, 0x1

    if-lt v1, v2, :cond_5

    const/4 v4, 0x1

    invoke-static {}, Landroidx/core/app/p2;->a()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_4

    const/4 v4, 0x4

    new-instance p0, Landroidx/core/app/x1$m;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p0}, Landroidx/core/app/x1$m;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    return-object p0

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Landroidx/core/app/q2;->a()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz p0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p0, Landroidx/core/app/x1$i;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Landroidx/core/app/x1$i;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0
.end method

.method static k(Landroid/os/Bundle;)Landroidx/core/app/x1$q;
    .locals 3
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    const-string v0, "CA.aTOurEpdpcEn.rTiod_eLpaArTMeP.x.oaMP"

    const-string/jumbo v0, "rd.aEpMpEMd.CrePArTaTLcTixOn.._apexoPoA"

    const/4 v2, 0x5

    const-string/jumbo v0, "roMxdrapMPcOp.depiTonaeLx.EA._ra.TCTtPA"

    const-string v0, "androidx.core.app.extra.COMPAT_TEMPLATE"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/app/x1$q;->i(Ljava/lang/String;)Landroidx/core/app/x1$q;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, ".ipilrsmqlqedNDfodaeaya"

    const-string/jumbo v0, "lafsilDoqNpnrdameeiday."

    const/4 v2, 0x3

    const-string v0, "Dosealnyir.ddNlmspfiesa"

    const-string v0, "android.selfDisplayName"

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_5

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "strmsliSemiUgaendossedyn.a"

    const-string v0, "Srsa.oenresdlydsgatmesnUii"

    const/4 v2, 0x4

    const-string/jumbo v0, "sedroay.gmtdeslgnroeiisanU"

    const-string v0, "android.messagingStyleUser"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v2, 0x3

    const-string/jumbo v0, "inrdobr.ipcudet"

    const-string v0, "android.picture"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance p0, Landroidx/core/app/x1$d;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Landroidx/core/app/x1$d;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "mTbi.guodxrniea"

    const-string/jumbo v0, "ragmixenti.bdTo"

    const/4 v2, 0x3

    const-string v0, "g.otiarpibexTdd"

    const-string v0, "android.bigText"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x1

    new-instance p0, Landroidx/core/app/x1$e;

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Landroidx/core/app/x1$e;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "indaotsLnider.xoe"

    const/4 v2, 0x6

    const-string/jumbo v0, "nad.tLtnqexeodrsi"

    const-string v0, "android.textLines"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    if-eqz v0, :cond_4

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance p0, Landroidx/core/app/x1$l;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Landroidx/core/app/x1$l;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0

    :cond_4
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, ".nseimateprddtbl"

    const-string v0, "arti.bmdnepltead"

    const/4 v2, 0x6

    const-string v0, "aeamnmpdit.elodt"

    const-string v0, "android.template"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {p0}, Landroidx/core/app/x1$q;->j(Ljava/lang/String;)Landroidx/core/app/x1$q;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0

    :cond_5
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance p0, Landroidx/core/app/x1$m;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Landroidx/core/app/x1$m;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method static l(Landroid/os/Bundle;)Landroidx/core/app/x1$q;
    .locals 4
    .param p0    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p0}, Landroidx/core/app/x1$q;->k(Landroid/os/Bundle;)Landroidx/core/app/x1$q;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v1

    :cond_0
    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$q;->y(Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    return-object v0

    :catch_0
    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v1
.end method

.method private n(III)Landroid/graphics/Bitmap;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, v0, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/IconCompat;->x(Landroid/content/Context;I)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, p3}, Landroidx/core/app/x1$q;->p(Landroidx/core/graphics/drawable/IconCompat;II)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1
.end method

.method private p(Landroidx/core/graphics/drawable/IconCompat;II)Landroid/graphics/Bitmap;
    .locals 5
    .param p1    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, v0, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroidx/core/graphics/drawable/IconCompat;->G(Landroid/content/Context;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p3, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    move v0, p3

    move v0, p3

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez p3, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result p3

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    sget-object v1, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, p3, v1}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, v2, v2, v0, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz p2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Landroid/graphics/PorterDuffColorFilter;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v2, Landroid/graphics/PorterDuff$Mode;->SRC_IN:Landroid/graphics/PorterDuff$Mode;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0, p2, v2}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p3, v0}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance p2, Landroid/graphics/Canvas;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p2, v1}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v1
.end method

.method private q(IIII)Landroid/graphics/Bitmap;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget v0, Landroidx/core/R$drawable;->notification_icon_background:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez p4, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 p4, 0x0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, v0, p4, p2}, Landroidx/core/app/x1$q;->n(III)Landroid/graphics/Bitmap;

    move-result-object p4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Landroid/graphics/Canvas;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0, p4}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, v1, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setFilterBitmap(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sub-int/2addr p2, p3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    div-int/lit8 p2, p2, 0x2

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    add-int/2addr p3, p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, p2, p2, p3, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p2, Landroid/graphics/PorterDuffColorFilter;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 p3, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v1, Landroid/graphics/PorterDuff$Mode;->SRC_ATOP:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p2, p3, v1}, Landroid/graphics/PorterDuffColorFilter;-><init>(ILandroid/graphics/PorterDuff$Mode;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p4
.end method

.method public static s(Landroid/app/Notification;)Landroidx/core/app/x1$q;
    .locals 2
    .param p0    # Landroid/app/Notification;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-static {p0}, Landroidx/core/app/x1;->n(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    if-nez p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p0

    :cond_0
    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p0}, Landroidx/core/app/x1$q;->l(Landroid/os/Bundle;)Landroidx/core/app/x1$q;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method private u(Landroid/widget/RemoteViews;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget v0, Landroidx/core/R$id;->title:I

    const/4 v3, 0x5

    const/16 v1, 0x8

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget v0, Landroidx/core/R$id;->text2:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    sget v0, Landroidx/core/R$id;->text:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-boolean v0, p0, Landroidx/core/app/x1$q;->d:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v0, "Tyruoiamur.snxetdao"

    const-string v0, "Taoxstumr.enayiurmd"

    const/4 v3, 0x6

    const-string v0, "d.nirbuoaxmsdtmeryT"

    const-string v0, "android.summaryText"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_0
    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "rlibdtun.tedai.op"

    const-string v1, ".dtitonp.delgrbai"

    const/4 v3, 0x4

    const-string/jumbo v1, "tgl.inrpeoiibdat."

    const-string v1, "android.title.big"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$q;->t()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "rCAL.PoEqMdeiqe.TATOdoc.xanTE.Maxtrppa_"

    const-string v1, "ceaedrCaq.EP._T.oEMOrMdanxArLxtTpTAio.p"

    const-string/jumbo v1, "rLsrAAOPtdEi_dTMoCp.aen.Troa.MaexxPEp.T"

    const-string v1, "androidx.core.app.extra.COMPAT_TEMPLATE"

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public b(Landroidx/core/app/v;)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public c(ZIZ)Landroid/widget/RemoteViews;
    .locals 12
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v0, v0, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    new-instance v7, Landroid/widget/RemoteViews;

    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v1, v1, Landroidx/core/app/x1$g;->a:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v7, v1, p2}, Landroid/widget/RemoteViews;-><init>(Ljava/lang/String;I)V

    iget-object p2, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    invoke-virtual {p2}, Landroidx/core/app/x1$g;->y()I

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v2, v1, Landroidx/core/app/x1$g;->j:Landroid/graphics/Bitmap;

    const/4 v8, 0x0

    if-eqz v2, :cond_0

    sget v1, Landroidx/core/R$id;->icon:I

    invoke-virtual {v7, v1, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    iget-object v2, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v2, v2, Landroidx/core/app/x1$g;->j:Landroid/graphics/Bitmap;

    invoke-virtual {v7, v1, v2}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    if-eqz p1, :cond_1

    iget-object p1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object p1, p1, Landroidx/core/app/x1$g;->U:Landroid/app/Notification;

    iget p1, p1, Landroid/app/Notification;->icon:I

    if-eqz p1, :cond_1

    sget p1, Landroidx/core/R$dimen;->notification_right_icon_size:I

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    sget v1, Landroidx/core/R$dimen;->notification_small_icon_background_padding:I

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    mul-int/lit8 v1, v1, 0x2

    sub-int v1, p1, v1

    iget-object v2, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v3, v2, Landroidx/core/app/x1$g;->U:Landroid/app/Notification;

    iget v3, v3, Landroid/app/Notification;->icon:I

    invoke-virtual {v2}, Landroidx/core/app/x1$g;->r()I

    move-result v2

    invoke-direct {p0, v3, p1, v1, v2}, Landroidx/core/app/x1$q;->q(IIII)Landroid/graphics/Bitmap;

    move-result-object p1

    sget v1, Landroidx/core/R$id;->right_icon:I

    invoke-virtual {v7, v1, p1}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    invoke-virtual {v7, v1, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    goto :goto_0

    :cond_0
    if-eqz p1, :cond_1

    iget-object p1, v1, Landroidx/core/app/x1$g;->U:Landroid/app/Notification;

    iget p1, p1, Landroid/app/Notification;->icon:I

    if-eqz p1, :cond_1

    sget p1, Landroidx/core/R$id;->icon:I

    invoke-virtual {v7, p1, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    sget v1, Landroidx/core/R$dimen;->notification_large_icon_width:I

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    sget v2, Landroidx/core/R$dimen;->notification_big_circle_margin:I

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    sub-int/2addr v1, v2

    sget v2, Landroidx/core/R$dimen;->notification_small_icon_size_as_large:I

    invoke-virtual {v0, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    iget-object v3, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v4, v3, Landroidx/core/app/x1$g;->U:Landroid/app/Notification;

    iget v4, v4, Landroid/app/Notification;->icon:I

    invoke-virtual {v3}, Landroidx/core/app/x1$g;->r()I

    move-result v3

    invoke-direct {p0, v4, v1, v2, v3}, Landroidx/core/app/x1$q;->q(IIII)Landroid/graphics/Bitmap;

    move-result-object v1

    invoke-virtual {v7, p1, v1}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    :cond_1
    :goto_0
    iget-object p1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object p1, p1, Landroidx/core/app/x1$g;->e:Ljava/lang/CharSequence;

    if-eqz p1, :cond_2

    sget v1, Landroidx/core/R$id;->title:I

    invoke-virtual {v7, v1, p1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_2
    iget-object p1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object p1, p1, Landroidx/core/app/x1$g;->f:Ljava/lang/CharSequence;

    const/4 v9, 0x1

    if-eqz p1, :cond_3

    sget v1, Landroidx/core/R$id;->text:I

    invoke-virtual {v7, v1, p1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    move p1, v9

    move p1, v9

    move p1, v9

    goto :goto_1

    :cond_3
    move p1, v8

    move p1, v8

    move p1, v8

    move p1, v8

    :goto_1
    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v2, v1, Landroidx/core/app/x1$g;->k:Ljava/lang/CharSequence;

    const/16 v10, 0x8

    if-eqz v2, :cond_4

    sget p1, Landroidx/core/R$id;->info:I

    invoke-virtual {v7, p1, v2}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-virtual {v7, p1, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    :goto_2
    move p1, v9

    move p1, v9

    move p1, v9

    move v11, p1

    move v11, p1

    move v11, p1

    move v11, p1

    goto :goto_4

    :cond_4
    iget v1, v1, Landroidx/core/app/x1$g;->l:I

    if-lez v1, :cond_6

    sget p1, Landroidx/core/R$integer;->status_bar_notification_info_maxnum:I

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getInteger(I)I

    move-result p1

    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget v1, v1, Landroidx/core/app/x1$g;->l:I

    if-le v1, p1, :cond_5

    sget p1, Landroidx/core/R$id;->info:I

    sget v1, Landroidx/core/R$string;->status_bar_notification_info_overflow:I

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v7, p1, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    goto :goto_3

    :cond_5
    invoke-static {}, Ljava/text/NumberFormat;->getIntegerInstance()Ljava/text/NumberFormat;

    move-result-object p1

    sget v1, Landroidx/core/R$id;->info:I

    iget-object v2, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget v2, v2, Landroidx/core/app/x1$g;->l:I

    int-to-long v2, v2

    invoke-virtual {p1, v2, v3}, Ljava/text/NumberFormat;->format(J)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v7, v1, p1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :goto_3
    sget p1, Landroidx/core/R$id;->info:I

    invoke-virtual {v7, p1, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    goto :goto_2

    :cond_6
    sget v1, Landroidx/core/R$id;->info:I

    invoke-virtual {v7, v1, v10}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    move v11, v8

    move v11, v8

    move v11, v8

    move v11, v8

    :goto_4
    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v1, v1, Landroidx/core/app/x1$g;->r:Ljava/lang/CharSequence;

    if-eqz v1, :cond_8

    sget v2, Landroidx/core/R$id;->text:I

    invoke-virtual {v7, v2, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    iget-object v1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-object v1, v1, Landroidx/core/app/x1$g;->f:Ljava/lang/CharSequence;

    if-eqz v1, :cond_7

    sget v2, Landroidx/core/R$id;->text2:I

    invoke-virtual {v7, v2, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-virtual {v7, v2, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    move v1, v9

    move v1, v9

    move v1, v9

    move v1, v9

    goto :goto_5

    :cond_7
    sget v1, Landroidx/core/R$id;->text2:I

    invoke-virtual {v7, v1, v10}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    :cond_8
    move v1, v8

    move v1, v8

    move v1, v8

    move v1, v8

    :goto_5
    if-eqz v1, :cond_a

    if-eqz p3, :cond_9

    sget p3, Landroidx/core/R$dimen;->notification_subtext_size:I

    invoke-virtual {v0, p3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p3

    int-to-float p3, p3

    sget v0, Landroidx/core/R$id;->text:I

    invoke-virtual {v7, v0, v8, p3}, Landroid/widget/RemoteViews;->setTextViewTextSize(IIF)V

    :cond_9
    sget v2, Landroidx/core/R$id;->line1:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    invoke-virtual/range {v1 .. v6}, Landroid/widget/RemoteViews;->setViewPadding(IIIII)V

    :cond_a
    iget-object p3, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    invoke-virtual {p3}, Landroidx/core/app/x1$g;->z()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    cmp-long p3, v0, v2

    if-eqz p3, :cond_c

    iget-object p3, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-boolean p3, p3, Landroidx/core/app/x1$g;->o:Z

    if-eqz p3, :cond_b

    sget p3, Landroidx/core/R$id;->chronometer:I

    invoke-virtual {v7, p3, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    invoke-virtual {v0}, Landroidx/core/app/x1$g;->z()J

    move-result-wide v0

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v2, v4

    add-long/2addr v0, v2

    const-string/jumbo v2, "tBsmesa"

    const-string v2, "esseaBt"

    const-string/jumbo v2, "setBase"

    invoke-virtual {v7, p3, v2, v0, v1}, Landroid/widget/RemoteViews;->setLong(ILjava/lang/String;J)V

    const-string/jumbo v0, "rSmtodtsea"

    const-string/jumbo v0, "tatmdSrets"

    const-string/jumbo v0, "sartdbeetS"

    const-string/jumbo v0, "setStarted"

    invoke-virtual {v7, p3, v0, v9}, Landroid/widget/RemoteViews;->setBoolean(ILjava/lang/String;Z)V

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    iget-boolean v0, v0, Landroidx/core/app/x1$g;->p:Z

    if-eqz v0, :cond_d

    const/16 v1, 0x18

    if-lt p2, v1, :cond_d

    invoke-static {v7, p3, v0}, Landroidx/core/app/o2;->a(Landroid/widget/RemoteViews;IZ)V

    goto :goto_6

    :cond_b
    sget p2, Landroidx/core/R$id;->time:I

    invoke-virtual {v7, p2, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    iget-object p3, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    invoke-virtual {p3}, Landroidx/core/app/x1$g;->z()J

    move-result-wide v0

    const-string/jumbo p3, "meTsotu"

    const-string/jumbo p3, "mteTose"

    const-string/jumbo p3, "pmeTtei"

    const-string/jumbo p3, "setTime"

    invoke-virtual {v7, p2, p3, v0, v1}, Landroid/widget/RemoteViews;->setLong(ILjava/lang/String;J)V

    goto :goto_6

    :cond_c
    move v9, v11

    move v9, v11

    move v9, v11

    move v9, v11

    :cond_d
    :goto_6
    sget p2, Landroidx/core/R$id;->right_side:I

    if-eqz v9, :cond_e

    move p3, v8

    move p3, v8

    move p3, v8

    move p3, v8

    goto :goto_7

    :cond_e
    move p3, v10

    move p3, v10

    move p3, v10

    move p3, v10

    :goto_7
    invoke-virtual {v7, p2, p3}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    sget p2, Landroidx/core/R$id;->line3:I

    if-eqz p1, :cond_f

    goto :goto_8

    :cond_f
    move v8, v10

    move v8, v10

    move v8, v10

    move v8, v10

    :goto_8
    invoke-virtual {v7, p2, v8}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    return-object v7
.end method

.method public d()Landroid/app/Notification;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/core/app/x1$g;->h()Landroid/app/Notification;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public e(Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
    .locals 9
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {p0, p1}, Landroidx/core/app/x1$q;->u(Landroid/widget/RemoteViews;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    sget v0, Landroidx/core/R$id;->notification_main_column:I

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {p1, v0}, Landroid/widget/RemoteViews;->removeAllViews(I)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p2}, Landroid/widget/RemoteViews;->clone()Landroid/widget/RemoteViews;

    move-result-object p2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1, v0, p2}, Landroid/widget/RemoteViews;->addView(ILandroid/widget/RemoteViews;)V

    const/4 v8, 0x7

    const/4 p2, 0x0

    const/4 v8, 0x3

    move v7, p2

    move v7, p2

    const/4 v8, 0x6

    invoke-virtual {p1, v0, p2}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget v2, Landroidx/core/R$id;->notification_main_column_container:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct {p0}, Landroidx/core/app/x1$q;->f()I

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v5, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v6, 0x0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual/range {v1 .. v6}, Landroid/widget/RemoteViews;->setViewPadding(IIIII)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void
.end method

.method protected g(Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const-string/jumbo v0, "oiar.nstqdudmaTebyx"

    const-string v0, "Tusrnbamaxymioedd.t"

    const/4 v2, 0x0

    const-string/jumbo v0, "odsydruaTeman.mritx"

    const-string v0, "android.summaryText"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v1, 0x0

    move v2, v1

    const-string v0, "dnrmba.iu.eitidtg"

    const-string v0, "i.netgu.taddrbiio"

    const/4 v2, 0x0

    const-string/jumbo v0, "t..doreniiiabotlg"

    const-string v0, "android.title.big"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v1, 0x4

    const-string/jumbo v0, "prAecboATpriLOtr.pP_xCxaoEPd.aEn..adMeM"

    const-string v0, "TM.OdMApppPorna.Px.orrE_taecTeEadCLA.ix"

    const/4 v2, 0x3

    const-string/jumbo v0, "oMLMaCuarppEAnrx.eoiE.ddctPeTOT.Pr_AxTa"

    const-string v0, "androidx.core.app.extra.COMPAT_TEMPLATE"

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public m(II)Landroid/graphics/Bitmap;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Landroidx/core/app/x1$q;->n(III)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p1
.end method

.method o(Landroidx/core/graphics/drawable/IconCompat;I)Landroid/graphics/Bitmap;
    .locals 3
    .param p1    # Landroidx/core/graphics/drawable/IconCompat;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0}, Landroidx/core/app/x1$q;->p(Landroidx/core/graphics/drawable/IconCompat;II)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p1
.end method

.method public r()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method protected t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public v(Landroidx/core/app/v;)Landroid/widget/RemoteViews;
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public w(Landroidx/core/app/v;)Landroid/widget/RemoteViews;
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-object p1
.end method

.method public x(Landroidx/core/app/v;)Landroid/widget/RemoteViews;
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 p1, 0x0

    move v1, p1

    return-object p1
.end method

.method protected y(Landroid/os/Bundle;)V
    .locals 4
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v0, ".qentddpTumrsaairmo"

    const-string v0, "arnToumtqdiarmd.sye"

    const/4 v3, 0x6

    const-string/jumbo v0, "mnrr.dxeqsaiodmutay"

    const-string v0, "android.summaryText"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/core/app/x1$q;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-boolean v0, p0, Landroidx/core/app/x1$q;->d:Z

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v0, "basiit.gnor.ietld"

    const-string v0, "android.title.big"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/core/app/x1$q;->b:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    move v3, v2

    return-void
.end method

.method public z(Landroidx/core/app/x1$g;)V
    .locals 3
    .param p1    # Landroidx/core/app/x1$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/core/app/x1$q;->a:Landroidx/core/app/x1$g;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1, p0}, Landroidx/core/app/x1$g;->z0(Landroidx/core/app/x1$q;)Landroidx/core/app/x1$g;

    :cond_0
    const/4 v2, 0x4

    return-void
.end method
