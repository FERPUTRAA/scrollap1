.class Landroidx/core/app/o3;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x10
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "NotificationCompat"

.field static final b:Ljava/lang/String; = "android.support.dataRemoteInputs"

.field static final c:Ljava/lang/String; = "android.support.allowGeneratedReplies"

.field private static final d:Ljava/lang/String; = "icon"

.field private static final e:Ljava/lang/String; = "title"

.field private static final f:Ljava/lang/String; = "actionIntent"

.field private static final g:Ljava/lang/String; = "extras"

.field private static final h:Ljava/lang/String; = "remoteInputs"

.field private static final i:Ljava/lang/String; = "dataOnlyRemoteInputs"

.field private static final j:Ljava/lang/String; = "resultKey"

.field private static final k:Ljava/lang/String; = "label"

.field private static final l:Ljava/lang/String; = "choices"

.field private static final m:Ljava/lang/String; = "allowFreeFormInput"

.field private static final n:Ljava/lang/String; = "allowedDataTypes"

.field private static final o:Ljava/lang/String; = "semanticAction"

.field private static final p:Ljava/lang/String; = "showsUserInterface"

.field private static final q:Ljava/lang/Object;

.field private static r:Ljava/lang/reflect/Field;

.field private static s:Z

.field private static final t:Ljava/lang/Object;

.field private static u:Ljava/lang/reflect/Field;

.field private static v:Ljava/lang/reflect/Field;

.field private static w:Ljava/lang/reflect/Field;

.field private static x:Ljava/lang/reflect/Field;

.field private static y:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Landroidx/core/app/o3;->q:Ljava/lang/Object;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-object v0, Landroidx/core/app/o3;->t:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-void
.end method

.method public static a(Ljava/util/List;)Landroid/util/SparseArray;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/os/Bundle;",
            ">;)",
            "Landroid/util/SparseArray<",
            "Landroid/os/Bundle;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "t s@~fc~@@ ~@i~~l~@  ~@~~~~@~@ ny ldM~o o~o@  bK1@@@/ai-u/m ~~@@~@o@ @@  o~ rf @b~ s~t~ v@4ob~iS"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ge v2, v0, :cond_2

    const/4 v5, 0x7

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    check-cast v3, Landroid/os/Bundle;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v1, Landroid/util/SparseArray;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v1
.end method

.method private static b()Z
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v0, "iaomfUs aitonoio bslcicceat annt tsnc"

    const-string/jumbo v0, "sis ncsn lobctoascUeafatoi nint toiac"

    const/4 v6, 0x1

    const-string/jumbo v0, "natcoifca  nooittl snossietiaeUccabo "

    const-string v0, "Unable to access notification actions"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v1, "iioaabpCmnmNittocf"

    const-string/jumbo v1, "poimntCtiaiNcamtof"

    const/4 v6, 0x4

    const-string v1, "NtifinucCtmtaoopao"

    const-string v1, "NotificationCompat"

    const/4 v5, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    sget-boolean v2, Landroidx/core/app/o3;->y:Z

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v2, 0x1

    :try_start_0
    const/4 v6, 0x0

    sget-object v3, Landroidx/core/app/o3;->u:Ljava/lang/reflect/Field;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const-string/jumbo v3, "oiraotdociNpcniAni$ndap.tf.ooit"

    const/4 v6, 0x6

    const-string/jumbo v3, "odt.Aanpa.iopfrtnoiitpiodacinNc"

    const-string v3, "android.app.Notification$Action"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v4, "ionc"

    const-string/jumbo v4, "noci"

    const-string v4, "cion"

    const-string/jumbo v4, "icon"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    sput-object v4, Landroidx/core/app/o3;->v:Ljava/lang/reflect/Field;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v4, "ltiqe"

    const-string/jumbo v4, "title"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    sput-object v4, Landroidx/core/app/o3;->w:Ljava/lang/reflect/Field;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v4, "ecsIntttanob"

    const-string v4, "caneIbttonnt"

    const/4 v6, 0x6

    const-string/jumbo v4, "tacmnnntItie"

    const-string v4, "actionIntent"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    sput-object v3, Landroidx/core/app/o3;->x:Ljava/lang/reflect/Field;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-class v3, Landroid/app/Notification;

    const-class v3, Landroid/app/Notification;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v4, "atocous"

    const-string/jumbo v4, "tisacou"

    const/4 v6, 0x5

    const-string/jumbo v4, "icstabn"

    const-string v4, "actions"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    sput-object v3, Landroidx/core/app/o3;->u:Ljava/lang/reflect/Field;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    move-exception v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {v1, v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    sput-boolean v2, Landroidx/core/app/o3;->y:Z

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :catch_1
    move-exception v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    sput-boolean v2, Landroidx/core/app/o3;->y:Z

    :cond_1
    :goto_0
    const/4 v6, 0x5

    sget-boolean v0, Landroidx/core/app/o3;->y:Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    xor-int/2addr v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v0
.end method

.method private static c(Landroid/os/Bundle;)Landroidx/core/app/h4;
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string/jumbo v0, "pltpalueoysadeaD"

    const-string/jumbo v0, "leaadwppayelosDt"

    const/4 v10, 0x5

    const-string v0, "adTlesapptDaylwo"

    const-string v0, "allowedDataTypes"

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    new-instance v8, Ljava/util/HashSet;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-direct {v8}, Ljava/util/HashSet;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-eqz v0, :cond_0

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eqz v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-interface {v8, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    new-instance v0, Landroidx/core/app/h4;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string v1, "Kqsyreueq"

    const-string v1, "erKsueytq"

    const/4 v10, 0x7

    const-string/jumbo v1, "susetreKy"

    const-string/jumbo v1, "resultKey"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v1, "bllme"

    const-string v1, "ebsll"

    const-string v1, "ebllo"

    const-string/jumbo v1, "label"

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v1, "chcisbm"

    const-string v1, "ecimhcs"

    const/4 v10, 0x5

    const-string v1, "ehiccsu"

    const-string v1, "choices"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getCharSequenceArray(Ljava/lang/String;)[Ljava/lang/CharSequence;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string v1, "epoonroptImeauwFlr"

    const-string/jumbo v1, "uFreoonrlpIloaetwm"

    const/4 v10, 0x1

    const-string/jumbo v1, "tomounIwqpllFeaeFr"

    const-string v1, "allowFreeFormInput"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v6, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v1, "exsatb"

    const-string/jumbo v1, "sxetab"

    const/4 v10, 0x5

    const-string/jumbo v1, "rtsmxa"

    const-string v1, "extras"

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v7

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct/range {v1 .. v8}, Landroidx/core/app/h4;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZILandroid/os/Bundle;Ljava/util/Set;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-object v0
.end method

.method private static d([Landroid/os/Bundle;)[Landroidx/core/app/h4;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    array-length v0, p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-array v0, v0, [Landroidx/core/app/h4;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    array-length v2, p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    if-ge v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    aget-object v2, p0, v1

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    invoke-static {v2}, Landroidx/core/app/o3;->c(Landroid/os/Bundle;)Landroidx/core/app/h4;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method

.method public static e(Landroid/app/Notification;I)Landroidx/core/app/x1$b;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v0, Landroidx/core/app/o3;->t:Ljava/lang/Object;

    const/4 v5, 0x2

    move v6, v5

    monitor-enter v0

    const/4 v5, 0x5

    move v6, v5

    const/4 v1, 0x0

    shr-int/2addr v6, v1

    :try_start_0
    const/4 v5, 0x5

    move v6, v5

    invoke-static {p0}, Landroidx/core/app/o3;->h(Landroid/app/Notification;)[Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    aget-object v2, v2, p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {p0}, Landroidx/core/app/o3;->k(Landroid/app/Notification;)Landroid/os/Bundle;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x4

    if-eqz p0, :cond_0

    const/4 v5, 0x0

    xor-int/2addr v6, v5

    const-string/jumbo v3, "rpttodadxsuncarpo.ou.saroEnt"

    const-string/jumbo v3, "uanp.susr.iotactopxtrnroaddE"

    const/4 v6, 0x0

    const-string v3, "android.support.actionExtras"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, v3}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz p0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    check-cast p0, Landroid/os/Bundle;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    sget-object p1, Landroidx/core/app/o3;->v:Ljava/lang/reflect/Field;

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {p1, v2}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object v3, Landroidx/core/app/o3;->w:Ljava/lang/reflect/Field;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v3, Ljava/lang/CharSequence;

    const/4 v6, 0x1

    sget-object v4, Landroidx/core/app/o3;->x:Ljava/lang/reflect/Field;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v4, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v2, Landroid/app/PendingIntent;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p1, v3, v2, p0}, Landroidx/core/app/o3;->l(ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;)Landroidx/core/app/x1$b;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_1

    :catch_0
    move-exception p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo p1, "tmofobptacaoiniiCN"

    const-string/jumbo p1, "tomaocNptiaipiCnof"

    const/4 v6, 0x3

    const-string/jumbo p1, "otonicuNitCmtfaaop"

    const-string p1, "NotificationCompat"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string v2, "i otastptsctoocenUlin qcace ifisnob n"

    const-string v2, "U snncaeqtieibcttacntsosc o fai oolni"

    const/4 v6, 0x2

    const-string/jumbo v2, "toUcbstoq an lif inane tscotaisicaocn"

    const-string v2, "Unable to access notification actions"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p1, v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v6, 0x3

    const/4 p0, 0x1

    const/4 v6, 0x5

    move v5, p0

    move v5, p0

    const/4 v6, 0x5

    sput-boolean p0, Landroidx/core/app/o3;->y:Z

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-object v1

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    throw p0
.end method

.method public static f(Landroid/app/Notification;)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Landroidx/core/app/o3;->t:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0}, Landroidx/core/app/o3;->h(Landroid/app/Notification;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    array-length p0, p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p0, 0x0

    :goto_0
    monitor-exit v0

    const/4 v2, 0x0

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p0
.end method

.method static g(Landroid/os/Bundle;)Landroidx/core/app/x1$b;
    .locals 15

    const-string/jumbo v0, "sasxet"

    const-string v0, "extras"

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    const-string/jumbo v3, "prdmisdtwoteanseiedrnlo.RlasluppoGre."

    const-string/jumbo v3, "rpstdndlstepsiweud.lGroaonpeR.reolaie"

    const-string v3, "Rlodoliwnrsad.ostdutpo.rnilpeGeraeepa"

    const-string v3, "android.support.allowGeneratedReplies"

    invoke-virtual {v1, v3, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    :cond_0
    move v10, v2

    move v10, v2

    move v10, v2

    move v10, v2

    new-instance v1, Landroidx/core/app/x1$b;

    const-string/jumbo v2, "oicn"

    const-string/jumbo v2, "onci"

    const-string/jumbo v2, "icon"

    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v4

    const-string v2, "bimtt"

    const-string/jumbo v2, "itemt"

    const-string/jumbo v2, "title"

    invoke-virtual {p0, v2}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v5

    const-string/jumbo v2, "tInioetnnatc"

    const-string v2, "actionIntent"

    invoke-virtual {p0, v2}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    move-object v6, v2

    check-cast v6, Landroid/app/PendingIntent;

    invoke-virtual {p0, v0}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v7

    const-string/jumbo v0, "tnepotuursbm"

    const-string/jumbo v0, "uteIpbtsmnro"

    const-string v0, "Inoeprspttmu"

    const-string/jumbo v0, "remoteInputs"

    invoke-static {p0, v0}, Landroidx/core/app/o3;->i(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/os/Bundle;

    move-result-object v0

    invoke-static {v0}, Landroidx/core/app/o3;->d([Landroid/os/Bundle;)[Landroidx/core/app/h4;

    move-result-object v8

    const-string v0, "dneetsuaqpRmnIOtlaou"

    const-string/jumbo v0, "patdIlusROoutenetmna"

    const-string/jumbo v0, "ltsOeptatnydoeunRaIs"

    const-string v0, "dataOnlyRemoteInputs"

    invoke-static {p0, v0}, Landroidx/core/app/o3;->i(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/os/Bundle;

    move-result-object v0

    invoke-static {v0}, Landroidx/core/app/o3;->d([Landroid/os/Bundle;)[Landroidx/core/app/h4;

    move-result-object v9

    const-string/jumbo v0, "nAmmtspeiinoca"

    const-string/jumbo v0, "oaeiccnpAstmni"

    const-string/jumbo v0, "ottionAicsecmn"

    const-string/jumbo v0, "semanticAction"

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v11

    const-string v0, "IaswtbrUeescqohsne"

    const-string/jumbo v0, "setoseraqsfeUncIhw"

    const-string v0, "UeorwnusrtcseeashI"

    const-string/jumbo v0, "showsUserInterface"

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v12

    const/4 v13, 0x0

    const/4 v14, 0x0

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    invoke-direct/range {v3 .. v14}, Landroidx/core/app/x1$b;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V

    return-object v1
.end method

.method private static h(Landroid/app/Notification;)[Ljava/lang/Object;
    .locals 6

    const/4 v4, 0x7

    move v5, v4

    sget-object v0, Landroidx/core/app/o3;->t:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Landroidx/core/app/o3;->b()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v2, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-object v2

    :cond_0
    :try_start_1
    const/4 v5, 0x6

    sget-object v1, Landroidx/core/app/o3;->u:Ljava/lang/reflect/Field;

    const/4 v4, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast p0, [Ljava/lang/Object;
    :try_end_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-object p0

    :catch_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v1, "NosfaiiptonciattCp"

    const-string/jumbo v1, "tNstnfiamapioCioct"

    const/4 v5, 0x3

    const-string v1, "fCootipiqctamaniNo"

    const-string v1, "NotificationCompat"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v3, "anscnficaolotn teoetac anmiis sbosiUt"

    const-string/jumbo v3, "neamsfc sttlnotboiccsioonta   eUniaia"

    const-string v3, "cscmtboa acfnotsacioli nnsoi n Uaiett"

    const-string v3, "Unable to access notification actions"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1, v3, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 p0, 0x1

    const/4 v4, 0x1

    move v5, v4

    sput-boolean p0, Landroidx/core/app/o3;->y:Z

    const/4 v4, 0x0

    move v5, v4

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object v2

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    throw p0
.end method

.method private static i(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/os/Bundle;
    .locals 5

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroid/os/Bundle;->getParcelableArray(Ljava/lang/String;)[Landroid/os/Parcelable;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    instance-of v1, v0, [Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    array-length v1, v0

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-class v2, [Landroid/os/Bundle;

    const-class v2, [Landroid/os/Bundle;

    const-class v2, [Landroid/os/Bundle;

    const-class v2, [Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0, v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;ILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    check-cast v0, [Landroid/os/Bundle;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p1, v0}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const/4 v4, 0x5

    return-object v0

    :cond_1
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    check-cast v0, [Landroid/os/Bundle;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object v0
.end method

.method static j(Landroidx/core/app/x1$b;)Landroid/os/Bundle;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    new-instance v0, Landroid/os/Bundle;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->f()Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroidx/core/graphics/drawable/IconCompat;->A()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v2, "onci"

    const-string/jumbo v2, "oicn"

    const/4 v5, 0x5

    const-string/jumbo v2, "icon"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string/jumbo v1, "lieto"

    const-string/jumbo v1, "ietlo"

    const/4 v5, 0x1

    const-string v1, "bleti"

    const-string/jumbo v1, "title"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->j()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v5, 0x1

    const-string/jumbo v1, "nncibtueontI"

    const-string/jumbo v1, "ontItbncinae"

    const/4 v5, 0x7

    const-string v1, "cntneItpotia"

    const-string v1, "actionIntent"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->a()Landroid/app/PendingIntent;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x2

    new-instance v1, Landroid/os/Bundle;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    :goto_1
    const/4 v5, 0x1

    const-string v2, "RasioGwnqpe.eidrasteotau.lpulrnerdope"

    const-string/jumbo v2, "wdrpnpuulspeato.tlesreoGlaadrRee.niio"

    const/4 v5, 0x0

    const-string/jumbo v2, "lrsrndredasldapoonpeil.tGw.etRepoeisa"

    const-string v2, "android.support.allowGeneratedReplies"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->b()Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const-string/jumbo v2, "xepmst"

    const-string/jumbo v2, "xpsaet"

    const/4 v5, 0x7

    const-string/jumbo v2, "srtaox"

    const-string v2, "extras"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->g()[Landroidx/core/app/h4;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v1}, Landroidx/core/app/o3;->n([Landroidx/core/app/h4;)[Landroid/os/Bundle;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string v2, "emorpbestnuI"

    const-string/jumbo v2, "remoteInputs"

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    invoke-virtual {v0, v2, v1}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v1, "eersesunwqUahosctf"

    const-string/jumbo v1, "scteeIefqsnrwsaUoh"

    const/4 v5, 0x6

    const-string/jumbo v1, "tewocUrprhsessIefa"

    const-string/jumbo v1, "showsUserInterface"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->i()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v5, 0x3

    const-string v1, "Acasomtcqentni"

    const-string/jumbo v1, "oastmnAtsccine"

    const/4 v5, 0x7

    const-string/jumbo v1, "tmsscnneAiciao"

    const-string/jumbo v1, "semanticAction"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroidx/core/app/x1$b;->h()I

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1, p0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object v0
.end method

.method public static k(Landroid/app/Notification;)Landroid/os/Bundle;
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    sget-object v0, Landroidx/core/app/o3;->q:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-boolean v1, Landroidx/core/app/o3;->s:Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-object v2

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v1, 0x1

    :try_start_1
    const/4 v7, 0x0

    sget-object v3, Landroidx/core/app/o3;->r:Ljava/lang/reflect/Field;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez v3, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-class v3, Landroid/app/Notification;

    const-class v3, Landroid/app/Notification;

    const-class v3, Landroid/app/Notification;

    const-class v3, Landroid/app/Notification;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v4, "sxtmma"

    const-string/jumbo v4, "xatmes"

    const/4 v7, 0x7

    const-string/jumbo v4, "rxtsoa"

    const-string v4, "extras"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-class v4, Landroid/os/Bundle;

    const-class v4, Landroid/os/Bundle;

    const/4 v7, 0x0

    const-class v4, Landroid/os/Bundle;

    const-class v4, Landroid/os/Bundle;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-nez v4, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string/jumbo p0, "titaoiNnCofocpotia"

    const/4 v7, 0x7

    const-string p0, "CotifbiapnoNacotmi"

    const-string p0, "NotificationCompat"

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    const-string/jumbo v3, "nrba sufiu x   etldaicntyNtinf lptoseootfeediio"

    const-string/jumbo v3, "ltnsebfdoNBricit   fxp sendoeeutl  aoytiiaotnif"

    const/4 v7, 0x3

    const-string/jumbo v3, "tdcaipipdfo ttBsnrt n lyoeesou aif oeiN efltx.n"

    const-string v3, "Notification.extras field is not of type Bundle"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p0, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    sput-boolean v1, Landroidx/core/app/o3;->s:Z
    :try_end_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-object v2

    :cond_1
    :try_start_3
    const/4 v7, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    sput-object v3, Landroidx/core/app/o3;->r:Ljava/lang/reflect/Field;

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget-object v3, Landroidx/core/app/o3;->r:Ljava/lang/reflect/Field;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v3, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    check-cast v3, Landroid/os/Bundle;

    const/4 v7, 0x1

    if-nez v3, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v3, Landroid/os/Bundle;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x6

    sget-object v4, Landroidx/core/app/o3;->r:Ljava/lang/reflect/Field;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v4, p0, v3}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :cond_3
    :try_start_4
    const/4 v7, 0x6

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-object v3

    :catch_0
    move-exception p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v3, "NiaoCtfiqamnouttcp"

    const-string/jumbo v3, "ioitNnutaptCfioamc"

    const/4 v7, 0x5

    const-string v3, "fastiootcimapNinoC"

    const-string v3, "NotificationCompat"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v4, "ec mt oanrsctap ni nxaaUlstieiooscft"

    const-string/jumbo v4, "rxnee apaoaiiceanotnit t fUcsstscol "

    const/4 v7, 0x4

    const-string v4, "Unable to access notification extras"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v3, v4, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x2

    goto :goto_0

    :catch_1
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string/jumbo v3, "otnpomoiaoitcqtCfi"

    const-string/jumbo v3, "tifnttocqapimoCoai"

    const/4 v7, 0x2

    const-string v3, "aoictbCtfpmtiiNnao"

    const-string v3, "NotificationCompat"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v4, "tecrtiuxcttnaeeliancssasn oaf  o ibs"

    const-string v4, "asseitsttncnae ccraaslofo  obt ineix"

    const/4 v7, 0x3

    const-string/jumbo v4, "iifaslUptstseoao cnnnte teo c baxric"

    const-string v4, "Unable to access notification extras"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v3, v4, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    sput-boolean v1, Landroidx/core/app/o3;->s:Z

    const/4 v6, 0x5

    const/4 v7, 0x3

    monitor-exit v0

    const/4 v7, 0x6

    return-object v2

    :catchall_0
    move-exception p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    throw p0
.end method

.method public static l(ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;)Landroidx/core/app/x1$b;
    .locals 13

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    if-eqz v4, :cond_0

    const-string/jumbo v0, "morsieedqrsdoop.pntrIntuuapm"

    const-string v0, "dntmmeoop.urr.ipdepsarIotnus"

    const-string v0, "ess.trdrnusuiateoropdI.ptmpn"

    const-string v0, "android.support.remoteInputs"

    invoke-static {v4, v0}, Landroidx/core/app/o3;->i(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/os/Bundle;

    move-result-object v0

    invoke-static {v0}, Landroidx/core/app/o3;->d([Landroid/os/Bundle;)[Landroidx/core/app/h4;

    move-result-object v0

    const-string/jumbo v1, "ti.mottepdodtoRaseupaanudsrpom.n"

    const-string/jumbo v1, "ptseoopiomuurtp..toedndadartnaRs"

    const-string v1, "android.support.dataRemoteInputs"

    invoke-static {v4, v1}, Landroidx/core/app/o3;->i(Landroid/os/Bundle;Ljava/lang/String;)[Landroid/os/Bundle;

    move-result-object v1

    invoke-static {v1}, Landroidx/core/app/o3;->d([Landroid/os/Bundle;)[Landroidx/core/app/h4;

    move-result-object v1

    const-string v2, ".pedow.iGRsbdurtpatlnldpeeroseoeralin"

    const-string/jumbo v2, "sraoabprleeterud.otwlplpResednda.Giin"

    const-string v2, "espe.buiad.nsodtGlenippldreoalRortewa"

    const-string v2, "android.support.allowGeneratedReplies"

    invoke-virtual {v4, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v2

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move v7, v2

    move v7, v2

    move v7, v2

    move v7, v2

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    const/4 v1, 0x0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v6, v5

    move-object v6, v5

    move v7, v1

    move v7, v1

    move v7, v1

    :goto_0
    new-instance v12, Landroidx/core/app/x1$b;

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object v0, v12

    move-object v0, v12

    move-object v0, v12

    move v1, p0

    move v1, p0

    move v1, p0

    move v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    invoke-direct/range {v0 .. v11}, Landroidx/core/app/x1$b;-><init>(ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroidx/core/app/h4;[Landroidx/core/app/h4;ZIZZZ)V

    return-object v12
.end method

.method private static m(Landroidx/core/app/h4;)Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/core/app/h4;->o()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v2, "euesrKuuy"

    const-string v2, "eyuesrutK"

    const/4 v4, 0x0

    const-string/jumbo v2, "letsurypK"

    const-string/jumbo v2, "resultKey"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v1, "lalqp"

    const-string/jumbo v1, "lepla"

    const/4 v4, 0x3

    const-string/jumbo v1, "llseb"

    const-string/jumbo v1, "label"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/core/app/h4;->n()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const/4 v4, 0x1

    const-string v1, "ehqmioc"

    const-string/jumbo v1, "oqehsic"

    const/4 v4, 0x6

    const-string v1, "ecshooc"

    const-string v1, "choices"

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/core/app/h4;->h()[Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putCharSequenceArray(Ljava/lang/String;[Ljava/lang/CharSequence;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "urIalbpwolFesFtoen"

    const-string v1, "easlulmoonFwepIFrt"

    const/4 v4, 0x3

    const-string/jumbo v1, "llmFoIuFeontaepruw"

    const-string v1, "allowFreeFormInput"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/core/app/h4;->f()Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v1, "rpstxa"

    const-string/jumbo v1, "tsrmax"

    const/4 v4, 0x2

    const-string/jumbo v1, "sxqrae"

    const-string v1, "extras"

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {p0}, Landroidx/core/app/h4;->m()Landroid/os/Bundle;

    move-result-object v2

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0, v1, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/core/app/h4;->g()Ljava/util/Set;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/Set;->isEmpty()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo p0, "yesslaatoTaoplwe"

    const-string p0, "aTlyoalwpedsotea"

    const/4 v4, 0x3

    const-string/jumbo p0, "waamedtalyDelsop"

    const-string p0, "allowedDataTypes"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p0, v1}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-object v0
.end method

.method private static n([Landroidx/core/app/h4;)[Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    array-length v0, p0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-array v0, v0, [Landroid/os/Bundle;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    array-length v2, p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    aget-object v2, p0, v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v2}, Landroidx/core/app/o3;->m(Landroidx/core/app/h4;)Landroid/os/Bundle;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v0
.end method

.method public static o(Landroid/app/Notification$Builder;Landroidx/core/app/x1$b;)Landroid/os/Bundle;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->f()Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroidx/core/graphics/drawable/IconCompat;->A()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->j()Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->a()Landroid/app/PendingIntent;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v1, v2}, Landroid/app/Notification$Builder;->addAction(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance p0, Landroid/os/Bundle;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->d()Landroid/os/Bundle;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->g()[Landroidx/core/app/h4;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->g()[Landroidx/core/app/h4;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Landroidx/core/app/o3;->n([Landroidx/core/app/h4;)[Landroid/os/Bundle;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "noiaoopmtsr.uudIsd.ptbrortnp"

    const-string/jumbo v1, "pdrnobmprIseatsup.trtiou.ond"

    const/4 v4, 0x2

    const-string/jumbo v1, "teIp.bppdesusaontr.rtdurinmo"

    const-string v1, "android.support.remoteInputs"

    const/4 v3, 0x7

    and-int/2addr v4, v3

    invoke-virtual {p0, v1, v0}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->c()[Landroidx/core/app/h4;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->c()[Landroidx/core/app/h4;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Landroidx/core/app/o3;->n([Landroidx/core/app/h4;)[Landroid/os/Bundle;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "apuaeuurmossnto.uietp.ptddRtdIoa"

    const-string/jumbo v1, "tndar.upaotdIssRort.euemipputdoa"

    const/4 v4, 0x1

    const-string v1, "aut.dnrpRoipprIns.adtteoupmeatsd"

    const-string v1, "android.support.dataRemoteInputs"

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, v1, v0}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    :cond_2
    const/4 v4, 0x4

    const-string/jumbo v0, "sesiRwlrqnddorearuaeoe.oGip.dnptleppa"

    const-string/jumbo v0, "satdw.ippodrirRnulpeet.eaoenrGsdeploa"

    const/4 v4, 0x1

    const-string/jumbo v0, "pdslosGsrnepurR.aaotid.oepwaletrdneel"

    const-string v0, "android.support.allowGeneratedReplies"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroidx/core/app/x1$b;->b()Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0, v0, p1}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    return-object p0
.end method
