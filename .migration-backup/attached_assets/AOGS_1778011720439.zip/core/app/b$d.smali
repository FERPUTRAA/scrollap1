.class Landroidx/core/app/b$d;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x16
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "d"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method

.method static a(Landroid/app/Activity;)Landroid/net/Uri;
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "rSsv~~~1~~t ~~ @ ~~@y@b  b@Mi o~@f~~@f@@i @@mo~n sc@/ .4 ~o/olt~~ b@ooil~ @@@@-a   ~@u~@@~ ~d~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/app/Activity;->getReferrer()Landroid/net/Uri;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method
