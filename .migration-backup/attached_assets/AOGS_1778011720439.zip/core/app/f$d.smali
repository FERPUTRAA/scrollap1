.class final Landroidx/core/app/f$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "d"
.end annotation


# instance fields
.field a:Ljava/lang/Object;

.field private b:Landroid/app/Activity;

.field private final c:I

.field private d:Z

.field private e:Z

.field private f:Z


# direct methods
.method constructor <init>(Landroid/app/Activity;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Landroidx/core/app/f$d;->d:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-boolean v0, p0, Landroidx/core/app/f$d;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-boolean v0, p0, Landroidx/core/app/f$d;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/core/app/f$d;->b:Landroid/app/Activity;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, p0, Landroidx/core/app/f$d;->c:I

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/ so~t@b~~~@.oso@@y4@-@~~c  Mrotb~idu @ @~@@~m@ l@~@@ ~~f~~ @1 v@ @i/on~l @f~~oK~  a~b~S~@  ~ i "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/f$d;->b:Landroid/app/Activity;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/core/app/f$d;->b:Landroid/app/Activity;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean p1, p0, Landroidx/core/app/f$d;->e:Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-boolean v0, p0, Landroidx/core/app/f$d;->e:Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    and-int/2addr v3, v2

    iget-boolean v0, p0, Landroidx/core/app/f$d;->f:Z

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    iget-boolean v0, p0, Landroidx/core/app/f$d;->d:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/f$d;->a:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, p0, Landroidx/core/app/f$d;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1, p1}, Landroidx/core/app/f;->h(Ljava/lang/Object;ILandroid/app/Activity;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x1

    shr-int/2addr v3, p1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-boolean p1, p0, Landroidx/core/app/f$d;->f:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x0

    iput-object p1, p0, Landroidx/core/app/f$d;->a:Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x5

    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/f$d;->b:Landroid/app/Activity;

    const/4 v2, 0x4

    if-ne v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-boolean p1, p0, Landroidx/core/app/f$d;->d:Z

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method
