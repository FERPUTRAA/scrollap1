.class public final Landroidx/core/app/n3;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "android.support.localOnly"

.field public static final b:Ljava/lang/String; = "android.support.groupKey"

.field public static final c:Ljava/lang/String; = "android.support.isGroupSummary"

.field public static final d:Ljava/lang/String; = "android.support.sortKey"

.field public static final e:Ljava/lang/String; = "android.support.actionExtras"

.field public static final f:Ljava/lang/String; = "android.support.remoteInputs"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method
