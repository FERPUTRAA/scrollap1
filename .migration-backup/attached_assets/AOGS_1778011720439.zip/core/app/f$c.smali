.class Landroidx/core/app/f$c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/app/f;->h(Ljava/lang/Object;ILandroid/app/Activity;)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/Object;

.field final synthetic b:Ljava/lang/Object;


# direct methods
.method constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/app/f$c;->a:Ljava/lang/Object;

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p2, p0, Landroidx/core/app/f$c;->b:Ljava/lang/Object;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 9

    :try_start_0
    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~@sono~ tt~ @@cb~fb~omMo-@~ /~@ly@ i@Sv ~.@ ~iu 4@1 i la @ @~@~@r@~ ~~@@~~/~@bo  ~@K   f@~~os@d~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x2

    sget-object v0, Landroidx/core/app/f;->e:Ljava/lang/reflect/Method;

    const/4 v7, 0x5

    move v8, v7

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v3, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v4, p0, Landroidx/core/app/f$c;->a:Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v5, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v6, p0, Landroidx/core/app/f$c;->b:Ljava/lang/Object;

    const/4 v8, 0x3

    aput-object v6, v5, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    aput-object v2, v5, v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string/jumbo v1, "ooamAn tamrpeCpiecst"

    const-string/jumbo v1, "tnsAtmCipeeaoroapcp "

    const/4 v8, 0x7

    const-string/jumbo v1, "tapioAaemocoprnCerp "

    const-string v1, "AppCompat recreation"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    aput-object v1, v5, v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    sget-object v0, Landroidx/core/app/f;->f:Ljava/lang/reflect/Method;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v4, p0, Landroidx/core/app/f$c;->a:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v5, p0, Landroidx/core/app/f$c;->b:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x6

    aput-object v5, v3, v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    aput-object v2, v3, v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, v4, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v1, "crrtibaetvtRiomAe"

    const-string v1, "acymtreoetitvirRA"

    const/4 v8, 0x2

    const-string v1, "ActivityRecreator"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const-string/jumbo v2, "orcxttuimwovvnEihAiSkptoon e gf ioirpeinecpl"

    const-string/jumbo v2, "ifAlowvtktngt peopncS iiteic iEhopvrirxeomon"

    const/4 v8, 0x4

    const-string v2, "Exception while invoking performStopActivity"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-class v2, Ljava/lang/RuntimeException;

    const-class v2, Ljava/lang/RuntimeException;

    const/4 v8, 0x3

    const-class v2, Ljava/lang/RuntimeException;

    const-class v2, Ljava/lang/RuntimeException;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-ne v1, v2, :cond_2

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v1, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v2, " oetbbUpptalso"

    const-string v2, "balptb sUoneot"

    const/4 v8, 0x2

    const-string v2, "Unable to stop"

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-nez v1, :cond_1

    const/4 v7, 0x2

    move v8, v7

    goto :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    throw v0

    :cond_2
    :goto_0
    const/4 v8, 0x7

    return-void
.end method
