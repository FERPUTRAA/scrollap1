.class public final synthetic Landroidx/core/app/j2;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s @~@~@f ~~@@~~~~bor~@cy M~~  @~ib/.-@/~o d s1@t~@olmK  S @u @~~ibi o~o@ @@~a~~v t~o@4 @fln~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Landroid/app/Notification$MessagingStyle;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
