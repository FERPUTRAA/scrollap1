.class public Landroidx/core/app/j4$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/app/j4;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private final a:Landroid/content/Context;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Landroid/content/Intent;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private c:Ljava/lang/CharSequence;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field private d:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private e:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private f:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private g:Ljava/util/ArrayList;
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/net/Uri;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {p1}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast v0, Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v0, p0, Landroidx/core/app/j4$b;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v1, "SEsia.itdnso.nDet.rncandiN"

    const-string/jumbo v1, "nds.ti.onDtEatniSdNcerin.a"

    const/4 v4, 0x4

    const-string/jumbo v1, "nDemEiiNntcon.rot.addiSant"

    const-string v1, "android.intent.action.SEND"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v2, "._EiodAd_opeKrAIxAAGcEGN.LCaTmC.npoLPaR"

    const-string v2, "CArmPnAIcRdK.oG.iECGTdE_LropAaLa_Ap.exN"

    const/4 v4, 0x1

    const-string v2, "ani.PbdAGaoANCAEC_oxIRppr.A_KEdGeLcXT.L"

    const-string v2, "androidx.core.app.EXTRA_CALLING_PACKAGE"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "oNuKpEurApLiXooCn_IaEGp.dALA_v4aPCAGR.sd..pt"

    const-string v1, "EAGroT4.dauaLApPGNdRA.nA_C.tiLEsp_XvoCpKIpo."

    const/4 v4, 0x2

    const-string v1, "Xnp..tCppEGALNiRpIpoEG_a4Po_KvrCL.rs.audATAd"

    const-string v1, "android.support.v4.app.EXTRA_CALLING_PACKAGE"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/high16 v1, 0x80000

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    instance-of v0, p1, Landroid/content/ContextWrapper;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    instance-of v0, p1, Landroid/app/Activity;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast p1, Landroid/app/Activity;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast p1, Landroid/content/ContextWrapper;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 p1, 0x0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "opGCArIbqC_V_xIXa...TYocirTLTNdeAIpLnaRE"

    const-string v1, "ReiXrbrTp_.L_AaCoT.NpaAIoGIYnVdExLCdTIc."

    const/4 v4, 0x4

    const-string v1, "cTsIYAANTGaRIdVX.pCErrTiaoe.ndC.LLIx_Ao_"

    const-string v1, "androidx.core.app.EXTRA_CALLING_ACTIVITY"

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x7

    move v4, v3

    const-string v1, "I4amCLnRor_ICGYIpdrTATs.ovp.E.dALXiVuNA_tTu.a"

    const-string/jumbo v1, "p.LT_Tu4dXErCApIN.soiILRpYtur.Ad.CvA_nIVGoaaT"

    const/4 v4, 0x3

    const-string v1, "CrAAo4CIp.ip.todpTRTIa_p.nT_rvouYXLI.NALdGaVs"

    const-string v1, "android.support.v4.app.EXTRA_CALLING_ACTIVITY"

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-void
.end method

.method private h(Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@ @@@b/~ @~ o@ ~ @ sr/@.~ay@~M@ f@i~~@~@f~@~oo m @l@~tol~~1~~ i~io~b~b 4n~~c@  -@StK @@  ub~dv~o"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    array-length v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    move v2, v1

    move v2, v1

    const/4 v5, 0x0

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/2addr v3, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    new-array v3, v3, [Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v1, v3, p2, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p2, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, p1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method private i(Ljava/lang/String;[Ljava/lang/String;)V
    .locals 7
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroidx/core/app/j4$b;->m()Landroid/content/Intent;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Landroid/content/Intent;->getStringArrayExtra(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    array-length v3, v1

    const/4 v5, 0x1

    or-int/2addr v6, v5

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    move v3, v2

    move v3, v2

    const/4 v6, 0x7

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    array-length v4, p2

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    add-int/2addr v4, v3

    const/4 v6, 0x0

    new-array v4, v4, [Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v1, :cond_1

    const/4 v6, 0x3

    invoke-static {v1, v2, v4, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    array-length v1, p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p2, v2, v4, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0, p1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void
.end method

.method public static k(Landroid/app/Activity;)Landroidx/core/app/j4$b;
    .locals 3
    .param p0    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Landroidx/core/app/j4$b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p0}, Landroidx/core/app/j4$b;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/j4$b;->f:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    iput-object v0, p0, Landroidx/core/app/j4$b;->f:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$b;->f:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public b([Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "eret.puCinr.nnoBa.Cdtait"

    const-string v0, "airdneBp.rC.Caxntte.nito"

    const/4 v2, 0x2

    const-string v0, "android.intent.extra.BCC"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Landroidx/core/app/j4$b;->i(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public c(Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$b;->e:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/core/app/j4$b;->e:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    iget-object v0, p0, Landroidx/core/app/j4$b;->e:Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public d([Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "td.odnipane.Cne.ttxiraq"

    const-string/jumbo v0, "ie.nCtxdq.tan.edainotCr"

    const/4 v2, 0x5

    const-string v0, "android.intent.extra.CC"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Landroidx/core/app/j4$b;->i(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v2, 0x5

    return-object p0
.end method

.method public e(Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public f([Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, "..rMreoeqd.EtixtniALsdaaIn"

    const-string/jumbo v0, "ons..intxInAd.MLtrearEeiad"

    const/4 v2, 0x0

    const-string/jumbo v0, "nasiettLAnMandeEorI.ri.dtx"

    const-string v0, "android.intent.extra.EMAIL"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, v0, p1}, Landroidx/core/app/j4$b;->i(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public g(Landroid/net/Uri;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public j()Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/core/app/j4$b;->m()Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/core/app/j4$b;->c:Ljava/lang/CharSequence;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0
.end method

.method l()Landroid/content/Context;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/app/j4$b;->a:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public m()Landroid/content/Intent;
    .locals 6
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v2, "MoemEtdIinet..ar.LAxirnadt"

    const-string/jumbo v2, "teAmoLtanxrd.niItid.raEMe."

    const/4 v5, 0x5

    const-string v2, "e.taoM.dIioLAtnrtnEine.xra"

    const-string v2, "android.intent.extra.EMAIL"

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-direct {p0, v2, v0}, Landroidx/core/app/j4$b;->h(Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-object v1, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$b;->e:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v2, "etConbireat.rx.adndin.C"

    const-string v2, "edrdonaxoet.CiCnrtan.i."

    const/4 v5, 0x3

    const-string v2, ".Cat.ruete.ionntidxnraC"

    const-string v2, "android.intent.extra.CC"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0, v2, v0}, Landroidx/core/app/j4$b;->h(Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v1, p0, Landroidx/core/app/j4$b;->e:Ljava/util/ArrayList;

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$b;->f:Ljava/util/ArrayList;

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, ".anotdeptndntiBrb.rexCa."

    const-string v2, ".entBbaatCon.rtxi.Cerddn"

    const/4 v5, 0x6

    const-string v2, "CCnBitntq.atedonxir.rda."

    const-string v2, "android.intent.extra.BCC"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {p0, v2, v0}, Landroidx/core/app/j4$b;->h(Ljava/lang/String;Ljava/util/ArrayList;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-object v1, p0, Landroidx/core/app/j4$b;->f:Ljava/util/ArrayList;

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-le v0, v2, :cond_3

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_3
    const/4 v4, 0x7

    move v5, v4

    move v2, v1

    move v2, v1

    const/4 v5, 0x3

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v0, "tMstn.Srda.eEedaxiRtTunioAr"

    const-string/jumbo v0, "rREnTdutd.nSotaMnxri.ieaAet"

    const/4 v5, 0x2

    const-string v0, ".tMmi.AanrdeST.ttirEneoRdna"

    const-string v0, "android.intent.extra.STREAM"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v2, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v2, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v4, 0x3

    move v5, v4

    const-string v3, "ad.aotinnD.npioticNetdES.n"

    const-string v3, "dntDScipNntaaEor.i.dn.teni"

    const/4 v5, 0x7

    const-string v3, ".E.tobtanrdneaicNDSnit.ond"

    const-string v3, "android.intent.action.SEND"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x2

    move v5, v4

    iget-object v2, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v2, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v3, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    check-cast v1, Landroid/os/Parcelable;

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v1, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0, v1}, Landroidx/core/app/j4$a;->b(Landroid/content/Intent;Ljava/util/ArrayList;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_1

    :cond_4
    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0}, Landroidx/core/app/j4$a;->c(Landroid/content/Intent;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_1

    :cond_5
    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v1, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v2, "teNctLiUqi.Trn_.MaIStio.ndEELPnDdna"

    const/4 v5, 0x6

    const-string v2, ".nnc.ruLonaei.SPELodMINiitE_ttUnDad"

    const-string v2, "android.intent.action.SEND_MULTIPLE"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v1, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v2, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putParcelableArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v1}, Landroidx/core/app/j4$a;->b(Landroid/content/Intent;Ljava/util/ArrayList;)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object v0
.end method

.method public n(I)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/app/j4$b;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroidx/core/app/j4$b;->o(Ljava/lang/CharSequence;)Landroidx/core/app/j4$b;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p1
.end method

.method public o(Ljava/lang/CharSequence;)Landroidx/core/app/j4$b;
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/app/j4$b;->c:Ljava/lang/CharSequence;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public p([Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 4
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "Csidranp.n.e.tnBtCxoiaed"

    const-string/jumbo v1, "nas.oeen.ntriCxir.ddtCBa"

    const/4 v3, 0x1

    const-string v1, ".Cett.deq.niartndCirnBao"

    const-string v1, "android.intent.extra.BCC"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0
.end method

.method public q([Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 4
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "i.s.aoedrtamndteir.txCn"

    const-string v1, ".C.mrxtinedadtiareCt.on"

    const/4 v3, 0x2

    const-string/jumbo v1, "riCmrn.teCi.oe.ndandatx"

    const-string v1, "android.intent.extra.CC"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0
.end method

.method public r([Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 4
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Landroidx/core/app/j4$b;->d:Ljava/util/ArrayList;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const-string v1, "MoenotrdianxdtIEL.a.o.Aine"

    const-string v1, "e.nronodtAn.aiMEraIdxi.eLt"

    const/4 v3, 0x6

    const-string/jumbo v1, "nEaiob.tex.reILdAirdtnMtan"

    const-string v1, "android.intent.extra.EMAIL"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x2

    return-object p0
.end method

.method public s(Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v1, "na_ETnutntXiotTa.LMHdbreixr.Td"

    const-string v1, "eTMtdbtHXTnnidEt.no._LTxiearar"

    const/4 v3, 0x6

    const-string/jumbo v1, "tToed.tpexLMdaHrTnnEtiaTX_..rn"

    const-string v1, "android.intent.extra.HTML_TEXT"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v1, "Taiutdatqi.reToXdn.rxn.en"

    const-string v1, "a.ndt.uitnrerTian.TeotXxd"

    const/4 v3, 0x7

    const-string/jumbo v1, "tnsar..entidr.ETedXxiatnT"

    const-string v1, "android.intent.extra.TEXT"

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    invoke-static {p1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;)Landroid/text/Spanned;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroidx/core/app/j4$b;->v(Ljava/lang/CharSequence;)Landroidx/core/app/j4$b;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p0
.end method

.method public t(Landroid/net/Uri;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    iput-object v0, p0, Landroidx/core/app/j4$b;->g:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroidx/core/app/j4$b;->g(Landroid/net/Uri;)Landroidx/core/app/j4$b;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public u(Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v1, ".iJxBnepttd.innU.adrTSretEoC"

    const/4 v3, 0x2

    const-string v1, "CSTmr.teidxt.BnJrtidaEn.oena"

    const-string v1, "android.intent.extra.SUBJECT"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public v(Ljava/lang/CharSequence;)Landroidx/core/app/j4$b;
    .locals 4
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v1, "etnToaXqr..dntnixoaetdET."

    const-string v1, "enaiEoe.qtntnrTXaxdr.dT.t"

    const/4 v3, 0x4

    const-string v1, "erex.b.t.tiiadTEondrtnnaX"

    const-string v1, "android.intent.extra.TEXT"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method public w(Ljava/lang/String;)Landroidx/core/app/j4$b;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-object v0, p0, Landroidx/core/app/j4$b;->b:Landroid/content/Intent;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public x()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/app/j4$b;->a:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/core/app/j4$b;->j()Landroid/content/Intent;

    move-result-object v1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method
