.class public final synthetic Landroidx/core/app/a3;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Builder;Z)Landroid/app/Notification$Builder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~Ss@~~r~ @sm~n@1@ ~ott@~c o.~ ~~/o@@o ~ o  i@av@o~@@ / f4b@y@ ~ ~bK @ @l~ l~~-~@@@udb i~~@i@~M f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroid/app/Notification$Builder;->setColorized(Z)Landroid/app/Notification$Builder;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p0
.end method
