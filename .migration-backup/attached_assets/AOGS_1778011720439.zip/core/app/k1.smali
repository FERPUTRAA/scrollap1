.class public final synthetic Landroidx/core/app/k1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/Notification$Action;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@sr  S@@~~olt@i// M~uo@~b~ @4o@df~-@.@c~n olb@@~~@~@~o~  ~v  ~f ~y@i~@~@~s~@ @ iK~b~m 1ao  ~@t "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/app/Notification$Action;->isAuthenticationRequired()Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    return p0
.end method
