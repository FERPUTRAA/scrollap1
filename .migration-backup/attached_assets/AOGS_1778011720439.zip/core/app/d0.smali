.class public final synthetic Landroidx/core/app/d0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/app/NotificationChannel;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "n~s~@~~ifs br@@@   @d @o~a @ol4@o@c~~-@~ o~i@@S~ Kl@by1 @~~~M~ t~~m ft/~   u~ i/ ~@b.@@~@vo o@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/app/NotificationChannel;->getLightColor()I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p0
.end method
