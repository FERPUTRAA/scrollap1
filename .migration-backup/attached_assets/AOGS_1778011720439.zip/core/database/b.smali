.class public final Landroidx/core/database/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/database/b$a;,
        Landroidx/core/database/b$b;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Ljava/lang/String;J)Landroid/database/CursorWindow;
    .locals 4
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~St~l@~   r@Mf@.~1~@ obi@~o@ @s  @~t@/ b@ ~~~- ~@ny~@ ~o@ /~ fv~adi ~u~~@~  @oc@lK4oo@@mib~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/16 v1, 0x1c

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0, p1, p2}, Landroidx/core/database/b$b;->a(Ljava/lang/String;J)Landroid/database/CursorWindow;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x4

    invoke-static {p0}, Landroidx/core/database/b$a;->a(Ljava/lang/String;)Landroid/database/CursorWindow;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method
