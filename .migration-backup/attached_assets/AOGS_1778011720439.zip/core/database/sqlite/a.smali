.class public final Landroidx/core/database/sqlite/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/database/sqlite/a$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/database/sqlite/SQLiteCursor;Z)V
    .locals 4
    .param p0    # Landroid/database/sqlite/SQLiteCursor;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s ~~ila~/c.~@o~@~t @S /t b @M@fmv@on@bK4d~@ @@i~@~y~@ oo~@@suo@l@ ri b ~~f@-~~~  @~ ~1@~o  @~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 v1, 0x1c

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0, p1}, Landroidx/core/database/sqlite/a$a;->a(Landroid/database/sqlite/SQLiteCursor;Z)V

    :cond_0
    return-void
.end method
