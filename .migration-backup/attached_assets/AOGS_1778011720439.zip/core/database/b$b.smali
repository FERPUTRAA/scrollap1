.class Landroidx/core/database/b$b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1c
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/database/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method static a(Ljava/lang/String;J)Landroid/database/CursorWindow;
    .locals 3
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "1~sv~~@ S @ i 4b~ c@lo.@ls~iy@o@@~@Mf~n  io~@~o @@~/~~~o~ ~~ @b ~ ~d~~~  Kf@b@@m@ @~ oa@@r@ ttu/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    new-instance v0, Landroid/database/CursorWindow;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    invoke-direct {v0, p0, p1, p2}, Landroid/database/CursorWindow;-><init>(Ljava/lang/String;J)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
