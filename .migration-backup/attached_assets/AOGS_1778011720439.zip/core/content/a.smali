.class public final Landroidx/core/content/a;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/content/ContentProvider;)Landroid/content/Context;
    .locals 3
    .param p0    # Landroid/content/ContentProvider;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "n@s~~~bM i@1 d@@.@~-o~@~/o @  @fcbl~ @oo ~ i~tS@4~ v~~r@y~  @~tm@ i@@f~~ l ~ s@~~~ /bao~uo@K@ ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string v0, "  tmor xomcCh.i irvet ffpdsnneeraonott"

    const-string v0, " is n tCecnprmaeoroiore ontt fhndvfxt."

    const/4 v2, 0x6

    const-string/jumbo v0, "norfor i mt r p ne.idotnCovenftxtecdho"

    const-string v0, "Cannot find context from the provider."

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    throw p0
.end method
