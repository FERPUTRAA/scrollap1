.class Landroidx/core/content/q$a;
.super Landroidx/core/app/unusedapprestrictions/a$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/core/content/q;->c()Landroidx/core/app/unusedapprestrictions/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic c:Landroidx/core/content/q;


# direct methods
.method constructor <init>(Landroidx/core/content/q;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/core/content/q$a;->c:Landroidx/core/content/q;

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Landroidx/core/app/unusedapprestrictions/a$b;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public w(ZZ)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "tosv@~y/1b iK.cl@~4l@  ~ ~~/@@ obirno t~b~ @o-@@o~~  @imo@ @~d ~~@ a@u Ss f~~~ ~~f~@@~M@@@ ~~@ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    if-eqz p1, :cond_1

    const/4 v0, 0x3

    move v1, v0

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iget-object p1, p0, Landroidx/core/content/q$a;->c:Landroidx/core/content/q;

    const/4 v1, 0x7

    iget-object p1, p1, Landroidx/core/content/q;->b:Landroidx/concurrent/futures/e;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p2, 0x3

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-object p1, p0, Landroidx/core/content/q$a;->c:Landroidx/core/content/q;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p1, p1, Landroidx/core/content/q;->b:Landroidx/concurrent/futures/e;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p2, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-virtual {p1, p2}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p1, p0, Landroidx/core/content/q$a;->c:Landroidx/core/content/q;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iget-object p1, p1, Landroidx/core/content/q;->b:Landroidx/concurrent/futures/e;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x6

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    const-string p1, "PackageManagerCompat"

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string/jumbo p2, "kiomvseeatooepn sm seotrt e ir lnrertratgittn fUccbe bs oiarethnom phi"

    const-string/jumbo p2, "ips oth geiineh ocsprUrboel omiset i voear r tt tmftrevotreacsnbatknen"

    const/4 v1, 0x0

    const-string/jumbo p2, "ptironbfe ttetmgrU teio rbceanvrshipveaosokoteiielorc renoe tn as ht  "

    const-string p2, "Unable to retrieve the permission revocation setting from the backport"

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
