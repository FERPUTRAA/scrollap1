.class public final Landroidx/core/content/g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/g$a;
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Landroid/content/LocusId;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "spsenc onydmbtet i"

    const-string/jumbo v0, "mesyaocbtnnedp i t"

    const/4 v3, 0x4

    const-string v0, "an myciedbo p etnm"

    const-string/jumbo v0, "id cannot be empty"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, v0}, Landroidx/core/util/q;->q(Ljava/lang/CharSequence;Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    iput-object v0, p0, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/16 v1, 0x1d

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1}, Landroidx/core/content/g$a;->a(Ljava/lang/String;)Landroid/content/LocusId;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/core/content/g;->b:Landroid/content/LocusId;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    const/4 p1, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object p1, p0, Landroidx/core/content/g;->b:Landroid/content/LocusId;

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method private b()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-c@ooi~41f~n  o@o~~S@/ @  @@bb .~~~@/v~@@fotm@@~ @ r~ ~K~~ ~~@l @l ~oMuy~ @@i@d~~ts@oa ~~b i ~@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string/jumbo v0, "mch_sb"

    const-string/jumbo v0, "s_amch"

    const/4 v3, 0x3

    const-string/jumbo v0, "uarc_h"

    const-string v0, "_chars"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public static d(Landroid/content/LocusId;)Landroidx/core/content/g;
    .locals 4
    .param p0    # Landroid/content/LocusId;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1d
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, "anbIltlp culeudc nn os"

    const-string/jumbo v0, "oun occd ubtnlIla seln"

    const/4 v3, 0x7

    const-string v0, "anoll buqtoldn enccuI "

    const-string/jumbo v0, "locusId cannot be null"

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0}, Landroidx/core/util/q;->m(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    move v3, v2

    new-instance v0, Landroidx/core/content/g;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p0}, Landroidx/core/content/g$a;->b(Landroid/content/LocusId;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "n se pceybo ttinad"

    const-string/jumbo v1, "tcyneb dntmpioa  e"

    const/4 v3, 0x5

    const-string/jumbo v1, "tptmdyo n eben ica"

    const-string/jumbo v1, "id cannot be empty"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0, v1}, Landroidx/core/util/q;->q(Ljava/lang/CharSequence;Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast p0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {v0, p0}, Landroidx/core/content/g;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    and-int/2addr v3, v2

    return-object v0
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v2, 0x2

    return-object v0
.end method

.method public c()Landroid/content/LocusId;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x1d
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Landroidx/core/content/g;->b:Landroid/content/LocusId;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-ne p0, p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez p1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-class v2, Landroidx/core/content/g;

    const-class v2, Landroidx/core/content/g;

    const/4 v5, 0x1

    const-class v2, Landroidx/core/content/g;

    const-class v2, Landroidx/core/content/g;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eq v2, v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    return v1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast p1, Landroidx/core/content/g;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v2, p0, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v2, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p1, p1, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez p1, :cond_3

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    move v0, v1

    const/4 v5, 0x5

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x3

    return v0

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object p1, p1, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v5, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return p1
.end method

.method public hashCode()I
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/content/g;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/16 v1, 0x1f

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "ooIsoLd[mupact"

    const-string/jumbo v1, "oaCscLup[tomdI"

    const/4 v3, 0x4

    const-string/jumbo v1, "osc[pbuaotdLCI"

    const-string v1, "LocusIdCompat["

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Landroidx/core/content/g;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method
