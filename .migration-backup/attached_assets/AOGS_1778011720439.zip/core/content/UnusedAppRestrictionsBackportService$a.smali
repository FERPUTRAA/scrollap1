.class Landroidx/core/content/UnusedAppRestrictionsBackportService$a;
.super Landroidx/core/app/unusedapprestrictions/b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/UnusedAppRestrictionsBackportService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic c:Landroidx/core/content/UnusedAppRestrictionsBackportService;


# direct methods
.method constructor <init>(Landroidx/core/content/UnusedAppRestrictionsBackportService;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/content/UnusedAppRestrictionsBackportService$a;->c:Landroidx/core/content/UnusedAppRestrictionsBackportService;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Landroidx/core/app/unusedapprestrictions/b$b;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public P(Landroidx/core/app/unusedapprestrictions/a;)V
    .locals 3
    .param p1    # Landroidx/core/app/unusedapprestrictions/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ sMm~f@@~v@y ~/@Kt~  b~@bobc ~~@r@t-~.4@ @l~ ~1f~@@lo@o@u~ii~a ~~   iS@o ~  sd@o@ @~ o@ @~n~@/~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Landroidx/core/content/p;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Landroidx/core/content/p;-><init>(Landroidx/core/app/unusedapprestrictions/a;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/core/content/UnusedAppRestrictionsBackportService$a;->c:Landroidx/core/content/UnusedAppRestrictionsBackportService;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroidx/core/content/UnusedAppRestrictionsBackportService;->a(Landroidx/core/content/p;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method
