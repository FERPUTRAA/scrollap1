.class public Landroidx/core/content/FileProvider;
.super Landroid/content/ContentProvider;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/FileProvider$a;,
        Landroidx/core/content/FileProvider$c;,
        Landroidx/core/content/FileProvider$b;
    }
.end annotation


# static fields
.field private static final c:[Ljava/lang/String;

.field private static final d:Ljava/lang/String; = "android.support.FILE_PROVIDER_PATHS"

.field private static final e:Ljava/lang/String; = "root-path"

.field private static final f:Ljava/lang/String; = "files-path"

.field private static final g:Ljava/lang/String; = "cache-path"

.field private static final h:Ljava/lang/String; = "external-path"

.field private static final i:Ljava/lang/String; = "external-files-path"

.field private static final j:Ljava/lang/String; = "external-cache-path"

.field private static final k:Ljava/lang/String; = "external-media-path"

.field private static final l:Ljava/lang/String; = "name"

.field private static final m:Ljava/lang/String; = "path"

.field private static final n:Ljava/lang/String; = "displayName"

.field private static final o:Ljava/io/File;

.field private static final p:Ljava/util/HashMap;
    .annotation build Landroidx/annotation/b0;
        value = "sCache"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Landroidx/core/content/FileProvider$b;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private a:Landroidx/core/content/FileProvider$b;

.field private b:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v0, "yls_iesps_daa"

    const-string/jumbo v0, "lys_iaa_epmds"

    const/4 v3, 0x3

    const-string/jumbo v0, "s_amnped_lyma"

    const-string v0, "_display_name"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v1, "sz_eo"

    const-string v1, "_esmz"

    const/4 v3, 0x3

    const-string v1, "bi_zs"

    const-string v1, "_size"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    sput-object v0, Landroidx/core/content/FileProvider;->c:[Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    new-instance v0, Ljava/io/File;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "/"

    const-string v1, "/"

    const/4 v3, 0x4

    const-string v1, "/"

    const-string v1, "/"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    sput-object v0, Landroidx/core/content/FileProvider;->o:Ljava/io/File;

    const/4 v3, 0x0

    const/4 v2, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    sput-object v0, Landroidx/core/content/FileProvider;->p:Ljava/util/HashMap;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput v0, p0, Landroidx/core/content/FileProvider;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method protected constructor <init>(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/m1;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Landroidx/core/content/FileProvider;->b:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private static varargs a(Ljava/io/File;[Ljava/lang/String;)Ljava/io/File;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ o@@/uir ~  c@o~M~@n   b~ob~~@@@~li~~y~@@S @ @~d f@~~~o a@ @  i@t~v 1t~~~mu lb~@sKfo/@-o@. ~~4@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    array-length v0, p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ge v1, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    aget-object v2, p1, v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    new-instance v3, Ljava/io/File;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v3, p0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object p0, v3

    move-object p0, v3

    move-object p0, v3

    move-object p0, v3

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    return-object p0
.end method

.method private static b([Ljava/lang/Object;I)[Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-array v0, p1, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method

.method private static c([Ljava/lang/String;I)[Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-array v0, p1, [Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x7

    return-object v0
.end method

.method static d(Landroid/content/Context;Ljava/lang/String;Landroid/content/pm/ProviderInfo;I)Landroid/content/res/XmlResourceParser;
    .locals 4
    .param p2    # Landroid/content/pm/ProviderInfo;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p2, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p1, p2, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;

    const/4 v3, 0x3

    const-string/jumbo v0, "oR__urHpOFLorp..TIEiRESdDPaVPodtsIp"

    const-string v0, "TpasoEI_tOSpu.iErAPLHooFRDrI_d.RdVP"

    const/4 v3, 0x3

    const-string v0, "ap_RD_dHqooAV.rLFStIuITEpdOrsPEniP."

    const-string v0, "android.support.FILE_PROVIDER_PATHS"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p3, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance p1, Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p1, v1}, Landroid/os/Bundle;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object p1, p2, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v0, p3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, p0, v0}, Landroid/content/pm/PackageItemInfo;->loadXmlMetaData(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/res/XmlResourceParser;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo p1, "tasaniPRobrSEoitMHdimAF-sOnaVuT .gs Ipse.rLDdRp_IdEaP"

    const-string p1, "asmRDbii_gorAOT_ ntaor E.eRnaiaIPsMIEPds.udHLtpdS-VpF"

    const-string p1, "Missing android.support.FILE_PROVIDER_PATHS meta-data"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    throw p0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p3, "rramtdiafnid/tief u tniutClaa dd-oeyp u rho/vo rtomw "

    const-string p3, " v rdiuritaefyhmeiauwdra/t rfadlioCpt-  uond hon/ tot"

    const/4 v3, 0x4

    const-string p3, "aaooofh vCu frdpitor/r -eiytm  wilred id /nhntaaotudt"

    const-string p3, "Couldn\'t find meta-data for provider with authority "

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p0
.end method

.method private static e(Landroid/content/Context;Ljava/lang/String;I)Landroidx/core/content/FileProvider$b;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Landroidx/core/content/FileProvider;->p:Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v1, Landroidx/core/content/FileProvider$b;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v1, :cond_0

    :try_start_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0, p1, p2}, Landroidx/core/content/FileProvider;->i(Landroid/content/Context;Ljava/lang/String;I)Landroidx/core/content/FileProvider$b;

    move-result-object v1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p2, "d.PRObapatIm PursDt AEodstaSeei_r_pH atenpRadd VoL-aEopFl.irT"

    const-string p2, "e-n.aaIppmdtaPs_ottadoD urSpr_R.TFe dlRdALaEOIat EeoVisp HPri"

    const/4 v3, 0x3

    const-string/jumbo p2, "otaoETu_tR ROrHsFLd-E PdnaI p setSFriVIlApemaPp_uaiearaD.ddt."

    const-string p2, "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p1, p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw p1

    :catch_1
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo p2, "sDqtsoHpadee rRd taEadr_-ttpP Vi_IEpmlTnFou.aPOSarReLiaA po.F"

    const-string/jumbo p2, "tS F.aAEqRnrVPetmDuo.IdHI_pTapRateOaris-FL rdaaEdtoepoP _ isl"

    const/4 v3, 0x1

    const-string/jumbo p2, "stTlRttIqFdD.rpaa__SeaEr Ainu aoLe-ROsVopPdemdoFPEpir.datIH  "

    const-string p2, "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data"

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-direct {p1, p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p1

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw p0
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/io/File;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x0

    const/4 v2, 0x5

    move v1, v0

    const/4 v2, 0x6

    invoke-static {p0, p1, v0}, Landroidx/core/content/FileProvider;->e(Landroid/content/Context;Ljava/lang/String;I)Landroidx/core/content/FileProvider$b;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p0, p2}, Landroidx/core/content/FileProvider$b;->a(Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public static g(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)Landroid/net/Uri;
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/io/File;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "StreamFiles"
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Landroidx/core/content/FileProvider;->f(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const-string/jumbo p1, "lssaiedyaNs"

    const-string p1, "essapialydN"

    const/4 v1, 0x5

    const-string/jumbo p1, "meNmlysiaad"

    const-string p1, "displayName"

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-object p0
.end method

.method private static h(Ljava/lang/String;)I
    .locals 5

    const/4 v4, 0x3

    const-string/jumbo v0, "r"

    const-string/jumbo v0, "r"

    const/4 v4, 0x5

    const-string/jumbo v0, "r"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/high16 p0, 0x10000000

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "w"

    const-string/jumbo v0, "w"

    const/4 v4, 0x2

    const-string/jumbo v0, "w"

    const-string/jumbo v0, "w"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v0, "wt"

    const-string/jumbo v0, "wt"

    const/4 v4, 0x1

    const-string/jumbo v0, "tw"

    const-string/jumbo v0, "wt"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v0, "aw"

    const-string/jumbo v0, "wa"

    const/4 v4, 0x5

    const-string v0, "aw"

    const-string/jumbo v0, "wa"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/high16 p0, 0x2a000000

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto/16 :goto_1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v0, "rw"

    const-string/jumbo v0, "rw"

    const/4 v4, 0x6

    const-string/jumbo v0, "wr"

    const-string/jumbo v0, "rw"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/high16 p0, 0x38000000

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v0, "wtr"

    const-string/jumbo v0, "rwt"

    const/4 v4, 0x1

    const-string/jumbo v0, "trw"

    const-string/jumbo v0, "rwt"

    const/4 v4, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/high16 p0, 0x3c000000    # 0.0078125f

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_1

    :cond_4
    const/4 v4, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const-string/jumbo v2, "moaIo:d lnidve"

    const-string v2, "aenmI:dmdvoli "

    const/4 v4, 0x2

    const-string/jumbo v2, "lnomab dd I:ie"

    const-string v2, "Invalid mode: "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    move v4, v3

    throw v0

    :cond_5
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/high16 p0, 0x2c000000

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    return p0
.end method

.method private static i(Landroid/content/Context;Ljava/lang/String;I)Landroidx/core/content/FileProvider$b;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x1

    new-instance v0, Landroidx/core/content/FileProvider$c;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-direct {v0, p1}, Landroidx/core/content/FileProvider$c;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/16 v2, 0x80

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1, p1, v2}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p0, p1, v1, p2}, Landroidx/core/content/FileProvider;->d(Landroid/content/Context;Ljava/lang/String;Landroid/content/pm/ProviderInfo;I)Landroid/content/res/XmlResourceParser;

    move-result-object p1

    :cond_0
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v1, 0x1

    const/4 v7, 0x4

    if-eq p2, v1, :cond_8

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v1, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ne p2, v1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v1, "enma"

    const-string/jumbo v1, "mnae"

    const/4 v7, 0x3

    const-string/jumbo v1, "nmae"

    const-string/jumbo v1, "name"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-interface {p1, v2, v1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v3, "hapt"

    const-string v3, "htap"

    const/4 v7, 0x4

    const-string/jumbo v3, "tpah"

    const-string/jumbo v3, "path"

    const/4 v6, 0x0

    move v7, v6

    invoke-interface {p1, v2, v3}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v4, "-pohtouor"

    const-string/jumbo v4, "ot-ootrph"

    const/4 v7, 0x2

    const-string/jumbo v4, "rptt-aopo"

    const-string/jumbo v4, "root-path"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v4, :cond_1

    const/4 v6, 0x5

    move v7, v6

    sget-object v2, Landroidx/core/content/FileProvider;->o:Ljava/io/File;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v4, "ia-setflqh"

    const-string v4, "files-path"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x6

    if-eqz v4, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto/16 :goto_1

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v4, "-eshpchtab"

    const-string v4, "e-chpbtaah"

    const/4 v7, 0x2

    const-string v4, "ehamahpct-"

    const-string v4, "cache-path"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v4, :cond_3

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x5

    const-string v4, "hlepoattuxenr"

    const-string/jumbo v4, "trlnxtuahpeae"

    const/4 v7, 0x6

    const-string v4, "etenpbxh-latr"

    const-string v4, "external-path"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v4, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto/16 :goto_1

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v4, "ehsnlaut-eftaxie-pr"

    const-string v4, "-eheiexp-atsltafnlr"

    const/4 v7, 0x3

    const-string/jumbo v4, "pl-thnrpaefeaxlis-t"

    const-string v4, "external-files-path"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    if-eqz v4, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p0, v2}, Landroidx/core/content/d;->getExternalFilesDirs(Landroid/content/Context;Ljava/lang/String;)[Ljava/io/File;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    array-length v4, p2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-lez v4, :cond_7

    const/4 v7, 0x2

    aget-object v2, p2, v5

    goto :goto_1

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo v4, "t-hneecaqqaaxpe-rhl"

    const-string/jumbo v4, "tcaeea--qnlhxreptha"

    const/4 v7, 0x6

    const-string v4, "clseerahehn-xatp-ta"

    const-string v4, "external-cache-path"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v4, :cond_6

    const/4 v7, 0x2

    invoke-static {p0}, Landroidx/core/content/d;->getExternalCacheDirs(Landroid/content/Context;)[Ljava/io/File;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    array-length v4, p2

    if-lez v4, :cond_7

    const/4 v6, 0x5

    and-int/2addr v7, v6

    aget-object v2, p2, v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_1

    :cond_6
    const/4 v7, 0x7

    const-string/jumbo v4, "tlnmerixasted-ampa-"

    const-string v4, "atsahtrlexe-impd-an"

    const/4 v7, 0x7

    const-string/jumbo v4, "xpteoiamher--edatla"

    const-string v4, "external-media-path"

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v4, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz p2, :cond_7

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {p0}, Landroidx/core/content/FileProvider$a;->a(Landroid/content/Context;)[Ljava/io/File;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    array-length v4, p2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-lez v4, :cond_7

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    aget-object v2, p2, v5

    :cond_7
    :goto_1
    const/4 v7, 0x6

    if-eqz v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    filled-new-array {v3}, [Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x3

    move v7, v6

    invoke-static {v2, p2}, Landroidx/core/content/FileProvider;->a(Ljava/io/File;[Ljava/lang/String;)Ljava/io/File;

    move-result-object p2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, v1, p2}, Landroidx/core/content/FileProvider$c;->c(Ljava/lang/String;Ljava/io/File;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto/16 :goto_0

    :cond_8
    const/4 v7, 0x1

    const/4 v6, 0x7

    return-object v0
.end method


# virtual methods
.method public attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/pm/ProviderInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Landroid/content/ContentProvider;->attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V

    iget-boolean v0, p2, Landroid/content/pm/ProviderInfo;->exported:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x1

    iget-boolean v0, p2, Landroid/content/pm/ProviderInfo;->grantUriPermissions:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p2, p2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, ";"

    const-string v0, ";"

    const/4 v2, 0x2

    const-string v0, ";"

    const-string v0, ";"

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {p2, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    aget-object p2, p2, v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Landroidx/core/content/FileProvider;->p:Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-enter v0

    :try_start_0
    invoke-virtual {v0, p2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    iget v0, p0, Landroidx/core/content/FileProvider;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1, p2, v0}, Landroidx/core/content/FileProvider;->e(Landroid/content/Context;Ljava/lang/String;I)Landroidx/core/content/FileProvider$b;

    move-result-object p1

    const/4 v1, 0x6

    and-int/2addr v2, v1

    iput-object p1, p0, Landroidx/core/content/FileProvider;->a:Landroidx/core/content/FileProvider$b;

    const/4 v2, 0x3

    const/4 v1, 0x4

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    throw p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/SecurityException;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo p2, "irormbstrrp aetgsossPeidri nvim u m"

    const-string p2, "gtsmrnasieriupr m sirvtusdmeP  ioor"

    const/4 v2, 0x0

    const-string/jumbo p2, "merrsmugPtnpos  tisirr aoudus nervi"

    const-string p2, "Provider must grant uri permissions"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p1, p2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/SecurityException;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string/jumbo p2, "roPod ip eett pxvbrnuterms do"

    const-string p2, "Provider must not be exported"

    const/4 v2, 0x2

    invoke-direct {p1, p2}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    throw p1
.end method

.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p2, p0, Landroidx/core/content/FileProvider;->a:Landroidx/core/content/FileProvider$b;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-interface {p2, p1}, Landroidx/core/content/FileProvider$b;->b(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p1
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .locals 4
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/content/FileProvider;->a:Landroidx/core/content/FileProvider$b;

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Landroidx/core/content/FileProvider$b;->b(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 v1, 0x2e

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ltz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/webkit/MimeTypeMap;->getMimeTypeFromExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo p1, "ore/top-qmcnaettltiposca"

    const-string p1, "/occotnast-plateeiraptom"

    const/4 v3, 0x5

    const-string/jumbo p1, "tisctpton/amapisactol-ee"

    const-string p1, "application/octet-stream"

    const/4 v3, 0x7

    return-object p1
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ContentValues;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    const-string/jumbo p2, "ntlmno bxi eNseaser"

    const-string/jumbo p2, "rNta besnsr xeinleo"

    const/4 v1, 0x3

    const-string/jumbo p2, "xse oltretn Naensoi"

    const-string p2, "No external inserts"

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    throw p1
.end method

.method public onCreate()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public openFile(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnknownNullness"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/FileNotFoundException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/content/FileProvider;->a:Landroidx/core/content/FileProvider$b;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Landroidx/core/content/FileProvider$b;->b(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-static {p2}, Landroidx/core/content/FileProvider;->h(Ljava/lang/String;)I

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, p2}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p1
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .locals 8
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object p3, p0, Landroidx/core/content/FileProvider;->a:Landroidx/core/content/FileProvider$b;

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-interface {p3, p1}, Landroidx/core/content/FileProvider$b;->b(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string p4, "Nluaabieysd"

    const-string p4, "apileauNyds"

    const/4 v7, 0x3

    const-string/jumbo p4, "lNdpayueaim"

    const-string p4, "displayName"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1, p4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object p2, Landroidx/core/content/FileProvider;->c:[Ljava/lang/String;

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    array-length p4, p2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-array p4, p4, [Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    array-length p5, p2

    const/4 v7, 0x4

    const/4 v6, 0x0

    new-array p5, p5, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x1

    array-length v0, p2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ge v1, v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    aget-object v3, p2, v1

    const/4 v7, 0x1

    const-string v4, "eyiadmpps_anl"

    const-string v4, "_display_name"

    const/4 v7, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v5, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    aput-object v4, p4, v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    add-int/lit8 v3, v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez p1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p3}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    aput-object v4, p5, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_2

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v4, "iep_z"

    const/4 v7, 0x7

    const-string v4, "ez_qi"

    const-string v4, "_size"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v3, :cond_3

    const/4 v7, 0x1

    aput-object v4, p4, v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    add-int/lit8 v3, v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p3}, Ljava/io/File;->length()J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    aput-object v4, p5, v2

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    move v2, v3

    const/4 v7, 0x3

    move v2, v3

    move v2, v3

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {p4, v2}, Landroidx/core/content/FileProvider;->c([Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p5, v2}, Landroidx/core/content/FileProvider;->b([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance p3, Landroid/database/MatrixCursor;

    const/4 v6, 0x0

    move v7, v6

    const/4 p4, 0x7

    const/4 p4, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {p3, p1, p4}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;I)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p3, p2}, Landroid/database/MatrixCursor;->addRow([Ljava/lang/Object;)V

    const/4 v7, 0x7

    return-object p3
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ContentValues;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string p2, "e sNeodspa qenruatl"

    const-string/jumbo p2, "teslr e qapoeuxNdna"

    const-string p2, " aump rosenNdtaeetx"

    const-string p2, "No external updates"

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    throw p1
.end method
