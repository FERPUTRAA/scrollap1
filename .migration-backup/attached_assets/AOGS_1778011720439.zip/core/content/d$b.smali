.class Landroidx/core/content/d$b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x13
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static a(Landroid/content/Context;)[Ljava/io/File;
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s~fS~ ~@lb@@ io~/ @~  /a c  -bl@ b o@s4~@~~~dr  @~@~@y~t.@~u~f@~~1~o@ ~@ otn@i@K@om ~oM~ ~ vi~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getExternalCacheDirs()[Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static b(Landroid/content/Context;Ljava/lang/String;)[Ljava/io/File;
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/content/Context;->getExternalFilesDirs(Ljava/lang/String;)[Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method static c(Landroid/content/Context;)[Ljava/io/File;
    .locals 2
    .annotation build Landroidx/annotation/u;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getObbDirs()[Ljava/io/File;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method
