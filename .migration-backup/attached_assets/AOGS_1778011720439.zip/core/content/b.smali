.class public final Landroidx/core/content/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/b$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroidx/core/os/c;)Landroid/database/Cursor;
    .locals 8
    .param p0    # Landroid/content/ContentResolver;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p6    # Landroidx/core/os/c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string/jumbo v7, "~~s/~~ ~@~ o / ~ @@~ ob~4M ~~il~@@.cKS@si~ d ~ou~@f@ n@tarot@lb  @-m~ ~~i@b~@ o@@o~@@~@  @v~@yf "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    if-eqz p6, :cond_0

    :try_start_0
    const/4 v7, 0x4

    invoke-virtual {p6}, Landroidx/core/os/c;->b()Ljava/lang/Object;

    move-result-object p6

    const/4 v7, 0x0

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v7, 0x6

    goto :goto_1

    :cond_0
    const/4 v7, 0x6

    const/4 p6, 0x0

    :goto_0
    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v7, 0x3

    check-cast v6, Landroid/os/CancellationSignal;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v7, 0x1

    invoke-static/range {v0 .. v6}, Landroidx/core/content/b$a;->a(Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/database/Cursor;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    return-object p0

    :goto_1
    const/4 v7, 0x5

    instance-of p1, p0, Landroid/os/OperationCanceledException;

    const/4 v7, 0x4

    if-eqz p1, :cond_1

    const/4 v7, 0x4

    new-instance p0, Landroidx/core/os/w;

    invoke-direct {p0}, Landroidx/core/os/w;-><init>()V

    const/4 v7, 0x2

    throw p0

    :cond_1
    const/4 v7, 0x5

    throw p0
.end method
