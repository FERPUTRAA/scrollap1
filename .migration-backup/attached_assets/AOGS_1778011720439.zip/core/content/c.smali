.class public final Landroidx/core/content/c;
.super Ljava/lang/Object;


# direct methods
.method public static final varargs a([Lkotlin/u0;)Landroid/content/ContentValues;
    .locals 8
    .param p0    # [Lkotlin/u0;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Lkotlin/u0<",
            "Ljava/lang/String;",
            "+",
            "Ljava/lang/Object;",
            ">;)",
            "Landroid/content/ContentValues;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string/jumbo v0, "pairs"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v0, Landroid/content/ContentValues;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    array-length v1, p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v0, v1}, Landroid/content/ContentValues;-><init>(I)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    array-length v1, p0

    const/4 v7, 0x6

    const/4 v2, 0x4

    const/4 v7, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-ge v2, v1, :cond_a

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    aget-object v3, p0, v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x6

    invoke-virtual {v3}, Lkotlin/u0;->a()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v3}, Lkotlin/u0;->b()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-nez v3, :cond_0

    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v4}, Landroid/content/ContentValues;->putNull(Ljava/lang/String;)V

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    instance-of v5, v3, Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v5, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast v3, Ljava/lang/String;

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    instance-of v5, v3, Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v5, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    check-cast v3, Ljava/lang/Integer;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    instance-of v5, v3, Ljava/lang/Long;

    const/4 v7, 0x6

    if-eqz v5, :cond_3

    const/4 v7, 0x0

    check-cast v3, Ljava/lang/Long;

    const/4 v7, 0x3

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_0

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    instance-of v5, v3, Ljava/lang/Boolean;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v5, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    check-cast v3, Ljava/lang/Boolean;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x5

    instance-of v5, v3, Ljava/lang/Float;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v5, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    check-cast v3, Ljava/lang/Float;

    const/4 v7, 0x3

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Float;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto/16 :goto_0

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    instance-of v5, v3, Ljava/lang/Double;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v5, :cond_6

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    check-cast v3, Ljava/lang/Double;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Double;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto/16 :goto_0

    :cond_6
    const/4 v7, 0x3

    const/4 v6, 0x2

    instance-of v5, v3, [B

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v5, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast v3, [B

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const/4 v7, 0x6

    goto/16 :goto_0

    :cond_7
    const/4 v7, 0x7

    instance-of v5, v3, Ljava/lang/Byte;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v5, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast v3, Ljava/lang/Byte;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Byte;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto/16 :goto_0

    :cond_8
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    instance-of v5, v3, Ljava/lang/Short;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v5, :cond_9

    const/4 v7, 0x3

    check-cast v3, Ljava/lang/Short;

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Short;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto/16 :goto_0

    :cond_9
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string v2, "etslg peeavy lIls l"

    const-string v2, "glsl lyeleevIp ata "

    const/4 v7, 0x7

    const-string v2, " e mlvlly palageteI"

    const-string v2, "Illegal value type "

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string/jumbo p0, "m/o o/yek f"

    const-string p0, " e/my of /k"

    const/4 v7, 0x3

    const-string p0, "/ e obkr f/"

    const-string p0, " for key \""

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/16 p0, 0x22

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    throw v0

    :cond_a
    return-object v0
.end method
