.class public final Landroidx/core/content/l;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/l$a;,
        Landroidx/core/content/l$b;
    }
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "PackageManagerCompat"
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "android.intent.action.AUTO_REVOKE_PERMISSIONS"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroid/content/pm/PackageManager;)Z
    .locals 7
    .param p0    # Landroid/content/pm/PackageManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "iMsr~Sb@~l@   i @uo~a@/1@l@~d~@~n@  @b -K~4~ .@~fs@v co ~of~@ /@ @~t~~~~ @ o~t@~~   o~~~@o@ib@@y"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 v3, 0x1e

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-lt v0, v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    move v4, v1

    move v4, v1

    const/4 v6, 0x2

    move v4, v1

    move v4, v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    move v4, v2

    move v4, v2

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ge v0, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    move v0, v1

    move v0, v1

    const/4 v6, 0x4

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    move v0, v2

    move v0, v2

    const/4 v6, 0x7

    move v0, v2

    move v0, v2

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p0}, Landroidx/core/content/l;->b(Landroid/content/pm/PackageManager;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz p0, :cond_2

    const/4 v5, 0x2

    and-int/2addr v6, v5

    move p0, v1

    move p0, v1

    const/4 v6, 0x7

    move p0, v1

    move p0, v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    move p0, v2

    move p0, v2

    const/4 v6, 0x6

    move p0, v2

    move p0, v2

    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v4, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz p0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_3

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    const/4 v6, 0x0

    move v1, v2

    move v1, v2

    :cond_4
    :goto_3
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    return v1
.end method

.method public static b(Landroid/content/pm/PackageManager;)Ljava/lang/String;
    .locals 6
    .param p0    # Landroid/content/pm/PackageManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "siimtIdrENoRS.OE_ntcK.otTOinan.RnOISaEedMP_SA"

    const-string v1, "P.sEME_ianRidRatcIE.reOnISSOi_KSNntAO.dUtoTon"

    const-string/jumbo v1, "naR_oVUnoSaIEOcO.MeiANRoPEdt.TnI_ii.OSrSdtEKt"

    const-string v1, "android.intent.action.AUTO_REVOKE_PERMISSIONS"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v1, "cgempba"

    const-string v1, "cagmpea"

    const/4 v5, 0x4

    const-string v1, "aegpcku"

    const-string/jumbo v1, "package"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v2, "eoepl.opmac"

    const-string/jumbo v2, "o.emolamepc"

    const/4 v5, 0x4

    const-string/jumbo v2, "mealpx.mqec"

    const-string v2, "com.example"

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1, v2, v3}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0, v0, v1}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast v1, Landroid/content/pm/ResolveInfo;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v2, "brsFGoCK.AAnT._EiTisIsPEoNCrIRaINViEdAp_dAOen"

    const-string v2, "Eres.bdNCIin_.RdIEAiTnFoGV_AIiAaEPONGpACroTKs"

    const/4 v5, 0x3

    const-string v2, "KrAm_iIAGGaIEsEPdNTCpimoeVRdE.InO.CTor_FAsAni"

    const-string v2, "android.permission.PACKAGE_VERIFICATION_AGENT"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0, v2, v1}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x7

    return-object v3

    :cond_1
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v3
.end method

.method public static c(Landroid/content/Context;)Lcom/google/common/util/concurrent/o2;
    .locals 9
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Lcom/google/common/util/concurrent/o2<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {}, Landroidx/concurrent/futures/e;->x()Landroidx/concurrent/futures/e;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {p0}, Landroidx/core/os/f0;->a(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string/jumbo v2, "nPraoagaeuCeapcMkogm"

    const-string/jumbo v2, "oPMCaguaeamrknepgcat"

    const-string/jumbo v2, "naeCkbgMmoraeaptgaca"

    const-string v2, "PackageManagerCompat"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-nez v1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, v3}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string p0, " bs diuno ookel iitUee t rpsrdceod"

    const-string/jumbo p0, "o cstl psrdeiot e n  ioUicoreedbdk"

    const/4 v8, 0x7

    const-string p0, "esmlrtnpcd  i oeriide  codU osbokt"

    const-string p0, "User is in locked direct boot mode"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object v0

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v1}, Landroidx/core/content/l;->a(Landroid/content/pm/PackageManager;)Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x2

    if-nez v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 p0, 0x3

    const/4 p0, 0x1

    const/4 v7, 0x7

    move v8, v7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, p0}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    xor-int/2addr v8, v7

    return-object v0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/16 v4, 0x1e

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-ge v1, v4, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v0, v3}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v7, 0x1

    move v8, v7

    const-string p0, "0ge wTioqrbS3qPotlDAKeI var  se"

    const-string p0, "KDeo 0TAqeobwlsvSri Iang e Pr3t"

    const/4 v8, 0x6

    const-string p0, "  sivag eIPoesbte3AoT0S  Krlrwn"

    const-string p0, "Target SDK version below API 30"

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-object v0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v3, 0x4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v5, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/16 v6, 0x1f

    const/4 v8, 0x5

    if-lt v2, v6, :cond_5

    const/4 v8, 0x2

    invoke-static {p0}, Landroidx/core/content/l$a;->a(Landroid/content/Context;)Z

    move-result p0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz p0, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-lt v1, v6, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v3, 0x5

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0, p0}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v7, 0x0

    move v8, v7

    goto :goto_0

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x0

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v0, p0}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x7

    return-object v0

    :cond_5
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ne v2, v4, :cond_7

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p0}, Landroidx/core/content/l$a;->a(Landroid/content/Context;)Z

    move-result p0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eqz p0, :cond_6

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_1

    :cond_6
    const/4 v8, 0x5

    const/4 v7, 0x1

    move v3, v5

    move v3, v5

    const/4 v8, 0x5

    move v3, v5

    move v3, v5

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, p0}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-object v0

    :cond_7
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v1, Landroidx/core/content/q;

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v1, p0}, Landroidx/core/content/q;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance p0, Landroidx/core/content/k;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-direct {p0, v1}, Landroidx/core/content/k;-><init>(Landroidx/core/content/q;)V

    const/4 v8, 0x0

    const/4 v7, 0x2

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, p0, v2}, Landroidx/concurrent/futures/a;->S(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v1, v0}, Landroidx/core/content/q;->a(Landroidx/concurrent/futures/e;)V

    const/4 v7, 0x0

    xor-int/2addr v8, v7

    return-object v0
.end method
