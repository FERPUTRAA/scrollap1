.class public Landroidx/core/content/p;
.super Ljava/lang/Object;


# instance fields
.field private a:Landroidx/core/app/unusedapprestrictions/a;


# direct methods
.method public constructor <init>(Landroidx/core/app/unusedapprestrictions/a;)V
    .locals 2
    .param p1    # Landroidx/core/app/unusedapprestrictions/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput-object p1, p0, Landroidx/core/content/p;->a:Landroidx/core/app/unusedapprestrictions/a;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public a(ZZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "i@sm@ 1i/-uc M~o @@~ b fr /~~sif @o~.@~tb ~  @~~o~ @~b~yd~@@@~@@~ v ~~ t~o@  @@@o@~oS~ @Ka~l~4l@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/core/content/p;->a:Landroidx/core/app/unusedapprestrictions/a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Landroidx/core/app/unusedapprestrictions/a;->w(ZZ)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method
