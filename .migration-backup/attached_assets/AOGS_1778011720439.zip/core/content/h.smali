.class public final Landroidx/core/content/h;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static a(Ljava/lang/String;[Ljava/lang/String;)Ljava/lang/String;
    .locals 8
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "b~s @ @ri~@@oi~~~m c~~ ~l~/~oS d@~ft~-@ y ~@~ . bto s@@ l~~  @K~1~on@u@@@fv 4/~a@@bo @~@ ~~M@o@ "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x5

    if-nez p0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-object v0

    :cond_0
    const/4 v7, 0x4

    const-string v1, "/"

    const-string v1, "/"

    const/4 v7, 0x0

    const-string v1, "/"

    const-string v1, "/"

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    array-length v2, p1

    const/4 v7, 0x6

    const/4 v3, 0x7

    const/4 v7, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ge v3, v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    aget-object v4, p1, v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p0, v5}, Landroidx/core/content/h;->e([Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v5, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object v4

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x3

    return-object v0
.end method

.method public static b([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 8
    .param p0    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez p0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-object v0

    :cond_0
    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string v1, "/"

    const-string v1, "/"

    const/4 v7, 0x6

    const-string v1, "/"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    array-length v2, p0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-ge v3, v2, :cond_2

    const/4 v6, 0x5

    move v7, v6

    aget-object v4, p0, v3

    const/4 v7, 0x4

    invoke-virtual {v4, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v5, p1}, Landroidx/core/content/h;->e([Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v5, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    return-object v4

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object v0
.end method

.method public static c(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x0

    move v1, p0

    move v1, p0

    const/4 v2, 0x0

    return p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "/"

    const-string v0, "/"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1}, Landroidx/core/content/h;->e([Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p0
.end method

.method public static d([Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;
    .locals 8
    .param p0    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v0, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez p0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-array p0, v0, [Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-object p0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v2, "/"

    const-string v2, "/"

    const/4 v7, 0x4

    const-string v2, "/"

    const-string v2, "/"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    array-length v3, p0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-ge v0, v3, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    aget-object v4, p0, v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v5, p1}, Landroidx/core/content/h;->e([Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v5, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-array p0, p0, [Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    check-cast p0, [Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-object p0
.end method

.method private static e([Ljava/lang/String;[Ljava/lang/String;)Z
    .locals 7
    .param p0    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    array-length v0, p1

    const/4 v5, 0x7

    move v6, v5

    const/4 v1, 0x2

    xor-int/2addr v6, v1

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-ne v0, v1, :cond_4

    const/4 v0, 0x0

    move v6, v0

    and-int/2addr v5, v0

    const/4 v6, 0x7

    aget-object v2, p1, v0

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    aget-object v3, p1, v2

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v3, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    array-length v3, p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eq v3, v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    aget-object v1, p1, v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "*"

    const-string v3, "*"

    const/4 v6, 0x5

    const-string v3, "*"

    const-string v3, "*"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    aget-object v1, p1, v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    aget-object v4, p0, v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    aget-object v1, p1, v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-nez v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x5

    aget-object p1, p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    aget-object p0, p0, v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-nez p0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    return v0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    return v2

    :cond_3
    const/4 v6, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string p1, "f -moyEt  l.rapMpsTtteeu spIeb rp Iieotrmtyem.Mleytfy "

    const-string/jumbo p1, "mts pe  u.yT tetlpit Mdertpfobyte-I.pmlfMe yyaerEors I"

    const/4 v6, 0x0

    const-string p1, " dtto efrtpeeooy-rlu yM riy. MyamTteIEfbetl pltIepsm. "

    const-string p1, "Ill-formatted MIME type filter. Type or subtype empty."

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    throw p0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x3

    const-string/jumbo p1, "tareybMIe e mfeblutEtl.I ieM/st t-l. ps emMtpdpryobfu"

    const-string/jumbo p1, "yelms r .pbe ms teet-ufput /IEtMtIeMdei alptylotrfMb."

    const-string/jumbo p1, "t/e.M ui It bfprtlre dasEe -yMtlMyeeI.oselmptt puubyt"

    const-string p1, "Ill-formatted MIME type filter. Must be type/subtype."

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    throw p0
.end method
