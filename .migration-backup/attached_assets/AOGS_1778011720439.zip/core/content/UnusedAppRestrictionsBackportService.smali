.class public abstract Landroidx/core/content/UnusedAppRestrictionsBackportService;
.super Landroid/app/Service;


# static fields
.field public static final b:Ljava/lang/String; = "android.support.unusedapprestrictions.action.CustomUnusedAppRestrictionsBackportService"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field


# instance fields
.field private a:Landroidx/core/app/unusedapprestrictions/b$b;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Landroidx/core/content/UnusedAppRestrictionsBackportService$a;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Landroidx/core/content/UnusedAppRestrictionsBackportService$a;-><init>(Landroidx/core/content/UnusedAppRestrictionsBackportService;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/core/content/UnusedAppRestrictionsBackportService;->a:Landroidx/core/app/unusedapprestrictions/b$b;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method protected abstract a(Landroidx/core/content/p;)V
    .param p1    # Landroidx/core/content/p;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  s dy m@@~c4~i@.~~@loatvo/nb~~@ @ @iof~~~~@~@ @u@ M~~~1~tob~lS@~K @@~@sb-~@   ~/@~@oro @i  f@  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p1, p0, Landroidx/core/content/UnusedAppRestrictionsBackportService;->a:Landroidx/core/app/unusedapprestrictions/b$b;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p1
.end method
