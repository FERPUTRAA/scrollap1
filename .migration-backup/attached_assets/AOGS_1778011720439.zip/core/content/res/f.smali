.class public Landroidx/core/content/res/f;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/res/f$a;,
        Landroidx/core/content/res/f$d;,
        Landroidx/core/content/res/f$e;,
        Landroidx/core/content/res/f$f;,
        Landroidx/core/content/res/f$b;,
        Landroidx/core/content/res/f$c;
    }
.end annotation


# static fields
.field private static final a:I = 0x190

.field private static final b:I = 0x1

.field public static final c:I = 0x0

.field public static final d:I = 0x1

.field public static final e:I = -0x1

.field private static final f:I = 0x1f4


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static a(Landroid/content/res/TypedArray;I)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~si 4@/u ~@~ ~f~  @s~tr  ~ ~MoS  io~@~~ l co ~@ bo@@@@ b~oa.~o@@@@  n@1fK-~m~lt~/@~~v@y~bi@@~~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/res/f$a;->a(Landroid/content/res/TypedArray;I)I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p0
.end method

.method public static b(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$b;
    .locals 5
    .param p0    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eq v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    move v4, v3

    if-eq v0, v2, :cond_0

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    if-ne v0, v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-static {p0, p1}, Landroidx/core/content/res/f;->d(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$b;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v4, 0x0

    const-string p1, "dos srntaaftNgout "

    const/4 v4, 0x2

    const-string p1, " odmftstron aguN a"

    const-string p1, "No start tag found"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    throw p0
.end method

.method public static c(Landroid/content/res/Resources;I)Ljava/util/List;
    .locals 7
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/e;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/res/Resources;",
            "I)",
            "Ljava/util/List<",
            "Ljava/util/List<",
            "[B>;>;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-object p0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->obtainTypedArray(I)Landroid/content/res/TypedArray;

    move-result-object v0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->length()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    return-object p0

    :cond_1
    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v0, v2}, Landroidx/core/content/res/f;->a(Landroid/content/res/TypedArray;I)I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ne v3, v4, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    move p1, v2

    move p1, v2

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->length()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-ge p1, v3, :cond_4

    const/4 v6, 0x6

    invoke-virtual {v0, p1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v3, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, v3}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v3}, Landroidx/core/content/res/f;->h([Ljava/lang/String;)Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {p0}, Landroidx/core/content/res/f;->h([Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    throw p0
.end method

.method private static d(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$b;
    .locals 5
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, "fmano-oflmi"

    const-string/jumbo v2, "ol-mfnitafm"

    const/4 v4, 0x0

    const-string/jumbo v2, "olfiybnt-fa"

    const-string v2, "font-family"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p0, v0, v1, v2}, Lorg/xmlpull/v1/XmlPullParser;->require(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0, p1}, Landroidx/core/content/res/f;->e(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$b;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p0}, Landroidx/core/content/res/f;->g(Lorg/xmlpull/v1/XmlPullParser;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v1
.end method

.method private static e(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$b;
    .locals 11
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {p0}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    sget-object v1, Landroidx/core/R$styleable;->FontFamily:[I

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    sget v1, Landroidx/core/R$styleable;->FontFamily_fontProviderAuthority:I

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    sget v2, Landroidx/core/R$styleable;->FontFamily_fontProviderPackage:I

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    sget v3, Landroidx/core/R$styleable;->FontFamily_fontProviderQuery:I

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    invoke-virtual {v0, v3}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    sget v4, Landroidx/core/R$styleable;->FontFamily_fontProviderCerts:I

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v5, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v0, v4, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    sget v6, Landroidx/core/R$styleable;->FontFamily_fontProviderFetchStrategy:I

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/4 v7, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v6, v7}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    sget v7, Landroidx/core/R$styleable;->FontFamily_fontProviderFetchTimeout:I

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/16 v8, 0x1f4

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0, v7, v8}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    sget v8, Landroidx/core/R$styleable;->FontFamily_fontProviderSystemFontFamily:I

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v8}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz v1, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v2, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-eqz v3, :cond_1

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eq v5, v0, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {p0}, Landroidx/core/content/res/f;->g(Lorg/xmlpull/v1/XmlPullParser;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {p1, v4}, Landroidx/core/content/res/f;->c(Landroid/content/res/Resources;I)Ljava/util/List;

    move-result-object p0

    const/4 v10, 0x6

    new-instance p1, Landroidx/core/content/res/f$f;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    new-instance v0, Landroidx/core/provider/f;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {v0, v1, v2, v3, p0}, Landroidx/core/provider/f;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {p1, v0, v6, v7, v8}, Landroidx/core/content/res/f$f;-><init>(Landroidx/core/provider/f;IILjava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    return-object p1

    :cond_1
    const/4 v9, 0x6

    const/4 v9, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-eq v2, v0, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/4 v3, 0x2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eq v2, v3, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_1

    :cond_2
    const/4 v9, 0x7

    move v10, v9

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const-string v3, "fnto"

    const-string v3, "fton"

    const-string/jumbo v3, "tonf"

    const-string v3, "font"

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-eqz v2, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-static {p0, p1}, Landroidx/core/content/res/f;->f(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$e;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-interface {v1, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    goto :goto_1

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {p0}, Landroidx/core/content/res/f;->g(Lorg/xmlpull/v1/XmlPullParser;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_1

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result p0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-eqz p0, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 p0, 0x0

    const/4 v10, 0x5

    return-object p0

    :cond_5
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance p0, Landroidx/core/content/res/f$d;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    new-array p1, v5, [Landroidx/core/content/res/f$e;

    const/4 v10, 0x1

    const/4 v9, 0x3

    invoke-interface {v1, p1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    check-cast p1, [Landroidx/core/content/res/f$e;

    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {p0, p1}, Landroidx/core/content/res/f$d;-><init>([Landroidx/core/content/res/f$e;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    return-object p0
.end method

.method private static f(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$e;
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {p0}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    sget-object v1, Landroidx/core/R$styleable;->FontFamilyFont:[I

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x2

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_fontWeight:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v1, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_android_fontWeight:I

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    const/16 v1, 0x190

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_fontStyle:I

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-eqz v1, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    goto :goto_1

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_android_fontStyle:I

    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v2, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ne v2, v0, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    move v5, v2

    move v5, v2

    const/4 v10, 0x7

    move v5, v2

    move v5, v2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_2

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    move v5, v1

    move v5, v1

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_ttcIndex:I

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz v2, :cond_3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_3

    :cond_3
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_android_ttcIndex:I

    :goto_3
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    sget v2, Landroidx/core/R$styleable;->FontFamilyFont_fontVariationSettings:I

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz v3, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    goto :goto_4

    :cond_4
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    sget v2, Landroidx/core/R$styleable;->FontFamilyFont_android_fontVariationSettings:I

    :goto_4
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_font:I

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v2

    const/4 v10, 0x7

    const/4 v9, 0x6

    if-eqz v2, :cond_5

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_5

    :cond_5
    const/4 v10, 0x2

    sget v0, Landroidx/core/R$styleable;->FontFamilyFont_android_font:I

    :goto_5
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    :goto_6
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v0, 0x3

    move v10, v0

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    if-eq p1, v0, :cond_6

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {p0}, Landroidx/core/content/res/f;->g(Lorg/xmlpull/v1/XmlPullParser;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    goto :goto_6

    :cond_6
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance p0, Landroidx/core/content/res/f$e;

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-direct/range {v2 .. v8}, Landroidx/core/content/res/f$e;-><init>(Ljava/lang/String;IZLjava/lang/String;II)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    return-object p0
.end method

.method private static g(Lorg/xmlpull/v1/XmlPullParser;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v0, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x1

    :goto_0
    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-lez v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eq v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eq v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method private static h([Ljava/lang/String;)Ljava/util/List;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "[B>;"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x2

    shl-int/2addr v5, v2

    const/4 v6, 0x3

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-ge v3, v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    aget-object v4, p0, v3

    const/4 v6, 0x1

    invoke-static {v4, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-object v0
.end method
