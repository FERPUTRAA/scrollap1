.class public final Landroidx/core/content/res/m;
.super Ljava/lang/Object;


# direct methods
.method private static final a(Landroid/content/res/TypedArray;I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ts~o~o@y~@/ @~f@@@S@~m~@~~4t a n~  o~ @@@~Ko~ ~.@@ ~iuci ~d@of   ~~/@@l@@~rM obv@1@s~i -  ~l~b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const-string/jumbo p1, "tnemi.int  strttne dedebfoAsu"

    const-string p1, "i.sietieutntdAnroefsnt e bd t"

    const-string/jumbo p1, "re.nonet iou ettb deAdntsitif"

    const-string p1, "Attribute not defined in set."

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    throw p0
.end method

.method public static final b(Landroid/content/res/TypedArray;I)Z
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v2, 0x7

    const-string/jumbo v0, "imshtb"

    const-string v0, "i>tmhs"

    const-string/jumbo v0, "uths><"

    const-string v0, "<this>"

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static final c(Landroid/content/res/TypedArray;I)I
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "<p>oih"

    const-string v0, ">siho<"

    const/4 v2, 0x1

    const-string v0, ">iq<sh"

    const-string v0, "<this>"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p0
.end method

.method public static final d(Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "tsshb>"

    const-string/jumbo v0, "s>t<hb"

    const/4 v2, 0x1

    const-string/jumbo v0, "st<m>h"

    const-string v0, "<this>"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo p1, "l.aiotcn eorttotuoaa vAs s rulwe totblr car eo su to"

    const-string/jumbo p1, "t lutlustoro  trstuo iw rstb nAa  aetoovrcaclea.elo "

    const/4 v2, 0x7

    const-string p1, "Attribute value was not a color or color state list."

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw p0
.end method

.method public static final e(Landroid/content/res/TypedArray;I)F
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v2, 0x2

    const-string v0, "hpts>b"

    const-string/jumbo v0, "ip>sth"

    const/4 v2, 0x2

    const-string/jumbo v0, "uhit>s"

    const-string v0, "<this>"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return p0
.end method

.method public static final f(Landroid/content/res/TypedArray;I)I
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "hpi>ts"

    const-string/jumbo v0, "thqis>"

    const/4 v2, 0x5

    const-string v0, ">tqsih"

    const-string v0, "<this>"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v0, 0x0

    move v2, v0

    move v1, v0

    move v1, v0

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p0
.end method

.method public static final g(Landroid/content/res/TypedArray;I)I
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/r;
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, "<hsi>t"

    const-string v0, "<this>"

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return p0
.end method

.method public static final h(Landroid/content/res/TypedArray;I)Landroid/graphics/drawable/Drawable;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "<>smsh"

    const-string v0, "hts>s<"

    const/4 v2, 0x5

    const-string/jumbo v0, "t>hios"

    const-string v0, "<this>"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-static {p0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public static final i(Landroid/content/res/TypedArray;I)F
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v2, 0x6

    const-string v0, "hi<stb"

    const-string v0, "<tsmhi"

    const/4 v2, 0x1

    const-string/jumbo v0, "uihts<"

    const-string v0, "<this>"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p0
.end method

.method public static final j(Landroid/content/res/TypedArray;I)Landroid/graphics/Typeface;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "ip>hto"

    const-string v0, ">tihos"

    const/4 v2, 0x4

    const-string v0, ">iq<st"

    const-string v0, "<this>"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0, p1}, Landroidx/core/content/res/l;->a(Landroid/content/res/TypedArray;I)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-static {p0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public static final k(Landroid/content/res/TypedArray;I)I
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string v0, "bhsi<>"

    const-string/jumbo v0, "t<h>ib"

    const/4 v2, 0x2

    const-string/jumbo v0, "ih>m<s"

    const-string v0, "<this>"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    return p0
.end method

.method public static final l(Landroid/content/res/TypedArray;I)I
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, ">iutos"

    const-string/jumbo v0, "u>tihs"

    const/4 v2, 0x2

    const-string/jumbo v0, "t<i>hb"

    const-string v0, "<this>"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getInteger(II)I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p0
.end method

.method public static final m(Landroid/content/res/TypedArray;I)I
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/c;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo v0, "upi>ht"

    const-string v0, "hps>ti"

    const/4 v2, 0x4

    const-string/jumbo v0, "sp<>ht"

    const-string v0, "<this>"

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p0
.end method

.method public static final n(Landroid/content/res/TypedArray;I)Ljava/lang/String;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "t<qih>"

    const/4 v2, 0x0

    const-string/jumbo v0, "itqs><"

    const-string v0, "<this>"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const-string p1, " ls bct  eeeSuioiotrAdu oottvgerntlra e.nt ccdu"

    const-string p1, "Attribute value could not be coerced to String."

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    throw p0
.end method

.method public static final o(Landroid/content/res/TypedArray;I)[Ljava/lang/CharSequence;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string v0, ">ihmt<"

    const-string v0, "<this>"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->getTextArray(I)[Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string p1, ")eTgosneieA(trrdxtx"

    const-string p1, "drsT)inxgrAe(ettexa"

    const/4 v2, 0x5

    const-string p1, "gtrAeb(iTxtdyaenerx"

    const-string p1, "getTextArray(index)"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final p(Landroid/content/res/TypedArray;I)Ljava/lang/CharSequence;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/g1;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "uih<st"

    const-string v0, "<this>"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-static {p0, p1}, Landroidx/core/content/res/m;->a(Landroid/content/res/TypedArray;I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string p1, "ecuteoqprbmn.euaeat t t neuoh dvcCedtA uobr lSeec cli"

    const-string p1, "ccomuaulct rheSuiunol r e eonotCed.a ebtect qdb veetA"

    const/4 v2, 0x1

    const-string p1, " ttereuuqoeei utaeoteccdan rdtnlroc hqe Clbe.AbcuS  v"

    const-string p1, "Attribute value could not be coerced to CharSequence."

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    throw p0
.end method

.method public static final q(Landroid/content/res/TypedArray;Li8/l;)Ljava/lang/Object;
    .locals 3
    .param p0    # Landroid/content/res/TypedArray;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<R:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/res/TypedArray;",
            "Li8/l<",
            "-",
            "Landroid/content/res/TypedArray;",
            "+TR;>;)TR;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string v0, "<tssi>"

    const-string/jumbo v0, "t<>ios"

    const/4 v2, 0x2

    const-string/jumbo v0, "t>im<h"

    const-string v0, "<this>"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "block"

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p1, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p1
.end method
