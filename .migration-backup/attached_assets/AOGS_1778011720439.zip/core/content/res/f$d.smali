.class public final Landroidx/core/content/res/f$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/content/res/f$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "d"
.end annotation


# instance fields
.field private final a:[Landroidx/core/content/res/f$e;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method public constructor <init>([Landroidx/core/content/res/f$e;)V
    .locals 2
    .param p1    # [Landroidx/core/content/res/f$e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/content/res/f$d;->a:[Landroidx/core/content/res/f$e;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()[Landroidx/core/content/res/f$e;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s ~   ~/~o~@K~ @ so~irc@4 @n~i~@o@ ~tf b~@@ l a @ @uv@oM~@~@~o~~ ~@@-@@  m.@@ob1~S@ft lbd~i~y~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/content/res/f$d;->a:[Landroidx/core/content/res/f$e;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method
