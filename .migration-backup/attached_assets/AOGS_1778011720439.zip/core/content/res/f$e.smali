.class public final Landroidx/core/content/res/f$e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "e"
.end annotation


# instance fields
.field private final a:Ljava/lang/String;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:I

.field private final c:Z

.field private final d:Ljava/lang/String;

.field private final e:I

.field private final f:I


# direct methods
.method public constructor <init>(Ljava/lang/String;IZLjava/lang/String;II)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput-object p1, p0, Landroidx/core/content/res/f$e;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p2, p0, Landroidx/core/content/res/f$e;->b:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-boolean p3, p0, Landroidx/core/content/res/f$e;->c:Z

    const/4 v0, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p4, p0, Landroidx/core/content/res/f$e;->d:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p5, p0, Landroidx/core/content/res/f$e;->e:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p6, p0, Landroidx/core/content/res/f$e;->f:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os oo @@fb f@@@~~/li@~a-~my~@@n@l/tc@@ibt4b@o~~ ~ ~ ~~@@u~~~@@s~~o~S  @ ~v~.MiKo @r  1~ d  @~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/content/res/f$e;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/content/res/f$e;->f:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public c()I
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget v0, p0, Landroidx/core/content/res/f$e;->e:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public d()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/content/res/f$e;->d:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public e()I
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/content/res/f$e;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/core/content/res/f$e;->c:Z

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method
