.class public final synthetic Landroidx/core/content/res/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/core/content/res/i$g;

.field public final synthetic b:Landroid/graphics/Typeface;


# direct methods
.method public synthetic constructor <init>(Landroidx/core/content/res/i$g;Landroid/graphics/Typeface;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/content/res/j;->a:Landroidx/core/content/res/i$g;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p2, p0, Landroidx/core/content/res/j;->b:Landroid/graphics/Typeface;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "i@s4 ~ s ~~nb@@@co@~@i@o ~y  @b@dt@  ~a/f 1~m  ~ @~@b@/@vo ~f~o~.t@~ o@~o-~ S@ Ku~l@~~~~~@ir@~M "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/content/res/j;->a:Landroidx/core/content/res/i$g;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Landroidx/core/content/res/j;->b:Landroid/graphics/Typeface;

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Landroidx/core/content/res/i$g;->b(Landroidx/core/content/res/i$g;Landroid/graphics/Typeface;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method
