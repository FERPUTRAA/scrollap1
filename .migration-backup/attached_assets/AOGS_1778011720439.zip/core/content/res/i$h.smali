.class public final Landroidx/core/content/res/i$h;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "h"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/res/i$h$a;,
        Landroidx/core/content/res/i$h$b;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static a(Landroid/content/res/Resources$Theme;)V
    .locals 4
    .param p0    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "t~s~~ @~~~~4/~Mbc~vo @@~@ @@@ @~@o~/@  ~oblo~1. @ ~i~ om  dftfs@ ~o@n~a~ly  @u -~i@K@r S@@~@ ib~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    const/16 v1, 0x1d

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0}, Landroidx/core/content/res/i$h$b;->a(Landroid/content/res/Resources$Theme;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    invoke-static {p0}, Landroidx/core/content/res/i$h$a;->a(Landroid/content/res/Resources$Theme;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method
