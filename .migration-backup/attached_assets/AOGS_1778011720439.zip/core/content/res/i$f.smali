.class final Landroidx/core/content/res/i$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "f"
.end annotation


# instance fields
.field final a:Landroid/content/res/Resources;

.field final b:Landroid/content/res/Resources$Theme;


# direct methods
.method constructor <init>(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)V
    .locals 2
    .param p1    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/core/content/res/i$f;->a:Landroid/content/res/Resources;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Landroidx/core/content/res/i$f;->b:Landroid/content/res/Resources$Theme;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ne p0, p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz p1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-class v2, Landroidx/core/content/res/i$f;

    const-class v2, Landroidx/core/content/res/i$f;

    const/4 v5, 0x3

    const-class v2, Landroidx/core/content/res/i$f;

    const-class v2, Landroidx/core/content/res/i$f;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v2, v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_1

    :cond_1
    check-cast p1, Landroidx/core/content/res/i$f;

    const/4 v5, 0x2

    const/4 v4, 0x6

    iget-object v2, p0, Landroidx/core/content/res/i$f;->a:Landroid/content/res/Resources;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v3, p1, Landroidx/core/content/res/i$f;->a:Landroid/content/res/Resources;

    const/4 v4, 0x4

    and-int/2addr v5, v4

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_2

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v2, p0, Landroidx/core/content/res/i$f;->b:Landroid/content/res/Resources$Theme;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object p1, p1, Landroidx/core/content/res/i$f;->b:Landroid/content/res/Resources$Theme;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v2, p1}, Landroidx/core/util/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    move v0, v1

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    return v0

    :cond_3
    :goto_1
    const/4 v5, 0x1

    return v1
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x2

    move v4, v0

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Landroidx/core/content/res/i$f;->a:Landroid/content/res/Resources;

    const/4 v4, 0x3

    const/4 v3, 0x5

    aput-object v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Landroidx/core/content/res/i$f;->b:Landroid/content/res/Resources$Theme;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    aput-object v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Landroidx/core/util/l;->b([Ljava/lang/Object;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0
.end method
