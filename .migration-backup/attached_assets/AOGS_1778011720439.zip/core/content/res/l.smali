.class public final synthetic Landroidx/core/content/res/l;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/res/TypedArray;I)Landroid/graphics/Typeface;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b snKr@~@M~4avt@yd cl~@o~  i~ s@bSi@@   @@@o@~~/~~f~.~o~ o@@ @t ~@ l~@-@1~ mo~~@f/b@~~ ~uo  i~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroid/content/res/TypedArray;->getFont(I)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method
