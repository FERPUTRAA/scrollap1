.class public final synthetic Landroidx/core/content/res/k;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/core/content/res/i$g;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Landroidx/core/content/res/i$g;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/core/content/res/k;->a:Landroidx/core/content/res/i$g;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p2, p0, Landroidx/core/content/res/k;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~sM-~@of@~@S~o@ ~ v@o//@ ~~@c~~ dm1t ii@@i@@~y b@lo @ @uo@~    K @~~n@ bt~~~@~.@~~ob~  @fl~s r4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/core/content/res/k;->a:Landroidx/core/content/res/i$g;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, p0, Landroidx/core/content/res/k;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroidx/core/content/res/i$g;->a(Landroidx/core/content/res/i$g;I)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method
