.class public final Landroidx/core/content/res/d;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final d:Ljava/lang/String; = "ComplexColorCompat"


# instance fields
.field private final a:Landroid/graphics/Shader;

.field private final b:Landroid/content/res/ColorStateList;

.field private c:I


# direct methods
.method private constructor <init>(Landroid/graphics/Shader;Landroid/content/res/ColorStateList;I)V
    .locals 2
    .param p3    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/content/res/d;->a:Landroid/graphics/Shader;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Landroidx/core/content/res/d;->b:Landroid/content/res/ColorStateList;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p3, p0, Landroidx/core/content/res/d;->c:I

    const/4 v1, 0x0

    return-void
.end method

.method private static a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroidx/core/content/res/d;
    .locals 6
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v2, 0x2

    if-eq v1, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eq v1, v3, :cond_0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    move v5, v4

    if-ne v1, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->hashCode()I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v2, "aesindgr"

    const-string v2, "gradient"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, "crtmeleo"

    const-string/jumbo v2, "trsecloe"

    const/4 v5, 0x6

    const-string/jumbo v2, "rceooels"

    const-string/jumbo v2, "selector"

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p0, p1, v0, p2}, Landroidx/core/content/res/c;->b(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0}, Landroidx/core/content/res/d;->c(Landroid/content/res/ColorStateList;)Landroidx/core/content/res/d;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string p1, " drpobaturunxgtscollc:ommp pe  e"

    const-string/jumbo p1, "rosm pceuegdmtaopp: xol luc nrot"

    const/4 v5, 0x5

    const-string/jumbo p1, "ltcsgxutn rop:pe oope aucdorul  "

    const-string p1, ": unsupported complex color tag "

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    throw p0

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0, p1, v0, p2}, Landroidx/core/content/res/g;->c(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/Shader;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p0}, Landroidx/core/content/res/d;->d(Landroid/graphics/Shader;)Landroidx/core/content/res/d;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object p0

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string p1, "a duNotp srafognto"

    const-string p1, "  taodoa Nrftosnug"

    const/4 v5, 0x3

    const-string p1, "g Narunaqdsoot ftt"

    const-string p1, "No start tag found"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    throw p0
.end method

.method static b(I)Landroidx/core/content/res/d;
    .locals 4
    .param p0    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v3, 0x0

    const/4 v2, 0x0

    new-instance v0, Landroidx/core/content/res/d;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1, v1, p0}, Landroidx/core/content/res/d;-><init>(Landroid/graphics/Shader;Landroid/content/res/ColorStateList;I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method static c(Landroid/content/res/ColorStateList;)Landroidx/core/content/res/d;
    .locals 5
    .param p0    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Landroidx/core/content/res/d;

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x0

    invoke-direct {v0, v2, p0, v1}, Landroidx/core/content/res/d;-><init>(Landroid/graphics/Shader;Landroid/content/res/ColorStateList;I)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method static d(Landroid/graphics/Shader;)Landroidx/core/content/res/d;
    .locals 5
    .param p0    # Landroid/graphics/Shader;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance v0, Landroidx/core/content/res/d;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0, p0, v1, v2}, Landroidx/core/content/res/d;-><init>(Landroid/graphics/Shader;Landroid/content/res/ColorStateList;I)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public static g(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroidx/core/content/res/d;
    .locals 2
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    :try_start_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Landroidx/core/content/res/d;->a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroidx/core/content/res/d;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0

    :catch_0
    move-exception p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string p1, "CesamrptoCooCxobpl"

    const-string/jumbo p1, "rxommbeCCCoaoppotl"

    const/4 v1, 0x0

    const-string/jumbo p1, "rlompatxpCooCCmolm"

    const-string p1, "ComplexColorCompat"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string/jumbo p2, "itdoxFutelaloei loaCfmp C nlr.e"

    const/4 v1, 0x7

    const-string/jumbo p2, "lodeompa ltCaliieCxn. l rooeoFf"

    const-string p2, "Failed to inflate ComplexColor."

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-object p0
.end method


# virtual methods
.method public e()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Landroidx/core/content/res/d;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public f()Landroid/graphics/Shader;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/content/res/d;->a:Landroid/graphics/Shader;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public h()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/content/res/d;->a:Landroid/graphics/Shader;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public i()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/content/res/d;->a:Landroid/graphics/Shader;

    const/4 v2, 0x3

    const/4 v1, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/content/res/d;->b:Landroid/content/res/ColorStateList;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->isStateful()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public j([I)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroidx/core/content/res/d;->i()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/content/res/d;->b:Landroid/content/res/ColorStateList;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p1, v1}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v0, p0, Landroidx/core/content/res/d;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eq p1, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    iput p1, p0, Landroidx/core/content/res/d;->c:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return p1
.end method

.method public k(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Landroidx/core/content/res/d;->c:I

    return-void
.end method

.method public l()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/core/content/res/d;->h()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Landroidx/core/content/res/d;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method
