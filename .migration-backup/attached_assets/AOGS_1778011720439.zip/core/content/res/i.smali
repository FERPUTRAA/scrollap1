.class public final Landroidx/core/content/res/i;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/res/i$h;,
        Landroidx/core/content/res/i$a;,
        Landroidx/core/content/res/i$b;,
        Landroidx/core/content/res/i$c;,
        Landroidx/core/content/res/i$d;,
        Landroidx/core/content/res/i$g;,
        Landroidx/core/content/res/i$e;,
        Landroidx/core/content/res/i$f;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "ResourcesCompat"

.field private static final b:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal<",
            "Landroid/util/TypedValue;",
            ">;"
        }
    .end annotation
.end field

.field private static final c:Ljava/util/WeakHashMap;
    .annotation build Landroidx/annotation/b0;
        value = "sColorStateCacheLock"
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroidx/core/content/res/i$f;",
            "Landroid/util/SparseArray<",
            "Landroidx/core/content/res/i$e;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final d:Ljava/lang/Object;

.field public static final e:I
    .annotation build Landroidx/annotation/c;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/ThreadLocal;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    const/4 v3, 0x2

    sput-object v0, Landroidx/core/content/res/i;->b:Ljava/lang/ThreadLocal;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/util/WeakHashMap;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput-object v0, Landroidx/core/content/res/i;->c:Ljava/util/WeakHashMap;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    sput-object v0, Landroidx/core/content/res/i;->d:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method private static a(Landroidx/core/content/res/i$f;ILandroid/content/res/ColorStateList;Landroid/content/res/Resources$Theme;)V
    .locals 5
    .param p0    # Landroidx/core/content/res/i$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "Sbs@  ~Mt@i@ c~~~@o@@ ~@s~ @o@f~  yo~@io~~l/  @-~@@/1.@~nm ~b ~4f b ~i uv~ ~~od@ @r~aKl@t~~@@ o@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Landroidx/core/content/res/i;->d:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v1, Landroidx/core/content/res/i;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x2

    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    check-cast v2, Landroid/util/SparseArray;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v2, Landroid/util/SparseArray;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v2}, Landroid/util/SparseArray;-><init>()V

    const/4 v4, 0x6

    invoke-virtual {v1, p0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    new-instance v1, Landroidx/core/content/res/i$e;

    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object p0, p0, Landroidx/core/content/res/i$f;->a:Landroid/content/res/Resources;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-direct {v1, p2, p0, p3}, Landroidx/core/content/res/i$e;-><init>(Landroid/content/res/ColorStateList;Landroid/content/res/Configuration;Landroid/content/res/Resources$Theme;)V

    const/4 v4, 0x0

    invoke-virtual {v2, p1, v1}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    throw p0
.end method

.method public static b(Landroid/content/res/Resources$Theme;)V
    .locals 5
    .param p0    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x2

    sget-object v0, Landroidx/core/content/res/i;->d:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v1, Landroidx/core/content/res/i;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/util/WeakHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    check-cast v2, Landroidx/core/content/res/i$f;

    const/4 v4, 0x4

    const/4 v3, 0x2

    if-eqz v2, :cond_0

    const/4 v3, 0x7

    and-int/2addr v4, v3

    iget-object v2, v2, Landroidx/core/content/res/i$f;->b:Landroid/content/res/Resources$Theme;

    const/4 v4, 0x5

    invoke-virtual {p0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    monitor-exit v0

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p0
.end method

.method private static c(Landroidx/core/content/res/i$f;I)Landroid/content/res/ColorStateList;
    .locals 7
    .param p0    # Landroidx/core/content/res/i$f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v6, 0x4

    sget-object v0, Landroidx/core/content/res/i;->d:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x6

    move v6, v5

    sget-object v1, Landroidx/core/content/res/i;->c:Ljava/util/WeakHashMap;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v1, p0}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v1, Landroid/util/SparseArray;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v1, :cond_3

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-lez v2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v2, Landroidx/core/content/res/i$e;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v3, v2, Landroidx/core/content/res/i$e;->b:Landroid/content/res/Configuration;

    const/4 v5, 0x2

    move v6, v5

    iget-object v4, p0, Landroidx/core/content/res/i$f;->a:Landroid/content/res/Resources;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v4}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Landroid/content/res/Configuration;->equals(Landroid/content/res/Configuration;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object p0, p0, Landroidx/core/content/res/i$f;->b:Landroid/content/res/Resources$Theme;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez p0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget v3, v2, Landroidx/core/content/res/i$e;->c:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v3, :cond_1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz p0, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget v3, v2, Landroidx/core/content/res/i$e;->c:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ne v3, p0, :cond_2

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object p0, v2, Landroidx/core/content/res/i$e;->a:Landroid/content/res/ColorStateList;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    monitor-exit v0

    return-object p0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Landroid/util/SparseArray;->remove(I)V

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 p0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    throw p0
.end method

.method public static d(Landroid/content/Context;I)Landroid/graphics/Typeface;
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/y;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 p0, 0x0

    const/4 v8, 0x3

    xor-int/2addr v9, v8

    return-object p0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    new-instance v2, Landroid/util/TypedValue;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v5, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v6, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v7, 0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    move v1, p1

    move v1, p1

    const/4 v9, 0x5

    move v1, p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static/range {v0 .. v7}, Landroidx/core/content/res/i;->p(Landroid/content/Context;ILandroid/util/TypedValue;ILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    return-object p0
.end method

.method public static e(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)I
    .locals 2
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Landroidx/core/content/res/i$c;->a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method

.method public static f(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    .locals 4
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Landroidx/core/content/res/i$f;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, p0, p2}, Landroidx/core/content/res/i$f;-><init>(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;)V

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, p1}, Landroidx/core/content/res/i;->c(Landroidx/core/content/res/i$f;I)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, p1, p2}, Landroidx/core/content/res/i;->n(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, p1, v1, p2}, Landroidx/core/content/res/i;->a(Landroidx/core/content/res/i$f;ILandroid/content/res/ColorStateList;Landroid/content/res/Resources$Theme;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0, p1, p2}, Landroidx/core/content/res/i$c;->b(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0
.end method

.method public static g(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Landroidx/core/content/res/i$b;->a(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method public static h(Landroid/content/res/Resources;IILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;
    .locals 2
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param
    .param p3    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3}, Landroidx/core/content/res/i$b;->b(Landroid/content/res/Resources;IILandroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public static i(Landroid/content/res/Resources;I)F
    .locals 5
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/q;
        .end annotation
    .end param

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    move v4, v3

    const/16 v1, 0x1d

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-lt v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/res/i$d;->a(Landroid/content/res/Resources;I)F

    move-result p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Landroidx/core/content/res/i;->m()Landroid/util/TypedValue;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget p0, v0, Landroid/util/TypedValue;->type:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-ne p0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/util/TypedValue;->getFloat()F

    move-result p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    return p0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance p0, Landroid/content/res/Resources$NotFoundException;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v2, "se ms#DoIc0u Re"

    const-string/jumbo v2, "u seRI0De#r sco"

    const/4 v4, 0x1

    const-string/jumbo v2, "uIcDo x#se0eor "

    const-string v2, "Resource ID #0x"

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo p1, "ypem0t #x"

    const/4 v4, 0x5

    const-string p1, "0#yxpbt  "

    const-string p1, " type #0x"

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget p1, v0, Landroid/util/TypedValue;->type:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo p1, "ioid suvla  t"

    const-string p1, " is not valid"

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    throw p0
.end method

.method public static j(Landroid/content/Context;I)Landroid/graphics/Typeface;
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/y;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz v0, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 p0, 0x0

    const/4 v9, 0x2

    return-object p0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v2, Landroid/util/TypedValue;

    const/4 v9, 0x5

    const/4 v8, 0x0

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    const/4 v9, 0x3

    const/4 v3, 0x4

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v9, 0x2

    const/4 v4, 0x0

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/4 v5, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v6, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/4 v7, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x6

    const/4 v8, 0x7

    move v1, p1

    move v1, p1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static/range {v0 .. v7}, Landroidx/core/content/res/i;->p(Landroid/content/Context;ILandroid/util/TypedValue;ILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    return-object p0
.end method

.method public static k(Landroid/content/Context;ILandroid/util/TypedValue;ILandroidx/core/content/res/i$g;)Landroid/graphics/Typeface;
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/y;
        .end annotation
    .end param
    .param p2    # Landroid/util/TypedValue;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroidx/core/content/res/i$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x7

    if-eqz v0, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 p0, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x4

    return-object p0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    const/4 v5, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v6, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v7, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    move v1, p1

    move v1, p1

    const/4 v9, 0x5

    move v1, p1

    move v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    move v3, p3

    move v3, p3

    const/4 v9, 0x2

    move v3, p3

    move v3, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static/range {v0 .. v7}, Landroidx/core/content/res/i;->p(Landroid/content/Context;ILandroid/util/TypedValue;ILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    return-object p0
.end method

.method public static l(Landroid/content/Context;ILandroidx/core/content/res/i$g;Landroid/os/Handler;)V
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/y;
        .end annotation
    .end param
    .param p2    # Landroidx/core/content/res/i$g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/os/Handler;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/res/Resources$NotFoundException;
        }
    .end annotation

    const/4 v8, 0x1

    move v9, v8

    invoke-static {p2}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 p0, -0x4

    const/4 v9, 0x5

    invoke-virtual {p2, p0, p3}, Landroidx/core/content/res/i$g;->c(ILandroid/os/Handler;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-void

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance v2, Landroid/util/TypedValue;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v6, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v7, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    move v1, p1

    move v1, p1

    const/4 v9, 0x1

    move v1, p1

    move v1, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static/range {v0 .. v7}, Landroidx/core/content/res/i;->p(Landroid/content/Context;ILandroid/util/TypedValue;ILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-void
.end method

.method private static m()Landroid/util/TypedValue;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Landroidx/core/content/res/i;->b:Ljava/lang/ThreadLocal;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    check-cast v1, Landroid/util/TypedValue;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v1, Landroid/util/TypedValue;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v1}, Landroid/util/TypedValue;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v1
.end method

.method private static n(Landroid/content/res/Resources;ILandroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;
    .locals 4
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, p1}, Landroidx/core/content/res/i;->o(Landroid/content/res/Resources;I)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object p1

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, p1, p2}, Landroidx/core/content/res/c;->a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/content/res/ColorStateList;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0

    :catch_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo p1, "ocpremspCoaRsto"

    const-string/jumbo p1, "tRsoocpCmrseoua"

    const/4 v3, 0x5

    const-string p1, "CopasmsoqRecreu"

    const-string p1, "ResourcesCompat"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string p2, "afst tlosFegmteotn roaoid e eeCietwrnofrthaiSlv,ii lt aLba t "

    const-string p2, "eeF  b wa ttatienlifeikoloo tedotharLgravrm otaelSC ifns t,it"

    const/4 v3, 0x0

    const-string/jumbo p2, "o fm sohaweFt Ctlvtngaittt arioloenedka llL,r af ieriem tioSt"

    const-string p2, "Failed to inflate ColorStateList, leaving it to the framework"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, p2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v1
.end method

.method private static o(Landroid/content/res/Resources;I)Z
    .locals 4
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/n;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {}, Landroidx/core/content/res/i;->m()Landroid/util/TypedValue;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0, v1}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget p0, v0, Landroid/util/TypedValue;->type:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/16 p1, 0x1c

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lt p0, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/16 p1, 0x1f

    const/4 v3, 0x6

    const/4 v2, 0x4

    if-gt p0, p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x0

    move v3, v1

    :goto_0
    return v1
.end method

.method private static p(Landroid/content/Context;ILandroid/util/TypedValue;ILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/TypedValue;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroidx/core/content/res/i$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # Landroid/os/Handler;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v0, 0x1

    move v9, p1

    move v9, p1

    move v9, p1

    move v9, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    invoke-virtual {v1, p1, p2, v0}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move v3, p1

    move v3, p1

    move v4, p3

    move v4, p3

    move v4, p3

    move v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v8, p7

    move/from16 v8, p7

    move/from16 v8, p7

    move/from16 v8, p7

    invoke-static/range {v0 .. v8}, Landroidx/core/content/res/i;->q(Landroid/content/Context;Landroid/content/res/Resources;Landroid/util/TypedValue;IILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;

    move-result-object v0

    if-nez v0, :cond_1

    if-nez p4, :cond_1

    if-eqz p7, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Landroid/content/res/Resources$NotFoundException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "IsnrocFut ooe #u r0e"

    const-string v2, " s Iotu0enFreuDc#r o"

    const-string v2, "Fx0#IbnrDt cu s ooer"

    const-string v2, "Font resource ID #0x"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "e o e ulocitdeevurnprd b"

    const-string v2, "e rldnbpoe. oeviudce r t"

    const-string/jumbo v2, "n .ercrpv oeodu ttl biee"

    const-string v2, " could not be retrieved."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    return-object v0
.end method

.method private static q(Landroid/content/Context;Landroid/content/res/Resources;Landroid/util/TypedValue;IILandroidx/core/content/res/i$g;Landroid/os/Handler;ZZ)Landroid/graphics/Typeface;
    .locals 17
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/TypedValue;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroidx/core/content/res/i$g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p6    # Landroid/os/Handler;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move-object/from16 v1, p2

    move/from16 v4, p3

    move/from16 v4, p3

    move/from16 v4, p3

    move/from16 v4, p3

    move-object/from16 v11, p5

    move-object/from16 v11, p5

    move-object/from16 v12, p6

    move-object/from16 v12, p6

    move-object/from16 v12, p6

    move-object/from16 v12, p6

    const-string/jumbo v13, "umesopCeqsRocrt"

    const-string/jumbo v13, "torseeRoqCucpms"

    const-string v13, "ResourcesCompat"

    iget-object v2, v1, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    if-eqz v2, :cond_b

    invoke-interface {v2}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v14

    const-string v2, "esr/"

    const-string v2, "/esr"

    const-string/jumbo v2, "res/"

    invoke-virtual {v14, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2

    const/4 v15, -0x3

    const/16 v16, 0x0

    if-nez v2, :cond_1

    if-eqz v11, :cond_0

    invoke-virtual {v11, v15, v12}, Landroidx/core/content/res/i$g;->c(ILandroid/os/Handler;)V

    :cond_0
    return-object v16

    :cond_1
    iget v2, v1, Landroid/util/TypedValue;->assetCookie:I

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    invoke-static {v0, v4, v14, v2, v7}, Landroidx/core/graphics/u0;->j(Landroid/content/res/Resources;ILjava/lang/String;II)Landroid/graphics/Typeface;

    move-result-object v2

    if-eqz v2, :cond_3

    if-eqz v11, :cond_2

    invoke-virtual {v11, v2, v12}, Landroidx/core/content/res/i$g;->d(Landroid/graphics/Typeface;Landroid/os/Handler;)V

    :cond_2
    return-object v2

    :cond_3
    if-eqz p8, :cond_4

    return-object v16

    :cond_4
    :try_start_0
    invoke-virtual {v14}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    const-string v3, ".mxl"

    const-string/jumbo v3, "mxl."

    const-string/jumbo v3, "mx.l"

    const-string v3, ".xml"

    invoke-virtual {v2, v3}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_7

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v2

    invoke-static {v2, v0}, Landroidx/core/content/res/f;->b(Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources;)Landroidx/core/content/res/f$b;

    move-result-object v2

    if-nez v2, :cond_6

    const-string v0, "ais-ifadFtlfe iontstg an om df"

    const-string/jumbo v0, "n sftemafalotd gd oFilia-t ifn"

    const-string v0, "  lmenfFtyifi dmaidf-ltoaont a"

    const-string v0, "Failed to find font-family tag"

    invoke-static {v13, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    if-eqz v11, :cond_5

    invoke-virtual {v11, v15, v12}, Landroidx/core/content/res/i$g;->c(ILandroid/os/Handler;)V

    :cond_5
    return-object v16

    :cond_6
    iget v6, v1, Landroid/util/TypedValue;->assetCookie:I

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move/from16 v4, p3

    move/from16 v4, p3

    move-object v5, v14

    move-object v5, v14

    move-object v5, v14

    move-object v5, v14

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    move/from16 v7, p4

    move-object/from16 v8, p5

    move-object/from16 v8, p5

    move-object/from16 v8, p5

    move-object/from16 v8, p5

    move-object/from16 v9, p6

    move-object/from16 v9, p6

    move-object/from16 v9, p6

    move-object/from16 v9, p6

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    move/from16 v10, p7

    invoke-static/range {v1 .. v10}, Landroidx/core/graphics/u0;->e(Landroid/content/Context;Landroidx/core/content/res/f$b;Landroid/content/res/Resources;ILjava/lang/String;IILandroidx/core/content/res/i$g;Landroid/os/Handler;Z)Landroid/graphics/Typeface;

    move-result-object v0

    return-object v0

    :cond_7
    iget v5, v1, Landroid/util/TypedValue;->assetCookie:I

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move/from16 v3, p3

    move/from16 v3, p3

    move-object v4, v14

    move-object v4, v14

    move-object v4, v14

    move-object v4, v14

    move/from16 v6, p4

    move/from16 v6, p4

    move/from16 v6, p4

    move/from16 v6, p4

    invoke-static/range {v1 .. v6}, Landroidx/core/graphics/u0;->g(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;II)Landroid/graphics/Typeface;

    move-result-object v0

    if-eqz v11, :cond_9

    if-eqz v0, :cond_8

    invoke-virtual {v11, v0, v12}, Landroidx/core/content/res/i$g;->d(Landroid/graphics/Typeface;Landroid/os/Handler;)V

    goto :goto_0

    :cond_8
    invoke-virtual {v11, v15, v12}, Landroidx/core/content/res/i$g;->c(ILandroid/os/Handler;)V
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :cond_9
    :goto_0
    return-object v0

    :catch_0
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "rdlsoelmra eueiemrod c aotxF"

    const-string v2, " e mmcer  xlesruaadloteiordF"

    const-string v2, "Failed to read xml resource "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v13, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto :goto_1

    :catch_1
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "sorcebteeFlo u oprl a  esmdix"

    const-string v2, " iaooelecFu ertd  pleorrxs ms"

    const-string v2, "ese xuuarre acmld pieorFlto s"

    const-string v2, "Failed to parse xml resource "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v13, v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    if-eqz v11, :cond_a

    invoke-virtual {v11, v15, v12}, Landroidx/core/content/res/i$g;->c(ILandroid/os/Handler;)V

    :cond_a
    return-object v16

    :cond_b
    new-instance v2, Landroid/content/res/Resources$NotFoundException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "/u cereps/b"

    const-string v5, "c/urRbees /"

    const-string/jumbo v5, "r u/se/eqco"

    const-string v5, "Resource \""

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "(/ /"

    const-string v0, "\" ("

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static/range {p3 .. p3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "uost )anF:  tosin"

    const-string v0, " ants un o Fi:o)t"

    const-string/jumbo v0, "ts mna Fo : o)i t"

    const-string v0, ") is not a Font: "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    throw v2
.end method
