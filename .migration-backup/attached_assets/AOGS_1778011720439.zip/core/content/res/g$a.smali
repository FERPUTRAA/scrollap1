.class final Landroidx/core/content/res/g$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "a"
.end annotation


# instance fields
.field final a:[I

.field final b:[F


# direct methods
.method constructor <init>(II)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    filled-new-array {p1, p2}, [I

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/core/content/res/g$a;->a:[I

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    new-array p1, p1, [F

    const/4 v1, 0x3

    fill-array-data p1, :array_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/core/content/res/g$a;->b:[F

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f800000    # 1.0f
    .end array-data
.end method

.method constructor <init>(III)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    filled-new-array {p1, p2, p3}, [I

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput-object p1, p0, Landroidx/core/content/res/g$a;->a:[I

    const/4 v0, 0x4

    move v1, v0

    const/4 p1, 0x2

    const/4 p1, 0x3

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    new-array p1, p1, [F

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    fill-array-data p1, :array_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/content/res/g$a;->b:[F

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void

    :array_0
    .array-data 4
        0x0
        0x3f000000    # 0.5f
        0x3f800000    # 1.0f
    .end array-data
.end method

.method constructor <init>(Ljava/util/List;Ljava/util/List;)V
    .locals 6
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x3

    new-array v1, v0, [I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object v1, p0, Landroidx/core/content/res/g$a;->a:[I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-array v1, v0, [F

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object v1, p0, Landroidx/core/content/res/g$a;->b:[F

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ge v1, v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v2, p0, Landroidx/core/content/res/g$a;->a:[I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    check-cast v3, Ljava/lang/Integer;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    aput v3, v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Landroidx/core/content/res/g$a;->b:[F

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast v3, Ljava/lang/Float;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    aput v3, v2, v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method
