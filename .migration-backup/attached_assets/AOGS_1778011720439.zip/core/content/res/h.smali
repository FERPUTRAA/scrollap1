.class final Landroidx/core/content/res/h;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public static a([III)[I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "K@s/~~b fi.   @~lfy ii @ @~ S@@~@ d o~~oaM@@~v@bo4  lt~@ @ ~~@~1~ bm~~~ @@@~~@roo/@~~~u~ @s@nc-t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x7

    array-length v1, p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-le v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-array v0, v0, [I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    aput p2, p0, p1

    const/4 v3, 0x1

    return-object p0
.end method

.method public static b([JIJ)[J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    array-length v1, p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-le v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-array v0, v0, [J

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    move v3, v2

    invoke-static {p0, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    aput-wide p2, p0, p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0
.end method

.method public static c([Ljava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;ITT;)[TT;"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    array-length v1, p0

    const/4 v3, 0x5

    if-le v0, v1, :cond_0

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p0, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    aput-object p2, p0, p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object p0
.end method

.method public static d([ZIZ)[Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    array-length v1, p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-le v0, v1, :cond_0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-array v0, v0, [Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0, v1, v0, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p0, v0

    move-object p0, v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    aput-boolean p2, p0, p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p0
.end method

.method public static e(I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-gt p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/16 p0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    mul-int/lit8 p0, p0, 0x2

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p0
.end method

.method public static f([IIII)[I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    array-length v1, p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-gt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 v0, p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    sub-int/2addr p1, p2

    const/4 v3, 0x3

    invoke-static {p0, p2, p0, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    aput p3, p0, p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    new-array p1, p1, [I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-static {p0, v0, p1, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    aput p3, p1, p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    add-int/lit8 p3, p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    array-length v0, p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    sub-int/2addr v0, p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p2, p1, p3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1
.end method

.method public static g([JIIJ)[J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    array-length v1, p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-gt v0, v1, :cond_0

    const/4 v3, 0x3

    add-int/lit8 v0, p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    sub-int/2addr p1, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, p2, p0, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    aput-wide p3, p0, p2

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x3

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-array p1, p1, [J

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0, v0, p1, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    aput-wide p3, p1, p2

    const/4 v3, 0x0

    add-int/lit8 p3, p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    array-length p4, p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    sub-int/2addr p4, p2

    const/4 v2, 0x3

    move v3, v2

    invoke-static {p0, p2, p1, p3, p4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1
.end method

.method public static h([Ljava/lang/Object;IILjava/lang/Object;)[Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;IITT;)[TT;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    add-int/lit8 v0, p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    array-length v1, p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-gt v0, v1, :cond_0

    const/4 v3, 0x4

    add-int/lit8 v0, p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    sub-int/2addr p1, p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p0, p2, p0, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    aput-object p3, p0, p2

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, p1}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast p1, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0, v0, p1, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    aput-object p3, p1, p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    add-int/lit8 p3, p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    array-length v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    sub-int/2addr v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p0, p2, p1, p3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p1
.end method

.method public static i([ZIIZ)[Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/lit8 v0, p1, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x0

    array-length v1, p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-gt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/lit8 v0, p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    sub-int/2addr p1, p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {p0, p2, p0, v0, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    aput-boolean p3, p0, p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Landroidx/core/content/res/h;->e(I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-array p1, p1, [Z

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x0

    xor-int/2addr v2, v0

    const/4 v3, 0x6

    invoke-static {p0, v0, p1, v0, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    aput-boolean p3, p1, p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/lit8 p3, p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    array-length v0, p0

    const/4 v3, 0x3

    sub-int/2addr v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0, p2, p1, p3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p1
.end method
