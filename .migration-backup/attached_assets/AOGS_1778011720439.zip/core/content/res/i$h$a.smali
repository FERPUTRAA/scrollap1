.class Landroidx/core/content/res/i$h$a;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x17
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/i$h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# static fields
.field private static final a:Ljava/lang/Object;

.field private static b:Ljava/lang/reflect/Method;

.field private static c:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Landroidx/core/content/res/i$h$a;->a:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method static a(Landroid/content/res/Resources$Theme;)V
    .locals 8
    .param p0    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "BanUncheckedReflection"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " .s@t@n ~@4d ~~ @@@1b@-S@@ ~@@o~/~Mb ~ baiK@floc ~~t@yl ~ i @@r~s~uf/@~~i   ~~~~ ~ o ~~oo@o~m@v@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    sget-object v0, Landroidx/core/content/res/i$h$a;->a:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-boolean v1, Landroidx/core/content/res/i$h$a;->c:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez v1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v1, 0x1

    :try_start_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-class v3, Landroid/content/res/Resources$Theme;

    const-class v3, Landroid/content/res/Resources$Theme;

    const-class v3, Landroid/content/res/Resources$Theme;

    const-class v3, Landroid/content/res/Resources$Theme;

    const/4 v6, 0x4

    shl-int/2addr v7, v6

    const-string v4, "esamse"

    const-string v4, "easseb"

    const/4 v7, 0x1

    const-string v4, "esbroe"

    const-string/jumbo v4, "rebase"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-array v5, v2, [Ljava/lang/Class;

    const/4 v7, 0x2

    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    sput-object v3, Landroidx/core/content/res/i$h$a;->b:Ljava/lang/reflect/Method;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :catch_0
    move-exception v3

    :try_start_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v4, "ouceebspmtRaoCm"

    const-string v4, "RoCmuosasceeptm"

    const/4 v7, 0x4

    const-string v4, "aseeomusorcRput"

    const-string v4, "ResourcesCompat"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v5, "isvr erpdtem )oe(o adrtteaeeeilo F"

    const-string/jumbo v5, "m ebotdlors)t(eoeriea eierdat e vF"

    const-string v5, "adeetos qoerlhbtdemr(tF iiae) reve"

    const-string v5, "Failed to retrieve rebase() method"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v4, v5, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    sput-boolean v1, Landroidx/core/content/res/i$h$a;->c:Z

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    sget-object v1, Landroidx/core/content/res/i$h$a;->b:Ljava/lang/reflect/Method;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v6, 0x5

    move v7, v6

    if-eqz v1, :cond_1

    :try_start_3
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catch Ljava/lang/IllegalAccessException; {:try_start_3 .. :try_end_3} :catch_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3 .. :try_end_3} :catch_1
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    goto :goto_2

    :catch_1
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x7

    goto :goto_1

    :catch_2
    move-exception p0

    :goto_1
    :try_start_4
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v1, "easpotsmcsoCRur"

    const-string v1, "ResourcesCompat"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v2, " tne b dao tvevl)cihnbkoedeiotiear  reos(Fafemi"

    const-string v2, "Failed to invoke rebase() method via reflection"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {v1, v2, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 p0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    sput-object p0, Landroidx/core/content/res/i$h$a;->b:Ljava/lang/reflect/Method;

    :cond_1
    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    monitor-exit v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw p0
.end method
