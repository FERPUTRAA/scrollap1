.class public final Landroidx/core/content/res/f$f;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/core/content/res/f$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/res/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "f"
.end annotation


# instance fields
.field private final a:Landroidx/core/provider/f;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:I

.field private final c:I

.field private final d:Ljava/lang/String;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroidx/core/provider/f;II)V
    .locals 3
    .param p1    # Landroidx/core/provider/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, p3, v0}, Landroidx/core/content/res/f$f;-><init>(Landroidx/core/provider/f;IILjava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroidx/core/provider/f;IILjava/lang/String;)V
    .locals 2
    .param p1    # Landroidx/core/provider/f;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/core/content/res/f$f;->a:Landroidx/core/provider/f;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p2, p0, Landroidx/core/content/res/f$f;->c:I

    const/4 v1, 0x1

    iput p3, p0, Landroidx/core/content/res/f$f;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p4, p0, Landroidx/core/content/res/f$f;->d:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "cnsov@~/@M~ti  ~fys o@   b@ ~~ ~@o~@i @~~@~-@d~bo~ 4 @@@~tb flK~~~o l1~imu ~ @@@.@@ o/~S@~r@@~~ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Landroidx/core/content/res/f$f;->c:I

    const/4 v2, 0x0

    return v0
.end method

.method public b()Landroidx/core/provider/f;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/content/res/f$f;->a:Landroidx/core/provider/f;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public c()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/content/res/f$f;->d:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Landroidx/core/content/res/f$f;->b:I

    const/4 v2, 0x1

    return v0
.end method
