.class final Landroidx/core/content/res/g;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/res/g$a;
    }
.end annotation


# static fields
.field private static final a:I = 0x0

.field private static final b:I = 0x1

.field private static final c:I = 0x2


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method private static a(Landroidx/core/content/res/g$a;IIZI)Landroidx/core/content/res/g$a;
    .locals 2
    .param p0    # Landroidx/core/content/res/g$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i@slS~~~~~buK  . ~~v1~@lfcyotn~ ~b@- @@b@ ~~ ~ai ~M m @~fd@@ ~ rt~o@@4~@@~o  s~o@i~/@@ @oo@@~/  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    if-eqz p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0

    :cond_0
    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-eqz p3, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    new-instance p0, Landroidx/core/content/res/g$a;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1, p4, p2}, Landroidx/core/content/res/g$a;-><init>(III)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    new-instance p0, Landroidx/core/content/res/g$a;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Landroidx/core/content/res/g$a;-><init>(II)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method static b(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/content/res/Resources$Theme;)Landroid/graphics/Shader;
    .locals 6
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eq v1, v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eq v1, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    if-ne v1, v2, :cond_1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0, p1, v0, p2}, Landroidx/core/content/res/g;->c(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/Shader;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p0

    :cond_1
    const/4 v5, 0x3

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string p1, "doumf nosNargtsta "

    const-string p1, "ausaN rgtfono sd t"

    const/4 v5, 0x7

    const-string/jumbo p1, "tondouotg Nsr a ft"

    const-string p1, "No start tag found"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    throw p0
.end method

.method static c(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/Shader;
    .locals 20
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "aiegmbnd"

    const-string v2, "enimtdag"

    const-string/jumbo v2, "naetriud"

    const-string v2, "gradient"

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3

    sget-object v1, Landroidx/core/R$styleable;->GradientColor:[I

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    invoke-static {v2, v4, v3, v1}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v1

    const-string/jumbo v5, "tpXato"

    const-string/jumbo v5, "tatsoX"

    const-string/jumbo v5, "stqtXr"

    const-string/jumbo v5, "startX"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_startX:I

    const/4 v7, 0x0

    invoke-static {v1, v0, v5, v6, v7}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v9

    const-string/jumbo v5, "trsstY"

    const-string/jumbo v5, "tYstrb"

    const-string v5, "Ystmrt"

    const-string/jumbo v5, "startY"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_startY:I

    invoke-static {v1, v0, v5, v6, v7}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v10

    const-string/jumbo v5, "ndeX"

    const-string v5, "enXd"

    const-string v5, "deXn"

    const-string v5, "endX"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_endX:I

    invoke-static {v1, v0, v5, v6, v7}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v11

    const-string v5, "enYd"

    const-string v5, "dneY"

    const-string v5, "dYen"

    const-string v5, "endY"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_endY:I

    invoke-static {v1, v0, v5, v6, v7}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v12

    const-string/jumbo v5, "nuetore"

    const-string/jumbo v5, "tXrneeu"

    const-string/jumbo v5, "rcteebX"

    const-string v5, "centerX"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_centerX:I

    invoke-static {v1, v0, v5, v6, v7}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v14

    const-string/jumbo v5, "rpentYu"

    const-string/jumbo v5, "pternYe"

    const-string/jumbo v5, "peYtren"

    const-string v5, "centerY"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_centerY:I

    invoke-static {v1, v0, v5, v6, v7}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v15

    const-string/jumbo v5, "ypet"

    const-string/jumbo v5, "pyet"

    const-string/jumbo v5, "teyp"

    const-string/jumbo v5, "type"

    sget v6, Landroidx/core/R$styleable;->GradientColor_android_type:I

    const/4 v8, 0x0

    invoke-static {v1, v0, v5, v6, v8}, Landroidx/core/content/res/n;->k(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v5

    const-string v6, "Ctsoartqqr"

    const-string/jumbo v6, "tltrosaCqr"

    const-string/jumbo v6, "slsCartrto"

    const-string/jumbo v6, "startColor"

    sget v13, Landroidx/core/R$styleable;->GradientColor_android_startColor:I

    invoke-static {v1, v0, v6, v13, v8}, Landroidx/core/content/res/n;->f(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v6

    const-string/jumbo v13, "oCnmerlrcse"

    const-string v13, "eCsletrronc"

    const-string v13, "centerColor"

    invoke-static {v0, v13}, Landroidx/core/content/res/n;->r(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Z

    move-result v7

    sget v2, Landroidx/core/R$styleable;->GradientColor_android_centerColor:I

    invoke-static {v1, v0, v13, v2, v8}, Landroidx/core/content/res/n;->f(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v2

    const-string v13, "Clenomro"

    const-string v13, "eoCmnrlo"

    const-string/jumbo v13, "onCrlbod"

    const-string v13, "endColor"

    sget v3, Landroidx/core/R$styleable;->GradientColor_android_endColor:I

    invoke-static {v1, v0, v13, v3, v8}, Landroidx/core/content/res/n;->f(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v3

    const-string v13, "eltMoeuo"

    const-string/jumbo v13, "oeedoMtl"

    const-string/jumbo v13, "tileMode"

    sget v4, Landroidx/core/R$styleable;->GradientColor_android_tileMode:I

    invoke-static {v1, v0, v13, v4, v8}, Landroidx/core/content/res/n;->k(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I

    move-result v4

    const-string v8, "gniisutpradRda"

    const-string v8, "gradientRadius"

    sget v13, Landroidx/core/R$styleable;->GradientColor_android_gradientRadius:I

    move/from16 v17, v14

    move/from16 v17, v14

    move/from16 v17, v14

    move/from16 v17, v14

    const/4 v14, 0x0

    invoke-static {v1, v0, v8, v13, v14}, Landroidx/core/content/res/n;->j(Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;IF)F

    move-result v8

    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    invoke-static/range {p0 .. p3}, Landroidx/core/content/res/g;->d(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/core/content/res/g$a;

    move-result-object v0

    invoke-static {v0, v6, v3, v7, v2}, Landroidx/core/content/res/g;->a(Landroidx/core/content/res/g$a;IIZI)Landroidx/core/content/res/g$a;

    move-result-object v0

    const/4 v1, 0x1

    if-eq v5, v1, :cond_1

    const/4 v1, 0x2

    if-eq v5, v1, :cond_0

    new-instance v1, Landroid/graphics/LinearGradient;

    iget-object v13, v0, Landroidx/core/content/res/g$a;->a:[I

    iget-object v14, v0, Landroidx/core/content/res/g$a;->b:[F

    invoke-static {v4}, Landroidx/core/content/res/g;->e(I)Landroid/graphics/Shader$TileMode;

    move-result-object v15

    move-object v8, v1

    move-object v8, v1

    invoke-direct/range {v8 .. v15}, Landroid/graphics/LinearGradient;-><init>(FFFF[I[FLandroid/graphics/Shader$TileMode;)V

    return-object v1

    :cond_0
    new-instance v1, Landroid/graphics/SweepGradient;

    iget-object v2, v0, Landroidx/core/content/res/g$a;->a:[I

    iget-object v0, v0, Landroidx/core/content/res/g$a;->b:[F

    move/from16 v3, v17

    move/from16 v3, v17

    move/from16 v3, v17

    move/from16 v3, v17

    invoke-direct {v1, v3, v15, v2, v0}, Landroid/graphics/SweepGradient;-><init>(FF[I[F)V

    return-object v1

    :cond_1
    move/from16 v3, v17

    move/from16 v3, v17

    const/4 v1, 0x0

    cmpg-float v1, v8, v1

    if-lez v1, :cond_2

    new-instance v1, Landroid/graphics/RadialGradient;

    iget-object v2, v0, Landroidx/core/content/res/g$a;->a:[I

    iget-object v0, v0, Landroidx/core/content/res/g$a;->b:[F

    invoke-static {v4}, Landroidx/core/content/res/g;->e(I)Landroid/graphics/Shader$TileMode;

    move-result-object v19

    move-object v13, v1

    move-object v13, v1

    move-object v13, v1

    move-object v13, v1

    move v14, v3

    move v14, v3

    move v14, v3

    move v14, v3

    move/from16 v16, v8

    move/from16 v16, v8

    move/from16 v16, v8

    move/from16 v16, v8

    move-object/from16 v17, v2

    move-object/from16 v17, v2

    move-object/from16 v17, v2

    move-object/from16 v17, v2

    move-object/from16 v18, v0

    move-object/from16 v18, v0

    move-object/from16 v18, v0

    move-object/from16 v18, v0

    invoke-direct/range {v13 .. v19}, Landroid/graphics/RadialGradient;-><init>(FFF[I[FLandroid/graphics/Shader$TileMode;)V

    return-object v1

    :cond_2
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, " dr/dbsa> aglaqaiti is /enaRdbeierraniuerthuteatdi p/rrtgt<ttuy weg/i"

    const-string/jumbo v1, "nayiti /qset q//ptteuabrrage tdiRwra tat <igaei gr/ durieainhdtrlud>e"

    const-string v1, "<gradient> tag requires \'gradientRadius\' attribute with radial type"

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_3
    new-instance v2, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {p1 .. p1}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "nvseii:latug  dirarot  oadgcl"

    const-string v0, "a i: lutdv   gteonlgdrcaroiia"

    const-string/jumbo v0, "ingm cirgo:dl  rtatlva ao dei"

    const-string v0, ": invalid gradient color tag "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v2, v0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v2
.end method

.method private static d(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/core/content/res/g$a;
    .locals 11
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/4 v1, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    add-int/2addr v0, v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance v2, Ljava/util/ArrayList;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/16 v3, 0x14

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    new-instance v4, Ljava/util/ArrayList;

    const/4 v10, 0x0

    const/4 v9, 0x6

    invoke-direct {v4, v3}, Ljava/util/ArrayList;-><init>(I)V

    :cond_0
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eq v3, v1, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x1

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v5

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-ge v5, v0, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-eq v3, v6, :cond_5

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v6, 0x2

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eq v3, v6, :cond_2

    const/4 v9, 0x2

    xor-int/2addr v10, v9

    goto :goto_0

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-gt v5, v0, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string/jumbo v5, "meti"

    const-string/jumbo v5, "item"

    const/4 v10, 0x0

    const-string/jumbo v5, "imte"

    const-string/jumbo v5, "item"

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-nez v3, :cond_3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_0

    :cond_3
    const/4 v10, 0x5

    sget-object v3, Landroidx/core/R$styleable;->GradientColorItem:[I

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {p0, p3, p2, v3}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    sget v5, Landroidx/core/R$styleable;->GradientColorItem_android_color:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v3, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    sget v7, Landroidx/core/R$styleable;->GradientColorItem_android_offset:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v3, v7}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v8

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v6, :cond_4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-eqz v8, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    const/4 v6, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v3, v5, v6}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/4 v6, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v3, v7, v6}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-interface {v4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x6

    const/4 v9, 0x4

    invoke-static {v6}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_4
    const/4 v10, 0x1

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v10, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string p1, "/sai etp/t/r  /ee  aattbuirtr ti t/:feg><a/  r/!tnourqf/emaacolsidote b"

    const/4 v10, 0x2

    const-string/jumbo p1, "sr//o iaeetitrgecet>m/afs/dbot  autr/ to /ieeoat i lbtqau/u</t rarf!: n"

    const-string p1, ": <item> tag requires a \'color\' attribute and a \'offset\' attribute!"

    const/4 v9, 0x4

    move v10, v9

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    throw p0

    :cond_5
    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result p0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-lez p0, :cond_6

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance p0, Landroidx/core/content/res/g$a;

    const/4 v9, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {p0, v4, v2}, Landroidx/core/content/res/g$a;-><init>(Ljava/util/List;Ljava/util/List;)V

    const/4 v10, 0x2

    return-object p0

    :cond_6
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 p0, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-object p0
.end method

.method private static e(I)Landroid/graphics/Shader$TileMode;
    .locals 3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eq p0, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p0, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object p0, Landroid/graphics/Shader$TileMode;->MIRROR:Landroid/graphics/Shader$TileMode;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object p0, Landroid/graphics/Shader$TileMode;->REPEAT:Landroid/graphics/Shader$TileMode;

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    return-object p0
.end method
