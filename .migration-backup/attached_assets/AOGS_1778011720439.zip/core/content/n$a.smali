.class public final Landroidx/core/content/n$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/n;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/n$a$a;
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static b:Landroidx/core/content/n$a;


# instance fields
.field private final a:Landroidx/core/content/n$a$a;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Landroidx/core/content/n$a$a;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0}, Landroidx/core/content/n$a$a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/content/n$a;->a:Landroidx/core/content/n$a$a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public static b()Landroidx/core/content/n$a;
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~@ ~~c~ o~om~ ~S~ io i@ @@ @~t@ta@~ov~ 1i @@~~~~MonK/   ~@ @y@ @~l@/l~~osbd bb.@~r uf ~f@4~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Landroidx/core/content/n$a;->b:Landroidx/core/content/n$a;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Landroidx/core/content/n$a;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Landroidx/core/content/n$a;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    sput-object v0, Landroidx/core/content/n$a;->b:Landroidx/core/content/n$a;

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Landroidx/core/content/n$a;->b:Landroidx/core/content/n$a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object v0
.end method


# virtual methods
.method public a(Landroid/content/SharedPreferences$Editor;)V
    .locals 3
    .param p1    # Landroid/content/SharedPreferences$Editor;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-object v0, p0, Landroidx/core/content/n$a;->a:Landroidx/core/content/n$a$a;

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroidx/core/content/n$a$a;->a(Landroid/content/SharedPreferences$Editor;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method
