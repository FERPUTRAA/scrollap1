.class final Landroidx/core/content/d$i;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "i"
.end annotation


# static fields
.field static final a:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Class<",
            "*>;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    sput-object v0, Landroidx/core/content/d$i;->a:Ljava/util/HashMap;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-class v1, Landroid/telephony/SubscriptionManager;

    const-class v1, Landroid/telephony/SubscriptionManager;

    const/4 v4, 0x4

    const-class v1, Landroid/telephony/SubscriptionManager;

    const-class v1, Landroid/telephony/SubscriptionManager;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-string/jumbo v2, "sss_yuciteheneic_oebssnilptorp"

    const-string/jumbo v2, "tnsts_srepcybiecnseuio_pevihol"

    const/4 v4, 0x2

    const-string/jumbo v2, "tsemvcssppecoybinrtoinrhiee_l_"

    const-string/jumbo v2, "telephony_subscription_service"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-class v1, Landroid/app/usage/UsageStatsManager;

    const-class v1, Landroid/app/usage/UsageStatsManager;

    const-class v1, Landroid/app/usage/UsageStatsManager;

    const-class v1, Landroid/app/usage/UsageStatsManager;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "tteuomgaas"

    const-string/jumbo v2, "taumegtass"

    const-string/jumbo v2, "ugetsbssaa"

    const-string/jumbo v2, "usagestats"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const-class v1, Landroid/appwidget/AppWidgetManager;

    const-class v1, Landroid/appwidget/AppWidgetManager;

    const/4 v4, 0x6

    const-class v1, Landroid/appwidget/AppWidgetManager;

    const-class v1, Landroid/appwidget/AppWidgetManager;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v2, "aewpdtuoi"

    const-string v2, "epdwoatip"

    const/4 v4, 0x7

    const-string v2, "gwipdatpp"

    const-string v2, "appwidget"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-class v1, Landroid/os/BatteryManager;

    const-class v1, Landroid/os/BatteryManager;

    const/4 v4, 0x0

    const-class v1, Landroid/os/BatteryManager;

    const-class v1, Landroid/os/BatteryManager;

    const/4 v3, 0x5

    move v4, v3

    const-string/jumbo v2, "rberaaybqmteag"

    const-string v2, "abargbyaetrtem"

    const/4 v4, 0x7

    const-string/jumbo v2, "ybseeagrrmtnaa"

    const-string v2, "batterymanager"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const-class v1, Landroid/hardware/camera2/CameraManager;

    const-class v1, Landroid/hardware/camera2/CameraManager;

    const/4 v4, 0x1

    const-class v1, Landroid/hardware/camera2/CameraManager;

    const-class v1, Landroid/hardware/camera2/CameraManager;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v2, "uacmre"

    const-string/jumbo v2, "uramce"

    const-string/jumbo v2, "maacoe"

    const-string v2, "camera"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const-class v1, Landroid/app/job/JobScheduler;

    const-class v1, Landroid/app/job/JobScheduler;

    const/4 v4, 0x2

    const-class v1, Landroid/app/job/JobScheduler;

    const-class v1, Landroid/app/job/JobScheduler;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v2, "epjolbbueshd"

    const-string v2, "ehoulcbpdesj"

    const/4 v4, 0x5

    const-string/jumbo v2, "lrcjdeuebhso"

    const-string/jumbo v2, "jobscheduler"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-class v1, Landroid/content/pm/LauncherApps;

    const/4 v4, 0x0

    const-class v1, Landroid/content/pm/LauncherApps;

    const-class v1, Landroid/content/pm/LauncherApps;

    const/4 v4, 0x1

    const-string v2, "aepnsalppuch"

    const-string/jumbo v2, "launcherapps"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-class v1, Landroid/media/projection/MediaProjectionManager;

    const-class v1, Landroid/media/projection/MediaProjectionManager;

    const/4 v4, 0x5

    const-class v1, Landroid/media/projection/MediaProjectionManager;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const-string/jumbo v2, "i_eoianeqropcmdt"

    const-string/jumbo v2, "media_projection"

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const-class v1, Landroid/media/session/MediaSessionManager;

    const-class v1, Landroid/media/session/MediaSessionManager;

    const-class v1, Landroid/media/session/MediaSessionManager;

    const-class v1, Landroid/media/session/MediaSessionManager;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "iosisqae_dsnm"

    const-string/jumbo v2, "osmesa_iqsndi"

    const/4 v4, 0x3

    const-string/jumbo v2, "onsmeisadsime"

    const-string/jumbo v2, "media_session"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-class v1, Landroid/content/RestrictionsManager;

    const-class v1, Landroid/content/RestrictionsManager;

    const/4 v4, 0x1

    const-class v1, Landroid/content/RestrictionsManager;

    const-class v1, Landroid/content/RestrictionsManager;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v2, "ncriotestsos"

    const-string v2, "cisitstonser"

    const/4 v4, 0x6

    const-string/jumbo v2, "neoribrcssti"

    const-string/jumbo v2, "restrictions"

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-class v1, Landroid/telecom/TelecomManager;

    const-class v1, Landroid/telecom/TelecomManager;

    const/4 v4, 0x4

    const-class v1, Landroid/telecom/TelecomManager;

    const-class v1, Landroid/telecom/TelecomManager;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, "clomteu"

    const-string v2, "etcmolm"

    const/4 v4, 0x3

    const-string/jumbo v2, "telecom"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-class v1, Landroid/media/tv/TvInputManager;

    const-class v1, Landroid/media/tv/TvInputManager;

    const/4 v4, 0x1

    const-class v1, Landroid/media/tv/TvInputManager;

    const-class v1, Landroid/media/tv/TvInputManager;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "upotn_ip"

    const-string/jumbo v2, "ut_noipt"

    const/4 v4, 0x4

    const-string/jumbo v2, "quniv_tp"

    const-string/jumbo v2, "tv_input"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-class v1, Landroid/app/AppOpsManager;

    const-class v1, Landroid/app/AppOpsManager;

    const/4 v4, 0x3

    const-class v1, Landroid/app/AppOpsManager;

    const-class v1, Landroid/app/AppOpsManager;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, "aopppb"

    const/4 v4, 0x7

    const-string/jumbo v2, "pasopp"

    const-string v2, "appops"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-class v1, Landroid/view/accessibility/CaptioningManager;

    const-class v1, Landroid/view/accessibility/CaptioningManager;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v2, "ionmutcgnp"

    const-string/jumbo v2, "igtcopunni"

    const/4 v4, 0x5

    const-string v2, "acgionpoit"

    const-string v2, "captioning"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-class v1, Landroid/hardware/ConsumerIrManager;

    const-class v1, Landroid/hardware/ConsumerIrManager;

    const-class v1, Landroid/hardware/ConsumerIrManager;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v2, "ic_nebormrs"

    const-string/jumbo v2, "ncr_meiprso"

    const/4 v4, 0x4

    const-string v2, "_ucorsumnei"

    const-string v2, "consumer_ir"

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const-class v1, Landroid/print/PrintManager;

    const-class v1, Landroid/print/PrintManager;

    const/4 v4, 0x2

    const-class v1, Landroid/print/PrintManager;

    const/4 v4, 0x6

    const-string/jumbo v2, "niprt"

    const-string/jumbo v2, "triqn"

    const/4 v4, 0x5

    const-string/jumbo v2, "inrqt"

    const-string/jumbo v2, "print"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-class v1, Landroid/bluetooth/BluetoothManager;

    const-class v1, Landroid/bluetooth/BluetoothManager;

    const/4 v4, 0x7

    const-class v1, Landroid/bluetooth/BluetoothManager;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "oestbhtos"

    const-string/jumbo v2, "tosbuheot"

    const/4 v4, 0x0

    const-string v2, "huomotteb"

    const-string v2, "bluetooth"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-class v1, Landroid/hardware/display/DisplayManager;

    const/4 v4, 0x3

    const-class v1, Landroid/hardware/display/DisplayManager;

    const-class v1, Landroid/hardware/display/DisplayManager;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v2, "dilmpay"

    const/4 v4, 0x0

    const-string/jumbo v2, "plsyodi"

    const-string v2, "display"

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-class v1, Landroid/os/UserManager;

    const-class v1, Landroid/os/UserManager;

    const/4 v4, 0x1

    const-class v1, Landroid/os/UserManager;

    const-class v1, Landroid/os/UserManager;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const-string/jumbo v2, "urse"

    const-string/jumbo v2, "srue"

    const/4 v4, 0x6

    const-string/jumbo v2, "usre"

    const-string/jumbo v2, "user"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    move v4, v3

    const-class v1, Landroid/hardware/input/InputManager;

    const-class v1, Landroid/hardware/input/InputManager;

    const/4 v4, 0x1

    const-class v1, Landroid/hardware/input/InputManager;

    const-class v1, Landroid/hardware/input/InputManager;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v2, "boinu"

    const-string/jumbo v2, "punio"

    const/4 v4, 0x0

    const-string/jumbo v2, "puuit"

    const-string/jumbo v2, "input"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-class v1, Landroid/media/MediaRouter;

    const/4 v4, 0x4

    const-class v1, Landroid/media/MediaRouter;

    const-class v1, Landroid/media/MediaRouter;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "uarmrtiped_b"

    const-string/jumbo v2, "m_irabderuto"

    const/4 v4, 0x4

    const-string/jumbo v2, "media_router"

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-class v1, Landroid/net/nsd/NsdManager;

    const-class v1, Landroid/net/nsd/NsdManager;

    const/4 v4, 0x6

    const-class v1, Landroid/net/nsd/NsdManager;

    const-class v1, Landroid/net/nsd/NsdManager;

    const/4 v4, 0x1

    const-string/jumbo v2, "sscrevurqdociiev"

    const-string/jumbo v2, "rrivcsuiycsevdoe"

    const/4 v4, 0x7

    const-string/jumbo v2, "iessivcycsdorere"

    const-string/jumbo v2, "servicediscovery"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-class v1, Landroid/view/accessibility/AccessibilityManager;

    const-class v1, Landroid/view/accessibility/AccessibilityManager;

    const-class v1, Landroid/view/accessibility/AccessibilityManager;

    const-class v1, Landroid/view/accessibility/AccessibilityManager;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const-string v2, "bctmyailiepsi"

    const-string/jumbo v2, "itcelsipsyiba"

    const/4 v4, 0x7

    const-string v2, "atlsobciiyiec"

    const-string v2, "accessibility"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v1, Landroid/accounts/AccountManager;

    const-class v1, Landroid/accounts/AccountManager;

    const/4 v4, 0x7

    const-class v1, Landroid/accounts/AccountManager;

    const-class v1, Landroid/accounts/AccountManager;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v2, "oncutba"

    const-string v2, "account"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const-class v1, Landroid/app/ActivityManager;

    const-class v1, Landroid/app/ActivityManager;

    const/4 v4, 0x6

    const-class v1, Landroid/app/ActivityManager;

    const-class v1, Landroid/app/ActivityManager;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v2, "qtayicui"

    const-string/jumbo v2, "qtiiyacv"

    const/4 v4, 0x7

    const-string/jumbo v2, "tacvytip"

    const-string v2, "activity"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-class v1, Landroid/app/AlarmManager;

    const-class v1, Landroid/app/AlarmManager;

    const/4 v4, 0x3

    const-class v1, Landroid/app/AlarmManager;

    const-class v1, Landroid/app/AlarmManager;

    const/4 v4, 0x4

    const-string v2, "asrql"

    const-string/jumbo v2, "mlsra"

    const/4 v4, 0x3

    const-string v2, "aasml"

    const-string v2, "alarm"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-class v1, Landroid/media/AudioManager;

    const-class v1, Landroid/media/AudioManager;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v2, "iouma"

    const-string/jumbo v2, "uaomi"

    const/4 v4, 0x2

    const-string/jumbo v2, "ouaio"

    const-string v2, "audio"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-class v1, Landroid/content/ClipboardManager;

    const-class v1, Landroid/content/ClipboardManager;

    const/4 v4, 0x4

    const-class v1, Landroid/content/ClipboardManager;

    const-class v1, Landroid/content/ClipboardManager;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v2, "abcdrbilo"

    const-string v2, "bprcodali"

    const/4 v4, 0x0

    const-string v2, "apcbdoulr"

    const-string v2, "clipboard"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-class v1, Landroid/net/ConnectivityManager;

    const-class v1, Landroid/net/ConnectivityManager;

    const/4 v4, 0x1

    const-class v1, Landroid/net/ConnectivityManager;

    const-class v1, Landroid/net/ConnectivityManager;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v2, "tbvcniopyiet"

    const-string/jumbo v2, "ttivcbniyceo"

    const/4 v4, 0x7

    const-string/jumbo v2, "octicentqniy"

    const-string v2, "connectivity"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const-class v1, Landroid/app/admin/DevicePolicyManager;

    const-class v1, Landroid/app/admin/DevicePolicyManager;

    const/4 v4, 0x6

    const-class v1, Landroid/app/admin/DevicePolicyManager;

    const-class v1, Landroid/app/admin/DevicePolicyManager;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v2, "leseipovd_ciy"

    const-string v2, "device_policy"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-class v1, Landroid/app/DownloadManager;

    const-class v1, Landroid/app/DownloadManager;

    const/4 v4, 0x6

    const-class v1, Landroid/app/DownloadManager;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "dwnmaulo"

    const-string v2, "dawonoul"

    const/4 v4, 0x7

    const-string/jumbo v2, "wandolod"

    const-string v2, "download"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-class v1, Landroid/os/DropBoxManager;

    const-class v1, Landroid/os/DropBoxManager;

    const/4 v4, 0x4

    const-class v1, Landroid/os/DropBoxManager;

    const-class v1, Landroid/os/DropBoxManager;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v2, "xpodpbo"

    const-string/jumbo v2, "pbpxood"

    const/4 v4, 0x7

    const-string/jumbo v2, "xpdoobu"

    const-string v2, "dropbox"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const-class v1, Landroid/view/inputmethod/InputMethodManager;

    const-class v1, Landroid/view/inputmethod/InputMethodManager;

    const/4 v4, 0x5

    const-class v1, Landroid/view/inputmethod/InputMethodManager;

    const-class v1, Landroid/view/inputmethod/InputMethodManager;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "imtpnd_ptqhe"

    const-string/jumbo v2, "ud_phtneqtmi"

    const/4 v4, 0x5

    const-string v2, "diu_emptqoth"

    const-string/jumbo v2, "input_method"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const-class v1, Landroid/app/KeyguardManager;

    const-class v1, Landroid/app/KeyguardManager;

    const/4 v4, 0x7

    const-class v1, Landroid/app/KeyguardManager;

    const-class v1, Landroid/app/KeyguardManager;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v2, "dksrseug"

    const-string/jumbo v2, "uesdgkra"

    const/4 v4, 0x5

    const-string/jumbo v2, "kudmgear"

    const-string/jumbo v2, "keyguard"

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-class v1, Landroid/view/LayoutInflater;

    const-class v1, Landroid/view/LayoutInflater;

    const/4 v4, 0x7

    const-class v1, Landroid/view/LayoutInflater;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "tafmluro_ayitel"

    const-string/jumbo v2, "nlauo_oytireafl"

    const-string/jumbo v2, "layout_inflater"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-class v1, Landroid/location/LocationManager;

    const-class v1, Landroid/location/LocationManager;

    const/4 v4, 0x5

    const-class v1, Landroid/location/LocationManager;

    const-class v1, Landroid/location/LocationManager;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "otloaboc"

    const-string v2, "alocoiot"

    const-string/jumbo v2, "niootauc"

    const-string/jumbo v2, "location"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-class v1, Landroid/nfc/NfcManager;

    const/4 v4, 0x2

    const-class v1, Landroid/nfc/NfcManager;

    const-class v1, Landroid/nfc/NfcManager;

    const/4 v4, 0x7

    const-string v2, "cfn"

    const-string/jumbo v2, "ncf"

    const/4 v4, 0x7

    const-string v2, "cnf"

    const-string/jumbo v2, "nfc"

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-class v1, Landroid/app/NotificationManager;

    const-class v1, Landroid/app/NotificationManager;

    const/4 v4, 0x0

    const-class v1, Landroid/app/NotificationManager;

    const-class v1, Landroid/app/NotificationManager;

    const-string/jumbo v2, "ofticinpniob"

    const-string/jumbo v2, "nfiocbnoitti"

    const/4 v4, 0x4

    const-string/jumbo v2, "nftoaiciqion"

    const-string/jumbo v2, "notification"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-class v1, Landroid/os/PowerManager;

    const-class v1, Landroid/os/PowerManager;

    const/4 v4, 0x3

    const-class v1, Landroid/os/PowerManager;

    const-class v1, Landroid/os/PowerManager;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, "erswu"

    const-string/jumbo v2, "wuore"

    const/4 v4, 0x3

    const-string/jumbo v2, "orwmp"

    const-string/jumbo v2, "power"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-class v1, Landroid/app/SearchManager;

    const-class v1, Landroid/app/SearchManager;

    const/4 v4, 0x6

    const-class v1, Landroid/app/SearchManager;

    const-class v1, Landroid/app/SearchManager;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v2, "hepaos"

    const-string v2, "apersh"

    const-string/jumbo v2, "rsheab"

    const-string/jumbo v2, "search"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    and-int/2addr v4, v3

    const-class v1, Landroid/hardware/SensorManager;

    const-class v1, Landroid/hardware/SensorManager;

    const/4 v4, 0x0

    const-class v1, Landroid/hardware/SensorManager;

    const-class v1, Landroid/hardware/SensorManager;

    const/4 v4, 0x1

    const-string/jumbo v2, "usensr"

    const-string/jumbo v2, "snqsre"

    const/4 v4, 0x7

    const-string/jumbo v2, "spsone"

    const-string/jumbo v2, "sensor"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-class v1, Landroid/os/storage/StorageManager;

    const-class v1, Landroid/os/storage/StorageManager;

    const-class v1, Landroid/os/storage/StorageManager;

    const-class v1, Landroid/os/storage/StorageManager;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v2, "sqrgosa"

    const-string/jumbo v2, "tssagor"

    const/4 v4, 0x1

    const-string/jumbo v2, "tasreog"

    const-string/jumbo v2, "storage"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const-class v1, Landroid/telephony/TelephonyManager;

    const-class v1, Landroid/telephony/TelephonyManager;

    const/4 v4, 0x7

    const-class v1, Landroid/telephony/TelephonyManager;

    const-class v1, Landroid/telephony/TelephonyManager;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v2, "nmomh"

    const-string v2, "ehnmo"

    const/4 v4, 0x6

    const-string/jumbo v2, "pohno"

    const-string/jumbo v2, "phone"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const-class v1, Landroid/view/textservice/TextServicesManager;

    const-class v1, Landroid/view/textservice/TextServicesManager;

    const/4 v4, 0x2

    const-class v1, Landroid/view/textservice/TextServicesManager;

    const-class v1, Landroid/view/textservice/TextServicesManager;

    const-string/jumbo v2, "sotvtbrixees"

    const-string/jumbo v2, "tstroxsvicee"

    const/4 v4, 0x5

    const-string/jumbo v2, "textservices"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-class v1, Landroid/app/UiModeManager;

    const-class v1, Landroid/app/UiModeManager;

    const/4 v4, 0x3

    const-class v1, Landroid/app/UiModeManager;

    const-class v1, Landroid/app/UiModeManager;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v2, "uimeou"

    const-string/jumbo v2, "uimode"

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-class v1, Landroid/hardware/usb/UsbManager;

    const-class v1, Landroid/hardware/usb/UsbManager;

    const/4 v4, 0x6

    const-class v1, Landroid/hardware/usb/UsbManager;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v2, "ubs"

    const-string v2, "bsu"

    const/4 v4, 0x7

    const-string/jumbo v2, "sbu"

    const-string/jumbo v2, "usb"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-class v1, Landroid/os/Vibrator;

    const-class v1, Landroid/os/Vibrator;

    const/4 v4, 0x5

    const-class v1, Landroid/os/Vibrator;

    const-class v1, Landroid/os/Vibrator;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v2, "rvbbioap"

    const-string/jumbo v2, "ibvrobar"

    const/4 v4, 0x0

    const-string/jumbo v2, "qtrorvia"

    const-string/jumbo v2, "vibrator"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const-class v1, Landroid/app/WallpaperManager;

    const-class v1, Landroid/app/WallpaperManager;

    const/4 v4, 0x4

    const-class v1, Landroid/app/WallpaperManager;

    const-class v1, Landroid/app/WallpaperManager;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const-string/jumbo v2, "ursplaael"

    const-string/jumbo v2, "paallpure"

    const/4 v4, 0x0

    const-string v2, "eaamwlrlp"

    const-string/jumbo v2, "wallpaper"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const-class v1, Landroid/net/wifi/p2p/WifiP2pManager;

    const-class v1, Landroid/net/wifi/p2p/WifiP2pManager;

    const-class v1, Landroid/net/wifi/p2p/WifiP2pManager;

    const-class v1, Landroid/net/wifi/p2p/WifiP2pManager;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v2, "ppifoiw"

    const-string/jumbo v2, "ppfwipi"

    const/4 v4, 0x1

    const-string v2, "fpwiib2"

    const-string/jumbo v2, "wifip2p"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-class v1, Landroid/net/wifi/WifiManager;

    const-class v1, Landroid/net/wifi/WifiManager;

    const/4 v4, 0x0

    const-class v1, Landroid/net/wifi/WifiManager;

    const-class v1, Landroid/net/wifi/WifiManager;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v2, "iifw"

    const-string v2, "fwii"

    const/4 v4, 0x3

    const-string/jumbo v2, "iwif"

    const-string/jumbo v2, "wifi"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-class v1, Landroid/view/WindowManager;

    const-class v1, Landroid/view/WindowManager;

    const/4 v4, 0x0

    const-class v1, Landroid/view/WindowManager;

    const-class v1, Landroid/view/WindowManager;

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v2, "uoiqwd"

    const-string/jumbo v2, "iwqdwo"

    const/4 v4, 0x3

    const-string/jumbo v2, "ipwwnd"

    const-string/jumbo v2, "window"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
