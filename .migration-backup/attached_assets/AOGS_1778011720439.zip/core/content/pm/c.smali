.class public final Landroidx/core/content/pm/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/pm/c$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method private static a([[B[B)Z
    .locals 6
    .param p0    # [[B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~s.@  @oibu~r~@@ y~@~@~o ~~ @@ ~i @i1  o/@~K~ @ 4t@ @~M@md~s@@ o@~l @vnc@~obfS ~b@ /~l~~ oa~f~-"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    array-length v0, p0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    if-ge v2, v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget-object v3, p0, v2

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1, v3}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 p0, 0x1

    const/4 v5, 0x6

    return p0

    :cond_0
    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v1
.end method

.method private static b([B)[B
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "S6sm2H"

    const-string v0, "26sHSA"

    const-string v0, "A25SoH"

    const-string v0, "SHA256"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0

    :catch_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v1, " cc/gb6hcdtoorpeH nAvk5stsSiD /en2 eutepmr i"

    const-string v1, "eerm utno 6csgDSei /t 5roi2ce/p tcHvAphsdnck"

    const/4 v3, 0x6

    const-string v1, "Device doesn\'t support SHA256 cert checking"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0, v1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw v0
.end method

.method public static c(Landroid/content/pm/PackageInfo;)J
    .locals 4
    .param p0    # Landroid/content/pm/PackageInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/16 v1, 0x1c

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-static {p0}, Landroidx/core/content/pm/c$a;->b(Landroid/content/pm/PackageInfo;)J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-wide v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    int-to-long v0, p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-wide v0
.end method

.method public static d(Landroid/content/pm/PackageManager;Ljava/lang/String;)Ljava/util/List;
    .locals 4
    .param p0    # Landroid/content/pm/PackageManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/pm/PackageManager;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Landroid/content/pm/Signature;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/pm/PackageManager$NameNotFoundException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0x1c

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-lt v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/high16 v0, 0x8000000

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0}, Landroidx/core/content/pm/b;->a(Landroid/content/pm/PackageInfo;)Landroid/content/pm/SigningInfo;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-static {p0}, Landroidx/core/content/pm/c$a;->d(Landroid/content/pm/SigningInfo;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/content/pm/c$a;->a(Landroid/content/pm/SigningInfo;)[Landroid/content/pm/Signature;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Landroidx/core/content/pm/c$a;->c(Landroid/content/pm/SigningInfo;)[Landroid/content/pm/Signature;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/16 v0, 0x40

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p0
.end method

.method public static e(Landroid/content/pm/PackageManager;Ljava/lang/String;Ljava/util/Map;Z)Z
    .locals 9
    .param p0    # Landroid/content/pm/PackageManager;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/Map;
        .annotation build Landroidx/annotation/c1;
            min = 0x1L
        .end annotation

        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/pm/PackageManager;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "[B",
            "Ljava/lang/Integer;",
            ">;Z)Z"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/content/pm/PackageManager$NameNotFoundException;
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-interface {p2}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v1, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    return v1

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {p2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string/jumbo v4, "ytieecusort reic tuUetp danfp"

    const-string v4, "Unsupported certificate type "

    const/4 v8, 0x6

    const/4 v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v3, :cond_5

    const/4 v7, 0x6

    shl-int/2addr v8, v7

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    check-cast v3, [B

    const/4 v8, 0x4

    const/4 v7, 0x5

    if-eqz v3, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-interface {p2, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    check-cast v3, Ljava/lang/Integer;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v3, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v6

    const/4 v8, 0x4

    const/4 v7, 0x0

    if-eqz v6, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-ne v6, v5, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto :goto_0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const-string p3, " frneg p eiivwoy"

    const-string p3, "hniwo rifvyee  g"

    const/4 v8, 0x0

    const-string/jumbo p3, "nfveihywq g r ie"

    const-string p3, " when verifying "

    const/4 v8, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    throw p0

    :cond_3
    const/4 v8, 0x4

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string p3, "eysc tdieg inceufernsTrbiyweb mf es thpfr iep  "

    const-string p3, "eicudbeefeprhegbs rs   tmfftnTevi   rwyyicn pei"

    const/4 v8, 0x3

    const-string/jumbo p3, "muimgs fpef oercei  e wy Teevriyb eft pdtishnnc"

    const-string p3, "Type must be specified for cert when verifying "

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    throw p0

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const-string p3, " eC oregarnyea ltahyunu w  ybblnntneveif rorit"

    const-string/jumbo p3, "uyahrnu  tbeenrn agbvnwter lCfre ly ye into ai"

    const/4 v8, 0x4

    const-string p3, " b enb  tl reCnavrhb cnioiyunwetyyln egaferta "

    const-string p3, "Cert byte array cannot be null when verifying "

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    throw p0

    :cond_5
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p0, p1}, Landroidx/core/content/pm/c;->d(Landroid/content/pm/PackageManager;Ljava/lang/String;)Ljava/util/List;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-nez p3, :cond_8

    const/4 v8, 0x1

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/16 v6, 0x1c

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    if-lt v3, v6, :cond_8

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :cond_6
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v0, :cond_7

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast v0, [B

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x7

    check-cast v2, Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p0, p1, v0, v2}, Landroidx/core/content/pm/c$a;->e(Landroid/content/pm/PackageManager;Ljava/lang/String;[BI)Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez v0, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    return v1

    :cond_7
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    return v5

    :cond_8
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz p0, :cond_f

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-interface {p2}, Ljava/util/Map;->size()I

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-gt p0, p1, :cond_f

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-eqz p3, :cond_9

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {p2}, Ljava/util/Map;->size()I

    move-result p0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eq p0, p1, :cond_9

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    goto/16 :goto_2

    :cond_9
    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {p2, p0}, Ljava/util/Map;->containsValue(Ljava/lang/Object;)Z

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz p0, :cond_a

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-array p0, p0, [[B

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    move p1, v1

    move p1, v1

    const/4 v8, 0x0

    move p1, v1

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-ge p1, p3, :cond_b

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {v2, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    check-cast p3, Landroid/content/pm/Signature;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p3}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object p3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {p3}, Landroidx/core/content/pm/c;->b([B)[B

    move-result-object p3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    aput-object p3, p0, p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    add-int/lit8 p1, p1, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_1

    :cond_a
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 p0, 0x0

    :cond_b
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz p3, :cond_f

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    check-cast p1, [B

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    check-cast p2, Ljava/lang/Integer;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz p3, :cond_d

    const/4 v7, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ne p3, v5, :cond_c

    const/4 v7, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-static {p0, p1}, Landroidx/core/content/pm/c;->a([[B[B)Z

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-nez p0, :cond_e

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    return v1

    :cond_c
    const/4 v8, 0x6

    const/4 v7, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    throw p0

    :cond_d
    const/4 v8, 0x1

    const/4 v7, 0x0

    new-instance p0, Landroid/content/pm/Signature;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {p0, p1}, Landroid/content/pm/Signature;-><init>([B)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v2, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-nez p0, :cond_e

    const/4 v7, 0x5

    shr-int/2addr v8, v7

    return v1

    :cond_e
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    return v5

    :cond_f
    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    return v1
.end method
