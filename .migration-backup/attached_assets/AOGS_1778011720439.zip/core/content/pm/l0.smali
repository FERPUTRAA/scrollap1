.class public final synthetic Landroidx/core/content/pm/l0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@osn~@b @ ~~c@~1@  oobv ~M~ @~@ i ifi~S~/~s@t~@ b~l ~~m a@-o@@ ~@~f.@@t~~~~r ~@o/o  @ud@K l@y4~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/pm/ShortcutInfo;->isPinned()Z

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p0
.end method
