.class public final synthetic Landroidx/core/content/pm/b;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/PackageInfo;)Landroid/content/pm/SigningInfo;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "l s  @~~~o~@1 ~~/bm~ .foi@~@tc@ ~@~~r ub@@otbn i/~@d~@ S ~@y~@ M  ~K@~vf s@-  @~~@@o o~@@~oa4@li"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signingInfo:Landroid/content/pm/SigningInfo;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method
