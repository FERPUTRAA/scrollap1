.class public Landroidx/core/content/pm/q0$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/pm/q0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private final a:Landroidx/core/content/pm/q0;

.field private b:Z

.field private c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;>;>;"
        }
    .end annotation
.end field

.field private e:Landroid/net/Uri;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/content/pm/ShortcutInfo;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/pm/ShortcutInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v0, Landroidx/core/content/pm/q0;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Landroidx/core/content/pm/q0;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object p1, v0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p2}, Landroidx/core/content/pm/x;->a(Landroid/content/pm/ShortcutInfo;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object p1, v0, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v4, 0x3

    invoke-static {p2}, Landroidx/core/content/pm/y;->a(Landroid/content/pm/ShortcutInfo;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object p1, v0, Landroidx/core/content/pm/q0;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p2}, Landroidx/core/content/pm/a0;->a(Landroid/content/pm/ShortcutInfo;)[Landroid/content/Intent;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    array-length v1, p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast p1, [Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object p1, v0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p2}, Landroidx/core/content/pm/b0;->a(Landroid/content/pm/ShortcutInfo;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object p1, v0, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p2}, Landroidx/core/content/pm/c0;->a(Landroid/content/pm/ShortcutInfo;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-object p1, v0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p2}, Landroidx/core/content/pm/d0;->a(Landroid/content/pm/ShortcutInfo;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object p1, v0, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p2}, Landroidx/core/content/pm/e0;->a(Landroid/content/pm/ShortcutInfo;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v4, 0x0

    iput-object p1, v0, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/16 v1, 0x1c

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-lt p1, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p2}, Landroidx/core/content/pm/f0;->a(Landroid/content/pm/ShortcutInfo;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput v1, v0, Landroidx/core/content/pm/q0;->A:I

    const/4 v4, 0x2

    goto :goto_1

    :cond_0
    const/4 v4, 0x7

    invoke-static {p2}, Landroidx/core/content/pm/o0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x3

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v1, v0, Landroidx/core/content/pm/q0;->A:I

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p2}, Landroidx/core/content/pm/g0;->a(Landroid/content/pm/ShortcutInfo;)Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v1, v0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p2}, Landroidx/core/content/pm/o;->a(Landroid/content/pm/ShortcutInfo;)Landroid/os/PersistableBundle;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v1}, Landroidx/core/content/pm/q0;->u(Landroid/os/PersistableBundle;)[Landroidx/core/app/f4;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-object v1, v0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p2}, Landroidx/core/content/pm/h0;->a(Landroid/content/pm/ShortcutInfo;)Landroid/os/UserHandle;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v1, v0, Landroidx/core/content/pm/q0;->s:Landroid/os/UserHandle;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p2}, Landroidx/core/content/pm/i0;->a(Landroid/content/pm/ShortcutInfo;)J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-wide v1, v0, Landroidx/core/content/pm/q0;->r:J

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/16 v1, 0x1e

    const/4 v4, 0x3

    if-lt p1, v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p2}, Landroidx/core/content/pm/j0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->t:Z

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p2}, Landroidx/core/content/pm/k0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->u:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p2}, Landroidx/core/content/pm/l0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->v:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-static {p2}, Landroidx/core/content/pm/m0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->w:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p2}, Landroidx/core/content/pm/n0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->x:Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {p2}, Landroidx/core/content/pm/o0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->y:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-static {p2}, Landroidx/core/content/pm/p0;->a(Landroid/content/pm/ShortcutInfo;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->z:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-static {p2}, Landroidx/core/content/pm/q0;->p(Landroid/content/pm/ShortcutInfo;)Landroidx/core/content/g;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    iput-object p1, v0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-static {p2}, Landroidx/core/content/pm/z;->a(Landroid/content/pm/ShortcutInfo;)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput p1, v0, Landroidx/core/content/pm/q0;->o:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p2}, Landroidx/core/content/pm/o;->a(Landroid/content/pm/ShortcutInfo;)Landroid/os/PersistableBundle;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    iput-object p1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Landroidx/core/content/pm/q0;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0}, Landroidx/core/content/pm/q0;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    iput-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v1, 0x7

    and-int/2addr v2, v1

    iput-object p1, v0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p2, v0, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroidx/core/content/pm/q0;)V
    .locals 5
    .param p1    # Landroidx/core/content/pm/q0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Landroidx/core/content/pm/q0;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Landroidx/core/content/pm/q0;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p1, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v1, v0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p1, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v4, 0x5

    iput-object v1, v0, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p1, Landroidx/core/content/pm/q0;->c:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-object v1, v0, Landroidx/core/content/pm/q0;->c:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p1, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    array-length v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast v1, [Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v1, v0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v4, 0x0

    iget-object v1, p1, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v4, 0x5

    const/4 v3, 0x7

    iput-object v1, v0, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p1, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object v1, v0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p1, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v1, v0, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p1, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v4, 0x0

    const/4 v3, 0x0

    iput-object v1, v0, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v1, p1, Landroidx/core/content/pm/q0;->A:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v1, v0, Landroidx/core/content/pm/q0;->A:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p1, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v1, v0, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->j:Z

    const/4 v4, 0x2

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->j:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p1, Landroidx/core/content/pm/q0;->s:Landroid/os/UserHandle;

    const/4 v4, 0x2

    iput-object v1, v0, Landroidx/core/content/pm/q0;->s:Landroid/os/UserHandle;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-wide v1, p1, Landroidx/core/content/pm/q0;->r:J

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-wide v1, v0, Landroidx/core/content/pm/q0;->r:J

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->t:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->t:Z

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->u:Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->u:Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->v:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->v:Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->w:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->w:Z

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->x:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->x:Z

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->y:Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->y:Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p1, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v1, v0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->n:Z

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->n:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v1, p1, Landroidx/core/content/pm/q0;->z:Z

    const/4 v3, 0x4

    move v4, v3

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->z:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v1, p1, Landroidx/core/content/pm/q0;->o:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput v1, v0, Landroidx/core/content/pm/q0;->o:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p1, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    array-length v2, v1

    const/4 v3, 0x1

    move v4, v3

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    check-cast v1, [Landroidx/core/app/f4;

    const/4 v4, 0x0

    const/4 v3, 0x2

    iput-object v1, v0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v1, p1, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v1, Ljava/util/HashSet;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v2, p1, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {v1, v2}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-object v1, v0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p1, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget p1, p1, Landroidx/core/content/pm/q0;->B:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput p1, v0, Landroidx/core/content/pm/q0;->B:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "MissingGetterMatchingBuilder"
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->c:Ljava/util/Set;

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Ljava/util/HashSet;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/content/pm/q0$a;->c:Ljava/util/Set;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->c:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public b(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)Landroidx/core/content/pm/q0$a;
    .locals 4
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "MissingGetterMatchingBuilder"
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Landroidx/core/content/pm/q0$a;"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroidx/core/content/pm/q0$a;->a(Ljava/lang/String;)Landroidx/core/content/pm/q0$a;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p3}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v3, 0x1

    new-instance v1, Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p1, Ljava/util/Map;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {p1, p2, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0
.end method

.method public c()Landroidx/core/content/pm/q0;
    .locals 12
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v0, v0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-nez v0, :cond_b

    const/4 v10, 0x7

    move v11, v10

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x5

    iget-object v1, v0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-eqz v1, :cond_a

    const/4 v11, 0x1

    const/4 v10, 0x4

    array-length v1, v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v1, :cond_a

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-boolean v1, p0, Landroidx/core/content/pm/q0$a;->b:Z

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v1, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget-object v1, v0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-nez v1, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance v1, Landroidx/core/content/g;

    const/4 v11, 0x4

    const/4 v10, 0x0

    iget-object v2, v0, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {v1, v2}, Landroidx/core/content/g;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    iput-object v1, v0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x2

    const/4 v1, 0x1

    const/4 v11, 0x6

    const/4 v1, 0x1

    const/4 v11, 0x5

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->n:Z

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->c:Ljava/util/Set;

    const/4 v11, 0x7

    if-eqz v0, :cond_3

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    iget-object v1, v0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-nez v1, :cond_2

    const/4 v11, 0x1

    new-instance v1, Ljava/util/HashSet;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    iput-object v1, v0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    :cond_2
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x7

    const/4 v10, 0x6

    iget-object v0, v0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v1, p0, Landroidx/core/content/pm/q0$a;->c:Ljava/util/Set;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-interface {v0, v1}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    if-eqz v0, :cond_7

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-object v1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-nez v1, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    new-instance v1, Landroid/os/PersistableBundle;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {v1}, Landroid/os/PersistableBundle;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    iput-object v1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    :cond_4
    const/4 v11, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_5
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-eqz v1, :cond_7

    const/4 v11, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v11, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x0

    iget-object v2, p0, Landroidx/core/content/pm/q0$a;->d:Ljava/util/Map;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x5

    check-cast v2, Ljava/util/Map;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object v4, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x5

    iget-object v4, v4, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    const/4 v5, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-array v6, v5, [Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-interface {v3, v6}, Ljava/util/Set;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    check-cast v3, [Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v4, v1, v3}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v2}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v4, :cond_5

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    check-cast v4, Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x4

    invoke-interface {v2, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    check-cast v6, Ljava/util/List;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object v7, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget-object v7, v7, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x2

    invoke-virtual {v8, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v9, "/"

    const-string v9, "/"

    const/4 v11, 0x7

    const-string v9, "/"

    const-string v9, "/"

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-nez v6, :cond_6

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-array v6, v5, [Ljava/lang/String;

    const/4 v10, 0x3

    move v11, v10

    goto :goto_1

    :cond_6
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-array v8, v5, [Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-interface {v6, v8}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    check-cast v6, [Ljava/lang/String;

    :goto_1
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v7, v4, v6}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_0

    :cond_7
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->e:Landroid/net/Uri;

    const/4 v10, 0x1

    or-int/2addr v11, v10

    if-eqz v0, :cond_9

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-nez v1, :cond_8

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance v1, Landroid/os/PersistableBundle;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {v1}, Landroid/os/PersistableBundle;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput-object v1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    :cond_8
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object v0, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-object v1, p0, Landroidx/core/content/pm/q0$a;->e:Landroid/net/Uri;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {v1}, Landroidx/core/net/f;->a(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string v2, "eSslixatUrier"

    const-string v2, "extraSliceUri"

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_9
    const/4 v11, 0x4

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    return-object v0

    :cond_a
    const/4 v10, 0x7

    move v11, v10

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v1, "cr mmhht vsa  nianuouenstett"

    const-string/jumbo v1, "tessno Suatihuera ch tnvt mn"

    const/4 v11, 0x6

    const-string v1, "e  toanmrttttnsohcS a viuuhn"

    const-string v1, "Shortcut must have an intent"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    throw v0

    :cond_b
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v1, " r aobtlavmnyh-m ce b heemnlStuspout"

    const-string/jumbo v1, "vc mahl- oo na btsemur upmhytenlaSte"

    const/4 v11, 0x5

    const-string/jumbo v1, "ynevaaulnSthmt sc u-epott ermobh l a"

    const-string v1, "Shortcut must have a non-empty label"

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    throw v0
.end method

.method public d(Landroid/content/ComponentName;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Landroid/content/ComponentName;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p1, v0, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public e()Landroidx/core/content/pm/q0$a;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->j:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p0
.end method

.method public f(Ljava/util/Set;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Ljava/util/Set;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Landroidx/core/content/pm/q0$a;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, v0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public g(Ljava/lang/CharSequence;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, v0, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public h(I)Landroidx/core/content/pm/q0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput p1, v0, Landroidx/core/content/pm/q0;->B:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public i(Landroid/os/PersistableBundle;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Landroid/os/PersistableBundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v1, 0x5

    move v2, v1

    iput-object p1, v0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public j(Landroidx/core/graphics/drawable/IconCompat;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, v0, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public k(Landroid/content/Intent;)Landroidx/core/content/pm/q0$a;
    .locals 4
    .param p1    # Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-array v0, v0, [Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    aput-object p1, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroidx/core/content/pm/q0$a;->l([Landroid/content/Intent;)Landroidx/core/content/pm/q0$a;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p1
.end method

.method public l([Landroid/content/Intent;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # [Landroid/content/Intent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x1

    const/4 v1, 0x6

    iput-object p1, v0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v1, 0x3

    move v2, v1

    return-object p0
.end method

.method public m()Landroidx/core/content/pm/q0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-boolean v0, p0, Landroidx/core/content/pm/q0$a;->b:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object p0
.end method

.method public n(Landroidx/core/content/g;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Landroidx/core/content/g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p1, v0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v2, 0x2

    return-object p0
.end method

.method public o(Ljava/lang/CharSequence;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x1

    const/4 v1, 0x2

    iput-object p1, v0, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public p()Landroidx/core/content/pm/q0$a;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-boolean v1, v0, Landroidx/core/content/pm/q0;->n:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0
.end method

.method public q(Z)Landroidx/core/content/pm/q0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean p1, v0, Landroidx/core/content/pm/q0;->n:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public r(Landroidx/core/app/f4;)Landroidx/core/content/pm/q0$a;
    .locals 4
    .param p1    # Landroidx/core/app/f4;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-array v0, v0, [Landroidx/core/app/f4;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    aput-object p1, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroidx/core/content/pm/q0$a;->s([Landroidx/core/app/f4;)Landroidx/core/content/pm/q0$a;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p1
.end method

.method public s([Landroidx/core/app/f4;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # [Landroidx/core/app/f4;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, v0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method public t(I)Landroidx/core/content/pm/q0$a;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, v0, Landroidx/core/content/pm/q0;->o:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public u(Ljava/lang/CharSequence;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object p1, v0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public v(Landroid/net/Uri;)Landroidx/core/content/pm/q0$a;
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "MissingGetterMatchingBuilder"
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/core/content/pm/q0$a;->e:Landroid/net/Uri;

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-object p0
.end method

.method public w(Landroid/os/Bundle;)Landroidx/core/content/pm/q0$a;
    .locals 3
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0$a;->a:Landroidx/core/content/pm/q0;

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    invoke-static {p1}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p1, Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, v0, Landroidx/core/content/pm/q0;->q:Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p0
.end method
