.class public final synthetic Landroidx/core/content/pm/o1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutManager;Ljava/util/List;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "vKs  @t~~~ti/~iS/f @ @oi~o~@@y~1~~am@  @~ ~~@b @@lfnr~ocs-@.o~~~ob  @l@    ~ @~b @ @@~@~d~@u4M@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/content/pm/ShortcutManager;->setDynamicShortcuts(Ljava/util/List;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method
