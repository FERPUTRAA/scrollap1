.class public final synthetic Landroidx/core/content/pm/j0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~si@b@ dyul~~@ ~o ~t@ @on-l~Kb a~@i@@@ M  ~b c@@@~4~ st /@ S~ m@ fo/~ofr~i~1~~ @~oo@ ~@v@~ @~.@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/content/pm/ShortcutInfo;->isCached()Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method
