.class public Landroidx/core/content/pm/q0;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/pm/q0$a;,
        Landroidx/core/content/pm/q0$b;
    }
.end annotation


# static fields
.field private static final C:Ljava/lang/String; = "extraPersonCount"

.field private static final D:Ljava/lang/String; = "extraPerson_"

.field private static final E:Ljava/lang/String; = "extraLocusId"

.field private static final F:Ljava/lang/String; = "extraLongLived"

.field private static final G:Ljava/lang/String; = "extraSliceUri"

.field public static final H:I = 0x1


# instance fields
.field A:I

.field B:I

.field a:Landroid/content/Context;

.field b:Ljava/lang/String;

.field c:Ljava/lang/String;

.field d:[Landroid/content/Intent;

.field e:Landroid/content/ComponentName;

.field f:Ljava/lang/CharSequence;

.field g:Ljava/lang/CharSequence;

.field h:Ljava/lang/CharSequence;

.field i:Landroidx/core/graphics/drawable/IconCompat;

.field j:Z

.field k:[Landroidx/core/app/f4;

.field l:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field m:Landroidx/core/content/g;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field n:Z

.field o:I

.field p:Landroid/os/PersistableBundle;

.field q:Landroid/os/Bundle;

.field r:J

.field s:Landroid/os/UserHandle;

.field t:Z

.field u:Z

.field v:Z

.field w:Z

.field x:Z

.field y:Z

.field z:Z


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean v0, p0, Landroidx/core/content/pm/q0;->y:Z

    const/4 v2, 0x4

    return-void
.end method

.method private b()Landroid/os/PersistableBundle;
    .locals 7
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x16
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v0, :cond_0

    const/4 v6, 0x5

    new-instance v0, Landroid/os/PersistableBundle;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v0}, Landroid/os/PersistableBundle;-><init>()V

    const/4 v6, 0x2

    iput-object v0, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    if-eqz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    array-length v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-lez v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v2, "rssrPCtoxutenesn"

    const-string v2, "ensoerxrsuCtatPn"

    const-string/jumbo v2, "nPtmroxeeantruso"

    const-string v2, "extraPersonCount"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    array-length v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    array-length v1, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-ge v0, v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v3, "_oteorxesPmn"

    const-string/jumbo v3, "x_Pmotraeesn"

    const/4 v6, 0x6

    const-string v3, "enoarb_erxtP"

    const-string v3, "extraPerson_"

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    add-int/lit8 v3, v0, 0x1

    const/4 v6, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v4, p0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    aget-object v0, v4, v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroidx/core/app/f4;->n()Landroid/os/PersistableBundle;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v0}, Landroid/os/PersistableBundle;->putPersistableBundle(Ljava/lang/String;Landroid/os/PersistableBundle;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    move v0, v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v2, "ocIauxutoLrs"

    const-string v2, "aocsoIexLrtu"

    const/4 v6, 0x5

    const-string/jumbo v2, "rxdeoLapIcts"

    const-string v2, "extraLocusId"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroidx/core/content/g;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v1, "dLtreegLqxnibv"

    const-string v1, "egoxebdiLnrtvL"

    const/4 v6, 0x5

    const-string v1, "gtseLdnriaeLov"

    const-string v1, "extraLongLived"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-boolean v2, p0, Landroidx/core/content/pm/q0;->n:Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-object v0
.end method

.method static c(Landroid/content/Context;Ljava/util/List;)Ljava/util/List;
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Landroid/content/pm/ShortcutInfo;",
            ">;)",
            "Ljava/util/List<",
            "Landroidx/core/content/pm/q0;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v1}, Landroidx/core/content/pm/p;->a(Ljava/lang/Object;)Landroid/content/pm/ShortcutInfo;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v2, Landroidx/core/content/pm/q0$a;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v2, p0, v1}, Landroidx/core/content/pm/q0$a;-><init>(Landroid/content/Context;Landroid/content/pm/ShortcutInfo;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroidx/core/content/pm/q0$a;->c()Landroidx/core/content/pm/q0;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v0
.end method

.method static p(Landroid/content/pm/ShortcutInfo;)Landroidx/core/content/g;
    .locals 4
    .param p0    # Landroid/content/pm/ShortcutInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x1d

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-lt v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/core/content/pm/f;->a(Landroid/content/pm/ShortcutInfo;)Landroid/content/LocusId;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Landroidx/core/content/pm/f;->a(Landroid/content/pm/ShortcutInfo;)Landroid/content/LocusId;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0}, Landroidx/core/content/g;->d(Landroid/content/LocusId;)Landroidx/core/content/g;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0}, Landroidx/core/content/pm/o;->a(Landroid/content/pm/ShortcutInfo;)Landroid/os/PersistableBundle;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/core/content/pm/q0;->q(Landroid/os/PersistableBundle;)Landroidx/core/content/g;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0
.end method

.method private static q(Landroid/os/PersistableBundle;)Landroidx/core/content/g;
    .locals 4
    .param p0    # Landroid/os/PersistableBundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v1, "IarmoducLtse"

    const-string v1, "aILdosurtxce"

    const-string v1, "aIusorocetxd"

    const-string v1, "extraLocusId"

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p0, :cond_1

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Landroidx/core/content/g;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Landroidx/core/content/g;-><init>(Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x4

    return-object v0
.end method

.method static s(Landroid/os/PersistableBundle;)Z
    .locals 4
    .param p0    # Landroid/os/PersistableBundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v0, "epLvobrndtegxL"

    const-string/jumbo v0, "txLgLropnvedie"

    const/4 v3, 0x4

    const-string v0, "aLgLxvundeitro"

    const-string v0, "extraLongLived"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p0

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return p0
.end method

.method static u(Landroid/os/PersistableBundle;)[Landroidx/core/app/f4;
    .locals 7
    .param p0    # Landroid/os/PersistableBundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x4

    if-eqz p0, :cond_2

    const/4 v5, 0x4

    move v6, v5

    const-string/jumbo v0, "oPeasnCpqetrtnxr"

    const-string v0, "PxoratnsqteCroen"

    const/4 v6, 0x4

    const-string/jumbo v0, "nreCaosrqnutoPxt"

    const-string v0, "extraPersonCount"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v1, :cond_0

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-array v1, v0, [Landroidx/core/app/f4;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ge v2, v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const-string v4, "Passosenrerx"

    const-string v4, "Pesron_rexas"

    const/4 v6, 0x4

    const-string/jumbo v4, "srxmenPrt_oe"

    const-string v4, "extraPerson_"

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int/lit8 v4, v2, 0x1

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0, v3}, Landroid/os/PersistableBundle;->getPersistableBundle(Ljava/lang/String;)Landroid/os/PersistableBundle;

    move-result-object v3

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v3}, Landroidx/core/app/f4;->c(Landroid/os/PersistableBundle;)Landroidx/core/app/f4;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    aput-object v3, v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v2, v4

    const/4 v6, 0x5

    move v2, v4

    move v2, v4

    const/4 v5, 0x7

    move v6, v5

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object v1

    :cond_2
    :goto_1
    const/4 v6, 0x4

    const/4 p0, 0x7

    const/4 v6, 0x6

    const/4 p0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-object p0
.end method


# virtual methods
.method public A()Z
    .locals 3

    const/4 v2, 0x7

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->t:Z

    const/4 v1, 0x2

    and-int/2addr v2, v1

    return v0
.end method

.method public B()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->w:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    return v0
.end method

.method public C()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->u:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public D()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x1

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->y:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public E(I)Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Landroidx/core/content/pm/q0;->B:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    and-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method

.method public F()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->x:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public G()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->v:Z

    const/4 v1, 0x7

    or-int/2addr v2, v1

    return v0
.end method

.method public H()Landroid/content/pm/ShortcutInfo;
    .locals 7
    .annotation build Landroidx/annotation/w0;
        value = 0x19
    .end annotation

    const/4 v6, 0x1

    invoke-static {}, Landroidx/core/content/pm/n;->a()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, v1}, Landroidx/core/content/pm/m;->a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ShortcutInfo$Builder;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v1}, Landroidx/core/content/pm/q;->a(Landroid/content/pm/ShortcutInfo$Builder;Ljava/lang/CharSequence;)Landroid/content/pm/ShortcutInfo$Builder;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1}, Landroidx/core/content/pm/v;->a(Landroid/content/pm/ShortcutInfo$Builder;[Landroid/content/Intent;)Landroid/content/pm/ShortcutInfo$Builder;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    iget-object v2, p0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Landroidx/core/graphics/drawable/IconCompat;->M(Landroid/content/Context;)Landroid/graphics/drawable/Icon;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-static {v0, v1}, Landroidx/core/content/pm/w;->a(Landroid/content/pm/ShortcutInfo$Builder;Landroid/graphics/drawable/Icon;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_0
    const/4 v6, 0x6

    iget-object v1, p0, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0, v1}, Landroidx/core/content/pm/g;->a(Landroid/content/pm/ShortcutInfo$Builder;Ljava/lang/CharSequence;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v1, p0, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p0, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v5, 0x4

    or-int/2addr v6, v5

    invoke-static {v0, v1}, Landroidx/core/content/pm/h;->a(Landroid/content/pm/ShortcutInfo$Builder;Ljava/lang/CharSequence;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, p0, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0, v1}, Landroidx/core/content/pm/i;->a(Landroid/content/pm/ShortcutInfo$Builder;Landroid/content/ComponentName;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v0, v1}, Landroidx/core/content/pm/j;->a(Landroid/content/pm/ShortcutInfo$Builder;Ljava/util/Set;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget v1, p0, Landroidx/core/content/pm/q0;->o:I

    const/4 v6, 0x4

    invoke-static {v0, v1}, Landroidx/core/content/pm/k;->a(Landroid/content/pm/ShortcutInfo$Builder;I)Landroid/content/pm/ShortcutInfo$Builder;

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v1, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0, v1}, Landroidx/core/content/pm/t;->a(Landroid/content/pm/ShortcutInfo$Builder;Landroid/os/PersistableBundle;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_5
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/16 v2, 0x1d

    const/4 v6, 0x3

    if-lt v1, v2, :cond_9

    const/4 v6, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v6, 0x6

    if-eqz v1, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    array-length v2, v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-lez v2, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    array-length v1, v1

    new-array v2, v1, [Landroid/app/Person;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    :goto_0
    const/4 v5, 0x4

    move v6, v5

    if-ge v3, v1, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v4, p0, Landroidx/core/content/pm/q0;->k:[Landroidx/core/app/f4;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    aget-object v4, v4, v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v4}, Landroidx/core/app/f4;->k()Landroid/app/Person;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    aput-object v4, v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, v2}, Landroidx/core/content/pm/l;->a(Landroid/content/pm/ShortcutInfo$Builder;[Landroid/app/Person;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_7
    const/4 v6, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v6, 0x3

    if-eqz v1, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroidx/core/content/g;->c()Landroid/content/LocusId;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v1}, Landroidx/core/content/pm/r;->a(Landroid/content/pm/ShortcutInfo$Builder;Landroid/content/LocusId;)Landroid/content/pm/ShortcutInfo$Builder;

    :cond_8
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-boolean v1, p0, Landroidx/core/content/pm/q0;->n:Z

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v1}, Landroidx/core/content/pm/s;->a(Landroid/content/pm/ShortcutInfo$Builder;Z)Landroid/content/pm/ShortcutInfo$Builder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_1

    :cond_9
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p0}, Landroidx/core/content/pm/q0;->b()Landroid/os/PersistableBundle;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v1}, Landroidx/core/content/pm/t;->a(Landroid/content/pm/ShortcutInfo$Builder;Landroid/os/PersistableBundle;)Landroid/content/pm/ShortcutInfo$Builder;

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Landroidx/core/content/pm/u;->a(Landroid/content/pm/ShortcutInfo$Builder;)Landroid/content/pm/ShortcutInfo;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v0
.end method

.method a(Landroid/content/Intent;)Landroid/content/Intent;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    array-length v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    add-int/lit8 v1, v1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    aget-object v0, v0, v1

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v1, "atatosmehdu.nn.cttIonoreTtTirEr.xNid"

    const-string/jumbo v1, "trTmnixt.nIehcnou.d..tNaiaEstorTtdre"

    const/4 v4, 0x3

    const-string v1, "Noat.biEtetntaNdnrxe.sdtiTu.oIrn.cTh"

    const-string v1, "android.intent.extra.shortcut.INTENT"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v1, p0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v2, ".cot.auenxrnotad.rouie.NrnAitEdhtM"

    const-string/jumbo v2, "oeN.oo..atdnMt.eirsdxtrnatnAchEuri"

    const-string v2, "cnnxtMopitEiatruAta.end.otr.sNr.de"

    const-string v2, "android.intent.extra.shortcut.NAME"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->j:Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v2, p0, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v2, :cond_0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Landroid/content/pm/PackageManager;->getActivityIcon(Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;

    move-result-object v1
    :try_end_0
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroid/content/pm/PackageItemInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v4, 0x5

    iget-object v2, p0, Landroidx/core/content/pm/q0;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, p1, v1, v2}, Landroidx/core/graphics/drawable/IconCompat;->j(Landroid/content/Intent;Landroid/graphics/drawable/Drawable;Landroid/content/Context;)V

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p1
.end method

.method public d()Landroid/content/ComponentName;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/content/pm/q0;->e:Landroid/content/ComponentName;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public e()Ljava/util/Set;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/core/content/pm/q0;->l:Ljava/util/Set;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public f()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0;->h:Ljava/lang/CharSequence;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget v0, p0, Landroidx/core/content/pm/q0;->A:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public h()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Landroidx/core/content/pm/q0;->B:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public i()Landroid/os/PersistableBundle;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0;->p:Landroid/os/PersistableBundle;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public j()Landroidx/core/graphics/drawable/IconCompat;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0;->i:Landroidx/core/graphics/drawable/IconCompat;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public k()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/core/content/pm/q0;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public l()Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v3, 0x3

    array-length v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    add-int/lit8 v1, v1, -0x1

    const/4 v2, 0x0

    move v3, v2

    aget-object v0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public m()[Landroid/content/Intent;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/core/content/pm/q0;->d:[Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    array-length v1, v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v0, [Landroid/content/Intent;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method public n()J
    .locals 4

    const/4 v2, 0x0

    move v3, v2

    iget-wide v0, p0, Landroidx/core/content/pm/q0;->r:J

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-wide v0
.end method

.method public o()Landroidx/core/content/g;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0;->m:Landroidx/core/content/g;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public r()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/core/content/pm/q0;->g:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    return-object v0
.end method

.method public t()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0;->c:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public v()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Landroidx/core/content/pm/q0;->o:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public w()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/core/content/pm/q0;->f:Ljava/lang/CharSequence;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public x()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/core/content/pm/q0;->q:Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public y()Landroid/os/UserHandle;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/core/content/pm/q0;->s:Landroid/os/UserHandle;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public z()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/core/content/pm/q0;->z:Z

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method
