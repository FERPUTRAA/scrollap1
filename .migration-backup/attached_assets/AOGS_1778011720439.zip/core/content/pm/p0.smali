.class public final synthetic Landroidx/core/content/pm/p0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@1soo b @ ~n@m @@t -~~@~ ~/~~@ro@l@~i4@t@b@@ ibfv~~l@do@~o a~yo ~ S~~~~ .@@ c~  KMi  s~u@~/@@~f "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/pm/ShortcutInfo;->hasKeyFieldsOnly()Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p0
.end method
