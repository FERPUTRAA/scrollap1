.class public final synthetic Landroidx/core/content/pm/n0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s~~~i-  @t/~~~/ba4S@@~l.~of@@ @@in~@ ~ v~  @mb~oy1~@~@@ ~rt~ ~@i@obo@o @ doM@@ l~~u@ Ks  @  ~c"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/pm/ShortcutInfo;->isImmutable()Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p0
.end method
