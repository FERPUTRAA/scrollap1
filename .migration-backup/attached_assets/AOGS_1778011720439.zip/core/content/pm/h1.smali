.class public final synthetic Landroidx/core/content/pm/h1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutManager;)Ljava/util/List;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s-v~a@@~S n4~r@@~i~co 1o@i@    ~ iu.oo/~~@@ ~d ~~@bb~@~~~@m~~s   /~Mo @f@of~b l@t~@@y@~~ @t l@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/content/pm/ShortcutManager;->getDynamicShortcuts()Ljava/util/List;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method
