.class public final synthetic Landroidx/core/content/pm/s0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a()Ljava/lang/Class;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "/ s@ @ @  ~lvr~~Mo  d~o@b~.b~o @i@ S f/ msa-@@4~~i~~ oou   ~~~~b@@@@t~l@@@f~~~@~t@K1@~@ y@c~~ in"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const-class v0, Landroid/content/pm/ShortcutManager;

    const-class v0, Landroid/content/pm/ShortcutManager;

    const/4 v2, 0x6

    const-class v0, Landroid/content/pm/ShortcutManager;

    const-class v0, Landroid/content/pm/ShortcutManager;

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-object v0
.end method
