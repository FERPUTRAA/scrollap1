.class Landroidx/core/content/pm/p1$b;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x19
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/content/pm/p1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method static a(Ljava/util/List;)Ljava/lang/String;
    .locals 7
    .param p0    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/content/pm/ShortcutInfo;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@-s~@@va@b~@K@i~o  @~.@/i@~dl@n @~t  ~@~ ~  m~4~r  ~~~@ ~lb@ffo @@  o~syS~@uo~@~1   ~@~cbt~oMo@/"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v0, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v1, 0x0

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    check-cast v2, Landroid/content/pm/ShortcutInfo;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v2}, Landroid/content/pm/ShortcutInfo;->getRank()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-le v3, v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroid/content/pm/ShortcutInfo;->getId()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v2}, Landroid/content/pm/ShortcutInfo;->getRank()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    move v4, v1

    move v4, v1

    const/4 v6, 0x5

    move v4, v1

    move v4, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    move v0, v4

    move v0, v4

    const/4 v6, 0x6

    move v0, v4

    move v0, v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-object v1
.end method
