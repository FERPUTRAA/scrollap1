.class public final synthetic Landroidx/core/content/pm/d1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/Object;)Landroid/content/pm/ShortcutManager;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ss o~lrclymo@@@~@d  /~ @tS~i@~   @/@i M bb@ @~ 1u@ ~oKo~ ~@@o4@t@~~~v .~ @fi~~f~@~o~~@ an~~@b- "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    check-cast p0, Landroid/content/pm/ShortcutManager;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method
