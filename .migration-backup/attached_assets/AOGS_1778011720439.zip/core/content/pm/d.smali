.class public final Landroidx/core/content/pm/d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/pm/d$a;,
        Landroidx/core/content/pm/d$c;,
        Landroidx/core/content/pm/d$b;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Landroid/content/pm/PermissionInfo;)I
    .locals 4
    .param p0    # Landroid/content/pm/PermissionInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ifs@~ ~tt@1~sbco@Mlv~@ @.o@ @@@u~@~/ S o- miK ~in   r~~l~ ~ b~~@a~f~~~ @oy/~ @~~@@~ 4o @@@b od@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/16 v1, 0x1c

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/core/content/pm/d$a;->a(Landroid/content/pm/PermissionInfo;)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p0

    :cond_0
    const/4 v2, 0x4

    move v3, v2

    iget p0, p0, Landroid/content/pm/PermissionInfo;->protectionLevel:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    and-int/lit8 p0, p0, 0xf

    const/4 v3, 0x7

    const/4 v2, 0x4

    return p0
.end method

.method public static b(Landroid/content/pm/PermissionInfo;)I
    .locals 4
    .param p0    # Landroid/content/pm/PermissionInfo;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 v1, 0x1c

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-lt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {p0}, Landroidx/core/content/pm/d$a;->b(Landroid/content/pm/PermissionInfo;)I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget p0, p0, Landroid/content/pm/PermissionInfo;->protectionLevel:I

    const/4 v3, 0x2

    and-int/lit8 p0, p0, -0x10

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return p0
.end method
