.class public final synthetic Landroidx/core/content/pm/i1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutManager;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ sM~~ @@ ~@ib~/ba~l~@  @ti~~ @ of~@d~~@o~oi~@v @c@ soS@-@K@ ~ 4  n1@~~m~bl @o@o@ ~ ~ t@u.~f@r~y"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/pm/ShortcutManager;->getIconMaxWidth()I

    move-result p0

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method
