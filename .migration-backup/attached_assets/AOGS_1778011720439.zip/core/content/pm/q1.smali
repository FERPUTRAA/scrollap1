.class public Landroidx/core/content/pm/q1;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final a:Ljava/lang/String; = "ShortcutXmlParser"

.field private static final b:Ljava/lang/String; = "android.app.shortcuts"

.field private static final c:Ljava/lang/String; = "shortcut"

.field private static final d:Ljava/lang/String; = "shortcutId"

.field private static volatile e:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final f:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    sput-object v0, Landroidx/core/content/pm/q1;->f:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method private static a(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~sf@~b/~c s~bl@l@a~~~m@~  ion@t~ @K@o4~@to do-@/ ~~~@b v@ @    oo~~@fM~ i~@1@.~S@~@ ~i r @~~@yu"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ":mmm/tpccaioa.sr/d/d/sd/rhetdopnesa.ankrsh"

    const-string/jumbo v0, "n/soenomtdmrrsa:pt.airsddcshe/dpcaa.//h/ik"

    const/4 v2, 0x4

    const-string v0, "ceosophomnnct/.r/tidara/rmoaie.p/dsd/:shka"

    const-string v0, "http://schemas.android.com/apk/res/android"

    const/4 v1, 0x4

    move v2, v1

    invoke-interface {p0, v0, p1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {p0, v0, p1}, Lorg/xmlpull/v1/XmlPullParser;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public static b(Landroid/content/Context;)Ljava/util/List;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/l1;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Landroidx/core/content/pm/q1;->e:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    sget-object v0, Landroidx/core/content/pm/q1;->f:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v1, Landroidx/core/content/pm/q1;->e:Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    sput-object v1, Landroidx/core/content/pm/q1;->e:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v1, Landroidx/core/content/pm/q1;->e:Ljava/util/ArrayList;

    const/4 v3, 0x5

    invoke-static {p0}, Landroidx/core/content/pm/q1;->e(Landroid/content/Context;)Ljava/util/Set;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object p0, Landroidx/core/content/pm/q1;->e:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p0
.end method

.method private static c(Landroid/content/Context;Landroid/content/pm/ActivityInfo;)Landroid/content/res/XmlResourceParser;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo v0, "tpciobmaonuatdds.hrpr"

    const-string v0, "druminoaodrtthp.sscap"

    const/4 v3, 0x7

    const-string v0, ".ir.dcuatuhpsatsoornp"

    const-string v0, "android.app.shortcuts"

    const/4 v3, 0x5

    invoke-virtual {p1, p0, v0}, Landroid/content/pm/PackageItemInfo;->loadXmlMetaData(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/res/XmlResourceParser;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v1, "tF frtapde tdm n oopaorrpcdos sher oeet.u ncaouel-otaa.pasi"

    const-string v1, "F ooo eerreaedtpsot  ana.d atchoomiud.sec  au-paprsotfrinlt"

    const/4 v3, 0x5

    const-string v1, " hiclod qanacradaso apeuptut.e-rfpro diostto soem.dr aF ent"

    const-string v1, "Failed to open android.app.shortcuts meta-data resource of "

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    throw p0
.end method

.method public static d(Lorg/xmlpull/v1/XmlPullParser;)Ljava/util/List;
    .locals 8
    .param p0    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/xmlpull/v1/XmlPullParser;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v1, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    :cond_0
    :goto_0
    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v2

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eq v2, v1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v3, 0x3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-ne v2, v3, :cond_1

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-lez v3, :cond_3

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-interface {p0}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v5, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ne v2, v5, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne v3, v5, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "tssbcuot"

    const-string/jumbo v2, "utcsobht"

    const/4 v7, 0x4

    const-string v2, "ctomtuhs"

    const-string/jumbo v2, "shortcut"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v2, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v2, "uIutosctoh"

    const-string/jumbo v2, "ttIochuusd"

    const/4 v7, 0x3

    const-string v2, "cosdIbutht"

    const-string/jumbo v2, "shortcutId"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p0, v2}, Landroidx/core/content/pm/q1;->a(Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_0

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object v0
.end method

.method private static e(Landroid/content/Context;)Ljava/util/Set;
    .locals 7
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v0, Ljava/util/HashSet;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v2, "tAptituni.an..oenndciIoraN"

    const-string/jumbo v2, "nAtd.aopieNritoI.inncaM.nt"

    const/4 v6, 0x1

    const-string v2, ".iainndpcMo.rettitInonNa.d"

    const-string v2, "android.intent.action.MAIN"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v2, "aHrettt.qciCnd.AneUigaoyrNqnRo.d"

    const-string v2, "Ro.negiiqrnnctaay.eUrAo.tdNtdEHC"

    const/4 v6, 0x4

    const-string v2, "ACsnteeLaoNUyr.dco..RHridgnttaiE"

    const-string v2, "android.intent.category.LAUNCHER"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/16 v3, 0x80

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v2, v1, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v1, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    if-nez v2, :cond_0

    const/4 v5, 0x5

    and-int/2addr v6, v5

    goto/16 :goto_2

    :cond_0
    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    check-cast v2, Landroid/content/pm/ResolveInfo;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v3, v2, Landroid/content/pm/ActivityInfo;->metaData:Landroid/os/Bundle;

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v6, 0x2

    const-string/jumbo v4, "issmcnto.prupsad.orha"

    const-string v4, "adsioru.pr.ncsohasttp"

    const/4 v6, 0x3

    const-string v4, "cs.ponahdpu.iatrosrot"

    const-string v4, "android.app.shortcuts"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p0, v2}, Landroidx/core/content/pm/q1;->c(Landroid/content/Context;Landroid/content/pm/ActivityInfo;)Landroid/content/res/XmlResourceParser;

    move-result-object v2
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v2}, Landroidx/core/content/pm/q1;->d(Lorg/xmlpull/v1/XmlPullParser;)Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v0, v3}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v2, :cond_1

    :try_start_2
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v2, :cond_2

    :try_start_3
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v2}, Landroid/content/res/XmlResourceParser;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto :goto_1

    :catchall_1
    move-exception v1

    :try_start_4
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2
    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    throw p0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    move-exception p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v1, "hermabturloPXtcsm"

    const-string/jumbo v1, "oXPmmulrrahtcSets"

    const-string v1, "hrotrtuSrsalPceXm"

    const-string v1, "ShortcutXmlParser"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v2, " al sasptrdlrXeoou m rFhecepe: oei"

    const-string/jumbo v2, "irXao  sd o :eraFpec  slehruetoelm"

    const/4 v6, 0x3

    const-string v2, " oroatueqlt eeFiXcmlssr eadhp e :r"

    const-string v2, "Failed to parse the Xml resource: "

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1, v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-object v0
.end method
