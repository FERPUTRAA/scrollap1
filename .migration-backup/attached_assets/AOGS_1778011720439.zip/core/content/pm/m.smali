.class public final synthetic Landroidx/core/content/pm/m;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/pm/ShortcutInfo$Builder;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bds @oobu@1~~  @ i.o~ a~~il @@~@~  @~c@ o@/~@y@S@ os@/ ~~ @@~4vf~@@  no@@t~i~rf~M~@mb~~  -~~~t K"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    new-instance v0, Landroid/content/pm/ShortcutInfo$Builder;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0, p1}, Landroid/content/pm/ShortcutInfo$Builder;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method
