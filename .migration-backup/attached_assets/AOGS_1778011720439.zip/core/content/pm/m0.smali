.class public final synthetic Landroidx/core/content/pm/m0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ssi@~bm ~  1~~c@ ov~ @n~ /4oboM~utf@K@. r  ~t@@~~~@@@ /o~~~   @Sa~~@~~ -b@@~i~ly l@fi@d@  ~o@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/pm/ShortcutInfo;->isDeclaredInManifest()Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return p0
.end method
