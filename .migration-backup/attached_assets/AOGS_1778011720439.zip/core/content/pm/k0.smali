.class public final synthetic Landroidx/core/content/pm/k0;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutInfo;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s f@ @v.~@~a~o~~@i bo@~~~~-@f1@ d  l~@ m@r@ /u~b~o~@l@  @stty~~@Kn  ~c~~S@i@o ~  ~io ~M/@@bo 4"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/pm/ShortcutInfo;->isDynamic()Z

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method
