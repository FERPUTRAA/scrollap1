.class public final synthetic Landroidx/core/content/pm/n1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutManager;Ljava/util/List;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @ss@ @tt~~@S@bffo 14.@@~n~rc~~ ~@y@  ~ i@ @~~ou~d ~@~@~m@ ~M@ ~-o@i@  ~~@o@lo~Kil//  ~a~~bv @b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Landroid/content/pm/ShortcutManager;->updateShortcuts(Ljava/util/List;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    return p0
.end method
