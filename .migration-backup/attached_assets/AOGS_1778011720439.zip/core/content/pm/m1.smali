.class public final synthetic Landroidx/core/content/pm/m1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutManager;Ljava/util/List;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~sd/o~  @v~@~~~  uy@@@o i~ mol @~~Sb~f@1c~ @~@t~iKi @tr@o@s  o/o@@@~~@@ ~~M b@~f ~-bl n@.~a~@~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/content/pm/ShortcutManager;->removeDynamicShortcuts(Ljava/util/List;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
