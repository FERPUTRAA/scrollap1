.class public final synthetic Landroidx/core/content/pm/a1;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/content/pm/ShortcutManager;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~syM@vo@a~@@~~1@@o@S o@c~s@i ft~ @ . @@~ fd~~l @o@ ~iio o-@uKb~~~r~@@~l@~ / tb b~  4~ m /n~~@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/content/pm/ShortcutManager;->getIconMaxHeight()I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p0
.end method
