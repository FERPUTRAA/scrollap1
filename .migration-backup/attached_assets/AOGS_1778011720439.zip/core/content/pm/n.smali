.class public final synthetic Landroidx/core/content/pm/n;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s-~f~SsMlut~b~ ~@n ~ @ iir~@ ~~y~~im @~@o@ @d~b ~@@1  @/@@oo~@ v@a~~@.~~t@o~@b@~ @ /of~4  loK "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Landroid/content/pm/ShortcutInfo$Builder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
