.class public final Landroidx/core/content/f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/f$a;
    }
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "android.intent.action.CREATE_REMINDER"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "android.intent.extra.HTML_TEXT"

.field public static final c:Ljava/lang/String; = "android.intent.extra.START_PLAYBACK"

.field public static final d:Ljava/lang/String; = "android.intent.extra.TIME"
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ActionValue"
        }
    .end annotation
.end field

.field public static final e:Ljava/lang/String; = "android.intent.category.LEANBACK_LAUNCHER"


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 7
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@s~@by@Mf@tt~b@r@mc 4~@/ @f o~o@a@ln@@ios b1v@lu~@ ~~  @~o@ S. ~ ~~~~~/~~  o di~  o~i~ K@@~@~@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v0}, Landroidx/core/content/l;->a(Landroid/content/pm/PackageManager;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/16 v1, 0x1f

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v3, "sckmgae"

    const-string v3, "ekscpga"

    const/4 v6, 0x6

    const-string/jumbo v3, "pakgoac"

    const-string/jumbo v3, "package"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-lt v0, v1, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance p0, Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string/jumbo v0, "sTIIsbOA_rESoPegtTTLIaE.LPd_DSTCAnn.NGStiINmd"

    const-string v0, "ErTmg_NSAILs.EPoCdITATSdtOnLAI_GtTasSD.NIPnei"

    const/4 v6, 0x5

    const-string v0, "S_iSLPuPTLtSIToGIdngEiI_NsADrItNTnOATeAaEs..C"

    const-string v0, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v6, 0x4

    invoke-direct {p0, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v3, p1, v2}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object p0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v4, "Eat.ttNpSeOiTdV__UORiinaIEEcIKARMSPnnO..odSor"

    const-string v4, "android.intent.action.AUTO_REVOKE_PERMISSIONS"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-direct {v1, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v3, p1, v2}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/16 v1, 0x1e

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-lt v0, v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-object p1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-static {p0}, Landroidx/core/content/l;->b(Landroid/content/pm/PackageManager;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p0}, Landroidx/core/util/q;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    check-cast p0, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    return-object p0

    :cond_2
    const/4 v6, 0x6

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo p1, "s tnUipiqcofee ocndu  etbp lraehsdRostraner vauAsi  iaeiteat env"

    const-string p1, "eineosufveeehettn   eaRcrnsAubi llataoareopidUtv i tidasc pr sn "

    const/4 v6, 0x2

    const-string/jumbo p1, "nbs tirsec adoirapletisiUht  aovteeaenoscn vedrAien sl aRe up fu"

    const-string p1, "Unused App Restriction features are not available on this device"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    throw p0
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    .locals 2
    .param p0    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0, p1}, Landroidx/core/content/f$a;->a(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-object p0
.end method
