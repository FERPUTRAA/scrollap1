.class public final Landroidx/core/content/o;
.super Ljava/lang/Object;


# direct methods
.method public static final a(Landroid/content/SharedPreferences;ZLi8/l;)V
    .locals 3
    .param p0    # Landroid/content/SharedPreferences;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "ApplySharedPref"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Z",
            "Li8/l<",
            "-",
            "Landroid/content/SharedPreferences$Editor;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "s>sih<"

    const-string v0, "><shis"

    const/4 v2, 0x3

    const-string/jumbo v0, "sihmt<"

    const-string v0, "<this>"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const-string/jumbo v0, "taomnc"

    const/4 v2, 0x2

    const-string/jumbo v0, "oinaoc"

    const-string v0, "action"

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "idortb"

    const-string/jumbo v0, "toidor"

    const/4 v2, 0x5

    const-string/jumbo v0, "uodrti"

    const-string v0, "editor"

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p2, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_0
    const/4 v1, 0x3

    return-void
.end method

.method public static synthetic b(Landroid/content/SharedPreferences;ZLi8/l;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    and-int/lit8 p3, p3, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p3, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p1, 0x0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    const-string p3, "hpis<>"

    const-string/jumbo p3, "sih><b"

    const/4 v1, 0x7

    const-string p3, "h>qs<i"

    const-string p3, "<this>"

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0, p3}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x1

    move v1, v0

    const-string/jumbo p3, "utsnao"

    const-string/jumbo p3, "uiotan"

    const/4 v1, 0x5

    const-string/jumbo p3, "tanmoc"

    const-string p3, "action"

    const/4 v1, 0x3

    invoke-static {p2, p3}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    const-string p3, "diproo"

    const-string/jumbo p3, "ipodrt"

    const/4 v1, 0x1

    const-string/jumbo p3, "teidrb"

    const-string p3, "editor"

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0, p3}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-interface {p2, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x1

    if-eqz p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    goto :goto_0

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
