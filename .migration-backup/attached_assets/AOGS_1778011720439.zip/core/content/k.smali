.class public final synthetic Landroidx/core/content/k;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/core/content/q;


# direct methods
.method public synthetic constructor <init>(Landroidx/core/content/q;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    move v1, v0

    iput-object p1, p0, Landroidx/core/content/k;->a:Landroidx/core/content/q;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @sv~ ~~4 obtf-@/fm@@1oy~~i@bi @@@ @s @ @~~.~l ~t @~S~~@~o~ ~@ o~ /~~@@ro@b nK ~~~di @Mc l@u @~a"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/core/content/k;->a:Landroidx/core/content/q;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/core/content/q;->b()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method
