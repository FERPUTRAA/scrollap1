.class Landroidx/core/content/q;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field a:Landroidx/core/app/unusedapprestrictions/b;
    .annotation build Landroidx/annotation/k1;
    .end annotation

    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field

.field b:Landroidx/concurrent/futures/e;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/concurrent/futures/e<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private final c:Landroid/content/Context;

.field private f:Z


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    move v2, v1

    const/4 v0, 0x0

    xor-int/2addr v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/core/content/q;->a:Landroidx/core/app/unusedapprestrictions/b;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-boolean v0, p0, Landroidx/core/content/q;->f:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/core/content/q;->c:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method private c()Landroidx/core/app/unusedapprestrictions/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@bs/t~o~a~~.@o~/id@@~@o@@~41brocK ~ ~Ml~ ~ @m@nu@fo ~t b~ @@~@iy  @i @  ~@ @  ~@~Sv~l@~  @o-~fs~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    new-instance v0, Landroidx/core/content/q$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p0}, Landroidx/core/content/q$a;-><init>(Landroidx/core/content/q;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public a(Landroidx/concurrent/futures/e;)V
    .locals 4
    .param p1    # Landroidx/concurrent/futures/e;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/concurrent/futures/e<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    iget-boolean v0, p0, Landroidx/core/content/q;->f:Z

    const/4 v2, 0x4

    move v3, v2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-boolean v0, p0, Landroidx/core/content/q;->f:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/core/content/q;->b:Landroidx/concurrent/futures/e;

    const/4 v3, 0x5

    new-instance p1, Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo v1, "tCimpceodotUscorunppraomtnod.sRspat.riaeBeS.oeristuuniincsoupucpdkAsndtestnrss.trrcieap"

    const-string/jumbo v1, "oSsdstuRrnceeaocriUsdeesndtoa.aoiupescns.tapepmiotpcvpooiuiuBsr.ntcnpsrtruiAdCnpt.rrskt"

    const-string v1, "BoeuotUCironpitre..itecntuoraRnudsSadncressspicpApmvotsp.ruintcuaito.rdsaispcdtrkponoes"

    const-string v1, "android.support.unusedapprestrictions.action.CustomUnusedAppRestrictionsBackportService"

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/core/content/q;->c:Landroid/content/Context;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v1}, Landroidx/core/content/l;->b(Landroid/content/pm/PackageManager;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/core/content/q;->c:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1, p1, p0, v0}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "loioBbn otnnCia.eccturdy nUpcchon nmpcb se etvScoAsdponernbreeik acEiRoneat"

    const-string/jumbo v0, "n ymnurSilEeodotnib asebcoceri tRshenc ctoconrpovn.nis koBcAeecnea CpUpadtn"

    const/4 v3, 0x0

    const-string/jumbo v0, "po a rulucdtco ertcRoeyuvtsAhnoiisannieEieBccoe.Sobsannptodepknn n ccrenC b"

    const-string v0, "Each UnusedAppRestrictionsBackportServiceConnection can only be bound once."

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw p1
.end method

.method public b()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-boolean v0, p0, Landroidx/core/content/q;->f:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-boolean v0, p0, Landroidx/core/content/q;->f:Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/core/content/q;->c:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "bSodnbbpcfbnnidiv cesdea eeiul e lreum r"

    const-string/jumbo v1, "olrfouueeensbcid mdebde  brclinvae inbS "

    const/4 v3, 0x4

    const-string v1, "bldaie bqlbstceeudbc m rrinieun eovSfnde"

    const-string v1, "bindService must be called before unbind"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    throw v0
.end method

.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    invoke-static {p2}, Landroidx/core/app/unusedapprestrictions/b$b;->a(Landroid/os/IBinder;)Landroidx/core/app/unusedapprestrictions/b;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/content/q;->a:Landroidx/core/app/unusedapprestrictions/b;

    :try_start_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Landroidx/core/content/q;->c()Landroidx/core/app/unusedapprestrictions/a;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-interface {p1, p2}, Landroidx/core/app/unusedapprestrictions/b;->P(Landroidx/core/app/unusedapprestrictions/a;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    goto :goto_0

    :catch_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget-object p1, p0, Landroidx/core/content/q;->b:Landroidx/concurrent/futures/e;

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroidx/concurrent/futures/e;->r(Ljava/lang/Object;)Z

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/core/content/q;->a:Landroidx/core/app/unusedapprestrictions/b;

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method
