.class public final Landroidx/core/content/m;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/core/content/m$a;
    }
.end annotation


# static fields
.field public static final a:I = 0x0

.field public static final b:I = -0x1

.field public static final c:I = -0x2


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)I
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "l1s s@@~fi~~S~@/~o/o@ov@@l~ it@~ ~@o~n @ @o ~@4d@b~@cbb ~   moa-~~@Kt y@.@ ~ ~fur@M@  i ~~~@ @~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p0, p1, v1, v2, v0}, Landroidx/core/content/m;->c(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;)I

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 p0, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    return p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Binder;->getCallingPid()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Landroid/os/Binder;->getCallingUid()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, p1, v0, v1, p2}, Landroidx/core/content/m;->c(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;)I

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return p0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;)I
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    invoke-virtual {p0, p1, p2, p3}, Landroid/content/Context;->checkPermission(Ljava/lang/String;II)I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne p2, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1}, Landroidx/core/app/j;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p2, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return p2

    :cond_1
    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p4, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p4, p3}, Landroid/content/pm/PackageManager;->getPackagesForUid(I)[Ljava/lang/String;

    move-result-object p4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p4, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    array-length v1, p4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-gtz v1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    aget-object p4, p4, p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v3, 0x2

    return v0

    :cond_4
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne v0, p3, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v1, p4}, Landroidx/core/util/l;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_2

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    move v0, p2

    move v0, p2

    const/4 v3, 0x2

    move v0, p2

    move v0, p2

    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_6

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p3, p1, p4}, Landroidx/core/app/j;->a(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    goto :goto_3

    :cond_6
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0, p1, p4}, Landroidx/core/app/j;->e(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    :goto_3
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez p0, :cond_7

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_4

    :cond_7
    const/4 v3, 0x3

    const/4 p2, -0x1

    const/4 v3, 0x4

    const/4 p2, -0x2

    :goto_4
    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return p2
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)I
    .locals 5
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p0, p1, v0, v1, v2}, Landroidx/core/content/m;->c(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;)I

    move-result p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    return p0
.end method
