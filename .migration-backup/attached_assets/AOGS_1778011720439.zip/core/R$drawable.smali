.class public final Landroidx/core/R$drawable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/core/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final notification_action_background:I = 0x7f08047f

.field public static final notification_bg:I = 0x7f080480

.field public static final notification_bg_low:I = 0x7f080481

.field public static final notification_bg_low_normal:I = 0x7f080482

.field public static final notification_bg_low_pressed:I = 0x7f080483

.field public static final notification_bg_normal:I = 0x7f080484

.field public static final notification_bg_normal_pressed:I = 0x7f080485

.field public static final notification_icon_background:I = 0x7f080486

.field public static final notification_template_icon_bg:I = 0x7f080487

.field public static final notification_template_icon_low_bg:I = 0x7f080488

.field public static final notification_tile_bg:I = 0x7f080489

.field public static final notify_panel_notification_icon_bg:I = 0x7f08048a


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
