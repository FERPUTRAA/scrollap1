.class public final Landroidx/asynclayoutinflater/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_container:I = 0x7f090052

.field public static final action_divider:I = 0x7f090054

.field public static final action_image:I = 0x7f090055

.field public static final action_text:I = 0x7f09005b

.field public static final actions:I = 0x7f09005d

.field public static final async:I = 0x7f090082

.field public static final blocking:I = 0x7f0900b8

.field public static final chronometer:I = 0x7f090161

.field public static final forever:I = 0x7f0902a7

.field public static final icon:I = 0x7f090318

.field public static final icon_group:I = 0x7f09031a

.field public static final info:I = 0x7f090385

.field public static final italic:I = 0x7f090391

.field public static final line1:I = 0x7f0904ef

.field public static final line3:I = 0x7f0904f1

.field public static final normal:I = 0x7f0905ff

.field public static final notification_background:I = 0x7f090602

.field public static final notification_main_column:I = 0x7f090603

.field public static final notification_main_column_container:I = 0x7f090604

.field public static final right_icon:I = 0x7f0906ca

.field public static final right_side:I = 0x7f0906cb

.field public static final tag_transition_group:I = 0x7f0907ad

.field public static final tag_unhandled_key_event_manager:I = 0x7f0907af

.field public static final tag_unhandled_key_listeners:I = 0x7f0907b0

.field public static final text:I = 0x7f0907b7

.field public static final text2:I = 0x7f0907ba

.field public static final time:I = 0x7f09082f

.field public static final title:I = 0x7f090834


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
