.class Landroidx/asynclayoutinflater/view/a$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Handler$Callback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/view/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/asynclayoutinflater/view/a;


# direct methods
.method constructor <init>(Landroidx/asynclayoutinflater/view/a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/asynclayoutinflater/view/a$a;->a:Landroidx/asynclayoutinflater/view/a;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o~s~n ~@i  @@~Sb@~@s~@ tl~ @c@y ~@b4o.~o~@fo@~i l~~ oMi ~a@@~~ud~o -b~ v@1//~rK~@@@@@@ f  ~~ mt "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget-object p1, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    check-cast p1, Landroidx/asynclayoutinflater/view/a$c;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->d:Landroid/view/View;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/asynclayoutinflater/view/a$a;->a:Landroidx/asynclayoutinflater/view/a;

    const/4 v5, 0x3

    iget-object v0, v0, Landroidx/asynclayoutinflater/view/a;->a:Landroid/view/LayoutInflater;

    const/4 v5, 0x5

    const/4 v4, 0x3

    iget v1, p1, Landroidx/asynclayoutinflater/view/a$c;->c:I

    const/4 v5, 0x4

    iget-object v2, p1, Landroidx/asynclayoutinflater/view/a$c;->b:Landroid/view/ViewGroup;

    const/4 v4, 0x1

    move v5, v4

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->d:Landroid/view/View;

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->e:Landroidx/asynclayoutinflater/view/a$e;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p1, Landroidx/asynclayoutinflater/view/a$c;->d:Landroid/view/View;

    iget v2, p1, Landroidx/asynclayoutinflater/view/a$c;->c:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v3, p1, Landroidx/asynclayoutinflater/view/a$c;->b:Landroid/view/ViewGroup;

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2, v3}, Landroidx/asynclayoutinflater/view/a$e;->a(Landroid/view/View;ILandroid/view/ViewGroup;)V

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/asynclayoutinflater/view/a$a;->a:Landroidx/asynclayoutinflater/view/a;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, v0, Landroidx/asynclayoutinflater/view/a;->c:Landroidx/asynclayoutinflater/view/a$d;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Landroidx/asynclayoutinflater/view/a$d;->d(Landroidx/asynclayoutinflater/view/a$c;)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 p1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return p1
.end method
