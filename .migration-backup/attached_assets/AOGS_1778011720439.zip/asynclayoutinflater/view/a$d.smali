.class Landroidx/asynclayoutinflater/view/a$d;
.super Ljava/lang/Thread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/view/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# static fields
.field private static final c:Landroidx/asynclayoutinflater/view/a$d;


# instance fields
.field private a:Ljava/util/concurrent/ArrayBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ArrayBlockingQueue<",
            "Landroidx/asynclayoutinflater/view/a$c;",
            ">;"
        }
    .end annotation
.end field

.field private b:Landroidx/core/util/p$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/core/util/p$c<",
            "Landroidx/asynclayoutinflater/view/a$c;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Landroidx/asynclayoutinflater/view/a$d;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Landroidx/asynclayoutinflater/view/a$d;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Landroidx/asynclayoutinflater/view/a$d;->c:Landroidx/asynclayoutinflater/view/a$d;

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/util/concurrent/ArrayBlockingQueue;

    const/4 v2, 0x2

    move v3, v2

    const/16 v1, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/concurrent/ArrayBlockingQueue;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Landroidx/asynclayoutinflater/view/a$d;->a:Ljava/util/concurrent/ArrayBlockingQueue;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Landroidx/core/util/p$c;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroidx/core/util/p$c;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Landroidx/asynclayoutinflater/view/a$d;->b:Landroidx/core/util/p$c;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public static b()Landroidx/asynclayoutinflater/view/a$d;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~.sr~/b~1fu   @o l@nv @o o / ~~~~@~@@ 4s ySif~~~@o~@~~ @@@~d@ Kb o@Mi @t~~@@~ctml ~a@-@@@~  ~~ob"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Landroidx/asynclayoutinflater/view/a$d;->c:Landroidx/asynclayoutinflater/view/a$d;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public a(Landroidx/asynclayoutinflater/view/a$c;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/asynclayoutinflater/view/a$d;->a:Ljava/util/concurrent/ArrayBlockingQueue;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/util/concurrent/ArrayBlockingQueue;->put(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "squml  ueuansnei  eoqty asFeircealnedef"

    const-string/jumbo v1, "ucsnsaneia es eeuefFrtqotdaqynileeu  l "

    const/4 v3, 0x3

    const-string/jumbo v1, "rtayonue   asalFilcuntuetqei s eeqedoen"

    const-string v1, "Failed to enqueue async inflate request"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, v1, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    move v3, v2

    throw v0
.end method

.method public c()Landroidx/asynclayoutinflater/view/a$c;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/asynclayoutinflater/view/a$d;->b:Landroidx/core/util/p$c;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/core/util/p$c;->b()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast v0, Landroidx/asynclayoutinflater/view/a$c;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Landroidx/asynclayoutinflater/view/a$c;

    const/4 v2, 0x1

    invoke-direct {v0}, Landroidx/asynclayoutinflater/view/a$c;-><init>()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public d(Landroidx/asynclayoutinflater/view/a$c;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->e:Landroidx/asynclayoutinflater/view/a$e;

    const/4 v3, 0x1

    iput-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->a:Landroidx/asynclayoutinflater/view/a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->b:Landroid/view/ViewGroup;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v1, p1, Landroidx/asynclayoutinflater/view/a$c;->c:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p1, Landroidx/asynclayoutinflater/view/a$c;->d:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/asynclayoutinflater/view/a$d;->b:Landroidx/core/util/p$c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroidx/core/util/p$c;->a(Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public e()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v0, "LlmynbetstayIocAanu"

    const-string v0, "asomyuyetAanclIrnLt"

    const/4 v7, 0x4

    const-string/jumbo v0, "olycyIunneLasrAuftt"

    const-string v0, "AsyncLayoutInflater"

    :try_start_0
    const/4 v7, 0x4

    iget-object v1, p0, Landroidx/asynclayoutinflater/view/a$d;->a:Ljava/util/concurrent/ArrayBlockingQueue;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/ArrayBlockingQueue;->take()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    check-cast v1, Landroidx/asynclayoutinflater/view/a$c;
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v7, 0x7

    const/4 v2, 0x2

    const/4 v7, 0x7

    const/4 v2, 0x0

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v3, v1, Landroidx/asynclayoutinflater/view/a$c;->a:Landroidx/asynclayoutinflater/view/a;

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v3, v3, Landroidx/asynclayoutinflater/view/a;->a:Landroid/view/LayoutInflater;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v4, v1, Landroidx/asynclayoutinflater/view/a$c;->c:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v5, v1, Landroidx/asynclayoutinflater/view/a$c;->b:Landroid/view/ViewGroup;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v3, v4, v5, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput-object v3, v1, Landroidx/asynclayoutinflater/view/a$c;->d:Landroid/view/View;
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x3

    goto :goto_0

    :catch_0
    move-exception v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v4, "guIa cope srcoiU  denhet oi tuo r rtlgFnet endthfb ya nekrhr!eiiRotneaa"

    const-string/jumbo v4, "oi rott etlrbFddan cIt uoe e! are t enaatiry kegrsRoU nednnehfhio cugih"

    const/4 v7, 0x5

    const-string v4, "ehadRa iqtd  korc nesI inr  eydatohuifet btgerrlte o naeUcgnenhtouilF r"

    const-string v4, "Failed to inflate resource in the background! Retrying on the UI thread"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v0, v4, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v0, v1, Landroidx/asynclayoutinflater/view/a$c;->a:Landroidx/asynclayoutinflater/view/a;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, v0, Landroidx/asynclayoutinflater/view/a;->b:Landroid/os/Handler;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v0, v2, v1}, Landroid/os/Message;->obtain(Landroid/os/Handler;ILjava/lang/Object;)Landroid/os/Message;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/os/Message;->sendToTarget()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-void

    :catch_1
    move-exception v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-void
.end method

.method public run()V
    .locals 2

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroidx/asynclayoutinflater/view/a$d;->e()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    goto :goto_0
.end method
