.class Landroidx/asynclayoutinflater/view/a$b;
.super Landroid/view/LayoutInflater;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/view/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# static fields
.field private static final a:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v3, 0x3

    const/4 v3, 0x2

    const-string/jumbo v0, "siswdeb.rokdain"

    const-string/jumbo v0, "iksdredaobnw.ti"

    const/4 v4, 0x7

    const-string/jumbo v0, "knomd.rdbi.waei"

    const-string v0, "android.webkit."

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "aopromnd.api"

    const-string/jumbo v1, "pddm.aiporna"

    const/4 v4, 0x3

    const-string v1, ".d.anbdrppio"

    const-string v1, "android.app."

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v2, "eoa.gdu.idintwd"

    const-string/jumbo v2, "netaog.odiwd.di"

    const/4 v4, 0x2

    const-string/jumbo v2, "ndidt.dpegaw.or"

    const-string v2, "android.widget."

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    sput-object v0, Landroidx/asynclayoutinflater/view/a$b;->a:[Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void
.end method

.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Landroid/view/LayoutInflater;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public cloneInContext(Landroid/content/Context;)Landroid/view/LayoutInflater;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "4 df@@i q~@ / M-~m@o  @~~ ~~o~~@@1@ v@ o~n@@ o@@~~~.bcS~ t  @~~u~@tl K@~~i@o @i~fb~ ~al@r~o y@s/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance v0, Landroidx/asynclayoutinflater/view/a$b;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Landroidx/asynclayoutinflater/view/a$b;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method protected onCreateView(Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/ClassNotFoundException;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v0, Landroidx/asynclayoutinflater/view/a$b;->a:[Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    array-length v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    if-ge v2, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    aget-object v3, v0, v2

    :try_start_0
    const/4 v5, 0x1

    invoke-virtual {p0, p1, v3, p2}, Landroid/view/LayoutInflater;->createView(Ljava/lang/String;Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object v3
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v3

    :catch_0
    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-super {p0, p1, p2}, Landroid/view/LayoutInflater;->onCreateView(Ljava/lang/String;Landroid/util/AttributeSet;)Landroid/view/View;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object p1
.end method
