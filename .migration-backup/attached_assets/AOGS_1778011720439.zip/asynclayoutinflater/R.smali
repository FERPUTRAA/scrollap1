.class public final Landroidx/asynclayoutinflater/R;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/asynclayoutinflater/R$attr;,
        Landroidx/asynclayoutinflater/R$color;,
        Landroidx/asynclayoutinflater/R$dimen;,
        Landroidx/asynclayoutinflater/R$drawable;,
        Landroidx/asynclayoutinflater/R$id;,
        Landroidx/asynclayoutinflater/R$integer;,
        Landroidx/asynclayoutinflater/R$layout;,
        Landroidx/asynclayoutinflater/R$string;,
        Landroidx/asynclayoutinflater/R$style;,
        Landroidx/asynclayoutinflater/R$styleable;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method
