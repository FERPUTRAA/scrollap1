.class public final Landroidx/asynclayoutinflater/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final TextAppearance_Compat_Notification:I = 0x7f1201e2

.field public static final TextAppearance_Compat_Notification_Info:I = 0x7f1201e3

.field public static final TextAppearance_Compat_Notification_Line2:I = 0x7f1201e5

.field public static final TextAppearance_Compat_Notification_Time:I = 0x7f1201e8

.field public static final TextAppearance_Compat_Notification_Title:I = 0x7f1201ea

.field public static final Widget_Compat_NotificationActionContainer:I = 0x7f120343

.field public static final Widget_Compat_NotificationActionText:I = 0x7f120344


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method
