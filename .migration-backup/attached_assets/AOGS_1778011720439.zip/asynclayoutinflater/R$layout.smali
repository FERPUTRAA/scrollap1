.class public final Landroidx/asynclayoutinflater/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final notification_action:I = 0x7f0c0215

.field public static final notification_action_tombstone:I = 0x7f0c0216

.field public static final notification_template_custom_big:I = 0x7f0c021d

.field public static final notification_template_icon_group:I = 0x7f0c021e

.field public static final notification_template_part_chronometer:I = 0x7f0c0222

.field public static final notification_template_part_time:I = 0x7f0c0223


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
