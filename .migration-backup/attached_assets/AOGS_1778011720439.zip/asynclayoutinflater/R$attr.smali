.class public final Landroidx/asynclayoutinflater/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/asynclayoutinflater/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final alpha:I = 0x7f040031

.field public static final font:I = 0x7f04020f

.field public static final fontProviderAuthority:I = 0x7f040211

.field public static final fontProviderCerts:I = 0x7f040212

.field public static final fontProviderFetchStrategy:I = 0x7f040213

.field public static final fontProviderFetchTimeout:I = 0x7f040214

.field public static final fontProviderPackage:I = 0x7f040215

.field public static final fontProviderQuery:I = 0x7f040216

.field public static final fontStyle:I = 0x7f040218

.field public static final fontVariationSettings:I = 0x7f040219

.field public static final fontWeight:I = 0x7f04021a

.field public static final ttcIndex:I = 0x7f04057d


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
