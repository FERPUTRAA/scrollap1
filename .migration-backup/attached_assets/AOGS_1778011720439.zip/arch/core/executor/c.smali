.class public Landroidx/arch/core/executor/c;
.super Landroidx/arch/core/executor/e;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static volatile c:Landroidx/arch/core/executor/c;

.field private static final d:Ljava/util/concurrent/Executor;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private static final e:Ljava/util/concurrent/Executor;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# instance fields
.field private a:Landroidx/arch/core/executor/e;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field private final b:Landroidx/arch/core/executor/e;
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance v0, Landroidx/arch/core/executor/a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Landroidx/arch/core/executor/a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Landroidx/arch/core/executor/c;->d:Ljava/util/concurrent/Executor;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Landroidx/arch/core/executor/b;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Landroidx/arch/core/executor/b;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput-object v0, Landroidx/arch/core/executor/c;->e:Ljava/util/concurrent/Executor;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Landroidx/arch/core/executor/e;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-instance v0, Landroidx/arch/core/executor/d;

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-direct {v0}, Landroidx/arch/core/executor/d;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/arch/core/executor/c;->b:Landroidx/arch/core/executor/e;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/arch/core/executor/c;->a:Landroidx/arch/core/executor/e;

    const/4 v2, 0x2

    return-void
.end method

.method public static synthetic e(Ljava/lang/Runnable;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o@sin@~~i oorl @~~@u~fy  ~l~@/@~@Kib ~otoM @~~~~v~f s~@ @@.ao~~b@ @~S  ~@~~ bc@4@~t  d/@@@  m@ -"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    invoke-static {p0}, Landroidx/arch/core/executor/c;->k(Ljava/lang/Runnable;)V

    const/4 v1, 0x6

    return-void
.end method

.method public static synthetic f(Ljava/lang/Runnable;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-static {p0}, Landroidx/arch/core/executor/c;->j(Ljava/lang/Runnable;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static g()Ljava/util/concurrent/Executor;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Landroidx/arch/core/executor/c;->e:Ljava/util/concurrent/Executor;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public static h()Landroidx/arch/core/executor/c;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Landroidx/arch/core/executor/c;->c:Landroidx/arch/core/executor/c;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v0, Landroidx/arch/core/executor/c;->c:Landroidx/arch/core/executor/c;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const-class v0, Landroidx/arch/core/executor/c;

    const-class v0, Landroidx/arch/core/executor/c;

    const/4 v3, 0x0

    const-class v0, Landroidx/arch/core/executor/c;

    const-class v0, Landroidx/arch/core/executor/c;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    sget-object v1, Landroidx/arch/core/executor/c;->c:Landroidx/arch/core/executor/c;

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v1, Landroidx/arch/core/executor/c;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v1}, Landroidx/arch/core/executor/c;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-object v1, Landroidx/arch/core/executor/c;->c:Landroidx/arch/core/executor/c;

    :cond_1
    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Landroidx/arch/core/executor/c;->c:Landroidx/arch/core/executor/c;

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw v1
.end method

.method public static i()Ljava/util/concurrent/Executor;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Landroidx/arch/core/executor/c;->d:Ljava/util/concurrent/Executor;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method private static synthetic j(Ljava/lang/Runnable;)V
    .locals 3

    const/4 v2, 0x2

    invoke-static {}, Landroidx/arch/core/executor/c;->h()Landroidx/arch/core/executor/c;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Landroidx/arch/core/executor/c;->d(Ljava/lang/Runnable;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private static synthetic k(Ljava/lang/Runnable;)V
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Landroidx/arch/core/executor/c;->h()Landroidx/arch/core/executor/c;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Landroidx/arch/core/executor/c;->a(Ljava/lang/Runnable;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Runnable;)V
    .locals 3
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    iget-object v0, p0, Landroidx/arch/core/executor/c;->a:Landroidx/arch/core/executor/e;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroidx/arch/core/executor/e;->a(Ljava/lang/Runnable;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/arch/core/executor/c;->a:Landroidx/arch/core/executor/e;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/arch/core/executor/e;->c()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public d(Ljava/lang/Runnable;)V
    .locals 3
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/arch/core/executor/c;->a:Landroidx/arch/core/executor/e;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/arch/core/executor/e;->d(Ljava/lang/Runnable;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public l(Landroidx/arch/core/executor/e;)V
    .locals 2
    .param p1    # Landroidx/arch/core/executor/e;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p1, :cond_0

    const/4 v1, 0x7

    iget-object p1, p0, Landroidx/arch/core/executor/c;->b:Landroidx/arch/core/executor/e;

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/arch/core/executor/c;->a:Landroidx/arch/core/executor/e;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method
