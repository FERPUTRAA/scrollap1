.class public Landroidx/arch/core/executor/d;
.super Landroidx/arch/core/executor/e;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/arch/core/executor/d$b;
    }
.end annotation


# instance fields
.field private final a:Ljava/lang/Object;

.field private final b:Ljava/util/concurrent/ExecutorService;

.field private volatile c:Landroid/os/Handler;
    .annotation build Landroidx/annotation/q0;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Landroidx/arch/core/executor/e;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/arch/core/executor/d;->a:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Landroidx/arch/core/executor/d$a;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Landroidx/arch/core/executor/d$a;-><init>(Landroidx/arch/core/executor/d;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1, v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Landroidx/arch/core/executor/d;->b:Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method private static e(Landroid/os/Looper;)Landroid/os/Handler;
    .locals 9
    .param p0    # Landroid/os/Looper;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " @s~@a.@4S@l@~o@@@s i  b iu  @~ydtv M~@ ~~@~b@-@i o~~~ ~~ c n lr@@tfoo@ ~~~/~mbo/K f@~~1~@o@~ @~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-lt v0, v1, :cond_0

    const/4 v8, 0x3

    invoke-static {p0}, Landroidx/arch/core/executor/d$b;->a(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-object p0

    :cond_0
    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-class v0, Landroid/os/Handler;

    const-class v0, Landroid/os/Handler;

    const/4 v8, 0x0

    const-class v0, Landroid/os/Handler;

    const-class v0, Landroid/os/Handler;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v1, 0x3

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-class v3, Landroid/os/Looper;

    const-class v3, Landroid/os/Looper;

    const/4 v8, 0x4

    const-class v3, Landroid/os/Looper;

    const-class v3, Landroid/os/Looper;

    const/4 v7, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    aput-object v3, v2, v4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-class v3, Landroid/os/Handler$Callback;

    const-class v3, Landroid/os/Handler$Callback;

    const/4 v8, 0x0

    const-class v3, Landroid/os/Handler$Callback;

    const-class v3, Landroid/os/Handler$Callback;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    aput-object v3, v2, v5

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v6, 0x2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object v3, v2, v6

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    aput-object p0, v1, v4

    const/4 v7, 0x5

    move v8, v7

    const/4 v2, 0x0

    shl-int/2addr v8, v2

    const/4 v7, 0x1

    move v8, v7

    aput-object v2, v1, v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    aput-object v2, v1, v6

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    check-cast v0, Landroid/os/Handler;
    :try_end_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x6

    const/4 v7, 0x0

    return-object v0

    :catch_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v0, Landroid/os/Handler;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {v0, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-object v0

    :catch_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0, p0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-object v0
.end method


# virtual methods
.method public a(Ljava/lang/Runnable;)V
    .locals 3
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/arch/core/executor/d;->b:Ljava/util/concurrent/ExecutorService;

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public c()Z
    .locals 4

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0
.end method

.method public d(Ljava/lang/Runnable;)V
    .locals 4
    .param p1    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/arch/core/executor/d;->c:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/arch/core/executor/d;->a:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/arch/core/executor/d;->c:Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v1}, Landroidx/arch/core/executor/d;->e(Landroid/os/Looper;)Landroid/os/Handler;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v1, p0, Landroidx/arch/core/executor/d;->c:Landroid/os/Handler;

    :cond_0
    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v2, 0x5

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/arch/core/executor/d;->c:Landroid/os/Handler;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method
