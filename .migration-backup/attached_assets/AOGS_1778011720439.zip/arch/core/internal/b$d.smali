.class public Landroidx/arch/core/internal/b$d;
.super Landroidx/arch/core/internal/b$f;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/arch/core/internal/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroidx/arch/core/internal/b$f<",
        "TK;TV;>;",
        "Ljava/util/Iterator<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field private a:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field private b:Z

.field final synthetic c:Landroidx/arch/core/internal/b;


# direct methods
.method constructor <init>(Landroidx/arch/core/internal/b;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/arch/core/internal/b$d;->c:Landroidx/arch/core/internal/b;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Landroidx/arch/core/internal/b$f;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-boolean p1, p0, Landroidx/arch/core/internal/b$d;->b:Z

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method a(Landroidx/arch/core/internal/b$c;)V
    .locals 3
    .param p1    # Landroidx/arch/core/internal/b$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ss/ @.@oK/s@1@~@@@ @ M-~@ t~i o@~b ~ @a@i~~m~nu@~~~@4fd @~o@~  ~@y ~@cio ob ~b rt @l~  f@~~~~ol"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-ne p1, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, v0, Landroidx/arch/core/internal/b$c;->d:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x5

    move v1, p1

    move v1, p1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-boolean p1, p0, Landroidx/arch/core/internal/b$d;->b:Z

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public b()Ljava/util/Map$Entry;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/arch/core/internal/b$d;->b:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-boolean v0, p0, Landroidx/arch/core/internal/b$d;->b:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/arch/core/internal/b$d;->c:Landroidx/arch/core/internal/b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, v0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    iget-object v0, v0, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object v0
.end method

.method public hasNext()Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-boolean v0, p0, Landroidx/arch/core/internal/b$d;->b:Z

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x4

    shl-int/2addr v3, v2

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/arch/core/internal/b$d;->c:Landroidx/arch/core/internal/b;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, v0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    move v1, v2

    move v1, v2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/arch/core/internal/b$d;->a:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    iget-object v0, v0, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    move v1, v2

    move v1, v2

    const/4 v4, 0x4

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v1
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/arch/core/internal/b$d;->b()Ljava/util/Map$Entry;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method
