.class Landroidx/arch/core/internal/b$c;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/util/Map$Entry;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/arch/core/internal/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;"
    }
.end annotation


# instance fields
.field final a:Ljava/lang/Object;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TK;"
        }
    .end annotation
.end field

.field final b:Ljava/lang/Object;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TV;"
        }
    .end annotation
.end field

.field c:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field d:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;Ljava/lang/Object;)V
    .locals 2
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " os~m /~b~~bSl@fs~~lo~~@-@~@K @aru ~. v@@/ t@~i~@@@ @~~o oc @ Mio~y o~@@~@d~  f~@@~ ~@tn@i1  4 b"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x3

    if-ne p1, p0, :cond_0

    const/4 v5, 0x6

    return v0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    instance-of v1, p1, Landroidx/arch/core/internal/b$c;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    return v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast p1, Landroidx/arch/core/internal/b$c;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    iget-object v3, p1, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p1, p1, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v0
.end method

.method public getKey()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TK;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getValue()Ljava/lang/Object;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TV;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public hashCode()I
    .locals 4

    iget-object v0, p0, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    xor-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0
.end method

.method public setValue(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)TV;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo v0, "t cmie itnn oiapsoA  usooettsmifydnndp"

    const-string/jumbo v0, "spsenAoitcofti pt ounmy rndan o tiides"

    const/4 v2, 0x1

    const-string/jumbo v0, "io yodrnoap einfreodpsctnttuois A m tn"

    const-string v0, "An entry modification is not supported"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    throw p1
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "="

    const-string v1, "="

    const-string v1, "="

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0
.end method
