.class abstract Landroidx/arch/core/internal/b$e;
.super Landroidx/arch/core/internal/b$f;

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/arch/core/internal/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "e"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Landroidx/arch/core/internal/b$f<",
        "TK;TV;>;",
        "Ljava/util/Iterator<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field a:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field b:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroidx/arch/core/internal/b$c;Landroidx/arch/core/internal/b$c;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Landroidx/arch/core/internal/b$f;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p2, p0, Landroidx/arch/core/internal/b$e;->a:Landroidx/arch/core/internal/b$c;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-void
.end method

.method private e()Landroidx/arch/core/internal/b$c;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/arch/core/internal/b$e;->a:Landroidx/arch/core/internal/b$c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroidx/arch/core/internal/b$e;->c(Landroidx/arch/core/internal/b$c;)Landroidx/arch/core/internal/b$c;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method


# virtual methods
.method public a(Landroidx/arch/core/internal/b$c;)V
    .locals 3
    .param p1    # Landroidx/arch/core/internal/b$c;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-ne v0, p1, :cond_0

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x7

    const/4 v1, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    move v1, v0

    move v1, v0

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/arch/core/internal/b$e;->a:Landroidx/arch/core/internal/b$c;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->a:Landroidx/arch/core/internal/b$c;

    const/4 v1, 0x5

    move v2, v1

    if-ne v0, p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Landroidx/arch/core/internal/b$e;->b(Landroidx/arch/core/internal/b$c;)Landroidx/arch/core/internal/b$c;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/arch/core/internal/b$e;->a:Landroidx/arch/core/internal/b$c;

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-ne v0, p1, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Landroidx/arch/core/internal/b$e;->e()Landroidx/arch/core/internal/b$c;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method abstract b(Landroidx/arch/core/internal/b$c;)Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;)",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end method

.method abstract c(Landroidx/arch/core/internal/b$c;)Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;)",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end method

.method public d()Ljava/util/Map$Entry;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0}, Landroidx/arch/core/internal/b$e;->e()Landroidx/arch/core/internal/b$c;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v1, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method

.method public hasNext()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/arch/core/internal/b$e;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public bridge synthetic next()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/arch/core/internal/b$e;->d()Ljava/util/Map$Entry;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method
