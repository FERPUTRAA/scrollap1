.class public Landroidx/arch/core/internal/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Iterable;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/arch/core/internal/b$c;,
        Landroidx/arch/core/internal/b$f;,
        Landroidx/arch/core/internal/b$a;,
        Landroidx/arch/core/internal/b$b;,
        Landroidx/arch/core/internal/b$d;,
        Landroidx/arch/core/internal/b$e;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Ljava/lang/Iterable<",
        "Ljava/util/Map$Entry<",
        "TK;TV;>;>;"
    }
.end annotation


# instance fields
.field a:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field private b:Landroidx/arch/core/internal/b$c;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation
.end field

.field private final c:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Landroidx/arch/core/internal/b$f<",
            "TK;TV;>;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field private d:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Ljava/util/WeakHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    const/4 v1, 0x4

    move v2, v1

    iput-object v0, p0, Landroidx/arch/core/internal/b;->c:Ljava/util/WeakHashMap;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput v0, p0, Landroidx/arch/core/internal/b;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()Ljava/util/Map$Entry;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method protected b(Ljava/lang/Object;)Landroidx/arch/core/internal/b$c;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, v0, Landroidx/arch/core/internal/b$c;->a:Ljava/lang/Object;

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, v0, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v3, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public d()Landroidx/arch/core/internal/b$d;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroidx/arch/core/internal/b<",
            "TK;TV;>.d;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Landroidx/arch/core/internal/b$d;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Landroidx/arch/core/internal/b$d;-><init>(Landroidx/arch/core/internal/b;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Landroidx/arch/core/internal/b;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0
.end method

.method public descendingIterator()Ljava/util/Iterator;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Landroidx/arch/core/internal/b$b;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v2, p0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v0, v1, v2}, Landroidx/arch/core/internal/b$b;-><init>(Landroidx/arch/core/internal/b$c;Landroidx/arch/core/internal/b$c;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/arch/core/internal/b;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, v0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0
.end method

.method public e()Ljava/util/Map$Entry;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v0, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-ne p1, p0, :cond_0

    const/4 v6, 0x7

    return v0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    instance-of v1, p1, Landroidx/arch/core/internal/b;

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x6

    move v5, v2

    move v5, v2

    const/4 v6, 0x0

    if-nez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v2

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    check-cast p1, Landroidx/arch/core/internal/b;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroidx/arch/core/internal/b;->size()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroidx/arch/core/internal/b;->size()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eq v1, v3, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    return v2

    :cond_2
    const/4 v6, 0x6

    invoke-virtual {p0}, Landroidx/arch/core/internal/b;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroidx/arch/core/internal/b;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v3, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v3, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v3, Ljava/util/Map$Entry;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v3, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez v4, :cond_5

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v3, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v3, v4}, Ljava/util/Map$Entry;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v3, :cond_3

    :cond_5
    const/4 v6, 0x5

    return v2

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x0

    if-nez v1, :cond_7

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    if-nez p1, :cond_7

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    goto :goto_0

    :cond_7
    move v0, v2

    move v0, v2

    const/4 v6, 0x6

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    return v0
.end method

.method f(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/arch/core/internal/b$c;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)",
            "Landroidx/arch/core/internal/b$c<",
            "TK;TV;>;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0, p1, p2}, Landroidx/arch/core/internal/b$c;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget p1, p0, Landroidx/arch/core/internal/b;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x7

    iput p1, p0, Landroidx/arch/core/internal/b;->d:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object v0, p0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p1, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, v0, Landroidx/arch/core/internal/b$c;->d:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public g(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)TV;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroidx/arch/core/internal/b;->b(Ljava/lang/Object;)Landroidx/arch/core/internal/b$c;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object p1, v0, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Landroidx/arch/core/internal/b;->f(Ljava/lang/Object;Ljava/lang/Object;)Landroidx/arch/core/internal/b$c;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public h(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)TV;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Landroidx/arch/core/internal/b;->b(Ljava/lang/Object;)Landroidx/arch/core/internal/b$c;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v1, p0, Landroidx/arch/core/internal/b;->d:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x3

    iput v1, p0, Landroidx/arch/core/internal/b;->d:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Landroidx/arch/core/internal/b;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/util/WeakHashMap;->isEmpty()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Landroidx/arch/core/internal/b;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/util/WeakHashMap;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast v2, Landroidx/arch/core/internal/b$f;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v2, p1}, Landroidx/arch/core/internal/b$f;->a(Landroidx/arch/core/internal/b$c;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    iget-object v1, p1, Landroidx/arch/core/internal/b$c;->d:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v2, p1, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v2, v1, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v2, p1, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v2, p0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v2, p1, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v2, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-object v1, v2, Landroidx/arch/core/internal/b$c;->d:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_2

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    iput-object v1, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    :goto_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-object v0, p1, Landroidx/arch/core/internal/b$c;->c:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v0, p1, Landroidx/arch/core/internal/b$c;->d:Landroidx/arch/core/internal/b$c;

    iget-object p1, p1, Landroidx/arch/core/internal/b$c;->b:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p1
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroidx/arch/core/internal/b;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {v2}, Ljava/util/Map$Entry;->hashCode()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v1
.end method

.method public iterator()Ljava/util/Iterator;
    .locals 5
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "TK;TV;>;>;"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v0, Landroidx/arch/core/internal/b$a;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Landroidx/arch/core/internal/b;->a:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Landroidx/arch/core/internal/b;->b:Landroidx/arch/core/internal/b$c;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Landroidx/arch/core/internal/b$a;-><init>(Landroidx/arch/core/internal/b$c;Landroidx/arch/core/internal/b$c;)V

    const/4 v4, 0x2

    iget-object v1, p0, Landroidx/arch/core/internal/b;->c:Ljava/util/WeakHashMap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v0, v2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Landroidx/arch/core/internal/b;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string v1, "["

    const-string v1, "["

    const/4 v4, 0x4

    const-string v1, "["

    const-string v1, "["

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/arch/core/internal/b;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v2, ", "

    const-string v2, ", "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x7

    const-string v1, "]"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method
