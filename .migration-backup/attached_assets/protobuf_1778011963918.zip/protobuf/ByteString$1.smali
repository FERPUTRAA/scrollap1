.class Lcom/google/protobuf/ByteString$1;
.super Lcom/google/protobuf/ByteString$AbstractByteIterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/protobuf/ByteString;->iterator()Lcom/google/protobuf/ByteString$ByteIterator;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private final limit:I

.field private position:I

.field final synthetic this$0:Lcom/google/protobuf/ByteString;


# direct methods
.method constructor <init>(Lcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x0

    move v2, v1

    iput-object p1, p0, Lcom/google/protobuf/ByteString$1;->this$0:Lcom/google/protobuf/ByteString;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/ByteString$AbstractByteIterator;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/ByteString$1;->position:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/protobuf/ByteString$1;->limit:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public hasNext()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s ~K@@@~b.v  n ts @4~yM~S~l @1@-@~~~m~~ o l ~~b @ic  @~ad//@~o@ur b@ ~~@i@ot@ @@o~f ~~o@ fo~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/ByteString$1;->position:I

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/ByteString$1;->limit:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ge v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method public nextByte()B
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/ByteString$1;->position:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/protobuf/ByteString$1;->limit:I

    const/4 v3, 0x6

    if-ge v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/lit8 v1, v0, 0x1

    const/4 v2, 0x3

    and-int/2addr v3, v2

    iput v1, p0, Lcom/google/protobuf/ByteString$1;->position:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/protobuf/ByteString$1;->this$0:Lcom/google/protobuf/ByteString;

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v1, v0}, Lcom/google/protobuf/ByteString;->internalByteAt(I)B

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Ljava/util/NoSuchElementException;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw v0
.end method
