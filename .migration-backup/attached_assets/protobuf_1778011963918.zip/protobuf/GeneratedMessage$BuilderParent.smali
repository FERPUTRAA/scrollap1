.class public interface abstract Lcom/google/protobuf/GeneratedMessage$BuilderParent;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/protobuf/AbstractMessage$BuilderParent;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/GeneratedMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x60c
    name = "BuilderParent"
.end annotation
