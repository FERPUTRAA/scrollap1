.class Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "SingularFieldAccessor"
.end annotation


# instance fields
.field protected final caseMethod:Ljava/lang/reflect/Method;

.field protected final caseMethodBuilder:Ljava/lang/reflect/Method;

.field protected final clearMethod:Ljava/lang/reflect/Method;

.field protected final field:Lcom/google/protobuf/Descriptors$FieldDescriptor;

.field protected final getMethod:Ljava/lang/reflect/Method;

.field protected final getMethodBuilder:Ljava/lang/reflect/Method;

.field protected final hasHasMethod:Z

.field protected final hasMethod:Ljava/lang/reflect/Method;

.field protected final hasMethodBuilder:Ljava/lang/reflect/Method;

.field protected final isOneofField:Z

.field protected final setMethod:Ljava/lang/reflect/Method;

.field protected final type:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "camelCaseName",
            "messageClass",
            "builderClass",
            "containingOneofCamelCaseName"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/protobuf/GeneratedMessage;",
            ">;",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/protobuf/GeneratedMessage$Builder;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->field:Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v1, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x1

    if-eqz v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    move v0, v1

    move v0, v1

    const/4 v8, 0x3

    move v0, v1

    move v0, v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    move v0, v2

    move v0, v2

    const/4 v8, 0x2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x2

    iput-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->isOneofField:Z

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {v3}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->access$1300(Lcom/google/protobuf/Descriptors$FileDescriptor;)Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-nez v3, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-nez v0, :cond_1

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    sget-object v3, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v8, 0x5

    if-ne p1, v3, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_1

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    move p1, v2

    move p1, v2

    const/4 v8, 0x4

    move p1, v2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    move p1, v1

    move p1, v1

    const/4 v8, 0x0

    move p1, v1

    move p1, v1

    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    iput-boolean p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasHasMethod:Z

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v4, "gte"

    const-string v4, "gte"

    const/4 v8, 0x3

    const-string/jumbo v4, "teg"

    const-string v4, "get"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-array v5, v2, [Ljava/lang/Class;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {p3, v3, v5}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    iput-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->getMethod:Ljava/lang/reflect/Method;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    new-array v6, v2, [Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v7, 0x5

    invoke-static {p4, v5, v6}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    iput-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->getMethodBuilder:Ljava/lang/reflect/Method;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    iput-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->type:Ljava/lang/Class;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "ets"

    const-string/jumbo v6, "ste"

    const/4 v8, 0x0

    const-string v6, "est"

    const-string/jumbo v6, "set"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-array v1, v1, [Ljava/lang/Class;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    aput-object v3, v1, v2

    const/4 v7, 0x6

    move v8, v7

    invoke-static {p4, v5, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    iput-object v1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->setMethod:Ljava/lang/reflect/Method;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v1, "ash"

    const-string v1, "ash"

    const/4 v8, 0x2

    const-string/jumbo v1, "sah"

    const-string v1, "has"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v3, 0x0

    shl-int/2addr v8, v3

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz p1, :cond_3

    const/4 v8, 0x4

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v5, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-array v6, v2, [Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p3, v5, v6}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_3

    :cond_3
    move-object v5, v3

    move-object v5, v3

    :goto_3
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasMethod:Ljava/lang/reflect/Method;

    const/4 v8, 0x5

    const/4 v7, 0x6

    if-eqz p1, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    new-array v1, v2, [Ljava/lang/Class;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p4, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_4

    :cond_4
    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    move-object p1, v3

    :goto_4
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasMethodBuilder:Ljava/lang/reflect/Method;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    move v8, v7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v1, "clsea"

    const/4 v8, 0x0

    const-string v1, "aesrc"

    const-string v1, "clear"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-array p2, v2, [Ljava/lang/Class;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p4, p1, p2}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->clearMethod:Ljava/lang/reflect/Method;

    const/4 v8, 0x7

    const-string/jumbo p1, "sCea"

    const-string p1, "aCse"

    const/4 v8, 0x6

    const-string p1, "easC"

    const-string p1, "Case"

    const/4 v7, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz v0, :cond_5

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-array v1, v2, [Ljava/lang/Class;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p3, p2, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    goto :goto_5

    :cond_5
    move-object p2, v3

    move-object p2, v3

    move-object p2, v3

    move-object p2, v3

    :goto_5
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput-object p2, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->caseMethod:Ljava/lang/reflect/Method;

    const/4 v8, 0x5

    const/4 v7, 0x4

    if-eqz v0, :cond_6

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-array p2, v2, [Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p4, p1, p2}, Lcom/google/protobuf/GeneratedMessage;->access$1100(Ljava/lang/Class;Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    :cond_6
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->caseMethodBuilder:Ljava/lang/reflect/Method;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-void
.end method

.method private getOneofFieldNumber(Lcom/google/protobuf/GeneratedMessage$Builder;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "builder"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/~ m@o@ol f~Ks@o@a  ~~1 @@u@ ~4M@   ~ @Sr@@~y~~~~ oo~@@i@lbd /~@. vb ~imf~~ ~tt~~obi@@n ~c@@-~ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->caseMethodBuilder:Ljava/lang/reflect/Method;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p1, Lcom/google/protobuf/Internal$EnumLite;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p1}, Lcom/google/protobuf/Internal$EnumLite;->getNumber()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p1
.end method

.method private getOneofFieldNumber(Lcom/google/protobuf/GeneratedMessage;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "message"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->caseMethod:Ljava/lang/reflect/Method;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p1, Lcom/google/protobuf/Internal$EnumLite;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1}, Lcom/google/protobuf/Internal$EnumLite;->getNumber()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p1
.end method


# virtual methods
.method public addRepeated(Lcom/google/protobuf/GeneratedMessage$Builder;Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string p2, "eedto rdlnegF id al.asiln Rdaddefacp me)ol(ela"

    const-string/jumbo p2, "ldemeFlada.(oplnfadeieiagsdnd   allRrc )tdeu e"

    const-string/jumbo p2, "odtf b air) li.RFadneea lleeldcuepdad(gdaseni "

    const-string p2, "addRepeatedField() called on a singular field."

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    throw p1
.end method

.method public clear(Lcom/google/protobuf/GeneratedMessage$Builder;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "builder"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->clearMethod:Ljava/lang/reflect/Method;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x1

    return-void
.end method

.method public get(Lcom/google/protobuf/GeneratedMessage$Builder;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->getMethodBuilder:Ljava/lang/reflect/Method;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    return-object p1
.end method

.method public get(Lcom/google/protobuf/GeneratedMessage;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "message"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->getMethod:Ljava/lang/reflect/Method;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method

.method public getBuilder(Lcom/google/protobuf/GeneratedMessage$Builder;)Lcom/google/protobuf/Message$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x5

    const-string v0, "a llgnuedMtrBu esoedcailpgee Fdt.l(  nso)yneoe-"

    const-string/jumbo v0, "urFloe.Msa  ei -(enetgypnolcdesaalgtee dln)oBd "

    const/4 v2, 0x0

    const-string v0, "d t -e poslneetnBailggMedaeayeFe) iuo .(cndlrsp"

    const-string v0, "getFieldBuilder() called on a non-Message type."

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    throw p1
.end method

.method public getRaw(Lcom/google/protobuf/GeneratedMessage$Builder;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->get(Lcom/google/protobuf/GeneratedMessage$Builder;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public getRaw(Lcom/google/protobuf/GeneratedMessage;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "message"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->get(Lcom/google/protobuf/GeneratedMessage;)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public getRepeated(Lcom/google/protobuf/GeneratedMessage$Builder;I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "builder",
            "index"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    const-string/jumbo p2, "ld efe eqdodean s .tu ginaRaglldie(rteilclpa)e"

    const-string p2, "getRepeatedField() called on a singular field."

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    throw p1
.end method

.method public getRepeated(Lcom/google/protobuf/GeneratedMessage;I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "message",
            "index"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    const-string p2, "easifsltn d ele(nlaeFar e.eit odldRb)gladeig u"

    const-string p2, " l clbansetdregl deildlieufgtad(i e.eaeoFRan )"

    const/4 v1, 0x5

    const-string/jumbo p2, "legmdlp   Feaetualaleiadeenredilndgt).s icf Ro"

    const-string p2, "getRepeatedField() called on a singular field."

    const/4 v0, 0x0

    shr-int/2addr v1, v0

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    throw p1
.end method

.method public getRepeatedBuilder(Lcom/google/protobuf/GeneratedMessage$Builder;I)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "builder",
            "index"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    const-string/jumbo p2, "lperon ieogdeoldRyB)tceddilpetan n Ma.esseuaeF lte-u ga"

    const-string p2, "eBrMdFugudp.ie-eieoc nlas)gl npeete e yaRlaetddonase tl"

    const/4 v1, 0x7

    const-string/jumbo p2, "oiletb a) -pnRdysd.i epeeF(undal lelnecdaBaesoeeMe rttg"

    const-string p2, "getRepeatedFieldBuilder() called on a non-Message type."

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x1

    move v1, v0

    throw p1
.end method

.method public getRepeatedCount(Lcom/google/protobuf/GeneratedMessage$Builder;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, "(taed uniciei  rdglSunaeapgoeddlFp Re.a e)eliellft"

    const-string v0, "ataezlopSrdlidpg)ee fue .da ead(ieleFlRclit gni en"

    const/4 v2, 0x4

    const-string/jumbo v0, "ztg aeppiaiaiieaeode(dR)  sStelelelF e.gcrlfdndlun"

    const-string v0, "getRepeatedFieldSize() called on a singular field."

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p1
.end method

.method public getRepeatedCount(Lcom/google/protobuf/GeneratedMessage;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "message"
        }
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, "Sdeti loqdlealu.n R pgeletcziddare Fa)i filanegse("

    const/4 v2, 0x2

    const-string v0, "SetlFeclqgrtflez  dngRie deisnd)ail (au aepdi.oela"

    const-string v0, "getRepeatedFieldSize() called on a singular field."

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    throw p1
.end method

.method public getRepeatedRaw(Lcom/google/protobuf/GeneratedMessage$Builder;I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "builder",
            "index"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    const-string/jumbo p2, "tRsuaadas.edl(lfeRgc t inllnge)edpeleie irad Faw "

    const-string p2, "getRepeatedFieldRaw() called on a singular field."

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    throw p1
.end method

.method public getRepeatedRaw(Lcom/google/protobuf/GeneratedMessage;I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "message",
            "index"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    const-string/jumbo p2, "l.(maerdeace)teRsspfo R  e lidtwFinalialueedd gla"

    const-string p2, "ddsrf(eunteagel Fe  aeio )slela iR.apncRtlddiwael"

    const/4 v1, 0x7

    const-string p2, "getRepeatedFieldRaw() called on a singular field."

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    throw p1
.end method

.method public has(Lcom/google/protobuf/GeneratedMessage$Builder;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasHasMethod:Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->isOneofField:Z

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    move v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->getOneofFieldNumber(Lcom/google/protobuf/GeneratedMessage$Builder;)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->field:Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne p1, v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    move v1, v2

    move v1, v2

    const/4 v4, 0x2

    move v1, v2

    move v1, v2

    :cond_0
    const/4 v4, 0x7

    return v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->get(Lcom/google/protobuf/GeneratedMessage$Builder;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->field:Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getDefaultValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    xor-int/2addr p1, v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    return p1

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasMethodBuilder:Ljava/lang/reflect/Method;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    return p1
.end method

.method public has(Lcom/google/protobuf/GeneratedMessage;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "message"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasHasMethod:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->isOneofField:Z

    const/4 v4, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x1

    move v4, v2

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->getOneofFieldNumber(Lcom/google/protobuf/GeneratedMessage;)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->field:Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-ne p1, v0, :cond_0

    const/4 v3, 0x6

    move v4, v3

    move v1, v2

    move v1, v2

    const/4 v4, 0x1

    move v1, v2

    move v1, v2

    :cond_0
    const/4 v3, 0x5

    const/4 v4, 0x7

    return v1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->get(Lcom/google/protobuf/GeneratedMessage;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->field:Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getDefaultValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    xor-int/2addr p1, v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    return p1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->hasMethod:Ljava/lang/reflect/Method;

    const/4 v4, 0x2

    const/4 v3, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/Boolean;

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    return p1
.end method

.method public newBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "nFeeole-rlsn p(nu Be gdFayeo  wecl.anaM)tsloeoidmd"

    const-string/jumbo v1, "o omlweMo a.nspt(  FyBslnrFeei -nddigeanaeelc)dleu"

    const/4 v3, 0x0

    const-string v1, "  clwb)ne .ilgdaos lieenrueBn-FeMeo pFaldy(rnseaod"

    const-string/jumbo v1, "newBuilderForField() called on a non-Message type."

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw v0
.end method

.method public set(Lcom/google/protobuf/GeneratedMessage$Builder;Ljava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "value"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;->setMethod:Ljava/lang/reflect/Method;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    aput-object p2, v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0, p1, v1}, Lcom/google/protobuf/GeneratedMessage;->access$1200(Ljava/lang/reflect/Method;Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    return-void
.end method

.method public setRepeated(Lcom/google/protobuf/GeneratedMessage$Builder;ILjava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "builder",
            "index",
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    const-string/jumbo p2, "tldeol(eerns)ucelneRat del d oFad af leipsig.a"

    const/4 v1, 0x0

    const-string p2, "  aRlguea.e deldefeu(nldc a oFnestldilpsai)eir"

    const-string/jumbo p2, "setRepeatedField() called on a singular field."

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    throw p1
.end method
