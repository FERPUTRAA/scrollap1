.class public final Lcom/google/protobuf/Duration;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/google/protobuf/DurationOrBuilder;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/Duration$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

.field public static final NANOS_FIELD_NUMBER:I = 0x2

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Duration;",
            ">;"
        }
    .end annotation
.end field

.field public static final SECONDS_FIELD_NUMBER:I = 0x1

.field private static final serialVersionUID:J


# instance fields
.field private memoizedIsInitialized:B

.field private nanos_:I

.field private seconds_:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    new-instance v0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/protobuf/Duration;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Lcom/google/protobuf/Duration;->DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lcom/google/protobuf/Duration$1;

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/protobuf/Duration$1;-><init>()V

    const/4 v2, 0x7

    sput-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x0

    move v2, v1

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/google/protobuf/Duration;->seconds_:J

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/protobuf/Duration;->nanos_:I

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, -0x1

    const/4 v3, 0x1

    iput-byte v0, p0, Lcom/google/protobuf/Duration;->memoizedIsInitialized:B

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/protobuf/Duration;->seconds_:J

    const/4 v2, 0x6

    move v3, v2

    const/4 p1, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x5

    iput p1, p0, Lcom/google/protobuf/Duration;->nanos_:I

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p1, -0x1

    const/4 v3, 0x2

    iput-byte p1, p0, Lcom/google/protobuf/Duration;->memoizedIsInitialized:B

    const/4 v3, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/google/protobuf/Duration$1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/Duration;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$302(Lcom/google/protobuf/Duration;J)J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os~d@~c~t @~u~a~l  ooo@   b@@ @~@K@~4fm-@/M~f l @@@/ ~o@nii @rv~b@@to ~~1~~ @y .@~i b~@~~~  S~s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iput-wide p1, p0, Lcom/google/protobuf/Duration;->seconds_:J

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-wide p1
.end method

.method static synthetic access$402(Lcom/google/protobuf/Duration;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/protobuf/Duration;->nanos_:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    return p1
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/Duration;
    .locals 3

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Duration;->DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DurationProto;->internal_static_google_protobuf_Duration_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/Duration$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/Duration;->DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/Duration;->toBuilder()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/Duration;)Lcom/google/protobuf/Duration$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Duration;->DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/Duration;->toBuilder()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Lcom/google/protobuf/Duration$Builder;->mergeFrom(Lcom/google/protobuf/Duration;)Lcom/google/protobuf/Duration$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Duration;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/Duration;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Duration;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-ne p1, p0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    instance-of v1, p1, Lcom/google/protobuf/Duration;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    return p1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    check-cast p1, Lcom/google/protobuf/Duration;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->getSeconds()J

    move-result-wide v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/Duration;->getSeconds()J

    move-result-wide v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    cmp-long v1, v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x4

    return v2

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->getNanos()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/Duration;->getNanos()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq v1, v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    return v2

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez p1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    return v2

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/Duration;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    sget-object v0, Lcom/google/protobuf/Duration;->DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->getDefaultInstanceForType()Lcom/google/protobuf/Duration;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->getDefaultInstanceForType()Lcom/google/protobuf/Duration;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getNanos()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/Duration;->nanos_:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Duration;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Duration;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSeconds()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/google/protobuf/Duration;->seconds_:J

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eq v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/google/protobuf/Duration;->seconds_:J

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    cmp-long v2, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt64Size(IJ)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    add-int/2addr v3, v0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/Duration;->nanos_:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x2

    move v5, v1

    const/4 v4, 0x4

    move v5, v4

    invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    add-int/2addr v3, v0

    :cond_2
    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/2addr v3, v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput v3, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v3
.end method

.method public hashCode()I
    .locals 6

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    return v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/Duration;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v1, 0x30b

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    add-int/2addr v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    mul-int/lit8 v1, v1, 0x35

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->getSeconds()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v2, v3}, Lcom/google/protobuf/Internal;->hashLong(J)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    add-int/2addr v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->getNanos()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    add-int/2addr v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    mul-int/lit8 v1, v1, 0x1d

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v0, Lcom/google/protobuf/DurationProto;->internal_static_google_protobuf_Duration_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-class v1, Lcom/google/protobuf/Duration;

    const-class v1, Lcom/google/protobuf/Duration;

    const/4 v4, 0x3

    const-class v1, Lcom/google/protobuf/Duration;

    const-class v1, Lcom/google/protobuf/Duration;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-class v2, Lcom/google/protobuf/Duration$Builder;

    const-class v2, Lcom/google/protobuf/Duration$Builder;

    const/4 v4, 0x6

    const-class v2, Lcom/google/protobuf/Duration$Builder;

    const-class v2, Lcom/google/protobuf/Duration$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v2, 0x3

    move v3, v2

    iget-byte v0, p0, Lcom/google/protobuf/Duration;->memoizedIsInitialized:B

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-byte v1, p0, Lcom/google/protobuf/Duration;->memoizedIsInitialized:B

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/Duration$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-static {}, Lcom/google/protobuf/Duration;->newBuilder()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Duration$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Lcom/google/protobuf/Duration$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/Duration$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/Duration$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->newBuilderForType()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/Duration;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Duration$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->newBuilderForType()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    new-instance p1, Lcom/google/protobuf/Duration;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p1}, Lcom/google/protobuf/Duration;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/Duration$Builder;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lcom/google/protobuf/Duration;->DEFAULT_INSTANCE:Lcom/google/protobuf/Duration;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne p0, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Lcom/google/protobuf/Duration$Builder;

    const/4 v2, 0x1

    move v3, v2

    invoke-direct {v0, v1}, Lcom/google/protobuf/Duration$Builder;-><init>(Lcom/google/protobuf/Duration$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    new-instance v0, Lcom/google/protobuf/Duration$Builder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/protobuf/Duration$Builder;-><init>(Lcom/google/protobuf/Duration$1;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Lcom/google/protobuf/Duration$Builder;->mergeFrom(Lcom/google/protobuf/Duration;)Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->toBuilder()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Duration;->toBuilder()Lcom/google/protobuf/Duration$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/Duration;->seconds_:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    cmp-long v2, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt64(IJ)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/Duration;->nanos_:I

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V

    :cond_1
    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x6

    and-int/2addr v5, v4

    return-void
.end method
