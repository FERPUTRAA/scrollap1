.class public final enum Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Descriptors$FileDescriptor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Syntax"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;",
        ">;"
    }
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

.field public static final enum EDITIONS:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

.field public static final enum PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

.field public static final enum PROTO3:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

.field public static final enum UNKNOWN:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;


# instance fields
.field private final name:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    new-instance v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string/jumbo v1, "osswnnk"

    const-string/jumbo v1, "nwskonn"

    const/4 v11, 0x5

    const-string/jumbo v1, "wnkmuno"

    const-string/jumbo v1, "unknown"

    const/4 v10, 0x0

    xor-int/2addr v11, v10

    const-string v2, "NWKOoUm"

    const-string v2, "OWNmNKU"

    const/4 v11, 0x1

    const-string v2, "NNNWUbO"

    const-string v2, "UNKNOWN"

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct {v0, v2, v3, v1}, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    sput-object v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->UNKNOWN:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x7

    const/4 v10, 0x0

    new-instance v1, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v10, 0x7

    move v11, v10

    const-string/jumbo v2, "oto2or"

    const/4 v11, 0x6

    const-string/jumbo v2, "u2toop"

    const-string/jumbo v2, "proto2"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string v4, "OpOR2T"

    const-string v4, "PROTO2"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {v1, v4, v5, v2}, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    sput-object v1, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v2, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string/jumbo v4, "pbq3ro"

    const-string/jumbo v4, "ropo3b"

    const/4 v11, 0x3

    const-string/jumbo v4, "orspt3"

    const-string/jumbo v4, "proto3"

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string v6, "ROum3P"

    const-string/jumbo v6, "uROP3T"

    const/4 v11, 0x3

    const-string v6, "T3PRoO"

    const-string v6, "PROTO3"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v7, 0x2

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {v2, v6, v7, v4}, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    sput-object v2, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO3:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v4, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string/jumbo v6, "iiodpbte"

    const-string/jumbo v6, "ideotinp"

    const/4 v11, 0x4

    const-string v6, "editions"

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string v8, "OIqSEDuT"

    const-string/jumbo v8, "qNSETOID"

    const/4 v11, 0x5

    const-string v8, "DIOIESNp"

    const-string v8, "EDITIONS"

    const/4 v11, 0x2

    const/4 v9, 0x0

    const/4 v11, 0x4

    const/4 v9, 0x3

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-direct {v4, v8, v9, v6}, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x1

    sput-object v4, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->EDITIONS:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v6, 0x4

    new-array v6, v6, [Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    aput-object v0, v6, v3

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    aput-object v1, v6, v5

    const/4 v10, 0x2

    move v11, v10

    aput-object v2, v6, v7

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    aput-object v4, v6, v9

    const/4 v11, 0x0

    sput-object v6, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->$VALUES:[Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "name"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->name:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$000(Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~ M4@ ~qr~f~@st@K-o~@@@~ dab @ @1~~  fo @~o@@~@ o  l @t~@ub~@l~i i@ ~@~  ~ @c~@/~~yib~vSoo~n.@/"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->name:Ljava/lang/String;

    const/4 v1, 0x7

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-class v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const-class v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const-class v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const-class v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    check-cast p0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->$VALUES:[Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, [Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method
