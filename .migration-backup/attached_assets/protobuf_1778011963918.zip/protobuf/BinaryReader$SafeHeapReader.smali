.class final Lcom/google/protobuf/BinaryReader$SafeHeapReader;
.super Lcom/google/protobuf/BinaryReader;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/BinaryReader;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "SafeHeapReader"
.end annotation


# instance fields
.field private final buffer:[B

.field private final bufferIsImmutable:Z

.field private endGroupTag:I

.field private final initialPos:I

.field private limit:I

.field private pos:I

.field private tag:I


# direct methods
.method public constructor <init>(Ljava/nio/ByteBuffer;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "bytebuf",
            "bufferIsImmutable"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x1

    move v2, v1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader;-><init>(Lcom/google/protobuf/BinaryReader$1;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    iput-boolean p2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->bufferIsImmutable:Z

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/nio/Buffer;->position()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    add-int/2addr p2, v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->initialPos:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    add-int/2addr p2, p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput p2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method private isAtEnd()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~~@.vo~@4ob~@ao~~-  d~nS l/@@ @ ~@~y@c~ ~~ u i~loi~/@@~f@bfo@@i @~ @  ~@~K~sb@t ~1@Mmt o@~ r "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v0
.end method

.method private readByte()B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v3, 0x6

    or-int/2addr v4, v3

    if-eq v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-int/lit8 v2, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    aget-byte v0, v1, v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    throw v0
.end method

.method private readField(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldType",
            "messageType",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/WireFormat$FieldType;",
            "Ljava/lang/Class<",
            "*>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")",
            "Ljava/lang/Object;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/BinaryReader$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    aget p1, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    packed-switch p1, :pswitch_data_0

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo p2, "ylomeep.p etpidun tdurf"

    const-string/jumbo p2, "pesdpr.elu pfutyodti ne"

    const/4 v2, 0x6

    const-string/jumbo p2, "ru loepistou tenedp.dpf"

    const-string/jumbo p2, "unsupported field type."

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    move v2, v1

    throw p1

    :pswitch_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readUInt64()J

    move-result-wide p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object p1

    :pswitch_1
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readUInt32()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1

    :pswitch_2
    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readStringRequireUtf8()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object p1

    :pswitch_3
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSInt64()J

    move-result-wide p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1

    :pswitch_4
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSInt32()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1

    :pswitch_5
    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSFixed64()J

    move-result-wide p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p1

    :pswitch_6
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSFixed32()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p1

    :pswitch_7
    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readMessage(Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1

    :pswitch_8
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readInt64()J

    move-result-wide p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p1

    :pswitch_9
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readInt32()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p1

    :pswitch_a
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFloat()F

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p1

    :pswitch_b
    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFixed64()J

    move-result-wide p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1

    :pswitch_c
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFixed32()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p1

    :pswitch_d
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readEnum()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p1

    :pswitch_e
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readDouble()D

    move-result-wide p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1, p2}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p1

    :pswitch_f
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object p1

    :pswitch_10
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readBool()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private readGroup(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/google/protobuf/Schema;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0, p1, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->mergeGroupField(Ljava/lang/Object;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {p1, v0}, Lcom/google/protobuf/Schema;->makeImmutable(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method private readLittleEndian32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method private readLittleEndian32_NoCheck()I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v5, 0x0

    add-int/lit8 v2, v0, 0x4

    const/4 v4, 0x4

    move v5, v4

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    aget-byte v2, v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-int/lit16 v2, v2, 0xff

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/lit8 v3, v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    aget-byte v3, v1, v3

    const/4 v5, 0x0

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    shl-int/lit8 v3, v3, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    or-int/2addr v2, v3

    const/4 v4, 0x0

    move v5, v4

    add-int/lit8 v3, v0, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    aget-byte v3, v1, v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    shl-int/lit8 v3, v3, 0x10

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    or-int/2addr v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    aget-byte v0, v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0xff

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    shl-int/lit8 v0, v0, 0x18

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    or-int/2addr v0, v2

    const/4 v5, 0x1

    return v0
.end method

.method private readLittleEndian64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 v0, 0x8

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-wide v0
.end method

.method private readLittleEndian64_NoCheck()J
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v10, 0x0

    add-int/lit8 v2, v0, 0x8

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v9, 0x0

    move v10, v9

    aget-byte v2, v1, v0

    const/4 v10, 0x4

    int-to-long v2, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-wide/16 v4, 0xff

    const/4 v10, 0x4

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    and-long/2addr v2, v4

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    add-int/lit8 v6, v0, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    aget-byte v6, v1, v6

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    int-to-long v6, v6

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    and-long/2addr v6, v4

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/16 v8, 0x8

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    shl-long/2addr v6, v8

    const/4 v10, 0x0

    const/4 v9, 0x1

    or-long/2addr v2, v6

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    add-int/lit8 v6, v0, 0x2

    const/4 v9, 0x3

    const/4 v9, 0x5

    aget-byte v6, v1, v6

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    int-to-long v6, v6

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    and-long/2addr v6, v4

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/16 v8, 0x10

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    shl-long/2addr v6, v8

    const/4 v10, 0x4

    or-long/2addr v2, v6

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    add-int/lit8 v6, v0, 0x3

    const/4 v10, 0x5

    aget-byte v6, v1, v6

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    int-to-long v6, v6

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    and-long/2addr v6, v4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v8, 0x18

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    shl-long/2addr v6, v8

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    or-long/2addr v2, v6

    const/4 v10, 0x5

    add-int/lit8 v6, v0, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    aget-byte v6, v1, v6

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    int-to-long v6, v6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    and-long/2addr v6, v4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/16 v8, 0x20

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    shl-long/2addr v6, v8

    const/4 v9, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    or-long/2addr v2, v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-int/lit8 v6, v0, 0x5

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    aget-byte v6, v1, v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    int-to-long v6, v6

    const/4 v10, 0x1

    and-long/2addr v6, v4

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/16 v8, 0x28

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    shl-long/2addr v6, v8

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    or-long/2addr v2, v6

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    add-int/lit8 v6, v0, 0x6

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    aget-byte v6, v1, v6

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    int-to-long v6, v6

    const/4 v10, 0x1

    and-long/2addr v6, v4

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/16 v8, 0x30

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    shl-long/2addr v6, v8

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    or-long/2addr v2, v6

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    add-int/lit8 v0, v0, 0x7

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    aget-byte v0, v1, v0

    const/4 v10, 0x2

    int-to-long v0, v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    and-long/2addr v0, v4

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/16 v4, 0x38

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    shl-long/2addr v0, v4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    or-long/2addr v0, v2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    return-wide v0
.end method

.method private readMessage(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {p1}, Lcom/google/protobuf/Schema;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0, p1, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->mergeMessageField(Ljava/lang/Object;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-interface {p1, v0}, Lcom/google/protobuf/Schema;->makeImmutable(Ljava/lang/Object;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method private readVarint32()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    if-eq v1, v0, :cond_8

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v3, v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    aget-byte v0, v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-ltz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput v3, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    return v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    sub-int/2addr v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/16 v4, 0x9

    const/4 v6, 0x2

    const/4 v5, 0x1

    if-ge v1, v4, :cond_1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64SlowPath()J

    move-result-wide v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    long-to-int v0, v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    return v0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    aget-byte v3, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    shl-int/lit8 v3, v3, 0x7

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    xor-int/2addr v0, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-gez v0, :cond_2

    const/4 v6, 0x2

    xor-int/lit8 v0, v0, -0x80

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    aget-byte v1, v2, v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    shl-int/lit8 v1, v1, 0xe

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    xor-int/2addr v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ltz v0, :cond_4

    const/4 v6, 0x1

    xor-int/lit16 v0, v0, 0x3f80

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    move v1, v3

    move v1, v3

    const/4 v6, 0x3

    move v1, v3

    move v1, v3

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    aget-byte v3, v2, v3

    const/4 v5, 0x5

    move v6, v5

    shl-int/lit8 v3, v3, 0x15

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    xor-int/2addr v0, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-gez v0, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const v2, -0x1fc080

    const/4 v5, 0x3

    const/4 v6, 0x2

    xor-int/2addr v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :cond_5
    const/4 v6, 0x7

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x2

    aget-byte v1, v2, v1

    const/4 v6, 0x2

    shl-int/lit8 v4, v1, 0x1c

    const/4 v6, 0x7

    xor-int/2addr v0, v4

    const/4 v5, 0x3

    or-int/2addr v6, v5

    const v4, 0xfe03f80

    const/4 v6, 0x0

    const/4 v5, 0x1

    xor-int/2addr v0, v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-gez v1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    aget-byte v3, v2, v3

    const/4 v5, 0x0

    move v6, v5

    if-gez v3, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    aget-byte v1, v2, v1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-gez v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x1

    aget-byte v3, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-gez v3, :cond_7

    const/4 v5, 0x5

    const/4 v6, 0x5

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    aget-byte v1, v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-gez v1, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    aget-byte v2, v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ltz v2, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    throw v0

    :cond_7
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    return v0

    :cond_8
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    throw v0
.end method

.method private readVarint64SlowPath()J
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v7, 0x7

    const/16 v3, 0x40

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ge v2, v3, :cond_1

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readByte()B

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    and-int/lit8 v4, v3, 0x7f

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    int-to-long v4, v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    shl-long/2addr v4, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    or-long/2addr v0, v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    and-int/lit16 v3, v3, 0x80

    const/4 v7, 0x6

    const/4 v6, 0x5

    if-nez v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-wide v0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x7

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x0

    throw v0
.end method

.method private requireBytes(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ltz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-gt p1, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw p1
.end method

.method private requirePosition(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "expectedPosition"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-ne v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    throw p1
.end method

.method private requireWireType(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "requiredWireType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-ne v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    throw p1
.end method

.method private skipBytes(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    add-int/2addr v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private skipGroup()V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1, v2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    :cond_0
    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->getFieldNumber()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const v2, 0x7fffffff

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eq v1, v2, :cond_1

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipField()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez v1, :cond_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-ne v1, v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v4, 0x0

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    throw v0
.end method

.method private skipVarint()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    sub-int/2addr v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/16 v2, 0xa

    const/4 v6, 0x2

    if-lt v0, v2, :cond_1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ge v3, v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/lit8 v4, v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    aget-byte v1, v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-ltz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    iput v4, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    move v1, v4

    move v1, v4

    const/4 v6, 0x7

    move v1, v4

    move v1, v4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipVarintSlowPath()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-void
.end method

.method private skipVarintSlowPath()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/16 v1, 0xa

    const/4 v2, 0x0

    move v3, v2

    if-ge v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readByte()B

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ltz v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    throw v0
.end method

.method private verifyPackedFixed32Length(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "bytes"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    and-int/lit8 p1, p1, 0x3

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    throw p1
.end method

.method private verifyPackedFixed64Length(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "bytes"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    and-int/lit8 p1, p1, 0x7

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    return-void

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    throw p1
.end method


# virtual methods
.method public getFieldNumber()I
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const v1, 0x7fffffff

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ne v0, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    return v1

    :cond_1
    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v0
.end method

.method public getTag()I
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getTotalBytesRead()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->initialPos:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    sub-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return v0
.end method

.method public mergeGroupField(Ljava/lang/Object;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v2, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v1, v2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {p2, p1, p0, p3}, Lcom/google/protobuf/Schema;->mergeFrom(Ljava/lang/Object;Lcom/google/protobuf/Reader;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget p2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ne p1, p2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_0
    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p1
.end method

.method public mergeMessageField(Ljava/lang/Object;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-int/2addr v2, v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {p2, p1, p0, p3}, Lcom/google/protobuf/Schema;->mergeFrom(Ljava/lang/Object;Lcom/google/protobuf/Reader;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne p1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void

    :cond_0
    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    throw p1
.end method

.method public readBool()Z
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v0
.end method

.method public readBoolList(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Boolean;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x4

    instance-of v0, p1, Lcom/google/protobuf/BooleanArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v3, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v0, :cond_5

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v0, Lcom/google/protobuf/BooleanArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz p1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne p1, v3, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget v3, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/2addr v3, p1

    :goto_0
    const/4 v5, 0x3

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-ge p1, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    move p1, v1

    move p1, v1

    const/4 v5, 0x6

    move p1, v1

    move p1, v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    move p1, v2

    move p1, v2

    const/4 v5, 0x6

    move p1, v2

    move p1, v2

    :goto_1
    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(Z)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {p0, v3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto/16 :goto_4

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    throw p1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readBool()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(Z)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eq v1, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_9

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ne v0, v3, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v3, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    add-int/2addr v3, v0

    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    if-ge v0, v3, :cond_7

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_6

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_3

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    move v0, v2

    move v0, v2

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    :goto_3
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_2

    :cond_7
    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p0, v3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    :goto_4
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void

    :cond_8
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    throw p1

    :cond_9
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readBool()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void

    :cond_a
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    if-eq v1, v2, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    return-void
.end method

.method public readBytes()Lcom/google/protobuf/ByteString;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-boolean v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->bufferIsImmutable:Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/ByteString;->wrap([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/2addr v2, v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v1
.end method

.method public readBytesList(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/google/protobuf/ByteString;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v1, 0x2

    move v4, v1

    const/4 v3, 0x0

    or-int/2addr v4, v3

    if-ne v0, v1, :cond_2

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x1

    move v4, v3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-eq v1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    throw p1
.end method

.method public readDouble()D
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-wide v0
.end method

.method public readDoubleList(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    instance-of v0, p1, Lcom/google/protobuf/DoubleArrayList;

    const/4 v1, 0x5

    and-int/2addr v5, v1

    const/4 v1, 0x2

    move v5, v1

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v0, Lcom/google/protobuf/DoubleArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eq p1, v2, :cond_1

    const/4 v4, 0x3

    move v5, v4

    if-ne p1, v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed64Length(I)V

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    add-int/2addr v1, p1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ge p1, v1, :cond_4

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v2, v3}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v3}, Lcom/google/protobuf/DoubleArrayList;->addDouble(D)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    throw p1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readDouble()D

    move-result-wide v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/DoubleArrayList;->addDouble(D)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x3

    if-eq v1, v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    return-void

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eq v0, v2, :cond_6

    const/4 v4, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-ne v0, v1, :cond_5

    const/4 v4, 0x5

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed64Length(I)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/2addr v1, v0

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    if-ge v0, v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v2, v3}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_1

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p1

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readDouble()D

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_7

    const/4 v5, 0x7

    return-void

    :cond_7
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eq v1, v2, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void
.end method

.method public readEnum()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    return v0
.end method

.method public readEnumList(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    instance-of v0, p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v0, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ne p1, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    add-int/2addr v1, p1

    :goto_0
    const/4 v4, 0x3

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-ge p1, v1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    throw p1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readEnum()I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void

    :cond_2
    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    if-eq v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void

    :cond_3
    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ne v0, v1, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x4

    if-ge v0, v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    goto :goto_1

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :cond_5
    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    throw p1

    :cond_6
    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readEnum()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void

    :cond_7
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eq v1, v2, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method public readFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    return v0
.end method

.method public readFixed32List(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    instance-of v0, p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x7

    const/4 v1, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_4

    const/4 v4, 0x1

    check-cast p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    if-eq v0, v2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-ne v0, v1, :cond_2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFixed32()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eq v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw p1

    :cond_3
    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed32Length(I)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    add-int/2addr v1, v0

    :goto_0
    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    if-ge v0, v1, :cond_9

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_4
    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eq v0, v2, :cond_8

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-ne v0, v1, :cond_7

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFixed32()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    move v4, v3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void

    :cond_6
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x6

    if-eq v1, v2, :cond_5

    const/4 v4, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-void

    :cond_7
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p1

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed32Length(I)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-ge v0, v1, :cond_9

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    and-int/2addr v4, v3

    goto :goto_1

    :cond_9
    const/4 v4, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public readFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    return-wide v0
.end method

.method public readFixed64List(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    instance-of v0, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast v0, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eq p1, v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne p1, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed64Length(I)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/2addr v1, p1

    :goto_0
    const/4 v4, 0x0

    move v5, v4

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ge p1, v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v3}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw p1

    :cond_1
    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFixed64()J

    move-result-wide v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq v1, v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v0, v2, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-ne v0, v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed64Length(I)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    add-int/2addr v1, v0

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    if-ge v0, v1, :cond_4

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    goto :goto_1

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    throw p1

    :cond_6
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFixed64()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_7

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void

    :cond_7
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq v1, v2, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x3

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method

.method public readFloat()F
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    return v0
.end method

.method public readFloatList(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x2

    instance-of v0, p1, Lcom/google/protobuf/FloatArrayList;

    const/4 v4, 0x7

    const/4 v1, 0x5

    const/4 v4, 0x3

    shl-int/2addr v3, v1

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast p1, Lcom/google/protobuf/FloatArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eq v0, v2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-ne v0, v1, :cond_2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFloat()F

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Lcom/google/protobuf/FloatArrayList;->addFloat(F)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eq v1, v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    throw p1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed32Length(I)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-ge v0, v1, :cond_9

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Lcom/google/protobuf/FloatArrayList;->addFloat(F)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eq v0, v2, :cond_8

    const/4 v3, 0x7

    move v4, v3

    if-ne v0, v1, :cond_7

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readFloat()F

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void

    :cond_6
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eq v1, v2, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :cond_7
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    throw p1

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed32Length(I)V

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-ge v0, v1, :cond_9

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_1

    :cond_9
    const/4 v4, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public readGroup(Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "clazz",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/Protobuf;->schemaFor(Ljava/lang/Class;)Lcom/google/protobuf/Schema;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readGroup(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public readGroupBySchemaWithCheck(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readGroup(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method public readGroupList(Ljava/util/List;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "TT;>;",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-ne v0, v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, p2, p3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readGroup(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eq v2, v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw p1
.end method

.method public readGroupList(Ljava/util/List;Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "targetType",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "TT;>;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p2}, Lcom/google/protobuf/Protobuf;->schemaFor(Ljava/lang/Class;)Lcom/google/protobuf/Schema;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readGroupList(Ljava/util/List;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public readInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public readInt32List(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    instance-of v0, p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x5

    move v3, v1

    move v3, v1

    const/4 v4, 0x0

    if-eqz v0, :cond_4

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v0, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ne p1, v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/2addr v1, p1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x4

    if-ge p1, v1, :cond_0

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    goto/16 :goto_2

    :cond_1
    const/4 v4, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw p1

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readInt32()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz p1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eq v1, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x1

    if-eqz v0, :cond_7

    const/4 v4, 0x6

    const/4 v3, 0x1

    if-ne v0, v1, :cond_6

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-ge v0, v1, :cond_5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_1

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    :goto_2
    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p1

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readInt32()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_8

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void

    :cond_8
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    if-eq v1, v2, :cond_7

    const/4 v3, 0x4

    move v4, v3

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void
.end method

.method public readInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v0, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-wide v0
.end method

.method public readInt64List(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    instance-of v0, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_4

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v0, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne p1, v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    add-int/2addr v1, p1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ge p1, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v3}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto/16 :goto_2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    throw p1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readInt64()J

    move-result-wide v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz p1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    and-int/2addr v5, v4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq v1, v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void

    :cond_4
    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_7

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ne v0, v1, :cond_6

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/2addr v1, v0

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    if-ge v0, v1, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v4, 0x2

    goto :goto_1

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void

    :cond_6
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x4

    throw p1

    :cond_7
    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readInt64()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_8

    const/4 v5, 0x0

    return-void

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    if-eq v1, v2, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void
.end method

.method public readMap(Ljava/util/Map;Lcom/google/protobuf/MapEntryLite$Metadata;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "metadata",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Map<",
            "TK;TV;>;",
            "Lcom/google/protobuf/MapEntryLite$Metadata<",
            "TK;TV;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v0, 0x2

    const/4 v8, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget v3, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    add-int/2addr v3, v1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    iput v3, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v1, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->defaultKey:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v3, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->defaultValue:Ljava/lang/Object;

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->getFieldNumber()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const v5, 0x7fffffff

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ne v4, v5, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-interface {p1, v1, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v8, 0x2

    return-void

    :cond_0
    const/4 v8, 0x7

    const/4 v5, 0x5

    const/4 v8, 0x3

    const/4 v5, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string/jumbo v6, "pe.o baaty ns ebrmnUalm tr"

    const-string/jumbo v6, "oU mree sn .aryat pltbamnp"

    const/4 v8, 0x5

    const-string/jumbo v6, "slnay.ueop  ante amtprbe U"

    const-string v6, "Unable to parse map entry."

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eq v4, v5, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eq v4, v0, :cond_2

    :try_start_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipField()Z

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v4, :cond_1

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v4, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {v4, v6}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    throw v4

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v4, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->valueType:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object v5, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->defaultValue:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {p0, v4, v5, p3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readField(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x1

    iget-object v4, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->keyType:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v5, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {p0, v4, v5, v5}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readField(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object v1
    :try_end_1
    .catch Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto/16 :goto_0

    :catch_0
    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipField()Z

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v4, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance p1, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {p1, v6}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    throw p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    iput v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    throw p1
.end method

.method public readMessage(Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "clazz",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/Protobuf;->schemaFor(Ljava/lang/Class;)Lcom/google/protobuf/Schema;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readMessage(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p1
.end method

.method public readMessageBySchemaWithCheck(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readMessage(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p1
.end method

.method public readMessageList(Ljava/util/List;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "schema",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "TT;>;",
            "Lcom/google/protobuf/Schema<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-ne v0, v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {p0, p2, p3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readMessage(Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p1, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eq v2, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw p1
.end method

.method public readMessageList(Ljava/util/List;Ljava/lang/Class;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "targetType",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/List<",
            "TT;>;",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p2}, Lcom/google/protobuf/Protobuf;->schemaFor(Ljava/lang/Class;)Lcom/google/protobuf/Schema;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readMessageList(Ljava/util/List;Lcom/google/protobuf/Schema;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public readSFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public readSFixed32List(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    instance-of v0, p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    check-cast p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eq v0, v2, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne v0, v1, :cond_2

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSFixed32()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eq v1, v2, :cond_0

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    throw p1

    :cond_3
    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed32Length(I)V

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    add-int/2addr v1, v0

    :goto_0
    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ge v0, v1, :cond_9

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_4
    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eq v0, v2, :cond_8

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-ne v0, v1, :cond_7

    :cond_5
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSFixed32()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void

    :cond_6
    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eq v1, v2, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void

    :cond_7
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p1

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed32Length(I)V

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    if-ge v0, v1, :cond_9

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian32_NoCheck()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x5

    goto :goto_1

    :cond_9
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method

.method public readSFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-wide v0
.end method

.method public readSFixed64List(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    instance-of v0, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    check-cast v0, Lcom/google/protobuf/LongArrayList;

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eq p1, v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne p1, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed64Length(I)V

    const/4 v4, 0x1

    move v5, v4

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    add-int/2addr v1, p1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-ge p1, v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v3}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    throw p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSFixed64()J

    move-result-wide v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eq v1, v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eq v0, v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne v0, v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->verifyPackedFixed64Length(I)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x5

    and-int/2addr v5, v4

    add-int/2addr v1, v0

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ge v0, v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readLittleEndian64_NoCheck()J

    move-result-wide v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_1

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-void

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    throw p1

    :cond_6
    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSFixed64()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void

    :cond_7
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    move v5, v4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eq v1, v2, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method

.method public readSInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public readSInt32List(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    instance-of v0, p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast v0, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-ne p1, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    add-int/2addr v1, p1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-ge p1, v1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    throw p1

    :cond_1
    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSInt32()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eq v1, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    return-void

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_6

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-ne v0, v1, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ge v0, v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    throw p1

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSInt32()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v0, :cond_7

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void

    :cond_7
    const/4 v4, 0x4

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eq v1, v2, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x7

    move v4, v3

    return-void
.end method

.method public readSInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    or-int/2addr v3, v2

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-wide v0
.end method

.method public readSInt64List(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    instance-of v0, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v1, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    check-cast v0, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-ne p1, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/2addr v1, p1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    if-ge p1, v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v2, v3}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v3}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    throw p1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSInt64()J

    move-result-wide v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x3

    return-void

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x5

    const/4 v4, 0x3

    if-eq v1, v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v0, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ne v0, v1, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    add-int/2addr v1, v0

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-ge v0, v1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v2, v3}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_1

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    throw p1

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readSInt64()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void

    :cond_7
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eq v1, v2, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method

.method public readString()Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readStringInternal(Z)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public readStringInternal(Z)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "requireUtf8"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v5, 0x5

    const-string p1, ""

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object p1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireBytes(I)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int v2, v1, v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p1, v1, v2}, Lcom/google/protobuf/Utf8;->isValidUtf8([BII)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz p1, :cond_1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidUtf8()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    throw p1

    :cond_2
    :goto_0
    const/4 v4, 0x5

    move v5, v4

    new-instance p1, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v5, 0x0

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object v3, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v4, 0x1

    move v5, v4

    invoke-direct {p1, v1, v2, v0, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object p1
.end method

.method public readStringList(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readStringListInternal(Ljava/util/List;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public readStringListInternal(Ljava/util/List;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "target",
            "requireUtf8"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x2

    move v4, v1

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-ne v0, v1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    instance-of v0, p1, Lcom/google/protobuf/LazyStringList;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez p2, :cond_2

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    check-cast v0, Lcom/google/protobuf/LazyStringList;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {v0, p1}, Lcom/google/protobuf/LazyStringList;->add(Lcom/google/protobuf/ByteString;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eq p2, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-void

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readStringInternal(Z)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_3
    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eq v1, v2, :cond_2

    const/4 v4, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    throw p1
.end method

.method public readStringListRequireUtf8(Ljava/util/List;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readStringListInternal(Ljava/util/List;Z)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public readStringRequireUtf8()Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readStringInternal(Z)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public readUInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public readUInt32List(Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    instance-of v0, p1, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    check-cast v0, Lcom/google/protobuf/IntArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-ne p1, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-int/2addr v1, p1

    :goto_0
    const/4 v4, 0x7

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ge p1, v1, :cond_4

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    throw p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readUInt32()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eq v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ne v0, v1, :cond_5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-int/2addr v1, v0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x5

    if-ge v0, v1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_1

    :cond_4
    const/4 v4, 0x3

    return-void

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw p1

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readUInt32()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_7

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    return-void

    :cond_7
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v3, 0x1

    move v4, v3

    if-eq v1, v2, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-void
.end method

.method public readUInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requireWireType(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-wide v0
.end method

.method public readUInt64List(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    instance-of v0, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    check-cast v0, Lcom/google/protobuf/LongArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ne p1, v1, :cond_1

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    add-int/2addr v1, p1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-ge p1, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v3}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto/16 :goto_2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    throw p1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readUInt64()J

    move-result-wide v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq v1, v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    iput p1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-ne v0, v1, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    add-int/2addr v1, v0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-ge v0, v1, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64()J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0, v1}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->requirePosition(I)V

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw p1

    :cond_7
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readUInt64()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void

    :cond_8
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq v1, v2, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    return-void
.end method

.method public readVarint64()J
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->limit:I

    const/4 v12, 0x2

    const/4 v11, 0x3

    if-eq v1, v0, :cond_b

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v2, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->buffer:[B

    const/4 v11, 0x6

    const/4 v12, 0x4

    add-int/lit8 v3, v0, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x1

    aget-byte v0, v2, v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-ltz v0, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    iput v3, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    int-to-long v0, v0

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x6

    return-wide v0

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    sub-int/2addr v1, v3

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/16 v4, 0x9

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-ge v1, v4, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint64SlowPath()J

    move-result-wide v0

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    return-wide v0

    :cond_1
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    add-int/lit8 v1, v3, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x5

    aget-byte v3, v2, v3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    shl-int/lit8 v3, v3, 0x7

    const/4 v12, 0x6

    const/4 v11, 0x5

    xor-int/2addr v0, v3

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-gez v0, :cond_2

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    xor-int/lit8 v0, v0, -0x80

    :goto_0
    int-to-long v2, v0

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    goto/16 :goto_4

    :cond_2
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    add-int/lit8 v3, v1, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x4

    aget-byte v1, v2, v1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    shl-int/lit8 v1, v1, 0xe

    const/4 v12, 0x6

    const/4 v11, 0x1

    xor-int/2addr v0, v1

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-ltz v0, :cond_3

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    xor-int/lit16 v0, v0, 0x3f80

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    int-to-long v0, v0

    move-wide v9, v0

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    move v1, v3

    move v1, v3

    const/4 v12, 0x1

    move v1, v3

    move v1, v3

    move-wide v2, v9

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    goto/16 :goto_4

    :cond_3
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    add-int/lit8 v1, v3, 0x1

    const/4 v12, 0x2

    aget-byte v3, v2, v3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    shl-int/lit8 v3, v3, 0x15

    const/4 v11, 0x6

    const/4 v12, 0x3

    xor-int/2addr v0, v3

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-gez v0, :cond_4

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    const v2, -0x1fc080

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    xor-int/2addr v0, v2

    const/4 v11, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x5

    goto :goto_0

    :cond_4
    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    int-to-long v3, v0

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    aget-byte v1, v2, v1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    int-to-long v5, v1

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/16 v1, 0x1c

    const/4 v11, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    shl-long/2addr v5, v1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    xor-long/2addr v3, v5

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    cmp-long v1, v3, v5

    const/4 v12, 0x4

    const/4 v11, 0x7

    if-ltz v1, :cond_5

    const/4 v11, 0x4

    or-int/2addr v12, v11

    const-wide/32 v1, 0xfe03f80

    const/4 v12, 0x6

    const-wide/32 v1, 0xfe03f80

    const-wide/32 v1, 0xfe03f80

    :goto_1
    const/4 v12, 0x5

    xor-long v2, v3, v1

    const/4 v12, 0x2

    move v1, v0

    move v1, v0

    const/4 v12, 0x6

    move v1, v0

    move v1, v0

    const/4 v12, 0x6

    goto/16 :goto_4

    :cond_5
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    aget-byte v0, v2, v0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    int-to-long v7, v0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/16 v0, 0x23

    const/4 v12, 0x0

    const/4 v11, 0x5

    shl-long/2addr v7, v0

    xor-long/2addr v3, v7

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    cmp-long v0, v3, v5

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-gez v0, :cond_6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-wide v5, -0x7f01fc080L

    const-wide v5, -0x7f01fc080L

    const/4 v12, 0x7

    const-wide v5, -0x7f01fc080L

    const-wide v5, -0x7f01fc080L

    :goto_2
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    xor-long v2, v3, v5

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    goto/16 :goto_4

    :cond_6
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    aget-byte v1, v2, v1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    int-to-long v7, v1

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/16 v1, 0x2a

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    shl-long/2addr v7, v1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    xor-long/2addr v3, v7

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    cmp-long v1, v3, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-ltz v1, :cond_7

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-wide v1, 0x3f80fe03f80L

    const-wide v1, 0x3f80fe03f80L

    const/4 v12, 0x0

    const-wide v1, 0x3f80fe03f80L

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x1

    goto/16 :goto_1

    :cond_7
    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    aget-byte v0, v2, v0

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x5

    int-to-long v7, v0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    const/16 v0, 0x31

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    shl-long/2addr v7, v0

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    xor-long/2addr v3, v7

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    cmp-long v0, v3, v5

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-gez v0, :cond_8

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-wide v5, -0x1fc07f01fc080L

    const-wide v5, -0x1fc07f01fc080L

    const/4 v12, 0x3

    const-wide v5, -0x1fc07f01fc080L

    const-wide v5, -0x1fc07f01fc080L

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    goto/16 :goto_2

    :cond_8
    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    aget-byte v1, v2, v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    int-to-long v7, v1

    const/4 v12, 0x4

    const/16 v1, 0x38

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    shl-long/2addr v7, v1

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    xor-long/2addr v3, v7

    const/4 v12, 0x2

    const-wide v7, 0xfe03f80fe03f80L

    const-wide v7, 0xfe03f80fe03f80L

    const-wide v7, 0xfe03f80fe03f80L

    const-wide v7, 0xfe03f80fe03f80L

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    xor-long/2addr v3, v7

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    cmp-long v1, v3, v5

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-gez v1, :cond_a

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    aget-byte v0, v2, v0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    int-to-long v7, v0

    const/4 v12, 0x6

    cmp-long v0, v7, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-ltz v0, :cond_9

    const/4 v12, 0x5

    const/4 v11, 0x6

    goto :goto_3

    :cond_9
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    throw v0

    :cond_a
    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    move v1, v0

    move v1, v0

    const/4 v12, 0x1

    move v1, v0

    move v1, v0

    :goto_3
    move-wide v2, v3

    :goto_4
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    iput v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->pos:I

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    return-wide v2

    :cond_b
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    throw v0
.end method

.method public skipField()Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->isAtEnd()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_6

    const/4 v4, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->tag:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->endGroupTag:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eq v0, v1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x3

    if-eq v0, v2, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    move v4, v3

    if-eq v0, v2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v2, 0x5

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ne v0, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipBytes(I)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    throw v0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipGroup()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return v1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->readVarint32()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipBytes(I)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v1

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/16 v0, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipBytes(I)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return v1

    :cond_5
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryReader$SafeHeapReader;->skipVarint()V

    const/4 v4, 0x0

    return v1

    :cond_6
    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return v0
.end method
