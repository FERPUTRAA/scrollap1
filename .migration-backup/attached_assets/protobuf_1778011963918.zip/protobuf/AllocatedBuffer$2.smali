.class Lcom/google/protobuf/AllocatedBuffer$2;
.super Lcom/google/protobuf/AllocatedBuffer;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/protobuf/AllocatedBuffer;->wrapNoCheck([BII)Lcom/google/protobuf/AllocatedBuffer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private position:I

.field final synthetic val$bytes:[B

.field final synthetic val$length:I

.field final synthetic val$offset:I


# direct methods
.method constructor <init>([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$bytes",
            "val$offset",
            "val$length"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$bytes:[B

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p2, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$offset:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p3, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$length:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/AllocatedBuffer;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public array()[B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "Kos~~-@.l   / @~ o@@~~~@@@/~ ~ s~ar@i@f~@  S~mM~@  ~d1@t@~no~iu~l@~~ @  o4@ ~o@i~~@@tfb @byv~ cb"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$bytes:[B

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public arrayOffset()I
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$offset:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public hasArray()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public hasNioBuffer()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v0, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public limit()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$length:I

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public nioBuffer()Ljava/nio/ByteBuffer;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    throw v0
.end method

.method public position()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/AllocatedBuffer$2;->position:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public position(I)Lcom/google/protobuf/AllocatedBuffer;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "position"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ltz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$length:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-gt p1, v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput p1, p0, Lcom/google/protobuf/AllocatedBuffer$2;->position:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v2, "nlsmvIsooa:tpn iii"

    const-string/jumbo v2, "nnsplI:ov s atiiio"

    const/4 v4, 0x0

    const-string v2, " :noolI ipiaiovtsd"

    const-string v2, "Invalid position: "

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    throw v0
.end method

.method public remaining()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/AllocatedBuffer$2;->val$length:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/AllocatedBuffer$2;->position:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    sub-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return v0
.end method
