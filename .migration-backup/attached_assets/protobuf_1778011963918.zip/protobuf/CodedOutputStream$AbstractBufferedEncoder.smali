.class abstract Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;
.super Lcom/google/protobuf/CodedOutputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedOutputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x40a
    name = "AbstractBufferedEncoder"
.end annotation


# instance fields
.field final buffer:[B

.field final limit:I

.field position:I

.field totalBytesWritten:I


# direct methods
.method constructor <init>(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "bufferSize"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream;-><init>(Lcom/google/protobuf/CodedOutputStream$1;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-ltz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/16 v0, 0x14

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-array p1, p1, [B

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    array-length p1, p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->limit:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x2

    move v2, v1

    const-string v0, "fisbe=sft0S u>e s eb zr"

    const-string v0, "fusb S e ebrim>s=fzet0 "

    const/4 v2, 0x7

    const-string v0, " Sumri b>fs eete0u mf=b"

    const-string v0, "bufferSize must be >= 0"

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    throw p1
.end method


# virtual methods
.method final buffer(B)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "o ~~o@~ ~~o ~~@t~ @@ ~@i ~@sb@@@@~ Sdll@~~~~@v/ @~c@o K~@.~  a~o1@f i~/@Mmb@u~rf n 4@i-o@t~  b y"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v4, 0x5

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    aput-byte p1, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method final bufferFixed32NoTag(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    and-int/lit16 v3, p1, 0xff

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x6

    aput-byte v3, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v1, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    shr-int/lit8 v3, p1, 0x8

    const/4 v4, 0x3

    move v5, v4

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    aput-byte v3, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x7

    move v5, v4

    shr-int/lit8 v3, p1, 0x10

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    int-to-byte v3, v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    aput-byte v3, v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    add-int/lit8 v1, v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v5, 0x7

    shr-int/lit8 p1, p1, 0x18

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    and-int/lit16 p1, p1, 0xff

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    int-to-byte p1, p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    aput-byte p1, v0, v2

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 p1, p1, 0x4

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-void
.end method

.method final bufferFixed64NoTag(J)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-wide/16 v3, 0xff

    const-wide/16 v3, 0xff

    const/4 v9, 0x2

    const-wide/16 v3, 0xff

    const-wide/16 v3, 0xff

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    and-long v5, p1, v3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    long-to-int v5, v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    int-to-byte v5, v5

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    aput-byte v5, v0, v1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    add-int/lit8 v1, v2, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/16 v5, 0x8

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    shr-long v6, p1, v5

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    and-long/2addr v6, v3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    long-to-int v6, v6

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    int-to-byte v6, v6

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    aput-byte v6, v0, v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/16 v6, 0x10

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    shr-long v6, p1, v6

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    and-long/2addr v6, v3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    long-to-int v6, v6

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    int-to-byte v6, v6

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    aput-byte v6, v0, v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    add-int/lit8 v1, v2, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/16 v6, 0x18

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    shr-long v6, p1, v6

    const/4 v9, 0x2

    const/4 v8, 0x3

    and-long/2addr v3, v6

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    long-to-int v3, v3

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    int-to-byte v3, v3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    aput-byte v3, v0, v2

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/16 v3, 0x20

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    shr-long v3, p1, v3

    const/4 v9, 0x6

    const/4 v8, 0x7

    long-to-int v3, v3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    int-to-byte v3, v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    aput-byte v3, v0, v1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-int/lit8 v1, v2, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/16 v3, 0x28

    const/4 v9, 0x7

    shr-long v3, p1, v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    long-to-int v3, v3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    and-int/lit16 v3, v3, 0xff

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    int-to-byte v3, v3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    aput-byte v3, v0, v2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    add-int/lit8 v2, v1, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/16 v3, 0x30

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    shr-long v3, p1, v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    long-to-int v3, v3

    const/4 v8, 0x3

    move v9, v8

    and-int/lit16 v3, v3, 0xff

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    int-to-byte v3, v3

    const/4 v8, 0x2

    move v9, v8

    aput-byte v3, v0, v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    add-int/lit8 v1, v2, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/16 v1, 0x38

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    shr-long/2addr p1, v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    long-to-int p1, p1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    and-int/lit16 p1, p1, 0xff

    const/4 v8, 0x3

    const/4 v9, 0x0

    int-to-byte p1, p1

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    aput-byte p1, v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/2addr p1, v5

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    return-void
.end method

.method final bufferInt32NoTag(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ltz p1, :cond_0

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt32NoTag(I)V

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    int-to-long v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt64NoTag(J)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method final bufferTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt32NoTag(I)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method final bufferUInt32NoTag(I)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {}, Lcom/google/protobuf/CodedOutputStream;->access$100()Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    int-to-long v0, v0

    :goto_0
    const/4 v7, 0x5

    and-int/lit8 v2, p1, -0x80

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-nez v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    add-int/lit8 v4, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput v4, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    int-to-long v3, v3

    const/4 v7, 0x2

    int-to-byte p1, p1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v2, v3, v4, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x0

    int-to-long v2, p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    sub-long/2addr v2, v0

    const/4 v7, 0x0

    long-to-int p1, v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    add-int/2addr v0, p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v7, 0x5

    const/4 v6, 0x3

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    add-int/lit8 v4, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    iput v4, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    int-to-long v3, v3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    and-int/lit8 v5, p1, 0x7f

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    or-int/lit16 v5, v5, 0x80

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    int-to-byte v5, v5

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v2, v3, v4, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v7, 0x4

    ushr-int/lit8 p1, p1, 0x7

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    and-int/lit8 v0, p1, -0x80

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez v0, :cond_2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    add-int/lit8 v2, v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    int-to-byte p1, p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    aput-byte p1, v0, v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v6, 0x7

    move v7, v6

    add-int/lit8 p1, p1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    return-void

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v6, 0x6

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    add-int/lit8 v2, v1, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    and-int/lit8 v2, p1, 0x7f

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    or-int/lit16 v2, v2, 0x80

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    int-to-byte v2, v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    aput-byte v2, v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v7, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    ushr-int/lit8 p1, p1, 0x7

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_1
.end method

.method final bufferUInt64NoTag(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {}, Lcom/google/protobuf/CodedOutputStream;->access$100()Z

    move-result v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    const/4 v1, 0x7

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-eqz v0, :cond_1

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    int-to-long v6, v0

    :goto_0
    const/4 v11, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    and-long v8, p1, v4

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    cmp-long v0, v8, v2

    const/4 v12, 0x5

    if-nez v0, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    add-int/lit8 v2, v1, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    int-to-long v1, v1

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x3

    long-to-int p1, p1

    const/4 v11, 0x0

    move v12, v11

    int-to-byte p1, p1

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    int-to-long p1, p1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    sub-long/2addr p1, v6

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    long-to-int p1, p1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget p2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    add-int/2addr p2, p1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    iput p2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v12, 0x0

    return-void

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget v8, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x5

    add-int/lit8 v9, v8, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    iput v9, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    int-to-long v8, v8

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    long-to-int v10, p1

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    and-int/lit8 v10, v10, 0x7f

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    or-int/lit16 v10, v10, 0x80

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    int-to-byte v10, v10

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {v0, v8, v9, v10}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    ushr-long/2addr p1, v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    goto/16 :goto_0

    :cond_1
    :goto_1
    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    and-long v6, p1, v4

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    cmp-long v0, v6, v2

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    if-nez v0, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v12, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    add-int/lit8 v2, v1, 0x1

    const/4 v11, 0x1

    move v12, v11

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x0

    long-to-int p1, p1

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    int-to-byte p1, p1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    aput-byte p1, v0, v1

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v12, 0x6

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    return-void

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget v6, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    add-int/lit8 v7, v6, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    iput v7, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v11, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    long-to-int v7, p1

    const/4 v12, 0x0

    and-int/lit8 v7, v7, 0x7f

    const/4 v11, 0x4

    move v12, v11

    or-int/lit16 v7, v7, 0x80

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    int-to-byte v7, v7

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    aput-byte v7, v0, v6

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v12, 0x2

    const/4 v11, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    ushr-long/2addr p1, v1

    goto :goto_1
.end method

.method public final getTotalBytesWritten()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method

.method public final spaceLeft()I
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const-string v1, "etBsobnle aaaddaf moyrnbnysiahrul .tleumpOr tgo lyBtdwa  te faotn( oL r   fSafeeriee tctcptuc)rCtara"

    const-string v1, "edamlya tBSeafo enulfrlao r tusr)  trypttn wt.d ataieaa gecoc ultfnCo nOfroab( trLa hmdsptriey ecB e"

    const/4 v3, 0x6

    const-string v1, "esnfrtu prec  et(aetu Btane  tle fyt  lyarnCtosfn. b atc liLumifotohtadrr yl)Sedprw ageareuaad aoocO"

    const-string/jumbo v1, "spaceLeft() can only be called on CodedOutputStreams that are writing to a flat array or ByteBuffer."

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw v0
.end method
