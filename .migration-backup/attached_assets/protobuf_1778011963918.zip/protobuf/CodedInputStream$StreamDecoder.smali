.class final Lcom/google/protobuf/CodedInputStream$StreamDecoder;
.super Lcom/google/protobuf/CodedInputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedInputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "StreamDecoder"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/CodedInputStream$StreamDecoder$RefillCallback;,
        Lcom/google/protobuf/CodedInputStream$StreamDecoder$SkippedDataSink;
    }
.end annotation


# instance fields
.field private final buffer:[B

.field private bufferSize:I

.field private bufferSizeAfterLimit:I

.field private currentLimit:I

.field private final input:Ljava/io/InputStream;

.field private lastTag:I

.field private pos:I

.field private refillCallback:Lcom/google/protobuf/CodedInputStream$StreamDecoder$RefillCallback;

.field private totalBytesRetired:I


# direct methods
.method private constructor <init>(Ljava/io/InputStream;I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "input",
            "bufferSize"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream;-><init>(Lcom/google/protobuf/CodedInputStream$1;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const v1, 0x7fffffff

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillCallback:Lcom/google/protobuf/CodedInputStream$StreamDecoder$RefillCallback;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "pssin"

    const-string/jumbo v0, "pnsit"

    const/4 v3, 0x3

    const-string/jumbo v0, "nupmi"

    const-string/jumbo v0, "input"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v3, 0x7

    new-array p1, p2, [B

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v3, 0x1

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method synthetic constructor <init>(Ljava/io/InputStream;ILcom/google/protobuf/CodedInputStream$1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;-><init>(Ljava/io/InputStream;I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$500(Lcom/google/protobuf/CodedInputStream$StreamDecoder;)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@S~soyo~ K@~ ~  @it1~@~ @.4 d@~ ~otn~v b-~i@@@ @r~~   @f @~ ~ @c~u~~@o@ool@ bf @o~a~@~Mml//i~~b@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget p0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v1, 0x7

    return p0
.end method

.method static synthetic access$600(Lcom/google/protobuf/CodedInputStream$StreamDecoder;)[B
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p0
.end method

.method private static available(Ljava/io/InputStream;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/io/InputStream;->available()I

    move-result p0
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p0

    :catch_0
    move-exception p0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/InvalidProtocolBufferException;->setThrownFromInputStream()V

    const/4 v0, 0x1

    const/4 v0, 0x4

    throw p0
.end method

.method private static read(Ljava/io/InputStream;[BII)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "input",
            "data",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2, p3}, Ljava/io/InputStream;->read([BII)I

    move-result p0
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p0

    :catch_0
    move-exception p0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/InvalidProtocolBufferException;->setThrownFromInputStream()V

    const/4 v1, 0x3

    throw p0
.end method

.method private readBytesSlowPath(I)Lcom/google/protobuf/ByteString;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPathOneChunk(I)[B

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFrom([B)Lcom/google/protobuf/ByteString;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    sub-int v2, v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    add-int/2addr v3, v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v6, 0x4

    sub-int v3, p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0, v3}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPathRemainingChunks(I)Ljava/util/List;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-array p1, p1, [B

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v4, v0, p1, v1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    check-cast v3, [B

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    array-length v4, v3

    const/4 v6, 0x2

    invoke-static {v3, v1, p1, v2, v4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    array-length v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    add-int/2addr v2, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/google/protobuf/ByteString;->wrap([B)Lcom/google/protobuf/ByteString;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object p1
.end method

.method private readRawBytesSlowPath(IZ)[B
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "size",
            "ensureNoLeakedReferences"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPathOneChunk(I)[B

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    if-eqz p2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, [B->clone()Ljava/lang/Object;

    move-result-object p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    check-cast v0, [B

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object v0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget p2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x7

    move v5, v4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    sub-int v1, v0, p2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/2addr v2, v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x0

    or-int/2addr v5, v0

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    sub-int v2, p1, v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {p0, v2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPathRemainingChunks(I)Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    new-array p1, p1, [B

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v3, p2, p1, v0, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    check-cast v2, [B

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    array-length v3, v2

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v2, v0, p1, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    array-length v2, v2

    const/4 v5, 0x0

    add-int/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object p1
.end method

.method private readRawBytesSlowPathOneChunk(I)[B
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget-object p1, Lcom/google/protobuf/Internal;->EMPTY_BYTE_ARRAY:[B

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object p1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-ltz p1, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    add-int v2, v0, v1

    const/4 v6, 0x7

    add-int/2addr v2, p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v3, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    sub-int v3, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-gtz v3, :cond_6

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-gt v2, v3, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x2

    and-int/2addr v6, v5

    sub-int/2addr v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    sub-int v1, p1, v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/16 v2, 0x1000

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-lt v1, v2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v6, 0x0

    invoke-static {v2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->available(Ljava/io/InputStream;)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-gt v1, v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 p1, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object p1

    :cond_2
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    new-array v1, p1, [B

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v2, v3, v1, v4, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    add-int/2addr v2, v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    iput v4, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    iput v4, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    :goto_1
    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ge v0, p1, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    sub-int v3, p1, v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v2, v1, v0, v3}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->read(Ljava/io/InputStream;[BII)I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v3, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eq v2, v3, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/2addr v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    add-int/2addr v0, v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    throw p1

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-object v1

    :cond_5
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    sub-int/2addr v3, v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    sub-int/2addr v3, v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawBytes(I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    throw p1

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->sizeLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    throw p1

    :cond_7
    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    throw p1
.end method

.method private readRawBytesSlowPathRemainingChunks(I)Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "sizeLeft"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)",
            "Ljava/util/List<",
            "[B>;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v6, 0x4

    move v7, v6

    if-lez p1, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/16 v1, 0x1000

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-array v2, v1, [B

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v3, 0x0

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ge v3, v1, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v6, 0x0

    move v7, v6

    sub-int v5, v1, v3

    const/4 v6, 0x2

    const/4 v6, 0x3

    invoke-virtual {v4, v2, v3, v5}, Ljava/io/InputStream;->read([BII)I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v5, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eq v4, v5, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget v5, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-int/2addr v5, v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    iput v5, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/2addr v3, v4

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_1

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    throw p1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    sub-int/2addr p1, v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-object v0
.end method

.method private recomputeBufferSizeAfterLimit()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSizeAfterLimit:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    add-int/2addr v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v4, 0x6

    add-int/2addr v1, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-le v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    sub-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSizeAfterLimit:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    sub-int/2addr v0, v1

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSizeAfterLimit:I

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void
.end method

.method private refillBuffer(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "n"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->tryRefillBuffer(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-le p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->sizeLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw p1

    :cond_0
    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method private static skip(Ljava/io/InputStream;J)J
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Ljava/io/InputStream;->skip(J)J

    move-result-wide p0
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-wide p0

    :catch_0
    move-exception p0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/InvalidProtocolBufferException;->setThrownFromInputStream()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    throw p0
.end method

.method private skipRawBytesSlowPath(I)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-ltz p1, :cond_7

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v8, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    add-int v2, v0, v1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    add-int/2addr v2, p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v8, 0x7

    move v9, v8

    if-gt v2, v3, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillCallback:Lcom/google/protobuf/CodedInputStream$StreamDecoder$RefillCallback;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-nez v2, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    add-int/2addr v0, v1

    const/4 v8, 0x4

    const/4 v9, 0x1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    sub-int/2addr v0, v1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    move v3, v0

    move v3, v0

    const/4 v9, 0x1

    move v3, v0

    move v3, v0

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-ge v3, p1, :cond_2

    const/4 v8, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    sub-int v0, p1, v3

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    int-to-long v4, v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v1, v4, v5}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skip(Ljava/io/InputStream;J)J

    move-result-wide v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x5

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    cmp-long v2, v0, v6

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ltz v2, :cond_1

    const/4 v9, 0x5

    cmp-long v4, v0, v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-gtz v4, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez v2, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto :goto_1

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    long-to-int v0, v0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    add-int/2addr v3, v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_0

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v9, 0x4

    const/4 v8, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    or-int/2addr v9, v8

    iget-object v4, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string v4, "d:inubdietinlpv mrskrtee s# l a"

    const-string v4, "i#rmeit ineulkrd  l es:npvsduta"

    const/4 v9, 0x6

    const-string/jumbo v4, "si lvuudr:tiua npedrirektse # l"

    const-string v4, "#skip returned invalid result: "

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v0, "S.utn lpsgtimipmeaeugrbynmT pth/aneot i en"

    const-string v0, "\nThe InputStream implementation is buggy."

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception p1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    add-int/2addr v0, v3

    const/4 v9, 0x2

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    throw p1

    :cond_2
    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    add-int/2addr v0, v3

    const/4 v9, 0x2

    const/4 v8, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->recomputeBufferSizeAfterLimit()V

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-ge v3, p1, :cond_5

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    sub-int v1, v0, v1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v0, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    sub-int v2, p1, v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-le v2, v3, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    add-int/2addr v1, v3

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    goto :goto_2

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    :cond_5
    const/4 v9, 0x7

    return-void

    :cond_6
    const/4 v9, 0x6

    const/4 v8, 0x2

    sub-int/2addr v3, v0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    sub-int/2addr v3, v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawBytes(I)V

    const/4 v9, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    throw p1

    :cond_7
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    throw p1
.end method

.method private skipRawVarint()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/16 v1, 0xa

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-lt v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawVarintFastPath()V

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawVarintSlowPath()V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method private skipRawVarintFastPath()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/16 v1, 0xa

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-ge v0, v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/lit8 v3, v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x4

    move v5, v4

    aget-byte v1, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ltz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw v0
.end method

.method private skipRawVarintSlowPath()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v1, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x0

    if-ge v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawByte()B

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ltz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    throw v0
.end method

.method private tryRefillBuffer(I)Z
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "n"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v7, 0x7

    move v8, v7

    add-int v1, v0, p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-le v1, v2, :cond_8

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v8, 0x1

    const/4 v7, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    sub-int/2addr v1, v2

    const/4 v7, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    sub-int/2addr v1, v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v3, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-le p1, v1, :cond_0

    const/4 v8, 0x5

    return v3

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    add-int/2addr v2, v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    add-int/2addr v2, p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    if-le v2, v0, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    return v3

    :cond_1
    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillCallback:Lcom/google/protobuf/CodedInputStream$StreamDecoder$RefillCallback;

    const/4 v8, 0x3

    const/4 v7, 0x7

    if-eqz v0, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder$RefillCallback;->onRefill()V

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-lez v0, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-le v1, v0, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v7, 0x4

    move v8, v7

    sub-int/2addr v1, v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    invoke-static {v2, v0, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    add-int/2addr v1, v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    sub-int/2addr v1, v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    :cond_4
    const/4 v7, 0x4

    move v8, v7

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    array-length v4, v1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    sub-int/2addr v4, v2

    const/4 v7, 0x0

    or-int/2addr v8, v7

    iget v5, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget v6, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    sub-int/2addr v5, v6

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    sub-int/2addr v5, v2

    const/4 v8, 0x4

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v0, v1, v2, v4}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->read(Ljava/io/InputStream;[BII)I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v0, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v1, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-lt v0, v1, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    array-length v1, v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    if-gt v0, v1, :cond_7

    const/4 v8, 0x6

    if-lez v0, :cond_6

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    add-int/2addr v1, v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-lt v0, p1, :cond_5

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 p1, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    goto :goto_0

    :cond_5
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->tryRefillBuffer(I)Z

    move-result p1

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    return p1

    :cond_6
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    return v3

    :cond_7
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v8, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->input:Ljava/io/InputStream;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo v2, "r)tsoyi(iaen:e ld[vtbdur]l tea#e  ednrr"

    const/4 v8, 0x4

    const-string v2, "[dua#i(nqebdev eai) t rrter]:nd uyrltes"

    const-string v2, "#read(byte[]) returned invalid result: "

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string v0, "I s Tye.agtsbtu n nprimSumloimetbnhpateegn"

    const-string/jumbo v0, "otrepbIynSiptmm. t aegtemigls au inhebnTnu"

    const/4 v8, 0x7

    const-string v0, " oymnt.uilbm tngtsm ue/ aTetrnemiepniagISh"

    const-string v0, "\nThe InputStream implementation is buggy."

    const/4 v7, 0x7

    and-int/2addr v8, v7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    throw p1

    :cond_8
    const/4 v7, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    const-string v2, "efcBore)h(lliuauwle lr endf"

    const-string/jumbo v2, "lhidfru(fBlfr)ealeulcneew  "

    const-string v2, "Bee(ebld wl hrlrficaul)fnfe"

    const-string/jumbo v2, "refillBuffer() called when "

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string p1, "  sf yu a eeerburpbyv frainaebealdeltwi"

    const-string p1, "e ee eapaeaybrrtlifu  l yfdsrblnivae wb"

    const/4 v8, 0x0

    const-string/jumbo p1, "srrbeyipen fwbl e tedyaueafalieava rb  "

    const-string p1, " bytes were already available in buffer"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    throw v0
.end method


# virtual methods
.method public checkLastTagWas(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->lastTag:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-ne v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidEndTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    throw p1
.end method

.method public enableAliasing(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enabled"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public getBytesUntilLimit()I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const v1, 0x7fffffff

    const/4 v4, 0x7

    if-ne v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x5

    add-int/2addr v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    sub-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    return v0
.end method

.method public getLastTag()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->lastTag:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public getTotalBytesRead()I
    .locals 4

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method public isAtEnd()Z
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->tryRefillBuffer(I)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0
.end method

.method public popLimit(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "oldLimit"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public pushLimit(I)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "byteLimit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ltz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    add-int/2addr p1, v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-gt p1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->currentLimit:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    throw p1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p1
.end method

.method public readBool()Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v0
.end method

.method public readByteArray()[B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    sub-int/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-gt v0, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-lez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x0

    add-int v3, v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-static {v1, v2, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    add-int/2addr v2, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object v1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {p0, v0, v1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPath(IZ)[B

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object v0
.end method

.method public readByteBuffer()Ljava/nio/ByteBuffer;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    sub-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-gt v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-lez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int v3, v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v1, v2, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x5

    const/4 v4, 0x2

    add-int/2addr v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return-object v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v0, Lcom/google/protobuf/Internal;->EMPTY_BYTE_BUFFER:Ljava/nio/ByteBuffer;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object v0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p0, v0, v1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPath(IZ)[B

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-object v0
.end method

.method public readBytes()Lcom/google/protobuf/ByteString;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    sub-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-gt v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-lez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    add-int/2addr v2, v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readBytesSlowPath(I)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method public readDouble()D
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-wide v0
.end method

.method public readEnum()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public readFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public readFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-wide v0
.end method

.method public readFloat()F
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public readGroup(ILcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(I",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p2, Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p3, 0x4

    const/4 v2, 0x0

    invoke-static {p1, p3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->checkLastTagWas(I)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p2
.end method

.method public readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 p2, 0x4

    shl-int/2addr v2, p2

    const/4 v1, 0x2

    move v2, v1

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->checkLastTagWas(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public readInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public readInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-wide v0
.end method

.method public readMessage(Lcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast p1, Lcom/google/protobuf/MessageLite;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p2, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/lit8 p2, p2, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->getBytesUntilLimit()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->popLimit(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    throw p1
.end method

.method public readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->getBytesUntilLimit()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->popLimit(I)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x0

    throw p1
.end method

.method public readRawByte()B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    aget-byte v0, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return v0
.end method

.method public readRawBytes(I)[B
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    sub-int/2addr v1, v0

    const/4 v3, 0x3

    if-gt p1, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-lez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/2addr p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v1, v0, p1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, p1, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPath(IZ)[B

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p1
.end method

.method public readRawLittleEndian32()I
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    sub-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x4

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ge v1, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0, v2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    add-int/lit8 v2, v0, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x6

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    aget-byte v2, v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    and-int/lit16 v2, v2, 0xff

    const/4 v5, 0x0

    add-int/lit8 v3, v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    aget-byte v3, v1, v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    shl-int/lit8 v3, v3, 0x8

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    or-int/2addr v2, v3

    add-int/lit8 v3, v0, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    aget-byte v3, v1, v3

    const/4 v4, 0x5

    and-int/2addr v5, v4

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    shl-int/lit8 v3, v3, 0x10

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    or-int/2addr v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    aget-byte v0, v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0xff

    const/4 v5, 0x1

    const/4 v4, 0x5

    shl-int/lit8 v0, v0, 0x18

    const/4 v4, 0x4

    move v5, v4

    or-int/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    return v0
.end method

.method public readRawLittleEndian64()J
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    sub-int/2addr v1, v0

    const/4 v10, 0x7

    const/16 v2, 0x8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-ge v1, v2, :cond_0

    const/4 v10, 0x5

    invoke-direct {p0, v2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    :cond_0
    const/4 v10, 0x4

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v9, 0x4

    move v10, v9

    add-int/lit8 v3, v0, 0x8

    const/4 v10, 0x2

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    aget-byte v3, v1, v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    int-to-long v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-wide/16 v5, 0xff

    const/4 v10, 0x2

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    and-long/2addr v3, v5

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    add-int/lit8 v7, v0, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x3

    aget-byte v7, v1, v7

    const/4 v10, 0x3

    int-to-long v7, v7

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    and-long/2addr v7, v5

    const/4 v9, 0x3

    const/4 v10, 0x3

    shl-long/2addr v7, v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    or-long v2, v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    add-int/lit8 v4, v0, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    aget-byte v4, v1, v4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    int-to-long v7, v4

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    and-long/2addr v7, v5

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/16 v4, 0x10

    const/4 v9, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    shl-long/2addr v7, v4

    const/4 v10, 0x2

    const/4 v9, 0x2

    or-long/2addr v2, v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    add-int/lit8 v4, v0, 0x3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    aget-byte v4, v1, v4

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    int-to-long v7, v4

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    and-long/2addr v7, v5

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/16 v4, 0x18

    const/4 v10, 0x3

    const/4 v9, 0x7

    shl-long/2addr v7, v4

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    or-long/2addr v2, v7

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    add-int/lit8 v4, v0, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    aget-byte v4, v1, v4

    const/4 v10, 0x5

    const/4 v9, 0x5

    int-to-long v7, v4

    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    and-long/2addr v7, v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/16 v4, 0x20

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    shl-long/2addr v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x0

    or-long/2addr v2, v7

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    add-int/lit8 v4, v0, 0x5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    aget-byte v4, v1, v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    int-to-long v7, v4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    and-long/2addr v7, v5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/16 v4, 0x28

    const/4 v9, 0x0

    move v10, v9

    shl-long/2addr v7, v4

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    or-long/2addr v2, v7

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    add-int/lit8 v4, v0, 0x6

    const/4 v10, 0x2

    const/4 v9, 0x0

    aget-byte v4, v1, v4

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    int-to-long v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    and-long/2addr v7, v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v4, 0x30

    const/4 v10, 0x1

    shl-long/2addr v7, v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    or-long/2addr v2, v7

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    add-int/lit8 v0, v0, 0x7

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    aget-byte v0, v1, v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    int-to-long v0, v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    and-long/2addr v0, v5

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/16 v4, 0x38

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x3

    shl-long/2addr v0, v4

    const/4 v10, 0x0

    or-long/2addr v0, v2

    const/4 v10, 0x1

    return-wide v0
.end method

.method public readRawVarint32()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ne v1, v0, :cond_0

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x3

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/lit8 v3, v0, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    aget-byte v0, v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-ltz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    sub-int/2addr v1, v3

    const/4 v6, 0x1

    const/16 v4, 0x9

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-ge v1, v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    aget-byte v3, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    shl-int/lit8 v3, v3, 0x7

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    xor-int/2addr v0, v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-gez v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    xor-int/lit8 v0, v0, -0x80

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x0

    aget-byte v1, v2, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    shl-int/lit8 v1, v1, 0xe

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    xor-int/2addr v0, v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-ltz v0, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    xor-int/lit16 v0, v0, 0x3f80

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x0

    move v1, v3

    move v1, v3

    const/4 v6, 0x6

    move v1, v3

    move v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    goto/16 :goto_1

    :cond_5
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    aget-byte v3, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    shl-int/lit8 v3, v3, 0x15

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    xor-int/2addr v0, v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-gez v0, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    const v2, -0x1fc080

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    xor-int/2addr v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    goto :goto_1

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    aget-byte v1, v2, v1

    const/4 v6, 0x0

    shl-int/lit8 v4, v1, 0x1c

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    xor-int/2addr v0, v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const v4, 0xfe03f80

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    xor-int/2addr v0, v4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-gez v1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    aget-byte v3, v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-gez v3, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x5

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    aget-byte v1, v2, v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-gez v1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    aget-byte v3, v2, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-gez v3, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x5

    aget-byte v1, v2, v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-gez v1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    aget-byte v2, v2, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-gez v2, :cond_7

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    long-to-int v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    return v0

    :cond_7
    :goto_1
    const/4 v6, 0x0

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    return v0
.end method

.method public readRawVarint64()J
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-ne v1, v0, :cond_0

    const/4 v12, 0x6

    goto/16 :goto_3

    :cond_0
    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    add-int/lit8 v3, v0, 0x1

    const/4 v11, 0x4

    move v12, v11

    aget-byte v0, v2, v0

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-ltz v0, :cond_1

    const/4 v12, 0x5

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    int-to-long v0, v0

    const/4 v12, 0x1

    const/4 v11, 0x4

    return-wide v0

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x2

    sub-int/2addr v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    const/16 v4, 0x9

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-ge v1, v4, :cond_2

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    goto/16 :goto_3

    :cond_2
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    add-int/lit8 v1, v3, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    aget-byte v3, v2, v3

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    shl-int/lit8 v3, v3, 0x7

    const/4 v12, 0x6

    const/4 v11, 0x1

    xor-int/2addr v0, v3

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-gez v0, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x6

    xor-int/lit8 v0, v0, -0x80

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x0

    int-to-long v2, v0

    const/4 v12, 0x0

    goto/16 :goto_4

    :cond_3
    add-int/lit8 v3, v1, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    aget-byte v1, v2, v1

    const/4 v12, 0x3

    const/4 v11, 0x3

    shl-int/lit8 v1, v1, 0xe

    const/4 v11, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    xor-int/2addr v0, v1

    const/4 v11, 0x1

    move v12, v11

    if-ltz v0, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    xor-int/lit16 v0, v0, 0x3f80

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    int-to-long v0, v0

    move-wide v9, v0

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    move v1, v3

    move v1, v3

    move-wide v2, v9

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    goto/16 :goto_4

    :cond_4
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    add-int/lit8 v1, v3, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    aget-byte v3, v2, v3

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    shl-int/lit8 v3, v3, 0x15

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    xor-int/2addr v0, v3

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    if-gez v0, :cond_5

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    const v2, -0x1fc080

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    xor-int/2addr v0, v2

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto :goto_0

    :cond_5
    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    int-to-long v3, v0

    const/4 v12, 0x1

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    aget-byte v1, v2, v1

    const/4 v11, 0x5

    move v12, v11

    int-to-long v5, v1

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/16 v1, 0x1c

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    shl-long/2addr v5, v1

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    xor-long/2addr v3, v5

    const/4 v12, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x6

    const-wide/16 v5, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    cmp-long v1, v3, v5

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-ltz v1, :cond_6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-wide/32 v1, 0xfe03f80

    const-wide/32 v1, 0xfe03f80

    :goto_1
    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    xor-long v2, v3, v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    goto/16 :goto_4

    :cond_6
    const/4 v11, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x4

    aget-byte v0, v2, v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    int-to-long v7, v0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/16 v0, 0x23

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    shl-long/2addr v7, v0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    xor-long/2addr v3, v7

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    cmp-long v0, v3, v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    if-gez v0, :cond_7

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    const-wide v5, -0x7f01fc080L

    const-wide v5, -0x7f01fc080L

    const/4 v12, 0x6

    const-wide v5, -0x7f01fc080L

    const-wide v5, -0x7f01fc080L

    :goto_2
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    xor-long v2, v3, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    goto/16 :goto_4

    :cond_7
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x0

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x5

    aget-byte v1, v2, v1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    int-to-long v7, v1

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/16 v1, 0x2a

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    shl-long/2addr v7, v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    xor-long/2addr v3, v7

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    cmp-long v1, v3, v5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    if-ltz v1, :cond_8

    const/4 v12, 0x4

    const-wide v1, 0x3f80fe03f80L

    const-wide v1, 0x3f80fe03f80L

    const/4 v12, 0x4

    const-wide v1, 0x3f80fe03f80L

    const-wide v1, 0x3f80fe03f80L

    const/4 v12, 0x7

    goto/16 :goto_1

    :cond_8
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x7

    aget-byte v0, v2, v0

    const/4 v11, 0x3

    const/4 v11, 0x7

    int-to-long v7, v0

    const/4 v12, 0x4

    const/16 v0, 0x31

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    shl-long/2addr v7, v0

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    xor-long/2addr v3, v7

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    cmp-long v0, v3, v5

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-gez v0, :cond_9

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    const-wide v5, -0x1fc07f01fc080L

    const-wide v5, -0x1fc07f01fc080L

    const/4 v12, 0x7

    const-wide v5, -0x1fc07f01fc080L

    const-wide v5, -0x1fc07f01fc080L

    const/4 v12, 0x2

    const/4 v11, 0x3

    goto/16 :goto_2

    :cond_9
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    aget-byte v1, v2, v1

    const/4 v12, 0x4

    int-to-long v7, v1

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x7

    const/16 v1, 0x38

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    shl-long/2addr v7, v1

    const/4 v11, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    xor-long/2addr v3, v7

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-wide v7, 0xfe03f80fe03f80L

    const-wide v7, 0xfe03f80fe03f80L

    const/4 v12, 0x1

    const-wide v7, 0xfe03f80fe03f80L

    const/4 v12, 0x7

    const/4 v11, 0x4

    xor-long/2addr v3, v7

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    cmp-long v1, v3, v5

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    if-gez v1, :cond_a

    const/4 v12, 0x5

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    aget-byte v0, v2, v0

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    int-to-long v7, v0

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    cmp-long v0, v7, v5

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-gez v0, :cond_b

    :goto_3
    const/4 v12, 0x6

    const/4 v11, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x2

    return-wide v0

    :cond_a
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    move v1, v0

    move v1, v0

    const/4 v12, 0x2

    move v1, v0

    move v1, v0

    :cond_b
    move-wide v2, v3

    :goto_4
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    return-wide v2
.end method

.method readRawVarint64SlowPath()J
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v3, 0x40

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-ge v2, v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawByte()B

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    and-int/lit8 v4, v3, 0x7f

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    int-to-long v4, v4

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    shl-long/2addr v4, v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    or-long/2addr v0, v4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    and-int/lit16 v3, v3, 0x80

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    return-wide v0

    :cond_0
    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-int/lit8 v2, v2, 0x7

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    throw v0
.end method

.method public readSFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public readSFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-wide v0
.end method

.method public readSInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public readSInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-wide v0
.end method

.method public readString()Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-lez v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    sub-int/2addr v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-gt v0, v1, :cond_0

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    new-instance v1, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget-object v4, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v1, v3, v2, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    add-int/2addr v2, v0

    const/4 v6, 0x4

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-object v1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-nez v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v0, ""

    const/4 v6, 0x5

    const-string v0, ""

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-object v0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-gt v0, v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object v4, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v1, v2, v3, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x0

    add-int/2addr v2, v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-object v1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {p0, v0, v2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPath(IZ)[B

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    sget-object v2, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-object v1
.end method

.method public readStringRequireUtf8()Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    sub-int v3, v2, v1

    const/4 v5, 0x7

    if-gt v0, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-lez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int v3, v1, v0

    const/4 v4, 0x3

    move v5, v4

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-object v0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    if-gt v0, v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->refillBuffer(I)V

    const/4 v4, 0x2

    or-int/2addr v5, v4

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->buffer:[B

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    add-int/lit8 v3, v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-direct {p0, v0, v1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawBytesSlowPath(IZ)[B

    move-result-object v2

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v2, v1, v0}, Lcom/google/protobuf/Utf8;->decodeUtf8([BII)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v0
.end method

.method public readTag()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->isAtEnd()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->lastTag:I

    const/4 v1, 0x6

    move v2, v1

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->lastTag:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->lastTag:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    return v0

    :cond_1
    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    throw v0
.end method

.method public readUInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public readUInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-wide v0
.end method

.method public readUnknownGroup(ILcom/google/protobuf/MessageLite$Builder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/ExtensionRegistryLite;->getEmptyRegistry()Lcom/google/protobuf/ExtensionRegistryLite;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public resetSizeCounter()V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    neg-int v0, v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->totalBytesRetired:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public skipField(I)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "tag"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_5

    const/4 v5, 0x0

    if-eq v0, v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x4

    if-eq v0, v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v2, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x4

    if-eq v0, v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eq v0, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 p1, 0x5

    const/4 v5, 0x1

    if-ne v0, p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawBytes(I)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    return p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipMessage()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->checkLastTagWas(I)V

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return v1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawVarint32()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawBytes(I)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v1

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/16 p1, 0x8

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawBytes(I)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v1

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawVarint()V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    return v1
.end method

.method public skipField(ILcom/google/protobuf/CodedOutputStream;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "tag",
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eq v0, v1, :cond_4

    const/4 v4, 0x1

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    if-eq v0, v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eq v0, v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eq v0, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v2, 0x5

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    if-ne v0, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeFixed32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    throw p1

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    return p1

    :cond_2
    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipMessage(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->checkLastTagWas(I)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v1

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readRawLittleEndian64()J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeFixed64NoTag(J)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v1

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readInt64()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeUInt64NoTag(J)V

    const/4 v5, 0x0

    return v1
.end method

.method public skipMessage()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipField(I)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public skipMessage(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipField(ILcom/google/protobuf/CodedOutputStream;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public skipRawBytes(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->bufferSize:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-gt p1, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ltz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    add-int/2addr v1, p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->pos:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;->skipRawBytesSlowPath(I)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method
