.class public final Lcom/google/protobuf/Api;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/google/protobuf/ApiOrBuilder;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/Api$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

.field public static final METHODS_FIELD_NUMBER:I = 0x2

.field public static final MIXINS_FIELD_NUMBER:I = 0x6

.field public static final NAME_FIELD_NUMBER:I = 0x1

.field public static final OPTIONS_FIELD_NUMBER:I = 0x3

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Api;",
            ">;"
        }
    .end annotation
.end field

.field public static final SOURCE_CONTEXT_FIELD_NUMBER:I = 0x5

.field public static final SYNTAX_FIELD_NUMBER:I = 0x7

.field public static final VERSION_FIELD_NUMBER:I = 0x4

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private memoizedIsInitialized:B

.field private methods_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/Method;",
            ">;"
        }
    .end annotation
.end field

.field private mixins_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/Mixin;",
            ">;"
        }
    .end annotation
.end field

.field private volatile name_:Ljava/lang/Object;

.field private options_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/Option;",
            ">;"
        }
    .end annotation
.end field

.field private sourceContext_:Lcom/google/protobuf/SourceContext;

.field private syntax_:I

.field private volatile version_:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    new-instance v0, Lcom/google/protobuf/Api;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/protobuf/Api;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object v0, Lcom/google/protobuf/Api;->DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Lcom/google/protobuf/Api$1;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/google/protobuf/Api$1;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sput-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v3, 0x2

    move v4, v3

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    iput v1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, -0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-byte v2, p0, Lcom/google/protobuf/Api;->memoizedIsInitialized:B

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    iput-object v2, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v2, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p1, -0x1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-byte p1, p0, Lcom/google/protobuf/Api;->memoizedIsInitialized:B

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/google/protobuf/Api$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/Api;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$1076(Lcom/google/protobuf/Api;I)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/Api;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    or-int/2addr p1, v0

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/protobuf/Api;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1
.end method

.method static synthetic access$300(Lcom/google/protobuf/Api;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$302(Lcom/google/protobuf/Api;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$400(Lcom/google/protobuf/Api;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    iget-object p0, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$402(Lcom/google/protobuf/Api;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v0, 0x7

    shr-int/2addr v1, v0

    return-object p1
.end method

.method static synthetic access$500(Lcom/google/protobuf/Api;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$502(Lcom/google/protobuf/Api;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$600(Lcom/google/protobuf/Api;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$602(Lcom/google/protobuf/Api;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$700(Lcom/google/protobuf/Api;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$702(Lcom/google/protobuf/Api;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic access$802(Lcom/google/protobuf/Api;Lcom/google/protobuf/SourceContext;)Lcom/google/protobuf/SourceContext;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/protobuf/Api;->sourceContext_:Lcom/google/protobuf/SourceContext;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$900(Lcom/google/protobuf/Api;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget p0, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    return p0
.end method

.method static synthetic access$902(Lcom/google/protobuf/Api;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p1
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/Api;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/Api;->DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    sget-object v0, Lcom/google/protobuf/ApiProto;->internal_static_google_protobuf_Api_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/Api$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Api;->DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Api;->toBuilder()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/Api;)Lcom/google/protobuf/Api$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/Api;->DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/Api;->toBuilder()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lcom/google/protobuf/Api$Builder;->mergeFrom(Lcom/google/protobuf/Api;)Lcom/google/protobuf/Api$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v1, 0x6

    move v2, v1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x6

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Api;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/Api;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Api;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-ne p1, p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    instance-of v1, p1, Lcom/google/protobuf/Api;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    return p1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    check-cast p1, Lcom/google/protobuf/Api;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v1, :cond_2

    const/4 v5, 0x2

    return v2

    :cond_2
    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getMethodsList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->getMethodsList()Ljava/util/List;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v1, v3}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v2

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getOptionsList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->getOptionsList()Ljava/util/List;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1, v3}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v2

    :cond_4
    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getVersion()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->getVersion()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v1, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v2

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->hasSourceContext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->hasSourceContext()Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eq v1, v3, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v2

    :cond_6
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->hasSourceContext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v1, :cond_7

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getSourceContext()Lcom/google/protobuf/SourceContext;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->getSourceContext()Lcom/google/protobuf/SourceContext;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, v3}, Lcom/google/protobuf/SourceContext;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v2

    :cond_7
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getMixinsList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/Api;->getMixinsList()Ljava/util/List;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1, v3}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v1, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v2

    :cond_8
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v3, p1, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eq v1, v3, :cond_9

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v2

    :cond_9
    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez p1, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v2

    :cond_a
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/Api;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/Api;->DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getDefaultInstanceForType()Lcom/google/protobuf/Api;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getDefaultInstanceForType()Lcom/google/protobuf/Api;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getMethods(I)Lcom/google/protobuf/Method;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p1, Lcom/google/protobuf/Method;

    const/4 v1, 0x7

    move v2, v1

    return-object p1
.end method

.method public getMethodsCount()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public getMethodsList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Method;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getMethodsOrBuilder(I)Lcom/google/protobuf/MethodOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p1, Lcom/google/protobuf/MethodOrBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public getMethodsOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/MethodOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getMixins(I)Lcom/google/protobuf/Mixin;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p1, Lcom/google/protobuf/Mixin;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p1
.end method

.method public getMixinsCount()I
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public getMixinsList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Mixin;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getMixinsOrBuilder(I)Lcom/google/protobuf/MixinOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v1, 0x2

    move v2, v1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p1, Lcom/google/protobuf/MixinOrBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1
.end method

.method public getMixinsOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/MixinOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v2, 0x3

    move v3, v2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0
.end method

.method public getOptions(I)Lcom/google/protobuf/Option;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p1, Lcom/google/protobuf/Option;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1
.end method

.method public getOptionsCount()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public getOptionsList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Option;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v2, 0x2

    return-object v0
.end method

.method public getOptionsOrBuilder(I)Lcom/google/protobuf/OptionOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p1, Lcom/google/protobuf/OptionOrBuilder;

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    return-object p1
.end method

.method public getOptionsOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/OptionOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Api;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/Api;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 8

    const/4 v7, 0x0

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v1, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eq v0, v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    return v0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-nez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v6, 0x3

    or-int/2addr v7, v6

    invoke-static {v2, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    add-int/2addr v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    move v0, v1

    move v0, v1

    const/4 v7, 0x3

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v3, v1

    move v3, v1

    const/4 v7, 0x0

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-ge v3, v4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    check-cast v4, Lcom/google/protobuf/MessageLite;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v5, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v5, v4}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-int/2addr v0, v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x2

    move v3, v1

    move v3, v1

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v4, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-ge v3, v4, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v7, 0x4

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast v4, Lcom/google/protobuf/MessageLite;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const/4 v5, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v5, v4}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    add-int/2addr v0, v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    goto :goto_2

    :cond_3
    const/4 v7, 0x3

    iget-object v3, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v3}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    if-nez v3, :cond_4

    const/4 v7, 0x1

    const/4 v3, 0x4

    const/4 v7, 0x6

    or-int/2addr v6, v3

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v6, 0x7

    move v7, v6

    invoke-static {v3, v4}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    add-int/2addr v0, v3

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget v3, p0, Lcom/google/protobuf/Api;->bitField0_:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    and-int/2addr v2, v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v2, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v2, 0x5

    move v7, v2

    const/4 v6, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getSourceContext()Lcom/google/protobuf/SourceContext;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v2, v3}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    add-int/2addr v0, v2

    :cond_5
    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-ge v1, v2, :cond_6

    const/4 v7, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    check-cast v2, Lcom/google/protobuf/MessageLite;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v3, 0x6

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v3, v2}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/2addr v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_3

    :cond_6
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v6, 0x6

    move v7, v6

    sget-object v2, Lcom/google/protobuf/Syntax;->SYNTAX_PROTO2:Lcom/google/protobuf/Syntax;

    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-virtual {v2}, Lcom/google/protobuf/Syntax;->getNumber()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eq v1, v2, :cond_7

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    const/4 v1, 0x7

    move v7, v1

    const/4 v6, 0x1

    move v7, v6

    iget v2, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v1, v2}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v1

    const/4 v7, 0x6

    add-int/2addr v0, v1

    :cond_7
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    add-int/2addr v0, v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    iput v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    return v0
.end method

.method public getSourceContext()Lcom/google/protobuf/SourceContext;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Api;->sourceContext_:Lcom/google/protobuf/SourceContext;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/SourceContext;->getDefaultInstance()Lcom/google/protobuf/SourceContext;

    move-result-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getSourceContextOrBuilder()Lcom/google/protobuf/SourceContextOrBuilder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Api;->sourceContext_:Lcom/google/protobuf/SourceContext;

    const/4 v2, 0x3

    const/4 v1, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/SourceContext;->getDefaultInstance()Lcom/google/protobuf/SourceContext;

    move-result-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public getSyntax()Lcom/google/protobuf/Syntax;
    .locals 3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/protobuf/Syntax;->forNumber(I)Lcom/google/protobuf/Syntax;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    sget-object v0, Lcom/google/protobuf/Syntax;->UNRECOGNIZED:Lcom/google/protobuf/Syntax;

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSyntaxValue()I
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public getVersion()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0
.end method

.method public getVersionBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method

.method public hasSourceContext()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/Api;->bitField0_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/Api;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/16 v1, 0x30b

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/2addr v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/2addr v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getMethodsCount()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-lez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getMethodsList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getOptionsCount()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-lez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getOptionsList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getVersion()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->hasSourceContext()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getSourceContext()Lcom/google/protobuf/SourceContext;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/SourceContext;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getMixinsCount()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-lez v0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x2

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getMixinsList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_4
    const/4 v2, 0x3

    move v3, v2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x7

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/2addr v1, v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget-object v0, Lcom/google/protobuf/ApiProto;->internal_static_google_protobuf_Api_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-class v1, Lcom/google/protobuf/Api;

    const-class v1, Lcom/google/protobuf/Api;

    const/4 v4, 0x7

    const-class v1, Lcom/google/protobuf/Api;

    const-class v1, Lcom/google/protobuf/Api;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-class v2, Lcom/google/protobuf/Api$Builder;

    const-class v2, Lcom/google/protobuf/Api$Builder;

    const/4 v4, 0x2

    const-class v2, Lcom/google/protobuf/Api$Builder;

    const-class v2, Lcom/google/protobuf/Api$Builder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-byte v0, p0, Lcom/google/protobuf/Api;->memoizedIsInitialized:B

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x2

    move v2, v1

    move v2, v1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v1

    :cond_0
    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v0

    :cond_1
    const/4 v3, 0x1

    iput-byte v1, p0, Lcom/google/protobuf/Api;->memoizedIsInitialized:B

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/Api$Builder;
    .locals 3

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/Api;->newBuilder()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Api$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/google/protobuf/Api$Builder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/Api$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/Api$1;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->newBuilderForType()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/Api;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Api$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->newBuilderForType()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    new-instance p1, Lcom/google/protobuf/Api;

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p1}, Lcom/google/protobuf/Api;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/Api$Builder;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lcom/google/protobuf/Api;->DEFAULT_INSTANCE:Lcom/google/protobuf/Api;

    const/4 v2, 0x3

    move v3, v2

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne p0, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Lcom/google/protobuf/Api$Builder;

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/google/protobuf/Api$Builder;-><init>(Lcom/google/protobuf/Api$1;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    new-instance v0, Lcom/google/protobuf/Api$Builder;

    const/4 v2, 0x4

    move v3, v2

    invoke-direct {v0, v1}, Lcom/google/protobuf/Api$Builder;-><init>(Lcom/google/protobuf/Api$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p0}, Lcom/google/protobuf/Api$Builder;->mergeFrom(Lcom/google/protobuf/Api;)Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->toBuilder()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->toBuilder()Lcom/google/protobuf/Api$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    iget-object v0, p0, Lcom/google/protobuf/Api;->name_:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    move v2, v0

    move v2, v0

    const/4 v6, 0x3

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ge v2, v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/google/protobuf/Api;->methods_:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    check-cast v3, Lcom/google/protobuf/MessageLite;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1, v4, v3}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x2

    move v2, v0

    move v2, v0

    const/4 v6, 0x1

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ge v2, v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/protobuf/Api;->options_:Ljava/util/List;

    const/4 v5, 0x0

    move v6, v5

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v3, Lcom/google/protobuf/MessageLite;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1, v4, v3}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_1

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v2, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v2, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/google/protobuf/Api;->version_:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {p1, v2, v3}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v2, p0, Lcom/google/protobuf/Api;->bitField0_:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    and-int/2addr v1, v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v1, 0x5

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Api;->getSourceContext()Lcom/google/protobuf/SourceContext;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1, v1, v2}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    :cond_4
    :goto_2
    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-ge v0, v1, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/protobuf/Api;->mixins_:Ljava/util/List;

    const/4 v5, 0x1

    move v6, v5

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v6, 0x2

    const/4 v2, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x6

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v6, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_2

    :cond_5
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget v0, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v5, 0x7

    move v6, v5

    sget-object v1, Lcom/google/protobuf/Syntax;->SYNTAX_PROTO2:Lcom/google/protobuf/Syntax;

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/Syntax;->getNumber()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eq v0, v1, :cond_6

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v0, 0x7

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/protobuf/Api;->syntax_:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_6
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void
.end method
