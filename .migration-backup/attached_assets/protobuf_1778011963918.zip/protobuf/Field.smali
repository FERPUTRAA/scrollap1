.class public final Lcom/google/protobuf/Field;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/google/protobuf/FieldOrBuilder;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/Field$Builder;,
        Lcom/google/protobuf/Field$Cardinality;,
        Lcom/google/protobuf/Field$Kind;
    }
.end annotation


# static fields
.field public static final CARDINALITY_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

.field public static final DEFAULT_VALUE_FIELD_NUMBER:I = 0xb

.field public static final JSON_NAME_FIELD_NUMBER:I = 0xa

.field public static final KIND_FIELD_NUMBER:I = 0x1

.field public static final NAME_FIELD_NUMBER:I = 0x4

.field public static final NUMBER_FIELD_NUMBER:I = 0x3

.field public static final ONEOF_INDEX_FIELD_NUMBER:I = 0x7

.field public static final OPTIONS_FIELD_NUMBER:I = 0x9

.field public static final PACKED_FIELD_NUMBER:I = 0x8

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Field;",
            ">;"
        }
    .end annotation
.end field

.field public static final TYPE_URL_FIELD_NUMBER:I = 0x6

.field private static final serialVersionUID:J


# instance fields
.field private cardinality_:I

.field private volatile defaultValue_:Ljava/lang/Object;

.field private volatile jsonName_:Ljava/lang/Object;

.field private kind_:I

.field private memoizedIsInitialized:B

.field private volatile name_:Ljava/lang/Object;

.field private number_:I

.field private oneofIndex_:I

.field private options_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/Option;",
            ">;"
        }
    .end annotation
.end field

.field private packed_:Z

.field private volatile typeUrl_:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance v0, Lcom/google/protobuf/Field;

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {v0}, Lcom/google/protobuf/Field;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    sput-object v0, Lcom/google/protobuf/Field;->DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/google/protobuf/Field$1;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/protobuf/Field$1;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v3, 0x6

    move v4, v3

    iput v0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/Field;->number_:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/Field;->oneofIndex_:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/google/protobuf/Field;->packed_:Z

    const/4 v4, 0x0

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v2, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-byte v2, p0, Lcom/google/protobuf/Field;->memoizedIsInitialized:B

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/protobuf/Field;->number_:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/protobuf/Field;->oneofIndex_:I

    const/4 v2, 0x0

    iput-boolean p1, p0, Lcom/google/protobuf/Field;->packed_:Z

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    iput-byte p1, p0, Lcom/google/protobuf/Field;->memoizedIsInitialized:B

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/google/protobuf/Field$1;)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/Field;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$1002(Lcom/google/protobuf/Field;Z)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ sn@r~vft~~db~~~@1u~@ b4 @@i ~c~o~ iM  @/~ol i~@~l~~ ~@m~f@@@ oa/. @ y~K@-~ ~o @o t @@S @@os~@b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/protobuf/Field;->packed_:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$1100(Lcom/google/protobuf/Field;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$1102(Lcom/google/protobuf/Field;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method static synthetic access$1200(Lcom/google/protobuf/Field;)Ljava/lang/Object;
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$1202(Lcom/google/protobuf/Field;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic access$300(Lcom/google/protobuf/Field;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$302(Lcom/google/protobuf/Field;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic access$400(Lcom/google/protobuf/Field;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget p0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic access$402(Lcom/google/protobuf/Field;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method static synthetic access$500(Lcom/google/protobuf/Field;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iget p0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    return p0
.end method

.method static synthetic access$502(Lcom/google/protobuf/Field;I)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput p1, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return p1
.end method

.method static synthetic access$602(Lcom/google/protobuf/Field;I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/protobuf/Field;->number_:I

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$700(Lcom/google/protobuf/Field;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    return-object p0
.end method

.method static synthetic access$702(Lcom/google/protobuf/Field;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-object p1
.end method

.method static synthetic access$800(Lcom/google/protobuf/Field;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$802(Lcom/google/protobuf/Field;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic access$902(Lcom/google/protobuf/Field;I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/protobuf/Field;->oneofIndex_:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/Field;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Field;->DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    sget-object v0, Lcom/google/protobuf/TypeProto;->internal_static_google_protobuf_Field_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/Field$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    sget-object v0, Lcom/google/protobuf/Field;->DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/Field;->toBuilder()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/Field;)Lcom/google/protobuf/Field$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Field;->DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Field;->toBuilder()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Lcom/google/protobuf/Field$Builder;->mergeFrom(Lcom/google/protobuf/Field;)Lcom/google/protobuf/Field$Builder;

    move-result-object p0

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x4

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Field;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast p0, Lcom/google/protobuf/Field;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Field;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-ne p1, p0, :cond_0

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    instance-of v1, p1, Lcom/google/protobuf/Field;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    return p1

    :cond_1
    const/4 v5, 0x2

    check-cast p1, Lcom/google/protobuf/Field;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v5, 0x0

    iget v2, p1, Lcom/google/protobuf/Field;->kind_:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eq v1, v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v3

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v1, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v5, 0x6

    iget v2, p1, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eq v1, v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v3

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getNumber()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getNumber()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eq v1, v2, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v3

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    return v3

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getTypeUrl()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getTypeUrl()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v1, :cond_6

    const/4 v5, 0x5

    return v3

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getOneofIndex()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getOneofIndex()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eq v1, v2, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v3

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getPacked()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getPacked()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v2, :cond_8

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    return v3

    :cond_8
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getOptionsList()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getOptionsList()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_9

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    return v3

    :cond_9
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getJsonName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getJsonName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v3

    :cond_a
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getDefaultValue()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/Field;->getDefaultValue()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    if-nez v1, :cond_b

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v3

    :cond_b
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez p1, :cond_c

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    return v3

    :cond_c
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v0
.end method

.method public getCardinality()Lcom/google/protobuf/Field$Cardinality;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/protobuf/Field$Cardinality;->forNumber(I)Lcom/google/protobuf/Field$Cardinality;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Field$Cardinality;->UNRECOGNIZED:Lcom/google/protobuf/Field$Cardinality;

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getCardinalityValue()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/Field;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Field;->DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getDefaultInstanceForType()Lcom/google/protobuf/Field;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getDefaultInstanceForType()Lcom/google/protobuf/Field;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public getDefaultValue()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0
.end method

.method public getDefaultValueBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public getJsonName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v2, 0x2

    or-int/2addr v3, v2

    return-object v0
.end method

.method public getJsonNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0
.end method

.method public getKind()Lcom/google/protobuf/Field$Kind;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-static {v0}, Lcom/google/protobuf/Field$Kind;->forNumber(I)Lcom/google/protobuf/Field$Kind;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Field$Kind;->UNRECOGNIZED:Lcom/google/protobuf/Field$Kind;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getKindValue()I
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x5

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public getName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method

.method public getNumber()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/Field;->number_:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public getOneofIndex()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/Field;->oneofIndex_:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public getOptions(I)Lcom/google/protobuf/Option;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p1, Lcom/google/protobuf/Option;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method

.method public getOptionsCount()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public getOptionsList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Option;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public getOptionsOrBuilder(I)Lcom/google/protobuf/OptionOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p1, Lcom/google/protobuf/OptionOrBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p1
.end method

.method public getOptionsOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/OptionOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public getPacked()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/google/protobuf/Field;->packed_:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/Field;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/Field;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x4

    const/4 v1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eq v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object v1, Lcom/google/protobuf/Field$Kind;->TYPE_UNKNOWN:Lcom/google/protobuf/Field$Kind;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/protobuf/Field$Kind;->getNumber()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v0, v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    move v0, v2

    move v0, v2

    const/4 v5, 0x1

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object v3, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_UNKNOWN:Lcom/google/protobuf/Field$Cardinality;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v3}, Lcom/google/protobuf/Field$Cardinality;->getNumber()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq v1, v3, :cond_2

    const/4 v4, 0x5

    move v5, v4

    const/4 v1, 0x2

    move v5, v1

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget v3, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1, v3}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    add-int/2addr v0, v1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/protobuf/Field;->number_:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/2addr v0, v1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v1, 0x4

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v3, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1, v3}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/2addr v0, v1

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez v1, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1, v3}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-int/2addr v0, v1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/protobuf/Field;->oneofIndex_:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v1, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v3, 0x7

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v0, v1

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-boolean v1, p0, Lcom/google/protobuf/Field;->packed_:Z

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v1, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/16 v3, 0x8

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v0, v1

    :cond_7
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ge v2, v1, :cond_8

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/16 v3, 0x9

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v3, v1}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v1

    const/4 v4, 0x4

    move v5, v4

    add-int/2addr v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_1

    :cond_8
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-nez v1, :cond_9

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/16 v1, 0xa

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v4, 0x3

    invoke-static {v1, v2}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/2addr v0, v1

    :cond_9
    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_a

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/16 v1, 0xb

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/2addr v0, v1

    :cond_a
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    return v0
.end method

.method public getTypeUrl()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public getTypeUrlBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x6

    move v3, v2

    return-object v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v2, 0x0

    move v3, v2

    invoke-static {}, Lcom/google/protobuf/Field;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/16 v1, 0x30b

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/2addr v1, v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getNumber()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getTypeUrl()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getOneofIndex()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x8

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getPacked()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getOptionsCount()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-lez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x9

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getOptionsList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getJsonName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0xb

    const/4 v2, 0x6

    move v3, v2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/2addr v1, v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v0, Lcom/google/protobuf/TypeProto;->internal_static_google_protobuf_Field_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const-class v1, Lcom/google/protobuf/Field;

    const-class v1, Lcom/google/protobuf/Field;

    const/4 v4, 0x5

    const-class v1, Lcom/google/protobuf/Field;

    const-class v1, Lcom/google/protobuf/Field;

    const/4 v4, 0x6

    const-class v2, Lcom/google/protobuf/Field$Builder;

    const-class v2, Lcom/google/protobuf/Field$Builder;

    const/4 v4, 0x5

    const-class v2, Lcom/google/protobuf/Field$Builder;

    const-class v2, Lcom/google/protobuf/Field$Builder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-byte v0, p0, Lcom/google/protobuf/Field;->memoizedIsInitialized:B

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-byte v1, p0, Lcom/google/protobuf/Field;->memoizedIsInitialized:B

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/Field$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/Field;->newBuilder()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Field$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Lcom/google/protobuf/Field$Builder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/Field$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/Field$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->newBuilderForType()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/Field;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Field$Builder;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->newBuilderForType()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    new-instance p1, Lcom/google/protobuf/Field;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p1}, Lcom/google/protobuf/Field;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/Field$Builder;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lcom/google/protobuf/Field;->DEFAULT_INSTANCE:Lcom/google/protobuf/Field;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne p0, v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v0, Lcom/google/protobuf/Field$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/protobuf/Field$Builder;-><init>(Lcom/google/protobuf/Field$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v0, Lcom/google/protobuf/Field$Builder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/Field$Builder;-><init>(Lcom/google/protobuf/Field$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Lcom/google/protobuf/Field$Builder;->mergeFrom(Lcom/google/protobuf/Field;)Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->toBuilder()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Field;->toBuilder()Lcom/google/protobuf/Field$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget-object v1, Lcom/google/protobuf/Field$Kind;->TYPE_UNKNOWN:Lcom/google/protobuf/Field$Kind;

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/Field$Kind;->getNumber()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq v0, v1, :cond_0

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/Field;->kind_:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v4, 0x2

    sget-object v1, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_UNKNOWN:Lcom/google/protobuf/Field$Cardinality;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1}, Lcom/google/protobuf/Field$Cardinality;->getNumber()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eq v0, v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/protobuf/Field;->cardinality_:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/Field;->number_:I

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/protobuf/Field;->name_:Ljava/lang/Object;

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_4

    const/4 v3, 0x7

    and-int/2addr v4, v3

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/protobuf/Field;->typeUrl_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/Field;->oneofIndex_:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x7

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V

    :cond_5
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/Field;->packed_:Z

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/16 v1, 0x8

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ge v0, v1, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/Field;->options_:Ljava/util/List;

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/16 v2, 0x9

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-nez v0, :cond_8

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/16 v0, 0xa

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/protobuf/Field;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_8
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/google/protobuf/GeneratedMessageV3;->isStringEmpty(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_9

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/16 v0, 0xb

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/protobuf/Field;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_9
    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method
