.class public Lcom/google/protobuf/MapFieldBuilder;
.super Lcom/google/protobuf/MapFieldReflectionAccessor;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/MapFieldBuilder$Converter;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<KeyT:",
        "Ljava/lang/Object;",
        "MessageOrBuilderT::",
        "Lcom/google/protobuf/MessageOrBuilder;",
        "MessageT:TMessageOrBuilderT;BuilderT:TMessageOrBuilderT;>",
        "Lcom/google/protobuf/MapFieldReflectionAccessor;"
    }
.end annotation


# instance fields
.field builderMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TKeyT;TMessageOrBuilderT;>;"
        }
    .end annotation
.end field

.field converter:Lcom/google/protobuf/MapFieldBuilder$Converter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/MapFieldBuilder$Converter<",
            "TKeyT;TMessageOrBuilderT;TMessageT;>;"
        }
    .end annotation
.end field

.field messageList:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/Message;",
            ">;"
        }
    .end annotation
.end field

.field messageMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "TKeyT;TMessageT;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/google/protobuf/MapFieldBuilder$Converter;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "converter"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/MapFieldBuilder$Converter<",
            "TKeyT;TMessageOrBuilderT;TMessageT;>;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/MapFieldReflectionAccessor;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v1, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method private getMapEntryList()Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/MapEntry<",
            "TKeyT;TMessageT;>;>;"
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "l~s@@~f@o @s@ ~S4~mfu.~i@@M1@o~c@tvri/oi@l  b  @   ~@~~ od~n~~@o @~~@ @~at@~  ~-~yK@ b~o ~b~/ @~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v1}, Lcom/google/protobuf/MapFieldBuilder$Converter;->defaultEntry()Lcom/google/protobuf/MapEntry;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/MapEntry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    check-cast v1, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v3, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    check-cast v3, Lcom/google/protobuf/Message;

    move-object v4, v3

    move-object v4, v3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    check-cast v4, Lcom/google/protobuf/MapEntry;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v4}, Lcom/google/protobuf/MapEntry;->getValue()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, v5}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v5, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v4}, Lcom/google/protobuf/MapFieldBuilder$Converter;->defaultEntry()Lcom/google/protobuf/MapEntry;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v4}, Lcom/google/protobuf/MapEntry;->toBuilder()Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v4, v3}, Lcom/google/protobuf/AbstractMessage$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/AbstractMessage$Builder;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    check-cast v3, Lcom/google/protobuf/MapEntry$Builder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    invoke-virtual {v3}, Lcom/google/protobuf/MapEntry$Builder;->build()Lcom/google/protobuf/MapEntry;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object v0
.end method

.method private populateMutableMap()Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TKeyT;TMessageT;>;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object v0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-interface {v4, v2}, Lcom/google/protobuf/MapFieldBuilder$Converter;->build(Lcom/google/protobuf/MessageOrBuilder;)Lcom/google/protobuf/MessageOrBuilder;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-object v0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/MapFieldBuilder;->getMapEntryList()Ljava/util/List;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    check-cast v2, Lcom/google/protobuf/MapEntry;

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v6, 0x3

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object v0
.end method

.method private typedEquals(Lcom/google/protobuf/MapFieldBuilder;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/MapFieldBuilder<",
            "TKeyT;TMessageOrBuilderT;TMessageT;TBuilderT;>;)Z"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/google/protobuf/MapFieldLite;->equals(Ljava/util/Map;Ljava/util/Map;)Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p1
.end method


# virtual methods
.method public build(Lcom/google/protobuf/MapEntry;)Lcom/google/protobuf/MapField;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "defaultEntry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/MapEntry<",
            "TKeyT;TMessageT;>;)",
            "Lcom/google/protobuf/MapField<",
            "TKeyT;TMessageT;>;"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/protobuf/MapField;->newMapField(Lcom/google/protobuf/MapEntry;)Lcom/google/protobuf/MapField;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/MapField;->getMutableMap()Ljava/util/Map;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-interface {v4, v2}, Lcom/google/protobuf/MapFieldBuilder$Converter;->build(Lcom/google/protobuf/MessageOrBuilder;)Lcom/google/protobuf/MessageOrBuilder;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/MapField;->makeImmutable()V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-object p1
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public copy()Lcom/google/protobuf/MapFieldBuilder;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/MapFieldBuilder<",
            "TKeyT;TMessageOrBuilderT;TMessageT;TBuilderT;>;"
        }
    .end annotation

    const/4 v4, 0x7

    new-instance v0, Lcom/google/protobuf/MapFieldBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/MapFieldBuilder;-><init>(Lcom/google/protobuf/MapFieldBuilder$Converter;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {v1, v2}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-object v0
.end method

.method public ensureBuilderMap()Ljava/util/Map;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TKeyT;TMessageOrBuilderT;>;"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-object v0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v0, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v5, 0x5

    move v6, v5

    iget-object v3, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v3, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object v0

    :cond_2
    const/4 v5, 0x2

    move v6, v5

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v6, 0x6

    const/4 v5, 0x4

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v0, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/MapFieldBuilder;->getMapEntryList()Ljava/util/List;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v2, Lcom/google/protobuf/MapEntry;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v3, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v6, 0x5

    const/4 v5, 0x6

    return-object v0
.end method

.method public ensureMessageList()Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Message;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x7

    move v7, v6

    iget-object v3, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {v4}, Lcom/google/protobuf/MapFieldBuilder$Converter;->defaultEntry()Lcom/google/protobuf/MapEntry;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-virtual {v4}, Lcom/google/protobuf/MapEntry;->toBuilder()Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-virtual {v4, v5}, Lcom/google/protobuf/MapEntry$Builder;->setKey(Ljava/lang/Object;)Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v5, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-interface {v5, v2}, Lcom/google/protobuf/MapFieldBuilder$Converter;->build(Lcom/google/protobuf/MessageOrBuilder;)Lcom/google/protobuf/MessageOrBuilder;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v4, v2}, Lcom/google/protobuf/MapEntry$Builder;->setValue(Ljava/lang/Object;)Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry$Builder;->build()Lcom/google/protobuf/MapEntry;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    iput-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-object v0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v7, 0x3

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map;->size()I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v0, v2}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v6, 0x0

    shr-int/2addr v7, v6

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-interface {v4}, Lcom/google/protobuf/MapFieldBuilder$Converter;->defaultEntry()Lcom/google/protobuf/MapEntry;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v4}, Lcom/google/protobuf/MapEntry;->toBuilder()Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-virtual {v4, v5}, Lcom/google/protobuf/MapEntry$Builder;->setKey(Ljava/lang/Object;)Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    check-cast v2, Lcom/google/protobuf/MessageOrBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v2}, Lcom/google/protobuf/MapEntry$Builder;->setValue(Ljava/lang/Object;)Lcom/google/protobuf/MapEntry$Builder;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2}, Lcom/google/protobuf/MapEntry$Builder;->build()Lcom/google/protobuf/MapEntry;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    iput-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-object v0
.end method

.method public ensureMessageMap()Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TKeyT;TMessageT;>;"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/MapFieldBuilder;->populateMutableMap()Ljava/util/Map;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->messageMap:Ljava/util/Map;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->builderMap:Ljava/util/Map;

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object v1, p0, Lcom/google/protobuf/MapFieldBuilder;->messageList:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "object"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    instance-of v0, p1, Lcom/google/protobuf/MapFieldBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p1, Lcom/google/protobuf/MapFieldBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/MapFieldBuilder;->typedEquals(Lcom/google/protobuf/MapFieldBuilder;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p1
.end method

.method public getImmutableMap()Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TKeyT;TMessageT;>;"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    new-instance v0, Lcom/google/protobuf/MapField$MutabilityAwareMap;

    const/4 v4, 0x1

    sget-object v1, Lcom/google/protobuf/MutabilityOracle;->IMMUTABLE:Lcom/google/protobuf/MutabilityOracle;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/MapFieldBuilder;->populateMutableMap()Ljava/util/Map;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/MapField$MutabilityAwareMap;-><init>(Lcom/google/protobuf/MutabilityOracle;Ljava/util/Map;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-object v0
.end method

.method getList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Message;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureMessageList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method getMapEntryMessageDefaultInstance()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/MapFieldBuilder;->converter:Lcom/google/protobuf/MapFieldBuilder$Converter;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0}, Lcom/google/protobuf/MapFieldBuilder$Converter;->defaultEntry()Lcom/google/protobuf/MapEntry;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method getMutableList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Message;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureMessageList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/MapFieldLite;->calculateHashCodeForMap(Ljava/util/Map;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public mergeFrom(Lcom/google/protobuf/MapField;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/MapField<",
            "TKeyT;TMessageT;>;)V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/MapFieldBuilder;->ensureBuilderMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/MapField;->getMap()Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/google/protobuf/MapFieldLite;->copy(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method
