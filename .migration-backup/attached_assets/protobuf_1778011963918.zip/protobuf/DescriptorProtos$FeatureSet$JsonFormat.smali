.class public final enum Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/protobuf/ProtocolMessageEnum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos$FeatureSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "JsonFormat"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;",
        ">;",
        "Lcom/google/protobuf/ProtocolMessageEnum;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

.field public static final enum ALLOW:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

.field public static final ALLOW_VALUE:I = 0x1

.field public static final enum JSON_FORMAT_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

.field public static final JSON_FORMAT_UNKNOWN_VALUE:I = 0x0

.field public static final enum LEGACY_BEST_EFFORT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

.field public static final LEGACY_BEST_EFFORT_VALUE:I = 0x2

.field private static final VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string v1, "FJsMOSORNKN_sNONW_T"

    const-string v1, "NKs_UO_NOJNNTFMSROW"

    const/4 v8, 0x6

    const-string v1, "ONMmJATNU_FNKOWNRSO"

    const-string v1, "JSON_FORMAT_UNKNOWN"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->JSON_FORMAT_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance v1, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v3, "ALWOo"

    const-string v3, "AWOmL"

    const/4 v8, 0x5

    const-string v3, "bALLW"

    const-string v3, "ALLOW"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x7

    invoke-direct {v1, v3, v4, v4}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    sput-object v1, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->ALLOW:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    new-instance v3, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string v5, "LEGACY_BEST_EFFORT"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v3, v5, v6, v6}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    sput-object v3, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->LEGACY_BEST_EFFORT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x2

    const/4 v5, 0x4

    const/4 v8, 0x7

    const/4 v5, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-array v5, v5, [Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    aput-object v0, v5, v2

    const/4 v7, 0x0

    xor-int/2addr v8, v7

    aput-object v1, v5, v4

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    aput-object v3, v5, v6

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    sput-object v5, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->$VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x6

    const/4 v7, 0x5

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat$1;

    const/4 v8, 0x1

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat$1;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->values()[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v8, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p3, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->value:I

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public static forNumber(I)Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o1S@@ u i@~m~ban~@~@b~i~~~otv~dsK@u @b  @  @y@~~ @ o @-~~~r~@ ~ @t ~@ofi ~oc4@of @@ ~~l. @~~@/lM"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    if-eqz p0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq p0, v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eq p0, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 p0, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->LEGACY_BEST_EFFORT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->ALLOW:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0

    :cond_2
    const/4 v2, 0x5

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->JSON_FORMAT_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getEnumTypes()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x5

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public static valueOf(I)Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-object p0
.end method

.method public static valueOf(Lcom/google/protobuf/Descriptors$EnumValueDescriptor;)Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "desc"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getType()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getIndex()I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    aget-object p0, v0, p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "tuprltipyiDooVeio cm usehspnorftsnar e  t"

    const-string v0, " aepouhrtsuocyEtlp tseo itosifn eD Vrrmni"

    const/4 v3, 0x0

    const-string v0, "EnumValueDescriptor is not for this type."

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x7

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->$VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast v0, [Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public final getDescriptorForType()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public final getNumber()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->value:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public final getValueDescriptor()Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$JsonFormat;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->getValues()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0
.end method
