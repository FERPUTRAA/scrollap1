.class final Lcom/google/protobuf/MapFieldSchemas;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/protobuf/CheckReturnValue;
.end annotation


# static fields
.field private static final FULL_SCHEMA:Lcom/google/protobuf/MapFieldSchema;

.field private static final LITE_SCHEMA:Lcom/google/protobuf/MapFieldSchema;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/MapFieldSchemas;->loadSchemaForFullRuntime()Lcom/google/protobuf/MapFieldSchema;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    sput-object v0, Lcom/google/protobuf/MapFieldSchemas;->FULL_SCHEMA:Lcom/google/protobuf/MapFieldSchema;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lcom/google/protobuf/MapFieldSchemaLite;

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/google/protobuf/MapFieldSchemaLite;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object v0, Lcom/google/protobuf/MapFieldSchemas;->LITE_SCHEMA:Lcom/google/protobuf/MapFieldSchema;

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method static full()Lcom/google/protobuf/MapFieldSchema;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s ~ v 1bio@. tcn/@~ @ybK~~b/a i@ ~@o~~~ @~@~f  ~~ ~ ~@ -mo@~@@~ ~lM4~~s@ or@oo@~@dfl@S~i@ut@@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/MapFieldSchemas;->FULL_SCHEMA:Lcom/google/protobuf/MapFieldSchema;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method static lite()Lcom/google/protobuf/MapFieldSchema;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/MapFieldSchemas;->LITE_SCHEMA:Lcom/google/protobuf/MapFieldSchema;

    const/4 v2, 0x1

    return-object v0
.end method

.method private static loadSchemaForFullRuntime()Lcom/google/protobuf/MapFieldSchema;
    .locals 5

    :try_start_0
    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-class v0, Lcom/google/protobuf/MapFieldSchemaFull;

    const-class v0, Lcom/google/protobuf/MapFieldSchemaFull;

    const/4 v4, 0x1

    const-class v0, Lcom/google/protobuf/MapFieldSchemaFull;

    const-class v0, Lcom/google/protobuf/MapFieldSchemaFull;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    check-cast v0, Lcom/google/protobuf/MapFieldSchema;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    move v4, v3

    return-object v0

    :catch_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0
.end method
