.class public interface abstract Lcom/google/protobuf/BoolValueOrBuilder;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/protobuf/MessageOrBuilder;


# virtual methods
.method public abstract getValue()Z
.end method
