.class synthetic Lcom/google/protobuf/ManifestSchemaFactory$2;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/ManifestSchemaFactory;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic $SwitchMap$com$google$protobuf$ProtoSyntax:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    invoke-static {}, Lcom/google/protobuf/ProtoSyntax;->values()[Lcom/google/protobuf/ProtoSyntax;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    array-length v0, v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-array v0, v0, [I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    sput-object v0, Lcom/google/protobuf/ManifestSchemaFactory$2;->$SwitchMap$com$google$protobuf$ProtoSyntax:[I

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v1, Lcom/google/protobuf/ProtoSyntax;->PROTO3:Lcom/google/protobuf/ProtoSyntax;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method
