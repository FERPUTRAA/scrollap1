.class public final Lcom/google/protobuf/Descriptors$FieldDescriptor;
.super Lcom/google/protobuf/Descriptors$GenericDescriptor;

# interfaces
.implements Ljava/lang/Comparable;
.implements Lcom/google/protobuf/FieldSet$FieldDescriptorLite;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Descriptors;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FieldDescriptor"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;,
        Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/Descriptors$GenericDescriptor;",
        "Ljava/lang/Comparable<",
        "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
        ">;",
        "Lcom/google/protobuf/FieldSet$FieldDescriptorLite<",
        "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
        ">;"
    }
.end annotation


# static fields
.field private static final NUMBER_GETTER:Lcom/google/protobuf/Descriptors$NumberGetter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Descriptors$NumberGetter<",
            "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
            ">;"
        }
    .end annotation
.end field

.field private static final table:[Lcom/google/protobuf/WireFormat$FieldType;


# instance fields
.field private containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

.field private containingType:Lcom/google/protobuf/Descriptors$Descriptor;

.field private defaultValue:Ljava/lang/Object;

.field private enumType:Lcom/google/protobuf/Descriptors$EnumDescriptor;

.field private final extensionScope:Lcom/google/protobuf/Descriptors$Descriptor;

.field private final file:Lcom/google/protobuf/Descriptors$FileDescriptor;

.field private final fullName:Ljava/lang/String;

.field private final index:I

.field private final isProto3Optional:Z

.field private jsonName:Ljava/lang/String;

.field private messageType:Lcom/google/protobuf/Descriptors$Descriptor;

.field private proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

.field private type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Lcom/google/protobuf/Descriptors$FieldDescriptor$1;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor$1;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    sput-object v0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->NUMBER_GETTER:Lcom/google/protobuf/Descriptors$NumberGetter;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/WireFormat$FieldType;->values()[Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->table:[Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->access$3000()[Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    array-length v0, v0

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;->values()[Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    array-length v1, v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "sps.oudeDp ddybel ptsvrd tria  ssen/iccdr..  eeo/set trortwcrpa hepaatwasjnaau"

    const-string v1, "bcsp ryorj n eu lcaar dsowtsrdtpd.Dnrsa.pespeeaut haaedp.s/itr w ectvte t/ioda"

    const/4 v3, 0x5

    const-string v1, "eismhtpar ssretadpesaraucv sd dtl.ddp//cnp et  twn t.pewDycra itoojr.uaear boo"

    const-string v1, "descriptor.proto has a new declared type but Descriptors.java wasn\'t updated."

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    throw v0
.end method

.method private constructor <init>(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "proto",
            "file",
            "parent",
            "index",
            "isExtension"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/Descriptors$GenericDescriptor;-><init>(Lcom/google/protobuf/Descriptors$1;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput p4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->index:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getName()Ljava/lang/String;

    move-result-object p4

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p2, p3, p4}, Lcom/google/protobuf/Descriptors;->access$2300(Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->fullName:Ljava/lang/String;

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasType()Z

    move-result p4

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz p4, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p4}, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->valueOf(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;)Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object p4

    const/4 v2, 0x1

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getProto3Optional()Z

    move-result p4

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-boolean p4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isProto3Optional:Z

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result p4

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-lez p4, :cond_8

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p5, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result p4

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p4, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p3, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->extensionScope:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->extensionScope:Lcom/google/protobuf/Descriptors$Descriptor;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOneofIndex()Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto/16 :goto_2

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x7

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const-string/jumbo p2, "lionocores.DFnefoP io ieolde srre e_ifmetnt.ddinxprototxe"

    const-string/jumbo p2, "oDemtiei edrlx_.nponrsntooe. oP oeieifordtiefce nfsdxFrtl"

    const/4 v2, 0x3

    const-string p2, ".ernfbnl etoxfpF ss_D teoldftoenPreeiii roordeintc.osoeix"

    const-string p2, "FieldDescriptorProto.oneof_index set for extension field."

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v2, 0x1

    throw p1

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v1, 0x5

    move v2, v1

    const-string/jumbo p2, "xxesleuPtrr iteieefoottoiolton.dpDf e.setonerFo   denedscn"

    const-string/jumbo p2, "ioxnodoesttnpoelPeres oeilr t.fefi detstDin ee. entcFdorox"

    const/4 v2, 0x1

    const-string p2, "eerfnPppo o e istdfoxddoieliieeeeottoss n tcF.lneDr.ettxnr"

    const-string p2, "FieldDescriptorProto.extendee not set for extension field."

    const/4 v2, 0x4

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    throw p1

    :cond_4
    const/4 v2, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result p4

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez p4, :cond_7

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOneofIndex()Z

    move-result p4

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz p4, :cond_6

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOneofIndex()I

    move-result p4

    const/4 v2, 0x1

    const/4 v1, 0x5

    if-ltz p4, :cond_5

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOneofIndex()I

    move-result p4

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p3}, Lcom/google/protobuf/Descriptors$Descriptor;->toProto()Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    move-result-object p5

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p5}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDeclCount()I

    move-result p5

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ge p4, p5, :cond_5

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p3}, Lcom/google/protobuf/Descriptors$Descriptor;->getOneofs()Ljava/util/List;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOneofIndex()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {p3, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p1, Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->access$2608(Lcom/google/protobuf/Descriptors$OneofDescriptor;)I

    const/4 v1, 0x5

    and-int/2addr v2, v1

    goto :goto_1

    :cond_5
    const/4 v1, 0x7

    move v2, v1

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string/jumbo p4, "ueyo o dqnffge iF o rDrxnpiosre_pPttnl.ostioi roeetefrc da"

    const-string p4, "FieldDescriptorProto.oneof_index is out of range for type "

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p3}, Lcom/google/protobuf/Descriptors$Descriptor;->getName()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p1

    :cond_6
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

    :goto_1
    const/4 v1, 0x7

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->extensionScope:Lcom/google/protobuf/Descriptors$Descriptor;

    :goto_2
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1, p0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->addSymbol(Lcom/google/protobuf/Descriptors$GenericDescriptor;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-void

    :cond_7
    const/4 v2, 0x7

    const/4 v1, 0x0

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo p2, "sesrtndtxor eeldtriie-osntn fte.fde pFsxn oenPer.oieceDbli"

    const-string/jumbo p2, "on rnbFr.-eenliiPocselttfeDieotttefosodedrx  pixne.resedn "

    const/4 v2, 0x2

    const-string/jumbo p2, "tiemetnxledtcoeneoiesFo.fnd.nnri-eDferp rotsetr o  ioldexs"

    const-string p2, "FieldDescriptorProto.extendee set for non-extension field."

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    throw p1

    :cond_8
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p2, " ritoburmeseFeolb .psi i iudgstvetsu ene"

    const-string/jumbo p2, "iebr tue elusnetFd.e bvr moismssupgti ie"

    const/4 v2, 0x7

    const-string/jumbo p2, "uttenbd reeiibslupeFtsvs i oes.e rnmm ig"

    const-string p2, "Field numbers must be positive integers."

    const/4 v2, 0x4

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw p1
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;IZLcom/google/protobuf/Descriptors$1;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct/range {p0 .. p5}, Lcom/google/protobuf/Descriptors$FieldDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;IZ)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$1400(Lcom/google/protobuf/Descriptors$FieldDescriptor;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @~K@@ud~ ~o b1iu ro~fc~fo@~ m@~S@ ~ @~@ ~~.@@~@lo~l@ @ 4~@bb~~@ ~t~@y-o v/@s o@i   ~~/~@aMi~n @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->crossLink()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$1800(Lcom/google/protobuf/Descriptors$FieldDescriptor;Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->setProto(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$2000()Lcom/google/protobuf/Descriptors$NumberGetter;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->NUMBER_GETTER:Lcom/google/protobuf/Descriptors$NumberGetter;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic access$4200(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget-boolean p0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isProto3Optional:Z

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p0
.end method

.method private crossLink()V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v1, " si yo pespt metang//as ."

    const/4 v7, 0x7

    const-string/jumbo v1, "mtes  spayn t/.ep/gsa  ie"

    const-string v1, "\" is not a message type."

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/16 v2, 0x22

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v6, 0x3

    if-eqz v0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v4}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getExtendee()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget-object v5, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->TYPES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0, v4, p0, v5}, Lcom/google/protobuf/Descriptors$DescriptorPool;->lookupSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$GenericDescriptor;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    instance-of v4, v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v4, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x2

    check-cast v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x4

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0, v4}, Lcom/google/protobuf/Descriptors$Descriptor;->isExtensionNumber(I)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Lcom/google/protobuf/Descriptors$Descriptor;->getFullName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v2, "d/ao eqtqc oslredn e"

    const-string v2, " /asle dqtco ndeer o"

    const/4 v7, 0x0

    const-string v2, " ssedeae/d o /lcrnt "

    const-string v2, "\" does not declare "

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v2, "brom ei.euxnasen  sman t"

    const-string v2, " as an extension number."

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    throw v0

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v2}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getExtendee()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    throw v0

    :cond_2
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasTypeName()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v0, :cond_b

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v4}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v5, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->TYPES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0, v4, p0, v5}, Lcom/google/protobuf/Descriptors$DescriptorPool;->lookupSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$GenericDescriptor;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v4}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasType()Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez v4, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    instance-of v4, v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v4, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x2

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput-object v4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_1

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    instance-of v4, v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    if-eqz v4, :cond_4

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-object v4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_1

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v2}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const-string v2, "/ot oa/i.sy n tse"

    const-string v2, "/ s eot t /yans.i"

    const/4 v7, 0x5

    const-string/jumbo v2, "tn/t b s.e/pi  oy"

    const-string v2, "\" is not a type."

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    throw v0

    :cond_5
    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    sget-object v5, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ne v4, v5, :cond_8

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    instance-of v4, v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v4, :cond_7

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    check-cast v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->messageType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-nez v0, :cond_6

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_2

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v1, "eslfasuae  dsh/m sguvalaeee/vnat cMu"

    const-string v1, "ecvme  edg/Mfauh /assela atsntlasuve"

    const/4 v7, 0x5

    const-string/jumbo v1, "tehe.sspdt aa//lacvuf ulgesMavns eae"

    const-string v1, "Messages can\'t have default values."

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    throw v0

    :cond_7
    const/4 v7, 0x7

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    invoke-virtual {v2}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    throw v0

    :cond_8
    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-ne v1, v4, :cond_a

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    instance-of v1, v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v1, :cond_9

    const/4 v7, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->enumType:Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto/16 :goto_2

    :cond_9
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x1

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    move v7, v6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v2, "mne/e. iqoo ntsn/pyt a "

    const-string/jumbo v2, "n/eyo te  aios tmn.n p/"

    const/4 v7, 0x3

    const-string/jumbo v2, "nessopn  ymt/ / .intu e"

    const-string v2, "\" is not an enum type."

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    throw v0

    :cond_a
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v1, "pp mnart shF_ .mvi ibayeittmpehilwedyt i"

    const-string v1, ". hyibm mee peenh tsFra ltii_yppwiadtitv"

    const-string v1, "Field with primitive type has type_name."

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    throw v0

    :cond_b
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eq v0, v1, :cond_1d

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eq v0, v1, :cond_1d

    :goto_2
    const/4 v7, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getPacked()Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v0, :cond_d

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isPackable()Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    if-eqz v0, :cond_c

    const/4 v7, 0x6

    goto :goto_3

    :cond_c
    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v1, "t rioedibd[d  pyetctenellref.ni rusfee mcdreiv  iuf eoie p]ckaoasp a"

    const-string/jumbo v1, "trinueu sre  paia eat fpet rnpoifpmcf r c]e dideleslibedyv[deeo.i ck"

    const/4 v7, 0x5

    const-string v1, "doalib  s drrebin ]e[unakfl ipctedp.cef ov cespit=riafeee teyei  pmr"

    const-string v1, "[packed = true] can only be specified for repeated primitive fields."

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    throw v0

    :cond_d
    :goto_3
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_16

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v0, :cond_15

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v0, Lcom/google/protobuf/Descriptors$1;->$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$Type:[I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    aget v0, v0, v1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_1

    const/4 v7, 0x2

    const-string/jumbo v1, "nan"

    const-string v1, "ann"

    const/4 v7, 0x5

    const-string/jumbo v1, "nan"

    const-string/jumbo v1, "nan"

    const/4 v7, 0x4

    const-string v4, "-nfi"

    const-string/jumbo v4, "nif-"

    const/4 v7, 0x7

    const-string/jumbo v4, "ifn-"

    const-string v4, "-inf"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v5, "inf"

    const-string v5, "fin"

    const/4 v7, 0x1

    const-string v5, "fin"

    const-string/jumbo v5, "inf"

    const/4 v7, 0x5

    packed-switch v0, :pswitch_data_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto/16 :goto_4

    :pswitch_0
    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo v1, "tuvspauelf.sha dee  gaetlpuy ed"

    const-string v1, "hp lfsepeuavee.da ta  slgydeuta"

    const/4 v7, 0x5

    const-string v1, "hleg.uapM auptsfda eeyetsa el d"

    const-string v1, "Message type had default value."

    const/4 v6, 0x2

    move v7, v6

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    throw v0

    :pswitch_1
    const/4 v7, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->enumType:Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v7, 0x6

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->findValueByName(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    if-eqz v0, :cond_e

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto/16 :goto_4

    :cond_e
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v4, "nk wnvmeq t ule/oalunu:/a fUnq"

    const-string v4, "f/aoelnlqnut  anm eeukwv:n/U u"

    const/4 v7, 0x0

    const-string v4, "easnln efvUe /wm aud/nl: ktuno"

    const-string v4, "Unknown enum default value: \""

    const/4 v6, 0x2

    and-int/2addr v7, v6

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    iget-object v4, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v4}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x1

    move v7, v6

    throw v0
    :try_end_1
    .catch Ljava/lang/NumberFormatException; {:try_start_1 .. :try_end_1} :catch_1

    :pswitch_2
    :try_start_2
    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/google/protobuf/TextFormat;->unescapeBytes(Ljava/lang/CharSequence;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;
    :try_end_2
    .catch Lcom/google/protobuf/TextFormat$InvalidEscapeSequenceException; {:try_start_2 .. :try_end_2} :catch_0
    .catch Ljava/lang/NumberFormatException; {:try_start_2 .. :try_end_2} :catch_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto/16 :goto_4

    :catch_0
    move-exception v0

    :try_start_3
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance v1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v5, "e/emlvralslnautdou uCpft :s a e"

    const-string/jumbo v5, "o s/u Ce/t eluellsnvaaaudt:pfr "

    const/4 v7, 0x1

    const-string v5, " feuo:/lsur aptv/ oeduledtalna "

    const-string v5, "Couldn\'t parse default value: "

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {v1, p0, v4, v0, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Ljava/lang/Throwable;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    throw v1

    :pswitch_3
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto/16 :goto_4

    :pswitch_4
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Ljava/lang/String;)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    goto/16 :goto_4

    :pswitch_5
    const/4 v7, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x7

    if-eqz v0, :cond_f

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-wide/high16 v0, 0x7ff0000000000000L    # Double.POSITIVE_INFINITY

    const-wide/high16 v0, 0x7ff0000000000000L    # Double.POSITIVE_INFINITY

    const/4 v7, 0x1

    const-wide/high16 v0, 0x7ff0000000000000L    # Double.POSITIVE_INFINITY

    const-wide/high16 v0, 0x7ff0000000000000L    # Double.POSITIVE_INFINITY

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto/16 :goto_4

    :cond_f
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_10

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-wide/high16 v0, -0x10000000000000L    # Double.NEGATIVE_INFINITY

    const/4 v7, 0x7

    const-wide/high16 v0, -0x10000000000000L    # Double.NEGATIVE_INFINITY

    const-wide/high16 v0, -0x10000000000000L    # Double.NEGATIVE_INFINITY

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto/16 :goto_4

    :cond_10
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v0, :cond_11

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-wide/high16 v0, 0x7ff8000000000000L    # Double.NaN

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto/16 :goto_4

    :cond_11
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v0}, Ljava/lang/Double;->valueOf(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto/16 :goto_4

    :pswitch_6
    const/4 v7, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v0, :cond_12

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/high16 v0, 0x7f800000    # Float.POSITIVE_INFINITY

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x7

    goto/16 :goto_4

    :cond_12
    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v0, :cond_13

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/high16 v0, -0x800000    # Float.NEGATIVE_INFINITY

    const/4 v7, 0x1

    const/4 v6, 0x7

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_4

    :cond_13
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v0, :cond_14

    const/4 v6, 0x7

    move v7, v6

    const/high16 v0, 0x7fc00000    # Float.NaN

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    goto/16 :goto_4

    :cond_14
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v0}, Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x2

    goto/16 :goto_4

    :pswitch_7
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/google/protobuf/TextFormat;->parseUInt64(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto/16 :goto_4

    :pswitch_8
    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/google/protobuf/TextFormat;->parseInt64(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto/16 :goto_4

    :pswitch_9
    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/google/protobuf/TextFormat;->parseUInt32(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x1

    goto/16 :goto_4

    :pswitch_a
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v0}, Lcom/google/protobuf/TextFormat;->parseInt32(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;
    :try_end_3
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto/16 :goto_4

    :catch_1
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v5, "rdu:eblnpaal/eu ed/Cfl toumtv   a"

    const-string v5, "/oamal:nu lld u/dor tvaf p eteueC"

    const/4 v7, 0x2

    const-string v5, "/atdtvudfupae noeeuorls  laCu/: l"

    const-string v5, "Could not parse default value: \""

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v5, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v5}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-direct {v1, p0, v2, v0, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Ljava/lang/Throwable;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw v1

    :cond_15
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v1, "Repeated fields cannot have default values."

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    throw v0

    :cond_16
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v0, :cond_17

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_4

    :cond_17
    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget-object v0, Lcom/google/protobuf/Descriptors$1;->$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$JavaType:[I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    aget v0, v0, v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eq v0, v1, :cond_19

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v1, 0x2

    move v7, v1

    const/4 v6, 0x2

    move v7, v6

    if-eq v0, v1, :cond_18

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->access$3200(Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v6, 0x2

    move v7, v6

    goto :goto_4

    :cond_18
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-object v3, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_4

    :cond_19
    const/4 v6, 0x5

    move v7, v6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->enumType:Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->getValues()Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x3

    shl-int/2addr v6, v1

    const/4 v7, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    :goto_4
    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v0, :cond_1c

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$MessageOptions;

    move-result-object v0

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$MessageOptions;->getMessageSetWireFormat()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_1c

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isExtension()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v0, :cond_1b

    const/4 v6, 0x5

    shr-int/2addr v7, v6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isOptional()Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v0, :cond_1a

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-ne v0, v1, :cond_1a

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_5

    :cond_1a
    const/4 v7, 0x4

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const-string v1, ".etlsmmpnaosipasessob egM t t ooaneesEisSsog tuese n"

    const-string v1, "anaaosfe gE g .s slneetsutebtsstomisoemoeSpMissn  eo"

    const-string v1, "esntanooqg.lut esSas taoxmoiesp ssniebmstgME ese efs"

    const-string v1, "Extensions of MessageSets must be optional messages."

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    throw v0

    :cond_1b
    const/4 v7, 0x1

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const-string/jumbo v1, "ntsneeesasgeafbse,nnyext.i  sSshM a tlise odolvo"

    const-string v1, " sdv b ,eaen Mse fshxnnSotsnitee.eolteoagassylin"

    const/4 v7, 0x1

    const-string v1, "eS min oitsnechstlae dnatsMsssefano lxgv.eon, ye"

    const-string v1, "MessageSets cannot have fields, only extensions."

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x5

    throw v0

    :cond_1c
    :goto_5
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void

    :cond_1d
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo v1, "ueFaoh wgem.sen upl tognnss smiritpi_emdameete y y"

    const-string/jumbo v1, "saymerus i tpe ipsonnaw_gmstutmmlenFy e.he i eedg "

    const/4 v7, 0x2

    const-string v1, " inppbe mm ma o_uheees gisasimnttn srwlFiyteey g.e"

    const-string v1, "Field with message or enum type missing type_name."

    const/4 v7, 0x7

    invoke-direct {v0, p0, v1, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    throw v0

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_a
        :pswitch_a
        :pswitch_a
        :pswitch_9
        :pswitch_9
        :pswitch_8
        :pswitch_8
        :pswitch_8
        :pswitch_7
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method private static fieldNameToJsonName(Ljava/lang/String;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    move v3, v2

    move v3, v2

    const/4 v8, 0x6

    move v3, v2

    move v3, v2

    const/4 v8, 0x1

    move v4, v3

    move v4, v3

    const/4 v8, 0x1

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-ge v3, v0, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/16 v6, 0x5f

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-ne v5, v6, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto :goto_1

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v4, :cond_2

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    const/16 v4, 0x61

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-gt v4, v5, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/16 v4, 0x7a

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-gt v5, v4, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v5, v5, -0x61

    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    add-int/lit8 v5, v5, 0x41

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    int-to-char v5, v5

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    move v4, v2

    move v4, v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    goto :goto_1

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_0

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-object p0
.end method

.method private setProto(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "proto"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v1, 0x3

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public compareTo(Lcom/google/protobuf/Descriptors$FieldDescriptor;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v3, 0x5

    iget-object v0, p1, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sub-int/2addr v0, p1

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "ec ofluaaepfiDoi edpti pyssF.onot geFosnrdsoseptpee r a dt fsemri im ctbalrchloro cmrsder see hylDte"

    const-string/jumbo v0, "s piep pndfhsd gtm pdromrlanoaraDpyse scy sbtsico D   eieccredoeFeelrehiratot.ls eesFf  treomfo lito"

    const/4 v3, 0x1

    const-string v0, "eclrmrdpr.eslorl peso pne teiosydm cf cFechlo e e sst asntiosFfieahe  agpteriryttbrm   ioafDepdDooed"

    const-string v0, "FieldDescriptors can only be compared to other FieldDescriptors for fields of the same message type."

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw p1
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    check-cast p1, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->compareTo(Lcom/google/protobuf/Descriptors$FieldDescriptor;)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p1
.end method

.method public getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getDefaultValue()Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eq v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->defaultValue:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x1

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "oeec lgqqVbtlmafd)ese.em  elepdD egaeD.dedfienlreurdaii toFsusadc(tn l"

    const-string v1, "bteeda eqtaFgDa.ia eeelef  reigmfVstdondrcpcll odea)iemudseduDnsl (el."

    const/4 v3, 0x0

    const-string v1, " osgudrdfcdadeiirtlllpanDedsaee.eacsuDle t.Veltmo(e nefee)gms eFad  lb"

    const-string v1, "FieldDescriptor.getDefaultValue() called on an embedded message field."

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw v0
.end method

.method public getEnumType()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-ne v0, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->enumType:Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object v0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x1

    move v5, v4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x6

    or-int/2addr v5, v4

    const/4 v2, 0x0

    and-int/2addr v5, v2

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->fullName:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    aput-object v3, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v2, "e.omdn ss)h ui%i  (iepsoTt lnsteff y"

    const-string v2, "%istsfstueni)   pfonesomh.eT(yil d  "

    const/4 v5, 0x4

    const-string/jumbo v2, "n( ho tyseflims etno%T.  uofp  sied)"

    const-string v2, "This field is not of enum type. (%s)"

    const/4 v5, 0x7

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    throw v0
.end method

.method public bridge synthetic getEnumType()Lcom/google/protobuf/Internal$EnumLiteMap;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getEnumType()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public getExtensionScope()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isExtension()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->extensionScope:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v4, 0x1

    and-int/2addr v5, v4

    return-object v0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->fullName:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    aput-object v3, v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, ".n( tbxsosiin ee sThs) moan niei %tf"

    const-string v2, "  emis)hnn T %fxst(s.eo tlii onnsiea"

    const-string v2, "(fhlsnuistxenondoei sais %en.t   i T"

    const-string v2, "This field is not an extension. (%s)"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw v0
.end method

.method public getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getFullName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->fullName:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public getIndex()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->index:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public getJsonName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->jsonName:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasJsonName()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getJsonName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->jsonName:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->fieldNameToJsonName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->jsonName:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/WireFormat$FieldType;->getJavaType()Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public getLiteType()Lcom/google/protobuf/WireFormat$FieldType;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->table:[Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    aget-object v0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0
.end method

.method public getMessageType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 6

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v5, 0x0

    const/4 v4, 0x6

    if-ne v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->messageType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v5, 0x1

    const/4 v1, 0x5

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->fullName:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v3, v1, v2

    const/4 v5, 0x5

    const-string v2, "e ssf%op p ss o(ind git f)oheT.atmlyee "

    const-string v2, "etdsof) tel yss%nig ioo e(aepf  hT msi."

    const/4 v5, 0x3

    const-string v2, "fspmt elqas %sog i si.e ed efoh(i) tyTs"

    const-string v2, "This field is not of message type. (%s)"

    const/4 v5, 0x5

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    throw v0
.end method

.method public getName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getNumber()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getNumber()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getRealContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->isSynthetic()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->containingOneof:Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public hasDefaultValue()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public hasOptionalKeyword()Z
    .locals 4
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isProto3Optional:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v1, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v3, 0x3

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isOptional()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v0
.end method

.method public hasPresence()Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    move v4, v3

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v2, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eq v0, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v2, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->GROUP:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eq v0, v2, :cond_1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v2, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v4, 0x2

    if-ne v0, v2, :cond_2

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v1, 0x1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v1
.end method

.method public internalMergeFrom(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/MessageLite$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "to",
            "from"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    check-cast p1, Lcom/google/protobuf/Message$Builder;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    check-cast p2, Lcom/google/protobuf/Message;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-interface {p1, p2}, Lcom/google/protobuf/Message$Builder;->mergeFrom(Lcom/google/protobuf/Message;)Lcom/google/protobuf/Message$Builder;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public isExtension()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public isMapField()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getMessageType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$MessageOptions;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$MessageOptions;->getMapEntry()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x2

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v0
.end method

.method public isOptional()Z
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getLabel()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;->LABEL_OPTIONAL:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public isPackable()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/WireFormat$FieldType;->isPackable()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public isPacked()Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isPackable()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v2, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne v0, v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getPacked()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hasPacked()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getPacked()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    :cond_2
    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return v1
.end method

.method public isRepeated()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getLabel()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;->LABEL_REPEATED:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x4

    shl-int/2addr v2, v0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return v0
.end method

.method public isRequired()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getLabel()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;->LABEL_REQUIRED:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method public legacyEnumFieldTreatedAsClosed()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getType()Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v1, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0
.end method

.method public needsUtf8Check()Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->type:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object v1, Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;->STRING:Lcom/google/protobuf/Descriptors$FieldDescriptor$Type;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eq v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    return v0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$MessageOptions;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$MessageOptions;->getMapEntry()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    return v1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v2, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO3:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v4, 0x7

    if-ne v0, v2, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getOptions()Lcom/google/protobuf/DescriptorProtos$FileOptions;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FileOptions;->getJavaStringCheckUtf8()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v0
.end method

.method public toProto()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$FieldDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic toProto()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->toProto()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getFullName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
