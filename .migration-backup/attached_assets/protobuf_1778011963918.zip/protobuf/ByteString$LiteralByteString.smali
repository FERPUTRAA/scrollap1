.class Lcom/google/protobuf/ByteString$LiteralByteString;
.super Lcom/google/protobuf/ByteString$LeafByteString;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/ByteString;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "LiteralByteString"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field protected final bytes:[B


# direct methods
.method constructor <init>([B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "bytes"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/ByteString$LeafByteString;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final asReadOnlyByteBuffer()Ljava/nio/ByteBuffer;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "M@s~ f~S @@l@ Kvcon~@@t~y b@@ i @@  @-@~~@a~@d.~b 1~~ ~ ~4ofri l/~@io  @s/~ b @@~~to~~ m~~oo@u@~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v0, v1, v2}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->asReadOnlyBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object v0
.end method

.method public final asReadOnlyByteBufferList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->asReadOnlyByteBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public byteAt(I)B
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    aget-byte p1, v0, p1

    const/4 v1, 0x0

    move v2, v1

    return p1
.end method

.method public final copyTo(Ljava/nio/ByteBuffer;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "target"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1, v2}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void
.end method

.method protected copyToInternal([BIII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "sourceOffset",
            "targetOffset",
            "numberToCopy"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0, p2, p1, p3, p4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "other"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ne p1, p0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    instance-of v1, p1, Lcom/google/protobuf/ByteString;

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    return v2

    :cond_1
    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast v3, Lcom/google/protobuf/ByteString;

    const/4 v5, 0x1

    invoke-virtual {v3}, Lcom/google/protobuf/ByteString;->size()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eq v1, v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v2

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    instance-of v0, p1, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    check-cast p1, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString;->peekCachedHashCode()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->peekCachedHashCode()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v0, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_4

    const/4 v4, 0x6

    move v5, v4

    if-eq v0, v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v2

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0, p1, v2, v0}, Lcom/google/protobuf/ByteString$LiteralByteString;->equalsRange(Lcom/google/protobuf/ByteString;II)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    return p1

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    return p1
.end method

.method final equalsRange(Lcom/google/protobuf/ByteString;II)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "other",
            "offset",
            "length"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-gt p3, v0, :cond_4

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    add-int v0, p2, p3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-gt v0, v1, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    instance-of v1, p1, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x7

    shl-int/2addr v5, v2

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x0

    check-cast p1, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v1, p1, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    add-int/2addr v3, p3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result p3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    add-int/2addr p1, p2

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-ge p3, v3, :cond_1

    const/4 v6, 0x7

    aget-byte p2, v0, p3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    aget-byte v4, v1, p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eq p2, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    return v2

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    add-int/lit8 p3, p3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/lit8 p1, p1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x4

    move v6, v5

    return p1

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1, p2, v0}, Lcom/google/protobuf/ByteString;->substring(II)Lcom/google/protobuf/ByteString;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0, v2, p3}, Lcom/google/protobuf/ByteString$LiteralByteString;->substring(II)Lcom/google/protobuf/ByteString;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, p2}, Lcom/google/protobuf/ByteString;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    return p1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v2, "o  mo sfn:tafo nerRhef"

    const-string/jumbo v2, "resRh: et n aonodfo ff"

    const-string v2, " da ote:hno Ro fo nrff"

    const-string v2, "Ran off end of other: "

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string p2, ", "

    const-string p2, ", "

    const/4 v6, 0x1

    const-string p2, ", "

    const-string p2, ", "

    const/4 v6, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    throw v0

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo v0, "oog ebtem Lhgtar:l"

    const-string v0, "eogme:lLt go t rah"

    const-string v0, "  lggtutnhoL eraeo"

    const-string v0, "Length too large: "

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result p3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    throw p1
.end method

.method protected getOffsetIntoBytes()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method internalByteAt(I)B
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    aget-byte p1, v0, p1

    const/4 v1, 0x4

    move v2, v1

    return p1
.end method

.method public final isValidUtf8()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    add-int/2addr v2, v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v0, v2}, Lcom/google/protobuf/Utf8;->isValidUtf8([BII)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    return v0
.end method

.method public final newCodedInput()Lcom/google/protobuf/CodedInputStream;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v0, v1, v2, v3}, Lcom/google/protobuf/CodedInputStream;->newInstance([BIIZ)Lcom/google/protobuf/CodedInputStream;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object v0
.end method

.method public final newInput()Ljava/io/InputStream;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Ljava/io/ByteArrayInputStream;

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v0, v1, v2, v3}, Ljava/io/ByteArrayInputStream;-><init>([BII)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v0
.end method

.method protected final partialHash(III)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "h",
            "offset",
            "length"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/2addr v1, p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0, v1, p3}, Lcom/google/protobuf/Internal;->partialHash(I[BII)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p1
.end method

.method protected final partialIsValidUtf8(III)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "state",
            "offset",
            "length"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    add-int/2addr v0, p2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    add-int/2addr p3, v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1, p2, v0, p3}, Lcom/google/protobuf/Utf8;->partialIsValidUtf8(I[BII)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    array-length v0, v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public final substring(II)Lcom/google/protobuf/ByteString;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "beginIndex",
            "endIndex"
        }
    .end annotation

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1, p2, v0}, Lcom/google/protobuf/ByteString;->checkRange(III)I

    move-result p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x5

    sget-object p1, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Lcom/google/protobuf/ByteString$BoundedByteString;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    add-int/2addr v2, p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2, p2}, Lcom/google/protobuf/ByteString$BoundedByteString;-><init>([BII)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object v0
.end method

.method protected final toStringInternal(Ljava/nio/charset/Charset;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "charset"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v0, v1, v2, v3, p1}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v0
.end method

.method final writeTo(Lcom/google/protobuf/ByteOutput;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1, v2}, Lcom/google/protobuf/ByteOutput;->writeLazy([BII)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method public final writeTo(Ljava/io/OutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "outputStream"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString;->toByteArray()[B

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method final writeToInternal(Ljava/io/OutputStream;II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "outputStream",
            "sourceOffset",
            "numberToWrite"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$LiteralByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/2addr v1, p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1, p3}, Ljava/io/OutputStream;->write([BII)V

    const/4 v3, 0x3

    return-void
.end method
