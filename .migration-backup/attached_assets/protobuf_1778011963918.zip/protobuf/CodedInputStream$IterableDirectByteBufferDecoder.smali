.class final Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;
.super Lcom/google/protobuf/CodedInputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedInputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "IterableDirectByteBufferDecoder"
.end annotation


# instance fields
.field private bufferSizeAfterCurrentLimit:I

.field private currentAddress:J

.field private currentByteBuffer:Ljava/nio/ByteBuffer;

.field private currentByteBufferLimit:J

.field private currentByteBufferPos:J

.field private currentByteBufferStartPos:J

.field private currentLimit:I

.field private enableAliasing:Z

.field private final immutable:Z

.field private final input:Ljava/lang/Iterable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Iterable<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private final iterator:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private lastTag:I

.field private startOffset:I

.field private totalBufferSize:I

.field private totalBytesRead:I


# direct methods
.method private constructor <init>(Ljava/lang/Iterable;IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "inputBufs",
            "size",
            "immutableFlag"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/nio/ByteBuffer;",
            ">;IZ)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream;-><init>(Lcom/google/protobuf/CodedInputStream$1;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const v0, 0x7fffffff

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentLimit:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->input:Ljava/lang/Iterable;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v1, 0x4

    move v2, v1

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->iterator:Ljava/util/Iterator;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean p3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->immutable:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->startOffset:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object p1, Lcom/google/protobuf/Internal;->EMPTY_BYTE_BUFFER:Ljava/nio/ByteBuffer;

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v2, 0x2

    const-wide/16 p1, 0x0

    const-wide/16 p1, 0x0

    const/4 v2, 0x0

    iput-wide p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-wide p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-wide p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-wide p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentAddress:J

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->tryGetNextByteBuffer()V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/Iterable;IZLcom/google/protobuf/CodedInputStream$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;-><init>(Ljava/lang/Iterable;IZ)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private currentRemaining()J
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o s@~ @@ vb@ y-@@fu@b @1~~@ @~l @ i  oSo~ @~ ~~@@~~m@~sd~.@i~@@Mncot~~o// o~fr@~ti~@ b~~l4~ ~ Ka"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method private getNextByteBuffer()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->iterator:Ljava/util/Iterator;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->tryGetNextByteBuffer()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    throw v0
.end method

.method private readRawBytesTo([BII)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x10
        }
        names = {
            "bytes",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x5

    if-ltz p3, :cond_2

    const/4 v11, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->remaining()I

    move-result v0

    const/4 v11, 0x1

    if-gt p3, v0, :cond_2

    const/4 v11, 0x6

    move v0, p3

    move v0, p3

    :goto_0
    const/4 v11, 0x0

    if-lez v0, :cond_1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v1

    const/4 v11, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x7

    cmp-long v1, v1, v3

    const/4 v11, 0x7

    if-nez v1, :cond_0

    const/4 v11, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getNextByteBuffer()V

    :cond_0
    const/4 v11, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v1

    const/4 v11, 0x2

    long-to-int v1, v1

    const/4 v11, 0x5

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    const/4 v11, 0x0

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x1

    sub-int v4, p3, v0

    const/4 v11, 0x2

    add-int/2addr v4, p2

    const/4 v11, 0x1

    int-to-long v5, v4

    const/4 v11, 0x1

    int-to-long v9, v1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-wide v7, v9

    const/4 v11, 0x5

    invoke-static/range {v2 .. v8}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v11, 0x2

    sub-int/2addr v0, v1

    const/4 v11, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x2

    add-long/2addr v1, v9

    const/4 v11, 0x5

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x4

    goto :goto_0

    :cond_1
    const/4 v11, 0x6

    return-void

    :cond_2
    const/4 v11, 0x5

    if-gtz p3, :cond_4

    const/4 v11, 0x2

    if-nez p3, :cond_3

    const/4 v11, 0x4

    return-void

    :cond_3
    const/4 v11, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v11, 0x1

    throw p1

    :cond_4
    const/4 v11, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v11, 0x6

    throw p1
.end method

.method private recomputeBufferSizeAfterLimit()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->bufferSizeAfterCurrentLimit:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->startOffset:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    sub-int v1, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentLimit:I

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    if-le v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    sub-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->bufferSizeAfterCurrentLimit:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    sub-int/2addr v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->bufferSizeAfterCurrentLimit:I

    :goto_0
    const/4 v4, 0x7

    return-void
.end method

.method private remaining()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v4, 0x0

    move v5, v4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    sub-int/2addr v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    int-to-long v0, v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    sub-long/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v4, 0x2

    move v5, v4

    add-long/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    long-to-int v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v0
.end method

.method private skipRawVarint()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/16 v1, 0xa

    const/4 v3, 0x0

    const/4 v2, 0x5

    if-ge v0, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ltz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw v0
.end method

.method private slice(II)Ljava/nio/ByteBuffer;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "begin",
            "end"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/nio/Buffer;->limit()I

    move-result v1

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2, p2}, Ljava/nio/Buffer;->limit(I)Ljava/nio/Buffer;

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2, v0}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v2, v1}, Ljava/nio/Buffer;->limit(I)Ljava/nio/Buffer;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v4, 0x4

    invoke-virtual {v2, v0}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2, v1}, Ljava/nio/Buffer;->limit(I)Ljava/nio/Buffer;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    throw p1
.end method

.method private tryGetNextByteBuffer()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->iterator:Ljava/util/Iterator;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    check-cast v0, Ljava/nio/ByteBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v7, 0x0

    const/4 v6, 0x2

    iget-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    sub-long/2addr v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    long-to-int v2, v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    add-int/2addr v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    int-to-long v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v7, 0x5

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/nio/Buffer;->limit()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    int-to-long v0, v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v7, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v6, 0x3

    move v7, v6

    invoke-static {v0}, Lcom/google/protobuf/UnsafeUtil;->addressOffset(Ljava/nio/ByteBuffer;)J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentAddress:J

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v6, 0x5

    move v7, v6

    add-long/2addr v2, v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v7, 0x5

    add-long/2addr v2, v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    add-long/2addr v2, v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-void
.end method


# virtual methods
.method public checkLastTagWas(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->lastTag:I

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidEndTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p1
.end method

.method public enableAliasing(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enabled"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->enableAliasing:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public getBytesUntilLimit()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentLimit:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const v1, 0x7fffffff

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getTotalBytesRead()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v0
.end method

.method public getLastTag()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->lastTag:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public getTotalBytesRead()I
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->startOffset:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    sub-int/2addr v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    int-to-long v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-long/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    sub-long/2addr v0, v2

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    long-to-int v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v0
.end method

.method public isAtEnd()Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    int-to-long v0, v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    add-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    sub-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    int-to-long v2, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x1

    xor-int/2addr v5, v0

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    move v5, v0

    :goto_0
    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v0
.end method

.method public popLimit(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "oldLimit"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentLimit:I

    const/4 v0, 0x6

    move v1, v0

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public pushLimit(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "byteLimit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-ltz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getTotalBytesRead()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    add-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentLimit:I

    const/4 v2, 0x7

    if-gt p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentLimit:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    throw p1

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw p1
.end method

.method public readBool()Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v4, 0x1

    or-int/2addr v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0
.end method

.method public readByteArray()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawBytes(I)[B

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method

.method public readByteBuffer()Ljava/nio/ByteBuffer;
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-lez v0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    int-to-long v8, v0

    const/4 v10, 0x6

    move v11, v10

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x0

    cmp-long v1, v8, v1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-gtz v1, :cond_1

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->immutable:Z

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-nez v1, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->enableAliasing:Z

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-eqz v1, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    add-long/2addr v0, v8

    const/4 v10, 0x6

    and-int/2addr v11, v10

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentAddress:J

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    sub-long v4, v0, v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    sub-long/2addr v4, v8

    long-to-int v4, v4

    const/4 v11, 0x5

    sub-long/2addr v0, v2

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    long-to-int v0, v0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-direct {p0, v4, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->slice(II)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    return-object v0

    :cond_0
    const/4 v11, 0x7

    new-array v0, v0, [B

    const/4 v11, 0x5

    const/4 v10, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v10, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x2

    const-wide/16 v4, 0x0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-wide v6, v8

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v11, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    add-long/2addr v1, v8

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v10, 0x1

    move v11, v10

    return-object v0

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-lez v0, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->remaining()I

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-gt v0, v1, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-array v1, v0, [B

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/4 v2, 0x0

    const/4 v11, 0x4

    invoke-direct {p0, v1, v2, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawBytesTo([BII)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x3

    return-object v0

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    if-nez v0, :cond_3

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    sget-object v0, Lcom/google/protobuf/Internal;->EMPTY_BYTE_BUFFER:Ljava/nio/ByteBuffer;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    return-object v0

    :cond_3
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-gez v0, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    throw v0

    :cond_4
    const/4 v10, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    throw v0
.end method

.method public readBytes()Lcom/google/protobuf/ByteString;
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    if-lez v0, :cond_1

    const/4 v10, 0x6

    or-int/2addr v11, v10

    int-to-long v8, v0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v11, 0x7

    const/4 v10, 0x4

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    sub-long/2addr v1, v3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    cmp-long v1, v8, v1

    const/4 v11, 0x7

    const/4 v10, 0x7

    if-gtz v1, :cond_1

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->immutable:Z

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-eqz v1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->enableAliasing:Z

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz v1, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentAddress:J

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    sub-long/2addr v3, v1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    long-to-int v1, v3

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    add-int/2addr v0, v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {p0, v1, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->slice(II)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->wrap(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    add-long/2addr v1, v8

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    return-object v0

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-array v0, v0, [B

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-wide/16 v5, 0x0

    const/4 v11, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    move-wide v1, v3

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-wide v4, v5

    move-wide v6, v8

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v10, 0x1

    move v11, v10

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    add-long/2addr v1, v8

    const/4 v10, 0x7

    move v11, v10

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->wrap([B)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v10, 0x7

    xor-int/2addr v11, v10

    return-object v0

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-lez v0, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->remaining()I

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-gt v0, v1, :cond_5

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->immutable:Z

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-eqz v1, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->enableAliasing:Z

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-eqz v1, :cond_4

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :goto_0
    const/4 v11, 0x2

    if-lez v0, :cond_3

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x7

    cmp-long v2, v2, v4

    const/4 v11, 0x1

    if-nez v2, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getNextByteBuffer()V

    :cond_2
    const/4 v10, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    long-to-int v2, v2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-wide v5, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentAddress:J

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    sub-long/2addr v3, v5

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    long-to-int v3, v3

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    add-int v4, v3, v2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-direct {p0, v3, v4}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->slice(II)Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static {v3}, Lcom/google/protobuf/ByteString;->wrap(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/ByteString;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x7

    const/4 v10, 0x1

    sub-int/2addr v0, v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    int-to-long v5, v2

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    add-long/2addr v3, v5

    const/4 v11, 0x0

    const/4 v10, 0x3

    iput-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    goto :goto_0

    :cond_3
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {v1}, Lcom/google/protobuf/ByteString;->copyFrom(Ljava/lang/Iterable;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    return-object v0

    :cond_4
    const/4 v11, 0x0

    new-array v1, v0, [B

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v2, 0x0

    xor-int/2addr v11, v2

    const/4 v10, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-direct {p0, v1, v2, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawBytesTo([BII)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {v1}, Lcom/google/protobuf/ByteString;->wrap([B)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    return-object v0

    :cond_5
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-nez v0, :cond_6

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    return-object v0

    :cond_6
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-gez v0, :cond_7

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    throw v0

    :cond_7
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v11, 0x2

    throw v0
.end method

.method public readDouble()D
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-wide v0
.end method

.method public readEnum()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public readFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public readFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-wide v0
.end method

.method public readFloat()F
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public readGroup(ILcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(I",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p2, Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p3, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1, p3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->checkLastTagWas(I)V

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p2
.end method

.method public readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p2, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->checkLastTagWas(I)V

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public readInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public readInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-wide v0
.end method

.method public readMessage(Lcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v2, 0x6

    move v3, v2

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast p1, Lcom/google/protobuf/MessageLite;

    const/4 v3, 0x6

    const/4 p2, 0x0

    const/4 v3, 0x4

    move v2, p2

    move v2, p2

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/lit8 p2, p2, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getBytesUntilLimit()I

    move-result p2

    const/4 v3, 0x5

    if-nez p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->popLimit(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p1
.end method

.method public readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getBytesUntilLimit()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->popLimit(I)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    throw p1
.end method

.method public readRawByte()B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    cmp-long v0, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getNextByteBuffer()V

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    add-long/2addr v2, v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0
.end method

.method public readRawBytes(I)[B
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-ltz p1, :cond_0

    const/4 v9, 0x4

    or-int/2addr v10, v9

    int-to-long v7, p1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    cmp-long v0, v7, v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-gtz v0, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x5

    new-array p1, p1, [B

    const/4 v9, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-wide v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static/range {v0 .. v6}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    add-long/2addr v0, v7

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    return-object p1

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-ltz p1, :cond_1

    const/4 v10, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->remaining()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-gt p1, v0, :cond_1

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    new-array v0, p1, [B

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/4 v1, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {p0, v0, v1, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawBytesTo([BII)V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    return-object v0

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-gtz p1, :cond_3

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-nez p1, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    sget-object p1, Lcom/google/protobuf/Internal;->EMPTY_BYTE_ARRAY:[B

    const/4 v10, 0x7

    return-object p1

    :cond_2
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    throw p1

    :cond_3
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    throw p1
.end method

.method public readRawLittleEndian32()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const-wide/16 v2, 0x4

    const-wide/16 v2, 0x4

    const/4 v6, 0x4

    const-wide/16 v2, 0x4

    const-wide/16 v2, 0x4

    const/4 v5, 0x3

    and-int/2addr v6, v5

    cmp-long v0, v0, v2

    const/4 v6, 0x0

    if-ltz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x6

    and-int/2addr v6, v5

    add-long/2addr v2, v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    and-int/lit16 v2, v2, 0xff

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x3

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-long/2addr v3, v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v3, v4}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    shl-int/lit8 v3, v3, 0x8

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    or-int/2addr v2, v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-wide/16 v3, 0x2

    const-wide/16 v3, 0x2

    const/4 v6, 0x7

    add-long/2addr v3, v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-static {v3, v4}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    shl-int/lit8 v3, v3, 0x10

    const/4 v6, 0x7

    const/4 v5, 0x7

    or-int/2addr v2, v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-wide/16 v3, 0x3

    const-wide/16 v3, 0x3

    const/4 v6, 0x4

    const-wide/16 v3, 0x3

    const-wide/16 v3, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-long/2addr v0, v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    and-int/lit16 v0, v0, 0xff

    const/4 v6, 0x6

    const/4 v5, 0x7

    shl-int/lit8 v0, v0, 0x18

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    or-int/2addr v0, v2

    const/4 v6, 0x1

    return v0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    and-int/lit16 v0, v0, 0xff

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    and-int/lit16 v1, v1, 0xff

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    shl-int/lit8 v1, v1, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    or-int/2addr v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    and-int/lit16 v1, v1, 0xff

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    shl-int/lit8 v1, v1, 0x10

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    or-int/2addr v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    and-int/lit16 v1, v1, 0xff

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    shl-int/lit8 v1, v1, 0x18

    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    or-int/2addr v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return v0
.end method

.method public readRawLittleEndian64()J
    .locals 17
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v1

    const-wide/16 v3, 0x8

    const-wide/16 v3, 0x8

    const-wide/16 v3, 0x8

    const-wide/16 v3, 0x8

    cmp-long v1, v1, v3

    const/16 v2, 0x38

    const/16 v7, 0x20

    const/16 v8, 0x18

    const/16 v9, 0x10

    const/16 v10, 0x8

    const-wide/16 v11, 0xff

    const-wide/16 v11, 0xff

    const-wide/16 v11, 0xff

    const-wide/16 v11, 0xff

    if-ltz v1, :cond_0

    iget-wide v13, v0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    add-long/2addr v3, v13

    iput-wide v3, v0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    invoke-static {v13, v14}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v3, v1

    and-long/2addr v3, v11

    const-wide/16 v15, 0x1

    const-wide/16 v15, 0x1

    const-wide/16 v15, 0x1

    const-wide/16 v15, 0x1

    add-long/2addr v15, v13

    invoke-static/range {v15 .. v16}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v10

    or-long/2addr v3, v5

    const-wide/16 v5, 0x2

    const-wide/16 v5, 0x2

    const-wide/16 v5, 0x2

    const-wide/16 v5, 0x2

    add-long/2addr v5, v13

    invoke-static {v5, v6}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v9

    or-long/2addr v3, v5

    const-wide/16 v5, 0x3

    const-wide/16 v5, 0x3

    const-wide/16 v5, 0x3

    const-wide/16 v5, 0x3

    add-long/2addr v5, v13

    invoke-static {v5, v6}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v8

    or-long/2addr v3, v5

    const-wide/16 v5, 0x4

    const-wide/16 v5, 0x4

    add-long/2addr v5, v13

    invoke-static {v5, v6}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v7

    or-long/2addr v3, v5

    const-wide/16 v5, 0x5

    const-wide/16 v5, 0x5

    add-long/2addr v5, v13

    invoke-static {v5, v6}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    const/16 v1, 0x28

    shl-long/2addr v5, v1

    or-long/2addr v3, v5

    const-wide/16 v5, 0x6

    const-wide/16 v5, 0x6

    const-wide/16 v5, 0x6

    add-long/2addr v5, v13

    invoke-static {v5, v6}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    const/16 v1, 0x30

    shl-long/2addr v5, v1

    or-long/2addr v3, v5

    const-wide/16 v5, 0x7

    const-wide/16 v5, 0x7

    const-wide/16 v5, 0x7

    const-wide/16 v5, 0x7

    add-long/2addr v13, v5

    invoke-static {v13, v14}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    :goto_0
    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long v1, v5, v2

    or-long/2addr v1, v3

    return-wide v1

    :cond_0
    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v3, v1

    and-long/2addr v3, v11

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v10

    or-long/2addr v3, v5

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v9

    or-long/2addr v3, v5

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v8

    or-long/2addr v3, v5

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    shl-long/2addr v5, v7

    or-long/2addr v3, v5

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    const/16 v1, 0x28

    shl-long/2addr v5, v1

    or-long/2addr v3, v5

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    int-to-long v5, v1

    and-long/2addr v5, v11

    const/16 v1, 0x30

    shl-long/2addr v5, v1

    or-long/2addr v3, v5

    invoke-virtual/range {p0 .. p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v1

    goto :goto_0
.end method

.method public readRawVarint32()I
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    cmp-long v2, v2, v0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-nez v2, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v11, 0x6

    const-wide/16 v2, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    add-long v4, v0, v2

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v11, 0x3

    const/4 v10, 0x3

    if-ltz v0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x6

    iget-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    add-long/2addr v4, v2

    const/4 v11, 0x1

    iput-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    return v0

    :cond_1
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget-wide v6, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-wide v8, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    sub-long/2addr v6, v8

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-wide/16 v8, 0xa

    const-wide/16 v8, 0xa

    const/4 v11, 0x7

    const-wide/16 v8, 0xa

    const-wide/16 v8, 0xa

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    cmp-long v1, v6, v8

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-gez v1, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    add-long v6, v4, v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    shl-int/lit8 v1, v1, 0x7

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    xor-int/2addr v0, v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-gez v0, :cond_3

    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    xor-int/lit8 v0, v0, -0x80

    const/4 v11, 0x0

    goto/16 :goto_1

    :cond_3
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    add-long v4, v6, v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    shl-int/lit8 v1, v1, 0xe

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x2

    xor-int/2addr v0, v1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-ltz v0, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    xor-int/lit16 v0, v0, 0x3f80

    :cond_4
    move-wide v6, v4

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    goto/16 :goto_1

    :cond_5
    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    add-long v6, v4, v2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    shl-int/lit8 v1, v1, 0x15

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    xor-int/2addr v0, v1

    const/4 v11, 0x4

    if-gez v0, :cond_6

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x1

    const v1, -0x1fc080

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    xor-int/2addr v0, v1

    const/4 v10, 0x3

    move v11, v10

    goto/16 :goto_1

    :cond_6
    const/4 v11, 0x0

    add-long v4, v6, v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    shl-int/lit8 v6, v1, 0x1c

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    xor-int/2addr v0, v6

    const/4 v11, 0x1

    const/4 v10, 0x4

    const v6, 0xfe03f80

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    xor-int/2addr v0, v6

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-gez v1, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x0

    add-long v6, v4, v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-gez v1, :cond_7

    const/4 v11, 0x3

    const/4 v10, 0x6

    add-long v4, v6, v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-gez v1, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    add-long v6, v4, v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-gez v1, :cond_7

    const/4 v11, 0x7

    const/4 v10, 0x3

    add-long v4, v6, v2

    const/4 v11, 0x2

    const/4 v10, 0x2

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-gez v1, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    add-long v6, v4, v2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-gez v1, :cond_7

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    long-to-int v0, v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    return v0

    :cond_7
    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    iput-wide v6, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    return v0
.end method

.method public readRawVarint64()J
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v11, 0x2

    const/4 v11, 0x3

    cmp-long v2, v2, v0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-nez v2, :cond_0

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    goto/16 :goto_4

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v12, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v11, 0x5

    move v12, v11

    add-long v4, v0, v2

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v12, 0x7

    const/4 v11, 0x6

    if-ltz v0, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x1

    iget-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x7

    add-long/2addr v4, v2

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    iput-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    int-to-long v0, v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    return-wide v0

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-wide v6, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v12, 0x6

    iget-wide v8, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    sub-long/2addr v6, v8

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    const-wide/16 v8, 0xa

    const-wide/16 v8, 0xa

    const/4 v12, 0x3

    const-wide/16 v8, 0xa

    const-wide/16 v8, 0xa

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    cmp-long v1, v6, v8

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    if-gez v1, :cond_2

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    goto/16 :goto_4

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    add-long v6, v4, v2

    const/4 v11, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v12, 0x1

    const/4 v11, 0x7

    shl-int/lit8 v1, v1, 0x7

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    xor-int/2addr v0, v1

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-gez v0, :cond_3

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    xor-int/lit8 v0, v0, -0x80

    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    int-to-long v0, v0

    const/4 v12, 0x2

    goto/16 :goto_5

    :cond_3
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    add-long v4, v6, v2

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    shl-int/lit8 v1, v1, 0xe

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    xor-int/2addr v0, v1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-ltz v0, :cond_5

    const/4 v12, 0x1

    xor-int/lit16 v0, v0, 0x3f80

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    int-to-long v0, v0

    :cond_4
    :goto_1
    move-wide v6, v4

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    goto/16 :goto_5

    :cond_5
    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    add-long v6, v4, v2

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    shl-int/lit8 v1, v1, 0x15

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x2

    xor-int/2addr v0, v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-gez v0, :cond_6

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    const v1, -0x1fc080

    const/4 v12, 0x6

    const/4 v11, 0x4

    xor-int/2addr v0, v1

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    goto :goto_0

    :cond_6
    const/4 v12, 0x2

    const/4 v11, 0x3

    int-to-long v0, v0

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    add-long v4, v6, v2

    const/4 v11, 0x6

    move v12, v11

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    int-to-long v6, v6

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    const/16 v8, 0x1c

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    shl-long/2addr v6, v8

    const/4 v12, 0x0

    const/4 v11, 0x3

    xor-long/2addr v0, v6

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    const-wide/16 v6, 0x0

    const/4 v12, 0x3

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    cmp-long v8, v0, v6

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-ltz v8, :cond_7

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-wide/32 v2, 0xfe03f80

    const-wide/32 v2, 0xfe03f80

    const/4 v12, 0x1

    const-wide/32 v2, 0xfe03f80

    const-wide/32 v2, 0xfe03f80

    :goto_2
    const/4 v11, 0x1

    const/4 v12, 0x3

    xor-long/2addr v0, v2

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    goto :goto_1

    :cond_7
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    add-long v8, v4, v2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x0

    int-to-long v4, v4

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    const/16 v10, 0x23

    const/4 v12, 0x5

    const/4 v11, 0x1

    shl-long/2addr v4, v10

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    xor-long/2addr v0, v4

    const/4 v11, 0x5

    move v12, v11

    cmp-long v4, v0, v6

    const/4 v12, 0x5

    if-gez v4, :cond_8

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-wide v2, -0x7f01fc080L

    const-wide v2, -0x7f01fc080L

    const/4 v12, 0x2

    const-wide v2, -0x7f01fc080L

    const-wide v2, -0x7f01fc080L

    :goto_3
    const/4 v12, 0x3

    xor-long/2addr v0, v2

    move-wide v6, v8

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    goto/16 :goto_5

    :cond_8
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    add-long v4, v8, v2

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-static {v8, v9}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v8

    const/4 v12, 0x5

    const/4 v11, 0x6

    int-to-long v8, v8

    const/4 v12, 0x3

    const/16 v10, 0x2a

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    shl-long/2addr v8, v10

    const/4 v12, 0x7

    const/4 v11, 0x2

    xor-long/2addr v0, v8

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    cmp-long v8, v0, v6

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-ltz v8, :cond_9

    const/4 v12, 0x5

    const/4 v11, 0x2

    const-wide v2, 0x3f80fe03f80L

    const-wide v2, 0x3f80fe03f80L

    const/4 v12, 0x0

    const/4 v11, 0x0

    goto :goto_2

    :cond_9
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    add-long v8, v4, v2

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x7

    int-to-long v4, v4

    const/4 v11, 0x6

    shr-int/2addr v12, v11

    const/16 v10, 0x31

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    shl-long/2addr v4, v10

    const/4 v12, 0x6

    xor-long/2addr v0, v4

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    cmp-long v4, v0, v6

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-gez v4, :cond_a

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    const-wide v2, -0x1fc07f01fc080L

    const/4 v12, 0x2

    const-wide v2, -0x1fc07f01fc080L

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    goto :goto_3

    :cond_a
    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    add-long v4, v8, v2

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v8, v9}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v8

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    int-to-long v8, v8

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/16 v10, 0x38

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    shl-long/2addr v8, v10

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    xor-long/2addr v0, v8

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-wide v8, 0xfe03f80fe03f80L

    const-wide v8, 0xfe03f80fe03f80L

    const-wide v8, 0xfe03f80fe03f80L

    const-wide v8, 0xfe03f80fe03f80L

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    xor-long/2addr v0, v8

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    cmp-long v8, v0, v6

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-gez v8, :cond_4

    const/4 v12, 0x4

    add-long/2addr v2, v4

    const/4 v12, 0x0

    const/4 v11, 0x1

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v4

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    int-to-long v4, v4

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x1

    cmp-long v4, v4, v6

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    if-gez v4, :cond_b

    :goto_4
    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x2

    return-wide v0

    :cond_b
    move-wide v6, v2

    :goto_5
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    iput-wide v6, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x1

    return-wide v0
.end method

.method readRawVarint64SlowPath()J
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x5

    const/16 v3, 0x40

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-ge v2, v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawByte()B

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    and-int/lit8 v4, v3, 0x7f

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    int-to-long v4, v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    shl-long/2addr v4, v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    or-long/2addr v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    and-int/lit16 v3, v3, 0x80

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-nez v3, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-wide v0

    :cond_0
    add-int/lit8 v2, v2, 0x7

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    throw v0
.end method

.method public readSFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public readSFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-wide v0
.end method

.method public readSInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public readSInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-wide v0
.end method

.method public readString()Ljava/lang/String;
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-lez v0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x5

    int-to-long v8, v0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v10, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    sub-long/2addr v1, v3

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    cmp-long v1, v8, v1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-gtz v1, :cond_0

    const/4 v11, 0x0

    new-array v0, v0, [B

    const/4 v10, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v11, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    move-wide v1, v3

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-wide v4, v5

    move-wide v6, v8

    const/4 v11, 0x4

    const/4 v10, 0x3

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance v1, Ljava/lang/String;

    const/4 v11, 0x7

    sget-object v2, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {v1, v0, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    add-long/2addr v2, v8

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    return-object v1

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-lez v0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->remaining()I

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-gt v0, v1, :cond_1

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-array v1, v0, [B

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v2, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-direct {p0, v1, v2, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawBytesTo([BII)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance v0, Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v2, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    return-object v0

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-nez v0, :cond_2

    const/4 v10, 0x0

    move v11, v10

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    return-object v0

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-gez v0, :cond_3

    const/4 v10, 0x3

    shl-int/2addr v11, v10

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    throw v0

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    throw v0
.end method

.method public readStringRequireUtf8()Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-lez v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    int-to-long v1, v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferLimit:J

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-wide v5, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    sub-long/2addr v3, v5

    const/4 v8, 0x5

    cmp-long v3, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    if-gtz v3, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    sub-long/2addr v5, v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    long-to-int v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    iget-object v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBuffer:Ljava/nio/ByteBuffer;

    invoke-static {v4, v3, v0}, Lcom/google/protobuf/Utf8;->decodeUtf8(Ljava/nio/ByteBuffer;II)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    add-long/2addr v3, v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    iput-wide v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v8, 0x5

    return-object v0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-ltz v0, :cond_1

    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->remaining()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-gt v0, v1, :cond_1

    const/4 v8, 0x2

    new-array v1, v0, [B

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v8, 0x4

    shl-int/2addr v7, v2

    const/4 v8, 0x7

    invoke-direct {p0, v1, v2, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawBytesTo([BII)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/Utf8;->decodeUtf8([BII)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-object v0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    if-nez v0, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v0, ""

    const/4 v8, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    return-object v0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-gtz v0, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    throw v0

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    throw v0
.end method

.method public readTag()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->isAtEnd()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->lastTag:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->lastTag:I

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->lastTag:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    throw v0
.end method

.method public readUInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public readUInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-wide v0
.end method

.method public readUnknownGroup(ILcom/google/protobuf/MessageLite$Builder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/protobuf/ExtensionRegistryLite;->getEmptyRegistry()Lcom/google/protobuf/ExtensionRegistryLite;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method public resetSizeCounter()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    int-to-long v0, v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    sub-long/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    long-to-int v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->startOffset:I

    const/4 v4, 0x0

    move v5, v4

    return-void
.end method

.method public skipField(I)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "tag"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v1, 0x1

    move v5, v1

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x0

    if-eq v0, v1, :cond_4

    const/4 v4, 0x6

    move v5, v4

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eq v0, v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 v2, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v3, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v0, v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eq v0, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 p1, 0x5

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne v0, p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipRawBytes(I)V

    const/4 v5, 0x5

    return v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw p1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    return p1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipMessage()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->checkLastTagWas(I)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v1

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawVarint32()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipRawBytes(I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    return v1

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/16 p1, 0x8

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipRawBytes(I)V

    const/4 v5, 0x2

    return v1

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipRawVarint()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    return v1
.end method

.method public skipField(ILcom/google/protobuf/CodedOutputStream;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "tag",
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eq v0, v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eq v0, v2, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    move v5, v4

    if-eq v0, v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eq v0, v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne v0, v2, :cond_0

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeFixed32NoTag(I)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    throw p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    return p1

    :cond_2
    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipMessage(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x3

    move v5, v4

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->checkLastTagWas(I)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v4, 0x2

    const/4 v5, 0x6

    return v1

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readRawLittleEndian64()J

    move-result-wide v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeFixed64NoTag(J)V

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    return v1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readInt64()J

    move-result-wide v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeUInt64NoTag(J)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    return v1
.end method

.method public skipMessage()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipField(I)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public skipMessage(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->skipField(ILcom/google/protobuf/CodedOutputStream;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public skipRawBytes(I)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ltz p1, :cond_2

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    int-to-long v0, p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBufferSize:I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->totalBytesRead:I

    const/4 v6, 0x0

    const/4 v6, 0x2

    sub-int/2addr v2, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    int-to-long v2, v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    sub-long/2addr v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-wide v4, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferStartPos:J

    const/4 v7, 0x5

    const/4 v6, 0x4

    add-long/2addr v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    cmp-long v0, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-gtz v0, :cond_2

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-lez p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    cmp-long v0, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->getNextByteBuffer()V

    :cond_0
    const/4 v6, 0x2

    move v7, v6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentRemaining()J

    move-result-wide v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    long-to-int v0, v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    sub-int/2addr p1, v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    int-to-long v3, v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    add-long/2addr v1, v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;->currentByteBufferPos:J

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-gez p1, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    throw p1

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    throw p1
.end method
