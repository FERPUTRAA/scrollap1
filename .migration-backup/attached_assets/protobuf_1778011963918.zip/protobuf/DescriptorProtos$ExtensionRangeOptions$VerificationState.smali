.class public final enum Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/protobuf/ProtocolMessageEnum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "VerificationState"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;",
        ">;",
        "Lcom/google/protobuf/ProtocolMessageEnum;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

.field public static final enum DECLARATION:Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

.field public static final DECLARATION_VALUE:I = 0x0

.field public static final enum UNVERIFIED:Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

.field public static final UNVERIFIED_VALUE:I = 0x1

.field private static final VALUES:[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v1, "sNsROCIDLAA"

    const-string v1, "ICsDANLAOTR"

    const/4 v6, 0x2

    const-string v1, "NAOmIALDREC"

    const-string v1, "DECLARATION"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v0, v1, v2, v2}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;-><init>(Ljava/lang/String;II)V

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->DECLARATION:Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v1, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v3, "RIEUoNEVmD"

    const-string v3, "INImRUVEED"

    const/4 v6, 0x4

    const-string v3, "FEIEIbVURD"

    const-string v3, "UNVERIFIED"

    const/4 v6, 0x3

    const/4 v4, 0x4

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v1, v3, v4, v4}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    sput-object v1, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->UNVERIFIED:Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x1

    const/4 v3, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-array v3, v3, [Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    aput-object v0, v3, v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    aput-object v1, v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    sput-object v3, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->$VALUES:[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState$1;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState$1;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->values()[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->VALUES:[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p3, p0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->value:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public static forNumber(I)Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ub~@ utfn ~m ~@@b ~o~~bl~ oci4i~@ ~o~ @~a1~@/@yi@ @-~ ~~ @@@@r@~~ @ v  o@ K~~d@S.ltfM~~ @oo /~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    if-eqz p0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    if-eq p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->UNVERIFIED:Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->DECLARATION:Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v1, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getEnumTypes()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public static valueOf(I)Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public static valueOf(Lcom/google/protobuf/Descriptors$EnumValueDescriptor;)Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "desc"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getType()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->VALUES:[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getIndex()I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    aget-object p0, v0, p0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const-string v0, "htsEfetp lon.aeioi rrsuoencDs  uVroi tpmy"

    const-string v0, "ernforenhlVuiraesti ustyoct  ED mspt.o oi"

    const/4 v3, 0x4

    const-string/jumbo v0, "nuonmDurqEtps lVe ttyostfsr.eciip ia roh "

    const-string v0, "EnumValueDescriptor is not for this type."

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-class v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v2, 0x6

    const-class v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->$VALUES:[Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v1, 0x1

    or-int/2addr v2, v1

    invoke-virtual {v0}, [Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast v0, [Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public final getDescriptorForType()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public final getNumber()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->value:I

    const/4 v2, 0x6

    return v0
.end method

.method public final getValueDescriptor()Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions$VerificationState;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->getValues()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0
.end method
