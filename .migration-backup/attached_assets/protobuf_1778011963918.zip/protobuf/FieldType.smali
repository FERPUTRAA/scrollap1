.class public final enum Lcom/google/protobuf/FieldType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/FieldType$Collection;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/FieldType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/FieldType;

.field public static final enum BOOL:Lcom/google/protobuf/FieldType;

.field public static final enum BOOL_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum BOOL_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum BYTES:Lcom/google/protobuf/FieldType;

.field public static final enum BYTES_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum DOUBLE:Lcom/google/protobuf/FieldType;

.field public static final enum DOUBLE_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum DOUBLE_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field private static final EMPTY_TYPES:[Ljava/lang/reflect/Type;

.field public static final enum ENUM:Lcom/google/protobuf/FieldType;

.field public static final enum ENUM_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum ENUM_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum FIXED32:Lcom/google/protobuf/FieldType;

.field public static final enum FIXED32_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum FIXED32_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum FIXED64:Lcom/google/protobuf/FieldType;

.field public static final enum FIXED64_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum FIXED64_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum FLOAT:Lcom/google/protobuf/FieldType;

.field public static final enum FLOAT_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum FLOAT_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum GROUP:Lcom/google/protobuf/FieldType;

.field public static final enum GROUP_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum INT32:Lcom/google/protobuf/FieldType;

.field public static final enum INT32_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum INT32_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum INT64:Lcom/google/protobuf/FieldType;

.field public static final enum INT64_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum INT64_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum MAP:Lcom/google/protobuf/FieldType;

.field public static final enum MESSAGE:Lcom/google/protobuf/FieldType;

.field public static final enum MESSAGE_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum SFIXED32:Lcom/google/protobuf/FieldType;

.field public static final enum SFIXED32_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum SFIXED32_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum SFIXED64:Lcom/google/protobuf/FieldType;

.field public static final enum SFIXED64_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum SFIXED64_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum SINT32:Lcom/google/protobuf/FieldType;

.field public static final enum SINT32_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum SINT32_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum SINT64:Lcom/google/protobuf/FieldType;

.field public static final enum SINT64_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum SINT64_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum STRING:Lcom/google/protobuf/FieldType;

.field public static final enum STRING_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum UINT32:Lcom/google/protobuf/FieldType;

.field public static final enum UINT32_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum UINT32_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field public static final enum UINT64:Lcom/google/protobuf/FieldType;

.field public static final enum UINT64_LIST:Lcom/google/protobuf/FieldType;

.field public static final enum UINT64_LIST_PACKED:Lcom/google/protobuf/FieldType;

.field private static final VALUES:[Lcom/google/protobuf/FieldType;


# instance fields
.field private final collection:Lcom/google/protobuf/FieldType$Collection;

.field private final elementType:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private final id:I

.field private final javaType:Lcom/google/protobuf/JavaType;

.field private final primitiveScalar:Z


# direct methods
.method static constructor <clinit>()V
    .locals 65

    new-instance v6, Lcom/google/protobuf/FieldType;

    const-string v1, "LOsEUs"

    const-string v1, "BUsOLE"

    const-string v1, "DOUBLE"

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v13, Lcom/google/protobuf/FieldType$Collection;->SCALAR:Lcom/google/protobuf/FieldType$Collection;

    sget-object v14, Lcom/google/protobuf/JavaType;->DOUBLE:Lcom/google/protobuf/JavaType;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v4, v13

    move-object v4, v13

    move-object v4, v13

    move-object v4, v13

    move-object v5, v14

    move-object v5, v14

    move-object v5, v14

    move-object v5, v14

    invoke-direct/range {v0 .. v5}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v6, Lcom/google/protobuf/FieldType;->DOUBLE:Lcom/google/protobuf/FieldType;

    new-instance v0, Lcom/google/protobuf/FieldType;

    const-string v8, "LFAmT"

    const-string v8, "FLOAT"

    const/4 v9, 0x1

    const/4 v10, 0x1

    sget-object v1, Lcom/google/protobuf/JavaType;->FLOAT:Lcom/google/protobuf/JavaType;

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v11, v13

    move-object v11, v13

    move-object v11, v13

    move-object v11, v13

    move-object v12, v1

    move-object v12, v1

    move-object v12, v1

    move-object v12, v1

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v0, Lcom/google/protobuf/FieldType;->FLOAT:Lcom/google/protobuf/FieldType;

    new-instance v2, Lcom/google/protobuf/FieldType;

    const-string v8, "6TImo"

    const-string v8, "I46mT"

    const-string v8, "bI6N4"

    const-string v8, "INT64"

    const/4 v9, 0x2

    const/4 v10, 0x2

    sget-object v3, Lcom/google/protobuf/JavaType;->LONG:Lcom/google/protobuf/JavaType;

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v2, Lcom/google/protobuf/FieldType;->INT64:Lcom/google/protobuf/FieldType;

    new-instance v4, Lcom/google/protobuf/FieldType;

    const-string/jumbo v8, "uo46UT"

    const-string v8, "6UTNo4"

    const-string v8, "4pNU6T"

    const-string v8, "UINT64"

    const/4 v9, 0x3

    const/4 v10, 0x3

    move-object v7, v4

    move-object v7, v4

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v4, Lcom/google/protobuf/FieldType;->UINT64:Lcom/google/protobuf/FieldType;

    new-instance v5, Lcom/google/protobuf/FieldType;

    const-string v8, "23Iqb"

    const-string v8, "bI3T2"

    const-string v8, "2TsI3"

    const-string v8, "INT32"

    const/4 v9, 0x4

    const/4 v10, 0x4

    sget-object v21, Lcom/google/protobuf/JavaType;->INT:Lcom/google/protobuf/JavaType;

    move-object v7, v5

    move-object v7, v5

    move-object v7, v5

    move-object v7, v5

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v5, Lcom/google/protobuf/FieldType;->INT32:Lcom/google/protobuf/FieldType;

    new-instance v22, Lcom/google/protobuf/FieldType;

    const-string v8, "E6Xmu4F"

    const-string v8, "XF6E4Du"

    const-string v8, "XD46oEI"

    const-string v8, "FIXED64"

    const/4 v9, 0x5

    const/4 v10, 0x5

    move-object/from16 v7, v22

    move-object/from16 v7, v22

    move-object/from16 v7, v22

    move-object/from16 v7, v22

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v22, Lcom/google/protobuf/FieldType;->FIXED64:Lcom/google/protobuf/FieldType;

    new-instance v23, Lcom/google/protobuf/FieldType;

    const-string/jumbo v8, "pEFD23X"

    const-string v8, "2DIFXbE"

    const-string v8, "FIXED32"

    const/4 v9, 0x6

    const/4 v10, 0x6

    move-object/from16 v7, v23

    move-object/from16 v7, v23

    move-object/from16 v7, v23

    move-object/from16 v7, v23

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v23, Lcom/google/protobuf/FieldType;->FIXED32:Lcom/google/protobuf/FieldType;

    new-instance v24, Lcom/google/protobuf/FieldType;

    const-string v8, "OOLB"

    const-string v8, "OLOB"

    const-string v8, "OOBL"

    const-string v8, "BOOL"

    const/4 v9, 0x7

    const/4 v10, 0x7

    sget-object v25, Lcom/google/protobuf/JavaType;->BOOLEAN:Lcom/google/protobuf/JavaType;

    move-object/from16 v7, v24

    move-object/from16 v7, v24

    move-object/from16 v7, v24

    move-object/from16 v7, v24

    move-object/from16 v12, v25

    move-object/from16 v12, v25

    move-object/from16 v12, v25

    move-object/from16 v12, v25

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v24, Lcom/google/protobuf/FieldType;->BOOL:Lcom/google/protobuf/FieldType;

    new-instance v26, Lcom/google/protobuf/FieldType;

    const-string/jumbo v8, "uTIGRS"

    const-string v8, "SGqITR"

    const-string v8, "GpTNRI"

    const-string v8, "STRING"

    const/16 v9, 0x8

    const/16 v10, 0x8

    sget-object v27, Lcom/google/protobuf/JavaType;->STRING:Lcom/google/protobuf/JavaType;

    move-object/from16 v7, v26

    move-object/from16 v7, v26

    move-object/from16 v7, v26

    move-object/from16 v7, v26

    move-object/from16 v12, v27

    move-object/from16 v12, v27

    move-object/from16 v12, v27

    move-object/from16 v12, v27

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v26, Lcom/google/protobuf/FieldType;->STRING:Lcom/google/protobuf/FieldType;

    new-instance v28, Lcom/google/protobuf/FieldType;

    const-string v8, "EqGsESA"

    const-string v8, "EMsEGAS"

    const-string v8, "EEsSGAM"

    const-string v8, "MESSAGE"

    const/16 v9, 0x9

    const/16 v10, 0x9

    sget-object v29, Lcom/google/protobuf/JavaType;->MESSAGE:Lcom/google/protobuf/JavaType;

    move-object/from16 v7, v28

    move-object/from16 v7, v28

    move-object/from16 v7, v28

    move-object/from16 v7, v28

    move-object/from16 v12, v29

    move-object/from16 v12, v29

    move-object/from16 v12, v29

    move-object/from16 v12, v29

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v28, Lcom/google/protobuf/FieldType;->MESSAGE:Lcom/google/protobuf/FieldType;

    new-instance v30, Lcom/google/protobuf/FieldType;

    const-string v8, "SBTmE"

    const-string v8, "STEmB"

    const-string v8, "YSTEo"

    const-string v8, "BYTES"

    const/16 v9, 0xa

    const/16 v10, 0xa

    sget-object v31, Lcom/google/protobuf/JavaType;->BYTE_STRING:Lcom/google/protobuf/JavaType;

    move-object/from16 v7, v30

    move-object/from16 v7, v30

    move-object/from16 v12, v31

    move-object/from16 v12, v31

    move-object/from16 v12, v31

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v30, Lcom/google/protobuf/FieldType;->BYTES:Lcom/google/protobuf/FieldType;

    new-instance v32, Lcom/google/protobuf/FieldType;

    const-string v8, "UI2Nob"

    const-string v8, "TN2UoI"

    const-string/jumbo v8, "u2NUI3"

    const-string v8, "UINT32"

    const/16 v9, 0xb

    const/16 v10, 0xb

    move-object/from16 v7, v32

    move-object/from16 v7, v32

    move-object/from16 v7, v32

    move-object/from16 v7, v32

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v32, Lcom/google/protobuf/FieldType;->UINT32:Lcom/google/protobuf/FieldType;

    new-instance v33, Lcom/google/protobuf/FieldType;

    const-string v8, "MNEU"

    const-string v8, "MUNE"

    const-string v8, "NUME"

    const-string v8, "ENUM"

    const/16 v9, 0xc

    const/16 v10, 0xc

    sget-object v34, Lcom/google/protobuf/JavaType;->ENUM:Lcom/google/protobuf/JavaType;

    move-object/from16 v7, v33

    move-object/from16 v7, v33

    move-object/from16 v7, v33

    move-object/from16 v7, v33

    move-object/from16 v12, v34

    move-object/from16 v12, v34

    move-object/from16 v12, v34

    move-object/from16 v12, v34

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v33, Lcom/google/protobuf/FieldType;->ENUM:Lcom/google/protobuf/FieldType;

    new-instance v35, Lcom/google/protobuf/FieldType;

    const-string v8, "3FbI2XDp"

    const-string v8, "3XF2IbDS"

    const-string v8, "SFIXED32"

    const/16 v9, 0xd

    const/16 v10, 0xd

    move-object/from16 v7, v35

    move-object/from16 v7, v35

    move-object/from16 v7, v35

    move-object/from16 v7, v35

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v35, Lcom/google/protobuf/FieldType;->SFIXED32:Lcom/google/protobuf/FieldType;

    new-instance v36, Lcom/google/protobuf/FieldType;

    const-string/jumbo v8, "qFSu6D4X"

    const-string v8, "IS6FDXu4"

    const-string v8, "EXsSI64F"

    const-string v8, "SFIXED64"

    const/16 v9, 0xe

    const/16 v10, 0xe

    move-object/from16 v7, v36

    move-object/from16 v7, v36

    move-object/from16 v7, v36

    move-object/from16 v7, v36

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v36, Lcom/google/protobuf/FieldType;->SFIXED64:Lcom/google/protobuf/FieldType;

    new-instance v37, Lcom/google/protobuf/FieldType;

    const-string v8, "TN2mIp"

    const-string v8, "2pINT3"

    const-string v8, "SINT32"

    const/16 v9, 0xf

    const/16 v10, 0xf

    move-object/from16 v7, v37

    move-object/from16 v7, v37

    move-object/from16 v7, v37

    move-object/from16 v7, v37

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    move-object/from16 v12, v21

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v37, Lcom/google/protobuf/FieldType;->SINT32:Lcom/google/protobuf/FieldType;

    new-instance v38, Lcom/google/protobuf/FieldType;

    const-string v8, "6NqIoT"

    const-string v8, "NTq4I6"

    const-string v8, "N46ITb"

    const-string v8, "SINT64"

    const/16 v9, 0x10

    const/16 v10, 0x10

    move-object/from16 v7, v38

    move-object/from16 v7, v38

    move-object/from16 v7, v38

    move-object/from16 v7, v38

    move-object v12, v3

    move-object v12, v3

    move-object v12, v3

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v38, Lcom/google/protobuf/FieldType;->SINT64:Lcom/google/protobuf/FieldType;

    new-instance v39, Lcom/google/protobuf/FieldType;

    const-string v8, "OuPGs"

    const-string v8, "GRsPO"

    const-string v8, "OGpPU"

    const-string v8, "GROUP"

    const/16 v9, 0x11

    const/16 v10, 0x11

    move-object/from16 v7, v39

    move-object/from16 v7, v39

    move-object/from16 v7, v39

    move-object/from16 v7, v39

    move-object/from16 v12, v29

    move-object/from16 v12, v29

    move-object/from16 v12, v29

    move-object/from16 v12, v29

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v39, Lcom/google/protobuf/FieldType;->GROUP:Lcom/google/protobuf/FieldType;

    new-instance v13, Lcom/google/protobuf/FieldType;

    const-string v8, "DmL_ESUTqLI"

    const-string v8, "DOLmTU_LESI"

    const-string v8, "DBsTL_OLSIU"

    const-string v8, "DOUBLE_LIST"

    const/16 v9, 0x12

    const/16 v10, 0x12

    sget-object v40, Lcom/google/protobuf/FieldType$Collection;->VECTOR:Lcom/google/protobuf/FieldType$Collection;

    move-object v7, v13

    move-object v7, v13

    move-object v7, v13

    move-object v7, v13

    move-object/from16 v11, v40

    move-object/from16 v11, v40

    move-object/from16 v11, v40

    move-object v12, v14

    move-object v12, v14

    move-object v12, v14

    move-object v12, v14

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v13, Lcom/google/protobuf/FieldType;->DOUBLE_LIST:Lcom/google/protobuf/FieldType;

    new-instance v41, Lcom/google/protobuf/FieldType;

    const-string v16, "IFLmOLA_TS"

    const-string v16, "FLOAT_LIST"

    const/16 v17, 0x13

    const/16 v18, 0x13

    move-object/from16 v15, v41

    move-object/from16 v15, v41

    move-object/from16 v15, v41

    move-object/from16 v15, v41

    move-object/from16 v19, v40

    move-object/from16 v19, v40

    move-object/from16 v19, v40

    move-object/from16 v19, v40

    move-object/from16 v20, v1

    move-object/from16 v20, v1

    move-object/from16 v20, v1

    move-object/from16 v20, v1

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v41, Lcom/google/protobuf/FieldType;->FLOAT_LIST:Lcom/google/protobuf/FieldType;

    new-instance v42, Lcom/google/protobuf/FieldType;

    const-string v16, "4TI_oL6oNS"

    const-string v16, "_SNIoTLI46"

    const-string v16, "4TI_LbSITN"

    const-string v16, "INT64_LIST"

    const/16 v17, 0x14

    const/16 v18, 0x14

    move-object/from16 v15, v42

    move-object/from16 v15, v42

    move-object/from16 v15, v42

    move-object/from16 v15, v42

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v42, Lcom/google/protobuf/FieldType;->INT64_LIST:Lcom/google/protobuf/FieldType;

    new-instance v43, Lcom/google/protobuf/FieldType;

    const-string v16, "TUIbNSuLIT_"

    const-string v16, "TTLINb_4IUS"

    const-string v16, "SI6TLITp4_N"

    const-string v16, "UINT64_LIST"

    const/16 v17, 0x15

    const/16 v18, 0x15

    move-object/from16 v15, v43

    move-object/from16 v15, v43

    move-object/from16 v15, v43

    move-object/from16 v15, v43

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v43, Lcom/google/protobuf/FieldType;->UINT64_LIST:Lcom/google/protobuf/FieldType;

    new-instance v44, Lcom/google/protobuf/FieldType;

    const-string v16, "2Tu_LST3qI"

    const-string v16, "T2I_ISuL3T"

    const-string v16, "INs2L3S_TT"

    const-string v16, "INT32_LIST"

    const/16 v17, 0x16

    const/16 v18, 0x16

    move-object/from16 v15, v44

    move-object/from16 v15, v44

    move-object/from16 v15, v44

    move-object/from16 v15, v44

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v44, Lcom/google/protobuf/FieldType;->INT32_LIST:Lcom/google/protobuf/FieldType;

    new-instance v45, Lcom/google/protobuf/FieldType;

    const-string/jumbo v16, "p4FmTLD_XI6E"

    const-string v16, "4X6LTE_pSFDI"

    const-string v16, "EFL4oXSITD6_"

    const-string v16, "FIXED64_LIST"

    const/16 v17, 0x17

    const/16 v18, 0x17

    move-object/from16 v15, v45

    move-object/from16 v15, v45

    move-object/from16 v15, v45

    move-object/from16 v15, v45

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v45, Lcom/google/protobuf/FieldType;->FIXED64_LIST:Lcom/google/protobuf/FieldType;

    new-instance v46, Lcom/google/protobuf/FieldType;

    const-string v16, "SqTLXbIDF2_3"

    const-string v16, "3TFD2_LEqXIS"

    const-string v16, "FIXED32_LIST"

    const/16 v17, 0x18

    const/16 v18, 0x18

    move-object/from16 v15, v46

    move-object/from16 v15, v46

    move-object/from16 v15, v46

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v46, Lcom/google/protobuf/FieldType;->FIXED32_LIST:Lcom/google/protobuf/FieldType;

    new-instance v47, Lcom/google/protobuf/FieldType;

    const-string v16, "LBOTS_usL"

    const-string v16, "OOsSTLB_L"

    const-string v16, "BSIT_LOpO"

    const-string v16, "BOOL_LIST"

    const/16 v17, 0x19

    const/16 v18, 0x19

    move-object/from16 v15, v47

    move-object/from16 v15, v47

    move-object/from16 v15, v47

    move-object/from16 v15, v47

    move-object/from16 v20, v25

    move-object/from16 v20, v25

    move-object/from16 v20, v25

    move-object/from16 v20, v25

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v47, Lcom/google/protobuf/FieldType;->BOOL_LIST:Lcom/google/protobuf/FieldType;

    new-instance v48, Lcom/google/protobuf/FieldType;

    const-string v16, "GINmLS_IRST"

    const-string v16, "ITSNSITRq_L"

    const-string v16, "STRING_LIST"

    const/16 v17, 0x1a

    const/16 v18, 0x1a

    move-object/from16 v15, v48

    move-object/from16 v15, v48

    move-object/from16 v20, v27

    move-object/from16 v20, v27

    move-object/from16 v20, v27

    move-object/from16 v20, v27

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v48, Lcom/google/protobuf/FieldType;->STRING_LIST:Lcom/google/protobuf/FieldType;

    new-instance v27, Lcom/google/protobuf/FieldType;

    const-string v16, "LosA_EMSSTGI"

    const-string v16, "TS_GoLASIMES"

    const-string v16, "MESSAGE_LIST"

    const/16 v17, 0x1b

    const/16 v18, 0x1b

    move-object/from16 v15, v27

    move-object/from16 v15, v27

    move-object/from16 v15, v27

    move-object/from16 v15, v27

    move-object/from16 v20, v29

    move-object/from16 v20, v29

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v27, Lcom/google/protobuf/FieldType;->MESSAGE_LIST:Lcom/google/protobuf/FieldType;

    new-instance v49, Lcom/google/protobuf/FieldType;

    const-string v16, "SSYmBLTT_E"

    const-string v16, "STTS_bELYB"

    const-string v16, "BYTES_LIST"

    const/16 v17, 0x1c

    const/16 v18, 0x1c

    move-object/from16 v15, v49

    move-object/from16 v15, v49

    move-object/from16 v15, v49

    move-object/from16 v15, v49

    move-object/from16 v20, v31

    move-object/from16 v20, v31

    move-object/from16 v20, v31

    move-object/from16 v20, v31

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v49, Lcom/google/protobuf/FieldType;->BYTES_LIST:Lcom/google/protobuf/FieldType;

    new-instance v31, Lcom/google/protobuf/FieldType;

    const-string v16, "2LNTouI_SUI"

    const-string v16, "ITT2UNuL_IS"

    const-string v16, "UINT32_LIST"

    const/16 v17, 0x1d

    const/16 v18, 0x1d

    move-object/from16 v15, v31

    move-object/from16 v15, v31

    move-object/from16 v15, v31

    move-object/from16 v15, v31

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v31, Lcom/google/protobuf/FieldType;->UINT32_LIST:Lcom/google/protobuf/FieldType;

    new-instance v50, Lcom/google/protobuf/FieldType;

    const-string v16, "INEMSbpL_"

    const-string v16, "STNIMELp_"

    const-string v16, "NSTL_EuUI"

    const-string v16, "ENUM_LIST"

    const/16 v17, 0x1e

    const/16 v18, 0x1e

    move-object/from16 v15, v50

    move-object/from16 v15, v50

    move-object/from16 v15, v50

    move-object/from16 v20, v34

    move-object/from16 v20, v34

    move-object/from16 v20, v34

    move-object/from16 v20, v34

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v50, Lcom/google/protobuf/FieldType;->ENUM_LIST:Lcom/google/protobuf/FieldType;

    new-instance v51, Lcom/google/protobuf/FieldType;

    const-string v16, "I_ET3FSpX2LIS"

    const-string v16, "_LTSEIFIq23SX"

    const-string v16, "DSFTI_E2qX3IL"

    const-string v16, "SFIXED32_LIST"

    const/16 v17, 0x1f

    const/16 v18, 0x1f

    move-object/from16 v15, v51

    move-object/from16 v15, v51

    move-object/from16 v15, v51

    move-object/from16 v15, v51

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v51, Lcom/google/protobuf/FieldType;->SFIXED32_LIST:Lcom/google/protobuf/FieldType;

    new-instance v52, Lcom/google/protobuf/FieldType;

    const-string v16, "T_sF64XLSsISE"

    const-string v16, "ILsFXD_6SET4S"

    const-string v16, "IXSmF_6DTSL4I"

    const-string v16, "SFIXED64_LIST"

    const/16 v17, 0x20

    const/16 v18, 0x20

    move-object/from16 v15, v52

    move-object/from16 v15, v52

    move-object/from16 v15, v52

    move-object/from16 v15, v52

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v52, Lcom/google/protobuf/FieldType;->SFIXED64_LIST:Lcom/google/protobuf/FieldType;

    new-instance v53, Lcom/google/protobuf/FieldType;

    const-string v16, "SLSToImI_23"

    const-string v16, "SI3mT2LIS_T"

    const-string v16, "L_NTIbS3TIS"

    const-string v16, "SINT32_LIST"

    const/16 v17, 0x21

    const/16 v18, 0x21

    move-object/from16 v15, v53

    move-object/from16 v15, v53

    move-object/from16 v15, v53

    move-object/from16 v15, v53

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v53, Lcom/google/protobuf/FieldType;->SINT32_LIST:Lcom/google/protobuf/FieldType;

    new-instance v54, Lcom/google/protobuf/FieldType;

    const-string v16, "SI6_SNuTI4o"

    const-string v16, "ST6SoI_4INT"

    const-string v16, "TS6SL_IpITN"

    const-string v16, "SINT64_LIST"

    const/16 v17, 0x22

    const/16 v18, 0x22

    move-object/from16 v15, v54

    move-object/from16 v15, v54

    move-object/from16 v15, v54

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v54, Lcom/google/protobuf/FieldType;->SINT64_LIST:Lcom/google/protobuf/FieldType;

    new-instance v55, Lcom/google/protobuf/FieldType;

    const-string v8, "DBEIOUALqb__CSPLKD"

    const-string v8, "DUIALbLB_KDSET_COP"

    const-string v8, "PLsCDUDBS_ETLKI_OA"

    const-string v8, "DOUBLE_LIST_PACKED"

    const/16 v9, 0x23

    const/16 v10, 0x23

    sget-object v56, Lcom/google/protobuf/FieldType$Collection;->PACKED_VECTOR:Lcom/google/protobuf/FieldType$Collection;

    move-object/from16 v7, v55

    move-object/from16 v7, v55

    move-object/from16 v7, v55

    move-object/from16 v7, v55

    move-object/from16 v11, v56

    move-object/from16 v11, v56

    move-object/from16 v11, v56

    move-object/from16 v11, v56

    invoke-direct/range {v7 .. v12}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v55, Lcom/google/protobuf/FieldType;->DOUBLE_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v7, Lcom/google/protobuf/FieldType;

    const-string v16, "ALDCE_uL_KTAITSPF"

    const-string v16, "_TOmKIAEFDA_CPLSL"

    const-string v16, "FLOAT_LIST_PACKED"

    const/16 v17, 0x24

    const/16 v18, 0x24

    move-object v15, v7

    move-object v15, v7

    move-object/from16 v19, v56

    move-object/from16 v19, v56

    move-object/from16 v19, v56

    move-object/from16 v19, v56

    move-object/from16 v20, v1

    move-object/from16 v20, v1

    move-object/from16 v20, v1

    move-object/from16 v20, v1

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v7, Lcom/google/protobuf/FieldType;->FLOAT_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v1, Lcom/google/protobuf/FieldType;

    const-string v16, "IN4IoSD__TE6KPTpL"

    const-string v16, "6ATK4SIp_TDIL_NPE"

    const-string v16, "LAIPTbC6KEIST_N_D"

    const-string v16, "INT64_LIST_PACKED"

    const/16 v17, 0x25

    const/16 v18, 0x25

    move-object v15, v1

    move-object v15, v1

    move-object v15, v1

    move-object v15, v1

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v1, Lcom/google/protobuf/FieldType;->INT64_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v8, Lcom/google/protobuf/FieldType;

    const-string v16, "ULTAT4u_q_IKNICD6S"

    const-string v16, "IIS6__ALqPDTU4TCKN"

    const-string v16, "UINT64_LIST_PACKED"

    const/16 v17, 0x26

    const/16 v18, 0x26

    move-object v15, v8

    move-object v15, v8

    move-object v15, v8

    move-object v15, v8

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v8, Lcom/google/protobuf/FieldType;->UINT64_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v9, Lcom/google/protobuf/FieldType;

    const-string v16, "SsNI3TEpDKC_LI2TA"

    const-string v16, "AKsLNPSITET_2C3ID"

    const-string v16, "ETLPNIDCq_K2TS3IA"

    const-string v16, "INT32_LIST_PACKED"

    const/16 v17, 0x27

    const/16 v18, 0x27

    move-object v15, v9

    move-object v15, v9

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v9, Lcom/google/protobuf/FieldType;->INT32_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v10, Lcom/google/protobuf/FieldType;

    const-string v16, "DDEmL6TFC_A4IEISX_K"

    const-string v16, "FIXED64_LIST_PACKED"

    const/16 v17, 0x28

    const/16 v18, 0x28

    move-object v15, v10

    move-object v15, v10

    move-object v15, v10

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v10, Lcom/google/protobuf/FieldType;->FIXED64_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v11, Lcom/google/protobuf/FieldType;

    const-string v16, "ADsXIoCIF_DK2EPLSE3"

    const-string v16, "F_DIoLKCSTDEAE2PX3I"

    const-string v16, "L_Cm_E2XSDITD3IEAKF"

    const-string v16, "FIXED32_LIST_PACKED"

    const/16 v17, 0x29

    const/16 v18, 0x29

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v11, Lcom/google/protobuf/FieldType;->FIXED32_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v12, Lcom/google/protobuf/FieldType;

    const-string v16, "CEADLbBILTO_O_PK"

    const-string v16, "TP_CoOKA_DISLOEL"

    const-string v16, "BOOL_LIST_PACKED"

    const/16 v17, 0x2a

    const/16 v18, 0x2a

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    move-object v15, v12

    move-object/from16 v20, v25

    move-object/from16 v20, v25

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v12, Lcom/google/protobuf/FieldType;->BOOL_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v14, Lcom/google/protobuf/FieldType;

    const-string v16, "ITI3AbNC_DSKPLu2ET"

    const-string v16, "_ANKD_uPIE3CLTI2ST"

    const-string v16, "_LI3KIuDEUTTCA2PNS"

    const-string v16, "UINT32_LIST_PACKED"

    const/16 v17, 0x2b

    const/16 v18, 0x2b

    move-object v15, v14

    move-object v15, v14

    move-object v15, v14

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v14, Lcom/google/protobuf/FieldType;->UINT32_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v25, Lcom/google/protobuf/FieldType;

    const-string v16, "EE_SKCApUTNMPD_I"

    const-string v16, "_EEKUMTp_NCDISAP"

    const-string v16, "ULEMS_NAqC_PKIDT"

    const-string v16, "ENUM_LIST_PACKED"

    const/16 v17, 0x2c

    const/16 v18, 0x2c

    move-object/from16 v15, v25

    move-object/from16 v15, v25

    move-object/from16 v15, v25

    move-object/from16 v15, v25

    move-object/from16 v20, v34

    move-object/from16 v20, v34

    move-object/from16 v20, v34

    move-object/from16 v20, v34

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v25, Lcom/google/protobuf/FieldType;->ENUM_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v34, Lcom/google/protobuf/FieldType;

    const-string v16, "2XsDI3SD_L_AEFTKECIS"

    const-string v16, "EIXELS_IqK2_CD3TAFDS"

    const-string v16, "XDLmDS2CI_AP3FSKET_E"

    const-string v16, "SFIXED32_LIST_PACKED"

    const/16 v17, 0x2d

    const/16 v18, 0x2d

    move-object/from16 v15, v34

    move-object/from16 v15, v34

    move-object/from16 v15, v34

    move-object/from16 v15, v34

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v34, Lcom/google/protobuf/FieldType;->SFIXED32_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v57, Lcom/google/protobuf/FieldType;

    const-string v16, "X_LIoTDIPKS6CsASE4_D"

    const-string v16, "AKsS6SDPLI4_ICTFX_ED"

    const-string v16, "S6IXPbTECIFL_ASD4_KE"

    const-string v16, "SFIXED64_LIST_PACKED"

    const/16 v17, 0x2e

    const/16 v18, 0x2e

    move-object/from16 v15, v57

    move-object/from16 v15, v57

    move-object/from16 v15, v57

    move-object/from16 v15, v57

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v57, Lcom/google/protobuf/FieldType;->SFIXED64_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v58, Lcom/google/protobuf/FieldType;

    const-string v16, "AIL2NCuDPKSm_ET3I_"

    const-string v16, "ITDm_A2_KNL3IETCPS"

    const-string v16, "STC_N2Kp3DI_LITPEA"

    const-string v16, "SINT32_LIST_PACKED"

    const/16 v17, 0x2f

    const/16 v18, 0x2f

    move-object/from16 v15, v58

    move-object/from16 v15, v58

    move-object/from16 v15, v58

    move-object/from16 v15, v58

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    move-object/from16 v20, v21

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v58, Lcom/google/protobuf/FieldType;->SINT32_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v21, Lcom/google/protobuf/FieldType;

    const-string v16, "ToISE_ADq4C6SLNT_P"

    const-string v16, "64NSoKADICLPT_TES_"

    const-string v16, "DCsE6SI4TTAN_ISKL_"

    const-string v16, "SINT64_LIST_PACKED"

    const/16 v17, 0x30

    const/16 v18, 0x30

    move-object/from16 v15, v21

    move-object/from16 v15, v21

    move-object/from16 v15, v21

    move-object/from16 v15, v21

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    move-object/from16 v20, v3

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v21, Lcom/google/protobuf/FieldType;->SINT64_LIST_PACKED:Lcom/google/protobuf/FieldType;

    new-instance v3, Lcom/google/protobuf/FieldType;

    const-string v16, "PIRmOTS_Lb"

    const-string v16, "PTISUbR_LO"

    const-string v16, "OLR_oGSTPI"

    const-string v16, "GROUP_LIST"

    const/16 v17, 0x31

    const/16 v18, 0x31

    move-object v15, v3

    move-object v15, v3

    move-object v15, v3

    move-object v15, v3

    move-object/from16 v19, v40

    move-object/from16 v19, v40

    move-object/from16 v19, v40

    move-object/from16 v19, v40

    move-object/from16 v20, v29

    move-object/from16 v20, v29

    move-object/from16 v20, v29

    move-object/from16 v20, v29

    invoke-direct/range {v15 .. v20}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v3, Lcom/google/protobuf/FieldType;->GROUP_LIST:Lcom/google/protobuf/FieldType;

    new-instance v15, Lcom/google/protobuf/FieldType;

    const-string v60, "PMA"

    const-string v60, "PMA"

    const-string v60, "MPA"

    const-string v60, "MAP"

    const/16 v61, 0x32

    const/16 v62, 0x32

    sget-object v63, Lcom/google/protobuf/FieldType$Collection;->MAP:Lcom/google/protobuf/FieldType$Collection;

    sget-object v64, Lcom/google/protobuf/JavaType;->VOID:Lcom/google/protobuf/JavaType;

    move-object/from16 v59, v15

    invoke-direct/range {v59 .. v64}, Lcom/google/protobuf/FieldType;-><init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V

    sput-object v15, Lcom/google/protobuf/FieldType;->MAP:Lcom/google/protobuf/FieldType;

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    const/16 v15, 0x33

    new-array v15, v15, [Lcom/google/protobuf/FieldType;

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    const/4 v3, 0x0

    aput-object v6, v15, v3

    const/4 v6, 0x1

    aput-object v0, v15, v6

    const/4 v0, 0x2

    aput-object v2, v15, v0

    const/4 v0, 0x3

    aput-object v4, v15, v0

    const/4 v0, 0x4

    aput-object v5, v15, v0

    const/4 v0, 0x5

    aput-object v22, v15, v0

    const/4 v0, 0x6

    aput-object v23, v15, v0

    const/4 v0, 0x7

    aput-object v24, v15, v0

    const/16 v0, 0x8

    aput-object v26, v15, v0

    const/16 v0, 0x9

    aput-object v28, v15, v0

    const/16 v0, 0xa

    aput-object v30, v15, v0

    const/16 v0, 0xb

    aput-object v32, v15, v0

    const/16 v0, 0xc

    aput-object v33, v15, v0

    const/16 v0, 0xd

    aput-object v35, v15, v0

    const/16 v0, 0xe

    aput-object v36, v15, v0

    const/16 v0, 0xf

    aput-object v37, v15, v0

    const/16 v0, 0x10

    aput-object v38, v15, v0

    const/16 v0, 0x11

    aput-object v39, v15, v0

    const/16 v0, 0x12

    aput-object v13, v15, v0

    const/16 v0, 0x13

    aput-object v41, v15, v0

    const/16 v0, 0x14

    aput-object v42, v15, v0

    const/16 v0, 0x15

    aput-object v43, v15, v0

    const/16 v0, 0x16

    aput-object v44, v15, v0

    const/16 v0, 0x17

    aput-object v45, v15, v0

    const/16 v0, 0x18

    aput-object v46, v15, v0

    const/16 v0, 0x19

    aput-object v47, v15, v0

    const/16 v0, 0x1a

    aput-object v48, v15, v0

    const/16 v0, 0x1b

    aput-object v27, v15, v0

    const/16 v0, 0x1c

    aput-object v49, v15, v0

    const/16 v0, 0x1d

    aput-object v31, v15, v0

    const/16 v0, 0x1e

    aput-object v50, v15, v0

    const/16 v0, 0x1f

    aput-object v51, v15, v0

    const/16 v0, 0x20

    aput-object v52, v15, v0

    const/16 v0, 0x21

    aput-object v53, v15, v0

    const/16 v0, 0x22

    aput-object v54, v15, v0

    const/16 v0, 0x23

    aput-object v55, v15, v0

    const/16 v0, 0x24

    aput-object v7, v15, v0

    const/16 v0, 0x25

    aput-object v1, v15, v0

    const/16 v0, 0x26

    aput-object v8, v15, v0

    const/16 v0, 0x27

    aput-object v9, v15, v0

    const/16 v0, 0x28

    aput-object v10, v15, v0

    const/16 v0, 0x29

    aput-object v11, v15, v0

    const/16 v0, 0x2a

    aput-object v12, v15, v0

    const/16 v0, 0x2b

    aput-object v14, v15, v0

    const/16 v0, 0x2c

    aput-object v25, v15, v0

    const/16 v0, 0x2d

    aput-object v34, v15, v0

    const/16 v0, 0x2e

    aput-object v57, v15, v0

    const/16 v0, 0x2f

    aput-object v58, v15, v0

    const/16 v0, 0x30

    aput-object v21, v15, v0

    const/16 v0, 0x31

    aput-object v17, v15, v0

    const/16 v0, 0x32

    aput-object v16, v15, v0

    sput-object v15, Lcom/google/protobuf/FieldType;->$VALUES:[Lcom/google/protobuf/FieldType;

    new-array v0, v3, [Ljava/lang/reflect/Type;

    sput-object v0, Lcom/google/protobuf/FieldType;->EMPTY_TYPES:[Ljava/lang/reflect/Type;

    invoke-static {}, Lcom/google/protobuf/FieldType;->values()[Lcom/google/protobuf/FieldType;

    move-result-object v0

    array-length v1, v0

    new-array v1, v1, [Lcom/google/protobuf/FieldType;

    sput-object v1, Lcom/google/protobuf/FieldType;->VALUES:[Lcom/google/protobuf/FieldType;

    array-length v1, v0

    :goto_0
    if-ge v3, v1, :cond_0

    aget-object v2, v0, v3

    sget-object v4, Lcom/google/protobuf/FieldType;->VALUES:[Lcom/google/protobuf/FieldType;

    iget v5, v2, Lcom/google/protobuf/FieldType;->id:I

    aput-object v2, v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IILcom/google/protobuf/FieldType$Collection;Lcom/google/protobuf/JavaType;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0,
            0x0,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "id",
            "collection",
            "javaType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Lcom/google/protobuf/FieldType$Collection;",
            "Lcom/google/protobuf/JavaType;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p3, p0, Lcom/google/protobuf/FieldType;->id:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/google/protobuf/FieldType;->collection:Lcom/google/protobuf/FieldType$Collection;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p5, p0, Lcom/google/protobuf/FieldType;->javaType:Lcom/google/protobuf/JavaType;

    const/4 v1, 0x1

    const/4 v0, 0x5

    sget-object p1, Lcom/google/protobuf/FieldType$1;->$SwitchMap$com$google$protobuf$FieldType$Collection:[I

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p4}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    aget p1, p1, p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p2, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    const/4 p3, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eq p1, p3, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eq p1, p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/google/protobuf/FieldType;->elementType:Ljava/lang/Class;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    invoke-virtual {p5}, Lcom/google/protobuf/JavaType;->getBoxedType()Ljava/lang/Class;

    move-result-object p1

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/FieldType;->elementType:Ljava/lang/Class;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    goto :goto_0

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p5}, Lcom/google/protobuf/JavaType;->getBoxedType()Ljava/lang/Class;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/protobuf/FieldType;->elementType:Ljava/lang/Class;

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    sget-object p1, Lcom/google/protobuf/FieldType$Collection;->SCALAR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-ne p4, p1, :cond_2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    sget-object p1, Lcom/google/protobuf/FieldType$1;->$SwitchMap$com$google$protobuf$JavaType:[I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p5}, Ljava/lang/Enum;->ordinal()I

    move-result p4

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    aget p1, p1, p4

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-eq p1, p3, :cond_2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eq p1, p2, :cond_2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p2, 0x3

    const/4 v1, 0x0

    const/4 v0, 0x4

    if-eq p1, p2, :cond_2

    const/4 v1, 0x1

    const/4 v0, 0x3

    goto :goto_1

    :cond_2
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p3, 0x0

    :goto_1
    const/4 v1, 0x7

    iput-boolean p3, p0, Lcom/google/protobuf/FieldType;->primitiveScalar:Z

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public static forId(I)Lcom/google/protobuf/FieldType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "id"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " t@@mbo @//@@ob~~~~@@1  ~ @b~~@~us afc~o @~@ ~-lol~~ @ bo ~ ni4d~@@i~ @~@@~ Mri  ~~K.f ~@~vtoy@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    if-ltz p0, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lcom/google/protobuf/FieldType;->VALUES:[Lcom/google/protobuf/FieldType;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    array-length v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-lt p0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    aget-object p0, v0, p0

    const/4 v2, 0x2

    move v3, v2

    return-object p0

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x1

    return-object p0
.end method

.method private static getGenericSuperList(Ljava/lang/Class;)Ljava/lang/reflect/Type;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "clazz"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;)",
            "Ljava/lang/reflect/Type;"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->getGenericInterfaces()[Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    array-length v1, v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v2, 0x0

    :goto_0
    const-class v3, Ljava/util/List;

    const-class v3, Ljava/util/List;

    const/4 v7, 0x1

    const-class v3, Ljava/util/List;

    const-class v3, Ljava/util/List;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-ge v2, v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    aget-object v4, v0, v2

    instance-of v5, v4, Ljava/lang/reflect/ParameterizedType;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v5, :cond_0

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    check-cast v5, Ljava/lang/reflect/ParameterizedType;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v5}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    check-cast v5, Ljava/lang/Class;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v3, v5}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v3, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    return-object v4

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getGenericSuperclass()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    instance-of v0, p0, Ljava/lang/reflect/ParameterizedType;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-eqz v0, :cond_2

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    check-cast v0, Ljava/lang/reflect/ParameterizedType;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v0}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    check-cast v0, Ljava/lang/Class;

    const/4 v7, 0x7

    invoke-virtual {v3, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    return-object p0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 p0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-object p0
.end method

.method private static getListParameter(Ljava/lang/Class;[Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "clazz",
            "realTypes"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "*>;[",
            "Ljava/lang/reflect/Type;",
            ")",
            "Ljava/lang/reflect/Type;"
        }
    .end annotation

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-class v0, Ljava/util/List;

    const-class v0, Ljava/util/List;

    const/4 v10, 0x0

    const-class v0, Ljava/util/List;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v1, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v2, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eq p0, v0, :cond_9

    const/4 v10, 0x0

    invoke-static {p0}, Lcom/google/protobuf/FieldType;->getGenericSuperList(Ljava/lang/Class;)Ljava/lang/reflect/Type;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    instance-of v4, v3, Ljava/lang/reflect/ParameterizedType;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    if-eqz v4, :cond_6

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    check-cast v3, Ljava/lang/reflect/ParameterizedType;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-interface {v3}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    move v4, v1

    move v4, v1

    const/4 v10, 0x4

    move v4, v1

    move v4, v1

    :goto_1
    const/4 v10, 0x4

    array-length v5, v0

    const/4 v9, 0x1

    move v10, v9

    if-ge v4, v5, :cond_5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    aget-object v5, v0, v4

    const/4 v9, 0x7

    const/4 v9, 0x3

    instance-of v6, v5, Ljava/lang/reflect/TypeVariable;

    const/4 v9, 0x6

    and-int/2addr v10, v9

    if-eqz v6, :cond_4

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p0}, Ljava/lang/Class;->getTypeParameters()[Ljava/lang/reflect/TypeVariable;

    move-result-object v6

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    array-length v7, p1

    const/4 v10, 0x4

    const/4 v9, 0x7

    array-length v8, v6

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-ne v7, v8, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v7, v1

    const/4 v10, 0x3

    move v7, v1

    move v7, v1

    :goto_2
    const/4 v10, 0x2

    const/4 v9, 0x4

    array-length v8, v6

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-ge v7, v8, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    aget-object v8, v6, v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-ne v5, v8, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    aget-object v6, p1, v7

    const/4 v9, 0x4

    move v10, v9

    aput-object v6, v0, v4

    const/4 v9, 0x4

    and-int/2addr v10, v9

    move v6, v2

    move v6, v2

    const/4 v10, 0x1

    move v6, v2

    move v6, v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto :goto_3

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    add-int/lit8 v7, v7, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto :goto_2

    :cond_1
    const/4 v10, 0x4

    move v6, v1

    move v6, v1

    const/4 v10, 0x3

    move v6, v1

    :goto_3
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v6, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto :goto_4

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v10, 0x2

    const/4 v9, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    move v10, v9

    const-string v0, "buUapeufa micl toentnen lr f od"

    const-string/jumbo v0, "neel iu fUorrcanoa ptemt lndf b"

    const/4 v10, 0x7

    const-string/jumbo v0, "n  cerepolmltr tiad fUpanon feb"

    const-string v0, "Unable to find replacement for "

    const/4 v10, 0x7

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    throw p0

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string p1, "crmamhaaqsipT yert "

    const-string/jumbo p1, "ryam rhpatmaipc Tes"

    const/4 v10, 0x7

    const-string p1, " msTc piayrsahymaer"

    const-string p1, "Type array mismatch"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    throw p0

    :cond_4
    :goto_4
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-interface {v3}, Ljava/lang/reflect/ParameterizedType;->getRawType()Ljava/lang/reflect/Type;

    move-result-object p0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    check-cast p0, Ljava/lang/Class;

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_6
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    sget-object p1, Lcom/google/protobuf/FieldType;->EMPTY_TYPES:[Ljava/lang/reflect/Type;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getInterfaces()[Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    array-length v3, v2

    :goto_5
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-ge v1, v3, :cond_8

    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    aget-object v4, v2, v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v5

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v5, :cond_7

    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    move-object p0, v4

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto/16 :goto_0

    :cond_7
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto :goto_5

    :cond_8
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto/16 :goto_0

    :cond_9
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    array-length p0, p1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-ne p0, v2, :cond_a

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    aget-object p0, p1, v1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    return-object p0

    :cond_a
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string/jumbo p1, "nqfmyp <lbaiadeot retpLe aUt>time rn ts eyoTf"

    const-string/jumbo p1, "ntt at yqTfms taeroin eaiborleit<fe dLp ype>U"

    const/4 v10, 0x6

    const-string/jumbo p1, "tyosoemofrfrieT<tintL b a Utpletra  pe nyeaid"

    const-string p1, "Unable to identify parameter type for List<T>"

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    throw p0
.end method

.method private isValidForList(Ljava/lang/reflect/Field;)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/FieldType;->javaType:Lcom/google/protobuf/JavaType;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/JavaType;->getType()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    return p1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v1, Lcom/google/protobuf/FieldType;->EMPTY_TYPES:[Ljava/lang/reflect/Type;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/reflect/Field;->getGenericType()Ljava/lang/reflect/Type;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    instance-of v2, v2, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/reflect/Field;->getGenericType()Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast p1, Ljava/lang/reflect/ParameterizedType;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/lang/reflect/ParameterizedType;->getActualTypeArguments()[Ljava/lang/reflect/Type;

    move-result-object v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/FieldType;->getListParameter(Ljava/lang/Class;[Ljava/lang/reflect/Type;)Ljava/lang/reflect/Type;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    instance-of v0, p1, Ljava/lang/Class;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    return p1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/protobuf/FieldType;->elementType:Ljava/lang/Class;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast p1, Ljava/lang/Class;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    return p1
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/FieldType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-class v0, Lcom/google/protobuf/FieldType;

    const-class v0, Lcom/google/protobuf/FieldType;

    const/4 v2, 0x0

    const-class v0, Lcom/google/protobuf/FieldType;

    const-class v0, Lcom/google/protobuf/FieldType;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/FieldType;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/FieldType;
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    sget-object v0, Lcom/google/protobuf/FieldType;->$VALUES:[Lcom/google/protobuf/FieldType;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lcom/google/protobuf/FieldType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast v0, [Lcom/google/protobuf/FieldType;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public getJavaType()Lcom/google/protobuf/JavaType;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Lcom/google/protobuf/FieldType;->javaType:Lcom/google/protobuf/JavaType;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public id()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/FieldType;->id:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public isList()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/FieldType;->collection:Lcom/google/protobuf/FieldType$Collection;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/FieldType$Collection;->isList()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public isMap()Z
    .locals 4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/FieldType;->collection:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v1, Lcom/google/protobuf/FieldType$Collection;->MAP:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    return v0
.end method

.method public isPacked()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lcom/google/protobuf/FieldType$Collection;->PACKED_VECTOR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/protobuf/FieldType;->collection:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return v0
.end method

.method public isPrimitiveScalar()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/google/protobuf/FieldType;->primitiveScalar:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public isScalar()Z
    .locals 4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/FieldType;->collection:Lcom/google/protobuf/FieldType$Collection;

    sget-object v1, Lcom/google/protobuf/FieldType$Collection;->SCALAR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method public isValidForField(Ljava/lang/reflect/Field;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lcom/google/protobuf/FieldType$Collection;->VECTOR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/protobuf/FieldType;->collection:Lcom/google/protobuf/FieldType$Collection;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/FieldType;->isValidForList(Ljava/lang/reflect/Field;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v2, 0x7

    move v3, v2

    iget-object v0, p0, Lcom/google/protobuf/FieldType;->javaType:Lcom/google/protobuf/JavaType;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/JavaType;->getType()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return p1
.end method
