.class final Lcom/google/protobuf/CodedInputStream$ArrayDecoder;
.super Lcom/google/protobuf/CodedInputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedInputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ArrayDecoder"
.end annotation


# instance fields
.field private final buffer:[B

.field private bufferSizeAfterLimit:I

.field private currentLimit:I

.field private enableAliasing:Z

.field private final immutable:Z

.field private lastTag:I

.field private limit:I

.field private pos:I

.field private startPos:I


# direct methods
.method private constructor <init>([BIIZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x0
        }
        names = {
            "buffer",
            "offset",
            "len",
            "immutable"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream;-><init>(Lcom/google/protobuf/CodedInputStream$1;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const v0, 0x7fffffff

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->currentLimit:I

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    add-int/2addr p3, p2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput p3, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput p2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput p2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->startPos:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean p4, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->immutable:Z

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method synthetic constructor <init>([BIIZLcom/google/protobuf/CodedInputStream$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;-><init>([BIIZ)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private recomputeBufferSizeAfterLimit()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "v s/ M~~t~u S~ @o@sblmi1@@~~i -~.~@@b @~o4@~~~@  r @@~~ ~d@@@f~i@~~oo  l  f@@@@cy ~ onKbao~~ @/t"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->bufferSizeAfterLimit:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->startPos:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    sub-int v1, v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->currentLimit:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-le v1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    sub-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->bufferSizeAfterLimit:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    sub-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x5

    move v4, v3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->bufferSizeAfterLimit:I

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method private skipRawVarint()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x7

    sub-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/16 v1, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-lt v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipRawVarintFastPath()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipRawVarintSlowPath()V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method private skipRawVarintFastPath()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/16 v1, 0xa

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-ge v0, v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-int/lit8 v3, v2, 0x1

    const/4 v5, 0x6

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    aget-byte v1, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-ltz v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    throw v0
.end method

.method private skipRawVarintSlowPath()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/16 v1, 0xa

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ge v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawByte()B

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ltz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    throw v0
.end method


# virtual methods
.method public checkLastTagWas(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->lastTag:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-ne v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidEndTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    throw p1
.end method

.method public enableAliasing(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enabled"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->enableAliasing:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public getBytesUntilLimit()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->currentLimit:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const v1, 0x7fffffff

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->getTotalBytesRead()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method public getLastTag()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->lastTag:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    return v0
.end method

.method public getTotalBytesRead()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->startPos:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v0
.end method

.method public isAtEnd()Z
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x2

    move v2, v0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0
.end method

.method public popLimit(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "oldLimit"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->currentLimit:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v0, 0x2

    and-int/2addr v1, v0

    return-void
.end method

.method public pushLimit(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "byteLimit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ltz p1, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->getTotalBytesRead()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    add-int/2addr p1, v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ltz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->currentLimit:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    if-gt p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->currentLimit:I

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    throw p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    throw p1

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    throw p1
.end method

.method public readBool()Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    cmp-long v0, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    return v0
.end method

.method public readByteArray()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawBytes(I)[B

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public readByteBuffer()Ljava/nio/ByteBuffer;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-lez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    sub-int/2addr v1, v2

    const/4 v5, 0x6

    if-gt v0, v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->immutable:Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->enableAliasing:Z

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    and-int/2addr v5, v4

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v1, v2, v0}, Ljava/nio/ByteBuffer;->wrap([BII)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-int v3, v2, v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, v2, v3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-int/2addr v2, v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object v1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    sget-object v0, Lcom/google/protobuf/Internal;->EMPTY_BYTE_BUFFER:Ljava/nio/ByteBuffer;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object v0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-gez v0, :cond_3

    const/4 v4, 0x5

    move v5, v4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    throw v0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    throw v0
.end method

.method public readBytes()Lcom/google/protobuf/ByteString;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-lez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    sub-int/2addr v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-gt v0, v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->immutable:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->enableAliasing:Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/ByteString;->wrap([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/2addr v2, v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawBytes(I)[B

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->wrap([B)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0
.end method

.method public readDouble()D
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide v0
.end method

.method public readEnum()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public readFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public readFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-wide v0
.end method

.method public readFloat()F
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v2, 0x5

    return v0
.end method

.method public readGroup(ILcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(I",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p2, Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p3, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-static {p1, p3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->checkLastTagWas(I)V

    const/4 v2, 0x4

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x0

    return-object p2
.end method

.method public readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 p2, 0x4

    move v2, p2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->checkLastTagWas(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public readInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public readInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-wide v0
.end method

.method public readMessage(Lcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    check-cast p1, Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x1

    move v3, v2

    const/4 p2, 0x0

    const/4 p2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    add-int/lit8 p2, p2, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->getBytesUntilLimit()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->popLimit(I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw p1
.end method

.method public readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x3

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->getBytesUntilLimit()I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->popLimit(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p1
.end method

.method public readRawByte()B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eq v0, v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    add-int/lit8 v2, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    aget-byte v0, v1, v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    throw v0
.end method

.method public readRawBytes(I)[B
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-lez p1, :cond_0

    const/4 v2, 0x2

    or-int/2addr v3, v2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-gt p1, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    add-int/2addr p1, v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v3, 0x6

    invoke-static {v0, v1, p1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-gtz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object p1, Lcom/google/protobuf/Internal;->EMPTY_BYTE_ARRAY:[B

    const/4 v3, 0x5

    return-object p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    throw p1

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    throw p1
.end method

.method public readRawLittleEndian32()I
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    sub-int/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x4

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-lt v1, v2, :cond_0

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v5, 0x3

    add-int/lit8 v2, v0, 0x4

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    aget-byte v2, v1, v0

    const/4 v4, 0x4

    const/4 v5, 0x2

    and-int/lit16 v2, v2, 0xff

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    add-int/lit8 v3, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    aget-byte v3, v1, v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    shl-int/lit8 v3, v3, 0x8

    const/4 v5, 0x0

    or-int/2addr v2, v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v3, v0, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    aget-byte v3, v1, v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    shl-int/lit8 v3, v3, 0x10

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    or-int/2addr v2, v3

    const/4 v5, 0x2

    const/4 v4, 0x3

    add-int/lit8 v0, v0, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x3

    aget-byte v0, v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    and-int/lit16 v0, v0, 0xff

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    shl-int/lit8 v0, v0, 0x18

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    or-int/2addr v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    throw v0
.end method

.method public readRawLittleEndian64()J
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    sub-int/2addr v1, v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/16 v2, 0x8

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-lt v1, v2, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x2

    add-int/lit8 v3, v0, 0x8

    const/4 v10, 0x2

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v10, 0x4

    const/4 v9, 0x4

    aget-byte v3, v1, v0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    int-to-long v3, v3

    const/4 v9, 0x5

    or-int/2addr v10, v9

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v10, 0x3

    const-wide/16 v5, 0xff

    const-wide/16 v5, 0xff

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    and-long/2addr v3, v5

    const/4 v10, 0x7

    add-int/lit8 v7, v0, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    aget-byte v7, v1, v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    int-to-long v7, v7

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    and-long/2addr v7, v5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    shl-long/2addr v7, v2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    or-long v2, v3, v7

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    add-int/lit8 v4, v0, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    aget-byte v4, v1, v4

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    int-to-long v7, v4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    and-long/2addr v7, v5

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/16 v4, 0x10

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    shl-long/2addr v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    or-long/2addr v2, v7

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-int/lit8 v4, v0, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    aget-byte v4, v1, v4

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    int-to-long v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    and-long/2addr v7, v5

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/16 v4, 0x18

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    shl-long/2addr v7, v4

    const/4 v10, 0x7

    const/4 v9, 0x2

    or-long/2addr v2, v7

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    add-int/lit8 v4, v0, 0x4

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    aget-byte v4, v1, v4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    int-to-long v7, v4

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    and-long/2addr v7, v5

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/16 v4, 0x20

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    shl-long/2addr v7, v4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    or-long/2addr v2, v7

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    add-int/lit8 v4, v0, 0x5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    aget-byte v4, v1, v4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    int-to-long v7, v4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    and-long/2addr v7, v5

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/16 v4, 0x28

    const/4 v10, 0x2

    const/4 v9, 0x3

    shl-long/2addr v7, v4

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    or-long/2addr v2, v7

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    add-int/lit8 v4, v0, 0x6

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    aget-byte v4, v1, v4

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    int-to-long v7, v4

    const/4 v10, 0x4

    const/4 v9, 0x6

    and-long/2addr v7, v5

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v4, 0x30

    const/4 v10, 0x1

    const/4 v9, 0x6

    shl-long/2addr v7, v4

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    or-long/2addr v2, v7

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    add-int/lit8 v0, v0, 0x7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    aget-byte v0, v1, v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    int-to-long v0, v0

    const/4 v10, 0x1

    and-long/2addr v0, v5

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/16 v4, 0x38

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    shl-long/2addr v0, v4

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    or-long/2addr v0, v2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    return-wide v0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    throw v0
.end method

.method public readRawVarint32()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-ne v1, v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_0
    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    add-int/lit8 v3, v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    aget-byte v0, v2, v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-ltz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    return v0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    sub-int/2addr v1, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/16 v4, 0x9

    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-ge v1, v4, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x2

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x1

    aget-byte v3, v2, v3

    const/4 v5, 0x2

    move v6, v5

    shl-int/lit8 v3, v3, 0x7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    xor-int/2addr v0, v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-gez v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    xor-int/lit8 v0, v0, -0x80

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    aget-byte v1, v2, v1

    const/4 v5, 0x5

    move v6, v5

    shl-int/lit8 v1, v1, 0xe

    const/4 v6, 0x1

    const/4 v5, 0x0

    xor-int/2addr v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ltz v0, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x3

    xor-int/lit16 v0, v0, 0x3f80

    :cond_4
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v1, v3

    move v1, v3

    const/4 v6, 0x6

    move v1, v3

    move v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto/16 :goto_1

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    aget-byte v3, v2, v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    shl-int/lit8 v3, v3, 0x15

    const/4 v6, 0x6

    xor-int/2addr v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-gez v0, :cond_6

    const v2, -0x1fc080

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    xor-int/2addr v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    goto :goto_1

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    aget-byte v1, v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    shl-int/lit8 v4, v1, 0x1c

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    xor-int/2addr v0, v4

    const/4 v5, 0x0

    and-int/2addr v6, v5

    const v4, 0xfe03f80

    const/4 v5, 0x5

    move v6, v5

    xor-int/2addr v0, v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-gez v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    aget-byte v3, v2, v3

    const/4 v6, 0x6

    if-gez v3, :cond_7

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    aget-byte v1, v2, v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-gez v1, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    aget-byte v3, v2, v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-gez v3, :cond_7

    const/4 v6, 0x5

    add-int/lit8 v3, v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    aget-byte v1, v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    if-gez v1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/lit8 v1, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    aget-byte v2, v2, v3

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-gez v2, :cond_7

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    long-to-int v0, v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    return v0

    :cond_7
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    return v0
.end method

.method public readRawVarint64()J
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    if-ne v1, v0, :cond_0

    const/4 v12, 0x2

    goto/16 :goto_3

    :cond_0
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v11, 0x1

    move v12, v11

    add-int/lit8 v3, v0, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    aget-byte v0, v2, v0

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-ltz v0, :cond_1

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    iput v3, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v11, 0x5

    move v12, v11

    int-to-long v0, v0

    const/4 v12, 0x3

    return-wide v0

    :cond_1
    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    sub-int/2addr v1, v3

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/16 v4, 0x9

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-ge v1, v4, :cond_2

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    goto/16 :goto_3

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x5

    add-int/lit8 v1, v3, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    aget-byte v3, v2, v3

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    shl-int/lit8 v3, v3, 0x7

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    xor-int/2addr v0, v3

    const/4 v12, 0x1

    if-gez v0, :cond_3

    const/4 v12, 0x5

    xor-int/lit8 v0, v0, -0x80

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    int-to-long v2, v0

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x7

    goto/16 :goto_4

    :cond_3
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    add-int/lit8 v3, v1, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x4

    aget-byte v1, v2, v1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    shl-int/lit8 v1, v1, 0xe

    const/4 v12, 0x5

    const/4 v11, 0x2

    xor-int/2addr v0, v1

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-ltz v0, :cond_4

    const/4 v12, 0x7

    const/4 v11, 0x6

    xor-int/lit16 v0, v0, 0x3f80

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    int-to-long v0, v0

    move-wide v9, v0

    const/4 v12, 0x3

    const/4 v11, 0x0

    move v1, v3

    move v1, v3

    const/4 v12, 0x4

    move v1, v3

    move v1, v3

    move-wide v2, v9

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    goto/16 :goto_4

    :cond_4
    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    add-int/lit8 v1, v3, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x3

    aget-byte v3, v2, v3

    const/4 v11, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    shl-int/lit8 v3, v3, 0x15

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    xor-int/2addr v0, v3

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-gez v0, :cond_5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    const v2, -0x1fc080

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    xor-int/2addr v0, v2

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    goto :goto_0

    :cond_5
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    int-to-long v3, v0

    const/4 v12, 0x3

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x7

    aget-byte v1, v2, v1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    int-to-long v5, v1

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/16 v1, 0x1c

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    shl-long/2addr v5, v1

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    xor-long/2addr v3, v5

    const/4 v12, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    cmp-long v1, v3, v5

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    if-ltz v1, :cond_6

    const/4 v11, 0x1

    move v12, v11

    const-wide/32 v1, 0xfe03f80

    const-wide/32 v1, 0xfe03f80

    const/4 v12, 0x4

    const-wide/32 v1, 0xfe03f80

    const-wide/32 v1, 0xfe03f80

    :goto_1
    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    xor-long v2, v3, v1

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    move v1, v0

    move v1, v0

    const/4 v12, 0x2

    move v1, v0

    move v1, v0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    goto/16 :goto_4

    :cond_6
    const/4 v12, 0x2

    const/4 v11, 0x0

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    aget-byte v0, v2, v0

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    int-to-long v7, v0

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    const/16 v0, 0x23

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    shl-long/2addr v7, v0

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    xor-long/2addr v3, v7

    const/4 v11, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    cmp-long v0, v3, v5

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    if-gez v0, :cond_7

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-wide v5, -0x7f01fc080L

    const-wide v5, -0x7f01fc080L

    const/4 v12, 0x4

    const-wide v5, -0x7f01fc080L

    :goto_2
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    xor-long v2, v3, v5

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    goto/16 :goto_4

    :cond_7
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x4

    aget-byte v1, v2, v1

    const/4 v11, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    int-to-long v7, v1

    const/4 v11, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/16 v1, 0x2a

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    shl-long/2addr v7, v1

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    xor-long/2addr v3, v7

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    cmp-long v1, v3, v5

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-ltz v1, :cond_8

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-wide v1, 0x3f80fe03f80L

    const-wide v1, 0x3f80fe03f80L

    const/4 v12, 0x4

    const-wide v1, 0x3f80fe03f80L

    const-wide v1, 0x3f80fe03f80L

    const/4 v11, 0x1

    move v12, v11

    goto/16 :goto_1

    :cond_8
    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x3

    aget-byte v0, v2, v0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    int-to-long v7, v0

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/16 v0, 0x31

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    shl-long/2addr v7, v0

    const/4 v11, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    xor-long/2addr v3, v7

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x3

    cmp-long v0, v3, v5

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-gez v0, :cond_9

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-wide v5, -0x1fc07f01fc080L

    const-wide v5, -0x1fc07f01fc080L

    const/4 v12, 0x1

    const-wide v5, -0x1fc07f01fc080L

    const-wide v5, -0x1fc07f01fc080L

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    goto/16 :goto_2

    :cond_9
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    add-int/lit8 v0, v1, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    aget-byte v1, v2, v1

    const/4 v12, 0x4

    const/4 v11, 0x2

    int-to-long v7, v1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/16 v1, 0x38

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x6

    shl-long/2addr v7, v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    xor-long/2addr v3, v7

    const/4 v12, 0x4

    const-wide v7, 0xfe03f80fe03f80L

    const-wide v7, 0xfe03f80fe03f80L

    const/4 v12, 0x3

    const-wide v7, 0xfe03f80fe03f80L

    const-wide v7, 0xfe03f80fe03f80L

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    xor-long/2addr v3, v7

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    cmp-long v1, v3, v5

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    if-gez v1, :cond_a

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    add-int/lit8 v1, v0, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    aget-byte v0, v2, v0

    const/4 v11, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    int-to-long v7, v0

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    cmp-long v0, v7, v5

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-gez v0, :cond_b

    :goto_3
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    return-wide v0

    :cond_a
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    move v1, v0

    move v1, v0

    :cond_b
    move-wide v2, v3

    :goto_4
    const/4 v12, 0x4

    const/4 v11, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    return-wide v2
.end method

.method readRawVarint64SlowPath()J
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x1

    const-wide/16 v0, 0x0

    const/4 v7, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/16 v3, 0x40

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ge v2, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawByte()B

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    and-int/lit8 v4, v3, 0x7f

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    int-to-long v4, v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    shl-long/2addr v4, v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    or-long/2addr v0, v4

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    and-int/lit16 v3, v3, 0x80

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-nez v3, :cond_0

    const/4 v7, 0x4

    return-wide v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    add-int/lit8 v2, v2, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    throw v0
.end method

.method public readSFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public readSFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-wide v0
.end method

.method public readSInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public readSInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-wide v0
.end method

.method public readString()Ljava/lang/String;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-lez v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    sub-int/2addr v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-gt v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-object v4, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {v1, v3, v2, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    add-int/2addr v2, v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object v1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-nez v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-object v0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-gez v0, :cond_2

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    throw v0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    throw v0
.end method

.method public readStringRequireUtf8()Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-lez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x6

    sub-int/2addr v1, v2

    const/4 v3, 0x4

    move v4, v3

    if-gt v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->buffer:[B

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-static {v1, v2, v0}, Lcom/google/protobuf/Utf8;->decodeUtf8([BII)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    add-int/2addr v2, v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x1

    const-string v0, ""

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-gtz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw v0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    throw v0
.end method

.method public readTag()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->isAtEnd()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->lastTag:I

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->lastTag:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->lastTag:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    throw v0
.end method

.method public readUInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public readUInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-wide v0
.end method

.method public readUnknownGroup(ILcom/google/protobuf/MessageLite$Builder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/protobuf/ExtensionRegistryLite;->getEmptyRegistry()Lcom/google/protobuf/ExtensionRegistryLite;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public resetSizeCounter()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->startPos:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public skipField(I)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "tag"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x6

    if-eq v0, v1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eq v0, v2, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v2, 0x3

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eq v0, v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eq v0, v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 p1, 0x5

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne v0, p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipRawBytes(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    throw p1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    return p1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipMessage()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->checkLastTagWas(I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return v1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawVarint32()I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipRawBytes(I)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v1

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/16 p1, 0x8

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipRawBytes(I)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipRawVarint()V

    const/4 v4, 0x6

    move v5, v4

    return v1
.end method

.method public skipField(ILcom/google/protobuf/CodedOutputStream;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "tag",
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eq v0, v1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eq v0, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x2

    const/4 v5, 0x2

    const/4 v3, 0x4

    const/4 v5, 0x3

    if-eq v0, v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eq v0, v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v2, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ne v0, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeFixed32NoTag(I)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw p1

    :cond_1
    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 p1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    return p1

    :cond_2
    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipMessage(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->checkLastTagWas(I)V

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x4

    return v1

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    return v1

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readRawLittleEndian64()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeFixed64NoTag(J)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v1

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readInt64()J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x1

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeUInt64NoTag(J)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    return v1
.end method

.method public skipMessage()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipField(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public skipMessage(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->skipField(ILcom/google/protobuf/CodedOutputStream;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public skipRawBytes(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ltz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->limit:I

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-gt p1, v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-int/2addr v1, p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput v1, p0, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-gez p1, :cond_1

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    throw p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    throw p1
.end method
