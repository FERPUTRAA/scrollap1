.class synthetic Lcom/google/protobuf/FieldSet$1;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/FieldSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic $SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

.field static final synthetic $SwitchMap$com$google$protobuf$WireFormat$JavaType:[I


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-static {}, Lcom/google/protobuf/WireFormat$FieldType;->values()[Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object v0

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x6

    array-length v0, v0

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x2

    new-array v0, v0, [I

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x1

    sput-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x2

    const/4 v1, 0x1

    :try_start_0
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x4

    sget-object v2, Lcom/google/protobuf/WireFormat$FieldType;->DOUBLE:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x4

    invoke-virtual {v2}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x2

    aput v1, v0, v2
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x3

    const/4 v0, 0x2

    :try_start_1
    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x7

    sget-object v2, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x1

    sget-object v3, Lcom/google/protobuf/WireFormat$FieldType;->FLOAT:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x0

    const/4 v12, 0x4

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x0

    aput v0, v2, v3
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x3

    const/4 v2, 0x3

    :try_start_2
    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x1

    sget-object v3, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x4

    sget-object v4, Lcom/google/protobuf/WireFormat$FieldType;->INT64:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    const/4 v13, 0x2

    const/4 v12, 0x4

    aput v2, v3, v4
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x1

    const/4 v3, 0x4

    :try_start_3
    const/4 v13, 0x4

    sget-object v4, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x2

    sget-object v5, Lcom/google/protobuf/WireFormat$FieldType;->UINT64:Lcom/google/protobuf/WireFormat$FieldType;

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x2

    aput v3, v4, v5
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x4

    const/4 v4, 0x5

    :try_start_4
    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x4

    sget-object v5, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x6

    sget-object v6, Lcom/google/protobuf/WireFormat$FieldType;->INT32:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v12, 0x5

    and-int/2addr v13, v12

    invoke-virtual {v6}, Ljava/lang/Enum;->ordinal()I

    move-result v6

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x3

    aput v4, v5, v6
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x4

    const/4 v5, 0x6

    :try_start_5
    const/4 v12, 0x3

    const/4 v13, 0x7

    sget-object v6, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x3

    sget-object v7, Lcom/google/protobuf/WireFormat$FieldType;->FIXED64:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x3

    aput v5, v6, v7
    :try_end_5
    .catch Ljava/lang/NoSuchFieldError; {:try_start_5 .. :try_end_5} :catch_5

    :catch_5
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v6, 0x7

    move v13, v6

    :try_start_6
    const/4 v12, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x6

    sget-object v7, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x0

    sget-object v8, Lcom/google/protobuf/WireFormat$FieldType;->FIXED32:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v8}, Ljava/lang/Enum;->ordinal()I

    move-result v8

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    aput v6, v7, v8
    :try_end_6
    .catch Ljava/lang/NoSuchFieldError; {:try_start_6 .. :try_end_6} :catch_6

    :catch_6
    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x1

    const/16 v7, 0x8

    :try_start_7
    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x7

    sget-object v8, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    sget-object v9, Lcom/google/protobuf/WireFormat$FieldType;->BOOL:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x6

    aput v7, v8, v9
    :try_end_7
    .catch Ljava/lang/NoSuchFieldError; {:try_start_7 .. :try_end_7} :catch_7

    :catch_7
    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    const/16 v8, 0x9

    :try_start_8
    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x7

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v12, 0x4

    const/4 v13, 0x4

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->GROUP:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v12, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x7

    const/4 v12, 0x1

    aput v8, v9, v10
    :try_end_8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_8 .. :try_end_8} :catch_8

    :catch_8
    :try_start_9
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x4

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->MESSAGE:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x3

    const/16 v11, 0xa

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x7

    aput v11, v9, v10
    :try_end_9
    .catch Ljava/lang/NoSuchFieldError; {:try_start_9 .. :try_end_9} :catch_9

    :catch_9
    :try_start_a
    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x2

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->STRING:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    const/16 v11, 0xb

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x2

    aput v11, v9, v10
    :try_end_a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_a .. :try_end_a} :catch_a

    :catch_a
    :try_start_b
    const/4 v13, 0x3

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x7

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->BYTES:Lcom/google/protobuf/WireFormat$FieldType;

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x6

    const/16 v11, 0xc

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x0

    aput v11, v9, v10
    :try_end_b
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b .. :try_end_b} :catch_b

    :catch_b
    :try_start_c
    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x3

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x0

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->UINT32:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    const/16 v11, 0xd

    const/4 v13, 0x3

    const/4 v12, 0x7

    aput v11, v9, v10
    :try_end_c
    .catch Ljava/lang/NoSuchFieldError; {:try_start_c .. :try_end_c} :catch_c

    :catch_c
    :try_start_d
    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x3

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x7

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED32:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x4

    const/16 v11, 0xe

    const/4 v13, 0x2

    const/4 v12, 0x1

    aput v11, v9, v10
    :try_end_d
    .catch Ljava/lang/NoSuchFieldError; {:try_start_d .. :try_end_d} :catch_d

    :catch_d
    :try_start_e
    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x5

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x0

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->SFIXED64:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v12, 0x4

    move v13, v12

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x1

    const/16 v11, 0xf

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x4

    aput v11, v9, v10
    :try_end_e
    .catch Ljava/lang/NoSuchFieldError; {:try_start_e .. :try_end_e} :catch_e

    :catch_e
    :try_start_f
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x2

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x1

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->SINT32:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x4

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x5

    const/16 v11, 0x10

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x0

    aput v11, v9, v10
    :try_end_f
    .catch Ljava/lang/NoSuchFieldError; {:try_start_f .. :try_end_f} :catch_f

    :catch_f
    :try_start_10
    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x5

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x1

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->SINT64:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x1

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x6

    const/16 v11, 0x11

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x2

    aput v11, v9, v10
    :try_end_10
    .catch Ljava/lang/NoSuchFieldError; {:try_start_10 .. :try_end_10} :catch_10

    :catch_10
    :try_start_11
    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x2

    sget-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x5

    sget-object v10, Lcom/google/protobuf/WireFormat$FieldType;->ENUM:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x4

    const/16 v11, 0x12

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x1

    aput v11, v9, v10
    :try_end_11
    .catch Ljava/lang/NoSuchFieldError; {:try_start_11 .. :try_end_11} :catch_11

    :catch_11
    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-static {}, Lcom/google/protobuf/WireFormat$JavaType;->values()[Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object v9

    const/4 v13, 0x1

    const/4 v12, 0x5

    array-length v9, v9

    const/4 v13, 0x6

    new-array v9, v9, [I

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x4

    sput-object v9, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    :try_start_12
    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x4

    sget-object v10, Lcom/google/protobuf/WireFormat$JavaType;->INT:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x3

    invoke-virtual {v10}, Ljava/lang/Enum;->ordinal()I

    move-result v10

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    aput v1, v9, v10
    :try_end_12
    .catch Ljava/lang/NoSuchFieldError; {:try_start_12 .. :try_end_12} :catch_12

    :catch_12
    :try_start_13
    const/4 v13, 0x2

    const/4 v12, 0x5

    sget-object v1, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v12, 0x5

    const/4 v13, 0x3

    sget-object v9, Lcom/google/protobuf/WireFormat$JavaType;->LONG:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x6

    aput v0, v1, v9
    :try_end_13
    .catch Ljava/lang/NoSuchFieldError; {:try_start_13 .. :try_end_13} :catch_13

    :catch_13
    :try_start_14
    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x6

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->FLOAT:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x3

    aput v2, v0, v1
    :try_end_14
    .catch Ljava/lang/NoSuchFieldError; {:try_start_14 .. :try_end_14} :catch_14

    :catch_14
    :try_start_15
    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x0

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v13, 0x4

    const/4 v12, 0x2

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->DOUBLE:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x6

    aput v3, v0, v1
    :try_end_15
    .catch Ljava/lang/NoSuchFieldError; {:try_start_15 .. :try_end_15} :catch_15

    :catch_15
    :try_start_16
    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x0

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x6

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->BOOLEAN:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x5

    aput v4, v0, v1
    :try_end_16
    .catch Ljava/lang/NoSuchFieldError; {:try_start_16 .. :try_end_16} :catch_16

    :catch_16
    :try_start_17
    const/4 v13, 0x6

    const/4 v12, 0x6

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v12, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x3

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->STRING:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x7

    aput v5, v0, v1
    :try_end_17
    .catch Ljava/lang/NoSuchFieldError; {:try_start_17 .. :try_end_17} :catch_17

    :catch_17
    :try_start_18
    const/4 v12, 0x7

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v13, 0x6

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->BYTE_STRING:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x1

    aput v6, v0, v1
    :try_end_18
    .catch Ljava/lang/NoSuchFieldError; {:try_start_18 .. :try_end_18} :catch_18

    :catch_18
    :try_start_19
    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x4

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v13, 0x2

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->ENUM:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    aput v7, v0, v1
    :try_end_19
    .catch Ljava/lang/NoSuchFieldError; {:try_start_19 .. :try_end_19} :catch_19

    :catch_19
    :try_start_1a
    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x1

    sget-object v0, Lcom/google/protobuf/FieldSet$1;->$SwitchMap$com$google$protobuf$WireFormat$JavaType:[I

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v13, 0x1

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x6

    aput v8, v0, v1
    :try_end_1a
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1a .. :try_end_1a} :catch_1a

    :catch_1a
    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x7

    return-void
.end method
