.class public final enum Lcom/google/protobuf/Extension$ExtensionType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Extension;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401c
    name = "ExtensionType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/Extension$ExtensionType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/Extension$ExtensionType;

.field public static final enum IMMUTABLE:Lcom/google/protobuf/Extension$ExtensionType;

.field public static final enum MUTABLE:Lcom/google/protobuf/Extension$ExtensionType;

.field public static final enum PROTO1:Lcom/google/protobuf/Extension$ExtensionType;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x7

    new-instance v0, Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v1, "MAsMEIUBT"

    const-string v1, "IMMUTABLE"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/Extension$ExtensionType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    sput-object v0, Lcom/google/protobuf/Extension$ExtensionType;->IMMUTABLE:Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-instance v1, Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x0

    const-string v3, "TUMmLsB"

    const-string v3, "MUsLEBT"

    const-string v3, "MAELoUT"

    const-string v3, "MUTABLE"

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x1

    invoke-direct {v1, v3, v4}, Lcom/google/protobuf/Extension$ExtensionType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    sput-object v1, Lcom/google/protobuf/Extension$ExtensionType;->MUTABLE:Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v3, Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string v5, "TOPR1b"

    const-string v5, "PROTO1"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v6, 0x2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v3, v5, v6}, Lcom/google/protobuf/Extension$ExtensionType;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    sput-object v3, Lcom/google/protobuf/Extension$ExtensionType;->PROTO1:Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v5, 0x3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-array v5, v5, [Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    aput-object v0, v5, v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    aput-object v1, v5, v4

    const/4 v7, 0x5

    and-int/2addr v8, v7

    aput-object v3, v5, v6

    const/4 v8, 0x0

    sput-object v5, Lcom/google/protobuf/Extension$ExtensionType;->$VALUES:[Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/Extension$ExtensionType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @~@f@u~@~M@ @ ~/n @d@ ~~@~ol@ @@ @~lf@Kvytbo~u 4  b i~o  cos1@~o~-~~atoi/~i@~@~ mb@~@ @~S~~~r ."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-class v0, Lcom/google/protobuf/Extension$ExtensionType;

    const-class v0, Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v2, 0x1

    const-class v0, Lcom/google/protobuf/Extension$ExtensionType;

    const-class v0, Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/Extension$ExtensionType;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Extension$ExtensionType;->$VALUES:[Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lcom/google/protobuf/Extension$ExtensionType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast v0, [Lcom/google/protobuf/Extension$ExtensionType;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method
