.class public final Lcom/google/protobuf/Descriptors$Descriptor;
.super Lcom/google/protobuf/Descriptors$GenericDescriptor;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Descriptors;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Descriptor"
.end annotation


# instance fields
.field private final containingType:Lcom/google/protobuf/Descriptors$Descriptor;

.field private final enumTypes:[Lcom/google/protobuf/Descriptors$EnumDescriptor;

.field private final extensionRangeLowerBounds:[I

.field private final extensionRangeUpperBounds:[I

.field private final extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

.field private final fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

.field private final fieldsSortedByNumber:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

.field private final file:Lcom/google/protobuf/Descriptors$FileDescriptor;

.field private final fullName:Ljava/lang/String;

.field private final index:I

.field private final nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

.field private final oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

.field private proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

.field private final realOneofCount:I


# direct methods
.method private constructor <init>(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;I)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "proto",
            "file",
            "parent",
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v10, 0x4

    const/4 v0, 0x0

    const/4 v10, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/Descriptors$GenericDescriptor;-><init>(Lcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x5

    iput p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->index:I

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getName()Ljava/lang/String;

    move-result-object p4

    const/4 v10, 0x3

    invoke-static {p2, p3, p4}, Lcom/google/protobuf/Descriptors;->access$2300(Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const/4 v10, 0x4

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fullName:Ljava/lang/String;

    const/4 v10, 0x2

    iput-object p2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$Descriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDeclCount()I

    move-result p3

    const/4 v10, 0x1

    if-lez p3, :cond_0

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDeclCount()I

    move-result p3

    const/4 v10, 0x7

    new-array p3, p3, [Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x1

    goto :goto_0

    :cond_0
    const/4 v10, 0x3

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$2200()[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object p3

    :goto_0
    const/4 v10, 0x1

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x6

    const/4 p3, 0x0

    const/4 v10, 0x1

    move p4, p3

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_1
    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDeclCount()I

    move-result v1

    const/4 v10, 0x7

    if-ge p4, v1, :cond_1

    const/4 v10, 0x7

    iget-object v7, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    new-instance v8, Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x5

    invoke-virtual {p1, p4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDecl(I)Lcom/google/protobuf/DescriptorProtos$OneofDescriptorProto;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v10, 0x1

    move v5, p4

    move v5, p4

    const/4 v10, 0x7

    invoke-direct/range {v1 .. v6}, Lcom/google/protobuf/Descriptors$OneofDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$OneofDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;ILcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x6

    aput-object v8, v7, p4

    const/4 v10, 0x3

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x6

    goto :goto_1

    :cond_1
    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getNestedTypeCount()I

    move-result p4

    const/4 v10, 0x6

    if-lez p4, :cond_2

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getNestedTypeCount()I

    move-result p4

    const/4 v10, 0x2

    new-array p4, p4, [Lcom/google/protobuf/Descriptors$Descriptor;

    goto :goto_2

    :cond_2
    const/4 v10, 0x4

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$400()[Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object p4

    :goto_2
    const/4 v10, 0x2

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v10, 0x0

    move p4, p3

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_3
    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getNestedTypeCount()I

    move-result v1

    const/4 v10, 0x5

    if-ge p4, v1, :cond_3

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v10, 0x1

    new-instance v2, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v10, 0x1

    invoke-virtual {p1, p4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getNestedType(I)Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    move-result-object v3

    const/4 v10, 0x0

    invoke-direct {v2, v3, p2, p0, p4}, Lcom/google/protobuf/Descriptors$Descriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;I)V

    const/4 v10, 0x1

    aput-object v2, v1, p4

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x0

    goto :goto_3

    :cond_3
    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getEnumTypeCount()I

    move-result p4

    const/4 v10, 0x1

    if-lez p4, :cond_4

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getEnumTypeCount()I

    move-result p4

    const/4 v10, 0x4

    new-array p4, p4, [Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v10, 0x5

    goto :goto_4

    :cond_4
    const/4 v10, 0x3

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$600()[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object p4

    :goto_4
    const/4 v10, 0x3

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->enumTypes:[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v10, 0x2

    move p4, p3

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_5
    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getEnumTypeCount()I

    move-result v1

    const/4 v10, 0x1

    if-ge p4, v1, :cond_5

    const/4 v10, 0x4

    iget-object v7, p0, Lcom/google/protobuf/Descriptors$Descriptor;->enumTypes:[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v10, 0x7

    new-instance v8, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v10, 0x5

    invoke-virtual {p1, p4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getEnumType(I)Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v10, 0x2

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    const/4 v10, 0x5

    invoke-direct/range {v1 .. v6}, Lcom/google/protobuf/Descriptors$EnumDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;ILcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x5

    aput-object v8, v7, p4

    const/4 v10, 0x1

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x1

    goto :goto_5

    :cond_5
    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getFieldCount()I

    move-result p4

    const/4 v10, 0x0

    if-lez p4, :cond_6

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getFieldCount()I

    move-result p4

    const/4 v10, 0x7

    new-array p4, p4, [Lcom/google/protobuf/Descriptors$FieldDescriptor;

    goto :goto_6

    :cond_6
    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$1000()[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object p4

    :goto_6
    const/4 v10, 0x7

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x5

    move p4, p3

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_7
    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getFieldCount()I

    move-result v1

    const/4 v10, 0x6

    if-ge p4, v1, :cond_7

    const/4 v10, 0x0

    iget-object v8, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x6

    new-instance v9, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x5

    invoke-virtual {p1, p4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getField(I)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v6, 0x0

    const/4 v10, 0x7

    const/4 v7, 0x0

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v10, 0x4

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    const/4 v10, 0x1

    invoke-direct/range {v1 .. v7}, Lcom/google/protobuf/Descriptors$FieldDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;IZLcom/google/protobuf/Descriptors$1;)V

    aput-object v9, v8, p4

    const/4 v10, 0x6

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x6

    goto :goto_7

    :cond_7
    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getFieldCount()I

    move-result p4

    const/4 v10, 0x3

    if-lez p4, :cond_8

    const/4 v10, 0x4

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    invoke-virtual {p4}, [Lcom/google/protobuf/Descriptors$FieldDescriptor;->clone()Ljava/lang/Object;

    move-result-object p4

    const/4 v10, 0x5

    check-cast p4, [Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x4

    goto :goto_8

    :cond_8
    const/4 v10, 0x0

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$1000()[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object p4

    :goto_8
    const/4 v10, 0x0

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fieldsSortedByNumber:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionCount()I

    move-result p4

    const/4 v10, 0x4

    if-lez p4, :cond_9

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionCount()I

    move-result p4

    const/4 v10, 0x3

    new-array p4, p4, [Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x3

    goto :goto_9

    :cond_9
    const/4 v10, 0x2

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$1000()[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object p4

    :goto_9
    const/4 v10, 0x7

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x2

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_a
    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionCount()I

    move-result v1

    const/4 v10, 0x5

    if-ge p4, v1, :cond_a

    const/4 v10, 0x0

    iget-object v8, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x0

    new-instance v9, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x3

    invoke-virtual {p1, p4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtension(I)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v6, 0x1

    const/4 v10, 0x1

    const/4 v7, 0x0

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v1, v9

    move-object v3, p2

    move-object v3, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v10, 0x1

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    const/4 v10, 0x7

    invoke-direct/range {v1 .. v7}, Lcom/google/protobuf/Descriptors$FieldDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;IZLcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x0

    aput-object v9, v8, p4

    const/4 v10, 0x4

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x3

    goto :goto_a

    :cond_a
    const/4 v10, 0x4

    move p4, p3

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_b
    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDeclCount()I

    move-result v1

    const/4 v10, 0x2

    if-ge p4, v1, :cond_b

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x4

    aget-object v1, v1, p4

    const/4 v10, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->getFieldCount()I

    move-result v2

    const/4 v10, 0x0

    new-array v2, v2, [Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x2

    invoke-static {v1, v2}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->access$2502(Lcom/google/protobuf/Descriptors$OneofDescriptor;[Lcom/google/protobuf/Descriptors$FieldDescriptor;)[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x1

    aget-object v1, v1, p4

    invoke-static {v1, p3}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->access$2602(Lcom/google/protobuf/Descriptors$OneofDescriptor;I)I

    const/4 v10, 0x5

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x5

    goto :goto_b

    :cond_b
    const/4 v10, 0x0

    move p4, p3

    move p4, p3

    move p4, p3

    move p4, p3

    :goto_c
    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getFieldCount()I

    move-result v1

    const/4 v10, 0x0

    if-ge p4, v1, :cond_d

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x6

    aget-object v1, v1, p4

    const/4 v10, 0x2

    invoke-virtual {v1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object v1

    const/4 v10, 0x7

    if-eqz v1, :cond_c

    const/4 v10, 0x3

    invoke-static {v1}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->access$2500(Lcom/google/protobuf/Descriptors$OneofDescriptor;)[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object v2

    const/4 v10, 0x4

    invoke-static {v1}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->access$2608(Lcom/google/protobuf/Descriptors$OneofDescriptor;)I

    move-result v1

    const/4 v10, 0x0

    iget-object v3, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v10, 0x6

    aget-object v3, v3, p4

    const/4 v10, 0x2

    aput-object v3, v2, v1

    :cond_c
    const/4 v10, 0x2

    add-int/lit8 p4, p4, 0x1

    const/4 v10, 0x6

    goto :goto_c

    :cond_d
    const/4 v10, 0x0

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x6

    array-length v1, p4

    const/4 v10, 0x0

    move v2, p3

    move v2, p3

    move v2, p3

    move v2, p3

    const/4 v10, 0x3

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_d
    const/4 v10, 0x5

    if-ge v2, v1, :cond_10

    const/4 v10, 0x6

    aget-object v4, p4, v2

    const/4 v10, 0x6

    invoke-virtual {v4}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->isSynthetic()Z

    move-result v4

    const/4 v10, 0x5

    if-eqz v4, :cond_e

    const/4 v10, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x0

    goto :goto_e

    :cond_e
    const/4 v10, 0x7

    if-gtz v3, :cond_f

    :goto_e
    const/4 v10, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v10, 0x7

    goto :goto_d

    :cond_f
    const/4 v10, 0x5

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v10, 0x2

    const-string/jumbo p2, "sts.eh  cnofo sSm smtuciltynsoet"

    const-string p2, " hst.ts toyeuoSl tneminocf smcse"

    const-string p2, "fucmtemoshecssoemtioyta .lnt S  "

    const-string p2, "Synthetic oneofs must come last."

    const/4 v10, 0x1

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x4

    throw p1

    :cond_10
    const/4 v10, 0x7

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v10, 0x7

    array-length p4, p4

    const/4 v10, 0x4

    sub-int/2addr p4, v3

    const/4 v10, 0x3

    iput p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->realOneofCount:I

    const/4 v10, 0x5

    invoke-static {p2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object p2

    const/4 v10, 0x1

    invoke-virtual {p2, p0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->addSymbol(Lcom/google/protobuf/Descriptors$GenericDescriptor;)V

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionRangeCount()I

    move-result p2

    const/4 v10, 0x4

    if-lez p2, :cond_12

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionRangeCount()I

    move-result p2

    const/4 v10, 0x4

    new-array p2, p2, [I

    iput-object p2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeLowerBounds:[I

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionRangeCount()I

    move-result p2

    const/4 v10, 0x6

    new-array p2, p2, [I

    const/4 v10, 0x5

    iput-object p2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeUpperBounds:[I

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionRangeList()Ljava/util/List;

    move-result-object p1

    const/4 v10, 0x6

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_f
    const/4 v10, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v10, 0x3

    if-eqz p2, :cond_11

    const/4 v10, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v10, 0x1

    check-cast p2, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange;

    const/4 v10, 0x3

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeLowerBounds:[I

    const/4 v10, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange;->getStart()I

    move-result v0

    const/4 v10, 0x4

    aput v0, p4, p3

    const/4 v10, 0x1

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeUpperBounds:[I

    const/4 v10, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange;->getEnd()I

    move-result p2

    const/4 v10, 0x4

    aput p2, p4, p3

    const/4 v10, 0x3

    add-int/lit8 p3, p3, 0x1

    const/4 v10, 0x6

    goto :goto_f

    :cond_11
    iget-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeLowerBounds:[I

    const/4 v10, 0x4

    invoke-static {p1}, Ljava/util/Arrays;->sort([I)V

    const/4 v10, 0x2

    iget-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeUpperBounds:[I

    const/4 v10, 0x3

    invoke-static {p1}, Ljava/util/Arrays;->sort([I)V

    const/4 v10, 0x5

    goto :goto_10

    :cond_12
    const/4 v10, 0x3

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$2800()[I

    move-result-object p1

    const/4 v10, 0x0

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeLowerBounds:[I

    const/4 v10, 0x7

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$2800()[I

    move-result-object p1

    const/4 v10, 0x3

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeUpperBounds:[I

    :goto_10
    const/4 v10, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;ILcom/google/protobuf/Descriptors$1;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/protobuf/Descriptors$Descriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;I)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method constructor <init>(Ljava/lang/String;)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "fullname"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v0, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/Descriptors$GenericDescriptor;-><init>(Lcom/google/protobuf/Descriptors$1;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/16 v1, 0x2e

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/4 v2, -0x1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-eq v1, v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p1, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x0

    const-string v1, ""

    const-string v1, ""

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    iput v3, p0, Lcom/google/protobuf/Descriptors$Descriptor;->index:I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->newBuilder()Lcom/google/protobuf/DescriptorProtos$DescriptorProto$Builder;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v4, v2}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$Builder;->setName(Ljava/lang/String;)Lcom/google/protobuf/DescriptorProtos$DescriptorProto$Builder;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange;->newBuilder()Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange$Builder;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v5, 0x1

    move v8, v5

    invoke-virtual {v4, v5}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange$Builder;->setStart(I)Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange$Builder;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/high16 v6, 0x20000000

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v4, v6}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange$Builder;->setEnd(I)Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange$Builder;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange$Builder;->build()Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v2, v4}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$Builder;->addExtensionRange(Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRange;)Lcom/google/protobuf/DescriptorProtos$DescriptorProto$Builder;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v2}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$Builder;->build()Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    iput-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fullName:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$400()[Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$600()[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->enumTypes:[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$1000()[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$1000()[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fieldsSortedByNumber:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$1000()[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$2200()[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    iput v3, p0, Lcom/google/protobuf/Descriptors$Descriptor;->realOneofCount:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance p1, Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {p1, v1, p0}, Lcom/google/protobuf/Descriptors$FileDescriptor;-><init>(Ljava/lang/String;Lcom/google/protobuf/Descriptors$Descriptor;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    filled-new-array {v5}, [I

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeLowerBounds:[I

    const/4 v8, 0x7

    const/4 v7, 0x4

    filled-new-array {v6}, [I

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeUpperBounds:[I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-void
.end method

.method static synthetic access$1200(Lcom/google/protobuf/Descriptors$Descriptor;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/Descriptors$Descriptor;->crossLink()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$1500(Lcom/google/protobuf/Descriptors$Descriptor;Lcom/google/protobuf/DescriptorProtos$DescriptorProto;)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/Descriptors$Descriptor;->setProto(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method private crossLink()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    array-length v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    move v3, v2

    move v3, v2

    const/4 v6, 0x7

    move v3, v2

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-ge v3, v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    aget-object v4, v0, v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    invoke-direct {v4}, Lcom/google/protobuf/Descriptors$Descriptor;->crossLink()V

    const/4 v6, 0x6

    const/4 v5, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v6, 0x2

    array-length v1, v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    move v3, v2

    move v3, v2

    const/4 v6, 0x7

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-ge v3, v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x0

    aget-object v4, v0, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v4}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->access$1400(Lcom/google/protobuf/Descriptors$FieldDescriptor;)V

    const/4 v6, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fieldsSortedByNumber:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0}, Ljava/util/Arrays;->sort([Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/Descriptors$Descriptor;->validateNoDuplicateFieldNumbers()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v5, 0x5

    const/4 v5, 0x3

    array-length v1, v0

    :goto_2
    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-ge v2, v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    aget-object v3, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v3}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->access$1400(Lcom/google/protobuf/Descriptors$FieldDescriptor;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_2

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void
.end method

.method private setProto(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "proto"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x0

    or-int/2addr v5, v0

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    array-length v3, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ge v1, v3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    aget-object v2, v2, v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, v1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getNestedType(I)Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {v2, v3}, Lcom/google/protobuf/Descriptors$Descriptor;->setProto(Lcom/google/protobuf/DescriptorProtos$DescriptorProto;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    move v1, v0

    move v1, v0

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v5, 0x6

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    array-length v3, v2

    const/4 v5, 0x3

    if-ge v1, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x3

    aget-object v2, v2, v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1, v1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOneofDecl(I)Lcom/google/protobuf/DescriptorProtos$OneofDescriptorProto;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-static {v2, v3}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->access$2900(Lcom/google/protobuf/Descriptors$OneofDescriptor;Lcom/google/protobuf/DescriptorProtos$OneofDescriptorProto;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    move v1, v0

    move v1, v0

    const/4 v5, 0x7

    move v1, v0

    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->enumTypes:[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    array-length v3, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-ge v1, v3, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    aget-object v2, v2, v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, v1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getEnumType(I)Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v2, v3}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->access$1600(Lcom/google/protobuf/Descriptors$EnumDescriptor;Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_2

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    move v1, v0

    move v1, v0

    const/4 v5, 0x6

    move v1, v0

    move v1, v0

    :goto_3
    const/4 v4, 0x6

    move v5, v4

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    array-length v3, v2

    const/4 v5, 0x1

    if-ge v1, v3, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    aget-object v2, v2, v1

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {p1, v1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getField(I)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v2, v3}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->access$1800(Lcom/google/protobuf/Descriptors$FieldDescriptor;Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)V

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    goto :goto_3

    :cond_3
    :goto_4
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    array-length v2, v1

    const/4 v5, 0x0

    if-ge v0, v2, :cond_4

    const/4 v4, 0x3

    and-int/2addr v5, v4

    aget-object v1, v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtension(I)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v2}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->access$1800(Lcom/google/protobuf/Descriptors$FieldDescriptor;Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    goto :goto_4

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method private validateNoDuplicateFieldNumbers()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    add-int/lit8 v1, v0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fieldsSortedByNumber:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    array-length v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-ge v1, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    aget-object v0, v2, v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    aget-object v2, v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v2}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eq v3, v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v4, "eui oemrm lnd"

    const-string v4, "e dmi erlmuFn"

    const/4 v6, 0x6

    const-string/jumbo v4, "ieb  bnFdmeul"

    const-string v4, "Field number "

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v4, "dynsbeu au /ir e s ed/aen oa"

    const-string v4, "d alode sneer /sunba  ayi/e "

    const/4 v6, 0x0

    const-string/jumbo v4, "yebd nepe a/ sa de/ rnuisha "

    const-string v4, " has already been used in \""

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    or-int/2addr v6, v5

    invoke-virtual {v2}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v4}, Lcom/google/protobuf/Descriptors$Descriptor;->getFullName()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo v4, "l  di//yqb// f"

    const-string v4, "i fy/b//dl / e"

    const/4 v6, 0x3

    const-string v4, " es/dl/b/yf  /"

    const-string v4, "\" by field \""

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const-string v0, ".//"

    const-string v0, "//."

    const/4 v6, 0x2

    const-string v0, ".//"

    const-string v0, "\"."

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-direct {v1, v2, v0, v3}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    throw v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method


# virtual methods
.method public findEnumTypeByName(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fullName:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/16 v2, 0x2e

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p1, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v3, 0x3

    move v4, v3

    return-object p1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 p1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object p1
.end method

.method public findFieldByName(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$FieldDescriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fullName:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/16 v2, 0x2e

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    check-cast p1, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object p1
.end method

.method public findFieldByNumber(I)Lcom/google/protobuf/Descriptors$FieldDescriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fieldsSortedByNumber:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x1

    const/4 v3, 0x4

    array-length v1, v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->access$2000()Lcom/google/protobuf/Descriptors$NumberGetter;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/Descriptors;->access$2100([Ljava/lang/Object;ILcom/google/protobuf/Descriptors$NumberGetter;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    check-cast p1, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p1
.end method

.method public findNestedTypeByName(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fullName:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/16 v2, 0x2e

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    check-cast p1, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object p1
.end method

.method public getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public getEnumTypes()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$EnumDescriptor;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->enumTypes:[Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    return-object v0
.end method

.method public getExtensions()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensions:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getFields()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fields:[Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v1, 0x6

    move v2, v1

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-object v0
.end method

.method public getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getFullName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->fullName:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object v0
.end method

.method public getIndex()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->index:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public getName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public getNestedTypes()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$Descriptor;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->nestedTypes:[Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getOneofs()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$OneofDescriptor;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public getOptions()Lcom/google/protobuf/DescriptorProtos$MessageOptions;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$MessageOptions;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getRealOneofs()Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$OneofDescriptor;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->oneofs:[Lcom/google/protobuf/Descriptors$OneofDescriptor;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->realOneofCount:I

    invoke-interface {v0, v1, v2}, Ljava/util/List;->subList(II)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object v0
.end method

.method public isExtendable()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getExtensionRangeList()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public isExtensionNumber(I)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeLowerBounds:[I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0, p1}, Ljava/util/Arrays;->binarySearch([II)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    if-gez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    not-int v0, v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    sub-int/2addr v0, v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ltz v0, :cond_1

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$Descriptor;->extensionRangeUpperBounds:[I

    const/4 v4, 0x1

    aget v0, v2, v0

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    if-ge p1, v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x4

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v4, 0x6

    return v1
.end method

.method public isReservedName(Ljava/lang/String;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getReservedNameList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x3

    xor-int/2addr v2, p1

    const/4 v3, 0x6

    return p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return p1
.end method

.method public isReservedNumber(I)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto;->getReservedRangeList()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    check-cast v1, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ReservedRange;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ReservedRange;->getStart()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-gt v2, p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ReservedRange;->getEnd()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ge p1, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    return p1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    return p1
.end method

.method public toProto()Lcom/google/protobuf/DescriptorProtos$DescriptorProto;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$Descriptor;->proto:Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic toProto()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$Descriptor;->toProto()Lcom/google/protobuf/DescriptorProtos$DescriptorProto;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method
