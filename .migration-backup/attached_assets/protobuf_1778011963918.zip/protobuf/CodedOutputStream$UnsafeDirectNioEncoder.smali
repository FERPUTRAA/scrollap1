.class final Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;
.super Lcom/google/protobuf/CodedOutputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedOutputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "UnsafeDirectNioEncoder"
.end annotation


# instance fields
.field private final address:J

.field private final buffer:Ljava/nio/ByteBuffer;

.field private final initialPosition:J

.field private final limit:J

.field private final oneVarintLimit:J

.field private final originalBuffer:Ljava/nio/ByteBuffer;

.field private position:J


# direct methods
.method constructor <init>(Ljava/nio/ByteBuffer;)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "buffer"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream;-><init>(Lcom/google/protobuf/CodedOutputStream$1;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-object p1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->originalBuffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    sget-object v1, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {p1}, Lcom/google/protobuf/UnsafeUtil;->addressOffset(Ljava/nio/ByteBuffer;)J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->address:J

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/nio/Buffer;->position()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    int-to-long v2, v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    add-long/2addr v2, v0

    const/4 v6, 0x0

    move v7, v6

    iput-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->initialPosition:J

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    int-to-long v4, p1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    add-long/2addr v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-wide/16 v4, 0xa

    const-wide/16 v4, 0xa

    const/4 v7, 0x2

    const-wide/16 v4, 0xa

    const-wide/16 v4, 0xa

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    sub-long/2addr v0, v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    iput-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->oneVarintLimit:J

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    iput-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-void
.end method

.method private bufferPos(J)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pos"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~sb~ f n ~v @@ ~~4@s@~@t~@~~ ir f o@~@tK~~~ bd yo@~.i/- @~l@~o @b@~~l1/a @@c@@Mo@~ ~@oS~i~ @m u"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->address:J

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    sub-long/2addr p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    long-to-int p1, p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    return p1
.end method

.method static isSupported()Z
    .locals 3

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/UnsafeUtil;->hasUnsafeByteBufferOperations()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    return v0
.end method

.method private repositionBuffer(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pos"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->bufferPos(J)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-static {v0, p1}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public flush()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->originalBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {p0, v1, v2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->bufferPos(J)I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0, v1}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x7

    move v4, v3

    return-void
.end method

.method public getTotalBytesWritten()I
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->initialPosition:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    sub-long/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    long-to-int v0, v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v0
.end method

.method public spaceLeft()I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    sub-long/2addr v0, v2

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    long-to-int v0, v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v0
.end method

.method public write(B)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    cmp-long v2, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-gez v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    add-long/2addr v2, v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v1, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance p1, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v0, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    aput-object v1, v0, v2

    const/4 v5, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    aput-object v1, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v1, 0x2

    move v5, v1

    const/4 v4, 0x6

    const/4 v4, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    aput-object v2, v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v1, "ddlmn%   d,ol:t %Pm:i:ies%s"

    const-string v1, "d%ss n :Pltd: o i%:leidm %,"

    const/4 v5, 0x1

    const-string v1, "i,ndol:%:   %P :tledm%do,s "

    const-string v1, "Pos: %d, limit: %d, len: %d"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p1, v0}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    throw p1
.end method

.method public write(Ljava/nio/ByteBuffer;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {p0, v1, v2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->repositionBuffer(J)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1, p1}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v6, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    int-to-long v3, v0

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    add-long/2addr v1, v3

    const/4 v5, 0x7

    move v6, v5

    iput-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J
    :try_end_0
    .catch Ljava/nio/BufferOverflowException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-void

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-direct {v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    throw v0
.end method

.method public write([BII)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x7

    if-eqz p1, :cond_1

    const/4 v11, 0x1

    if-ltz p2, :cond_1

    const/4 v11, 0x4

    if-ltz p3, :cond_1

    const/4 v11, 0x7

    array-length v0, p1

    const/4 v11, 0x0

    sub-int/2addr v0, p3

    const/4 v11, 0x0

    if-lt v0, p2, :cond_1

    const/4 v11, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v11, 0x2

    int-to-long v9, p3

    const/4 v11, 0x7

    sub-long/2addr v0, v9

    const/4 v11, 0x1

    iget-wide v5, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v11, 0x2

    cmp-long v0, v0, v5

    const/4 v11, 0x6

    if-gez v0, :cond_0

    const/4 v11, 0x4

    goto :goto_0

    :cond_0
    const/4 v11, 0x7

    int-to-long v3, p2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-wide v7, v9

    const/4 v11, 0x6

    invoke-static/range {v2 .. v8}, Lcom/google/protobuf/UnsafeUtil;->copyMemory([BJJJ)V

    iget-wide p1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v11, 0x3

    add-long/2addr p1, v9

    const/4 v11, 0x6

    iput-wide p1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v11, 0x4

    return-void

    :cond_1
    :goto_0
    const/4 v11, 0x4

    if-nez p1, :cond_2

    const/4 v11, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v11, 0x7

    const-string p2, "balev"

    const-string/jumbo p2, "lvame"

    const-string/jumbo p2, "lueav"

    const-string/jumbo p2, "value"

    const/4 v11, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    throw p1

    :cond_2
    const/4 v11, 0x2

    new-instance p1, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v11, 0x3

    const/4 p2, 0x3

    const/4 v11, 0x3

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v11, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v1, 0x0

    const/4 v11, 0x6

    aput-object v0, p2, v1

    const/4 v11, 0x7

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v11, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v1, 0x1

    const/4 v11, 0x2

    aput-object v0, p2, v1

    const/4 v11, 0x7

    const/4 v0, 0x2

    const/4 v11, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v11, 0x7

    aput-object p3, p2, v0

    const/4 v11, 0x2

    const-string p3, "%os:odn :%d: i,P %i  dtlml,"

    const-string p3, "P% :%  psdmld,i% onl:,t:edi"

    const-string p3, "Pos: %d, limit: %d, len: %d"

    const/4 v11, 0x1

    invoke-static {p3, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x5

    invoke-direct {p1, p2}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x6

    throw p1
.end method

.method public writeBool(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    int-to-byte p1, p2

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->write(B)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public writeByteArray(I[B)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    array-length v0, p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2, v1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeByteArray(I[BII)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public writeByteArray(I[BII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p3, p4}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeByteArrayNoTag([BII)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public writeByteArrayNoTag([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->write([BII)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public writeByteBuffer(ILjava/nio/ByteBuffer;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p2}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeRawBytes(Ljava/nio/ByteBuffer;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public writeBytes(ILcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public writeBytesNoTag(Lcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, p0}, Lcom/google/protobuf/ByteString;->writeTo(Lcom/google/protobuf/ByteOutput;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public writeFixed32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeFixed32NoTag(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public writeFixed32NoTag(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {p0, v1, v2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->bufferPos(J)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1, p1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-wide/16 v2, 0x4

    const-wide/16 v2, 0x4

    const/4 v5, 0x2

    const-wide/16 v2, 0x4

    const-wide/16 v2, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method public writeFixed64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeFixed64NoTag(J)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public writeFixed64NoTag(J)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, v1, v2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->bufferPos(J)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-wide p1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const-wide/16 v0, 0x8

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    add-long/2addr p1, v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-wide p1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method public writeInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeInt32NoTag(I)V

    const/4 v1, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public writeInt32NoTag(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ltz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    int-to-long v0, p1

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt64NoTag(J)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public writeLazy(Ljava/nio/ByteBuffer;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->write(Ljava/nio/ByteBuffer;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public writeLazy([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->write([BII)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public writeMessage(ILcom/google/protobuf/MessageLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method writeMessage(ILcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p1}, Lcom/google/protobuf/MessageLite;->getSerializedSize()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-interface {p1, p0}, Lcom/google/protobuf/MessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method writeMessageNoTag(Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast v0, Lcom/google/protobuf/AbstractMessageLite;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {v0, p2}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize(Lcom/google/protobuf/Schema;)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream;->wrapper:Lcom/google/protobuf/CodedOutputStreamWriter;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p2, p1, v0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public writeMessageSetExtension(ILcom/google/protobuf/MessageLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0, v2, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32(II)V

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 p1, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method

.method public writeRawBytes(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->write([BII)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p1}, Lcom/google/protobuf/Java8Compatibility;->clear(Ljava/nio/Buffer;)V

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->write(Ljava/nio/ByteBuffer;)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public writeRawMessageSetExtension(ILcom/google/protobuf/ByteString;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v2, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32(II)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeBytes(ILcom/google/protobuf/ByteString;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method public writeString(ILjava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeStringNoTag(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public writeStringNoTag(Ljava/lang/String;)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    mul-int/lit8 v2, v2, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v3}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    if-ne v3, v2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    iget-wide v4, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {p0, v4, v5}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->bufferPos(J)I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    add-int/2addr v2, v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v3, v2}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {p1, v3}, Lcom/google/protobuf/Utf8;->encodeUtf8(Ljava/lang/CharSequence;Ljava/nio/ByteBuffer;)V

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v8, 0x6

    invoke-virtual {v3}, Ljava/nio/Buffer;->position()I

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    sub-int/2addr v3, v2

    const/4 v8, 0x2

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-wide v4, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x1

    int-to-long v2, v3

    const/4 v8, 0x0

    add-long/2addr v4, v2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    iput-wide v4, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x0

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p1}, Lcom/google/protobuf/Utf8;->encodedLength(Ljava/lang/CharSequence;)I

    move-result v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p0, v2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v8, 0x3

    iget-wide v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x6

    const/4 v7, 0x4

    invoke-direct {p0, v3, v4}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->repositionBuffer(J)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {p1, v3}, Lcom/google/protobuf/Utf8;->encodeUtf8(Ljava/lang/CharSequence;Ljava/nio/ByteBuffer;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-wide v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    int-to-long v5, v2

    const/4 v8, 0x6

    add-long/2addr v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    iput-wide v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J
    :try_end_0
    .catch Lcom/google/protobuf/Utf8$UnpairedSurrogateException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x2

    throw v0

    :catch_1
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v8, 0x7

    invoke-direct {v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    throw v0

    :catch_2
    move-exception v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->repositionBuffer(J)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p0, p1, v2}, Lcom/google/protobuf/CodedOutputStream;->inefficientWriteStringNoTag(Ljava/lang/String;Lcom/google/protobuf/Utf8$UnpairedSurrogateException;)V

    :goto_0
    const/4 v7, 0x6

    move v8, v7

    return-void
.end method

.method public writeTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public writeUInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public writeUInt32NoTag(I)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->oneVarintLimit:J

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    cmp-long v0, v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v8, 0x4

    const-wide/16 v1, 0x1

    const-wide/16 v1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-gtz v0, :cond_1

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    and-int/lit8 v0, p1, -0x80

    const/4 v8, 0x1

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-wide v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    add-long/2addr v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    iput-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x2

    const/4 v7, 0x0

    int-to-byte p1, p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v3, v4, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-void

    :cond_0
    const/4 v8, 0x0

    iget-wide v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    add-long v5, v3, v1

    const/4 v8, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    and-int/lit8 v0, p1, 0x7f

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    or-int/lit16 v0, v0, 0x80

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    int-to-byte v0, v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v3, v4, v0}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    ushr-int/lit8 p1, p1, 0x7

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-wide v3, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-wide v5, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    cmp-long v0, v3, v5

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-gez v0, :cond_3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    and-int/lit8 v0, p1, -0x80

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-nez v0, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    add-long/2addr v1, v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    iput-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x2

    int-to-byte p1, p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v3, v4, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    return-void

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    add-long v5, v3, v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    and-int/lit8 v0, p1, 0x7f

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    or-int/lit16 v0, v0, 0x80

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    int-to-byte v0, v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v3, v4, v0}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    ushr-int/lit8 p1, p1, 0x7

    const/4 v8, 0x5

    goto :goto_1

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance p1, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v0, 0x3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    aput-object v1, v0, v2

    const/4 v8, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v8, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    aput-object v1, v0, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v1, 0x2

    const/4 v7, 0x5

    move v8, v7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    aput-object v2, v0, v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string v1, "edlsb%,tq noi :Pd:% l :m,d "

    const-string/jumbo v1, "m:%:tb, ldil   oi% s:dde,nP"

    const-string v1, "dPs%:%id %snt, i, l dl:o em"

    const-string v1, "Pos: %d, limit: %d, len: %d"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {p1, v0}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x1

    throw p1
.end method

.method public writeUInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->writeUInt64NoTag(J)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public writeUInt64NoTag(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x3

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x1

    iget-wide v2, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->oneVarintLimit:J

    const/4 v12, 0x5

    cmp-long v0, v0, v2

    const/4 v12, 0x5

    const/4 v1, 0x7

    const/4 v12, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v12, 0x3

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const/4 v12, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v12, 0x7

    if-gtz v0, :cond_1

    :goto_0
    const/4 v12, 0x0

    and-long v8, p1, v4

    const/4 v12, 0x1

    cmp-long v0, v8, v2

    const/4 v12, 0x6

    if-nez v0, :cond_0

    const/4 v12, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x4

    add-long/2addr v6, v0

    const/4 v12, 0x6

    iput-wide v6, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x5

    long-to-int p1, p1

    const/4 v12, 0x3

    int-to-byte p1, p1

    const/4 v12, 0x4

    invoke-static {v0, v1, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v12, 0x7

    return-void

    :cond_0
    const/4 v12, 0x1

    iget-wide v8, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x5

    add-long v10, v8, v6

    const/4 v12, 0x3

    iput-wide v10, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x7

    long-to-int v0, p1

    const/4 v12, 0x1

    and-int/lit8 v0, v0, 0x7f

    const/4 v12, 0x0

    or-int/lit16 v0, v0, 0x80

    const/4 v12, 0x0

    int-to-byte v0, v0

    invoke-static {v8, v9, v0}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v12, 0x0

    ushr-long/2addr p1, v1

    const/4 v12, 0x0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v12, 0x2

    iget-wide v8, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x2

    iget-wide v10, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    cmp-long v0, v8, v10

    const/4 v12, 0x5

    if-gez v0, :cond_3

    const/4 v12, 0x3

    and-long v10, p1, v4

    const/4 v12, 0x2

    cmp-long v0, v10, v2

    const/4 v12, 0x0

    if-nez v0, :cond_2

    const/4 v12, 0x1

    add-long/2addr v6, v8

    const/4 v12, 0x2

    iput-wide v6, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x1

    long-to-int p1, p1

    const/4 v12, 0x5

    int-to-byte p1, p1

    const/4 v12, 0x2

    invoke-static {v8, v9, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v12, 0x3

    return-void

    :cond_2
    const/4 v12, 0x3

    add-long v10, v8, v6

    const/4 v12, 0x6

    iput-wide v10, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    long-to-int v0, p1

    const/4 v12, 0x0

    and-int/lit8 v0, v0, 0x7f

    const/4 v12, 0x5

    or-int/lit16 v0, v0, 0x80

    const/4 v12, 0x4

    int-to-byte v0, v0

    const/4 v12, 0x6

    invoke-static {v8, v9, v0}, Lcom/google/protobuf/UnsafeUtil;->putByte(JB)V

    const/4 v12, 0x7

    ushr-long/2addr p1, v1

    const/4 v12, 0x3

    goto :goto_1

    :cond_3
    const/4 v12, 0x7

    new-instance p1, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v12, 0x1

    const/4 p2, 0x3

    const/4 v12, 0x7

    new-array p2, p2, [Ljava/lang/Object;

    const/4 v12, 0x1

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->position:J

    const/4 v12, 0x4

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v1, 0x0

    const/4 v12, 0x5

    aput-object v0, p2, v1

    const/4 v12, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedOutputStream$UnsafeDirectNioEncoder;->limit:J

    const/4 v12, 0x7

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v1, 0x1

    const/4 v12, 0x4

    aput-object v0, p2, v1

    const/4 v12, 0x4

    const/4 v0, 0x2

    const/4 v12, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v12, 0x3

    aput-object v1, p2, v0

    const/4 v12, 0x6

    const-string/jumbo v0, "l%mml:td:Psd, inio :% e d, "

    const-string v0, " ids:duol : ,% t:m,l%dP nei"

    const-string/jumbo v0, "l%P o  ,o%id:d, simt%e: :nd"

    const-string v0, "Pos: %d, limit: %d, len: %d"

    const/4 v12, 0x0

    invoke-static {v0, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x6

    invoke-direct {p1, p2}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x2

    throw p1
.end method
