.class public abstract Lcom/google/protobuf/CodedInputStream;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;,
        Lcom/google/protobuf/CodedInputStream$StreamDecoder;,
        Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;,
        Lcom/google/protobuf/CodedInputStream$ArrayDecoder;
    }
.end annotation


# static fields
.field private static final DEFAULT_BUFFER_SIZE:I = 0x1000

.field private static final DEFAULT_SIZE_LIMIT:I = 0x7fffffff

.field private static volatile defaultRecursionLimit:I = 0x64


# instance fields
.field recursionDepth:I

.field recursionLimit:I

.field private shouldDiscardUnknownFields:Z

.field sizeLimit:I

.field wrapper:Lcom/google/protobuf/CodedInputStreamReader;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget v0, Lcom/google/protobuf/CodedInputStream;->defaultRecursionLimit:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionLimit:I

    const/4 v1, 0x7

    move v2, v1

    const v0, 0x7fffffff

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/google/protobuf/CodedInputStream;->shouldDiscardUnknownFields:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/CodedInputStream$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static decodeZigZag32(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "n"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s.K@~@@ 1b si@@  @ @l~@~ ~Md /oci f~ur@ o@~~~~@Sn@ o~@y ~-~a~im/@l~@~b@~ ~ b~@v ~t@@o4otf~ @ o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    ushr-int/lit8 v0, p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    and-int/lit8 p0, p0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    neg-int p0, p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    xor-int/2addr p0, v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method public static decodeZigZag64(J)J
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "n"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    ushr-long v0, p0, v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    and-long/2addr p0, v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    neg-long p0, p0

    xor-long/2addr p0, v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-wide p0
.end method

.method public static newInstance(Ljava/io/InputStream;)Lcom/google/protobuf/CodedInputStream;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "input"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/16 v0, 0x1000

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/io/InputStream;I)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static newInstance(Ljava/io/InputStream;I)Lcom/google/protobuf/CodedInputStream;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "input",
            "bufferSize"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-lez p1, :cond_1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object p0, Lcom/google/protobuf/Internal;->EMPTY_BYTE_ARRAY:[B

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/google/protobuf/CodedInputStream;->newInstance([B)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Lcom/google/protobuf/CodedInputStream$StreamDecoder;

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    move v2, v1

    move v2, v1

    const/4 v3, 0x0

    invoke-direct {v0, p0, p1, v1}, Lcom/google/protobuf/CodedInputStream$StreamDecoder;-><init>(Ljava/io/InputStream;ILcom/google/protobuf/CodedInputStream$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p1, "bu>mm sbtuSesfrei z fe"

    const-string p1, " fsr e>ie Suumbztfs eb"

    const/4 v3, 0x5

    const-string p1, "  f>ob0b rfemsuetuzei "

    const-string p1, "bufferSize must be > 0"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw p0
.end method

.method public static newInstance(Ljava/lang/Iterable;)Lcom/google/protobuf/CodedInputStream;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/nio/ByteBuffer;",
            ">;)",
            "Lcom/google/protobuf/CodedInputStream;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->isSupported()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Lcom/google/protobuf/IterableByteBufferInputStream;

    const/4 v1, 0x0

    move v2, v1

    invoke-direct {v0, p0}, Lcom/google/protobuf/IterableByteBufferInputStream;-><init>(Ljava/lang/Iterable;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/io/InputStream;)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/lang/Iterable;Z)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method static newInstance(Ljava/lang/Iterable;Z)Lcom/google/protobuf/CodedInputStream;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "bufs",
            "bufferIsImmutable"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/nio/ByteBuffer;",
            ">;Z)",
            "Lcom/google/protobuf/CodedInputStream;"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x0

    move v2, v1

    move v2, v1

    const/4 v6, 0x0

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v3, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v3, Ljava/nio/ByteBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/nio/Buffer;->remaining()I

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    add-int/2addr v2, v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    or-int/lit8 v1, v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/nio/ByteBuffer;->isDirect()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    or-int/lit8 v1, v1, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    or-int/lit8 v1, v1, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v0, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-ne v1, v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v0, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v0, p0, v2, p1, v1}, Lcom/google/protobuf/CodedInputStream$IterableDirectByteBufferDecoder;-><init>(Ljava/lang/Iterable;IZLcom/google/protobuf/CodedInputStream$1;)V

    const/4 v6, 0x1

    return-object v0

    :cond_3
    const/4 v6, 0x5

    new-instance p1, Lcom/google/protobuf/IterableByteBufferInputStream;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {p1, p0}, Lcom/google/protobuf/IterableByteBufferInputStream;-><init>(Ljava/lang/Iterable;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/io/InputStream;)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-object p0
.end method

.method public static newInstance(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/CodedInputStream;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "buf"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/google/protobuf/CodedInputStream;->newInstance(Ljava/nio/ByteBuffer;Z)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method static newInstance(Ljava/nio/ByteBuffer;Z)Lcom/google/protobuf/CodedInputStream;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "buf",
            "bufferIsImmutable"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/nio/Buffer;->position()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    add-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/nio/Buffer;->remaining()I

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0, v1, p0, p1}, Lcom/google/protobuf/CodedInputStream;->newInstance([BIIZ)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->isDirect()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->isSupported()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    new-instance v0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, p0, p1, v1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;-><init>(Ljava/nio/ByteBuffer;ZLcom/google/protobuf/CodedInputStream$1;)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v0

    :cond_1
    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/nio/Buffer;->remaining()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-array v0, p1, [B

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x3

    invoke-static {v0, p0, p1, v1}, Lcom/google/protobuf/CodedInputStream;->newInstance([BIIZ)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object p0
.end method

.method public static newInstance([B)Lcom/google/protobuf/CodedInputStream;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "buf"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    array-length v0, p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0, v1, v0}, Lcom/google/protobuf/CodedInputStream;->newInstance([BII)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0
.end method

.method public static newInstance([BII)Lcom/google/protobuf/CodedInputStream;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "buf",
            "off",
            "len"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-static {p0, p1, p2, v0}, Lcom/google/protobuf/CodedInputStream;->newInstance([BIIZ)Lcom/google/protobuf/CodedInputStream;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method static newInstance([BIIZ)Lcom/google/protobuf/CodedInputStream;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "buf",
            "off",
            "len",
            "bufferIsImmutable"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v6, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v5, 0x0

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    move v2, p1

    move v2, p1

    move v2, p1

    const/4 v7, 0x0

    or-int/2addr v8, v7

    move v3, p2

    move v3, p2

    const/4 v8, 0x4

    move v3, p2

    move v3, p2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    move v4, p3

    move v4, p3

    const/4 v8, 0x2

    move v4, p3

    move v4, p3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;-><init>([BIIZLcom/google/protobuf/CodedInputStream$1;)V

    :try_start_0
    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {v6, p2}, Lcom/google/protobuf/CodedInputStream$ArrayDecoder;->pushLimit(I)I
    :try_end_0
    .catch Lcom/google/protobuf/InvalidProtocolBufferException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x4

    return-object v6

    :catch_0
    move-exception p0

    const/4 v7, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    throw p1
.end method

.method public static readRawVarint32(ILjava/io/InputStream;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "firstByte",
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    and-int/lit16 v0, p0, 0x80

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x2

    or-int/2addr v4, v3

    return p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    and-int/lit8 p0, p0, 0x7f

    const/4 v0, 0x5

    move v4, v0

    const/4 v0, 0x4

    const/4 v0, 0x7

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/16 v1, 0x20

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v2, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    if-ge v0, v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq v1, v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    and-int/lit8 v2, v1, 0x7f

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    shl-int/2addr v2, v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    or-int/2addr p0, v2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    and-int/lit16 v1, v1, 0x80

    const/4 v4, 0x1

    const/4 v3, 0x7

    if-nez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    return p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x7

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    throw p0

    :cond_3
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 v1, 0x40

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ge v0, v1, :cond_6

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    if-eq v1, v2, :cond_5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    and-int/lit16 v1, v1, 0x80

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v1, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    return p0

    :cond_4
    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    add-int/lit8 v0, v0, 0x7

    const/4 v3, 0x3

    move v4, v3

    goto :goto_1

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    throw p0

    :cond_6
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    throw p0
.end method

.method static readRawVarint32(Ljava/io/InputStream;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/io/InputStream;->read()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/CodedInputStream;->readRawVarint32(ILjava/io/InputStream;)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return p0

    :cond_0
    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p0
.end method


# virtual methods
.method public abstract checkLastTagWas(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation
.end method

.method public checkRecursionLimit()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionLimit:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ge v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->recursionLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    throw v0
.end method

.method final discardUnknownFields()V
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/protobuf/CodedInputStream;->shouldDiscardUnknownFields:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public abstract enableAliasing(Z)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enabled"
        }
    .end annotation
.end method

.method public abstract getBytesUntilLimit()I
.end method

.method public abstract getLastTag()I
.end method

.method public abstract getTotalBytesRead()I
.end method

.method public abstract isAtEnd()Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract popLimit(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "oldLimit"
        }
    .end annotation
.end method

.method public abstract pushLimit(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "byteLimit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation
.end method

.method public abstract readBool()Z
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readByteArray()[B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readByteBuffer()Ljava/nio/ByteBuffer;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readBytes()Lcom/google/protobuf/ByteString;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readDouble()D
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readEnum()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readFixed32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readFixed64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readFloat()F
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readGroup(ILcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(I",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readInt32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readInt64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readMessage(Lcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readRawByte()B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readRawBytes(I)[B
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readRawLittleEndian32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readRawLittleEndian64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readRawVarint32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readRawVarint64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method abstract readRawVarint64SlowPath()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readSFixed32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readSFixed64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readSInt32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readSInt64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readString()Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readStringRequireUtf8()Ljava/lang/String;
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readTag()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readUInt32()I
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readUInt64()J
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract readUnknownGroup(ILcom/google/protobuf/MessageLite$Builder;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract resetSizeCounter()V
.end method

.method public final setRecursionLimit(I)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "limit"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ltz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionLimit:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionLimit:I

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v2, "antRmb ae cno ermisvn:i ieu bteicglo"

    const-string/jumbo v2, "n lmt tegu Rneociicaintvea ibr :omse"

    const/4 v4, 0x2

    const-string v2, "etetomucnnigcii senelavor Rt  unib :"

    const-string v2, "Recursion limit cannot be negative: "

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    throw v0
.end method

.method public final setSizeLimit(I)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "limit"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-ltz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->sizeLimit:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v2, " onim zpev:cineiStlo eata gb ie"

    const-string v2, "em voc lantiigineb:ett z e Soai"

    const/4 v4, 0x5

    const-string v2, "Stcv :tiqeei blni aao  netnizgm"

    const-string v2, "Size limit cannot be negative: "

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    throw v0
.end method

.method final shouldDiscardUnknownFields()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/CodedInputStream;->shouldDiscardUnknownFields:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public abstract skipField(I)Z
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "tag"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract skipField(ILcom/google/protobuf/CodedOutputStream;)Z
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "tag",
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end method

.method public abstract skipMessage()V
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract skipMessage(Lcom/google/protobuf/CodedOutputStream;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method public abstract skipRawBytes(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "size"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation
.end method

.method final unsetDiscardUnknownFields()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/google/protobuf/CodedInputStream;->shouldDiscardUnknownFields:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method
