.class public final Lcom/google/protobuf/DurationProto;
.super Ljava/lang/Object;


# static fields
.field private static descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

.field static final internal_static_google_protobuf_Duration_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

.field static final internal_static_google_protobuf_Duration_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v0, ".gsr/ea2l for0//gr/pP/uiarPf.1uout2neoo0tme1u/0bsuu0oB0u8ua:0not0p(olw/u0uo0uo0kt/o0000/b/01l1u10o11u0uoou.0tsu1/o.01pbeiiu0Pb0T0ntrsu/10/uo/pro0Dag/u/n2u01ger3/4rg0supeal000cngt0B7/Po0nD0o00uogo//0/0l80K/la0n0/0o100.r0l08/80a1dg.00s/g1wtf50y0o5/f0.g/02Wou0bRn0/211upu0b00/doe3so0p00u.fG8oenyB1ou0r/on0urs0co/0uonarr0u0u8t07e00un00(0du/p/ioof//00uRt/afl0/e/n003/a0un2uo2d00b0usnu3nc6Geungu03o/oeg/0 t1/0t00/0/s5Ztoo/o0u0/n/rnpnu"

    const-string/jumbo v0, "susae0au001o 2i0Bt/0n0rf0/ug01tno00f1ouonugl/d0tpsP000Rp1r0/d0o5gy//...3/210oPnu0nro00ruuonu/1o0oueP///uok0u /0TBupdn0/ns0lslu0(0rZ0a0/10r0f/0g2P2Go//gcao0f.e00///00nuu0100o/0u/a8e/u0tpR0o80Bu000u/70l03o2u0o0rDp1uf0netnu0u1a00fD8y1u.0no/tuaobn0oetuGoouuKo0twor0g8r0b/:ue/0/n.u02piat///ou00W0ufgb0elo.01(5u1o1ro/oe1u03o0/3cr0p0/100w/7acrt6lg00/one4u08mgt/0sod/nonoeu0n/b10/p.t/8o/t10/o02so0bn0uo0s/ibe/i//g5un0uuubap0u300grglsrl/"

    const/4 v5, 0x0

    const-string v0, "0o0meKc/nuP1/ngg/u080o/ou00u(0u500t0orclusou2r030(o2pot1bu100/0o/1ugo/s/a.no01/tg/aeD0sune//uy000P/0ssB 08au/0u/2a/10ul0m/eo/pu011euuo0d0o58r01p1etp/lu3/rlgd0s00roaf0ue/801f7wuZn00o/0/0uf/0n/u21ouogn0r0o0..ouuetg/0f1sg.f0/l0f/n/Gl.u0eb/00/4nn/u0002nb7oo/ua10Tpr208u10wu0/0ru/Wf/dg/e/un.b r/3n/udoD/0tgi0ton060g00/oe/00e8ouuu0120/rkn0Pt0Rao0/0/000spo000gooao00ni5ao0ooR0yrtoo0/1o0p00nBouaP30cl01bup0urrltuu/Bu0ito.tt3.nbunpnrib:G"

    const-string v0, "\n\u001egoogle/protobuf/duration.proto\u0012\u000fgoogle.protobuf\":\n\u0008Duration\u0012\u0018\n\u0007seconds\u0018\u0001 \u0001(\u0003R\u0007seconds\u0012\u0014\n\u0005nanos\u0018\u0002 \u0001(\u0005R\u0005nanosB\u0083\u0001\n\u0013com.google.protobufB\rDurationProtoP\u0001Z1google.golang.org/protobuf/types/known/durationpb\u00f8\u0001\u0001\u00a2\u0002\u0003GPB\u00aa\u0002\u001eGoogle.Protobuf.WellKnownTypesb\u0006proto3"

    const/4 v5, 0x3

    const/4 v4, 0x2

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-array v2, v1, [Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v5, 0x1

    invoke-static {v0, v2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->internalBuildGeneratedFileFrom([Ljava/lang/String;[Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    sput-object v0, Lcom/google/protobuf/DurationProto;->descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {}, Lcom/google/protobuf/DurationProto;->getDescriptor()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getMessageTypes()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v5, 0x4

    const/4 v4, 0x2

    sput-object v0, Lcom/google/protobuf/DurationProto;->internal_static_google_protobuf_Duration_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v1, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v5, 0x1

    const-string/jumbo v2, "ocSmodn"

    const-string/jumbo v2, "ndemSoc"

    const/4 v5, 0x5

    const-string v2, "cdnsobe"

    const-string v2, "Seconds"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v3, "auoNn"

    const-string/jumbo v3, "naNoo"

    const/4 v5, 0x4

    const-string v3, "anpNo"

    const-string v3, "Nanos"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v1, v0, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;-><init>(Lcom/google/protobuf/Descriptors$Descriptor;[Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    sput-object v1, Lcom/google/protobuf/DurationProto;->internal_static_google_protobuf_Duration_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public static getDescriptor()Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@ 4~b~vqioil/@~ @  @i -~us~ @~.t~@om@~fcK~ M~So~ ~n@~@@ a~ @~~yd  o@@~b@  b@t~f@@ 1~or~~l ~o @/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/DurationProto;->descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x6

    return-object v0
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistry;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v0, 0x3

    move v1, v0

    invoke-static {p0}, Lcom/google/protobuf/DurationProto;->registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method
