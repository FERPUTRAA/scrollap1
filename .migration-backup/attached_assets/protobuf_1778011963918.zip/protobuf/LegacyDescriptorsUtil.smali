.class public final Lcom/google/protobuf/LegacyDescriptorsUtil;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyOneofDescriptor;,
        Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFieldDescriptor;,
        Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
