.class final Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;
.super Lcom/google/protobuf/BinaryWriter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/BinaryWriter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "SafeHeapWriter"
.end annotation


# instance fields
.field private allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

.field private buffer:[B

.field private limit:I

.field private limitMinusOne:I

.field private offset:I

.field private offsetMinusOne:I

.field private pos:I


# direct methods
.method constructor <init>(Lcom/google/protobuf/BufferAllocator;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Lcom/google/protobuf/BinaryWriter;-><init>(Lcom/google/protobuf/BufferAllocator;ILcom/google/protobuf/BinaryWriter$1;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method private nextBuffer()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@sliK-oo~~ d@~ur ot@@ ~b l~~ ~/~@@c@ @@o @    asm~@S~4@~f ~o1@/~Mit~~. ~@@@v~b  b~@ ~@ ~~fyo@ni"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->newHeapBuffer()Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method private nextBuffer(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newHeapBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method private nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "allocatedBuffer"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->hasArray()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->finishCurrentBuffer()V

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->array()[B

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->arrayOffset()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->limit()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->limit:I

    const/4 v3, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->position()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/2addr v0, p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offset:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offsetMinusOne:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->limit:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->limitMinusOne:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v0, "rrbmhlfeu frpaaout erneecnA tlsdno"

    const-string/jumbo v0, "orsArld  uennhtltrfeurpofcn aeobea"

    const/4 v3, 0x0

    const-string v0, "Afehopntb ruanol u otocerre-nfaeld"

    const-string v0, "Allocator returned non-heap buffer"

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    throw p1
.end method

.method private writeVarint32FiveBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    ushr-int/lit8 v3, p1, 0x1c

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    int-to-byte v3, v3

    const/4 v5, 0x7

    aput-byte v3, v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    ushr-int/lit8 v3, p1, 0x15

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    aput-byte v3, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    ushr-int/lit8 v3, p1, 0xe

    const/4 v5, 0x6

    const/4 v4, 0x5

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    aput-byte v3, v0, v1

    const/4 v5, 0x4

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    ushr-int/lit8 v3, p1, 0x7

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    aput-byte v3, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    and-int/lit8 p1, p1, 0x7f

    const/4 v5, 0x5

    or-int/lit16 p1, p1, 0x80

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    int-to-byte p1, p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    aput-byte p1, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method private writeVarint32FourBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    ushr-int/lit8 v3, p1, 0x15

    const/4 v4, 0x2

    move v5, v4

    int-to-byte v3, v3

    const/4 v5, 0x2

    const/4 v4, 0x5

    aput-byte v3, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    ushr-int/lit8 v3, p1, 0xe

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x7

    const/4 v4, 0x6

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x2

    int-to-byte v3, v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    aput-byte v3, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    ushr-int/lit8 v3, p1, 0x7

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x0

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    int-to-byte v3, v3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    aput-byte v3, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x4

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    and-int/lit8 p1, p1, 0x7f

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    or-int/lit16 p1, p1, 0x80

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    int-to-byte p1, p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    aput-byte p1, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void
.end method

.method private writeVarint32OneByte(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    add-int/lit8 v2, v1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    int-to-byte p1, p1

    const/4 v3, 0x6

    or-int/2addr v4, v3

    aput-byte p1, v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method private writeVarint32ThreeBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    ushr-int/lit8 v3, p1, 0xe

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    aput-byte v3, v0, v1

    const/4 v5, 0x7

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    ushr-int/lit8 v3, p1, 0x7

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    int-to-byte v3, v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    aput-byte v3, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x6

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x3

    and-int/lit8 p1, p1, 0x7f

    const/4 v5, 0x6

    or-int/lit16 p1, p1, 0x80

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    int-to-byte p1, p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    aput-byte p1, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-void
.end method

.method private writeVarint32TwoBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x1

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    ushr-int/lit8 v3, p1, 0x7

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    int-to-byte v3, v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    aput-byte v3, v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    and-int/lit8 p1, p1, 0x7f

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    or-int/lit16 p1, p1, 0x80

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    int-to-byte p1, p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    aput-byte p1, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void
.end method

.method private writeVarint64EightBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/16 v3, 0x31

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    ushr-long v3, p1, v3

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    long-to-int v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    aput-byte v3, v0, v1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/16 v3, 0x2a

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    ushr-long v3, p1, v3

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x6

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    and-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x1

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    long-to-int v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    aput-byte v3, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    const/16 v3, 0x23

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    ushr-long v3, p1, v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    and-long/2addr v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    or-long/2addr v3, v7

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    long-to-int v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x3

    aput-byte v3, v0, v1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/16 v3, 0x1c

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    ushr-long v3, p1, v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    and-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x7

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    long-to-int v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    int-to-byte v3, v3

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    aput-byte v3, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x5

    const/16 v3, 0x15

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    and-long/2addr v3, v5

    or-long/2addr v3, v7

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    int-to-byte v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    aput-byte v3, v0, v1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/16 v3, 0xe

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    ushr-long v3, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    and-long/2addr v3, v5

    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    or-long/2addr v3, v7

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    int-to-byte v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    aput-byte v3, v0, v2

    const/4 v9, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v3, 0x7

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    and-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    int-to-byte v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    aput-byte v3, v0, v1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    and-long/2addr p1, v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    or-long/2addr p1, v7

    const/4 v10, 0x4

    long-to-int p1, p1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    int-to-byte p1, p1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    aput-byte p1, v0, v2

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    return-void
.end method

.method private writeVarint64FiveBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/16 v3, 0x1c

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    aput-byte v3, v0, v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v3, 0x15

    const/4 v10, 0x1

    const/4 v9, 0x3

    ushr-long v3, p1, v3

    const/4 v10, 0x0

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x2

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    and-long/2addr v3, v5

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x6

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x2

    or-long/2addr v3, v7

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    long-to-int v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    int-to-byte v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    aput-byte v3, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/16 v3, 0xe

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    ushr-long v3, p1, v3

    const/4 v10, 0x2

    const/4 v9, 0x0

    and-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-byte v3, v0, v1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v3, 0x7

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    ushr-long v3, p1, v3

    and-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    int-to-byte v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    aput-byte v3, v0, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    and-long/2addr p1, v5

    const/4 v10, 0x4

    or-long/2addr p1, v7

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    long-to-int p1, p1

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    int-to-byte p1, p1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    aput-byte p1, v0, v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    return-void
.end method

.method private writeVarint64FourBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/16 v3, 0x15

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    ushr-long v3, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    long-to-int v3, v3

    const/4 v9, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    aput-byte v3, v0, v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/16 v3, 0xe

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    and-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    const-wide/16 v7, 0x80

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    or-long/2addr v3, v7

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    long-to-int v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x2

    aput-byte v3, v0, v2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v3, 0x7

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    and-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    or-long/2addr v3, v7

    const/4 v9, 0x2

    move v10, v9

    long-to-int v3, v3

    const/4 v9, 0x7

    move v10, v9

    int-to-byte v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    aput-byte v3, v0, v1

    const/4 v9, 0x5

    move v10, v9

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    and-long/2addr p1, v5

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    or-long/2addr p1, v7

    const/4 v10, 0x5

    long-to-int p1, p1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    int-to-byte p1, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    aput-byte p1, v0, v2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    return-void
.end method

.method private writeVarint64NineBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x0

    const/4 v9, 0x7

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    const/16 v3, 0x38

    const/4 v10, 0x1

    const/4 v9, 0x6

    ushr-long v3, p1, v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    int-to-byte v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    aput-byte v3, v0, v1

    const/4 v10, 0x1

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    const/16 v3, 0x31

    const/4 v10, 0x3

    ushr-long v3, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x7

    const/4 v9, 0x0

    and-long/2addr v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    or-long/2addr v3, v7

    const/4 v10, 0x0

    long-to-int v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    int-to-byte v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    aput-byte v3, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v9, 0x3

    and-int/2addr v10, v9

    const/16 v3, 0x2a

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    ushr-long v3, p1, v3

    const/4 v9, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    and-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    or-long/2addr v3, v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    long-to-int v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    int-to-byte v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    aput-byte v3, v0, v1

    const/4 v10, 0x1

    const/4 v9, 0x5

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/16 v3, 0x23

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x7

    and-long/2addr v3, v5

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    or-long/2addr v3, v7

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    long-to-int v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    int-to-byte v3, v3

    aput-byte v3, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/16 v3, 0x1c

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    and-long/2addr v3, v5

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    or-long/2addr v3, v7

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    long-to-int v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x4

    int-to-byte v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    aput-byte v3, v0, v1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/16 v3, 0x15

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    ushr-long v3, p1, v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    and-long/2addr v3, v5

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    long-to-int v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    int-to-byte v3, v3

    const/4 v9, 0x6

    const/4 v9, 0x5

    aput-byte v3, v0, v2

    const/4 v9, 0x4

    move v10, v9

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/16 v3, 0xe

    const/4 v10, 0x1

    const/4 v9, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    and-long/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    long-to-int v3, v3

    const/4 v9, 0x1

    move v10, v9

    int-to-byte v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    aput-byte v3, v0, v1

    const/4 v10, 0x2

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v3, 0x7

    const/4 v10, 0x2

    const/4 v9, 0x5

    ushr-long v3, p1, v3

    const/4 v9, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    and-long/2addr v3, v5

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    long-to-int v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    aput-byte v3, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x1

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x2

    and-long/2addr p1, v5

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    or-long/2addr p1, v7

    const/4 v10, 0x7

    const/4 v9, 0x6

    long-to-int p1, p1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    int-to-byte p1, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    aput-byte p1, v0, v1

    const/4 v9, 0x1

    move v10, v9

    return-void
.end method

.method private writeVarint64OneByte(J)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    long-to-int p1, p1

    const/4 v4, 0x3

    int-to-byte p1, p1

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput-byte p1, v0, v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-void
.end method

.method private writeVarint64SevenBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v3, 0x2a

    const/4 v10, 0x2

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x5

    long-to-int v3, v3

    const/4 v9, 0x2

    move v10, v9

    int-to-byte v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x0

    aput-byte v3, v0, v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    add-int/lit8 v1, v2, -0x1

    const/4 v9, 0x6

    move v10, v9

    const/16 v3, 0x23

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-wide/16 v5, 0x7f

    const/4 v10, 0x7

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    and-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    or-long/2addr v3, v7

    const/4 v9, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    long-to-int v3, v3

    const/4 v10, 0x7

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    aput-byte v3, v0, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    const/16 v3, 0x1c

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    and-long/2addr v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    or-long/2addr v3, v7

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    long-to-int v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    int-to-byte v3, v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    aput-byte v3, v0, v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v3, 0x15

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    ushr-long v3, p1, v3

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    and-long/2addr v3, v5

    const/4 v10, 0x1

    or-long/2addr v3, v7

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    long-to-int v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    int-to-byte v3, v3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    aput-byte v3, v0, v2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/16 v3, 0xe

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    and-long/2addr v3, v5

    const/4 v10, 0x3

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v9, 0x4

    shr-int/2addr v10, v9

    int-to-byte v3, v3

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    aput-byte v3, v0, v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v3, 0x7

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    ushr-long v3, p1, v3

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    and-long/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    long-to-int v3, v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    aput-byte v3, v0, v2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    add-int/lit8 v2, v1, -0x1

    const/4 v9, 0x7

    move v10, v9

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    and-long/2addr p1, v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    or-long/2addr p1, v7

    long-to-int p1, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    int-to-byte p1, p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    aput-byte p1, v0, v1

    const/4 v9, 0x0

    shr-int/2addr v10, v9

    return-void
.end method

.method private writeVarint64SixBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x6

    const/4 v9, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    add-int/lit8 v2, v1, -0x1

    const/4 v9, 0x3

    move v10, v9

    const/16 v3, 0x23

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    ushr-long v3, p1, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    aput-byte v3, v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/16 v3, 0x1c

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x5

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    and-long/2addr v3, v5

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x0

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x4

    const/4 v9, 0x2

    or-long/2addr v3, v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    int-to-byte v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    aput-byte v3, v0, v2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/16 v3, 0x15

    const/4 v10, 0x3

    ushr-long v3, p1, v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    and-long/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    or-long/2addr v3, v7

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v9, 0x0

    move v10, v9

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    aput-byte v3, v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    add-int/lit8 v1, v2, -0x1

    const/4 v9, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v3, 0xe

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    ushr-long v3, p1, v3

    const/4 v10, 0x7

    and-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    or-long/2addr v3, v7

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    long-to-int v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x4

    int-to-byte v3, v3

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    aput-byte v3, v0, v2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v9, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v3, 0x7

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x2

    and-long/2addr v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    aput-byte v3, v0, v1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    and-long/2addr p1, v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    or-long/2addr p1, v7

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    long-to-int p1, p1

    const/4 v10, 0x3

    int-to-byte p1, p1

    const/4 v9, 0x3

    move v10, v9

    aput-byte p1, v0, v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    return-void
.end method

.method private writeVarint64TenBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x3

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    const/16 v3, 0x3f

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    ushr-long v3, p1, v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    int-to-byte v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    aput-byte v3, v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x5

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/16 v3, 0x38

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    ushr-long v3, p1, v3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    and-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    or-long/2addr v3, v7

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    int-to-byte v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    aput-byte v3, v0, v2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/16 v3, 0x31

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    ushr-long v3, p1, v3

    const/4 v10, 0x0

    and-long/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    or-long/2addr v3, v7

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    long-to-int v3, v3

    const/4 v9, 0x3

    const/4 v10, 0x3

    int-to-byte v3, v3

    const/4 v10, 0x1

    aput-byte v3, v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    add-int/lit8 v1, v2, -0x1

    const/4 v9, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v3, 0x2a

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    and-long/2addr v3, v5

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    or-long/2addr v3, v7

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    long-to-int v3, v3

    const/4 v9, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    aput-byte v3, v0, v2

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/16 v3, 0x23

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    ushr-long v3, p1, v3

    const/4 v9, 0x5

    move v10, v9

    and-long/2addr v3, v5

    const/4 v9, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    or-long/2addr v3, v7

    const/4 v10, 0x3

    const/4 v9, 0x1

    long-to-int v3, v3

    const/4 v9, 0x1

    const/4 v10, 0x2

    int-to-byte v3, v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    aput-byte v3, v0, v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/16 v3, 0x1c

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    ushr-long v3, p1, v3

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    and-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    or-long/2addr v3, v7

    const/4 v9, 0x6

    const/4 v10, 0x3

    long-to-int v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    aput-byte v3, v0, v2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/16 v3, 0x15

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    ushr-long v3, p1, v3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    and-long/2addr v3, v5

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    or-long/2addr v3, v7

    const/4 v9, 0x0

    const/4 v10, 0x6

    long-to-int v3, v3

    const/4 v10, 0x2

    const/4 v9, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    aput-byte v3, v0, v1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/16 v3, 0xe

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    ushr-long v3, p1, v3

    const/4 v9, 0x2

    move v10, v9

    and-long/2addr v3, v5

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    long-to-int v3, v3

    const/4 v10, 0x6

    const/4 v9, 0x1

    int-to-byte v3, v3

    const/4 v10, 0x7

    const/4 v9, 0x7

    aput-byte v3, v0, v2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v3, 0x7

    const/4 v10, 0x6

    ushr-long v3, p1, v3

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    and-long/2addr v3, v5

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    or-long/2addr v3, v7

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    long-to-int v3, v3

    int-to-byte v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    aput-byte v3, v0, v1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    add-int/lit8 v1, v2, -0x1

    const/4 v9, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    and-long/2addr p1, v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    or-long/2addr p1, v7

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    long-to-int p1, p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    int-to-byte p1, p1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    aput-byte p1, v0, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    return-void
.end method

.method private writeVarint64ThreeBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    long-to-int v3, p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    ushr-int/lit8 v3, v3, 0xe

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    int-to-byte v3, v3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    aput-byte v3, v0, v1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    add-int/lit8 v1, v2, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v3, 0x7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    ushr-long v3, p1, v3

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x4

    const-wide/16 v5, 0x7f

    const-wide/16 v5, 0x7f

    const/4 v10, 0x4

    and-long/2addr v3, v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-wide/16 v7, 0x80

    const/4 v10, 0x7

    const-wide/16 v7, 0x80

    const-wide/16 v7, 0x80

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    or-long/2addr v3, v7

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    long-to-int v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x2

    int-to-byte v3, v3

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    aput-byte v3, v0, v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v10, 0x1

    const/4 v9, 0x4

    and-long/2addr p1, v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    or-long/2addr p1, v7

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    long-to-int p1, p1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    int-to-byte p1, p1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    aput-byte p1, v0, v1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-void
.end method

.method private writeVarint64TwoBytes(J)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    add-int/lit8 v2, v1, -0x1

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    ushr-long v3, p1, v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    long-to-int v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    int-to-byte v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    aput-byte v3, v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/lit8 v1, v2, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    long-to-int p1, p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    and-int/lit8 p1, p1, 0x7f

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    or-int/lit16 p1, p1, 0x80

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    int-to-byte p1, p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    aput-byte p1, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method


# virtual methods
.method bytesWrittenToCurrentBuffer()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->limitMinusOne:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method finishCurrentBuffer()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->bytesWrittenToCurrentBuffer()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    add-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/AllocatedBuffer;->arrayOffset()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    sub-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/google/protobuf/AllocatedBuffer;->position(I)Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->limitMinusOne:I

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public getTotalBytesWritten()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->bytesWrittenToCurrentBuffer()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0
.end method

.method requireSpace(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "size"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->spaceLeft()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ge v0, p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer(I)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method spaceLeft()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offsetMinusOne:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0
.end method

.method public write(B)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    add-int/lit8 v2, v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    aput-byte p1, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method public write(Ljava/nio/ByteBuffer;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->spaceLeft()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-ge v1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer(I)V

    :cond_0
    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    sub-int/2addr v1, v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, v2, v1, v0}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method

.method public write([BII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->spaceLeft()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ge v0, p3, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p0, p3}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer(I)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    sub-int/2addr v0, p3

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, p2, v1, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x1

    return-void
.end method

.method public writeBool(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x6

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    int-to-byte p2, p2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->write(B)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method writeBool(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    int-to-byte p1, p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->write(B)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public writeBytes(ILcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p2, p0}, Lcom/google/protobuf/ByteString;->writeToReverse(Lcom/google/protobuf/ByteOutput;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/16 v0, 0xa

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p2}, Lcom/google/protobuf/ByteString;->size()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p2, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x6

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance p2, Ljava/lang/RuntimeException;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    const/4 v1, 0x2

    throw p2
.end method

.method public writeEndGroup(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method writeFixed32(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    shr-int/lit8 v3, p1, 0x18

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    int-to-byte v3, v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    aput-byte v3, v0, v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    shr-int/lit8 v3, p1, 0x10

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    int-to-byte v3, v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    aput-byte v3, v0, v2

    const/4 v5, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    shr-int/lit8 v3, p1, 0x8

    const/4 v5, 0x1

    const/4 v4, 0x1

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    int-to-byte v3, v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    aput-byte v3, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/lit8 v1, v2, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    and-int/lit16 p1, p1, 0xff

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    int-to-byte p1, p1

    const/4 v5, 0x5

    aput-byte p1, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method

.method public writeFixed32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/16 v0, 0x9

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeFixed32(I)V

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p2, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public writeFixed64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0xd

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeFixed64(J)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method writeFixed64(J)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v6, 0x0

    const/16 v3, 0x38

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    shr-long v3, p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    long-to-int v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x0

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    int-to-byte v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    aput-byte v3, v0, v1

    const/4 v5, 0x4

    move v6, v5

    add-int/lit8 v1, v2, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/16 v3, 0x30

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    shr-long v3, p1, v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    long-to-int v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x0

    move v6, v5

    int-to-byte v3, v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    aput-byte v3, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    add-int/lit8 v2, v1, -0x1

    const/4 v6, 0x2

    const/16 v3, 0x28

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    shr-long v3, p1, v3

    const/4 v6, 0x1

    long-to-int v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    int-to-byte v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    aput-byte v3, v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    add-int/lit8 v1, v2, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/16 v3, 0x20

    const/4 v5, 0x5

    move v6, v5

    shr-long v3, p1, v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    long-to-int v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x6

    int-to-byte v3, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    aput-byte v3, v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/16 v3, 0x18

    const/4 v6, 0x0

    shr-long v3, p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    long-to-int v3, v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    int-to-byte v3, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    aput-byte v3, v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    add-int/lit8 v1, v2, -0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/16 v3, 0x10

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    shr-long v3, p1, v3

    const/4 v5, 0x5

    move v6, v5

    long-to-int v3, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x6

    const/4 v6, 0x4

    int-to-byte v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    aput-byte v3, v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-int/lit8 v2, v1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/16 v3, 0x8

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    shr-long v3, p1, v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    long-to-int v3, v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    int-to-byte v3, v3

    const/4 v6, 0x2

    aput-byte v3, v0, v1

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    add-int/lit8 v1, v2, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    long-to-int p1, p1

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    and-int/lit16 p1, p1, 0xff

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    int-to-byte p1, p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    aput-byte p1, v0, v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void
.end method

.method public writeGroup(ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/Protobuf;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p2, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    return-void
.end method

.method public writeGroup(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p3, p2, p0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p2, 0x3

    const/4 v1, 0x5

    and-int/2addr v2, v1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method writeInt32(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ltz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    int-to-long v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64(J)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method public writeInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/16 v0, 0xf

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeInt32(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p2, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x1

    return-void
.end method

.method public writeLazy(Ljava/nio/ByteBuffer;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->spaceLeft()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    if-ge v1, v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    add-int/2addr v1, v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput v1, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/protobuf/AllocatedBuffer;->wrap(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer()V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sub-int/2addr v1, v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1, v2, v1, v0}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public writeLazy([BII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->spaceLeft()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ge v0, p3, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    add-int/2addr v0, p3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1, p2, p3}, Lcom/google/protobuf/AllocatedBuffer;->wrap([BII)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->nextBuffer()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    sub-int/2addr v0, p3

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1, p2, v1, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v2, 0x0

    move v3, v2

    return-void
.end method

.method public writeMessage(ILjava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {v1, p2, p0}, Lcom/google/protobuf/Protobuf;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    sub-int/2addr p2, v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 v0, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 p2, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public writeMessage(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {p3, p2, p0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sub-int/2addr p2, v0

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/16 p3, 0xa

    const/4 v2, 0x0

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p2, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x2

    return-void
.end method

.method writeSInt32(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag32(I)I

    move-result p1

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public writeSInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/16 v0, 0xa

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeSInt32(I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public writeSInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/16 v0, 0xf

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeSInt64(J)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p2, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method writeSInt64(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag64(J)J

    move-result-wide p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64(J)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public writeStartGroup(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public writeString(ILjava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeString(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    sub-int/2addr p2, v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/16 v0, 0xa

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v1, 0x4

    and-int/2addr v2, v1

    const/4 p2, 0x2

    shr-int/2addr v2, p2

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    return-void
.end method

.method writeString(Ljava/lang/String;)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "in"
        }
    .end annotation

    const/4 v9, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    sub-int/2addr v1, v0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/16 v1, 0x80

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-ltz v0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-ge v2, v1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget v3, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    add-int/2addr v3, v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    int-to-byte v2, v2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    aput-byte v2, v1, v3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 v2, -0x1

    const/4 v9, 0x7

    if-ne v0, v2, :cond_1

    const/4 v9, 0x4

    iget p1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v8, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    iput p1, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-void

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget v3, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    add-int/2addr v3, v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    iput v3, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-ltz v0, :cond_8

    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-ge v3, v1, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget v4, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offsetMinusOne:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-le v4, v5, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    add-int/lit8 v6, v4, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    iput v6, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    int-to-byte v3, v3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    aput-byte v3, v5, v4

    const/4 v9, 0x5

    goto/16 :goto_2

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/16 v4, 0x800

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-ge v3, v4, :cond_3

    const/4 v8, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget v4, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offset:I

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-le v4, v5, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/lit8 v6, v4, -0x1

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    and-int/lit8 v7, v3, 0x3f

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    or-int/2addr v7, v1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    int-to-byte v7, v7

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    aput-byte v7, v5, v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    add-int/lit8 v4, v6, -0x1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput v4, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    ushr-int/lit8 v3, v3, 0x6

    const/4 v9, 0x5

    or-int/lit16 v3, v3, 0x3c0

    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    int-to-byte v3, v3

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    aput-byte v3, v5, v6

    const/4 v9, 0x0

    const/4 v8, 0x3

    goto/16 :goto_2

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    const v4, 0xd800

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-lt v3, v4, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    const v4, 0xdfff

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-ge v4, v3, :cond_5

    :cond_4
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget v4, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offset:I

    const/4 v9, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-le v4, v5, :cond_5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    add-int/lit8 v6, v4, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    and-int/lit8 v7, v3, 0x3f

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    or-int/2addr v7, v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    int-to-byte v7, v7

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    aput-byte v7, v5, v4

    const/4 v8, 0x1

    const/4 v8, 0x5

    add-int/lit8 v4, v6, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    ushr-int/lit8 v7, v3, 0x6

    const/4 v8, 0x5

    move v9, v8

    and-int/lit8 v7, v7, 0x3f

    const/4 v9, 0x6

    const/4 v8, 0x4

    or-int/2addr v7, v1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    int-to-byte v7, v7

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    aput-byte v7, v5, v6

    const/4 v8, 0x5

    or-int/2addr v9, v8

    add-int/lit8 v6, v4, -0x1

    const/4 v8, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    iput v6, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    ushr-int/lit8 v3, v3, 0xc

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    or-int/lit16 v3, v3, 0x1e0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    int-to-byte v3, v3

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    aput-byte v3, v5, v4

    const/4 v9, 0x5

    const/4 v8, 0x1

    goto/16 :goto_2

    :cond_5
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget v4, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->offset:I

    const/4 v9, 0x5

    const/4 v8, 0x3

    add-int/lit8 v5, v5, 0x2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-le v4, v5, :cond_7

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v0, :cond_6

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/lit8 v4, v0, -0x1

    invoke-virtual {p1, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-static {v4, v3}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz v5, :cond_6

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v4, v3}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v3

    const/4 v9, 0x4

    iget-object v4, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->buffer:[B

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    add-int/lit8 v6, v5, -0x1

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    and-int/lit8 v7, v3, 0x3f

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    or-int/2addr v7, v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    int-to-byte v7, v7

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    aput-byte v7, v4, v5

    const/4 v9, 0x3

    add-int/lit8 v5, v6, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x1

    ushr-int/lit8 v7, v3, 0x6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    and-int/lit8 v7, v7, 0x3f

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    or-int/2addr v7, v1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    int-to-byte v7, v7

    const/4 v8, 0x6

    const/4 v9, 0x0

    aput-byte v7, v4, v6

    const/4 v8, 0x2

    const/4 v9, 0x2

    add-int/lit8 v6, v5, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    ushr-int/lit8 v7, v3, 0xc

    const/4 v8, 0x7

    const/4 v8, 0x7

    and-int/lit8 v7, v7, 0x3f

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    or-int/2addr v7, v1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    int-to-byte v7, v7

    const/4 v9, 0x2

    aput-byte v7, v4, v5

    const/4 v9, 0x7

    const/4 v8, 0x7

    add-int/lit8 v5, v6, -0x1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    iput v5, p0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->pos:I

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    ushr-int/lit8 v3, v3, 0x12

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    or-int/lit16 v3, v3, 0xf0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    int-to-byte v3, v3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    aput-byte v3, v4, v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    goto :goto_2

    :cond_6
    const/4 v9, 0x0

    new-instance p1, Lcom/google/protobuf/Utf8$UnpairedSurrogateException;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    add-int/lit8 v1, v0, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {p1, v1, v0}, Lcom/google/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    const/4 v9, 0x4

    throw p1

    :cond_7
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    add-int/lit8 v0, v0, 0x1

    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    add-int/2addr v0, v2

    const/4 v8, 0x0

    xor-int/2addr v9, v8

    goto/16 :goto_1

    :cond_8
    const/4 v9, 0x1

    return-void
.end method

.method writeTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public writeUInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/16 v0, 0xa

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p2, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public writeUInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/16 v0, 0xf

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64(J)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method writeVarint32(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    and-int/lit8 v0, p1, -0x80

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32OneByte(I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    and-int/lit16 v0, p1, -0x4000

    const/4 v2, 0x2

    const/4 v1, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32TwoBytes(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/high16 v0, -0x200000

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    and-int/2addr v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32ThreeBytes(I)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/high16 v0, -0x10000000

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    and-int/2addr v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32FourBytes(I)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint32FiveBytes(I)V

    :goto_0
    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method writeVarint64(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, p2}, Lcom/google/protobuf/BinaryWriter;->access$200(J)B

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    packed-switch v0, :pswitch_data_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64TenBytes(J)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64NineBytes(J)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_2
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64EightBytes(J)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_3
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64SevenBytes(J)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :pswitch_4
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64SixBytes(J)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :pswitch_5
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64FiveBytes(J)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :pswitch_6
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64FourBytes(J)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_7
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64ThreeBytes(J)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :pswitch_8
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64TwoBytes(J)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_9
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;->writeVarint64OneByte(J)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
