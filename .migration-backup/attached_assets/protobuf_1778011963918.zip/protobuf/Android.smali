.class final Lcom/google/protobuf/Android;
.super Ljava/lang/Object;


# static fields
.field private static ASSUME_ANDROID:Z

.field private static final IS_ROBOLECTRIC:Z

.field private static final MEMORY_CLASS:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo v0, "r.syocele.oMrbimo"

    const/4 v2, 0x2

    const-string/jumbo v0, "rls.ribeciMoe.omo"

    const-string/jumbo v0, "libcore.io.Memory"

    const/4 v1, 0x0

    move v2, v1

    invoke-static {v0}, Lcom/google/protobuf/Android;->getClassForName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput-object v0, Lcom/google/protobuf/Android;->MEMORY_CLASS:Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-boolean v0, Lcom/google/protobuf/Android;->ASSUME_ANDROID:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, "cgRm.ooirlb.tireoleroocbmtc"

    const-string/jumbo v0, "tlrmri.oioogRbeco.coetcrcbl"

    const/4 v2, 0x6

    const-string/jumbo v0, "tiroorrcltbeo.ccibl.gRooore"

    const-string/jumbo v0, "org.robolectric.Robolectric"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/protobuf/Android;->getClassForName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-boolean v0, Lcom/google/protobuf/Android;->IS_ROBOLECTRIC:Z

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private static getClassForName(Ljava/lang/String;)Ljava/lang/Class;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "name"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation

    :try_start_0
    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-object p0

    :catchall_0
    const/4 v0, 0x3

    move v1, v0

    const/4 p0, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method static getMemoryClass()Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Android;->MEMORY_CLASS:Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method static isOnAndroidDevice()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-boolean v0, Lcom/google/protobuf/Android;->ASSUME_ANDROID:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/Android;->MEMORY_CLASS:Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-boolean v0, Lcom/google/protobuf/Android;->IS_ROBOLECTRIC:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method
