.class public final Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/LegacyDescriptorsUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "LegacyFileDescriptor"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static getSyntax(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "descriptor"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@4s @r~@i~@ i~/@o~c@.n~@ @~ -~~~  @aoM i~~S~~sK  @@ m~tbo~@@/1@l b~ftlo@~ b@ @@uv~@o~d@f~ ~oy~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/LegacyDescriptorsUtil$1;->$SwitchMap$com$google$protobuf$Descriptors$FileDescriptor$Syntax:[I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    aget p0, v0, p0

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    if-eq p0, v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v0, 0x2

    or-int/2addr v2, v0

    const/4 v1, 0x4

    move v2, v1

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-ne p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object p0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->PROTO3:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const-string/jumbo v0, "xUpmdxnestaeseynt"

    const-string/jumbo v0, "ntsUtsaynpxeeedx "

    const/4 v2, 0x7

    const-string/jumbo v0, "nasyo ctxnUetxedp"

    const-string v0, "Unexpected syntax"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    throw p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object p0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x6

    return-object p0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object p0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->UNKNOWN:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method
