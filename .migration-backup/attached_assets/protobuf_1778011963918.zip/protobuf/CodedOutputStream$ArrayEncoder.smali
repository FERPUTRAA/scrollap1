.class Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;
.super Lcom/google/protobuf/CodedOutputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedOutputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "ArrayEncoder"
.end annotation


# instance fields
.field private final buffer:[B

.field private final limit:I

.field private final offset:I

.field private position:I


# direct methods
.method constructor <init>([BII)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "buffer",
            "offset",
            "length"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream;-><init>(Lcom/google/protobuf/CodedOutputStream$1;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz p1, :cond_1

    or-int v0, p2, p3

    const/4 v4, 0x2

    const/4 v3, 0x6

    array-length v1, p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    add-int v2, p2, p3

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    sub-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x6

    or-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ltz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v4, 0x4

    iput p2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->offset:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput p2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v4, 0x7

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x5

    const/4 v1, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    array-length p1, p1

    const/4 v3, 0x5

    or-int/2addr v4, v3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    aput-object p1, v1, v2

    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    aput-object p2, v1, p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    aput-object p2, v1, p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string p1, "f srtidhdBn=ahled=lif ran,%d.tr veo =usfgrn%l.neA% yseaseitfg,"

    const-string p1, ",usdvdAs%ndialfld,fgeBi  ete rey  nr%iarfhtf rn=%ansl.g=h.e=to"

    const/4 v4, 0x5

    const-string/jumbo p1, "rfemdn =h fhdden% n.f vt,erl%nadgegali%ols tA.s ,eyiB=g=airtfu"

    const-string p1, "Array range is invalid. Buffer.length=%d, offset=%d, length=%d"

    const/4 v4, 0x6

    const/4 v3, 0x5

    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    throw v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo p2, "remuob"

    const-string p2, "fubmre"

    const/4 v4, 0x1

    const-string p2, "fufbrb"

    const-string p2, "buffer"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw p1
.end method


# virtual methods
.method public flush()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "l~~ 4 u@b~oyi ib~  @ ~i~@~-M@ @~o@@vf~~@l  f1o~n@s@S Kt  @~@~~do ~@ou~~~@/ @~ ~@~~a /@@.b c@tmr@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public final getTotalBytesWritten()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->offset:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    sub-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public final spaceLeft()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    sub-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method

.method public final write(B)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    aput-byte p1, v0, v1
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    return-void

    :catch_0
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v1, 0x3

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    aput-object v2, v1, v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    aput-object v3, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v2, "l oo:i p:  eP:,,ndtdl %%idm"

    const-string v2, " P  oi%ei %,ndtmd:,%o: ld:l"

    const/4 v5, 0x6

    const-string v2, ":, :n% lql mdsid t:%,idPo %"

    const-string v2, "Pos: %d, limit: %d, len: %d"

    const/4 v5, 0x0

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v1, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    throw v0
.end method

.method public final write(Ljava/nio/ByteBuffer;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1, v1, v2, v0}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    add-int/2addr p1, v0

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x1

    return-void

    :catch_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v1, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x1

    aput-object v3, v2, v4

    const/4 v5, 0x1

    shr-int/2addr v6, v5

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    move v6, v5

    aput-object v3, v2, v4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v3, 0x2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    aput-object v0, v2, v3

    const/4 v5, 0x0

    and-int/2addr v6, v5

    const-string v0, ",es  o%sldli%:Pmid%:nd,t:  "

    const-string v0, "Pos: %d, limit: %d, len: %d"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v1, v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    throw v1
.end method

.method public final write([BII)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v4, 0x4

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/2addr p1, p3

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance p2, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v3, 0x1

    move v4, v3

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    aput-object v1, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    aput-object p3, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string p3, ":%Pm d:i%eol:ns,bdl mdt%  ,"

    const-string/jumbo p3, "n P%dbmd:te:i,: llo ,% %dsi"

    const/4 v4, 0x1

    const-string p3, "%:ePolo% tm,nd:d, s :d%li i"

    const-string p3, "Pos: %d, limit: %d, len: %d"

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p3, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p2, p3, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    throw p2
.end method

.method public final writeBool(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    int-to-byte p1, p2

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->write(B)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public final writeByteArray(I[B)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    array-length v0, p2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p1, p2, v1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeByteArray(I[BII)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public final writeByteArray(I[BII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p2, p3, p4}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeByteArrayNoTag([BII)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public final writeByteArrayNoTag([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p3}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->write([BII)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public final writeByteBuffer(ILjava/nio/ByteBuffer;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p2}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeRawBytes(Ljava/nio/ByteBuffer;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public final writeBytes(ILcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public final writeBytesNoTag(Lcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1, p0}, Lcom/google/protobuf/ByteString;->writeTo(Lcom/google/protobuf/ByteOutput;)V

    const/4 v2, 0x5

    return-void
.end method

.method public final writeFixed32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x5

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeFixed32NoTag(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public final writeFixed32NoTag(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    and-int/lit16 v3, p1, 0xff

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    int-to-byte v3, v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    aput-byte v3, v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    add-int/lit8 v1, v2, 0x1

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    shr-int/lit8 v3, p1, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    int-to-byte v3, v3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    aput-byte v3, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    shr-int/lit8 v3, p1, 0x10

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    and-int/lit16 v3, v3, 0xff

    const/4 v5, 0x7

    int-to-byte v3, v3

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-byte v3, v0, v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    add-int/lit8 v1, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    shr-int/lit8 p1, p1, 0x18

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    and-int/lit16 p1, p1, 0xff

    const/4 v5, 0x2

    int-to-byte p1, p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-byte p1, v0, v2
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :catch_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x0

    aput-object v2, v1, v3

    const/4 v5, 0x3

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    aput-object v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const-string/jumbo v2, "ml% dbi sP::% u% ti: ,dlnod"

    const-string v2, "%, soluliPd md:it   dn,%%::"

    const/4 v5, 0x6

    const-string v2, "d l nmui % %oedsd, t:l,:%P:"

    const-string v2, "Pos: %d, limit: %d, len: %d"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-direct {v0, v1, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    throw v0
.end method

.method public final writeFixed64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x1

    move v2, v1

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeFixed64NoTag(J)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public final writeFixed64NoTag(J)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    long-to-int v3, p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    int-to-byte v3, v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    aput-byte v3, v0, v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    add-int/lit8 v1, v2, 0x1

    const/4 v6, 0x0

    const/16 v3, 0x8

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    shr-long v3, p1, v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    long-to-int v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    int-to-byte v3, v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    aput-byte v3, v0, v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/16 v3, 0x10

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    shr-long v3, p1, v3

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    long-to-int v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    int-to-byte v3, v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    aput-byte v3, v0, v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    add-int/lit8 v1, v2, 0x1

    const/4 v6, 0x5

    const/16 v3, 0x18

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    shr-long v3, p1, v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    long-to-int v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    int-to-byte v3, v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    aput-byte v3, v0, v2

    const/4 v5, 0x2

    shl-int/2addr v6, v5

    add-int/lit8 v2, v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/16 v3, 0x20

    const/4 v6, 0x7

    const/4 v5, 0x7

    shr-long v3, p1, v3

    const/4 v5, 0x3

    move v6, v5

    long-to-int v3, v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    int-to-byte v3, v3

    const/4 v5, 0x4

    move v6, v5

    aput-byte v3, v0, v1

    const/4 v6, 0x4

    add-int/lit8 v1, v2, 0x1

    const/4 v5, 0x4

    move v6, v5

    const/16 v3, 0x28

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    shr-long v3, p1, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    long-to-int v3, v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    int-to-byte v3, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    aput-byte v3, v0, v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/16 v3, 0x30

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    shr-long v3, p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    long-to-int v3, v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x6

    const/4 v5, 0x1

    int-to-byte v3, v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    aput-byte v3, v0, v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    add-int/lit8 v1, v2, 0x1

    const/4 v6, 0x1

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/16 v1, 0x38

    const/4 v5, 0x3

    move v6, v5

    shr-long/2addr p1, v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    long-to-int p1, p1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    and-int/lit16 p1, p1, 0xff

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    int-to-byte p1, p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    aput-byte p1, v0, v2
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void

    :catch_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance p2, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v0, 0x3

    move v6, v0

    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    aput-object v1, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    aput-object v1, v0, v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v1, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    aput-object v2, v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const-string/jumbo v1, "o%i :pspd:td n,Pl%mi % de :"

    const-string v1, ":om %dip:edn%,iP:ls %ltd   "

    const/4 v6, 0x7

    const-string v1, "diot   nq%lPdms%e%:,  id:,l"

    const-string v1, "Pos: %d, limit: %d, len: %d"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {p2, v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    throw p2
.end method

.method public final writeInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeInt32NoTag(I)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public final writeInt32NoTag(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ltz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    int-to-long v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt64NoTag(J)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public final writeLazy(Ljava/nio/ByteBuffer;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->write(Ljava/nio/ByteBuffer;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public final writeLazy([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->write([BII)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public final writeMessage(ILcom/google/protobuf/MessageLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method final writeMessage(ILcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v0, 0x2

    move v2, v0

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p1, Lcom/google/protobuf/AbstractMessageLite;

    const/4 v2, 0x2

    invoke-virtual {p1, p3}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize(Lcom/google/protobuf/Schema;)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/protobuf/CodedOutputStream;->wrapper:Lcom/google/protobuf/CodedOutputStreamWriter;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-interface {p3, p2, p1}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public final writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/google/protobuf/MessageLite;->getSerializedSize()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p1, p0}, Lcom/google/protobuf/MessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method final writeMessageNoTag(Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, Lcom/google/protobuf/AbstractMessageLite;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0, p2}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize(Lcom/google/protobuf/Schema;)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream;->wrapper:Lcom/google/protobuf/CodedOutputStreamWriter;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p2, p1, v0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public final writeMessageSetExtension(ILcom/google/protobuf/MessageLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v0, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    move v4, v2

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, v2, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32(II)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p1, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v4, 0x4

    return-void
.end method

.method public final writeRawBytes(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->write([BII)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/google/protobuf/Java8Compatibility;->clear(Ljava/nio/Buffer;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->write(Ljava/nio/ByteBuffer;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public final writeRawMessageSetExtension(ILcom/google/protobuf/ByteString;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x0

    move v4, v3

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, v2, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32(II)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeBytes(ILcom/google/protobuf/ByteString;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 p1, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public final writeString(ILjava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeStringNoTag(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public final writeStringNoTag(Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    mul-int/lit8 v1, v1, 0x3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ne v2, v1, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    add-int v1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->spaceLeft()I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1, v3, v1, v4}, Lcom/google/protobuf/Utf8;->encode(Ljava/lang/CharSequence;[BII)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    sub-int v3, v1, v0

    const/4 v5, 0x1

    move v6, v5

    sub-int/2addr v3, v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p1}, Lcom/google/protobuf/Utf8;->encodedLength(Ljava/lang/CharSequence;)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v6, 0x6

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->spaceLeft()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1, v1, v2, v3}, Lcom/google/protobuf/Utf8;->encode(Ljava/lang/CharSequence;[BII)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I
    :try_end_0
    .catch Lcom/google/protobuf/Utf8$UnpairedSurrogateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v6, 0x5

    invoke-direct {v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    throw v0

    :catch_1
    move-exception v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {p0, p1, v1}, Lcom/google/protobuf/CodedOutputStream;->inefficientWriteStringNoTag(Ljava/lang/String;Lcom/google/protobuf/Utf8$UnpairedSurrogateException;)V

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-void
.end method

.method public final writeTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public final writeUInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public final writeUInt32NoTag(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    and-int/lit8 v0, p1, -0x80

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v0, :cond_0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    int-to-byte p1, p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    aput-byte p1, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    and-int/lit8 v2, p1, 0x7f

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    or-int/lit16 v2, v2, 0x80

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    int-to-byte v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    aput-byte v2, v0, v1
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    ushr-int/lit8 p1, p1, 0x7

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    aput-object v2, v1, v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    aput-object v2, v1, v3

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v4, 0x5

    move v5, v4

    aput-object v3, v1, v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v2, "Pds % mqio:  , ,::e%dlsd%li"

    const-string/jumbo v2, "o n%m%: q,:dsld:ed  %ii,Pl "

    const/4 v5, 0x2

    const-string v2, ": dmt, mn,el %: P:%io i%sdl"

    const-string v2, "Pos: %d, limit: %d, len: %d"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {v2, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v0, v1, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    throw v0
.end method

.method public final writeUInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->writeUInt64NoTag(J)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public final writeUInt64NoTag(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {}, Lcom/google/protobuf/CodedOutputStream;->access$100()Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v1, 0x7

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const/4 v10, 0x1

    const-wide/16 v4, -0x80

    const-wide/16 v4, -0x80

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-eqz v0, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->spaceLeft()I

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/16 v6, 0xa

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-lt v0, v6, :cond_1

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    and-long v6, p1, v4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    cmp-long v0, v6, v2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-nez v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    add-int/lit8 v2, v1, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    int-to-long v1, v1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    long-to-int p1, p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    int-to-byte p1, p1

    const/4 v10, 0x4

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v9, 0x7

    move v10, v9

    return-void

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget v6, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    add-int/lit8 v7, v6, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput v7, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    int-to-long v6, v6

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    long-to-int v8, p1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    and-int/lit8 v8, v8, 0x7f

    const/4 v10, 0x7

    const/4 v9, 0x6

    or-int/lit16 v8, v8, 0x80

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    int-to-byte v8, v8

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v0, v6, v7, v8}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    ushr-long/2addr p1, v1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    and-long v6, p1, v4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    cmp-long v0, v6, v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-nez v0, :cond_2

    :try_start_0
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v10, 0x1

    const/4 v9, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    add-int/lit8 v2, v1, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    long-to-int p1, p1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    int-to-byte p1, p1

    const/4 v10, 0x5

    aput-byte p1, v0, v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    return-void

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->buffer:[B

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget v6, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    add-int/lit8 v7, v6, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    iput v7, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    long-to-int v7, p1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    and-int/lit8 v7, v7, 0x7f

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    or-int/lit16 v7, v7, 0x80

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    int-to-byte v7, v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-byte v7, v0, v6
    :try_end_0
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    ushr-long/2addr p1, v1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    new-instance p2, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v0, 0x3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v9, 0x1

    shl-int/2addr v10, v9

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->position:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v2, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    aput-object v1, v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$ArrayEncoder;->limit:I

    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v2, 0x1

    move v10, v2

    const/4 v9, 0x7

    const/4 v10, 0x7

    aput-object v1, v0, v2

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    const/4 v1, 0x2

    move v10, v1

    const/4 v9, 0x6

    shl-int/2addr v10, v9

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    aput-object v2, v0, v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-string v1, "d o o,%led%t:::i d Pl s%mn,"

    const-string v1, "Pos: %d, limit: %d, len: %d"

    const/4 v9, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {p2, v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    throw p2
.end method
