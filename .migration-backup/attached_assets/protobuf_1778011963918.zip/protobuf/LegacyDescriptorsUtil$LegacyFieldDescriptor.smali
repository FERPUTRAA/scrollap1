.class public final Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFieldDescriptor;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/LegacyDescriptorsUtil;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "LegacyFieldDescriptor"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static hasOptionalKeyword(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "descriptor"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t s@@~ ~f~4/bs@o ~~ l.d @b~m~  ~ ~@v@y-K~fi/ @~  oi ~r@@ cSo~@@~@@~Mu@ ~no@@1lo@i@~~t~~ oa ~ @~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->hasOptionalKeyword()Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p0
.end method
