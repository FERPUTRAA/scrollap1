.class public final Lcom/google/protobuf/ByteString$Output;
.super Ljava/io/OutputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/ByteString;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Output"
.end annotation


# static fields
.field private static final EMPTY_BYTE_ARRAY:[B


# instance fields
.field private buffer:[B

.field private bufferPos:I

.field private final flushedBuffers:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/google/protobuf/ByteString;",
            ">;"
        }
    .end annotation
.end field

.field private flushedBuffersTotalBytes:I

.field private final initialCapacity:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-array v0, v0, [B

    const/4 v2, 0x1

    sput-object v0, Lcom/google/protobuf/ByteString$Output;->EMPTY_BYTE_ARRAY:[B

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method constructor <init>(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "initialCapacity"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/io/OutputStream;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-ltz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput p1, p0, Lcom/google/protobuf/ByteString$Output;->initialCapacity:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v2, 0x6

    new-array p1, p1, [B

    const/4 v2, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x5

    move v2, v1

    const-string/jumbo v0, "res 0Buezf<iss "

    const-string v0, "e sBr0sf ui <ez"

    const/4 v2, 0x3

    const-string/jumbo v0, "su mfre e Bizf0"

    const-string v0, "Buffer size < 0"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    throw p1
.end method

.method private flushFullBuffer(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "minSize"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @@~os1~~-l  @i/~n ~M@u ~~@o~co@K~f~ ym@. @tl@@@@iobfa~@ot@@rbov  ~/   @b~ ~S i@ ~d@~~~4@~~o~~ @"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v1, v2}, Lcom/google/protobuf/ByteString$LiteralByteString;-><init>([B)V

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffersTotalBytes:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    array-length v1, v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-int/2addr v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffersTotalBytes:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/ByteString$Output;->initialCapacity:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    ushr-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1, v0}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-array p1, p1, [B

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput p1, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v3, 0x0

    and-int/2addr v4, v3

    return-void
.end method

.method private flushLastBuffer()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    iget-object v1, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    array-length v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-ge v0, v2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-lez v0, :cond_1

    const/4 v3, 0x0

    move v4, v3

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v2, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v2, v0}, Lcom/google/protobuf/ByteString$LiteralByteString;-><init>([B)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    new-instance v1, Lcom/google/protobuf/ByteString$LiteralByteString;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1, v2}, Lcom/google/protobuf/ByteString$LiteralByteString;-><init>([B)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v0, Lcom/google/protobuf/ByteString$Output;->EMPTY_BYTE_ARRAY:[B

    const/4 v4, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffersTotalBytes:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v1, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    add-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffersTotalBytes:I

    const/4 v0, 0x0

    move v4, v0

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method


# virtual methods
.method public declared-synchronized reset()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffersTotalBytes:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x6

    const/4 v2, 0x5

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    throw v0
.end method

.method public declared-synchronized size()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffersTotalBytes:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    throw v0
.end method

.method public declared-synchronized toByteString()Lcom/google/protobuf/ByteString;
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    monitor-enter p0

    :try_start_0
    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/ByteString$Output;->flushLastBuffer()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFrom(Ljava/lang/Iterable;)Lcom/google/protobuf/ByteString;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    throw v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    aput-object v1, v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$Output;->size()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    aput-object v1, v0, v2

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v1, "inse@bteszpmit%udO<ByS =t.g%tu"

    const-string v1, "<OBmesuintiytt.uS@ %gzs%=tedp>"

    const/4 v4, 0x5

    const-string v1, "esySituert% @<uusdn>O=zptgBt%i"

    const-string v1, "<ByteString.Output@%s size=%d>"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0
.end method

.method public declared-synchronized write(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "b"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x6

    move v4, v3

    iget v0, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x0

    const/4 v3, 0x7

    array-length v1, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/ByteString$Output;->flushFullBuffer(I)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v1, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput v2, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v3, 0x6

    move v4, v3

    int-to-byte p1, p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    aput-byte p1, v0, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    monitor-exit p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw p1
.end method

.method public declared-synchronized write([BII)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "b",
            "offset",
            "length"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    array-length v1, v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v2, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    sub-int/2addr v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-gt p3, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p1, p2, v0, v2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget p1, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    add-int/2addr p1, p3

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput p1, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v3, 0x6

    move v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    array-length v1, v0

    const/4 v4, 0x4

    sub-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1, p2, v0, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    add-int/2addr p2, v1

    const/4 v4, 0x6

    sub-int/2addr p3, v1

    const/4 v4, 0x0

    invoke-direct {p0, p3}, Lcom/google/protobuf/ByteString$Output;->flushFullBuffer(I)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    and-int/2addr v4, v1

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1, p2, v0, v1, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput p3, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    monitor-exit p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    throw p1
.end method

.method public writeTo(Ljava/io/OutputStream;)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "out"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/protobuf/ByteString$Output;->flushedBuffers:Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-array v2, v1, [Lcom/google/protobuf/ByteString;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    check-cast v0, [Lcom/google/protobuf/ByteString;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/google/protobuf/ByteString$Output;->buffer:[B

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget v3, p0, Lcom/google/protobuf/ByteString$Output;->bufferPos:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    array-length v4, v0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ge v1, v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    aget-object v5, v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v5, p1}, Lcom/google/protobuf/ByteString;->writeTo(Ljava/io/OutputStream;)V

    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {v2, v3}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    throw p1
.end method
