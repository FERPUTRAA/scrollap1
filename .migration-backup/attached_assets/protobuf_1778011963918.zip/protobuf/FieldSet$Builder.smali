.class final Lcom/google/protobuf/FieldSet$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/FieldSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = "Builder"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T::",
        "Lcom/google/protobuf/FieldSet$FieldDescriptorLite<",
        "TT;>;>",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field private fields:Lcom/google/protobuf/SmallSortedMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/SmallSortedMap<",
            "TT;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private hasLazyField:Z

.field private hasNestedBuilders:Z

.field private isMutable:Z


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/16 v0, 0x10

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/SmallSortedMap;->newFieldMap(I)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/FieldSet$Builder;-><init>(Lcom/google/protobuf/SmallSortedMap;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/FieldSet$1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/SmallSortedMap;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fields"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/SmallSortedMap<",
            "TT;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v0, 0x7

    and-int/2addr v1, v0

    const/4 p1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/protobuf/FieldSet$Builder;->isMutable:Z

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method private buildImpl(Z)Lcom/google/protobuf/FieldSet;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "partial"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Lcom/google/protobuf/FieldSet<",
            "TT;>;"
        }
    .end annotation

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Lcom/google/protobuf/FieldSet;->emptySet()Lcom/google/protobuf/FieldSet;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->isMutable:Z

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-boolean v2, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v1, v0}, Lcom/google/protobuf/FieldSet;->access$100(Lcom/google/protobuf/SmallSortedMap;Z)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilders(Lcom/google/protobuf/SmallSortedMap;Z)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance p1, Lcom/google/protobuf/FieldSet;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p1, v1, v0}, Lcom/google/protobuf/FieldSet;-><init>(Lcom/google/protobuf/SmallSortedMap;Lcom/google/protobuf/FieldSet$1;)V

    const/4 v3, 0x5

    move v4, v3

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasLazyField:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/google/protobuf/FieldSet;->access$302(Lcom/google/protobuf/FieldSet;Z)Z

    const/4 v4, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method private ensureIsMutable()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->isMutable:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/google/protobuf/FieldSet;->access$100(Lcom/google/protobuf/SmallSortedMap;Z)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v0

    const/4 v2, 0x3

    or-int/2addr v3, v2

    iput-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-boolean v1, p0, Lcom/google/protobuf/FieldSet$Builder;->isMutable:Z

    :cond_0
    return-void
.end method

.method public static fromFieldSet(Lcom/google/protobuf/FieldSet;)Lcom/google/protobuf/FieldSet$Builder;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldSet"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/FieldSet$FieldDescriptorLite<",
            "TT;>;>(",
            "Lcom/google/protobuf/FieldSet<",
            "TT;>;)",
            "Lcom/google/protobuf/FieldSet$Builder<",
            "TT;>;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Lcom/google/protobuf/FieldSet$Builder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/google/protobuf/FieldSet;->access$400(Lcom/google/protobuf/FieldSet;)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1, v2}, Lcom/google/protobuf/FieldSet;->access$100(Lcom/google/protobuf/SmallSortedMap;Z)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Lcom/google/protobuf/FieldSet$Builder;-><init>(Lcom/google/protobuf/SmallSortedMap;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/google/protobuf/FieldSet;->access$300(Lcom/google/protobuf/FieldSet;)Z

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-boolean p0, v0, Lcom/google/protobuf/FieldSet$Builder;->hasLazyField:Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object v0
.end method

.method private mergeFromField(Ljava/util/Map$Entry;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "entry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map$Entry<",
            "TT;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    instance-of v1, p1, Lcom/google/protobuf/LazyField;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    check-cast p1, Lcom/google/protobuf/LazyField;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/LazyField;->getValue()Lcom/google/protobuf/MessageLite;

    move-result-object p1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0, v0}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast v1, Ljava/util/List;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    iget-object v2, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2, v0, v1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast p1, Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_6

    const/4 v3, 0x2

    move v4, v3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/google/protobuf/FieldSet;->access$700(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    or-int/2addr v4, v3

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object v2, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-ne v1, v2, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez v1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/google/protobuf/FieldSet;->access$700(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, v0, p1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    goto :goto_1

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    instance-of v2, v1, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v4, 0x6

    if-eqz v2, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    check-cast v1, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast p1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v0, v1, p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->internalMergeFrom(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_1

    :cond_4
    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {v1}, Lcom/google/protobuf/MessageLite;->toBuilder()Lcom/google/protobuf/MessageLite$Builder;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0, v1, p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->internalMergeFrom(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/MessageLite$Builder;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p1}, Lcom/google/protobuf/MessageLite$Builder;->build()Lcom/google/protobuf/MessageLite;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v0, p1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_1

    :cond_5
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/google/protobuf/FieldSet;->access$700(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1, v0, p1}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method private static replaceBuilder(Ljava/lang/Object;Z)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "value",
            "partial"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    instance-of v0, p0, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v1, 0x2

    move v2, v1

    check-cast p0, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-interface {p0}, Lcom/google/protobuf/MessageLite$Builder;->buildPartial()Lcom/google/protobuf/MessageLite;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_1
    const/4 v2, 0x0

    invoke-interface {p0}, Lcom/google/protobuf/MessageLite$Builder;->build()Lcom/google/protobuf/MessageLite;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object p0
.end method

.method private static replaceBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Z)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "descriptor",
            "value",
            "partial"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/FieldSet$FieldDescriptorLite<",
            "TT;>;>(TT;",
            "Ljava/lang/Object;",
            "Z)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {p0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ne v0, v1, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p0}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p0, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    instance-of p0, p1, Ljava/util/List;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz p0, :cond_4

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    move-object p0, p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast p0, Ljava/util/List;

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ge v0, v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1, p2}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilder(Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eq v2, v1, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne p0, p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, p0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p0, v0, v2}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p0

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v0, "eys lan tnneucs ostatlisloaon aeye RtL s uale sdipaic:cttu dipbthf"

    const-string/jumbo v0, "nssu e itn clyuaaep sit tio   odttudl lfnLyReacoce:aesst hilptaban"

    const/4 v4, 0x7

    const-string v0, "i ampetun safitdncioupabenoselsdyl:ot y enhl   cctdu i atRetLslaa "

    const-string v0, "Repeated field should contains a List but actually contains type: "

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    throw p0

    :cond_5
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1, p2}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilder(Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object p0

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object p1
.end method

.method private static replaceBuilders(Lcom/google/protobuf/SmallSortedMap;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldMap",
            "partial"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/FieldSet$FieldDescriptorLite<",
            "TT;>;>(",
            "Lcom/google/protobuf/SmallSortedMap<",
            "TT;",
            "Ljava/lang/Object;",
            ">;Z)V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ge v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v1, p1}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilders(Ljava/util/Map$Entry;Z)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilders(Ljava/util/Map$Entry;Z)V

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method private static replaceBuilders(Ljava/util/Map$Entry;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "entry",
            "partial"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/FieldSet$FieldDescriptorLite<",
            "TT;>;>(",
            "Ljava/util/Map$Entry<",
            "TT;",
            "Ljava/lang/Object;",
            ">;Z)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-interface {p0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0, v1, p1}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p0, p1}, Ljava/util/Map$Entry;->setValue(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method private verifyType(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, p2}, Lcom/google/protobuf/FieldSet;->access$500(Lcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/WireFormat$FieldType;->getJavaType()Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget-object v1, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ne v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v5, 0x3

    instance-of v0, p2, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x3

    or-int/2addr v5, v1

    const/4 v4, 0x5

    move v5, v4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getNumber()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    aput-object v2, v1, v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/WireFormat$FieldType;->getJavaType()Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    aput-object p1, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 p2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    aput-object p1, v1, p2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo p1, "iosuoFenec beW me% dstvwogie:j/otatpeiien seplcl,f/etey :re vralm  ltadt hopnnj,mn e%blfe yta oou   dc%gsr.:srp d"

    const-string p1, " Wpm%ota abvpgeg   deebr/d:nvst  ytm%uidneerrlo:o. s:oe/p tnhes,,eei t  ajt lFcfsci llyclt eenfjwoneo%ms idpuraye"

    const/4 v5, 0x0

    const-string p1, " e%embvtju endi%repbdt i n e:o r,  sl .b avteolsfFyn stlt oWgeenhpaependcj tomee aya:lriiod syspof/r:wt%/g ccul,u"

    const-string p1, "Wrong object type used with protocol message reflection.\nField number: %d, field java type: %s, value type: %s\n"

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p1, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw v0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method


# virtual methods
.method public addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;->ensureIsMutable()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    instance-of v0, p2, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v0, 0x1

    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/FieldSet$Builder;->verifyType(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p1, v0}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_2

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v0, Ljava/util/List;

    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void

    :cond_3
    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const-string/jumbo p2, "iecFdpuc .l nelbe d eaaeRoatnadel eeraysdd lonfd(tei lde)"

    const-string p2, "addRepeatedField() can only be called on repeated fields."

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    throw p1
.end method

.method public build()Lcom/google/protobuf/FieldSet;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/FieldSet<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/FieldSet$Builder;->buildImpl(Z)Lcom/google/protobuf/FieldSet;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public buildPartial()Lcom/google/protobuf/FieldSet;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/FieldSet<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/FieldSet$Builder;->buildImpl(Z)Lcom/google/protobuf/FieldSet;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public clearField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;->ensureIsMutable()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/SmallSortedMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/util/AbstractMap;->isEmpty()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 p1, 0x7

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean p1, p0, Lcom/google/protobuf/FieldSet$Builder;->hasLazyField:Z

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public getAllFields()Ljava/util/Map;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "TT;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasLazyField:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/FieldSet;->access$100(Lcom/google/protobuf/SmallSortedMap;Z)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap;->isImmutable()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->makeImmutable()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilders(Lcom/google/protobuf/SmallSortedMap;Z)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v2, 0x4

    move v3, v2

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/SmallSortedMap;->isImmutable()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method

.method public getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    instance-of v0, p1, Lcom/google/protobuf/LazyField;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p1, Lcom/google/protobuf/LazyField;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/LazyField;->getValue()Lcom/google/protobuf/MessageLite;

    move-result-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p1
.end method

.method public getRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;->ensureIsMutable()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/FieldSet$Builder;->getRepeatedFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 p2, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lcom/google/protobuf/FieldSet$Builder;->replaceBuilder(Ljava/lang/Object;Z)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p1
.end method

.method getRepeatedFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;I)Ljava/lang/Object;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I)",
            "Ljava/lang/Object;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    check-cast p1, Ljava/util/List;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {p1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    throw p1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x6

    move v2, v1

    const-string/jumbo p2, "ltes eep i(adRddoa  baecn eelpypoee Fdf aee)rlttin.dnogel"

    const-string p2, " ltposlFilot  n)(aden Rdenlypeeoaef  ddeecrea.tleeaie bdg"

    const-string p2, "edeyF)rlqpldeceioedaagdesoebnc(eildnetalfae    etl p.n t "

    const-string p2, "getRepeatedField() can only be called on repeated fields."

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    throw p1
.end method

.method public getRepeatedFieldCount(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)I"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p1, Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p1

    :cond_1
    const/4 v1, 0x2

    move v2, v1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "nestlabaFed eodea.tgeldlenl ctee r n pol)d epyne(ueRcbfaii oCs"

    const-string/jumbo v0, "oe(lFbrnsed)ulepc.cdlelnyeeboi  dtltifdCgneae e aR  anpted eao"

    const/4 v2, 0x6

    const-string v0, "getRepeatedFieldCount() can only be called on repeated fields."

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw p1
.end method

.method public hasField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)Z"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/google/protobuf/SmallSortedMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string v0, "eelmd-yhe  n cdfcaodella.sdlaptonFeiuanienoel) s  bnr"

    const-string/jumbo v0, "tb)yl ulee npihd dac lseelneaFn-d e. alonr fcoasdeoni"

    const/4 v2, 0x0

    const-string v0, "hasField() can only be called on non-repeated fields."

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p1
.end method

.method public isInitialized()Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    move v1, v0

    move v1, v0

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x4

    iget-object v2, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v2}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ge v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v2, v1}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v2}, Lcom/google/protobuf/FieldSet;->access$600(Ljava/util/Map$Entry;)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v2}, Lcom/google/protobuf/FieldSet;->access$600(Ljava/util/Map$Entry;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v2, :cond_2

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    return v0

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return v0
.end method

.method public mergeFrom(Lcom/google/protobuf/FieldSet;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "other"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/FieldSet<",
            "TT;>;)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;->ensureIsMutable()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/protobuf/FieldSet;->access$400(Lcom/google/protobuf/FieldSet;)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/SmallSortedMap;->getNumArrayEntries()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ge v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/protobuf/FieldSet;->access$400(Lcom/google/protobuf/FieldSet;)Lcom/google/protobuf/SmallSortedMap;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Lcom/google/protobuf/SmallSortedMap;->getArrayEntryAt(I)Ljava/util/Map$Entry;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p0, v1}, Lcom/google/protobuf/FieldSet$Builder;->mergeFromField(Ljava/util/Map$Entry;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/protobuf/FieldSet;->access$400(Lcom/google/protobuf/FieldSet;)Lcom/google/protobuf/SmallSortedMap;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/SmallSortedMap;->getOverflowEntries()Ljava/lang/Iterable;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/FieldSet$Builder;->mergeFromField(Ljava/util/Map$Entry;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "descriptor",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;->ensureIsMutable()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x7

    shr-int/2addr v6, v5

    if-eqz v0, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    instance-of v0, p2, Ljava/util/List;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast p2, Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v0, p2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v3, :cond_2

    const/4 v5, 0x5

    move v6, v5

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p0, p1, v3}, Lcom/google/protobuf/FieldSet$Builder;->verifyType(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-boolean v4, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v4, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    instance-of v3, v3, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    move v3, v1

    move v3, v1

    const/4 v6, 0x2

    move v3, v1

    move v3, v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_2

    :cond_1
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    move v3, v2

    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-boolean v3, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v6, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    move-object p2, v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_3

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string p2, "feuto  em plg oytretgota Wsidlccrebjpo. pecoti oonwsrese"

    const-string/jumbo p2, "oio eecp sphenlsdw  fttoseetje yr baeo crrcgmtptouW.goil"

    const/4 v6, 0x1

    const-string p2, "cmynubpoogi eleotrswc  rlpWejta otrscb o s gofn.eittdehe"

    const-string p2, "Wrong object type used with protocol message reflection."

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    throw p1

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/FieldSet$Builder;->verifyType(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    :goto_3
    const/4 v5, 0x1

    move v6, v5

    instance-of v0, p2, Lcom/google/protobuf/LazyField;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v0, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-boolean v2, p0, Lcom/google/protobuf/FieldSet$Builder;->hasLazyField:Z

    :cond_5
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v0, :cond_6

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    instance-of v0, p2, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v6, 0x2

    if-eqz v0, :cond_7

    :cond_6
    const/4 v5, 0x3

    move v6, v5

    move v1, v2

    move v1, v2

    const/4 v6, 0x6

    move v1, v2

    move v1, v2

    :cond_7
    const/4 v6, 0x5

    const/4 v5, 0x7

    iput-boolean v1, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/protobuf/FieldSet$Builder;->fields:Lcom/google/protobuf/SmallSortedMap;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/SmallSortedMap;->put(Ljava/lang/Comparable;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method public setRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "index",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;I",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/FieldSet$Builder;->ensureIsMutable()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {p1}, Lcom/google/protobuf/FieldSet$FieldDescriptorLite;->isRepeated()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    instance-of v0, p3, Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/google/protobuf/FieldSet$Builder;->hasNestedBuilders:Z

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/FieldSet$Builder;->getFieldAllowBuilders(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0, p1, p3}, Lcom/google/protobuf/FieldSet$Builder;->verifyType(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    check-cast v0, Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0, p2, p3}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    throw p1

    :cond_3
    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo p2, "oes eiu(Rpdfl  e npdnFeo .e)ltnl edaegdiecd ttaeyeabealqc"

    const-string p2, " b(elgeaqeocade dc)andtlde eoFpnsdfiyte .ne eeieltla Rlp "

    const/4 v2, 0x3

    const-string/jumbo p2, "p gib(ipl)aFesoateedleder deedc na elcp nee lfttneoylad.R"

    const-string p2, "getRepeatedField() can only be called on repeated fields."

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw p1
.end method
