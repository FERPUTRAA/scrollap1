.class final Lcom/google/protobuf/ByteString$BoundedByteString;
.super Lcom/google/protobuf/ByteString$LiteralByteString;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/ByteString;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "BoundedByteString"
.end annotation


# static fields
.field private static final serialVersionUID:J = 0x1L


# instance fields
.field private final bytesLength:I

.field private final bytesOffset:I


# direct methods
.method constructor <init>([BII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "bytes",
            "offset",
            "length"
        }
    .end annotation

    invoke-direct {p0, p1}, Lcom/google/protobuf/ByteString$LiteralByteString;-><init>([B)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    add-int v0, p2, p3

    const/4 v2, 0x0

    const/4 v1, 0x0

    array-length p1, p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p2, v0, p1}, Lcom/google/protobuf/ByteString;->checkRange(III)I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput p2, p0, Lcom/google/protobuf/ByteString$BoundedByteString;->bytesOffset:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput p3, p0, Lcom/google/protobuf/ByteString$BoundedByteString;->bytesLength:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "in"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance p1, Ljava/io/InvalidObjectException;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string/jumbo v0, "uesesecealt mrtbo nienlyt  erastaon rtdsntcdisrdBd eiiBy Seea"

    const-string/jumbo v0, "iosalSadltciebnd idateorrueeryocen ye nt etr eiadt ms sBeBstn"

    const/4 v2, 0x5

    const-string/jumbo v0, "zsnms tancmrloeeBd rdeu ntd iaoic edotyrtyreeiB e nlasietbaet"

    const-string v0, "BoundedByteStream instances are not to be serialized directly"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    throw p1
.end method


# virtual methods
.method public byteAt(I)B
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$BoundedByteString;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/protobuf/ByteString;->checkIndex(II)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/protobuf/ByteString$BoundedByteString;->bytesOffset:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    add-int/2addr v1, p1

    const/4 v3, 0x2

    aget-byte p1, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return p1
.end method

.method protected copyToInternal([BIII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "target",
            "sourceOffset",
            "targetOffset",
            "numberToCopy"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString$BoundedByteString;->getOffsetIntoBytes()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/2addr v1, p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, v1, p1, p3, p4}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method protected getOffsetIntoBytes()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/ByteString$BoundedByteString;->bytesOffset:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method internalByteAt(I)B
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/ByteString$LiteralByteString;->bytes:[B

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/ByteString$BoundedByteString;->bytesOffset:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/2addr v1, p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    aget-byte p1, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/ByteString$BoundedByteString;->bytesLength:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method writeReplace()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/ByteString;->toByteArray()[B

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->wrap([B)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method
