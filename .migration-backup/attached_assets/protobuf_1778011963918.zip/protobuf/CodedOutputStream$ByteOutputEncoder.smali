.class final Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;
.super Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedOutputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "ByteOutputEncoder"
.end annotation


# instance fields
.field private final out:Lcom/google/protobuf/ByteOutput;


# direct methods
.method constructor <init>(Lcom/google/protobuf/ByteOutput;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "out",
            "bufferSize"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p2}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;-><init>(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->out:Lcom/google/protobuf/ByteOutput;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/NullPointerException;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const-string/jumbo p2, "out"

    const-string/jumbo p2, "uto"

    const/4 v1, 0x2

    const-string/jumbo p2, "otu"

    const-string/jumbo p2, "out"

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    throw p1
.end method

.method private doFlush()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~s ~bo ~@ n~~. y@~@lob t~/@lf @fb~~ at Sio~~~@-M@/v 1@i ~4r@d~@@@u~@~@oc@~~ ~@@K~ imo@ ~~ so @@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->out:Lcom/google/protobuf/ByteOutput;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x0

    move v5, v3

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v3, v2}, Lcom/google/protobuf/ByteOutput;->write([BII)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method private flushIfNotAvailable(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "requiredSize"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->limit:I

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ge v0, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->doFlush()V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public flush()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-lez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->doFlush()V

    :cond_0
    const/4 v2, 0x1

    return-void
.end method

.method public write(B)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->limit:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->doFlush()V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer(B)V

    const/4 v3, 0x2

    return-void
.end method

.method public write(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flush()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->out:Lcom/google/protobuf/ByteOutput;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Lcom/google/protobuf/ByteOutput;->write(Ljava/nio/ByteBuffer;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/2addr p1, v0

    const/4 v2, 0x4

    move v3, v2

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public write([BII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flush()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->out:Lcom/google/protobuf/ByteOutput;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/ByteOutput;->write([BII)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    add-int/2addr p1, p3

    const/4 v1, 0x0

    move v2, v1

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public writeBool(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/16 v0, 0xb

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    int-to-byte p1, p2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer(B)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method public writeByteArray(I[B)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    array-length v0, p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2, v1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeByteArray(I[BII)V

    const/4 v2, 0x2

    and-int/2addr v3, v2

    return-void
.end method

.method public writeByteArray(I[BII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p2, p3, p4}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeByteArrayNoTag([BII)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public writeByteArrayNoTag([BII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-virtual {p0, p3}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->write([BII)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public writeByteBuffer(ILjava/nio/ByteBuffer;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p2}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeRawBytes(Ljava/nio/ByteBuffer;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public writeBytes(ILcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public writeBytesNoTag(Lcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/ByteString;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1, p0}, Lcom/google/protobuf/ByteString;->writeTo(Lcom/google/protobuf/ByteOutput;)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public writeFixed32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 v0, 0xe

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferTag(II)V

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferFixed32NoTag(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public writeFixed32NoTag(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    move v2, v1

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferFixed32NoTag(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public writeFixed64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/16 v0, 0x12

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferFixed64NoTag(J)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public writeFixed64NoTag(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/16 v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferFixed64NoTag(J)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public writeInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/16 v0, 0x14

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferInt32NoTag(I)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public writeInt32NoTag(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ltz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    int-to-long v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt64NoTag(J)V

    :goto_0
    const/4 v3, 0x7

    return-void
.end method

.method public writeLazy(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flush()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->out:Lcom/google/protobuf/ByteOutput;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Lcom/google/protobuf/ByteOutput;->writeLazy(Ljava/nio/ByteBuffer;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/2addr p1, v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v3, 0x3

    return-void
.end method

.method public writeLazy([BII)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flush()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->out:Lcom/google/protobuf/ByteOutput;

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2, p3}, Lcom/google/protobuf/ByteOutput;->writeLazy([BII)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    add-int/2addr p1, p3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public writeMessage(ILcom/google/protobuf/MessageLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method writeMessage(ILcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeMessageNoTag(Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public writeMessageNoTag(Lcom/google/protobuf/MessageLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p1}, Lcom/google/protobuf/MessageLite;->getSerializedSize()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {p1, p0}, Lcom/google/protobuf/MessageLite;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method

.method writeMessageNoTag(Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, Lcom/google/protobuf/AbstractMessageLite;

    const/4 v2, 0x6

    invoke-virtual {v0, p2}, Lcom/google/protobuf/AbstractMessageLite;->getSerializedSize(Lcom/google/protobuf/Schema;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/CodedOutputStream;->wrapper:Lcom/google/protobuf/CodedOutputStreamWriter;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {p2, p1, v0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public writeMessageSetExtension(ILcom/google/protobuf/MessageLite;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, v2, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32(II)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public writeRawBytes(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0, v0, v1, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->write([BII)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/google/protobuf/Java8Compatibility;->clear(Ljava/nio/Buffer;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->write(Ljava/nio/ByteBuffer;)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public writeRawMessageSetExtension(ILcom/google/protobuf/ByteString;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v4, 0x5

    const/4 v2, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v2, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32(II)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeBytes(ILcom/google/protobuf/ByteString;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 p1, 0x4

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public writeString(ILjava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeStringNoTag(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public writeStringNoTag(Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    mul-int/lit8 v0, v0, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    add-int v2, v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->limit:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-le v2, v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-array v1, v0, [B

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1, v1, v2, v0}, Lcom/google/protobuf/Utf8;->encode(Ljava/lang/CharSequence;[BII)I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    invoke-virtual {p0, v1, v2, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeLazy([BII)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    sub-int/2addr v3, v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-le v2, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->doFlush()V

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    :try_start_0
    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v2}, Lcom/google/protobuf/CodedOutputStream;->computeUInt32SizeNoTag(I)I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ne v2, v1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    add-int v1, v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v4, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->limit:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    sub-int/2addr v4, v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1, v3, v1, v4}, Lcom/google/protobuf/Utf8;->encode(Ljava/lang/CharSequence;[BII)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    sub-int v3, v1, v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    sub-int/2addr v3, v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt32NoTag(I)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/2addr v1, v3

    const/4 v6, 0x3

    iput v1, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/google/protobuf/Utf8;->encodedLength(Ljava/lang/CharSequence;)I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0, v1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt32NoTag(I)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->buffer:[B

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x5

    invoke-static {p1, v2, v3, v1}, Lcom/google/protobuf/Utf8;->encode(Ljava/lang/CharSequence;[BII)I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x6

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/2addr v2, v1

    const/4 v6, 0x0

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I
    :try_end_0
    .catch Lcom/google/protobuf/Utf8$UnpairedSurrogateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    new-instance v0, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, p1}, Lcom/google/protobuf/CodedOutputStream$OutOfSpaceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    throw v0

    :catch_1
    move-exception v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v3, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    sub-int/2addr v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    sub-int/2addr v2, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput v2, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->totalBytesWritten:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->position:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, p1, v1}, Lcom/google/protobuf/CodedOutputStream;->inefficientWriteStringNoTag(Ljava/lang/String;Lcom/google/protobuf/Utf8$UnpairedSurrogateException;)V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void
.end method

.method public writeTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->writeUInt32NoTag(I)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public writeUInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/16 v0, 0x14

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt32NoTag(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public writeUInt32NoTag(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt32NoTag(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public writeUInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/16 v0, 0x14

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferTag(II)V

    const/4 v2, 0x7

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt64NoTag(J)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public writeUInt64NoTag(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/16 v0, 0xa

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedOutputStream$ByteOutputEncoder;->flushIfNotAvailable(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/CodedOutputStream$AbstractBufferedEncoder;->bufferUInt64NoTag(J)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method
