.class Lcom/google/protobuf/IterableByteBufferInputStream;
.super Ljava/io/InputStream;


# instance fields
.field private currentAddress:J

.field private currentArray:[B

.field private currentArrayOffset:I

.field private currentByteBuffer:Ljava/nio/ByteBuffer;

.field private currentByteBufferPos:I

.field private currentIndex:I

.field private dataSize:I

.field private hasArray:Z

.field private iterator:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "Ljava/nio/ByteBuffer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Iterable;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Iterable<",
            "Ljava/nio/ByteBuffer;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->iterator:Ljava/util/Iterator;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->dataSize:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast v1, Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->dataSize:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x2

    iput v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->dataSize:I

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 p1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentIndex:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/IterableByteBufferInputStream;->getNextByteBuffer()Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    if-nez p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object p1, Lcom/google/protobuf/Internal;->EMPTY_BYTE_BUFFER:Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentIndex:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentAddress:J

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method private getNextByteBuffer()Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "c~s@ @ ~~@bMfi~~@@ ~  ~~S@ @r~u ~@@.~@o ~~t~l~@@@K~a  @1l@d@/nb@os@~y~v f4  tm~oioi/@boo - ~~  @"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentIndex:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/2addr v0, v1

    const/4 v4, 0x5

    move v5, v4

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentIndex:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->iterator:Ljava/util/Iterator;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v2

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->iterator:Ljava/util/Iterator;

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    check-cast v0, Ljava/nio/ByteBuffer;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-boolean v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->hasArray:Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArray:[B

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArrayOffset:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    iput-boolean v2, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->hasArray:Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/google/protobuf/UnsafeUtil;->addressOffset(Ljava/nio/ByteBuffer;)J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    iput-wide v2, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentAddress:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArray:[B

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v1
.end method

.method private updateCurrentByteBufferPos(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "numberOfBytesRead"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    add-int/2addr v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-ne v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/IterableByteBufferInputStream;->getNextByteBuffer()Z

    :cond_0
    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public read()I
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentIndex:I

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->dataSize:I

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-ne v0, v1, :cond_0

    const/4 v7, 0x7

    const/4 v0, 0x0

    const/4 v7, 0x4

    const/4 v0, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    return v0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    iget-boolean v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->hasArray:Z

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x3

    and-int/2addr v7, v6

    if-eqz v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArray:[B

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget v2, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget v3, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArrayOffset:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    add-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    aget-byte v0, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    and-int/lit16 v0, v0, 0xff

    const/4 v7, 0x2

    invoke-direct {p0, v1}, Lcom/google/protobuf/IterableByteBufferInputStream;->updateCurrentByteBufferPos(I)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    return v0

    :cond_1
    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    int-to-long v2, v0

    const/4 v7, 0x2

    iget-wide v4, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentAddress:J

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    add-long/2addr v2, v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v2, v3}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    and-int/lit16 v0, v0, 0xff

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p0, v1}, Lcom/google/protobuf/IterableByteBufferInputStream;->updateCurrentByteBufferPos(I)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    return v0
.end method

.method public read([BII)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "output",
            "offset",
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentIndex:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->dataSize:I

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 p1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/nio/Buffer;->limit()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    sub-int/2addr v0, v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-le p3, v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    move p3, v0

    move p3, v0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-boolean v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->hasArray:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArray:[B

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v2, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentArrayOffset:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-int/2addr v1, v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0, v1, p1, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x1

    move v4, v3

    invoke-direct {p0, p3}, Lcom/google/protobuf/IterableByteBufferInputStream;->updateCurrentByteBufferPos(I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x5

    iget v2, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBufferPos:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v1, v2}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, p1, p2, p3}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/protobuf/IterableByteBufferInputStream;->currentByteBuffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0, p3}, Lcom/google/protobuf/IterableByteBufferInputStream;->updateCurrentByteBufferPos(I)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    return p3
.end method
