.class public final Lcom/google/protobuf/EmptyProto;
.super Ljava/lang/Object;


# static fields
.field private static descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

.field static final internal_static_google_protobuf_Empty_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

.field static final internal_static_google_protobuf_Empty_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v0, "0ospf00staPpe/0uu0/o0/p0/p0P0wpg.snorpye0gg01/rao/uteB1tsobBnyopuo00u0Tt.oowamp/.}l0Efulgem60e0eEr0/eubmptuoB0e1/ootbf0gofmuuruon/u/ru2g//0f.ut0oo0rZo00/l0no/a1.gbotPu/13bGn/0gr/2nu00n/p05/opulurru00/Wnb/0y.G37ologb8p0ulP0pgt0off/t2e.yoo/.0/o1g/000mboutyn/e/u021oyg3oot/o0t.00leck"

    const-string v0, "btsnu0ouo.0o200noa/eyg//6oyoup0f0bo/0bblp03f/0efgr/ue0y.W/loug0/0opp/tat/00lb.o3t1ugB10g5200.l0u0olnPBy/0t0/B0gwngrp0w/ooc/Zen0uo0ryofruut/0u.uGnu0oe0afo0uP2gT/.0tt.2oup.teup1unr0oeb01P3}suoof7obeg/0//p000t/0npo/k/e/uo/ggutmp1Et/ub.0mEmr/ooo0rl18/Goepu0Ptla0yoo0g01/m0lppnro/sfmer"

    const/4 v4, 0x2

    const-string v0, "/oomlpr00trbotWE50ugf0e2gogkp/2omlp}o//2ne3n/.r0.0.t1r0ty/rr/Tue/0bruoe00tZ0nswb1pgpoao/fBtob/t/Bto/ltunoup0/Kenf/epe0umto1pll060p0000.o0uP0Puu/oumEu3gn1uym8P0//.gbeoa/o/03ufu/0gtpo/pb0l0/0.y01yt0g.enuouoofeb210gfreopuc0bwg0/o0/0poso00.700al/Bu/oG0tlo1o.u0of0myy/0nga/gnPuuGo00o/u"

    const-string v0, "\n\u001bgoogle/protobuf/empty.proto\u0012\u000fgoogle.protobuf\"\u0007\n\u0005EmptyB}\n\u0013com.google.protobufB\nEmptyProtoP\u0001Z.google.golang.org/protobuf/types/known/emptypb\u00f8\u0001\u0001\u00a2\u0002\u0003GPB\u00aa\u0002\u001eGoogle.Protobuf.WellKnownTypesb\u0006proto3"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-array v2, v1, [Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0, v2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->internalBuildGeneratedFileFrom([Ljava/lang/String;[Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    sput-object v0, Lcom/google/protobuf/EmptyProto;->descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/protobuf/EmptyProto;->getDescriptor()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getMessageTypes()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    sput-object v0, Lcom/google/protobuf/EmptyProto;->internal_static_google_protobuf_Empty_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v2, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-array v1, v1, [Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v2, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;-><init>(Lcom/google/protobuf/Descriptors$Descriptor;[Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    sput-object v2, Lcom/google/protobuf/EmptyProto;->internal_static_google_protobuf_Empty_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static getDescriptor()Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~b4uo@ K~o@l1d oo@   ~~@@ ~./o ~fa~@@c-~~@@y ~@ ~~@m@i ~@~ ~@~Mblt~n @o@ ~@S s~r i/ t@~@ivb @o~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/EmptyProto;->descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistry;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/EmptyProto;->registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
