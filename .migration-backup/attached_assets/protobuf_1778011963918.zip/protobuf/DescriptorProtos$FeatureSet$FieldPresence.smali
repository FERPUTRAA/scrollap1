.class public final enum Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/protobuf/ProtocolMessageEnum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos$FeatureSet;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "FieldPresence"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;",
        ">;",
        "Lcom/google/protobuf/ProtocolMessageEnum;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

.field public static final enum EXPLICIT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

.field public static final EXPLICIT_VALUE:I = 0x1

.field public static final enum FIELD_PRESENCE_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

.field public static final FIELD_PRESENCE_UNKNOWN_VALUE:I = 0x0

.field public static final enum IMPLICIT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

.field public static final IMPLICIT_VALUE:I = 0x2

.field public static final enum LEGACY_REQUIRED:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

.field public static final LEGACY_REQUIRED_VALUE:I = 0x3

.field private static final VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string v1, "SNsEINEOKEP_NLFNWUsRE_"

    const-string v1, "NEsLNNP_REIKWUENS_EFDO"

    const-string v1, "LNFmDKEENRNONUICEP_WSE"

    const-string v1, "FIELD_PRESENCE_UNKNOWN"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {v0, v1, v2, v2}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;-><init>(Ljava/lang/String;II)V

    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->FIELD_PRESENCE_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    new-instance v1, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string v3, "XImCoEPT"

    const-string v3, "TLPmCXEI"

    const-string v3, "IICXPbLE"

    const-string v3, "EXPLICIT"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {v1, v3, v4, v4}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    sput-object v1, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->EXPLICIT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    new-instance v3, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x0

    const-string/jumbo v5, "oTCIILuI"

    const-string v5, "ITMLoCII"

    const/4 v10, 0x1

    const-string v5, "CTILMIIp"

    const-string v5, "IMPLICIT"

    const/4 v9, 0x2

    xor-int/2addr v10, v9

    const/4 v6, 0x2

    move v10, v6

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {v3, v5, v6, v6}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    sput-object v3, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->IMPLICIT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    new-instance v5, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string v7, "UYLIEDGRqAQERCb"

    const-string v7, "ECGEIbQURRDYLAE"

    const/4 v10, 0x6

    const-string v7, "CYs_EEGERQUADRL"

    const-string v7, "LEGACY_REQUIRED"

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v8, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {v5, v7, v8, v8}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    sput-object v5, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->LEGACY_REQUIRED:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v7, 0x4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-array v7, v7, [Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    aput-object v0, v7, v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    aput-object v1, v7, v4

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    aput-object v3, v7, v6

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    aput-object v5, v7, v8

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    sput-object v7, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->$VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v9, 0x4

    const/4 v9, 0x2

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence$1;

    const/4 v10, 0x1

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence$1;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->values()[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p3, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->value:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static forNumber(I)Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~S m~@ vf@y~.o~i~rl-@b~  t l@ @ @~~u@~@ ~@i~@d@@@b~ @~K~/oi / @~t~~ @1sa~ ooM@@bo m ~@f  ~no~@c4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    if-eqz p0, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    if-eq p0, v0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eq p0, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x1

    if-eq p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->LEGACY_REQUIRED:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->IMPLICIT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->EXPLICIT:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0

    :cond_3
    const/4 v2, 0x5

    sget-object p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->FIELD_PRESENCE_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getEnumTypes()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v3, 0x0

    return-object v0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object v0
.end method

.method public static valueOf(I)Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method public static valueOf(Lcom/google/protobuf/Descriptors$EnumValueDescriptor;)Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "desc"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getType()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getIndex()I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    aget-object p0, v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo v0, "oepuonhus ittelo sartim fVD.csyEeio utprn"

    const-string v0, "cfrpstuDEmsti rV teoti o uasyepunl i.nohe"

    const/4 v3, 0x7

    const-string/jumbo v0, "m ou b y cissoteioirtEtphnptnDrsleaV.ue r"

    const-string v0, "EnumValueDescriptor is not for this type."

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const-class v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->$VALUES:[Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast v0, [Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public final getDescriptorForType()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public final getNumber()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->value:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public final getValueDescriptor()Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSet$FieldPresence;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->getValues()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-object v0
.end method
