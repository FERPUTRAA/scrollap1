.class final Lcom/google/protobuf/Descriptors$DescriptorPool;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Descriptors;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "DescriptorPool"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/Descriptors$DescriptorPool$PackageDescriptor;,
        Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;
    }
.end annotation


# instance fields
.field private final allowUnknownDependencies:Z

.field private final dependencies:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lcom/google/protobuf/Descriptors$FileDescriptor;",
            ">;"
        }
    .end annotation
.end field

.field private final descriptorsByName:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Lcom/google/protobuf/Descriptors$GenericDescriptor;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>([Lcom/google/protobuf/Descriptors$FileDescriptor;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0
        }
        names = {
            "dependencies",
            "allowUnknownDependencies"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v0, Ljava/util/IdentityHashMap;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    array-length v1, p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Ljava/util/IdentityHashMap;-><init>(I)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/util/Collections;->newSetFromMap(Ljava/util/Map;)Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->dependencies:Ljava/util/Set;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean p2, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->allowUnknownDependencies:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    array-length p2, p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ge v0, p2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    aget-object v1, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->dependencies:Ljava/util/Set;

    invoke-interface {v2, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p0, v1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->importPublicDependencies(Lcom/google/protobuf/Descriptors$FileDescriptor;)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->dependencies:Ljava/util/Set;

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    if-eqz p2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast p2, Lcom/google/protobuf/Descriptors$FileDescriptor;

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getPackage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, v0, p2}, Lcom/google/protobuf/Descriptors$DescriptorPool;->addPackage(Ljava/lang/String;Lcom/google/protobuf/Descriptors$FileDescriptor;)V
    :try_end_0
    .catch Lcom/google/protobuf/Descriptors$DescriptorValidationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance p2, Ljava/lang/AssertionError;

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {p2, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    throw p2

    :cond_1
    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void
.end method

.method private importPublicDependencies(Lcom/google/protobuf/Descriptors$FileDescriptor;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "file"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "y@s@  @~~b~ ~~~ol~ 1oK~v~~o~du@.m~ ~ 4@b t@r@ bSco@o~@@-~@@@at~@ o@/@~~n~ ~i  fM@ i~~s  @@ f/l i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getPublicDependencies()Ljava/util/List;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->dependencies:Ljava/util/Set;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->importPublicDependencies(Lcom/google/protobuf/Descriptors$FileDescriptor;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method static validateSymbolName(Lcom/google/protobuf/Descriptors$GenericDescriptor;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v1, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x5

    if-ge v1, v3, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/16 v4, 0x61

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-gt v4, v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/16 v4, 0x7a

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-le v3, v4, :cond_3

    :cond_0
    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v4, 0x41

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-gt v4, v3, :cond_1

    const/4 v5, 0x5

    move v6, v5

    const/16 v4, 0x5a

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    if-le v3, v4, :cond_3

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/16 v4, 0x5f

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eq v3, v4, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/16 v4, 0x30

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-gt v4, v3, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/16 v4, 0x39

    const/4 v6, 0x4

    if-gt v3, v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-lez v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v6, 0x3

    const/4 v5, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 v4, 0x22

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v0, "/nimtsvr.alidio /e sfead i  n"

    const-string v0, " os/irated sdt.fe v iinn/ ail"

    const/4 v6, 0x3

    const-string v0, " v/iorsafidt .d aoe/  neltiin"

    const-string v0, "\" is not a valid identifier."

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v1, p0, v0, v2}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    throw v1

    :cond_3
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-void

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v0, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v1, "sm asbnmnMei."

    const-string/jumbo v1, "innmeMags .sm"

    const/4 v6, 0x6

    const-string v1, "Missing name."

    const/4 v5, 0x7

    move v6, v5

    invoke-direct {v0, p0, v1, v2}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    throw v0
.end method


# virtual methods
.method addPackage(Ljava/lang/String;Lcom/google/protobuf/Descriptors$FileDescriptor;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fullName",
            "file"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/16 v0, 0x2e

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    if-ne v0, v1, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v1, p2}, Lcom/google/protobuf/Descriptors$DescriptorPool;->addPackage(Ljava/lang/String;Lcom/google/protobuf/Descriptors$FileDescriptor;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v2, Lcom/google/protobuf/Descriptors$DescriptorPool$PackageDescriptor;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v2, v0, p1, p2}, Lcom/google/protobuf/Descriptors$DescriptorPool$PackageDescriptor;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/google/protobuf/Descriptors$FileDescriptor;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v1, p1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v1, Lcom/google/protobuf/Descriptors$GenericDescriptor;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v2, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    instance-of p1, v1, Lcom/google/protobuf/Descriptors$DescriptorPool$PackageDescriptor;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 v3, 0x22

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v0, "lie  rust)h cemdfrign  a/  dt aenlsheaa (oei/ poa ayd/ioiganneehk s/"

    const-string v0, "/rdmohe(aehdecnnrlk /aogf tas /hoein)gpyens i/ii a dl   a af etei as"

    const/4 v5, 0x5

    const-string v0, "eh eie pafl hgtnaeaar/ dcaiitm  knidhds spn a)a/( e  li fes/o/yonrtg"

    const-string v0, "\" is already defined (as something other than a package) in file \""

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v0, ".//"

    const-string v0, "\"."

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p1, p2, v0, v1}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$FileDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw p1

    :cond_2
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-void
.end method

.method addSymbol(Lcom/google/protobuf/Descriptors$GenericDescriptor;)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "descriptor"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->validateSymbolName(Lcom/google/protobuf/Descriptors$GenericDescriptor;)V

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFullName()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-interface {v1, v0, p1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    check-cast v1, Lcom/google/protobuf/Descriptors$GenericDescriptor;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-interface {v2, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v1}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v4, "/./"

    const-string v4, ".//"

    const/4 v8, 0x6

    const-string v4, "\"."

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/16 v6, 0x22

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-ne v2, v3, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/16 v1, 0x2e

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v2, -0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ne v1, v2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const-string v0, "/deyd irq e.sibeln af/"

    const-string/jumbo v0, "iilnabfaedye//rds  .e "

    const/4 v8, 0x1

    const-string v0, "a sn/ eilee.da dy/idsr"

    const-string v0, "\" is already defined."

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v1, p1, v0, v5}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    throw v1

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance v2, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v8, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move v8, v7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    add-int/lit8 v6, v1, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    move v8, v7

    const-string v6, "/lnmidse/iu/y   ne/d da far"

    const-string/jumbo v6, "sna/riuele/ i/yaddidf /   n"

    const-string v6, "a//io/i dl afei nens dydr /"

    const-string v6, "\" is already defined in \""

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v6, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v6, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v2, p1, v0, v5}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    throw v2

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v2, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v0, "e senbi a/ ely ir l/ddfi /and/if"

    const-string v0, "\" is already defined in file \""

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-direct {v2, p1, v0, v5}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    throw v2

    :cond_2
    const/4 v7, 0x0

    move v8, v7

    return-void
.end method

.method findSymbol(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$GenericDescriptor;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "fullName"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->ALL_SYMBOLS:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p1
.end method

.method findSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fullName",
            "filter"
        }
    .end annotation

    const/4 v3, 0x2

    move v4, v3

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$GenericDescriptor;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    sget-object v1, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->ALL_SYMBOLS:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eq p2, v1, :cond_1

    const/4 v4, 0x4

    sget-object v1, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->TYPES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ne p2, v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->isType(Lcom/google/protobuf/Descriptors$GenericDescriptor;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez v1, :cond_1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v1, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->AGGREGATES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-ne p2, v1, :cond_2

    const/4 v3, 0x4

    shl-int/2addr v4, v3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->isAggregate(Lcom/google/protobuf/Descriptors$GenericDescriptor;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->dependencies:Ljava/util/Set;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v1, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    check-cast v1, Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, v1, Lcom/google/protobuf/Descriptors$DescriptorPool;->descriptorsByName:Ljava/util/Map;

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    invoke-interface {v1, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v1, Lcom/google/protobuf/Descriptors$GenericDescriptor;

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v2, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->ALL_SYMBOLS:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eq p2, v2, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object v2, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->TYPES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-ne p2, v2, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0, v1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->isType(Lcom/google/protobuf/Descriptors$GenericDescriptor;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v2, :cond_5

    :cond_4
    const/4 v3, 0x7

    move v4, v3

    sget-object v2, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->AGGREGATES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne p2, v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->isAggregate(Lcom/google/protobuf/Descriptors$GenericDescriptor;)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v2, :cond_3

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-object v1

    :cond_6
    const/4 v4, 0x1

    const/4 p1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p1
.end method

.method isAggregate(Lcom/google/protobuf/Descriptors$GenericDescriptor;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "descriptor"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$DescriptorPool$PackageDescriptor;

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    instance-of p1, p1, Lcom/google/protobuf/Descriptors$ServiceDescriptor;

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1
.end method

.method isType(Lcom/google/protobuf/Descriptors$GenericDescriptor;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "descriptor"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of p1, p1, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    const/4 v2, 0x3

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x7

    return p1
.end method

.method lookupSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$GenericDescriptor;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "name",
            "relativeTo",
            "filter"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string v0, "."

    const/4 v10, 0x7

    const-string v0, "."

    const-string v0, "."

    const/4 v10, 0x3

    const/4 v9, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz v1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v0, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p0, v0, p3}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x4

    goto/16 :goto_3

    :cond_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/16 v1, 0x2e

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/String;->indexOf(I)I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v2, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-ne v1, v2, :cond_1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    goto :goto_0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/4 v3, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p1, v3, v1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFullName()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :goto_1
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->lastIndexOf(Ljava/lang/String;)I

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-ne v5, v2, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {p0, p1, p3}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object v1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v10, 0x3

    const/4 v9, 0x5

    goto :goto_3

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    add-int/lit8 v6, v5, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    sget-object v8, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->AGGREGATES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p0, v7, v8}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v7, :cond_6

    const/4 v10, 0x3

    if-eq v1, v2, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p0, v0, p3}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    goto :goto_2

    :cond_3
    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :goto_3
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    if-nez v1, :cond_5

    const/4 v9, 0x6

    move v10, v9

    iget-boolean v1, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->allowUnknownDependencies:Z

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    if-eqz v1, :cond_4

    const/4 v9, 0x7

    move v10, v9

    sget-object v1, Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;->TYPES_ONLY:Lcom/google/protobuf/Descriptors$DescriptorPool$SearchFilter;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-ne p3, v1, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {}, Lcom/google/protobuf/Descriptors;->access$100()Ljava/util/logging/Logger;

    move-result-object p2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v1, "apTphpu s/rce ers tdygifms/oe eroe"

    const-string v1, "  e hs pdaorseprgoem cT/eitepf/sry"

    const/4 v10, 0x6

    const-string/jumbo v1, "mgph/dfp Tra  eec/ryoptoses rt eis"

    const-string v1, "The descriptor for message type \""

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const-string/jumbo p1, "tnd qaleqocncerdo dnfte  lfih  nsc//i  raeb dat rpoaoa"

    const-string p1, "caa   itqinlesdeaateolfd    pchorer/nodnn afob/drtc  e"

    const/4 v10, 0x0

    const-string p1, " aseoeu olta i t pbncfeeh n ico/alfdan sncaore/d  dtdr"

    const-string p1, "\" cannot be found and a placeholder is created for it"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p2, p1}, Ljava/util/logging/Logger;->warning(Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance p1, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v10, 0x0

    invoke-direct {p1, v0}, Lcom/google/protobuf/Descriptors$Descriptor;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object p2, p0, Lcom/google/protobuf/Descriptors$DescriptorPool;->dependencies:Ljava/util/Set;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$GenericDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object p3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-interface {p2, p3}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x1

    return-object p1

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    new-instance p3, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/16 v1, 0x22

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string/jumbo p1, "nn.mdti/ eoeidf ss"

    const-string/jumbo p1, "tnsd/ods/ fiie.ne "

    const/4 v10, 0x1

    const-string p1, "/ .foes n/d iionte"

    const-string p1, "\" is not defined."

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v0, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {p3, p2, p1, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    throw p3

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x7

    return-object v1

    :cond_6
    const/4 v10, 0x3

    const/4 v9, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->setLength(I)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto/16 :goto_1
.end method
