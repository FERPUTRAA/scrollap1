.class final Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;
.super Lcom/google/protobuf/BinaryWriter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/BinaryWriter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "UnsafeHeapWriter"
.end annotation


# instance fields
.field private allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

.field private buffer:[B

.field private limit:J

.field private limitMinusOne:J

.field private offset:J

.field private offsetMinusOne:J

.field private pos:J


# direct methods
.method constructor <init>(Lcom/google/protobuf/BufferAllocator;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, v0}, Lcom/google/protobuf/BinaryWriter;-><init>(Lcom/google/protobuf/BufferAllocator;ILcom/google/protobuf/BinaryWriter$1;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->nextBuffer()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method private arrayPos()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "MSs/~lo~@f@r~m@ot@@~@@@K~~@@cb @~ so~@ a@ ~t y@b~~~@ i ~@~i4  ~.~@v1 -nbd~~~ loo @@ uf /~i~   ~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    long-to-int v0, v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method static isSupported()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/protobuf/UnsafeUtil;->hasUnsafeArrayOperations()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method private nextBuffer()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->newHeapBuffer()Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private nextBuffer(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newHeapBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V

    const/4 v0, 0x1

    and-int/2addr v1, v0

    return-void
.end method

.method private nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "allocatedBuffer"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->hasArray()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->finishCurrentBuffer()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->array()[B

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->arrayOffset()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    int-to-long v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->limit()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    int-to-long v2, v2

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-long/2addr v2, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-wide v2, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->limit:J

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->position()I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    int-to-long v2, p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    add-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offset:J

    const/4 v4, 0x5

    move v5, v4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x2

    const-wide/16 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    sub-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offsetMinusOne:J

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->limit:J

    const/4 v5, 0x0

    sub-long/2addr v0, v2

    const/4 v4, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->limitMinusOne:J

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v0, "ohs rp ftulaf teelrobodrrnauenne-A"

    const/4 v5, 0x1

    const-string/jumbo v0, "llhm ofadtuooaenrerArpfurecnt neb "

    const-string v0, "Allocator returned non-heap buffer"

    const/4 v5, 0x7

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw p1
.end method

.method private writeVarint32FiveBytes(I)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    sub-long v5, v1, v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    ushr-int/lit8 v5, p1, 0x1c

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    int-to-byte v5, v5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    sub-long v5, v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    ushr-int/lit8 v5, p1, 0x15

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    and-int/lit8 v5, v5, 0x7f

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    or-int/lit16 v5, v5, 0x80

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    int-to-byte v5, v5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    sub-long v5, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    ushr-int/lit8 v5, p1, 0xe

    const/4 v7, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    and-int/lit8 v5, v5, 0x7f

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    or-int/lit16 v5, v5, 0x80

    const/4 v8, 0x5

    int-to-byte v5, v5

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    sub-long v5, v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    ushr-int/lit8 v5, p1, 0x7

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    and-int/lit8 v5, v5, 0x7f

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    or-int/lit16 v5, v5, 0x80

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    int-to-byte v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    sub-long v3, v1, v3

    const/4 v7, 0x2

    move v8, v7

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    and-int/lit8 p1, p1, 0x7f

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    or-int/lit16 p1, p1, 0x80

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    int-to-byte p1, p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v7, 0x5

    move v8, v7

    return-void
.end method

.method private writeVarint32FourBytes(I)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x5

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x0

    sub-long v5, v1, v3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    ushr-int/lit8 v5, p1, 0x15

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    int-to-byte v5, v5

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x4

    const/4 v7, 0x6

    sub-long v5, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    ushr-int/lit8 v5, p1, 0xe

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    and-int/lit8 v5, v5, 0x7f

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    or-int/lit16 v5, v5, 0x80

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    int-to-byte v5, v5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    sub-long v5, v1, v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    ushr-int/lit8 v5, p1, 0x7

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    and-int/lit8 v5, v5, 0x7f

    const/4 v8, 0x1

    const/4 v7, 0x7

    or-int/lit16 v5, v5, 0x80

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    int-to-byte v5, v5

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x6

    sub-long v3, v1, v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    and-int/lit8 p1, p1, 0x7f

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    or-int/lit16 p1, p1, 0x80

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    int-to-byte p1, p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-void
.end method

.method private writeVarint32OneByte(I)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v6, 0x4

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x5

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    sub-long v3, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    int-to-byte p1, p1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method

.method private writeVarint32ThreeBytes(I)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    sub-long v5, v1, v3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    ushr-int/lit8 v5, p1, 0xe

    const/4 v8, 0x2

    const/4 v7, 0x2

    int-to-byte v5, v5

    const/4 v7, 0x6

    move v8, v7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    sub-long v5, v1, v3

    const/4 v8, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x6

    ushr-int/lit8 v5, p1, 0x7

    const/4 v8, 0x2

    and-int/lit8 v5, v5, 0x7f

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    or-int/lit16 v5, v5, 0x80

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    int-to-byte v5, v5

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    sub-long v3, v1, v3

    const/4 v8, 0x5

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    and-int/lit8 p1, p1, 0x7f

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    or-int/lit16 p1, p1, 0x80

    const/4 v8, 0x2

    int-to-byte p1, p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-void
.end method

.method private writeVarint32TwoBytes(I)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x5

    const-wide/16 v3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    sub-long v5, v1, v3

    const/4 v8, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    ushr-int/lit8 v5, p1, 0x7

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    int-to-byte v5, v5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v7, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    sub-long v3, v1, v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x3

    and-int/lit8 p1, p1, 0x7f

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    or-int/lit16 p1, p1, 0x80

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    int-to-byte p1, p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    return-void
.end method

.method private writeVarint64EightBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v11, 0x0

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v11, 0x3

    shr-int/2addr v12, v11

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x6

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x6

    sub-long v5, v1, v3

    const/4 v11, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/16 v5, 0x31

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    ushr-long v5, p1, v5

    const/4 v11, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    long-to-int v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    int-to-byte v5, v5

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v11, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    const/16 v5, 0x2a

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    ushr-long v5, p1, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x3

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    and-long/2addr v5, v7

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x3

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    or-long/2addr v5, v9

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    sub-long v5, v1, v3

    const/4 v12, 0x4

    const/4 v11, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    const/16 v5, 0x23

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x1

    ushr-long v5, p1, v5

    const/4 v11, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    long-to-int v5, v5

    const/4 v12, 0x7

    int-to-byte v5, v5

    const/4 v11, 0x4

    const/4 v11, 0x2

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    sub-long v5, v1, v3

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/16 v5, 0x1c

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    ushr-long v5, p1, v5

    const/4 v12, 0x5

    and-long/2addr v5, v7

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    or-long/2addr v5, v9

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    long-to-int v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    int-to-byte v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/16 v5, 0x15

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    and-long/2addr v5, v7

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    or-long/2addr v5, v9

    const/4 v11, 0x3

    move v12, v11

    long-to-int v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    int-to-byte v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    sub-long v5, v1, v3

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/16 v5, 0xe

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x7

    ushr-long v5, p1, v5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    and-long/2addr v5, v7

    const/4 v11, 0x2

    const/4 v12, 0x2

    or-long/2addr v5, v9

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    int-to-byte v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    sub-long v5, v1, v3

    const/4 v12, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v5, 0x7

    shl-int/2addr v12, v5

    const/4 v11, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    ushr-long v5, p1, v5

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x3

    or-long/2addr v5, v9

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    long-to-int v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    int-to-byte v5, v5

    const/4 v11, 0x1

    and-int/2addr v12, v11

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x4

    sub-long v3, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    and-long/2addr p1, v7

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    or-long/2addr p1, v9

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    long-to-int p1, p1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    int-to-byte p1, p1

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v11, 0x2

    move v12, v11

    return-void
.end method

.method private writeVarint64FiveBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x5

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/16 v5, 0x1c

    const/4 v12, 0x5

    ushr-long v5, p1, v5

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x1

    int-to-byte v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/16 v5, 0x15

    const/4 v12, 0x2

    const/4 v11, 0x0

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x7

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x5

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    and-long/2addr v5, v7

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x7

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    long-to-int v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x7

    int-to-byte v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x5

    move v12, v11

    sub-long v5, v1, v3

    const/4 v11, 0x4

    move v12, v11

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/16 v5, 0xe

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    ushr-long v5, p1, v5

    const/4 v12, 0x3

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x3

    int-to-byte v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    sub-long v5, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    const/4 v5, 0x7

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    ushr-long v5, p1, v5

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    and-long/2addr v5, v7

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    or-long/2addr v5, v9

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x7

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x2

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    sub-long v3, v1, v3

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x5

    move v12, v11

    and-long/2addr p1, v7

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    or-long/2addr p1, v9

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    long-to-int p1, p1

    const/4 v12, 0x3

    int-to-byte p1, p1

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    return-void
.end method

.method private writeVarint64FourBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x3

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    sub-long v5, v1, v3

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    const/16 v5, 0x15

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    long-to-int v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    int-to-byte v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    sub-long v5, v1, v3

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    const/16 v5, 0xe

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x3

    const-wide/16 v7, 0x7f

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x6

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x5

    or-long/2addr v5, v9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    long-to-int v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    int-to-byte v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    sub-long v5, v1, v3

    const/4 v12, 0x1

    const/4 v11, 0x6

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    const/4 v5, 0x7

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x6

    ushr-long v5, p1, v5

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    long-to-int v5, v5

    const/4 v11, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    int-to-byte v5, v5

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    sub-long v3, v1, v3

    const/4 v12, 0x0

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    and-long/2addr p1, v7

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    or-long/2addr p1, v9

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    long-to-int p1, p1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    int-to-byte p1, p1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    return-void
.end method

.method private writeVarint64NineBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    sub-long v5, v1, v3

    const/4 v11, 0x1

    move v12, v11

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/16 v5, 0x38

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    long-to-int v5, v5

    const/4 v11, 0x0

    move v12, v11

    int-to-byte v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    const/16 v5, 0x31

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    ushr-long v5, p1, v5

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x4

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x1

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x4

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    or-long/2addr v5, v9

    const/4 v12, 0x6

    long-to-int v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    int-to-byte v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    const/16 v5, 0x2a

    const/4 v12, 0x3

    const/4 v11, 0x3

    ushr-long v5, p1, v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    and-long/2addr v5, v7

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    or-long/2addr v5, v9

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    long-to-int v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    int-to-byte v5, v5

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    sub-long v5, v1, v3

    const/4 v12, 0x5

    const/4 v11, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/16 v5, 0x23

    const/4 v11, 0x5

    move v12, v11

    ushr-long v5, p1, v5

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    and-long/2addr v5, v7

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    or-long/2addr v5, v9

    const/4 v12, 0x4

    long-to-int v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    int-to-byte v5, v5

    const/4 v11, 0x3

    shr-int/2addr v12, v11

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    sub-long v5, v1, v3

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/16 v5, 0x1c

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    and-long/2addr v5, v7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    long-to-int v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    int-to-byte v5, v5

    const/4 v12, 0x3

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    sub-long v5, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x6

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/16 v5, 0x15

    const/4 v11, 0x6

    move v12, v11

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x2

    and-long/2addr v5, v7

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    long-to-int v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    int-to-byte v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    sub-long v5, v1, v3

    const/4 v12, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    const/16 v5, 0xe

    const/4 v12, 0x0

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    and-long/2addr v5, v7

    const/4 v12, 0x1

    const/4 v11, 0x6

    or-long/2addr v5, v9

    const/4 v12, 0x4

    const/4 v11, 0x7

    long-to-int v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x6

    int-to-byte v5, v5

    const/4 v11, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x4

    sub-long v5, v1, v3

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    const/4 v5, 0x7

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    or-long/2addr v5, v9

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x2

    long-to-int v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    int-to-byte v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    sub-long v3, v1, v3

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x4

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    and-long/2addr p1, v7

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    or-long/2addr p1, v9

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    long-to-int p1, p1

    const/4 v12, 0x5

    const/4 v11, 0x4

    int-to-byte p1, p1

    const/4 v11, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x4

    return-void
.end method

.method private writeVarint64OneByte(J)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    sub-long v3, v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    long-to-int p1, p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    int-to-byte p1, p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void
.end method

.method private writeVarint64SevenBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x0

    const/4 v11, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    sub-long v5, v1, v3

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    const/16 v5, 0x2a

    const/4 v11, 0x2

    move v12, v11

    ushr-long v5, p1, v5

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x3

    int-to-byte v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x6

    sub-long v5, v1, v3

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/16 v5, 0x23

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    ushr-long v5, p1, v5

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x5

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    and-long/2addr v5, v7

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x5

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    or-long/2addr v5, v9

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    long-to-int v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    sub-long v5, v1, v3

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    const/16 v5, 0x1c

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    ushr-long v5, p1, v5

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x7

    or-long/2addr v5, v9

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x1

    long-to-int v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x0

    int-to-byte v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    sub-long v5, v1, v3

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/16 v5, 0x15

    ushr-long v5, p1, v5

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    or-long/2addr v5, v9

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x0

    long-to-int v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/16 v5, 0xe

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    ushr-long v5, p1, v5

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    and-long/2addr v5, v7

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x7

    or-long/2addr v5, v9

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x3

    long-to-int v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x2

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    const/4 v5, 0x7

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    ushr-long v5, p1, v5

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    or-long/2addr v5, v9

    long-to-int v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    int-to-byte v5, v5

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x0

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    sub-long v3, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x0

    or-int/2addr v12, v11

    and-long/2addr p1, v7

    const/4 v12, 0x4

    or-long/2addr p1, v9

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    long-to-int p1, p1

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x1

    int-to-byte p1, p1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    return-void
.end method

.method private writeVarint64SixBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    sub-long v5, v1, v3

    const/4 v11, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    const/16 v5, 0x23

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    ushr-long v5, p1, v5

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    long-to-int v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x3

    move v12, v11

    const/16 v5, 0x1c

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v11, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x5

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x6

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    or-long/2addr v5, v9

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    int-to-byte v5, v5

    const/4 v11, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x4

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    const/16 v5, 0x15

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    and-long/2addr v5, v7

    const/4 v12, 0x5

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    int-to-byte v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    const/16 v5, 0xe

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    and-long/2addr v5, v7

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    or-long/2addr v5, v9

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    int-to-byte v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    const/4 v5, 0x7

    const/4 v12, 0x0

    const/4 v11, 0x1

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x7

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    long-to-int v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v11, 0x6

    move v12, v11

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    sub-long v3, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    and-long/2addr p1, v7

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    or-long/2addr p1, v9

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    long-to-int p1, p1

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    int-to-byte p1, p1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v11, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    return-void
.end method

.method private writeVarint64TenBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v11, 0x4

    move v12, v11

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    sub-long v5, v1, v3

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/16 v5, 0x3f

    const/4 v12, 0x5

    const/4 v11, 0x1

    ushr-long v5, p1, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    long-to-int v5, v5

    const/4 v11, 0x4

    move v12, v11

    int-to-byte v5, v5

    const/4 v12, 0x1

    const/4 v11, 0x4

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/16 v5, 0x38

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x4

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    or-long/2addr v5, v9

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    int-to-byte v5, v5

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/16 v5, 0x31

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    ushr-long v5, p1, v5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    and-long/2addr v5, v7

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    or-long/2addr v5, v9

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    long-to-int v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    int-to-byte v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    sub-long v5, v1, v3

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/16 v5, 0x2a

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    ushr-long v5, p1, v5

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x6

    and-long/2addr v5, v7

    const/4 v11, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    or-long/2addr v5, v9

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x3

    int-to-byte v5, v5

    const/4 v11, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v11, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x7

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    const/16 v5, 0x23

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    ushr-long v5, p1, v5

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    and-long/2addr v5, v7

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    long-to-int v5, v5

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x2

    int-to-byte v5, v5

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/16 v5, 0x1c

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    ushr-long v5, p1, v5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    and-long/2addr v5, v7

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    or-long/2addr v5, v9

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    int-to-byte v5, v5

    const/4 v12, 0x4

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x1

    or-int/2addr v12, v11

    const/16 v5, 0x15

    const/4 v11, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    ushr-long v5, p1, v5

    const/4 v12, 0x4

    const/4 v11, 0x0

    and-long/2addr v5, v7

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x1

    or-long/2addr v5, v9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    long-to-int v5, v5

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    int-to-byte v5, v5

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v11, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v11, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x4

    const/4 v11, 0x6

    sub-long v5, v1, v3

    const/4 v12, 0x0

    const/4 v11, 0x4

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    const/16 v5, 0xe

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    ushr-long v5, p1, v5

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    and-long/2addr v5, v7

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    or-long/2addr v5, v9

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    long-to-int v5, v5

    const/4 v12, 0x2

    int-to-byte v5, v5

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    sub-long v5, v1, v3

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v5, 0x7

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    ushr-long v5, p1, v5

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    and-long/2addr v5, v7

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    or-long/2addr v5, v9

    const/4 v11, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    long-to-int v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    int-to-byte v5, v5

    const/4 v12, 0x3

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    sub-long v3, v1, v3

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    and-long/2addr p1, v7

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    or-long/2addr p1, v9

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x0

    long-to-int p1, p1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x3

    int-to-byte p1, p1

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-void
.end method

.method private writeVarint64ThreeBytes(J)V
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x7

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v12, 0x6

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v11, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x2

    sub-long v5, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    long-to-int v5, p1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    ushr-int/lit8 v5, v5, 0xe

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    int-to-byte v5, v5

    const/4 v12, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    sub-long v5, v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    const/4 v5, 0x7

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    ushr-long v5, p1, v5

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-wide/16 v7, 0x7f

    const-wide/16 v7, 0x7f

    const/4 v12, 0x3

    const-wide/16 v7, 0x7f

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    and-long/2addr v5, v7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    const-wide/16 v9, 0x80

    const-wide/16 v9, 0x80

    const/4 v12, 0x1

    const-wide/16 v9, 0x80

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    or-long/2addr v5, v9

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x6

    long-to-int v5, v5

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x1

    int-to-byte v5, v5

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    sub-long v3, v1, v3

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    and-long/2addr p1, v7

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    or-long/2addr p1, v9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    long-to-int p1, p1

    const/4 v12, 0x0

    const/4 v11, 0x2

    int-to-byte p1, p1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    return-void
.end method

.method private writeVarint64TwoBytes(J)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x2

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    sub-long v5, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v5, 0x7

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    ushr-long v5, p1, v5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    long-to-int v5, v5

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    int-to-byte v5, v5

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x0

    const/4 v7, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    sub-long v3, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    long-to-int p1, p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    and-int/lit8 p1, p1, 0x7f

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    or-int/lit16 p1, p1, 0x80

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    int-to-byte p1, p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-void
.end method


# virtual methods
.method bytesWrittenToCurrentBuffer()I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->limitMinusOne:J

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    sub-long/2addr v0, v2

    const/4 v5, 0x4

    long-to-int v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v0
.end method

.method finishCurrentBuffer()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->bytesWrittenToCurrentBuffer()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->arrayPos()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget-object v2, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2}, Lcom/google/protobuf/AllocatedBuffer;->arrayOffset()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    sub-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/google/protobuf/AllocatedBuffer;->position(I)Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->allocatedBuffer:Lcom/google/protobuf/AllocatedBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->limitMinusOne:J

    :cond_0
    const/4 v4, 0x7

    return-void
.end method

.method public getTotalBytesWritten()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->bytesWrittenToCurrentBuffer()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method requireSpace(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "size"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->spaceLeft()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ge v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->nextBuffer(I)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method spaceLeft()I
    .locals 6

    const/4 v5, 0x3

    iget-wide v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-wide v2, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offsetMinusOne:J

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    sub-long/2addr v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    long-to-int v0, v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v0
.end method

.method public write(B)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x6

    move v6, v5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x0

    const-wide/16 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    sub-long v3, v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method

.method public write(Ljava/nio/ByteBuffer;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    int-to-long v3, v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    sub-long/2addr v1, v3

    const/4 v6, 0x4

    iput-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v5, 0x7

    move v6, v5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->arrayPos()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1, v1, v2, v0}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void
.end method

.method public write([BII)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v0, 0x1

    move v6, v0

    const/4 v5, 0x0

    const/4 v5, 0x7

    if-ltz p2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int v1, p2, p3

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    array-length v2, p1

    const/4 v5, 0x5

    and-int/2addr v6, v5

    if-gt v1, v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x2

    int-to-long v3, p3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    sub-long/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->arrayPos()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    add-int/2addr v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {p1, p2, v1, v2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    array-length p1, p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    aput-object p1, v2, v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    aput-object p1, v2, v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 p1, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    aput-object p2, v2, p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const-string p1, ",ftmtldngsed=guol,=v%te%enh lf h%dea."

    const/4 v6, 0x6

    const-string p1, " veaodesglf.l tng==%ludte=tho,en,df%h"

    const-string/jumbo p1, "value.length=%d, offset=%d, length=%d"

    invoke-static {p1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-direct {v1, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    throw v1
.end method

.method public writeBool(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x6

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    int-to-byte p2, p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->write(B)V

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x7

    return-void
.end method

.method writeBool(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    int-to-byte p1, p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->write(B)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public writeBytes(ILcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p2, p0}, Lcom/google/protobuf/ByteString;->writeToReverse(Lcom/google/protobuf/ByteOutput;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 v0, 0xa

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p2}, Lcom/google/protobuf/ByteString;->size()I

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p2, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance p2, Ljava/lang/RuntimeException;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    throw p2
.end method

.method public writeEndGroup(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x4

    shr-int/2addr v2, v0

    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method writeFixed32(I)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v7, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    sub-long v5, v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    shr-int/lit8 v5, p1, 0x18

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    int-to-byte v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    sub-long v5, v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    shr-int/lit8 v5, p1, 0x10

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    int-to-byte v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v7, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v7, 0x3

    shr-int/2addr v8, v7

    sub-long v5, v1, v3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    shr-int/lit8 v5, p1, 0x8

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    int-to-byte v5, v5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    sub-long v3, v1, v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    and-int/lit16 p1, p1, 0xff

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    int-to-byte p1, p1

    const/4 v7, 0x1

    move v8, v7

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-void
.end method

.method public writeFixed32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/16 v0, 0x9

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeFixed32(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p2, 0x5

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public writeFixed64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/16 v0, 0xd

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeFixed64(J)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p2, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method writeFixed64(J)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    sub-long v5, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/16 v5, 0x38

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    shr-long v5, p1, v5

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    long-to-int v5, v5

    const/4 v7, 0x6

    and-int/2addr v8, v7

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    int-to-byte v5, v5

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    sub-long v5, v1, v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/16 v5, 0x30

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    shr-long v5, p1, v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    long-to-int v5, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    int-to-byte v5, v5

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v7, 0x0

    const/4 v8, 0x1

    sub-long v5, v1, v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/16 v5, 0x28

    shr-long v5, p1, v5

    const/4 v8, 0x1

    long-to-int v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    int-to-byte v5, v5

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    sub-long v5, v1, v3

    const/4 v8, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/16 v5, 0x20

    const/4 v7, 0x0

    and-int/2addr v8, v7

    shr-long v5, p1, v5

    const/4 v7, 0x4

    and-int/2addr v8, v7

    long-to-int v5, v5

    const/4 v8, 0x4

    const/4 v7, 0x0

    and-int/lit16 v5, v5, 0xff

    const/4 v7, 0x3

    and-int/2addr v8, v7

    int-to-byte v5, v5

    const/4 v8, 0x6

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    sub-long v5, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/16 v5, 0x18

    const/4 v8, 0x7

    const/4 v7, 0x1

    shr-long v5, p1, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    long-to-int v5, v5

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    int-to-byte v5, v5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x4

    const/4 v7, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v7, 0x6

    sub-long v5, v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/16 v5, 0x10

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    shr-long v5, p1, v5

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    long-to-int v5, v5

    const/4 v7, 0x7

    move v8, v7

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x0

    int-to-byte v5, v5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x4

    sub-long v5, v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    iput-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/16 v5, 0x8

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    shr-long v5, p1, v5

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    long-to-int v5, v5

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    int-to-byte v5, v5

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v0, v1, v2, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v8, 0x1

    const/4 v7, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x6

    const/4 v7, 0x5

    sub-long v3, v1, v3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput-wide v3, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v8, 0x1

    long-to-int p1, p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    and-int/lit16 p1, p1, 0xff

    const/4 v8, 0x7

    const/4 v7, 0x5

    int-to-byte p1, p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v8, 0x7

    return-void
.end method

.method public writeGroup(ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/Protobuf;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p2, 0x3

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public writeGroup(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-interface {p3, p2, p0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p2, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x0

    return-void
.end method

.method writeInt32(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-ltz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    int-to-long v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64(J)V

    :goto_0
    const/4 v3, 0x2

    return-void
.end method

.method public writeInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v0, 0xf

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeInt32(I)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public writeLazy(Ljava/nio/ByteBuffer;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->spaceLeft()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    if-ge v1, v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    add-int/2addr v1, v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput v1, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/google/protobuf/AllocatedBuffer;->wrap(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->nextBuffer()V

    :cond_0
    const/4 v6, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    int-to-long v3, v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    sub-long/2addr v1, v3

    const/4 v6, 0x4

    iput-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->arrayPos()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1, v1, v2, v0}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method public writeLazy([BII)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ltz p2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int v1, p2, p3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    array-length v2, p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-gt v1, v2, :cond_1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->spaceLeft()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ge v1, p3, :cond_0

    const/4 v5, 0x1

    move v6, v5

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-int/2addr v0, p3

    const/4 v6, 0x3

    iput v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p1, p2, p3}, Lcom/google/protobuf/AllocatedBuffer;->wrap([BII)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->nextBuffer()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    int-to-long v3, p3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    sub-long/2addr v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput-wide v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->arrayPos()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    add-int/2addr v2, v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p1, p2, v1, v2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x3

    return-void

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/ArrayIndexOutOfBoundsException;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    array-length p1, p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x7

    aput-object p1, v2, v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    aput-object p1, v2, v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 p1, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    aput-object p2, v2, p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string p1, "%,e%gbloe ehtd t=ll=u=ag.sddthv%fn,oe"

    const-string p1, "%.llot%,tldhhge =%utdf,=fo e=egavsedn"

    const/4 v6, 0x6

    const-string p1, " =evdeu lefndt=%=tt%dfh.ghulnoe%s,l,g"

    const-string/jumbo p1, "value.length=%d, offset=%d, length=%d"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p1, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v1, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x3

    throw v1
.end method

.method public writeMessage(ILjava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1, p2, p0}, Lcom/google/protobuf/Protobuf;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    sub-int/2addr p2, v0

    const/4 v2, 0x6

    move v3, v2

    const/16 v0, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p2, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public writeMessage(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p3, p2, p0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    sub-int/2addr p2, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 p3, 0xa

    const/4 v2, 0x0

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p2, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method writeSInt32(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag32(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public writeSInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/16 v0, 0xa

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeSInt32(I)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public writeSInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/16 v0, 0xf

    const/4 v1, 0x1

    move v2, v1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeSInt64(J)V

    const/4 v2, 0x5

    const/4 p2, 0x0

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method writeSInt64(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag64(J)J

    move-result-wide p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64(J)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    return-void
.end method

.method public writeStartGroup(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x5

    return-void
.end method

.method public writeString(ILjava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeString(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    sub-int/2addr p2, v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 v0, 0xa

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p2, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method writeString(Ljava/lang/String;)V
    .locals 14
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "in"
        }
    .end annotation

    const/4 v13, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x7

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x0

    const/16 v1, 0x80

    const/4 v12, 0x1

    move v13, v12

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v13, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x7

    if-ltz v0, :cond_0

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x6

    if-ge v4, v1, :cond_0

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x4

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x0

    iget-wide v5, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x5

    sub-long v2, v5, v2

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x4

    iput-wide v2, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    int-to-byte v2, v4

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-static {v1, v5, v6, v2}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v13, 0x2

    const/4 v12, 0x1

    goto :goto_0

    :cond_0
    const/4 v13, 0x7

    const/4 v4, -0x6

    const/4 v13, 0x6

    const/4 v4, -0x1

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x2

    if-ne v0, v4, :cond_1

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x1

    return-void

    :cond_1
    :goto_1
    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x0

    if-ltz v0, :cond_8

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x0

    if-ge v5, v1, :cond_2

    const/4 v13, 0x2

    const/4 v12, 0x2

    iget-wide v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x5

    iget-wide v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offsetMinusOne:J

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x2

    cmp-long v8, v6, v8

    const/4 v13, 0x2

    if-lez v8, :cond_2

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    iget-object v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x4

    sub-long v9, v6, v2

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x2

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x5

    int-to-byte v5, v5

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-static {v8, v6, v7, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x1

    goto/16 :goto_2

    :cond_2
    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x7

    const/16 v6, 0x800

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x6

    if-ge v5, v6, :cond_3

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x7

    iget-wide v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x7

    const/4 v12, 0x3

    iget-wide v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offset:J

    const/4 v13, 0x2

    cmp-long v8, v6, v8

    const/4 v12, 0x4

    and-int/2addr v13, v12

    if-lez v8, :cond_3

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x7

    iget-object v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x6

    sub-long v9, v6, v2

    const/4 v13, 0x6

    const/4 v12, 0x7

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x7

    const/4 v12, 0x0

    and-int/lit8 v9, v5, 0x3f

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x4

    or-int/2addr v9, v1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x7

    int-to-byte v9, v9

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-static {v8, v6, v7, v9}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x2

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x7

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x6

    sub-long v9, v7, v2

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x2

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x4

    ushr-int/lit8 v5, v5, 0x6

    const/4 v13, 0x6

    const/4 v12, 0x6

    or-int/lit16 v5, v5, 0x3c0

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x6

    int-to-byte v5, v5

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-static {v6, v7, v8, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x6

    goto/16 :goto_2

    :cond_3
    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x1

    const v6, 0xd800

    const/4 v12, 0x0

    move v13, v12

    if-lt v5, v6, :cond_4

    const/4 v13, 0x2

    const v6, 0xdfff

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x7

    if-ge v6, v5, :cond_5

    :cond_4
    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x7

    iget-wide v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    iget-wide v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offset:J

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x4

    add-long/2addr v8, v2

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x5

    cmp-long v8, v6, v8

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x1

    if-lez v8, :cond_5

    const/4 v13, 0x6

    iget-object v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x2

    sub-long v9, v6, v2

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x7

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x2

    and-int/lit8 v9, v5, 0x3f

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    or-int/2addr v9, v1

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x4

    int-to-byte v9, v9

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x0

    invoke-static {v8, v6, v7, v9}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x1

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x1

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x0

    const/4 v12, 0x4

    sub-long v9, v7, v2

    const/4 v13, 0x6

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x3

    ushr-int/lit8 v9, v5, 0x6

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x6

    and-int/lit8 v9, v9, 0x3f

    const/4 v13, 0x3

    or-int/2addr v9, v1

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x6

    int-to-byte v9, v9

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-static {v6, v7, v8, v9}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x6

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x2

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x6

    sub-long v9, v7, v2

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x6

    ushr-int/lit8 v5, v5, 0xc

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x1

    or-int/lit16 v5, v5, 0x1e0

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x5

    int-to-byte v5, v5

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-static {v6, v7, v8, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x4

    goto/16 :goto_2

    :cond_5
    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x0

    iget-wide v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    iget-wide v8, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->offset:J

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    const-wide/16 v10, 0x2

    const-wide/16 v10, 0x2

    const/4 v13, 0x3

    const-wide/16 v10, 0x2

    const-wide/16 v10, 0x2

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x7

    add-long/2addr v8, v10

    const/4 v13, 0x4

    cmp-long v6, v6, v8

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x7

    if-lez v6, :cond_7

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x3

    if-eqz v0, :cond_6

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x7

    add-int/lit8 v6, v0, -0x1

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {p1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v13, 0x4

    const/4 v12, 0x1

    invoke-static {v6, v5}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v7

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x4

    if-eqz v7, :cond_6

    const/4 v13, 0x3

    add-int/lit8 v0, v0, -0x1

    invoke-static {v6, v5}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v5

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x0

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x3

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v12, 0x3

    move v13, v12

    sub-long v9, v7, v2

    const/4 v13, 0x6

    const/4 v12, 0x3

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    and-int/lit8 v9, v5, 0x3f

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x6

    or-int/2addr v9, v1

    const/4 v13, 0x4

    const/4 v12, 0x7

    int-to-byte v9, v9

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-static {v6, v7, v8, v9}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x4

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x5

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x2

    sub-long v9, v7, v2

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x7

    ushr-int/lit8 v9, v5, 0x6

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x5

    and-int/lit8 v9, v9, 0x3f

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x3

    or-int/2addr v9, v1

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x4

    int-to-byte v9, v9

    const/4 v12, 0x3

    and-int/2addr v13, v12

    invoke-static {v6, v7, v8, v9}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x7

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x5

    sub-long v9, v7, v2

    const/4 v13, 0x0

    const/4 v12, 0x5

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    ushr-int/lit8 v9, v5, 0xc

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x6

    and-int/lit8 v9, v9, 0x3f

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x4

    or-int/2addr v9, v1

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x2

    int-to-byte v9, v9

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-static {v6, v7, v8, v9}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->buffer:[B

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x5

    iget-wide v7, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x1

    sub-long v9, v7, v2

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    iput-wide v9, p0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->pos:J

    const/4 v13, 0x6

    ushr-int/lit8 v5, v5, 0x12

    const/4 v12, 0x3

    or-int/2addr v13, v12

    or-int/lit16 v5, v5, 0xf0

    const/4 v13, 0x2

    const/4 v12, 0x0

    int-to-byte v5, v5

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static {v6, v7, v8, v5}, Lcom/google/protobuf/UnsafeUtil;->putByte([BJB)V

    const/4 v13, 0x4

    const/4 v12, 0x3

    goto :goto_2

    :cond_6
    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x2

    new-instance p1, Lcom/google/protobuf/Utf8$UnpairedSurrogateException;

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x3

    add-int/lit8 v1, v0, -0x1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-direct {p1, v1, v0}, Lcom/google/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x5

    throw p1

    :cond_7
    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v12, 0x6

    xor-int/2addr v13, v12

    add-int/lit8 v0, v0, 0x1

    :goto_2
    const/4 v13, 0x4

    add-int/2addr v0, v4

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x3

    goto/16 :goto_1

    :cond_8
    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x5

    return-void
.end method

.method writeTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public writeUInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/16 v0, 0xa

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32(I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public writeUInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/16 v0, 0xf

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->requireSpace(I)V

    const/4 v2, 0x5

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64(J)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 p2, 0x0

    shl-int/2addr v2, p2

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method writeVarint32(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    and-int/lit8 v0, p1, -0x80

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32OneByte(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    and-int/lit16 v0, p1, -0x4000

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez v0, :cond_1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32TwoBytes(I)V

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/high16 v0, -0x200000

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    and-int/2addr v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez v0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32ThreeBytes(I)V

    const/4 v2, 0x7

    goto :goto_0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/high16 v0, -0x10000000

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    and-int/2addr v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32FourBytes(I)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint32FiveBytes(I)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method writeVarint64(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p1, p2}, Lcom/google/protobuf/BinaryWriter;->access$200(J)B

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    packed-switch v0, :pswitch_data_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64TenBytes(J)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64NineBytes(J)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_2
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64EightBytes(J)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :pswitch_3
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64SevenBytes(J)V

    const/4 v2, 0x3

    goto :goto_0

    :pswitch_4
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64SixBytes(J)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :pswitch_5
    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64FiveBytes(J)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :pswitch_6
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64FourBytes(J)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_7
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64ThreeBytes(J)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :pswitch_8
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64TwoBytes(J)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_9
    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->writeVarint64OneByte(J)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
