.class public Lcom/google/protobuf/InvalidProtocolBufferException;
.super Ljava/io/IOException;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;
    }
.end annotation


# static fields
.field private static final serialVersionUID:J = -0x166db9773d0dffacL


# instance fields
.field private unfinishedMessage:Lcom/google/protobuf/MessageLite;

.field private wasThrownFromInputStream:Z


# direct methods
.method public constructor <init>(Ljava/io/IOException;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "e"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p0, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/Exception;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "e"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    invoke-direct {p0, v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "description"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/io/IOException;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "description",
            "e"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-direct {p0, p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v0, 0x6

    move v1, v0

    iput-object p1, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "description",
            "e"
        }
    .end annotation

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0, p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method static invalidEndTag()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/@s@ -/~t vo@ni~ @@@  4y~~  ~f~@~1~@ @Kmol@o~ ~~ ~   @ i@@S~@ a@~~ @.~cot ~d~@~~@br~io@uls~bM@bf"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "iatm ueng o-md atedeoo oantsleep.tgPp rmgcc stxogrcdhtasd "

    const-string/jumbo v1, "tese ngc t acesplPd mttopamicedoeoagstoegndaru x d-rhg ot."

    const/4 v3, 0x4

    const-string v1, "dxetoghoi.a ote e-otcgnc nrPe trsc ptldapedmgomsuot gad ea"

    const-string v1, "Protocol message end-group tag did not match expected tag."

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method

.method static invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "t(rgiboPi em c  avertacledod oonaolnsgms)iz.nt ae"

    const-string v1, " anm.vd (oeaomno iso iogiare nPnadttgtcelc )lezrs"

    const/4 v3, 0x0

    const-string v1, "(llge)umtPii es vctasarnorocdnidenozaoo  .e tga n"

    const-string v1, "Protocol message contained an invalid tag (zero)."

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method static invalidUtf8()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v1, "cn og ipvmTeasPei-r ha8aUlddtlosF.o"

    const-string/jumbo v1, "oiiroFella c8tgdm nUa.-Ph sos dTaev"

    const-string/jumbo v1, "lFo enacqsa-hoPTiseU.dgdomlt  ivr a"

    const-string v1, "Protocol message had invalid UTF-8."

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0
.end method

.method static invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v1, "Ptsogpy.n lmtlvecdrroaas aa s e h tegibiwde"

    const-string v1, "ganroboawydltveoeP. a tishreigmsp  eltadc  "

    const/4 v3, 0x5

    const-string/jumbo v1, "riymria  Plde iaveoosdaten a. wphsctto lggm"

    const-string v1, "Protocol message tag had invalid wire type."

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method static malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "Cdneovdlmmatodne.rpeInaaeeoioec S ururtr atmdftn"

    const-string/jumbo v1, "rtlertuaeCer et a arnoddp.dmnfiItSmvoeuoedcnunma"

    const/4 v3, 0x2

    const-string v1, "CodedInputStream encountered a malformed varint."

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0
.end method

.method static negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "drsitbedzupanm wegrtoenoeCchhe .mebgiiSnmaesseaeed  a icvlr egst e chndrI avedadneeto pnt omidu"

    const-string v1, "dtai nepalegeh dohSes.Ioa v regtdn ecee iddetadseuedmttrwnoompb iiaeme  zcmcnCreuigsasv nrnh e "

    const/4 v3, 0x7

    const-string v1, "eh t iuiesvnpersegru esatevudnS  bdamcadhdddoegeng.a esem encez deC r oiintehaon rmI wmcatiottl"

    const-string v1, "CodedInputStream encountered an embedded string or message which claimed to have negative size."

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    return-object v0
.end method

.method static parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v1, " seot epermtahp e ise.sdgaql"

    const-string/jumbo v1, "mee ea  qatsehFsp sloi.rgdet"

    const/4 v3, 0x5

    const-string/jumbo v1, "to.sl F qasdrpeeeea ah gsiet"

    const-string v1, "Failed to parse the message."

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method static recursionLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "atsale.rgnoym)eseMtsu iat elsst uoUtstrctco.nru deeInsacaPilm egs iivsi dlnepnCnemoeioaedfSost Loiree.hd  ( imb soolict my oeh atthm e Rp "

    const-string v1, "Prsat.ts euspvIai si elrgapo  aiuoohnit  oodg  rScoiehoy s ettdfd onsLbsd  ilmmao .eei (nuee)tltRmaly tcUcensociheemnC eeMi tslmt.sentarem"

    const/4 v3, 0x5

    const-string v1, ".ramo.fegesemCsss  tl)nPcnhcao ema eau(os i rL Mt.RegSprstttia n teI d.denpdoh otn m eiumie u rlv ee tessibli lhetm tyUcnaoiioaiodmlsyootc"

    const-string v1, "Protocol message had too many levels of nesting.  May be malicious.  Use CodedInputStream.setRecursionLimit() to increase the depth limit."

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method static sizeLimitExceeded()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "uaowo parmeeiisnSa atc eettsezMSiim C rs)ct sa solz mLeo semaci e rnma( . tsul .yetrit.e dIdit.l ihbgPtUsmeooiogelo"

    const-string/jumbo v1, "im minierbct.iP dI oetr( snhsicelittems tg ol oumCattepls ezeSasl.dua Ma.S etgeaorrz )oy o ULtsisaaom.mocie  iwe se"

    const/4 v3, 0x1

    const-string/jumbo v1, "mPse baiaSm znUdein)  r ioei twrms. Moec.semisttereeIbLug.Ct o(mzltoio e lcied sSltuato aayas itecl rohs epa stog.e"

    const-string v1, "Protocol message was too large.  May be malicious.  Use CodedInputStream.setSizeLimit() to increase the size limit."

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method static truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Lcom/google/protobuf/InvalidProtocolBufferException;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, ",eap.ducetdiidoi lr du nhg t mlep hWaenehpf  eo ehnuhfttdrdalent dteTbolrtdcpweei aien c ndtime ern eeuat sts ne blot ngh tadnogootea  ia.ey hxenesh l e o aacr  egoms p hsedutsihiieptsedar sem immnrstl "

    const-string/jumbo v1, "na.eotneddeduhWtgdooeTt.lre isd oh hdrghgbidpttatxa ie r  w   meitn icrrnrptnul npst plntr em es a heteyes mtba ic tel t diaehsl emddmp dooef eacueeioosisonate ca eatlngnaeh i  idupmsfe  e uelhnen eh,sh"

    const/4 v3, 0x7

    const-string/jumbo v1, "sesdodope uttt awhc u   ehcdtfttnes rx rrab tme de uts   iontnhrsishl pemaue pce thagd,ca needpihe olf  mTdinpr geodstasipl eninohha eethnr ldelt.iemnbg e p Wneti ndiel gatdeuaertmo.halin dis o e ytaeme"

    const-string v1, "While parsing a protocol message, the input ended unexpectedly in the middle of a field.  This could mean either that the input has been truncated or that an embedded message misreported its own length."

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/protobuf/InvalidProtocolBufferException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    return-object v0
.end method


# virtual methods
.method getThrownFromInputStream()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->wasThrownFromInputStream:Z

    const/4 v1, 0x6

    move v2, v1

    return v0
.end method

.method public getUnfinishedMessage()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method setThrownFromInputStream()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->wasThrownFromInputStream:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public setUnfinishedMessage(Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/InvalidProtocolBufferException;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unfinishedMessage"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/protobuf/InvalidProtocolBufferException;->unfinishedMessage:Lcom/google/protobuf/MessageLite;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public unwrapIOException()Ljava/io/IOException;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    instance-of v0, v0, Ljava/io/IOException;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Ljava/io/IOException;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    return-object v0
.end method
