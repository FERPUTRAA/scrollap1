.class public final Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/GeneratedMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FieldAccessorTable"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedMessageFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularMessageFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularStringFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedEnumFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularEnumFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$MapFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;,
        Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;
    }
.end annotation


# instance fields
.field private camelCaseNames:[Ljava/lang/String;

.field private final descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

.field private final fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

.field private volatile initialized:Z

.field private final oneofs:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;


# direct methods
.method public constructor <init>(Lcom/google/protobuf/Descriptors$Descriptor;[Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "camelCaseNames"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$Descriptor;->getFields()Ljava/util/List;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    new-array p2, p2, [Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$Descriptor;->getOneofs()Ljava/util/List;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-array p1, p1, [Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->oneofs:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->initialized:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/google/protobuf/Descriptors$Descriptor;[Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "descriptor",
            "camelCaseNames",
            "messageClass",
            "builderClass"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/Descriptors$Descriptor;",
            "[",
            "Ljava/lang/String;",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/protobuf/GeneratedMessage;",
            ">;",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/protobuf/GeneratedMessage$Builder;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;-><init>(Lcom/google/protobuf/Descriptors$Descriptor;[Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0, p3, p4}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$000(Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;)Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~m  ~ @fvi S -~~~  ~@@@@o/t~~ oi~ui~~@ ~.l~@~oa1 @@ ~Kb oM~l@@d fcoo y~ @bb @@~st@@r~@ @/@~4n"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$100(Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->getOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$1300(Lcom/google/protobuf/Descriptors$FileDescriptor;)Z
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->supportFieldPresence(Lcom/google/protobuf/Descriptors$FileDescriptor;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$200(Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->getField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method private getField(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v3, 0x7

    const/4 v2, 0x0

    if-ne v0, v1, :cond_1

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isExtension()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getIndex()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    aget-object p1, v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "eeim eyn xvhh sssoioto a.pttnTdeen "

    const-string v0, "This type does not have extensions."

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    throw p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "n aios dpert ocdcelhgtiepessamm.  eoseFDtrto"

    const-string/jumbo v0, "iessDy hale sdtin o mttgrced pmoeeasFcpt.reo"

    const-string v0, "cher bs.speinootgatlatmrt  edDs peeosFi ycme"

    const-string v0, "FieldDescriptor does not match message type."

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    move v3, v2

    throw p1
.end method

.method private getOneof(Lcom/google/protobuf/Descriptors$OneofDescriptor;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "oneof"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->oneofs:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->getIndex()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    aget-object p1, v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v0, "msyasduhosr.Deiotctm pcegstp metnoeerneO ao "

    const-string v0, "e smayadcoh.Onmti gtes o toppsreoctreemnes D"

    const/4 v3, 0x7

    const-string/jumbo v0, "ntcpeiOps .oen cofssoemdeDgrsapo thatyet  er"

    const-string v0, "OneofDescriptor does not match message type."

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p1
.end method

.method private isMapFieldEnabled(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x7

    return p1
.end method

.method private static supportFieldPresence(Lcom/google/protobuf/Descriptors$FileDescriptor;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "file"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-ne p0, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0
.end method


# virtual methods
.method public ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;
    .locals 13
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "messageClass",
            "builderClass"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/protobuf/GeneratedMessage;",
            ">;",
            "Ljava/lang/Class<",
            "+",
            "Lcom/google/protobuf/GeneratedMessage$Builder;",
            ">;)",
            "Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;"
        }
    .end annotation

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->initialized:Z

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-eqz v0, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    return-object p0

    :cond_0
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-boolean v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->initialized:Z

    const/4 v12, 0x5

    if-eqz v0, :cond_1

    const/4 v12, 0x4

    const/4 v11, 0x0

    monitor-exit p0

    const/4 v12, 0x3

    const/4 v11, 0x5

    return-object p0

    :cond_1
    const/4 v11, 0x7

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    array-length v0, v0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v1, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    const/4 v3, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x4

    if-ge v2, v0, :cond_a

    const/4 v11, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-object v4, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v4}, Lcom/google/protobuf/Descriptors$Descriptor;->getFields()Ljava/util/List;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    move-object v6, v4

    move-object v6, v4

    move-object v6, v4

    move-object v6, v4

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    check-cast v6, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-eqz v4, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getContainingOneof()Lcom/google/protobuf/Descriptors$OneofDescriptor;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v4}, Lcom/google/protobuf/Descriptors$OneofDescriptor;->getIndex()I

    move-result v4

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    add-int/2addr v4, v0

    const/4 v12, 0x5

    const/4 v11, 0x7

    aget-object v3, v3, v4

    :cond_2
    move-object v10, v3

    move-object v10, v3

    move-object v10, v3

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    if-eqz v3, :cond_6

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-ne v3, v4, :cond_4

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isMapField()Z

    move-result v3

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-eqz v3, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-direct {p0, v6}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->isMapFieldEnabled(Lcom/google/protobuf/Descriptors$FieldDescriptor;)Z

    move-result v3

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x2

    if-eqz v3, :cond_3

    const/4 v12, 0x6

    const/4 v11, 0x7

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$MapFieldAccessor;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    aget-object v5, v5, v2

    const/4 v12, 0x5

    invoke-direct {v4, v6, v5, p1, p2}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$MapFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    aput-object v4, v3, v2

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedMessageFieldAccessor;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x7

    aget-object v5, v5, v2

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct {v4, v6, v5, p1, p2}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedMessageFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    aput-object v4, v3, v2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    goto/16 :goto_1

    :cond_4
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    if-ne v3, v4, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x3

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedEnumFieldAccessor;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    aget-object v5, v5, v2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-direct {v4, v6, v5, p1, p2}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedEnumFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V

    const/4 v11, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    aput-object v4, v3, v2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    goto/16 :goto_1

    :cond_5
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedFieldAccessor;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    aget-object v5, v5, v2

    const/4 v12, 0x4

    const/4 v11, 0x6

    invoke-direct {v4, v6, v5, p1, p2}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$RepeatedFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    aput-object v4, v3, v2

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    goto/16 :goto_1

    :cond_6
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v3

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->MESSAGE:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x7

    if-ne v3, v4, :cond_7

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularMessageFieldAccessor;

    const/4 v12, 0x4

    const/4 v11, 0x3

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x5

    aget-object v7, v5, v2

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-direct/range {v5 .. v10}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularMessageFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    aput-object v4, v3, v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    goto/16 :goto_1

    :cond_7
    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v3

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x3

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->ENUM:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x7

    if-ne v3, v4, :cond_8

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x5

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularEnumFieldAccessor;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    aget-object v7, v5, v2

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-direct/range {v5 .. v10}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularEnumFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    aput-object v4, v3, v2

    const/4 v11, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    goto :goto_1

    :cond_8
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v6}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getJavaType()Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x2

    sget-object v4, Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;->STRING:Lcom/google/protobuf/Descriptors$FieldDescriptor$JavaType;

    const/4 v11, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-ne v3, v4, :cond_9

    const/4 v12, 0x2

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularStringFieldAccessor;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    aget-object v7, v5, v2

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-direct/range {v5 .. v10}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularStringFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    aput-object v4, v3, v2

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    goto :goto_1

    :cond_9
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->fields:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$FieldAccessor;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    new-instance v4, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget-object v5, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    aget-object v7, v5, v2

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-direct/range {v5 .. v10}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$SingularFieldAccessor;-><init>(Lcom/google/protobuf/Descriptors$FieldDescriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x1

    aput-object v4, v3, v2

    :goto_1
    const/4 v12, 0x4

    const/4 v11, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v12, 0x1

    goto/16 :goto_0

    :cond_a
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->oneofs:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    array-length v2, v2

    :goto_2
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-ge v1, v2, :cond_b

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object v4, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->oneofs:[Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    new-instance v5, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;

    const/4 v12, 0x3

    iget-object v6, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-object v7, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    add-int v8, v1, v0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    aget-object v7, v7, v8

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-direct {v5, v6, v7, p1, p2}, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable$OneofAccessor;-><init>(Lcom/google/protobuf/Descriptors$Descriptor;Ljava/lang/String;Ljava/lang/Class;Ljava/lang/Class;)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    aput-object v5, v4, v1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    goto :goto_2

    :cond_b
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 p1, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    iput-boolean p1, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->initialized:Z

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    iput-object v3, p0, Lcom/google/protobuf/GeneratedMessage$FieldAccessorTable;->camelCaseNames:[Ljava/lang/String;

    const/4 v12, 0x3

    monitor-exit p0

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    return-object p0

    :catchall_0
    move-exception p1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x4

    throw p1
.end method
