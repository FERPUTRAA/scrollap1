.class public interface abstract Lcom/google/protobuf/DescriptorProtos$GeneratedCodeInfo$AnnotationOrBuilder;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/protobuf/MessageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos$GeneratedCodeInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "AnnotationOrBuilder"
.end annotation


# virtual methods
.method public abstract getBegin()I
.end method

.method public abstract getEnd()I
.end method

.method public abstract getPath(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation
.end method

.method public abstract getPathCount()I
.end method

.method public abstract getPathList()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end method

.method public abstract getSemantic()Lcom/google/protobuf/DescriptorProtos$GeneratedCodeInfo$Annotation$Semantic;
.end method

.method public abstract getSourceFile()Ljava/lang/String;
.end method

.method public abstract getSourceFileBytes()Lcom/google/protobuf/ByteString;
.end method

.method public abstract hasBegin()Z
.end method

.method public abstract hasEnd()Z
.end method

.method public abstract hasSemantic()Z
.end method

.method public abstract hasSourceFile()Z
.end method
