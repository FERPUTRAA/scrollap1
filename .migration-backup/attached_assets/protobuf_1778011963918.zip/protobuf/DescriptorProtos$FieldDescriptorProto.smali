.class public final Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProtoOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FieldDescriptorProto"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;,
        Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;,
        Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

.field public static final DEFAULT_VALUE_FIELD_NUMBER:I = 0x7

.field public static final EXTENDEE_FIELD_NUMBER:I = 0x2

.field public static final JSON_NAME_FIELD_NUMBER:I = 0xa

.field public static final LABEL_FIELD_NUMBER:I = 0x4

.field public static final NAME_FIELD_NUMBER:I = 0x1

.field public static final NUMBER_FIELD_NUMBER:I = 0x3

.field public static final ONEOF_INDEX_FIELD_NUMBER:I = 0x9

.field public static final OPTIONS_FIELD_NUMBER:I = 0x8

.field public static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final PROTO3_OPTIONAL_FIELD_NUMBER:I = 0x11

.field public static final TYPE_FIELD_NUMBER:I = 0x5

.field public static final TYPE_NAME_FIELD_NUMBER:I = 0x6

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private volatile defaultValue_:Ljava/lang/Object;

.field private volatile extendee_:Ljava/lang/Object;

.field private volatile jsonName_:Ljava/lang/Object;

.field private label_:I

.field private memoizedIsInitialized:B

.field private volatile name_:Ljava/lang/Object;

.field private number_:I

.field private oneofIndex_:I

.field private options_:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

.field private proto3Optional_:Z

.field private volatile typeName_:Ljava/lang/Object;

.field private type_:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$1;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$1;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->number_:I

    const/4 v4, 0x5

    const/4 v2, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    iput v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->oneofIndex_:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->proto3Optional_:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-byte v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->memoizedIsInitialized:B

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->number_:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->oneofIndex_:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->proto3Optional_:Z

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-byte p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->memoizedIsInitialized:B

    const/4 v3, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/google/protobuf/DescriptorProtos$1;)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic access$8400(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o so~~b ~~o~@Sflv4to~~/n1@~~@s@ t ~@~bM~a/~ @um-o  @@~K~r.@f~ i i@   ~l~@~~od@b~@ @i @c  @@@y@~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$8402(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v0, 0x0

    move v1, v0

    return-object p1
.end method

.method static synthetic access$8502(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;I)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->number_:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic access$8602(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;I)I
    .locals 2

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    return p1
.end method

.method static synthetic access$8702(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v0, 0x6

    move v1, v0

    return p1
.end method

.method static synthetic access$8800(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$8802(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p1
.end method

.method static synthetic access$8900(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$8902(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$9000(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$9002(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method static synthetic access$9102(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->oneofIndex_:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$9200(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$9202(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method static synthetic access$9302(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Lcom/google/protobuf/DescriptorProtos$FieldOptions;)Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->options_:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$9402(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;Z)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->proto3Optional_:Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$9576(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    or-int/2addr p1, v0

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p1
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x1

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos;->access$7900()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;->mergeFrom(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v1, 0x6

    move v2, v1

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x1

    move v5, v0

    const/4 v4, 0x3

    move v5, v4

    if-ne p1, p0, :cond_0

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    instance-of v1, p1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    return p1

    :cond_1
    const/4 v5, 0x2

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasName()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasName()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eq v1, v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v3

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasName()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v1, :cond_3

    return v3

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasNumber()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasNumber()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eq v1, v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    return v3

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasNumber()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getNumber()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getNumber()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eq v1, v2, :cond_5

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    return v3

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasLabel()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasLabel()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v1, v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v3

    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasLabel()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v2, p1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v1, v2, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v3

    :cond_7
    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasType()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasType()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eq v1, v2, :cond_8

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v3

    :cond_8
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasType()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v2, p1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    if-eq v1, v2, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    return v3

    :cond_9
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasTypeName()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasTypeName()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v1, v2, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    return v3

    :cond_a
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasTypeName()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v1, :cond_b

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v1, :cond_b

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v3

    :cond_b
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v2, :cond_c

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v3

    :cond_c
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_d

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getExtendee()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getExtendee()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v1, :cond_d

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    return v3

    :cond_d
    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eq v1, v2, :cond_e

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v3

    :cond_e
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v1, :cond_f

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v1, :cond_f

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    return v3

    :cond_f
    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOneofIndex()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOneofIndex()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eq v1, v2, :cond_10

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v3

    :cond_10
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOneofIndex()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v1, :cond_11

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOneofIndex()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOneofIndex()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eq v1, v2, :cond_11

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    return v3

    :cond_11
    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasJsonName()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasJsonName()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v1, v2, :cond_12

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v3

    :cond_12
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasJsonName()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_13

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getJsonName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getJsonName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v1, :cond_13

    const/4 v5, 0x7

    const/4 v4, 0x2

    return v3

    :cond_13
    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOptions()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOptions()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eq v1, v2, :cond_14

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v3

    :cond_14
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOptions()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_15

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v1, :cond_15

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v3

    :cond_15
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasProto3Optional()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasProto3Optional()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eq v1, v2, :cond_16

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v3

    :cond_16
    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasProto3Optional()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v1, :cond_17

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getProto3Optional()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getProto3Optional()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eq v1, v2, :cond_17

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v3

    :cond_17
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_18

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v3

    :cond_18
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-object v0
.end method

.method public getDefaultValue()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v1
.end method

.method public getDefaultValueBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0
.end method

.method public getExtendee()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    return-object v1
.end method

.method public getExtendeeBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0
.end method

.method public getJsonName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    return-object v1
.end method

.method public getJsonNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method public getLabel()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;->LABEL_OPTIONAL:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Label;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v1
.end method

.method public getNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public getNumber()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->number_:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public getOneofIndex()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->oneofIndex_:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->options_:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method public getOptionsOrBuilder()Lcom/google/protobuf/DescriptorProtos$FieldOptionsOrBuilder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->options_:Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getProto3Optional()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->proto3Optional_:Z

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v0, v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    and-int/2addr v0, v1

    const/4 v2, 0x0

    shl-int/2addr v5, v2

    xor-int/2addr v4, v2

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    and-int/lit8 v0, v0, 0x20

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    and-int/2addr v5, v4

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-static {v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/2addr v2, v0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    and-int/2addr v0, v1

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v0, 0x3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->number_:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_3
    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x4

    or-int/2addr v5, v1

    const/4 v4, 0x6

    or-int/2addr v5, v4

    and-int/2addr v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    add-int/2addr v2, v0

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/16 v1, 0x8

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    and-int/2addr v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v0, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v0, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v3}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    add-int/2addr v2, v0

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    and-int/lit8 v0, v0, 0x10

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v0, 0x6

    const/4 v5, 0x1

    const/4 v4, 0x4

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v3}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/2addr v2, v0

    :cond_6
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    and-int/lit8 v0, v0, 0x40

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v0, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v0, 0x7

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v3}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    add-int/2addr v2, v0

    :cond_7
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    and-int/lit16 v0, v0, 0x200

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v0, :cond_8

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v1, v0}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_8
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    and-int/lit16 v0, v0, 0x80

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_9

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 v0, 0x9

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->oneofIndex_:I

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeInt32Size(II)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_9
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    and-int/lit16 v0, v0, 0x100

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_a

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/16 v0, 0xa

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->computeStringSize(ILjava/lang/Object;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    add-int/2addr v2, v0

    :cond_a
    const/4 v5, 0x0

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x2

    const/4 v5, 0x0

    and-int/lit16 v0, v0, 0x400

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eqz v0, :cond_b

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v0, 0x11

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->proto3Optional_:Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/2addr v2, v0

    :cond_b
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/2addr v2, v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput v2, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v2
.end method

.method public getType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;->TYPE_DOUBLE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Type;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTypeName()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->toStringUtf8()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/ByteString;->isValidUtf8()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    return-object v1
.end method

.method public getTypeNameBytes()Lcom/google/protobuf/ByteString;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    instance-of v1, v0, Ljava/lang/String;

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->copyFromUtf8(Ljava/lang/String;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast v0, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0
.end method

.method public hasDefaultValue()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x40

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public hasExtendee()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    and-int/lit8 v0, v0, 0x20

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public hasJsonName()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    and-int/lit16 v0, v0, 0x100

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public hasLabel()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public hasName()Z
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public hasNumber()Z
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public hasOneofIndex()Z
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    and-int/lit16 v0, v0, 0x80

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public hasOptions()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit16 v0, v0, 0x200

    const/4 v2, 0x7

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public hasProto3Optional()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    and-int/lit16 v0, v0, 0x400

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public hasType()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public hasTypeName()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/16 v1, 0x30b

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasName()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x7

    const/4 v2, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasNumber()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x5

    move v3, v2

    add-int/lit8 v1, v1, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getNumber()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasLabel()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasType()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz v0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasTypeName()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_5

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x6

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getTypeName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasExtendee()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getExtendee()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-int/2addr v1, v0

    :cond_6
    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasDefaultValue()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_7

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x7

    const/4 v2, 0x6

    or-int/2addr v3, v2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getDefaultValue()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    add-int/2addr v1, v0

    :cond_7
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOneofIndex()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_8

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x1

    add-int/lit8 v1, v1, 0x9

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOneofIndex()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_8
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasJsonName()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_9

    const/4 v2, 0x6

    move v3, v2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getJsonName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/2addr v1, v0

    :cond_9
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOptions()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_a

    const/4 v3, 0x5

    mul-int/lit8 v1, v1, 0x25

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/2addr v1, v0

    :cond_a
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasProto3Optional()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_b

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x11

    const/4 v3, 0x4

    const/4 v2, 0x6

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getProto3Optional()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/2addr v1, v0

    :cond_b
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/2addr v1, v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos;->access$8000()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v4, 0x7

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const/4 v4, 0x2

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-byte v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->memoizedIsInitialized:B

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-ne v0, v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v2

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->hasOptions()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FieldOptions;->isInitialized()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-byte v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->memoizedIsInitialized:B

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    return v2

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-byte v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->memoizedIsInitialized:B

    const/4 v4, 0x6

    const/4 v3, 0x0

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->newBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    new-instance p1, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne p0, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;-><init>(Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;-><init>(Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;->mergeFrom(Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;)Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->name_:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    and-int/lit8 v0, v0, 0x20

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->extendee_:Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    and-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v0, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->number_:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    and-int/2addr v0, v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->label_:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/16 v1, 0x8

    const/4 v4, 0x1

    and-int/2addr v0, v1

    const/4 v4, 0x6

    if-eqz v0, :cond_4

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->type_:I

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v2}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_4
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    and-int/lit8 v0, v0, 0x10

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->typeName_:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p1, v0, v2}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_5
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    and-int/lit8 v0, v0, 0x40

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v0, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v0, 0x7

    const/4 v4, 0x5

    const/4 v3, 0x6

    iget-object v2, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->defaultValue_:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-static {p1, v0, v2}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_6
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    and-int/lit16 v0, v0, 0x200

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_7

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$FieldOptions;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    and-int/lit16 v0, v0, 0x80

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_8

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 v0, 0x9

    const/4 v4, 0x5

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->oneofIndex_:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeInt32(II)V

    :cond_8
    const/4 v4, 0x0

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    and-int/lit16 v0, v0, 0x100

    const/4 v4, 0x3

    if-eqz v0, :cond_9

    const/4 v3, 0x6

    move v4, v3

    const/16 v0, 0xa

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->jsonName_:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v0, v1}, Lcom/google/protobuf/GeneratedMessageV3;->writeString(Lcom/google/protobuf/CodedOutputStream;ILjava/lang/Object;)V

    :cond_9
    const/4 v4, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->bitField0_:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    and-int/lit16 v0, v0, 0x400

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_a

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/16 v0, 0x11

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/google/protobuf/DescriptorProtos$FieldDescriptorProto;->proto3Optional_:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_a
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x0

    return-void
.end method
