.class final enum Lcom/google/protobuf/FieldType$Collection;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/FieldType;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4018
    name = "Collection"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/FieldType$Collection;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/FieldType$Collection;

.field public static final enum MAP:Lcom/google/protobuf/FieldType$Collection;

.field public static final enum PACKED_VECTOR:Lcom/google/protobuf/FieldType$Collection;

.field public static final enum SCALAR:Lcom/google/protobuf/FieldType$Collection;

.field public static final enum VECTOR:Lcom/google/protobuf/FieldType$Collection;


# instance fields
.field private final isList:Z


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    new-instance v0, Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string v1, "ALsRsC"

    const-string v1, "ARsCLS"

    const-string v1, "SCALAR"

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v2, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {v0, v1, v2, v2}, Lcom/google/protobuf/FieldType$Collection;-><init>(Ljava/lang/String;IZ)V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    sput-object v0, Lcom/google/protobuf/FieldType$Collection;->SCALAR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance v1, Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string v3, "ORmmVE"

    const-string v3, "TEVmOR"

    const/4 v10, 0x3

    const-string v3, "OERCoT"

    const-string v3, "VECTOR"

    const/4 v10, 0x1

    const/4 v4, 0x1

    const/4 v10, 0x0

    shr-int/2addr v9, v4

    const/4 v10, 0x6

    invoke-direct {v1, v3, v4, v4}, Lcom/google/protobuf/FieldType$Collection;-><init>(Ljava/lang/String;IZ)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    sput-object v1, Lcom/google/protobuf/FieldType$Collection;->VECTOR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    new-instance v3, Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string/jumbo v5, "oTEERbCPK_CVA"

    const-string v5, "E_PCoCEAVKRTO"

    const/4 v10, 0x6

    const-string v5, "ERECOCuDKTAV_"

    const-string v5, "PACKED_VECTOR"

    const/4 v9, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v6, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {v3, v5, v6, v4}, Lcom/google/protobuf/FieldType$Collection;-><init>(Ljava/lang/String;IZ)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    sput-object v3, Lcom/google/protobuf/FieldType$Collection;->PACKED_VECTOR:Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x5

    const/4 v9, 0x1

    new-instance v5, Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string v7, "PMA"

    const-string v7, "MPA"

    const/4 v10, 0x5

    const-string v7, "MPA"

    const-string v7, "MAP"

    const/4 v9, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v8, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-direct {v5, v7, v8, v2}, Lcom/google/protobuf/FieldType$Collection;-><init>(Ljava/lang/String;IZ)V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    sput-object v5, Lcom/google/protobuf/FieldType$Collection;->MAP:Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v7, 0x4

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    new-array v7, v7, [Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    aput-object v0, v7, v2

    const/4 v9, 0x5

    move v10, v9

    aput-object v1, v7, v4

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    aput-object v3, v7, v6

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    aput-object v5, v7, v8

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    sput-object v7, Lcom/google/protobuf/FieldType$Collection;->$VALUES:[Lcom/google/protobuf/FieldType$Collection;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IZ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "isList"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p3, p0, Lcom/google/protobuf/FieldType$Collection;->isList:Z

    const/4 v1, 0x3

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/FieldType$Collection;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o  d@@~p~ b@s@~~o.~~Kv~~o /t ~@f ~~bio@c~/ ~@SM~u@to@  ~lr~l@~~n@f~1@@io~@~@@ -   yimb@  4~  @@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-class v0, Lcom/google/protobuf/FieldType$Collection;

    const-class v0, Lcom/google/protobuf/FieldType$Collection;

    const-class v0, Lcom/google/protobuf/FieldType$Collection;

    const-class v0, Lcom/google/protobuf/FieldType$Collection;

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/FieldType$Collection;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/FieldType$Collection;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/FieldType$Collection;->$VALUES:[Lcom/google/protobuf/FieldType$Collection;

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lcom/google/protobuf/FieldType$Collection;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast v0, [Lcom/google/protobuf/FieldType$Collection;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public isList()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/google/protobuf/FieldType$Collection;->isList:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method
