.class public final Lcom/google/protobuf/BoolValue;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/google/protobuf/BoolValueOrBuilder;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/BoolValue$Builder;
    }
.end annotation


# static fields
.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

.field private static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/BoolValue;",
            ">;"
        }
    .end annotation
.end field

.field public static final VALUE_FIELD_NUMBER:I = 0x1

.field private static final serialVersionUID:J


# instance fields
.field private memoizedIsInitialized:B

.field private value_:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance v0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/protobuf/BoolValue;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    sput-object v0, Lcom/google/protobuf/BoolValue;->DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Lcom/google/protobuf/BoolValue$1;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/protobuf/BoolValue$1;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    const/4 v0, 0x0

    shr-int/2addr v2, v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/google/protobuf/BoolValue;->value_:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-byte v0, p0, Lcom/google/protobuf/BoolValue;->memoizedIsInitialized:B

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x3

    move v0, p1

    move v0, p1

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/google/protobuf/BoolValue;->value_:Z

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p1, -0x1

    const/4 v1, 0x4

    const/4 v0, 0x3

    iput-byte p1, p0, Lcom/google/protobuf/BoolValue;->memoizedIsInitialized:B

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/google/protobuf/BoolValue$1;)V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/google/protobuf/BoolValue;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$302(Lcom/google/protobuf/BoolValue;Z)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~isM~@@@ @@~@/ ~ ob~ m  @@4~S K~~~y ~o~1i b@@u@drl t@o~~ sai @@~@bf @~@/o~~~lo~@~ ctn f~~- @vo @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/google/protobuf/BoolValue;->value_:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p1
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/BoolValue;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/BoolValue;->DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/WrappersProto;->internal_static_google_protobuf_BoolValue_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v1, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/BoolValue$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/BoolValue;->DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/BoolValue;->toBuilder()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/BoolValue;)Lcom/google/protobuf/BoolValue$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/BoolValue;->DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/BoolValue;->toBuilder()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Lcom/google/protobuf/BoolValue$Builder;->mergeFrom(Lcom/google/protobuf/BoolValue;)Lcom/google/protobuf/BoolValue$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public static of(Z)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/BoolValue;->newBuilder()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Lcom/google/protobuf/BoolValue$Builder;->setValue(Z)Lcom/google/protobuf/BoolValue$Builder;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue$Builder;->build()Lcom/google/protobuf/BoolValue;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/BoolValue;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    check-cast p0, Lcom/google/protobuf/BoolValue;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/BoolValue;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x0

    if-ne p1, p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    return v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    instance-of v1, p1, Lcom/google/protobuf/BoolValue;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x5

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return p1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    check-cast p1, Lcom/google/protobuf/BoolValue;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->getValue()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/BoolValue;->getValue()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eq v1, v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    return v3

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez p1, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v3

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/BoolValue;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/BoolValue;->DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->getDefaultInstanceForType()Lcom/google/protobuf/BoolValue;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->getDefaultInstanceForType()Lcom/google/protobuf/BoolValue;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/BoolValue;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/BoolValue;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq v0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-boolean v0, p0, Lcom/google/protobuf/BoolValue;->value_:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v2, v0}, Lcom/google/protobuf/CodedOutputStream;->computeBoolSize(IZ)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    add-int/2addr v1, v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v4, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v1, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return v1
.end method

.method public getValue()Z
    .locals 3

    iget-boolean v0, p0, Lcom/google/protobuf/BoolValue;->value_:Z

    const/4 v1, 0x6

    move v2, v1

    return v0
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/protobuf/BoolValue;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/16 v1, 0x30b

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/2addr v1, v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->getValue()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v0, Lcom/google/protobuf/WrappersProto;->internal_static_google_protobuf_BoolValue_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-class v1, Lcom/google/protobuf/BoolValue;

    const-class v1, Lcom/google/protobuf/BoolValue;

    const/4 v4, 0x1

    const-class v1, Lcom/google/protobuf/BoolValue;

    const-class v1, Lcom/google/protobuf/BoolValue;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-class v2, Lcom/google/protobuf/BoolValue$Builder;

    const-class v2, Lcom/google/protobuf/BoolValue$Builder;

    const/4 v4, 0x2

    const-class v2, Lcom/google/protobuf/BoolValue$Builder;

    const-class v2, Lcom/google/protobuf/BoolValue$Builder;

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-byte v0, p0, Lcom/google/protobuf/BoolValue;->memoizedIsInitialized:B

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0

    :cond_1
    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-byte v1, p0, Lcom/google/protobuf/BoolValue;->memoizedIsInitialized:B

    const/4 v2, 0x2

    and-int/2addr v3, v2

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/BoolValue$Builder;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/BoolValue;->newBuilder()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/BoolValue$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Lcom/google/protobuf/BoolValue$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/BoolValue$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/BoolValue$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->newBuilderForType()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BoolValue;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/BoolValue$Builder;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->newBuilderForType()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    new-instance p1, Lcom/google/protobuf/BoolValue;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p1}, Lcom/google/protobuf/BoolValue;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/BoolValue$Builder;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/google/protobuf/BoolValue;->DEFAULT_INSTANCE:Lcom/google/protobuf/BoolValue;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    if-ne p0, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/google/protobuf/BoolValue$Builder;

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/BoolValue$Builder;-><init>(Lcom/google/protobuf/BoolValue$1;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    new-instance v0, Lcom/google/protobuf/BoolValue$Builder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/google/protobuf/BoolValue$Builder;-><init>(Lcom/google/protobuf/BoolValue$1;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Lcom/google/protobuf/BoolValue$Builder;->mergeFrom(Lcom/google/protobuf/BoolValue;)Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->toBuilder()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BoolValue;->toBuilder()Lcom/google/protobuf/BoolValue$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-boolean v0, p0, Lcom/google/protobuf/BoolValue;->value_:Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, v1, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBool(IZ)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method
