.class public final Lcom/google/protobuf/FieldInfo$Builder;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/FieldInfo;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Builder"
.end annotation


# instance fields
.field private cachedSizeField:Ljava/lang/reflect/Field;

.field private enforceUtf8:Z

.field private enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

.field private field:Ljava/lang/reflect/Field;

.field private fieldNumber:I

.field private mapDefaultEntry:Ljava/lang/Object;

.field private oneof:Lcom/google/protobuf/OneofInfo;

.field private oneofStoredType:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private presenceField:Ljava/lang/reflect/Field;

.field private presenceMask:I

.field private required:Z

.field private type:Lcom/google/protobuf/FieldType;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/FieldInfo$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/FieldInfo$Builder;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public build()Lcom/google/protobuf/FieldInfo;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "i-s@@~ a @/bo@@~c ~~v~@o~M@.~@ i~ @~fr u@@~s l1~b~i@~@m@~o@ ono@@ @t f~ ~b@~~ tyd~~ ~4 ~ KSol  /"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->oneof:Lcom/google/protobuf/OneofInfo;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v2, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->oneofStoredType:Ljava/lang/Class;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-boolean v4, p0, Lcom/google/protobuf/FieldInfo$Builder;->enforceUtf8:Z

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object v5, p0, Lcom/google/protobuf/FieldInfo$Builder;->enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static/range {v0 .. v5}, Lcom/google/protobuf/FieldInfo;->forOneofMemberField(ILcom/google/protobuf/FieldType;Lcom/google/protobuf/OneofInfo;Ljava/lang/Class;ZLcom/google/protobuf/Internal$EnumVerifier;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    return-object v0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->mapDefaultEntry:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v1, v2, v0, v3}, Lcom/google/protobuf/FieldInfo;->forMapField(Ljava/lang/reflect/Field;ILjava/lang/Object;Lcom/google/protobuf/Internal$EnumVerifier;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-object v0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v4, p0, Lcom/google/protobuf/FieldInfo$Builder;->presenceField:Ljava/lang/reflect/Field;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz v4, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-boolean v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->required:Z

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x3

    iget v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget v5, p0, Lcom/google/protobuf/FieldInfo$Builder;->presenceMask:I

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-boolean v6, p0, Lcom/google/protobuf/FieldInfo$Builder;->enforceUtf8:Z

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v7, p0, Lcom/google/protobuf/FieldInfo$Builder;->enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/FieldInfo;->forLegacyRequiredField(Ljava/lang/reflect/Field;ILcom/google/protobuf/FieldType;Ljava/lang/reflect/Field;IZLcom/google/protobuf/Internal$EnumVerifier;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-object v0

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget v5, p0, Lcom/google/protobuf/FieldInfo$Builder;->presenceMask:I

    const/4 v9, 0x2

    const/4 v8, 0x6

    iget-boolean v6, p0, Lcom/google/protobuf/FieldInfo$Builder;->enforceUtf8:Z

    const/4 v9, 0x0

    const/4 v8, 0x5

    iget-object v7, p0, Lcom/google/protobuf/FieldInfo$Builder;->enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/FieldInfo;->forExplicitPresenceField(Ljava/lang/reflect/Field;ILcom/google/protobuf/FieldType;Ljava/lang/reflect/Field;IZLcom/google/protobuf/Internal$EnumVerifier;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-object v0

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-eqz v0, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->cachedSizeField:Ljava/lang/reflect/Field;

    const/4 v9, 0x4

    const/4 v8, 0x2

    if-nez v1, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v1, v2, v3, v0}, Lcom/google/protobuf/FieldInfo;->forFieldWithEnumVerifier(Ljava/lang/reflect/Field;ILcom/google/protobuf/FieldType;Lcom/google/protobuf/Internal$EnumVerifier;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x0

    return-object v0

    :cond_4
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    iget-object v4, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v2, v3, v4, v0, v1}, Lcom/google/protobuf/FieldInfo;->forPackedFieldWithEnumVerifier(Ljava/lang/reflect/Field;ILcom/google/protobuf/FieldType;Lcom/google/protobuf/Internal$EnumVerifier;Ljava/lang/reflect/Field;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    return-object v0

    :cond_5
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->cachedSizeField:Ljava/lang/reflect/Field;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-nez v0, :cond_6

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v8, 0x3

    xor-int/2addr v9, v8

    iget-boolean v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->enforceUtf8:Z

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v0, v1, v2, v3}, Lcom/google/protobuf/FieldInfo;->forField(Ljava/lang/reflect/Field;ILcom/google/protobuf/FieldType;Z)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    return-object v0

    :cond_6
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget v2, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v3, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v8, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v1, v2, v3, v0}, Lcom/google/protobuf/FieldInfo;->forPackedField(Ljava/lang/reflect/Field;ILcom/google/protobuf/FieldType;Ljava/lang/reflect/Field;)Lcom/google/protobuf/FieldInfo;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-object v0
.end method

.method public withCachedSizeField(Ljava/lang/reflect/Field;)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "cachedSizeField"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->cachedSizeField:Ljava/lang/reflect/Field;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public withEnforceUtf8(Z)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enforceUtf8"
        }
    .end annotation

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->enforceUtf8:Z

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public withEnumVerifier(Lcom/google/protobuf/Internal$EnumVerifier;)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enumVerifier"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->enumVerifier:Lcom/google/protobuf/Internal$EnumVerifier;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public withField(Ljava/lang/reflect/Field;)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "field"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->oneof:Lcom/google/protobuf/OneofInfo;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string/jumbo v0, "odCmeefaghlns.ltonnw enu dntbe is fiaoi"

    const-string v0, "bosnua e dwnisinCho g atefdfot enneill."

    const/4 v2, 0x0

    const-string/jumbo v0, "lfoioeo.nbn i ehf i danaCsdttnn eeg lwo"

    const-string v0, "Cannot set field when building a oneof."

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    throw p1
.end method

.method public withFieldNumber(I)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    const/4 v1, 0x4

    iput p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->fieldNumber:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method public withMapDefaultEntry(Ljava/lang/Object;)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mapDefaultEntry"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->mapDefaultEntry:Ljava/lang/Object;

    const/4 v1, 0x7

    return-object p0
.end method

.method public withOneof(Lcom/google/protobuf/OneofInfo;Ljava/lang/Class;)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "oneof",
            "oneofStoredType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/OneofInfo;",
            "Ljava/lang/Class<",
            "*>;)",
            "Lcom/google/protobuf/FieldInfo$Builder;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->field:Ljava/lang/reflect/Field;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/FieldInfo$Builder;->presenceField:Ljava/lang/reflect/Field;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->oneof:Lcom/google/protobuf/OneofInfo;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p2, p0, Lcom/google/protobuf/FieldInfo$Builder;->oneofStoredType:Ljava/lang/Class;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string p2, " seirbnFlthnr  in ltavpsnoeeeop Comew i ebvfenfdr neehddaeeco o"

    const-string/jumbo p2, "lo mewrtnsnved nh roen Ff e edvoa coC  ibsrihneenitedeaoeelppfe"

    const/4 v2, 0x1

    const-string/jumbo p2, "rtnse u woclFraindosvC o neentpvieenei   eeeer nopfelhahdfbdod "

    const-string p2, "Cannot set oneof when field or presenceField have been provided"

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw p1
.end method

.method public withPresence(Ljava/lang/reflect/Field;I)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "presenceField",
            "presenceMask"
        }
    .end annotation

    const/4 v2, 0x7

    const-string v0, "cnisoelpeFpee"

    const-string/jumbo v0, "peeloiescnFde"

    const/4 v2, 0x5

    const-string v0, "elniceseqdreF"

    const-string/jumbo v0, "presenceField"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p1, Ljava/lang/reflect/Field;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->presenceField:Ljava/lang/reflect/Field;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p2, p0, Lcom/google/protobuf/FieldInfo$Builder;->presenceMask:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public withRequired(Z)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "required"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->required:Z

    const/4 v1, 0x5

    return-object p0
.end method

.method public withType(Lcom/google/protobuf/FieldType;)Lcom/google/protobuf/FieldInfo$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/FieldInfo$Builder;->type:Lcom/google/protobuf/FieldType;

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method
