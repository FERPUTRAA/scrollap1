.class abstract Lcom/google/protobuf/BinaryWriter;
.super Lcom/google/protobuf/ByteOutput;

# interfaces
.implements Lcom/google/protobuf/Writer;


# annotations
.annotation runtime Lcom/google/protobuf/CheckReturnValue;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/BinaryWriter$UnsafeDirectWriter;,
        Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;,
        Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;,
        Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;
    }
.end annotation


# static fields
.field public static final DEFAULT_CHUNK_SIZE:I = 0x1000

.field private static final MAP_KEY_NUMBER:I = 0x1

.field private static final MAP_VALUE_NUMBER:I = 0x2


# instance fields
.field private final alloc:Lcom/google/protobuf/BufferAllocator;

.field final buffers:Ljava/util/ArrayDeque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayDeque<",
            "Lcom/google/protobuf/AllocatedBuffer;",
            ">;"
        }
    .end annotation
.end field

.field private final chunkSize:I

.field totalDoneBytes:I


# direct methods
.method private constructor <init>(Lcom/google/protobuf/BufferAllocator;I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/ByteOutput;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v0, Ljava/util/ArrayDeque;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/util/ArrayDeque;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-lez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v0, "lasco"

    const-string v0, "cosla"

    const/4 v3, 0x1

    const-string v0, "aolmc"

    const-string v0, "alloc"

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast p1, Lcom/google/protobuf/BufferAllocator;

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/google/protobuf/BinaryWriter;->alloc:Lcom/google/protobuf/BufferAllocator;

    const/4 v3, 0x2

    const/4 v2, 0x6

    iput p2, p0, Lcom/google/protobuf/BinaryWriter;->chunkSize:I

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const-string p2, "0ukboS  usi>met  nhcz"

    const-string p2, "bezmuSnc0h >utks e  i"

    const/4 v3, 0x7

    const-string p2, "e me b ushbz0ctk uS>i"

    const-string p2, "chunkSize must be > 0"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    throw p1
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/BufferAllocator;ILcom/google/protobuf/BinaryWriter$1;)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;-><init>(Lcom/google/protobuf/BufferAllocator;I)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$200(J)B
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "l~MfK@u~~S~@ua~i  y~o@l~/@~@tf o@.~~ s@@io  o ~@b/c @ @on@@@b ~~m-@~~~~ ~ 4 @~  v@~~dbt@ io 1~r@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/protobuf/BinaryWriter;->computeUInt64SizeNoTag(J)B

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p0
.end method

.method private static computeUInt64SizeNoTag(J)B
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-wide/16 v0, -0x80

    const-wide/16 v0, -0x80

    const/4 v7, 0x6

    const-wide/16 v0, -0x80

    const-wide/16 v0, -0x80

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    and-long/2addr v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    cmp-long v0, v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 p0, 0x1

    move v7, p0

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    return p0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    cmp-long v0, p0, v2

    const/4 v7, 0x3

    if-gez v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 p0, 0xa

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    return p0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-wide v0, -0x800000000L

    const-wide v0, -0x800000000L

    const/4 v7, 0x3

    const-wide v0, -0x800000000L

    const-wide v0, -0x800000000L

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    and-long/2addr v0, p0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    cmp-long v0, v0, v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v0, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v0, 0x6

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    int-to-byte v0, v0

    const/4 v6, 0x1

    move v7, v6

    const/16 v1, 0x1c

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    ushr-long/2addr p0, v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v0, 0x2

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-wide/32 v4, -0x200000

    const-wide/32 v4, -0x200000

    const/4 v7, 0x6

    const-wide/32 v4, -0x200000

    const-wide/32 v4, -0x200000

    const/4 v6, 0x2

    move v7, v6

    and-long/2addr v4, p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    cmp-long v1, v4, v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-int/lit8 v0, v0, 0x2

    const/4 v7, 0x5

    int-to-byte v0, v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/16 v1, 0xe

    const/4 v7, 0x6

    const/4 v6, 0x7

    ushr-long/2addr p0, v1

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-wide/16 v4, -0x4000

    const-wide/16 v4, -0x4000

    const/4 v7, 0x1

    const-wide/16 v4, -0x4000

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    and-long/2addr p0, v4

    const/4 v6, 0x6

    move v7, v6

    cmp-long p0, p0, v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz p0, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x6

    or-int/2addr v7, v6

    int-to-byte v0, v0

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    return v0
.end method

.method static isUnsafeDirectSupported()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/BinaryWriter$UnsafeDirectWriter;->access$000()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method static isUnsafeHeapSupported()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;->isSupported()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public static newDirectInstance(Lcom/google/protobuf/BufferAllocator;)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "alloc"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/16 v0, 0x1000

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/google/protobuf/BinaryWriter;->newDirectInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public static newDirectInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/BinaryWriter;->isUnsafeDirectSupported()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newUnsafeDirectInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newSafeDirectInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;

    move-result-object p0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public static newHeapInstance(Lcom/google/protobuf/BufferAllocator;)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "alloc"
        }
    .end annotation

    const/4 v2, 0x5

    const/16 v0, 0x1000

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/google/protobuf/BinaryWriter;->newHeapInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method

.method public static newHeapInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/google/protobuf/BinaryWriter;->isUnsafeHeapSupported()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newUnsafeHeapInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    move v2, v1

    invoke-static {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newSafeHeapInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;

    move-result-object p0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method static newSafeDirectInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;-><init>(Lcom/google/protobuf/BufferAllocator;I)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method static newSafeHeapInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeHeapWriter;-><init>(Lcom/google/protobuf/BufferAllocator;I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object v0
.end method

.method static newUnsafeDirectInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/BinaryWriter;->isUnsafeDirectSupported()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/google/protobuf/BinaryWriter$UnsafeDirectWriter;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeDirectWriter;-><init>(Lcom/google/protobuf/BufferAllocator;I)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo p1, "tdoUuo pfnpa oosaspiesopneet rn"

    const-string/jumbo p1, "useUoot fsonpp aeitaned ptnosro"

    const/4 v2, 0x7

    const-string/jumbo p1, "isnapptoqnero eetaUuo onpsfdrs "

    const-string p1, "Unsafe operations not supported"

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    throw p0
.end method

.method static newUnsafeHeapInstance(Lcom/google/protobuf/BufferAllocator;I)Lcom/google/protobuf/BinaryWriter;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/protobuf/BinaryWriter;->isUnsafeHeapSupported()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    new-instance v0, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1}, Lcom/google/protobuf/BinaryWriter$UnsafeHeapWriter;-><init>(Lcom/google/protobuf/BufferAllocator;I)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string p1, " tspssrort eopoeidUbponnuenast "

    const-string/jumbo p1, "tUonsb oerpuredfp iaeosnn tspto"

    const-string/jumbo p1, "rt merofdn paososUa neppsntouti"

    const-string p1, "Unsafe operations not supported"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    throw p0
.end method

.method private writeBoolList_Internal(ILcom/google/protobuf/BooleanArrayList;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p3, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/BooleanArrayList;->size()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2}, Lcom/google/protobuf/BooleanArrayList;->size()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ltz v0, :cond_0

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Lcom/google/protobuf/BooleanArrayList;->getBoolean(I)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeBool(Z)V

    const/4 v2, 0x2

    move v3, v2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    sub-int/2addr p2, p3

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 p2, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x2

    goto :goto_2

    :cond_1
    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p2}, Lcom/google/protobuf/BooleanArrayList;->size()I

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ltz p3, :cond_2

    const/4 v3, 0x1

    invoke-virtual {p2, p3}, Lcom/google/protobuf/BooleanArrayList;->getBoolean(I)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeBool(IZ)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method private writeBoolList_Internal(ILjava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p3, :cond_1

    const/4 v3, 0x7

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    if-ltz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v1, Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeBool(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    sub-int/2addr p2, p3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p2, 0x2

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    goto :goto_2

    :cond_1
    const/4 v3, 0x2

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ltz p3, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeBool(IZ)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method private writeDoubleList_Internal(ILcom/google/protobuf/DoubleArrayList;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p2}, Lcom/google/protobuf/DoubleArrayList;->size()I

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    mul-int/lit8 p3, p3, 0x8

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/DoubleArrayList;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x4

    if-ltz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Lcom/google/protobuf/DoubleArrayList;->getDouble(I)D

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeFixed64(J)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    sub-int/2addr p2, p3

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 p2, 0x2

    shr-int/2addr v4, p2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_2

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/DoubleArrayList;->size()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-ltz p3, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2, p3}, Lcom/google/protobuf/DoubleArrayList;->getDouble(I)D

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p1, v0, v1}, Lcom/google/protobuf/BinaryWriter;->writeDouble(ID)V

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method

.method private writeDoubleList_Internal(ILjava/util/List;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p3, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    mul-int/lit8 p3, p3, 0x8

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    if-ltz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast v1, Ljava/lang/Double;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v1, v2}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeFixed64(J)V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x0

    sub-int/2addr p2, p3

    const/4 v4, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 p2, 0x2

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_2

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-ltz p3, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v0, Ljava/lang/Double;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, p1, v0, v1}, Lcom/google/protobuf/BinaryWriter;->writeDouble(ID)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method private writeFixed32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    if-eqz p3, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    mul-int/lit8 p3, p3, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeFixed32(I)V

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    sub-int/2addr p2, p3

    const/4 v2, 0x1

    and-int/2addr v3, v2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x7

    const/4 p2, 0x4

    const/4 v3, 0x1

    const/4 p2, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_2

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ltz p3, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p2, p3}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeFixed32(II)V

    const/4 v3, 0x1

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method private writeFixed32List_Internal(ILjava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p3, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 p3, p3, 0x4

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeFixed32(I)V

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    sub-int/2addr p2, p3

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_2

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ltz p3, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeFixed32(II)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method private writeFixed64List_Internal(ILcom/google/protobuf/LongArrayList;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p3, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    mul-int/lit8 p3, p3, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ltz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeFixed64(J)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    sub-int/2addr p2, p3

    const/4 v4, 0x3

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_2

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p3

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-ltz p3, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, p3}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p0, p1, v0, v1}, Lcom/google/protobuf/Writer;->writeFixed64(IJ)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method private writeFixed64List_Internal(ILjava/util/List;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p3, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    mul-int/lit8 p3, p3, 0x8

    const/4 v4, 0x0

    const/4 v3, 0x5

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ltz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v1, Ljava/lang/Long;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeFixed64(J)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    sub-int/2addr p2, p3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 p2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_2

    :cond_1
    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ltz p3, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast v0, Ljava/lang/Long;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p0, p1, v0, v1}, Lcom/google/protobuf/Writer;->writeFixed64(IJ)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method private writeFloatList_Internal(ILcom/google/protobuf/FloatArrayList;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p3, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/FloatArrayList;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    mul-int/lit8 p3, p3, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/FloatArrayList;->size()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    if-ltz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p2, v0}, Lcom/google/protobuf/FloatArrayList;->getFloat(I)F

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeFixed32(I)V

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    sub-int/2addr p2, p3

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p2, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_2

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/google/protobuf/FloatArrayList;->size()I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ltz p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2, p3}, Lcom/google/protobuf/FloatArrayList;->getFloat(I)F

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter;->writeFloat(IF)V

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method private writeFloatList_Internal(ILjava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-eqz p3, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    mul-int/lit8 p3, p3, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/lit8 p3, p3, 0xa

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v1, Ljava/lang/Float;

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeFixed32(I)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x7

    sub-int/2addr p2, p3

    const/4 v3, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p2, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_2

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x7

    if-ltz p3, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v0, Ljava/lang/Float;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Float;->floatValue()F

    move-result v0

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter;->writeFloat(IF)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method private writeInt32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-eqz p3, :cond_1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x1

    mul-int/lit8 p3, p3, 0xa

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x5

    if-ltz v0, :cond_0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeInt32(I)V

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    sub-int/2addr p2, p3

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p2, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_2

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x1

    if-ltz p3, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, p3}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeInt32(II)V

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method private writeInt32List_Internal(ILjava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p3, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    mul-int/lit8 p3, p3, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x5

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-ltz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeInt32(I)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    sub-int/2addr p2, p3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p2, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_2

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ltz p3, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeInt32(II)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method private writeLazyString(ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    instance-of v0, p2, Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast p2, Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeString(ILjava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p2, Lcom/google/protobuf/ByteString;

    const/4 v1, 0x5

    move v2, v1

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeBytes(ILcom/google/protobuf/ByteString;)V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method static final writeMapEntryField(Lcom/google/protobuf/Writer;ILcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "writer",
            "fieldNumber",
            "fieldType",
            "object"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v0, Lcom/google/protobuf/BinaryWriter$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    aget v0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    packed-switch v0, :pswitch_data_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p3, "meeuopp: yuUnrtpo arfopdeuv la s"

    const-string p3, "atfpeluv oueypo rpunsU rm:d a ep"

    const/4 v3, 0x0

    const-string p3, ":ne rb pUuf molaotyeprvs tupd ea"

    const-string p3, "Unsupported map value type for: "

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0

    :pswitch_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    instance-of p2, p3, Lcom/google/protobuf/Internal$EnumLite;

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    check-cast p3, Lcom/google/protobuf/Internal$EnumLite;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {p3}, Lcom/google/protobuf/Internal$EnumLite;->getNumber()I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeEnum(II)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    instance-of p2, p3, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast p3, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeEnum(II)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p1, "Urippeutea  ecty  nxpmfdep nu.ne"

    const-string p1, "aempU ipercydx te.ppnnftu m  nee"

    const/4 v3, 0x1

    const-string p1, "Unexpected type for enum in map."

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    throw p0

    :pswitch_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast p3, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p0, p1, p3}, Lcom/google/protobuf/Writer;->writeBytes(ILcom/google/protobuf/ByteString;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto/16 :goto_0

    :pswitch_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p0, p1, p3}, Lcom/google/protobuf/Writer;->writeMessage(ILjava/lang/Object;)V

    const/4 v3, 0x0

    goto/16 :goto_0

    :pswitch_3
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    check-cast p3, Ljava/lang/Double;

    const/4 v3, 0x1

    invoke-virtual {p3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide p2

    const/4 v2, 0x5

    move v3, v2

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeDouble(ID)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto/16 :goto_0

    :pswitch_4
    const/4 v3, 0x0

    const/4 v2, 0x4

    check-cast p3, Ljava/lang/Float;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p3}, Ljava/lang/Float;->floatValue()F

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeFloat(IF)V

    const/4 v2, 0x7

    or-int/2addr v3, v2

    goto/16 :goto_0

    :pswitch_5
    const/4 v3, 0x6

    const/4 v2, 0x4

    check-cast p3, Ljava/lang/Long;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeUInt64(IJ)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto/16 :goto_0

    :pswitch_6
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    check-cast p3, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeUInt32(II)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto/16 :goto_0

    :pswitch_7
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p3, Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p0, p1, p3}, Lcom/google/protobuf/Writer;->writeString(ILjava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto/16 :goto_0

    :pswitch_8
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p3, Ljava/lang/Long;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeSInt64(IJ)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    goto/16 :goto_0

    :pswitch_9
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    check-cast p3, Ljava/lang/Integer;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeSInt32(II)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto/16 :goto_0

    :pswitch_a
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast p3, Ljava/lang/Long;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeSFixed64(IJ)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :pswitch_b
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast p3, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeSFixed32(II)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :pswitch_c
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast p3, Ljava/lang/Long;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeInt64(IJ)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :pswitch_d
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    check-cast p3, Ljava/lang/Integer;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeInt32(II)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :pswitch_e
    const/4 v3, 0x4

    check-cast p3, Ljava/lang/Long;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p3}, Ljava/lang/Long;->longValue()J

    move-result-wide p2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeFixed64(IJ)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :pswitch_f
    const/4 v2, 0x0

    move v3, v2

    check-cast p3, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeFixed32(II)V

    const/4 v2, 0x1

    and-int/2addr v3, v2

    goto :goto_0

    :pswitch_10
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    check-cast p3, Ljava/lang/Boolean;

    const/4 v3, 0x3

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeBool(IZ)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private writeSInt32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p3, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-int/lit8 p3, p3, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ltz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeSInt32(I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    sub-int/2addr p2, p3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p2, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_2

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x1

    if-ltz p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2, p3}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v0

    const/4 v3, 0x3

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeSInt32(II)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method private writeSInt32List_Internal(ILjava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p3, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x7

    mul-int/lit8 p3, p3, 0x5

    const/4 v3, 0x4

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ltz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeSInt32(I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    sub-int/2addr p2, p3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p2, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x7

    goto :goto_2

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ltz p3, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeSInt32(II)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method private writeSInt64List_Internal(ILcom/google/protobuf/LongArrayList;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz p3, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    mul-int/lit8 p3, p3, 0xa

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-ltz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p2, v0}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeSInt64(J)V

    const/4 v4, 0x1

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    sub-int/2addr p2, p3

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 p2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_2

    :cond_1
    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p3

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ltz p3, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p2, p3}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p0, p1, v0, v1}, Lcom/google/protobuf/Writer;->writeSInt64(IJ)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method private writeSInt64List_Internal(ILjava/util/List;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz p3, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    mul-int/lit8 p3, p3, 0xa

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-ltz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    check-cast v1, Ljava/lang/Long;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeSInt64(J)V

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    sub-int/2addr p2, p3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 p2, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    goto :goto_2

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x3

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-ltz p3, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast v0, Ljava/lang/Long;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p0, p1, v0, v1}, Lcom/google/protobuf/Writer;->writeSInt64(IJ)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method private writeUInt32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    if-eqz p3, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    mul-int/lit8 p3, p3, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ltz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    sub-int/2addr p2, p3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p2, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x5

    goto :goto_2

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p2}, Lcom/google/protobuf/IntArrayList;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    if-ltz p3, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2, p3}, Lcom/google/protobuf/IntArrayList;->getInt(I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeUInt32(II)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method private writeUInt32List_Internal(ILjava/util/List;Z)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p3, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x4

    const/4 v2, 0x3

    mul-int/lit8 p3, p3, 0x5

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/lit8 p3, p3, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v2, 0x3

    const/4 v2, 0x2

    if-ltz v0, :cond_0

    const/4 v2, 0x7

    move v3, v2

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    sub-int/2addr p2, p3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p2, 0x2

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_2

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ltz p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p0, p1, v0}, Lcom/google/protobuf/Writer;->writeUInt32(II)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 p3, p3, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method private writeUInt64List_Internal(ILcom/google/protobuf/LongArrayList;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz p3, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    mul-int/lit8 p3, p3, 0xa

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ltz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-virtual {p2, v0}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeVarint64(J)V

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    sub-int/2addr p2, p3

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p2, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_2

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p3

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x4

    if-ltz p3, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2, p3}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p0, p1, v0, v1}, Lcom/google/protobuf/Writer;->writeUInt64(IJ)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v3, 0x1

    move v4, v3

    return-void
.end method

.method private writeUInt64List_Internal(ILjava/util/List;Z)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x3

    if-eqz p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x0

    mul-int/lit8 p3, p3, 0xa

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    add-int/lit8 p3, p3, 0xa

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter;->requireSpace(I)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-ltz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast v1, Ljava/lang/Long;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeVarint64(J)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    sub-int/2addr p2, p3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v4, 0x4

    const/4 p2, 0x2

    const/4 v4, 0x4

    move v3, p2

    move v3, p2

    const/4 v4, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_2

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/lit8 p3, p3, -0x1

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ltz p3, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v0, Ljava/lang/Long;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-interface {p0, p1, v0, v1}, Lcom/google/protobuf/Writer;->writeUInt64(IJ)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    add-int/lit8 p3, p3, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method


# virtual methods
.method public final complete()Ljava/util/Queue;
    .locals 3
    .annotation build Lcom/google/protobuf/CanIgnoreReturnValue;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Queue<",
            "Lcom/google/protobuf/AllocatedBuffer;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->finishCurrentBuffer()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public final fieldOrder()Lcom/google/protobuf/Writer$FieldOrder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/Writer$FieldOrder;->DESCENDING:Lcom/google/protobuf/Writer$FieldOrder;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method abstract finishCurrentBuffer()V
.end method

.method public abstract getTotalBytesWritten()I
.end method

.method final newDirectBuffer()Lcom/google/protobuf/AllocatedBuffer;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->alloc:Lcom/google/protobuf/BufferAllocator;

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->chunkSize:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/protobuf/BufferAllocator;->allocateDirectBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method

.method final newDirectBuffer(I)Lcom/google/protobuf/AllocatedBuffer;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->alloc:Lcom/google/protobuf/BufferAllocator;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->chunkSize:I

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/google/protobuf/BufferAllocator;->allocateDirectBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1
.end method

.method final newHeapBuffer()Lcom/google/protobuf/AllocatedBuffer;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->alloc:Lcom/google/protobuf/BufferAllocator;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->chunkSize:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/google/protobuf/BufferAllocator;->allocateHeapBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method

.method final newHeapBuffer(I)Lcom/google/protobuf/AllocatedBuffer;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->alloc:Lcom/google/protobuf/BufferAllocator;

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->chunkSize:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Lcom/google/protobuf/BufferAllocator;->allocateHeapBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method

.method abstract requireSpace(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "size"
        }
    .end annotation
.end method

.method abstract writeBool(Z)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method public final writeBoolList(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    instance-of v0, p2, Lcom/google/protobuf/BooleanArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p2, Lcom/google/protobuf/BooleanArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeBoolList_Internal(ILcom/google/protobuf/BooleanArrayList;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeBoolList_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public final writeBytesList(ILjava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/google/protobuf/ByteString;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    check-cast v1, Lcom/google/protobuf/ByteString;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-interface {p0, p1, v1}, Lcom/google/protobuf/Writer;->writeBytes(ILcom/google/protobuf/ByteString;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public final writeDouble(ID)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p2, p3}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    move-result-wide p2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeFixed64(IJ)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public final writeDoubleList(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    instance-of v0, p2, Lcom/google/protobuf/DoubleArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast p2, Lcom/google/protobuf/DoubleArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeDoubleList_Internal(ILcom/google/protobuf/DoubleArrayList;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeDoubleList_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public final writeEnum(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeInt32(II)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public final writeEnumList(ILjava/util/List;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeInt32List(ILjava/util/List;Z)V

    const/4 v1, 0x0

    return-void
.end method

.method abstract writeFixed32(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method public final writeFixed32List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    instance-of v0, p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFixed32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFixed32List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method abstract writeFixed64(J)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method public final writeFixed64List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    instance-of v0, p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    check-cast p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFixed64List_Internal(ILcom/google/protobuf/LongArrayList;Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFixed64List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public final writeFloat(IF)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeFixed32(II)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public final writeFloatList(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    instance-of v0, p2, Lcom/google/protobuf/FloatArrayList;

    const/4 v1, 0x0

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    check-cast p2, Lcom/google/protobuf/FloatArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFloatList_Internal(ILcom/google/protobuf/FloatArrayList;Z)V

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFloatList_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public final writeGroupList(ILjava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    if-ltz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-interface {p0, p1, v1}, Lcom/google/protobuf/Writer;->writeGroup(ILjava/lang/Object;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    return-void
.end method

.method public final writeGroupList(ILjava/util/List;Lcom/google/protobuf/Schema;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "*>;",
            "Lcom/google/protobuf/Schema;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p0, p1, v1, p3}, Lcom/google/protobuf/Writer;->writeGroup(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method abstract writeInt32(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method public final writeInt32List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    instance-of v0, p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeInt32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeInt32List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public final writeInt64(IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeUInt64(IJ)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public final writeInt64List(ILjava/util/List;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeUInt64List(ILjava/util/List;Z)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public writeMap(ILcom/google/protobuf/MapEntryLite$Metadata;Ljava/util/Map;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "metadata",
            "map"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<K:",
            "Ljava/lang/Object;",
            "V:",
            "Ljava/lang/Object;",
            ">(I",
            "Lcom/google/protobuf/MapEntryLite$Metadata<",
            "TK;TV;>;",
            "Ljava/util/Map<",
            "TK;TV;>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {p3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {p3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p3

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->valueType:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v4, 0x2

    const/4 v6, 0x7

    invoke-static {p0, v4, v2, v3}, Lcom/google/protobuf/BinaryWriter;->writeMapEntryField(Lcom/google/protobuf/Writer;ILcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v2, p2, Lcom/google/protobuf/MapEntryLite$Metadata;->keyType:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p0, v3, v2, v0}, Lcom/google/protobuf/BinaryWriter;->writeMapEntryField(Lcom/google/protobuf/Writer;ILcom/google/protobuf/WireFormat$FieldType;Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    sub-int/2addr v0, v1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter;->writeVarint32(I)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0, p1, v4}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void
.end method

.method public final writeMessageList(ILjava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-interface {p0, p1, v1}, Lcom/google/protobuf/Writer;->writeMessage(ILjava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public final writeMessageList(ILjava/util/List;Lcom/google/protobuf/Schema;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "*>;",
            "Lcom/google/protobuf/Schema;",
            ")V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    if-ltz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p0, p1, v1, p3}, Lcom/google/protobuf/Writer;->writeMessage(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public final writeMessageSetItem(ILjava/lang/Object;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x4

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0, v1, v0}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    instance-of v0, p2, Lcom/google/protobuf/ByteString;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x3

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast p2, Lcom/google/protobuf/ByteString;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p0, v2, p2}, Lcom/google/protobuf/Writer;->writeBytes(ILcom/google/protobuf/ByteString;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p0, v2, p2}, Lcom/google/protobuf/Writer;->writeMessage(ILjava/lang/Object;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 p2, 0x2

    const/4 v4, 0x6

    invoke-interface {p0, p2, p1}, Lcom/google/protobuf/Writer;->writeUInt32(II)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p0, v1, v2}, Lcom/google/protobuf/BinaryWriter;->writeTag(II)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-void
.end method

.method public final writeSFixed32(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-interface {p0, p1, p2}, Lcom/google/protobuf/Writer;->writeFixed32(II)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public final writeSFixed32List(ILjava/util/List;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFixed32List(ILjava/util/List;Z)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public final writeSFixed64(IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-interface {p0, p1, p2, p3}, Lcom/google/protobuf/Writer;->writeFixed64(IJ)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public final writeSFixed64List(ILjava/util/List;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeFixed64List(ILjava/util/List;Z)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method abstract writeSInt32(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method public final writeSInt32List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    instance-of v0, p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeSInt32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeSInt32List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method abstract writeSInt64(J)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method public final writeSInt64List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    instance-of v0, p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeSInt64List_Internal(ILcom/google/protobuf/LongArrayList;Z)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeSInt64List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method abstract writeString(Ljava/lang/String;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "in"
        }
    .end annotation
.end method

.method public final writeStringList(ILjava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    instance-of v0, p2, Lcom/google/protobuf/LazyStringList;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v0, Lcom/google/protobuf/LazyStringList;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/lit8 p2, p2, -0x1

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ltz p2, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0, p2}, Lcom/google/protobuf/LazyStringList;->getRaw(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0, p1, v1}, Lcom/google/protobuf/BinaryWriter;->writeLazyString(ILjava/lang/Object;)V

    const/4 v3, 0x2

    add-int/lit8 p2, p2, -0x1

    const/4 v2, 0x4

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ltz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p0, p1, v1}, Lcom/google/protobuf/Writer;->writeString(ILjava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method abstract writeTag(II)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation
.end method

.method public final writeUInt32List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    instance-of v0, p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeUInt32List_Internal(ILcom/google/protobuf/IntArrayList;Z)V

    const/4 v1, 0x6

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeUInt32List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public final writeUInt64List(ILjava/util/List;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "list",
            "packed"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    instance-of v0, p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeUInt64List_Internal(ILcom/google/protobuf/LongArrayList;Z)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, p3}, Lcom/google/protobuf/BinaryWriter;->writeUInt64List_Internal(ILjava/util/List;Z)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method abstract writeVarint32(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method

.method abstract writeVarint64(J)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation
.end method
