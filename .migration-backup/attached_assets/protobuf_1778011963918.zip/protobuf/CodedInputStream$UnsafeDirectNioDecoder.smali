.class final Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;
.super Lcom/google/protobuf/CodedInputStream;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/CodedInputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "UnsafeDirectNioDecoder"
.end annotation


# instance fields
.field private final address:J

.field private final buffer:Ljava/nio/ByteBuffer;

.field private bufferSizeAfterLimit:I

.field private currentLimit:I

.field private enableAliasing:Z

.field private final immutable:Z

.field private lastTag:I

.field private limit:J

.field private pos:J

.field private startPos:J


# direct methods
.method private constructor <init>(Ljava/nio/ByteBuffer;Z)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "buffer",
            "immutable"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p0, v0}, Lcom/google/protobuf/CodedInputStream;-><init>(Lcom/google/protobuf/CodedInputStream$1;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const v0, 0x7fffffff

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->currentLimit:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/google/protobuf/UnsafeUtil;->addressOffset(Ljava/nio/ByteBuffer;)J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->address:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    int-to-long v2, v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-long/2addr v2, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/nio/Buffer;->position()I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    int-to-long v2, p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v5, 0x4

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->startPos:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput-boolean p2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->immutable:Z

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-void
.end method

.method synthetic constructor <init>(Ljava/nio/ByteBuffer;ZLcom/google/protobuf/CodedInputStream$1;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;-><init>(Ljava/nio/ByteBuffer;Z)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method private bufferPos(J)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pos"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s.@b~ 4~lio~c@~~l~-@@@msi~o~@@b@     @~a@ f@~~t@i~@~ ~~~K@ 1@d@ on@v @~oM@/~/~u~t~ob   fyS  o "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->address:J

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    sub-long/2addr p1, v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    long-to-int p1, p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p1
.end method

.method static isSupported()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/UnsafeUtil;->hasUnsafeByteBufferOperations()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method private recomputeBufferSizeAfterLimit()V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->bufferSizeAfterLimit:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    int-to-long v2, v2

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    add-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->startPos:J

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    sub-long v2, v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    long-to-int v2, v2

    const/4 v4, 0x7

    or-int/2addr v5, v4

    iget v3, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->currentLimit:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-le v2, v3, :cond_0

    const/4 v5, 0x0

    sub-int/2addr v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->bufferSizeAfterLimit:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    int-to-long v2, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    sub-long/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->bufferSizeAfterLimit:I

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method

.method private remaining()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v4, 0x2

    move v5, v4

    sub-long/2addr v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    long-to-int v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    return v0
.end method

.method private skipRawVarint()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/16 v1, 0xa

    const/4 v3, 0x7

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipRawVarintFastPath()V

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipRawVarintSlowPath()V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method private skipRawVarintFastPath()V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/16 v1, 0xa

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-ge v0, v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v6, 0x4

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    add-long/2addr v3, v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-wide v3, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v1, v2}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ltz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    throw v0
.end method

.method private skipRawVarintSlowPath()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v0, 0x0

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v3, 0x3

    const/16 v1, 0xa

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ge v0, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawByte()B

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ltz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw v0
.end method

.method private slice(JJ)Ljava/nio/ByteBuffer;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "begin",
            "end"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/nio/Buffer;->position()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/nio/Buffer;->limit()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->buffer:Ljava/nio/ByteBuffer;

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->bufferPos(J)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v2, p1}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, p3, p4}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->bufferPos(J)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v2, p1}, Ljava/nio/Buffer;->limit(I)Ljava/nio/Buffer;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2, v0}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Ljava/nio/Buffer;->limit(I)Ljava/nio/Buffer;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2, v0}, Ljava/nio/Buffer;->position(I)Ljava/nio/Buffer;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Ljava/nio/Buffer;->limit(I)Ljava/nio/Buffer;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    throw p1
.end method


# virtual methods
.method public checkLastTagWas(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->lastTag:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-ne v0, p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidEndTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    throw p1
.end method

.method public enableAliasing(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enabled"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->enableAliasing:Z

    const/4 v1, 0x1

    return-void
.end method

.method public getBytesUntilLimit()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->currentLimit:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    const v1, 0x7fffffff

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->getTotalBytesRead()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    sub-int/2addr v0, v1

    const/4 v3, 0x1

    return v0
.end method

.method public getLastTag()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->lastTag:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public getTotalBytesRead()I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->startPos:J

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    sub-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    long-to-int v0, v0

    const/4 v4, 0x7

    move v5, v4

    return v0
.end method

.method public isAtEnd()Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v4, 0x2

    or-int/2addr v5, v4

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    return v0
.end method

.method public popLimit(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "oldLimit"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->currentLimit:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public pushLimit(I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "byteLimit"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-ltz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->getTotalBytesRead()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    add-int/2addr p1, v0

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->currentLimit:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-gt p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput p1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->currentLimit:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->recomputeBufferSizeAfterLimit()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    throw p1
.end method

.method public readBool()Z
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    cmp-long v0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v0
.end method

.method public readByteArray()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawBytes(I)[B

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public readByteBuffer()Ljava/nio/ByteBuffer;
    .locals 14
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v13, 0x0

    const/4 v12, 0x2

    if-lez v0, :cond_1

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v1

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x4

    if-gt v0, v1, :cond_1

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x4

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->immutable:Z

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x4

    if-nez v1, :cond_0

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x5

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->enableAliasing:Z

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x7

    if-eqz v1, :cond_0

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    int-to-long v3, v0

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x1

    add-long v5, v1, v3

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-direct {p0, v1, v2, v5, v6}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->slice(JJ)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x2

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x3

    add-long/2addr v1, v3

    const/4 v12, 0x4

    move v13, v12

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x6

    return-object v0

    :cond_0
    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x7

    new-array v1, v0, [B

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x1

    iget-wide v3, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v13, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v13, 0x1

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x4

    int-to-long v10, v0

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-wide v8, v10

    const/4 v13, 0x1

    const/4 v12, 0x2

    invoke-static/range {v3 .. v9}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x1

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v13, 0x5

    const/4 v12, 0x5

    add-long/2addr v2, v10

    const/4 v13, 0x7

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-static {v1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x3

    return-object v0

    :cond_1
    const/4 v13, 0x2

    if-nez v0, :cond_2

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x1

    sget-object v0, Lcom/google/protobuf/Internal;->EMPTY_BYTE_BUFFER:Ljava/nio/ByteBuffer;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x7

    return-object v0

    :cond_2
    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x0

    if-gez v0, :cond_3

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x1

    throw v0

    :cond_3
    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x2

    throw v0
.end method

.method public readBytes()Lcom/google/protobuf/ByteString;
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    if-lez v0, :cond_1

    const/4 v11, 0x6

    const/4 v11, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v1

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-gt v0, v1, :cond_1

    const/4 v12, 0x7

    const/4 v11, 0x4

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->immutable:Z

    const/4 v12, 0x3

    const/4 v11, 0x3

    if-eqz v1, :cond_0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    iget-boolean v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->enableAliasing:Z

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-eqz v1, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    int-to-long v3, v0

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    add-long v5, v1, v3

    const/4 v12, 0x3

    invoke-direct {p0, v1, v2, v5, v6}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->slice(JJ)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    add-long/2addr v1, v3

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static {v0}, Lcom/google/protobuf/ByteString;->wrap(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    return-object v0

    :cond_0
    const/4 v12, 0x3

    new-array v8, v0, [B

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v11, 0x0

    shr-int/2addr v12, v11

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v12, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v12, 0x6

    int-to-long v9, v0

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-wide v6, v9

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v11, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x5

    add-long/2addr v0, v9

    const/4 v12, 0x7

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-static {v8}, Lcom/google/protobuf/ByteString;->wrap([B)Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    return-object v0

    :cond_1
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x1

    if-nez v0, :cond_2

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v12, 0x2

    return-object v0

    :cond_2
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-gez v0, :cond_3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    throw v0

    :cond_3
    const/4 v12, 0x1

    const/4 v11, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    throw v0
.end method

.method public readDouble()D
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0
.end method

.method public readEnum()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public readFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public readFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-wide v0
.end method

.method public readFloat()F
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x7

    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public readGroup(ILcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(I",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p2, Lcom/google/protobuf/MessageLite;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p3, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1, p3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->checkLastTagWas(I)V

    const/4 v1, 0x3

    move v2, v1

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object p2
.end method

.method public readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput v0, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {p2, p0, p3}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p2, 0x4

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->checkLastTagWas(I)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    add-int/lit8 p1, p1, -0x1

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public readInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    return v0
.end method

.method public readInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-wide v0
.end method

.method public readMessage(Lcom/google/protobuf/Parser;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "parser",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Lcom/google/protobuf/MessageLite;",
            ">(",
            "Lcom/google/protobuf/Parser<",
            "TT;>;",
            "Lcom/google/protobuf/ExtensionRegistryLite;",
            ")TT;"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/Parser;->parsePartialFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    check-cast p1, Lcom/google/protobuf/MessageLite;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p2, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->checkLastTagWas(I)V

    const/4 v3, 0x5

    iget p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    add-int/lit8 p2, p2, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput p2, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->getBytesUntilLimit()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->popLimit(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    throw p1
.end method

.method public readMessage(Lcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "builder",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream;->checkRecursionLimit()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pushLimit(I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput v1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v2, 0x4

    move v3, v2

    invoke-interface {p1, p0, p2}, Lcom/google/protobuf/MessageLite$Builder;->mergeFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/MessageLite$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->checkLastTagWas(I)V

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput p1, p0, Lcom/google/protobuf/CodedInputStream;->recursionDepth:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->getBytesUntilLimit()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->popLimit(I)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v3, 0x0

    throw p1
.end method

.method public readRawByte()B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v5, 0x7

    cmp-long v2, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-long/2addr v2, v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v0

    :cond_0
    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    throw v0
.end method

.method public readRawBytes(I)[B
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-ltz p1, :cond_0

    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-gt p1, v0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-array v0, p1, [B

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v8, 0x5

    const/4 v7, 0x7

    int-to-long v3, p1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    add-long v5, v1, v3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {p0, v1, v2, v5, v6}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->slice(JJ)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->get([B)Ljava/nio/ByteBuffer;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    add-long/2addr v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-object v0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    if-gtz p1, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-nez p1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x7

    sget-object p1, Lcom/google/protobuf/Internal;->EMPTY_BYTE_ARRAY:[B

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    return-object p1

    :cond_1
    const/4 v8, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    throw p1

    :cond_2
    const/4 v7, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    throw p1
.end method

.method public readRawLittleEndian32()I
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x1

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    sub-long/2addr v2, v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const-wide/16 v4, 0x4

    const-wide/16 v4, 0x4

    const/4 v7, 0x4

    const-wide/16 v4, 0x4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    cmp-long v2, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-ltz v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    add-long/2addr v4, v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-wide v4, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    and-int/lit16 v2, v2, 0xff

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-long/2addr v3, v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v3, v4}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    and-int/lit16 v3, v3, 0xff

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    shl-int/lit8 v3, v3, 0x8

    const/4 v6, 0x7

    or-int/2addr v7, v6

    or-int/2addr v2, v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-wide/16 v3, 0x2

    const-wide/16 v3, 0x2

    const/4 v7, 0x2

    const-wide/16 v3, 0x2

    const-wide/16 v3, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    add-long/2addr v3, v0

    const/4 v7, 0x4

    invoke-static {v3, v4}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    and-int/lit16 v3, v3, 0xff

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    shl-int/lit8 v3, v3, 0x10

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    or-int/2addr v2, v3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-wide/16 v3, 0x3

    const-wide/16 v3, 0x3

    const/4 v7, 0x2

    const-wide/16 v3, 0x3

    const-wide/16 v3, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-long/2addr v0, v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    and-int/lit16 v0, v0, 0xff

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    shl-int/lit8 v0, v0, 0x18

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    or-int/2addr v0, v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    return v0

    :cond_0
    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    throw v0
.end method

.method public readRawLittleEndian64()J
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v10, 0x3

    const/4 v9, 0x4

    sub-long/2addr v2, v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-wide/16 v4, 0x8

    const-wide/16 v4, 0x8

    const/4 v10, 0x4

    const-wide/16 v4, 0x8

    const-wide/16 v4, 0x8

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    cmp-long v2, v2, v4

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-ltz v2, :cond_0

    const/4 v10, 0x3

    add-long/2addr v4, v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    iput-wide v4, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v10, 0x5

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    int-to-long v2, v2

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const/4 v9, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    and-long/2addr v2, v4

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v10, 0x2

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    add-long/2addr v6, v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x1

    int-to-long v6, v6

    const/4 v9, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    and-long/2addr v6, v4

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/16 v8, 0x8

    const/4 v10, 0x5

    const/4 v9, 0x5

    shl-long/2addr v6, v8

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    or-long/2addr v2, v6

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-wide/16 v6, 0x2

    const-wide/16 v6, 0x2

    const/4 v10, 0x4

    const-wide/16 v6, 0x2

    const-wide/16 v6, 0x2

    const/4 v9, 0x5

    move v10, v9

    add-long/2addr v6, v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    int-to-long v6, v6

    const/4 v10, 0x2

    and-long/2addr v6, v4

    const/4 v10, 0x7

    const/16 v8, 0x10

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    shl-long/2addr v6, v8

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    or-long/2addr v2, v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-wide/16 v6, 0x3

    const-wide/16 v6, 0x3

    const/4 v10, 0x1

    const-wide/16 v6, 0x3

    const-wide/16 v6, 0x3

    const/4 v10, 0x0

    const/4 v9, 0x2

    add-long/2addr v6, v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    int-to-long v6, v6

    const/4 v10, 0x0

    const/4 v9, 0x4

    and-long/2addr v6, v4

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/16 v8, 0x18

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    shl-long/2addr v6, v8

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    or-long/2addr v2, v6

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-wide/16 v6, 0x4

    const-wide/16 v6, 0x4

    const/4 v10, 0x4

    const-wide/16 v6, 0x4

    const-wide/16 v6, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    add-long/2addr v6, v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v10, 0x0

    const/4 v9, 0x6

    int-to-long v6, v6

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    and-long/2addr v6, v4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v8, 0x20

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    shl-long/2addr v6, v8

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    or-long/2addr v2, v6

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-wide/16 v6, 0x5

    const-wide/16 v6, 0x5

    const/4 v10, 0x7

    const-wide/16 v6, 0x5

    const-wide/16 v6, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    add-long/2addr v6, v0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x3

    int-to-long v6, v6

    const/4 v10, 0x6

    const/4 v9, 0x5

    and-long/2addr v6, v4

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/16 v8, 0x28

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    shl-long/2addr v6, v8

    const/4 v10, 0x7

    const/4 v9, 0x1

    or-long/2addr v2, v6

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-wide/16 v6, 0x6

    const-wide/16 v6, 0x6

    const/4 v10, 0x5

    const-wide/16 v6, 0x6

    const-wide/16 v6, 0x6

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    add-long/2addr v6, v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    int-to-long v6, v6

    const/4 v10, 0x6

    const/4 v9, 0x0

    and-long/2addr v6, v4

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/16 v8, 0x30

    const/4 v9, 0x2

    move v10, v9

    shl-long/2addr v6, v8

    const/4 v9, 0x6

    and-int/2addr v10, v9

    or-long/2addr v2, v6

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-wide/16 v6, 0x7

    const-wide/16 v6, 0x7

    const/4 v10, 0x2

    const-wide/16 v6, 0x7

    const-wide/16 v6, 0x7

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    add-long/2addr v0, v6

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x4

    int-to-long v0, v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    and-long/2addr v0, v4

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/16 v4, 0x38

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    shl-long/2addr v0, v4

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    or-long/2addr v0, v2

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    return-wide v0

    :cond_0
    const/4 v9, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    throw v0
.end method

.method public readRawVarint32()I
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v11, 0x2

    const/4 v10, 0x4

    cmp-long v2, v2, v0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-nez v2, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v11, 0x2

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    add-long v4, v0, v2

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-ltz v0, :cond_1

    const/4 v10, 0x0

    const/4 v11, 0x1

    iput-wide v4, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v11, 0x1

    return v0

    :cond_1
    const/4 v11, 0x2

    const/4 v10, 0x5

    iget-wide v6, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    sub-long/2addr v6, v4

    const/4 v10, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-wide/16 v8, 0x9

    const-wide/16 v8, 0x9

    const/4 v11, 0x6

    const-wide/16 v8, 0x9

    const-wide/16 v8, 0x9

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    cmp-long v1, v6, v8

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-gez v1, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    add-long v6, v4, v2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    shl-int/lit8 v1, v1, 0x7

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    xor-int/2addr v0, v1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-gez v0, :cond_3

    const/4 v11, 0x0

    xor-int/lit8 v0, v0, -0x80

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto/16 :goto_1

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    add-long v4, v6, v2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    shl-int/lit8 v1, v1, 0xe

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    xor-int/2addr v0, v1

    const/4 v11, 0x0

    const/4 v10, 0x6

    if-ltz v0, :cond_5

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    xor-int/lit16 v0, v0, 0x3f80

    :cond_4
    move-wide v6, v4

    const/4 v11, 0x5

    const/4 v10, 0x3

    goto/16 :goto_1

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    add-long v6, v4, v2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    shl-int/lit8 v1, v1, 0x15

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    xor-int/2addr v0, v1

    const/4 v11, 0x0

    if-gez v0, :cond_6

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    const v1, -0x1fc080

    const/4 v10, 0x6

    move v11, v10

    xor-int/2addr v0, v1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto/16 :goto_1

    :cond_6
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    add-long v4, v6, v2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    shl-int/lit8 v6, v1, 0x1c

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    xor-int/2addr v0, v6

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    const v6, 0xfe03f80

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    xor-int/2addr v0, v6

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-gez v1, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    add-long v6, v4, v2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-gez v1, :cond_7

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    add-long v4, v6, v2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-gez v1, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    add-long v6, v4, v2

    const/4 v11, 0x2

    const/4 v10, 0x0

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-gez v1, :cond_7

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x5

    add-long v4, v6, v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-gez v1, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    add-long v6, v4, v2

    const/4 v11, 0x7

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    if-gez v1, :cond_7

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    long-to-int v0, v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    return v0

    :cond_7
    :goto_1
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    iput-wide v6, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    return v0
.end method

.method public readRawVarint64()J
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v12, 0x2

    cmp-long v2, v2, v0

    const/4 v11, 0x1

    const/4 v12, 0x5

    if-nez v2, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x3

    goto/16 :goto_4

    :cond_0
    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v12, 0x3

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    add-long v4, v0, v2

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v0, v1}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    if-ltz v0, :cond_1

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    iput-wide v4, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    int-to-long v0, v0

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x1

    return-wide v0

    :cond_1
    iget-wide v6, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->limit:J

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    sub-long/2addr v6, v4

    const/4 v12, 0x5

    const-wide/16 v8, 0x9

    const-wide/16 v8, 0x9

    const/4 v12, 0x3

    const-wide/16 v8, 0x9

    const-wide/16 v8, 0x9

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    cmp-long v1, v6, v8

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x2

    if-gez v1, :cond_2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    goto/16 :goto_4

    :cond_2
    const/4 v12, 0x3

    const/4 v11, 0x5

    add-long v6, v4, v2

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    shl-int/lit8 v1, v1, 0x7

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x1

    xor-int/2addr v0, v1

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-gez v0, :cond_3

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    xor-int/lit8 v0, v0, -0x80

    :goto_0
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    int-to-long v0, v0

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    goto/16 :goto_5

    :cond_3
    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    add-long v4, v6, v2

    const/4 v11, 0x7

    move v12, v11

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    shl-int/lit8 v1, v1, 0xe

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    xor-int/2addr v0, v1

    const/4 v11, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    if-ltz v0, :cond_5

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x1

    xor-int/lit16 v0, v0, 0x3f80

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    int-to-long v0, v0

    :cond_4
    :goto_1
    move-wide v6, v4

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    goto/16 :goto_5

    :cond_5
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    add-long v6, v4, v2

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v1

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x6

    shl-int/lit8 v1, v1, 0x15

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x6

    xor-int/2addr v0, v1

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    if-gez v0, :cond_6

    const/4 v11, 0x5

    move v12, v11

    const v1, -0x1fc080

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    xor-int/2addr v0, v1

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    goto :goto_0

    :cond_6
    const/4 v11, 0x4

    move v12, v11

    int-to-long v0, v0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    add-long v4, v6, v2

    const/4 v12, 0x3

    invoke-static {v6, v7}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v6

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    int-to-long v6, v6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    const/16 v8, 0x1c

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    shl-long/2addr v6, v8

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    xor-long/2addr v0, v6

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v12, 0x5

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    cmp-long v8, v0, v6

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-ltz v8, :cond_7

    const/4 v11, 0x6

    and-int/2addr v12, v11

    const-wide/32 v2, 0xfe03f80

    const-wide/32 v2, 0xfe03f80

    const/4 v12, 0x2

    const-wide/32 v2, 0xfe03f80

    const-wide/32 v2, 0xfe03f80

    :goto_2
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    xor-long/2addr v0, v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    goto :goto_1

    :cond_7
    const/4 v12, 0x5

    add-long v8, v4, v2

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v4

    const/4 v12, 0x6

    const/4 v11, 0x1

    int-to-long v4, v4

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    const/16 v10, 0x23

    const/4 v12, 0x6

    shl-long/2addr v4, v10

    const/4 v12, 0x7

    const/4 v11, 0x6

    xor-long/2addr v0, v4

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    cmp-long v4, v0, v6

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-gez v4, :cond_8

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-wide v2, -0x7f01fc080L

    const-wide v2, -0x7f01fc080L

    const/4 v12, 0x6

    const-wide v2, -0x7f01fc080L

    const-wide v2, -0x7f01fc080L

    :goto_3
    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    xor-long/2addr v0, v2

    move-wide v6, v8

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto/16 :goto_5

    :cond_8
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    add-long v4, v8, v2

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static {v8, v9}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v8

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    int-to-long v8, v8

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    const/16 v10, 0x2a

    const/4 v12, 0x6

    const/4 v11, 0x2

    shl-long/2addr v8, v10

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    xor-long/2addr v0, v8

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x3

    cmp-long v8, v0, v6

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-ltz v8, :cond_9

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-wide v2, 0x3f80fe03f80L

    const-wide v2, 0x3f80fe03f80L

    const/4 v12, 0x7

    const/4 v11, 0x2

    goto :goto_2

    :cond_9
    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    add-long v8, v4, v2

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v4

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    int-to-long v4, v4

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    const/16 v10, 0x31

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    shl-long/2addr v4, v10

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    xor-long/2addr v0, v4

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x2

    cmp-long v4, v0, v6

    const/4 v11, 0x7

    or-int/2addr v12, v11

    if-gez v4, :cond_a

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    const-wide v2, -0x1fc07f01fc080L

    const-wide v2, -0x1fc07f01fc080L

    const/4 v12, 0x6

    const-wide v2, -0x1fc07f01fc080L

    const-wide v2, -0x1fc07f01fc080L

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    goto/16 :goto_3

    :cond_a
    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    add-long v4, v8, v2

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {v8, v9}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v8

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    int-to-long v8, v8

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    const/16 v10, 0x38

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    shl-long/2addr v8, v10

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    xor-long/2addr v0, v8

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-wide v8, 0xfe03f80fe03f80L

    const-wide v8, 0xfe03f80fe03f80L

    const/4 v12, 0x6

    const-wide v8, 0xfe03f80fe03f80L

    const-wide v8, 0xfe03f80fe03f80L

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    xor-long/2addr v0, v8

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    cmp-long v8, v0, v6

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    if-gez v8, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    add-long/2addr v2, v4

    const/4 v11, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v4, v5}, Lcom/google/protobuf/UnsafeUtil;->getByte(J)B

    move-result v4

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    int-to-long v4, v4

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    cmp-long v4, v4, v6

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-gez v4, :cond_b

    :goto_4
    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint64SlowPath()J

    move-result-wide v0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    return-wide v0

    :cond_b
    move-wide v6, v2

    :goto_5
    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    iput-wide v6, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x2

    return-wide v0
.end method

.method readRawVarint64SlowPath()J
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x6

    const/4 v6, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x4

    move v7, v6

    const/4 v2, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/16 v3, 0x40

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-ge v2, v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawByte()B

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    and-int/lit8 v4, v3, 0x7f

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    int-to-long v4, v4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    shl-long/2addr v4, v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    or-long/2addr v0, v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    and-int/lit16 v3, v3, 0x80

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-wide v0

    :cond_0
    const/4 v7, 0x3

    add-int/lit8 v2, v2, 0x7

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->malformedVarint()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    throw v0
.end method

.method public readSFixed32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public readSFixed64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian64()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-wide v0
.end method

.method public readSInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method

.method public readSInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-wide v0
.end method

.method public readString()Ljava/lang/String;
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x7

    if-lez v0, :cond_0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v1

    const/4 v12, 0x4

    const/4 v11, 0x4

    if-gt v0, v1, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    new-array v1, v0, [B

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v12, 0x2

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v11, 0x7

    xor-int/2addr v12, v11

    int-to-long v9, v0

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-wide v7, v9

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-static/range {v2 .. v8}, Lcom/google/protobuf/UnsafeUtil;->copyMemory(J[BJJ)V

    const/4 v12, 0x4

    new-instance v0, Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    sget-object v2, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v12, 0x1

    invoke-direct {v0, v1, v2}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x6

    add-long/2addr v1, v9

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    iput-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v12, 0x6

    const/4 v11, 0x3

    return-object v0

    :cond_0
    const/4 v12, 0x3

    if-nez v0, :cond_1

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    return-object v0

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-gez v0, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    throw v0

    :cond_2
    const/4 v12, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    throw v0
.end method

.method public readStringRequireUtf8()Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-lez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-gt v0, v1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-wide v1, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {p0, v1, v2}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->bufferPos(J)I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->buffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v2, v1, v0}, Lcom/google/protobuf/Utf8;->decodeUtf8(Ljava/nio/ByteBuffer;II)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v6, 0x4

    shr-int/2addr v7, v6

    int-to-long v4, v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    add-long/2addr v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iput-wide v2, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v7, 0x0

    const/4 v6, 0x6

    return-object v1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x3

    const/4 v6, 0x6

    return-object v0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-gtz v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    throw v0

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x6

    throw v0
.end method

.method public readTag()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->isAtEnd()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->lastTag:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->lastTag:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->lastTag:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    throw v0
.end method

.method public readUInt32()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    return v0
.end method

.method public readUInt64()J
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint64()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method

.method public readUnknownGroup(ILcom/google/protobuf/MessageLite$Builder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "fieldNumber",
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/ExtensionRegistryLite;->getEmptyRegistry()Lcom/google/protobuf/ExtensionRegistryLite;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readGroup(ILcom/google/protobuf/MessageLite$Builder;Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public resetSizeCounter()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->startPos:J

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public skipField(I)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "tag"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eq v0, v1, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eq v0, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v2, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v3, 0x4

    const/4 v5, 0x1

    if-eq v0, v2, :cond_2

    const/4 v4, 0x5

    move v5, v4

    if-eq v0, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 p1, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne v0, p1, :cond_0

    const/4 v4, 0x4

    and-int/2addr v5, v4

    invoke-virtual {p0, v3}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipRawBytes(I)V

    const/4 v4, 0x3

    move v5, v4

    return v1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    throw p1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 p1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    return p1

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipMessage()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->checkLastTagWas(I)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    return v1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawVarint32()I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipRawBytes(I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/16 p1, 0x8

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipRawBytes(I)V

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    return v1

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipRawVarint()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    return v1
.end method

.method public skipField(ILcom/google/protobuf/CodedOutputStream;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "tag",
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x6

    or-int/2addr v5, v4

    if-eqz v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eq v0, v1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eq v0, v2, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v3, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eq v0, v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eq v0, v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v2, 0x5

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne v0, v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian32()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v4, 0x6

    or-int/2addr v5, v4

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeFixed32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    return v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidWireType()Lcom/google/protobuf/InvalidProtocolBufferException$InvalidWireTypeException;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    throw p1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    return p1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipMessage(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-static {p1, v3}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->checkLastTagWas(I)V

    const/4 v4, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readBytes()Lcom/google/protobuf/ByteString;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Lcom/google/protobuf/CodedOutputStream;->writeBytesNoTag(Lcom/google/protobuf/ByteString;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    return v1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readRawLittleEndian64()J

    move-result-wide v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x4

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeFixed64NoTag(J)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v1

    :cond_5
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readInt64()J

    move-result-wide v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2, p1}, Lcom/google/protobuf/CodedOutputStream;->writeUInt32NoTag(I)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p2, v2, v3}, Lcom/google/protobuf/CodedOutputStream;->writeUInt64NoTag(J)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v1
.end method

.method public skipMessage()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipField(I)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    :cond_1
    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public skipMessage(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->readTag()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, v0, p1}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->skipField(ILcom/google/protobuf/CodedOutputStream;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez v0, :cond_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public skipRawBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "length"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ltz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->remaining()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-gt p1, v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    int-to-long v2, p1

    const/4 v5, 0x3

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/google/protobuf/CodedInputStream$UnsafeDirectNioDecoder;->pos:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-gez p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    throw p1

    :cond_1
    const/4 v4, 0x0

    move v5, v4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    throw p1
.end method
