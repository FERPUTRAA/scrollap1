.class public final enum Lcom/google/protobuf/Field$Cardinality;
.super Ljava/lang/Enum;

# interfaces
.implements Lcom/google/protobuf/ProtocolMessageEnum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Field;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Cardinality"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/Field$Cardinality;",
        ">;",
        "Lcom/google/protobuf/ProtocolMessageEnum;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/Field$Cardinality;

.field public static final enum CARDINALITY_OPTIONAL:Lcom/google/protobuf/Field$Cardinality;

.field public static final CARDINALITY_OPTIONAL_VALUE:I = 0x1

.field public static final enum CARDINALITY_REPEATED:Lcom/google/protobuf/Field$Cardinality;

.field public static final CARDINALITY_REPEATED_VALUE:I = 0x3

.field public static final enum CARDINALITY_REQUIRED:Lcom/google/protobuf/Field$Cardinality;

.field public static final CARDINALITY_REQUIRED_VALUE:I = 0x2

.field public static final enum CARDINALITY_UNKNOWN:Lcom/google/protobuf/Field$Cardinality;

.field public static final CARDINALITY_UNKNOWN_VALUE:I

.field public static final enum UNRECOGNIZED:Lcom/google/protobuf/Field$Cardinality;

.field private static final VALUES:[Lcom/google/protobuf/Field$Cardinality;

.field private static final internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/Field$Cardinality;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private final value:I


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x7

    new-instance v0, Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x2

    const/4 v12, 0x0

    const-string v1, "DYsWR_LAINNCNsANOTU"

    const-string v1, "KNsYALWNNDUCRA_OINT"

    const/4 v13, 0x6

    const-string v1, "AONmYNDLUNICWTNAIKR"

    const-string v1, "CARDINALITY_UNKNOWN"

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x5

    const/4 v2, 0x0

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x5

    invoke-direct {v0, v1, v2, v2}, Lcom/google/protobuf/Field$Cardinality;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x5

    sput-object v0, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_UNKNOWN:Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x0

    new-instance v1, Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x5

    const-string v3, "D_RLoONImIOALYANAPTI"

    const-string v3, "DITmNL_TNOOIPYRIAAAL"

    const/4 v13, 0x5

    const-string v3, "AITIYbRIALNNPAD_LOCO"

    const-string v3, "CARDINALITY_OPTIONAL"

    const/4 v12, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    const/4 v4, 0x1

    const/4 v12, 0x6

    move v13, v12

    invoke-direct {v1, v3, v4, v4}, Lcom/google/protobuf/Field$Cardinality;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x5

    const/4 v12, 0x1

    sput-object v1, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_OPTIONAL:Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x0

    new-instance v3, Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x2

    const-string v5, "EQUYLAuER_RTICIDADIR"

    const-string v5, "CARDINALITY_REQUIRED"

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x2

    const/4 v6, 0x2

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-direct {v3, v5, v6, v6}, Lcom/google/protobuf/Field$Cardinality;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x1

    sput-object v3, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_REQUIRED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x6

    new-instance v5, Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x2

    const-string v7, "ECNPoIIRELY_ETADTADA"

    const/4 v13, 0x1

    const-string v7, "ADIPERYpNTATDEEILAR_"

    const-string v7, "CARDINALITY_REPEATED"

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    const/4 v8, 0x3

    const/4 v13, 0x0

    invoke-direct {v5, v7, v8, v8}, Lcom/google/protobuf/Field$Cardinality;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x3

    sput-object v5, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_REPEATED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x6

    const/4 v12, 0x3

    new-instance v7, Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x6

    const/4 v9, -0x1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x0

    const-string v10, "URNEGZIOqCNE"

    const-string v10, "CRZGIbENNOUE"

    const/4 v13, 0x2

    const-string v10, "REsEOCNNUIZD"

    const-string v10, "UNRECOGNIZED"

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v11, 0x4

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    invoke-direct {v7, v10, v11, v9}, Lcom/google/protobuf/Field$Cardinality;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x2

    sput-object v7, Lcom/google/protobuf/Field$Cardinality;->UNRECOGNIZED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x5

    const/4 v9, 0x5

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    new-array v9, v9, [Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x7

    aput-object v0, v9, v2

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x4

    aput-object v1, v9, v4

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x1

    aput-object v3, v9, v6

    const/4 v13, 0x1

    aput-object v5, v9, v8

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x2

    aput-object v7, v9, v11

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x1

    sput-object v9, Lcom/google/protobuf/Field$Cardinality;->$VALUES:[Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x2

    new-instance v0, Lcom/google/protobuf/Field$Cardinality$1;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-direct {v0}, Lcom/google/protobuf/Field$Cardinality$1;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x5

    sput-object v0, Lcom/google/protobuf/Field$Cardinality;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-static {}, Lcom/google/protobuf/Field$Cardinality;->values()[Lcom/google/protobuf/Field$Cardinality;

    move-result-object v0

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    sput-object v0, Lcom/google/protobuf/Field$Cardinality;->VALUES:[Lcom/google/protobuf/Field$Cardinality;

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x0

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p3, p0, Lcom/google/protobuf/Field$Cardinality;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static forNumber(I)Lcom/google/protobuf/Field$Cardinality;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    if-eqz p0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eq p0, v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eq p0, v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eq p0, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object p0, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_REPEATED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0

    :cond_1
    const/4 v2, 0x1

    sget-object p0, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_REQUIRED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object p0, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_OPTIONAL:Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object p0, Lcom/google/protobuf/Field$Cardinality;->CARDINALITY_UNKNOWN:Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/Field;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$Descriptor;->getEnumTypes()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumDescriptor;

    return-object v0
.end method

.method public static internalGetValueMap()Lcom/google/protobuf/Internal$EnumLiteMap;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Internal$EnumLiteMap<",
            "Lcom/google/protobuf/Field$Cardinality;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/Field$Cardinality;->internalValueMap:Lcom/google/protobuf/Internal$EnumLiteMap;

    const/4 v2, 0x1

    return-object v0
.end method

.method public static valueOf(I)Lcom/google/protobuf/Field$Cardinality;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/google/protobuf/Field$Cardinality;->forNumber(I)Lcom/google/protobuf/Field$Cardinality;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public static valueOf(Lcom/google/protobuf/Descriptors$EnumValueDescriptor;)Lcom/google/protobuf/Field$Cardinality;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "desc"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getType()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/Field$Cardinality;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ne v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getIndex()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, -0x1

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object p0, Lcom/google/protobuf/Field$Cardinality;->UNRECOGNIZED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x5

    sget-object v0, Lcom/google/protobuf/Field$Cardinality;->VALUES:[Lcom/google/protobuf/Field$Cardinality;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getIndex()I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    aget-object p0, v0, p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "otimfathsismurrspue pc lnurVy .noeDtt oe "

    const-string/jumbo v0, "pi r puit.usres tVmcsEneohDf alyretounot "

    const/4 v3, 0x7

    const-string v0, "fDsuorEeo tlpyssnnatuVi p tec eirmh.or ot"

    const-string v0, "EnumValueDescriptor is not for this type."

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/Field$Cardinality;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-class v0, Lcom/google/protobuf/Field$Cardinality;

    const-class v0, Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x7

    const-class v0, Lcom/google/protobuf/Field$Cardinality;

    const-class v0, Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/Field$Cardinality;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/Field$Cardinality;->$VALUES:[Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/google/protobuf/Field$Cardinality;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, [Lcom/google/protobuf/Field$Cardinality;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public final getDescriptorForType()Lcom/google/protobuf/Descriptors$EnumDescriptor;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-static {}, Lcom/google/protobuf/Field$Cardinality;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public final getNumber()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Lcom/google/protobuf/Field$Cardinality;->UNRECOGNIZED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eq p0, v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/Field$Cardinality;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, " u.umbaugovtmpnere/abnuef tanenh Ck   nwo/t n l"

    const-string v1, "bnunuahp /onon f nmu r/tv  euneae.m geCakt lewt"

    const/4 v3, 0x1

    const-string v1, " n an uet an v.nnCk ualmtu/ne hoowegefrtu emu/b"

    const-string v1, "Can\'t get the number of an unknown enum value."

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw v0
.end method

.method public final getValueDescriptor()Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/google/protobuf/Field$Cardinality;->UNRECOGNIZED:Lcom/google/protobuf/Field$Cardinality;

    const/4 v3, 0x2

    if-eq p0, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/protobuf/Field$Cardinality;->getDescriptor()Lcom/google/protobuf/Descriptors$EnumDescriptor;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->getValues()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x4

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v1, "oea edgp tgr iv.ehnn/ ocliro rnzf nd epCettusaq /uceatmn"

    const-string v1, "e vatgepqaon rhdnfn idl ueo itege Coseetuzcnm/tc/na r.r "

    const/4 v3, 0x4

    const-string/jumbo v1, "onvee .dqs aieptdcoc  fnetelrCa/ gn uih ut te/rrzenmuago"

    const-string v1, "Can\'t get the descriptor of an unrecognized enum value."

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    throw v0
.end method
