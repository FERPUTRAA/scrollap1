.class public final Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
.super Lcom/google/protobuf/GeneratedMessageV3;

# interfaces
.implements Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaultsOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "FeatureSetDefaults"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;,
        Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;,
        Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefaultOrBuilder;
    }
.end annotation


# static fields
.field public static final DEFAULTS_FIELD_NUMBER:I = 0x1

.field private static final DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

.field public static final MAXIMUM_EDITION_FIELD_NUMBER:I = 0x5

.field public static final MINIMUM_EDITION_FIELD_NUMBER:I = 0x4

.field public static final PARSER:Lcom/google/protobuf/Parser;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;",
            ">;"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field private static final serialVersionUID:J


# instance fields
.field private bitField0_:I

.field private defaults_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;",
            ">;"
        }
    .end annotation
.end field

.field private maximumEdition_:I

.field private memoizedIsInitialized:B

.field private minimumEdition_:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$1;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$1;-><init>()V

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/GeneratedMessageV3;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v3, 0x3

    const/4 v1, -0x1

    const/4 v3, 0x3

    or-int/2addr v2, v1

    const/4 v3, 0x0

    iput-byte v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->memoizedIsInitialized:B

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v2, 0x7

    move v3, v2

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "builder"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/GeneratedMessageV3$Builder<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 p1, -0x1

    xor-int/2addr v1, p1

    const/4 v0, 0x3

    or-int/2addr v1, v0

    iput-byte p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->memoizedIsInitialized:B

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;Lcom/google/protobuf/DescriptorProtos$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;-><init>(Lcom/google/protobuf/GeneratedMessageV3$Builder;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic access$31600(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;)Ljava/util/List;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t@s t~s@Sl-~~ @@i ~ b@~/u@r1@@ n~@co~i@ ~~  ~d ~~4 a~~b~@KMfof~@v@@@~.lboo@~ ~ ~y@/o o @@  ~ @im"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-object p0
.end method

.method static synthetic access$31602(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;Ljava/util/List;)Ljava/util/List;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method static synthetic access$31702(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;I)I
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method static synthetic access$31802(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method static synthetic access$31976(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;I)I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    or-int/2addr p1, v0

    const/4 v2, 0x6

    iput p1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p1
.end method

.method public static getDefaultInstance()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public static final getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos;->access$30300()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object v0
.end method

.method public static newBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public static newBuilder(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "prototype"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;->mergeFrom(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseDelimitedFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseDelimitedWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Lcom/google/protobuf/ByteString;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Lcom/google/protobuf/CodedInputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "input"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {v0, p0}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public static parseFrom(Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "input",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0, p0, p1}, Lcom/google/protobuf/GeneratedMessageV3;->parseWithIOException(Lcom/google/protobuf/Parser;Ljava/io/InputStream;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/Message;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v1, 0x4

    move v2, v1

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom(Ljava/nio/ByteBuffer;Lcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom([B)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Lcom/google/protobuf/Parser;->parseFrom([B)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public static parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "extensionRegistry"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p0, p1}, Lcom/google/protobuf/Parser;->parseFrom([BLcom/google/protobuf/ExtensionRegistryLite;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public static parser()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "obj"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ne p1, p0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    instance-of v1, p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractMessage;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    return p1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultsList()Ljava/util/List;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultsList()Ljava/util/List;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1, v2}, Ljava/util/List;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    return v2

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMinimumEdition()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMinimumEdition()Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eq v1, v3, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v2

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMinimumEdition()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v3, p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eq v1, v3, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v2

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMaximumEdition()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMaximumEdition()Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eq v1, v3, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    return v2

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMaximumEdition()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v1, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget v3, p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eq v1, v3, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v2

    :cond_6
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1, p1}, Lcom/google/protobuf/UnknownFieldSet;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez p1, :cond_7

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    return v2

    :cond_7
    const/4 v4, 0x3

    const/4 v5, 0x1

    return v0
.end method

.method public getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lcom/google/protobuf/MessageLite;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultInstanceForType()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public getDefaults(I)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p1
.end method

.method public getDefaultsCount()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v2, 0x1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public getDefaultsList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v2, 0x4

    return-object v0
.end method

.method public getDefaultsOrBuilder(I)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefaultOrBuilder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefaultOrBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p1
.end method

.method public getDefaultsOrBuilderList()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "+",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefaultOrBuilder;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getMaximumEdition()Lcom/google/protobuf/DescriptorProtos$Edition;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$Edition;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$Edition;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$Edition;->EDITION_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$Edition;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public getMinimumEdition()Lcom/google/protobuf/DescriptorProtos$Edition;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/google/protobuf/DescriptorProtos$Edition;->forNumber(I)Lcom/google/protobuf/DescriptorProtos$Edition;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$Edition;->EDITION_UNKNOWN:Lcom/google/protobuf/DescriptorProtos$Edition;

    :cond_0
    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public getParserForType()Lcom/google/protobuf/Parser;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/protobuf/Parser<",
            "Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->PARSER:Lcom/google/protobuf/Parser;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSerializedSize()I
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v1, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    if-eq v0, v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-ge v0, v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast v2, Lcom/google/protobuf/MessageLite;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v3, v2}, Lcom/google/protobuf/CodedOutputStream;->computeMessageSize(ILcom/google/protobuf/MessageLite;)I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    add-int/2addr v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    and-int/2addr v0, v3

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v0, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0, v2}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    add-int/2addr v1, v0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    and-int/lit8 v0, v0, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v0, 0x5

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v2, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-static {v0, v2}, Lcom/google/protobuf/CodedOutputStream;->computeEnumSize(II)I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    add-int/2addr v1, v0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->getSerializedSize()I

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/2addr v1, v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput v1, p0, Lcom/google/protobuf/AbstractMessage;->memoizedSize:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v1
.end method

.method public hasMaximumEdition()Z
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public hasMinimumEdition()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    move v3, v2

    and-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v1
.end method

.method public hashCode()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDescriptor()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v1, 0x30b

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    add-int/2addr v1, v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultsCount()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-lez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultsList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/List;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v1, v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMinimumEdition()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    mul-int/lit8 v1, v1, 0x35

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/2addr v1, v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->hasMaximumEdition()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    mul-int/lit8 v1, v1, 0x25

    const/4 v3, 0x3

    add-int/lit8 v1, v1, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x35

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    add-int/2addr v1, v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    mul-int/lit8 v1, v1, 0x1d

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/UnknownFieldSet;->hashCode()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x7

    iput v1, p0, Lcom/google/protobuf/AbstractMessageLite;->memoizedHashCode:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v1
.end method

.method protected internalGetFieldAccessorTable()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos;->access$30400()Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v4, 0x0

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const-class v1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const/4 v4, 0x5

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const-class v2, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;->ensureFieldAccessorsInitialized(Ljava/lang/Class;Ljava/lang/Class;)Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    return-object v0
.end method

.method public final isInitialized()Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-byte v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->memoizedIsInitialized:B

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne v0, v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    return v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaultsCount()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-ge v0, v3, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->getDefaults(I)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v3}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$FeatureSetEditionDefault;->isInitialized()Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-nez v3, :cond_2

    const/4 v4, 0x0

    move v5, v4

    iput-byte v2, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->memoizedIsInitialized:B

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v2

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto :goto_0

    :cond_3
    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-byte v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->memoizedIsInitialized:B

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    return v1
.end method

.method public newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->newBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method protected newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v3, 0x0

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, p1, v1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;-><init>(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-object v0
.end method

.method protected bridge synthetic newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/Message$Builder;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "parent"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->newBuilderForType(Lcom/google/protobuf/GeneratedMessageV3$BuilderParent;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic newBuilderForType()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->newBuilderForType()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method protected newInstance(Lcom/google/protobuf/GeneratedMessageV3$UnusedPrivateParameter;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "unused"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    new-instance p1, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v1, 0x7

    invoke-direct {p1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public toBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->DEFAULT_INSTANCE:Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-ne p0, v0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;-><init>(Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;-><init>(Lcom/google/protobuf/DescriptorProtos$1;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;->mergeFrom(Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;)Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/Message$Builder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toBuilder()Lcom/google/protobuf/MessageLite$Builder;
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->toBuilder()Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults$Builder;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public writeTo(Lcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v0, v1, :cond_0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->defaults_:Ljava/util/List;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast v1, Lcom/google/protobuf/MessageLite;

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, v2, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessage(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    and-int/2addr v0, v2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x4

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->minimumEdition_:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v0, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->bitField0_:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    and-int/lit8 v0, v0, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v0, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/DescriptorProtos$FeatureSetDefaults;->maximumEdition_:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeEnum(II)V

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageV3;->getUnknownFields()Lcom/google/protobuf/UnknownFieldSet;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Lcom/google/protobuf/UnknownFieldSet;->writeTo(Lcom/google/protobuf/CodedOutputStream;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method
