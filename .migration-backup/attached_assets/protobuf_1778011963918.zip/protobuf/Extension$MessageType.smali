.class public final enum Lcom/google/protobuf/Extension$MessageType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Extension;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "MessageType"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/Extension$MessageType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/Extension$MessageType;

.field public static final enum PROTO1:Lcom/google/protobuf/Extension$MessageType;

.field public static final enum PROTO2:Lcom/google/protobuf/Extension$MessageType;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v0, Lcom/google/protobuf/Extension$MessageType;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v1, "OPsRO1"

    const-string v1, "1PsROO"

    const/4 v6, 0x6

    const-string v1, "PR1mTO"

    const-string v1, "PROTO1"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/Extension$MessageType;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    sput-object v0, Lcom/google/protobuf/Extension$MessageType;->PROTO1:Lcom/google/protobuf/Extension$MessageType;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Lcom/google/protobuf/Extension$MessageType;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v3, "OOR2oP"

    const-string v3, "ROPmO2"

    const/4 v6, 0x6

    const-string v3, "R2POOb"

    const-string v3, "PROTO2"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v1, v3, v4}, Lcom/google/protobuf/Extension$MessageType;-><init>(Ljava/lang/String;I)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    sput-object v1, Lcom/google/protobuf/Extension$MessageType;->PROTO2:Lcom/google/protobuf/Extension$MessageType;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-array v3, v3, [Lcom/google/protobuf/Extension$MessageType;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    aput-object v0, v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    aput-object v1, v3, v4

    const/4 v6, 0x7

    sput-object v3, Lcom/google/protobuf/Extension$MessageType;->$VALUES:[Lcom/google/protobuf/Extension$MessageType;

    const/4 v6, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/Extension$MessageType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ 4~~ u@ @o ~ ~l~@ @ @@n~~/o  Mbo~i @@~  cr~o~i@~1t. Ktf@oy~s~o~b~~Sv@ @@@ l@@~@-/bu@i~f  dma~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const-class v0, Lcom/google/protobuf/Extension$MessageType;

    const-class v0, Lcom/google/protobuf/Extension$MessageType;

    const/4 v2, 0x3

    const-class v0, Lcom/google/protobuf/Extension$MessageType;

    const-class v0, Lcom/google/protobuf/Extension$MessageType;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p0, Lcom/google/protobuf/Extension$MessageType;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/Extension$MessageType;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    sget-object v0, Lcom/google/protobuf/Extension$MessageType;->$VALUES:[Lcom/google/protobuf/Extension$MessageType;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lcom/google/protobuf/Extension$MessageType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast v0, [Lcom/google/protobuf/Extension$MessageType;

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-object v0
.end method
