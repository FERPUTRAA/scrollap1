.class public final Lcom/google/protobuf/AnyProto;
.super Ljava/lang/Object;


# static fields
.field private static descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

.field static final internal_static_google_protobuf_Any_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

.field static final internal_static_google_protobuf_Any_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v0, "0ts0nt0u2f0oPTveuppeW0y20bbo2fte.fo.ty01l00t/010b/Rp20u/rel59uAeoalo3lueypenl1B0y000r/o1l/s./0/3G010/0ur/g0ae02u00//rnr/1Pugu/u00r00._/0/un180utu00su/up00usoy0g3gcol/0/Putn000u0u0c1Bote/. /0oo02Ggfn0oplyn/gn0uZublo1R(/1p0rg000//u0/0pu00B/oun9ou/auyrbo0p0lu/0moga/2/00g/,y0/e tlp/afvt/4/oon00ooa050u0l/18uwk0nUftoooo(0e//0o/0b06rue0610/ob.v1gpw8onneuu08rag3tonA/uauo0uur.1g/0P0/K7."

    const-string/jumbo v0, "u2sPn/l07Bup0003l0001/0n/y0ap0v020/0v0kpUGot(uy00Bptoo/s26e3/ug0ue5Teuuuou/on0euA/t103wul//0l0Za/(Pfyt/r/1eG0.lo5ngfgo0/py0/n/10u0rueu0o01g00ue8uu0poarlo060//o 40/.0a0tu2g/eumn0alyb/orf/9P1/00tn0/e00/un0y/uR2u1c/rl8./ou0 uo1os./0/l1gur//o0ugc/boy0o0002u0rt0/o00/2.8b.uf0w0nooo0reon0u0bl0tlA/8otl00_0ru0uR0yu1rKn0oBeet0o90v/ou.u3uag1o/1a0Wn/0ngeg0ofgPgnr/oo00fp,pat.p0pb/pu0//tbb11"

    const/4 v5, 0x4

    const-string/jumbo v0, "oltm0n1eoeo5tRo/yo0n/u0AB00scuy01uA10fo0y/uu2nvupe.//Zulb0nayrl0g0eUo//ru/gutba0glp0bK2ton0uurf3n0y0kupr01oo0u//gorn1u1.018grlu2ay/lgn50.unt0/ou/guneyP/00to/0f0a(tpoR/u90/uuv00uuu2u/u0ao400001ae8Pa/g//0._1u90Gwbp0pe000tou/0o/cu/00orfo00/10.0gt0/r/o3tg/02B0on0b0ofogna 0/u/0u0e.0p0/mf06(ouyl1u0b1/.o00teole/00T/rWow/u61/e/002 p0stBpGn0ue0l/7lpl00eb/3g8.8v0o02nur03/roP0p0/,/lou/01o"

    const-string v0, "\n\u0019google/protobuf/any.proto\u0012\u000fgoogle.protobuf\"6\n\u0003Any\u0012\u0019\n\u0008type_url\u0018\u0001 \u0001(\tR\u0007typeUrl\u0012\u0014\n\u0005value\u0018\u0002 \u0001(\u000cR\u0005valueBv\n\u0013com.google.protobufB\u0008AnyProtoP\u0001Z,google.golang.org/protobuf/types/known/anypb\u00a2\u0002\u0003GPB\u00aa\u0002\u001eGoogle.Protobuf.WellKnownTypesb\u0006proto3"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-array v2, v1, [Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0, v2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->internalBuildGeneratedFileFrom([Ljava/lang/String;[Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    sput-object v0, Lcom/google/protobuf/AnyProto;->descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/protobuf/AnyProto;->getDescriptor()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getMessageTypes()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    sput-object v0, Lcom/google/protobuf/AnyProto;->internal_static_google_protobuf_Any_descriptor:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v1, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v2, "mUyToep"

    const-string v2, "TlUmpey"

    const/4 v5, 0x7

    const-string v2, "TlrpUby"

    const-string v2, "TypeUrl"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const-string/jumbo v3, "luoau"

    const-string/jumbo v3, "lVauo"

    const/4 v5, 0x5

    const-string v3, "Vepul"

    const-string v3, "Value"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-direct {v1, v0, v2}, Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;-><init>(Lcom/google/protobuf/Descriptors$Descriptor;[Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    sput-object v1, Lcom/google/protobuf/AnyProto;->internal_static_google_protobuf_Any_fieldAccessorTable:Lcom/google/protobuf/GeneratedMessageV3$FieldAccessorTable;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public static getDescriptor()Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "1 o /@/~qS  s@mi oi @ot~ ~K@~@@~~i @ l@c~ t~4~  buov~a @l~- fr~@yfbMo~@@@@~ @@b~ ~@~~d~@~@o~~.n "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/AnyProto;->descriptor:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object v0
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistry;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/google/protobuf/AnyProto;->registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public static registerAllExtensions(Lcom/google/protobuf/ExtensionRegistryLite;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method
