.class public interface abstract Lcom/google/protobuf/DescriptorProtos$DescriptorProto$ExtensionRangeOrBuilder;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/protobuf/MessageOrBuilder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/DescriptorProtos$DescriptorProto;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "ExtensionRangeOrBuilder"
.end annotation


# virtual methods
.method public abstract getEnd()I
.end method

.method public abstract getOptions()Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptions;
.end method

.method public abstract getOptionsOrBuilder()Lcom/google/protobuf/DescriptorProtos$ExtensionRangeOptionsOrBuilder;
.end method

.method public abstract getStart()I
.end method

.method public abstract hasEnd()Z
.end method

.method public abstract hasOptions()Z
.end method

.method public abstract hasStart()Z
.end method
