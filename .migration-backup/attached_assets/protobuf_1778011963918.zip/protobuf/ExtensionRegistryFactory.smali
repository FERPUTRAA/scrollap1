.class final Lcom/google/protobuf/ExtensionRegistryFactory;
.super Ljava/lang/Object;


# static fields
.field static final EXTENSION_REGISTRY_CLASS:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field static final FULL_REGISTRY_CLASS_NAME:Ljava/lang/String; = "com.google.protobuf.ExtensionRegistry"


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/protobuf/ExtensionRegistryFactory;->reflectExtensionRegistry()Ljava/lang/Class;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    sput-object v0, Lcom/google/protobuf/ExtensionRegistryFactory;->EXTENSION_REGISTRY_CLASS:Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static create()Lcom/google/protobuf/ExtensionRegistryLite;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s ~~s@~~  y d@- ~~ om@iu@~ b Scr. ~@a@@b4M ~ofK~1b@~l~~@@@@o/ @~@ft ~ lo@n@~@i@t~ @ /~@ov~o~i "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-string/jumbo v0, "nesmewtIans"

    const-string v0, "ecsewaIsnnt"

    const/4 v2, 0x1

    const-string v0, "etnnoaIwncs"

    const-string/jumbo v0, "newInstance"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/google/protobuf/ExtensionRegistryFactory;->invokeSubclassFactory(Ljava/lang/String;)Lcom/google/protobuf/ExtensionRegistryLite;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Lcom/google/protobuf/ExtensionRegistryLite;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/protobuf/ExtensionRegistryLite;-><init>()V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    return-object v0
.end method

.method public static createEmpty()Lcom/google/protobuf/ExtensionRegistryLite;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "metgybyEgtrmetps"

    const-string/jumbo v0, "tmsmRyttrgeEygep"

    const/4 v2, 0x4

    const-string v0, "getEmptyRegistry"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/google/protobuf/ExtensionRegistryFactory;->invokeSubclassFactory(Ljava/lang/String;)Lcom/google/protobuf/ExtensionRegistryLite;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/ExtensionRegistryLite;->EMPTY_REGISTRY_LITE:Lcom/google/protobuf/ExtensionRegistryLite;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method private static final invokeSubclassFactory(Ljava/lang/String;)Lcom/google/protobuf/ExtensionRegistryLite;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "methodName"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v0, Lcom/google/protobuf/ExtensionRegistryFactory;->EXTENSION_REGISTRY_CLASS:Ljava/lang/Class;

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x0

    shl-int/2addr v4, v1

    const/4 v5, 0x3

    if-nez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object v1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v5, 0x4

    invoke-virtual {v0, p0, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x1

    new-array v0, v2, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, v1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x1

    check-cast p0, Lcom/google/protobuf/ExtensionRegistryLite;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p0

    :catch_0
    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object v1
.end method

.method static isFullRegistry(Lcom/google/protobuf/ExtensionRegistryLite;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "registry"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lcom/google/protobuf/ExtensionRegistryFactory;->EXTENSION_REGISTRY_CLASS:Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 p0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0
.end method

.method static reflectExtensionRegistry()Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string/jumbo v0, "uEiorgubotxogo.titoeRmfp.eocgosnl.eys"

    const-string v0, "egnmoRoltu.roo.tfgEgnxyeoooset.spcibi"

    const/4 v2, 0x5

    const-string v0, ".itssgepo.yEfuxoopmbtniotggoelRrc.eon"

    const-string v0, "com.google.protobuf.ExtensionRegistry"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0

    :catch_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method
