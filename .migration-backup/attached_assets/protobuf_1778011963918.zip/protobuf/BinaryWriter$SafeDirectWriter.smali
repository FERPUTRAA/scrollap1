.class final Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;
.super Lcom/google/protobuf/BinaryWriter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/BinaryWriter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "SafeDirectWriter"
.end annotation


# instance fields
.field private buffer:Ljava/nio/ByteBuffer;

.field private limitMinusOne:I

.field private pos:I


# direct methods
.method constructor <init>(Lcom/google/protobuf/BufferAllocator;I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alloc",
            "chunkSize"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2, v0}, Lcom/google/protobuf/BinaryWriter;-><init>(Lcom/google/protobuf/BufferAllocator;ILcom/google/protobuf/BinaryWriter$1;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method private bytesWrittenToCurrentBuffer()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l/s@ ~@@@od@b~/@~ o @a~ 1.@~~b4m@c@i~f@o~f~ tS@ yri@ot@~ ~v~@ ~ bu @ MnK- ~ ~o@ ~ i@ls ~ o~~~@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->limitMinusOne:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    sub-int/2addr v0, v1

    const/4 v3, 0x0

    return v0
.end method

.method private nextBuffer()V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter;->newDirectBuffer()Lcom/google/protobuf/AllocatedBuffer;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private nextBuffer(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter;->newDirectBuffer(I)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method private nextBuffer(Lcom/google/protobuf/AllocatedBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "allocatedBuffer"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->hasNioBuffer()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1}, Lcom/google/protobuf/AllocatedBuffer;->nioBuffer()Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->isDirect()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->finishCurrentBuffer()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lcom/google/protobuf/Java8Compatibility;->limit(Ljava/nio/Buffer;I)V

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/nio/Buffer;->limit()I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->limitMinusOne:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v0, "nrrmsoul ntle-recrrf Aiunetcfe odoad"

    const-string/jumbo v0, "rrscnoteeauA eltlfofr-rdteducr non i"

    const/4 v3, 0x7

    const-string/jumbo v0, "onilorcrAnt fetuo-rdtu foldrrceee na"

    const-string v0, "Allocator returned non-direct buffer"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    move v3, v2

    throw p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const-string v0, " ev rbcbeIe fOlasudhfolbadtent NuoefAr  o"

    const-string v0, "Allocated buffer does not have NIO buffer"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    move v3, v2

    throw p1
.end method

.method private spaceLeft()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v1, 0x2

    and-int/2addr v2, v1

    return v0
.end method

.method private writeVarint32FiveBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v5, 0x0

    ushr-int/lit8 v2, p1, 0x1c

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    int-to-byte v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x3

    move v5, v4

    add-int/lit8 v0, v0, -0x4

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    ushr-int/lit8 v2, p1, 0x15

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    and-int/lit8 v2, v2, 0x7f

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    or-int/lit16 v2, v2, 0x80

    const/4 v5, 0x5

    shl-int/lit8 v2, v2, 0x18

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    ushr-int/lit8 v3, p1, 0xe

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x5

    or-int/lit16 v3, v3, 0x80

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    shl-int/lit8 v3, v3, 0x10

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    or-int/2addr v2, v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    ushr-int/lit8 v3, p1, 0x7

    const/4 v5, 0x4

    const/4 v4, 0x4

    and-int/lit8 v3, v3, 0x7f

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    or-int/lit16 v3, v3, 0x80

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    shl-int/lit8 v3, v3, 0x8

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    or-int/2addr v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    and-int/lit8 p1, p1, 0x7f

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    or-int/lit16 p1, p1, 0x80

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    or-int/2addr p1, v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v1, v0, p1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    const/4 v4, 0x7

    move v5, v4

    return-void
.end method

.method private writeVarint32FourBytes(I)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    add-int/lit8 v0, v0, -0x4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/high16 v2, 0xfe00000

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    and-int/2addr v2, p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    shl-int/lit8 v2, v2, 0x3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const v3, 0x1fc000

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    and-int/2addr v3, p1

    const/4 v6, 0x5

    const/high16 v4, 0x200000

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    or-int/2addr v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    shl-int/lit8 v3, v3, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    or-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    and-int/lit16 v3, p1, 0x3f80

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    or-int/lit16 v3, v3, 0x4000

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    shl-int/lit8 v3, v3, 0x1

    const/4 v5, 0x4

    const/4 v5, 0x1

    or-int/2addr v2, v3

    const/4 v5, 0x6

    or-int/2addr v6, v5

    and-int/lit8 p1, p1, 0x7f

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    or-int/lit16 p1, p1, 0x80

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    or-int/2addr p1, v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1, v0, p1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method

.method private writeVarint32OneByte(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    add-int/lit8 v2, v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x2

    int-to-byte p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1, p1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method private writeVarint32ThreeBytes(I)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x6

    move v5, v4

    add-int/lit8 v0, v0, -0x3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    const v2, 0x1fc000

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    and-int/2addr v2, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    shl-int/lit8 v2, v2, 0xa

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    and-int/lit16 v3, p1, 0x3f80

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    or-int/lit16 v3, v3, 0x4000

    const/4 v5, 0x5

    shl-int/lit8 v3, v3, 0x9

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    or-int/2addr v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    and-int/lit8 p1, p1, 0x7f

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    or-int/lit16 p1, p1, 0x80

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    shl-int/lit8 p1, p1, 0x8

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    or-int/2addr p1, v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v0, p1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method

.method private writeVarint32TwoBytes(I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    add-int/lit8 v0, v0, -0x2

    const/4 v4, 0x7

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x5

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    and-int/lit16 v2, p1, 0x3f80

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    shl-int/lit8 v2, v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    and-int/lit8 p1, p1, 0x7f

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    or-int/lit16 p1, p1, 0x80

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    or-int/2addr p1, v2

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    int-to-short p1, p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v0, p1}, Ljava/nio/ByteBuffer;->putShort(IS)Ljava/nio/ByteBuffer;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method private writeVarint64EightBytes(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    add-int/lit8 v0, v0, -0x8

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x4

    move v10, v9

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v2, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    add-int/2addr v0, v2

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-wide/high16 v3, 0xfe000000000000L

    const-wide/high16 v3, 0xfe000000000000L

    const/4 v10, 0x2

    const-wide/high16 v3, 0xfe000000000000L

    const-wide/high16 v3, 0xfe000000000000L

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    and-long/2addr v3, p1

    const/4 v10, 0x6

    const/4 v5, 0x7

    const/4 v10, 0x6

    shl-int/2addr v9, v5

    const/4 v10, 0x6

    shl-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-wide v5, 0x1fc0000000000L

    const-wide v5, 0x1fc0000000000L

    const/4 v10, 0x6

    const-wide v5, 0x1fc0000000000L

    const-wide v5, 0x1fc0000000000L

    const/4 v10, 0x6

    and-long/2addr v5, p1

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    const-wide/high16 v7, 0x2000000000000L

    const-wide/high16 v7, 0x2000000000000L

    const/4 v10, 0x6

    or-long/2addr v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v7, 0x7

    const/4 v7, 0x6

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    shl-long/2addr v5, v7

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    or-long/2addr v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-wide v5, 0x3f800000000L

    const-wide v5, 0x3f800000000L

    const/4 v10, 0x1

    const-wide v5, 0x3f800000000L

    const-wide v5, 0x3f800000000L

    const/4 v9, 0x2

    xor-int/2addr v10, v9

    and-long/2addr v5, p1

    const/4 v10, 0x4

    const-wide v7, 0x40000000000L

    const-wide v7, 0x40000000000L

    const/4 v10, 0x0

    const-wide v7, 0x40000000000L

    const-wide v7, 0x40000000000L

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    or-long/2addr v5, v7

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    const/4 v7, 0x5

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    shl-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    or-long/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-wide v5, 0x7f0000000L

    const-wide v5, 0x7f0000000L

    const/4 v10, 0x2

    const-wide v5, 0x7f0000000L

    const-wide v5, 0x7f0000000L

    const/4 v9, 0x2

    const/4 v10, 0x4

    and-long/2addr v5, p1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-wide v7, 0x800000000L

    const-wide v7, 0x800000000L

    const/4 v10, 0x5

    const/4 v9, 0x6

    or-long/2addr v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    const/4 v7, 0x4

    const/4 v10, 0x0

    shl-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    or-long/2addr v3, v5

    const/4 v9, 0x4

    or-int/2addr v10, v9

    const-wide/32 v5, 0xfe00000

    const-wide/32 v5, 0xfe00000

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    and-long/2addr v5, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-wide/32 v7, 0x10000000

    const-wide/32 v7, 0x10000000

    const/4 v10, 0x7

    const-wide/32 v7, 0x10000000

    const-wide/32 v7, 0x10000000

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    or-long/2addr v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v7, 0x3

    const/4 v9, 0x7

    move v10, v9

    shl-long/2addr v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    or-long/2addr v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-wide/32 v5, 0x1fc000

    const-wide/32 v5, 0x1fc000

    const/4 v10, 0x0

    const-wide/32 v5, 0x1fc000

    const-wide/32 v5, 0x1fc000

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    and-long/2addr v5, p1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-wide/32 v7, 0x200000

    const-wide/32 v7, 0x200000

    const/4 v10, 0x7

    const-wide/32 v7, 0x200000

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    or-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v7, 0x2

    const/4 v10, 0x3

    shl-long/2addr v5, v7

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    or-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-wide/16 v5, 0x3f80

    const-wide/16 v5, 0x3f80

    const/4 v10, 0x5

    const-wide/16 v5, 0x3f80

    const-wide/16 v5, 0x3f80

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    and-long/2addr v5, p1

    const/4 v9, 0x7

    move v10, v9

    const-wide/16 v7, 0x4000

    const-wide/16 v7, 0x4000

    const/4 v10, 0x1

    const-wide/16 v7, 0x4000

    const-wide/16 v7, 0x4000

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    or-long/2addr v5, v7

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    shl-long/2addr v5, v2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    or-long v2, v3, v5

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v10, 0x0

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    and-long/2addr p1, v4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v10, 0x3

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    or-long/2addr p1, v4

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    or-long/2addr p1, v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v1, v0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    return-void
.end method

.method private writeVarint64EightBytesWithSign(J)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    add-int/lit8 v0, v0, -0x8

    const/4 v9, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v2, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    add-int/2addr v0, v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-wide/high16 v3, 0xfe000000000000L

    const-wide/high16 v3, 0xfe000000000000L

    const/4 v10, 0x7

    const-wide/high16 v3, 0xfe000000000000L

    const/4 v10, 0x5

    and-long/2addr v3, p1

    const/4 v10, 0x0

    const-wide/high16 v5, 0x100000000000000L

    const-wide/high16 v5, 0x100000000000000L

    const/4 v10, 0x0

    const-wide/high16 v5, 0x100000000000000L

    const-wide/high16 v5, 0x100000000000000L

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    or-long/2addr v3, v5

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v5, 0x7

    move v10, v5

    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    shl-long/2addr v3, v5

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-wide v5, 0x1fc0000000000L

    const-wide v5, 0x1fc0000000000L

    const/4 v10, 0x6

    const-wide v5, 0x1fc0000000000L

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    and-long/2addr v5, p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-wide/high16 v7, 0x2000000000000L

    const-wide/high16 v7, 0x2000000000000L

    const/4 v10, 0x0

    const-wide/high16 v7, 0x2000000000000L

    const-wide/high16 v7, 0x2000000000000L

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    or-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v7, 0x6

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    shl-long/2addr v5, v7

    or-long/2addr v3, v5

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-wide v5, 0x3f800000000L

    const-wide v5, 0x3f800000000L

    const/4 v10, 0x4

    const-wide v5, 0x3f800000000L

    const-wide v5, 0x3f800000000L

    const/4 v10, 0x6

    and-long/2addr v5, p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-wide v7, 0x40000000000L

    const-wide v7, 0x40000000000L

    const/4 v10, 0x3

    const-wide v7, 0x40000000000L

    const-wide v7, 0x40000000000L

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    or-long/2addr v5, v7

    const/4 v9, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v7, 0x5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    shl-long/2addr v5, v7

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    or-long/2addr v3, v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-wide v5, 0x7f0000000L

    const-wide v5, 0x7f0000000L

    const/4 v10, 0x3

    const-wide v5, 0x7f0000000L

    const-wide v5, 0x7f0000000L

    const/4 v9, 0x5

    shr-int/2addr v10, v9

    and-long/2addr v5, p1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-wide v7, 0x800000000L

    const-wide v7, 0x800000000L

    const/4 v10, 0x5

    const-wide v7, 0x800000000L

    const-wide v7, 0x800000000L

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    or-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v7, 0x4

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    shl-long/2addr v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    or-long/2addr v3, v5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-wide/32 v5, 0xfe00000

    const-wide/32 v5, 0xfe00000

    const/4 v10, 0x4

    const-wide/32 v5, 0xfe00000

    const-wide/32 v5, 0xfe00000

    const/4 v10, 0x0

    const/4 v9, 0x6

    and-long/2addr v5, p1

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-wide/32 v7, 0x10000000

    const-wide/32 v7, 0x10000000

    const/4 v10, 0x4

    const-wide/32 v7, 0x10000000

    const-wide/32 v7, 0x10000000

    const/4 v10, 0x5

    const/4 v9, 0x0

    or-long/2addr v5, v7

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v7, 0x3

    const/4 v10, 0x4

    shl-long/2addr v5, v7

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    or-long/2addr v3, v5

    const/4 v10, 0x6

    const-wide/32 v5, 0x1fc000

    const-wide/32 v5, 0x1fc000

    const/4 v10, 0x3

    const-wide/32 v5, 0x1fc000

    const-wide/32 v5, 0x1fc000

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    and-long/2addr v5, p1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-wide/32 v7, 0x200000

    const-wide/32 v7, 0x200000

    const/4 v10, 0x2

    const-wide/32 v7, 0x200000

    const-wide/32 v7, 0x200000

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    or-long/2addr v5, v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v7, 0x2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    shl-long/2addr v5, v7

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    or-long/2addr v3, v5

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-wide/16 v5, 0x3f80

    const-wide/16 v5, 0x3f80

    const/4 v10, 0x2

    const-wide/16 v5, 0x3f80

    const-wide/16 v5, 0x3f80

    const/4 v9, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    and-long/2addr v5, p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const-wide/16 v7, 0x4000

    const-wide/16 v7, 0x4000

    const/4 v10, 0x6

    const-wide/16 v7, 0x4000

    const-wide/16 v7, 0x4000

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    or-long/2addr v5, v7

    const/4 v10, 0x0

    shl-long/2addr v5, v2

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    or-long v2, v3, v5

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v10, 0x5

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v10, 0x3

    and-long/2addr p1, v4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    or-long/2addr p1, v4

    const/4 v10, 0x5

    or-long/2addr p1, v2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v1, v0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    return-void
.end method

.method private writeVarint64FiveBytes(J)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/lit8 v0, v0, -0x5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v8, 0x3

    and-int/2addr v9, v8

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    add-int/lit8 v0, v0, -0x2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-wide v2, 0x7f0000000L

    const-wide v2, 0x7f0000000L

    const/4 v9, 0x6

    const-wide v2, 0x7f0000000L

    const-wide v2, 0x7f0000000L

    const/4 v9, 0x5

    and-long/2addr v2, p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    const/16 v4, 0x1c

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    shl-long/2addr v2, v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-wide/32 v4, 0xfe00000

    const-wide/32 v4, 0xfe00000

    const/4 v9, 0x1

    const-wide/32 v4, 0xfe00000

    const-wide/32 v4, 0xfe00000

    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    and-long/2addr v4, p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const-wide/32 v6, 0x10000000

    const/4 v9, 0x5

    const-wide/32 v6, 0x10000000

    const-wide/32 v6, 0x10000000

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    or-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/16 v6, 0x1b

    const/4 v8, 0x7

    or-int/2addr v9, v8

    shl-long/2addr v4, v6

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    or-long/2addr v2, v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const-wide/32 v4, 0x1fc000

    const-wide/32 v4, 0x1fc000

    const/4 v9, 0x1

    const-wide/32 v4, 0x1fc000

    const-wide/32 v4, 0x1fc000

    const/4 v9, 0x6

    const/4 v8, 0x7

    and-long/2addr v4, p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-wide/32 v6, 0x200000

    const-wide/32 v6, 0x200000

    const/4 v9, 0x0

    const-wide/32 v6, 0x200000

    const-wide/32 v6, 0x200000

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    or-long/2addr v4, v6

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/16 v6, 0x1a

    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    shl-long/2addr v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    or-long/2addr v2, v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-wide/16 v4, 0x3f80

    const-wide/16 v4, 0x3f80

    const/4 v9, 0x0

    const-wide/16 v4, 0x3f80

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    and-long/2addr v4, p1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-wide/16 v6, 0x4000

    const-wide/16 v6, 0x4000

    const/4 v9, 0x2

    const-wide/16 v6, 0x4000

    const-wide/16 v6, 0x4000

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    or-long/2addr v4, v6

    const/4 v8, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/16 v6, 0x19

    const/4 v9, 0x0

    shl-long/2addr v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    or-long/2addr v2, v4

    const/4 v9, 0x3

    const/4 v8, 0x3

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    and-long/2addr p1, v4

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v9, 0x1

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    or-long/2addr p1, v4

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/16 v4, 0x18

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    shl-long/2addr p1, v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    or-long/2addr p1, v2

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1, v0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-void
.end method

.method private writeVarint64FourBytes(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    long-to-int p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32FourBytes(I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method private writeVarint64NineBytes(J)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/lit8 v2, v1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/16 v2, 0x38

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    ushr-long v2, p1, v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    long-to-int v2, v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    int-to-byte v2, v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-wide v0, 0xffffffffffffffL

    const-wide v0, 0xffffffffffffffL

    const/4 v5, 0x5

    const-wide v0, 0xffffffffffffffL

    const-wide v0, 0xffffffffffffffL

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    and-long/2addr p1, v0

    const/4 v5, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64EightBytesWithSign(J)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method

.method private writeVarint64OneByte(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    long-to-int p1, p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32OneByte(I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method private writeVarint64SevenBytes(J)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    add-int/lit8 v0, v0, -0x7

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-wide v2, 0x1fc0000000000L

    const-wide v2, 0x1fc0000000000L

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    and-long/2addr v2, p1

    const/4 v9, 0x2

    const/16 v4, 0xe

    const/4 v9, 0x5

    shl-long/2addr v2, v4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-wide v4, 0x3f800000000L

    const-wide v4, 0x3f800000000L

    const/4 v9, 0x0

    const-wide v4, 0x3f800000000L

    const-wide v4, 0x3f800000000L

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    and-long/2addr v4, p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-wide v6, 0x40000000000L

    const-wide v6, 0x40000000000L

    const/4 v9, 0x0

    const-wide v6, 0x40000000000L

    const-wide v6, 0x40000000000L

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    or-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/16 v6, 0xd

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    shl-long/2addr v4, v6

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    or-long/2addr v2, v4

    const/4 v8, 0x3

    shl-int/2addr v9, v8

    const-wide v4, 0x7f0000000L

    const-wide v4, 0x7f0000000L

    const/4 v9, 0x2

    const-wide v4, 0x7f0000000L

    const-wide v4, 0x7f0000000L

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    and-long/2addr v4, p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide v6, 0x800000000L

    const-wide v6, 0x800000000L

    const/4 v9, 0x2

    const-wide v6, 0x800000000L

    const-wide v6, 0x800000000L

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    or-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/16 v6, 0xc

    const/4 v9, 0x4

    const/4 v8, 0x0

    shl-long/2addr v4, v6

    const/4 v9, 0x6

    const/4 v8, 0x6

    or-long/2addr v2, v4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-wide/32 v4, 0xfe00000

    const/4 v8, 0x6

    const/4 v8, 0x4

    and-long/2addr v4, p1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const-wide/32 v6, 0x10000000

    const-wide/32 v6, 0x10000000

    const/4 v9, 0x1

    const-wide/32 v6, 0x10000000

    const-wide/32 v6, 0x10000000

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    or-long/2addr v4, v6

    const/4 v9, 0x6

    const/16 v6, 0xb

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    shl-long/2addr v4, v6

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    or-long/2addr v2, v4

    const/4 v9, 0x6

    const-wide/32 v4, 0x1fc000

    const-wide/32 v4, 0x1fc000

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    and-long/2addr v4, p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-wide/32 v6, 0x200000

    const-wide/32 v6, 0x200000

    const/4 v9, 0x7

    const-wide/32 v6, 0x200000

    const-wide/32 v6, 0x200000

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    or-long/2addr v4, v6

    const/4 v8, 0x6

    move v9, v8

    const/16 v6, 0xa

    const/4 v9, 0x3

    const/4 v8, 0x5

    shl-long/2addr v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x4

    or-long/2addr v2, v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-wide/16 v4, 0x3f80

    const-wide/16 v4, 0x3f80

    const/4 v9, 0x5

    const-wide/16 v4, 0x3f80

    const-wide/16 v4, 0x3f80

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    and-long/2addr v4, p1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-wide/16 v6, 0x4000

    const/4 v9, 0x5

    const-wide/16 v6, 0x4000

    const-wide/16 v6, 0x4000

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    or-long/2addr v4, v6

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/16 v6, 0x9

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    shl-long/2addr v4, v6

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    or-long/2addr v2, v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v9, 0x1

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    and-long/2addr p1, v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v9, 0x2

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    or-long/2addr p1, v4

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/16 v4, 0x8

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    shl-long/2addr p1, v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    or-long/2addr p1, v2

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v1, v0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    return-void
.end method

.method private writeVarint64SixBytes(J)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    add-int/lit8 v0, v0, -0x6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-wide v2, 0x3f800000000L

    const-wide v2, 0x3f800000000L

    const/4 v9, 0x1

    const-wide v2, 0x3f800000000L

    const-wide v2, 0x3f800000000L

    const/4 v8, 0x7

    const/4 v8, 0x5

    and-long/2addr v2, p1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/16 v4, 0x15

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    shl-long/2addr v2, v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-wide v4, 0x7f0000000L

    const/4 v9, 0x1

    const-wide v4, 0x7f0000000L

    const-wide v4, 0x7f0000000L

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    and-long/2addr v4, p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-wide v6, 0x800000000L

    const-wide v6, 0x800000000L

    const/4 v9, 0x4

    const-wide v6, 0x800000000L

    const-wide v6, 0x800000000L

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    or-long/2addr v4, v6

    const/4 v9, 0x7

    const/16 v6, 0x14

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    shl-long/2addr v4, v6

    const/4 v9, 0x3

    or-long/2addr v2, v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-wide/32 v4, 0xfe00000

    const-wide/32 v4, 0xfe00000

    const/4 v9, 0x1

    const-wide/32 v4, 0xfe00000

    const-wide/32 v4, 0xfe00000

    const/4 v9, 0x3

    const/4 v8, 0x0

    and-long/2addr v4, p1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-wide/32 v6, 0x10000000

    const-wide/32 v6, 0x10000000

    const/4 v9, 0x1

    const-wide/32 v6, 0x10000000

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    or-long/2addr v4, v6

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v6, 0x13

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    shl-long/2addr v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    or-long/2addr v2, v4

    const/4 v9, 0x6

    const-wide/32 v4, 0x1fc000

    const-wide/32 v4, 0x1fc000

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    and-long/2addr v4, p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-wide/32 v6, 0x200000

    const/4 v9, 0x0

    const-wide/32 v6, 0x200000

    const-wide/32 v6, 0x200000

    const/4 v8, 0x1

    const/4 v8, 0x7

    or-long/2addr v4, v6

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/16 v6, 0x12

    const/4 v9, 0x0

    shl-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    or-long/2addr v2, v4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-wide/16 v4, 0x3f80

    const-wide/16 v4, 0x3f80

    const/4 v9, 0x0

    const-wide/16 v4, 0x3f80

    const-wide/16 v4, 0x3f80

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    and-long/2addr v4, p1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-wide/16 v6, 0x4000

    const-wide/16 v6, 0x4000

    const/4 v9, 0x5

    const-wide/16 v6, 0x4000

    const-wide/16 v6, 0x4000

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    or-long/2addr v4, v6

    const/4 v8, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/16 v6, 0x11

    const/4 v9, 0x4

    shl-long/2addr v4, v6

    const/4 v8, 0x3

    move v9, v8

    or-long/2addr v2, v4

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v9, 0x0

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    and-long/2addr p1, v4

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v9, 0x0

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    or-long/2addr p1, v4

    const/4 v9, 0x6

    const/16 v4, 0x10

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    shl-long/2addr p1, v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    or-long/2addr p1, v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v1, v0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-void
.end method

.method private writeVarint64TenBytes(J)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    add-int/lit8 v2, v1, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/16 v2, 0x3f

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    ushr-long v2, p1, v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    long-to-int v2, v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    int-to-byte v2, v2

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v7, 0x7

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    add-int/lit8 v2, v1, -0x1

    const/4 v7, 0x0

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/16 v2, 0x38

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    ushr-long v2, p1, v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-wide/16 v4, 0x7f

    const-wide/16 v4, 0x7f

    const/4 v7, 0x7

    const-wide/16 v4, 0x7f

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    and-long/2addr v2, v4

    const/4 v7, 0x5

    const-wide/16 v4, 0x80

    const-wide/16 v4, 0x80

    const/4 v7, 0x1

    const-wide/16 v4, 0x80

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    or-long/2addr v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    long-to-int v2, v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    int-to-byte v2, v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-wide v0, 0xffffffffffffffL

    const-wide v0, 0xffffffffffffffL

    const/4 v7, 0x6

    const-wide v0, 0xffffffffffffffL

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    and-long/2addr p1, v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64EightBytesWithSign(J)V

    const/4 v7, 0x3

    return-void
.end method

.method private writeVarint64ThreeBytes(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v0, 0x1

    long-to-int p1, p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32ThreeBytes(I)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private writeVarint64TwoBytes(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    long-to-int p1, p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32TwoBytes(I)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method finishCurrentBuffer()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->bytesWrittenToCurrentBuffer()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    add-int/2addr v0, v1

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x4

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->limitMinusOne:I

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public getTotalBytesWritten()I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->bytesWrittenToCurrentBuffer()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0
.end method

.method requireSpace(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "size"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->spaceLeft()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-ge v0, p1, :cond_0

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer(I)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public write(B)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v4, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v2, v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, p1}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method public write(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->spaceLeft()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-ge v1, v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer(I)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v2, 0x6

    and-int/2addr v3, v2

    sub-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public write([BII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->spaceLeft()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ge v0, p3, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0, p3}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer(I)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    sub-int/2addr v0, p3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2, p3}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method public writeBool(IZ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    int-to-byte p2, p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->write(B)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method writeBool(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    int-to-byte p1, p1

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->write(B)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public writeBytes(ILcom/google/protobuf/ByteString;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, p0}, Lcom/google/protobuf/ByteString;->writeToReverse(Lcom/google/protobuf/ByteOutput;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/16 v0, 0xa

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p2}, Lcom/google/protobuf/ByteString;->size()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 p2, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void

    :catch_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance p2, Ljava/lang/RuntimeException;

    const/4 v2, 0x6

    invoke-direct {p2, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    throw p2
.end method

.method public writeEndGroup(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method writeFixed32(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/lit8 v0, v0, -0x4

    const/4 v3, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v1, v0, p1}, Ljava/nio/ByteBuffer;->putInt(II)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public writeFixed32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 v0, 0x9

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeFixed32(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x0

    return-void
.end method

.method public writeFixed64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/16 v0, 0xd

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeFixed64(J)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p2, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method writeFixed64(J)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x5

    add-int/lit8 v0, v0, -0x8

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1, v0, p1, p2}, Ljava/nio/ByteBuffer;->putLong(IJ)Ljava/nio/ByteBuffer;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public writeGroup(ILjava/lang/Object;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/Protobuf;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 p2, 0x3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public writeGroup(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {p3, p2, p0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p2, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method writeInt32(I)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ltz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    int-to-long v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64(J)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public writeInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/16 v0, 0xf

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeInt32(I)V

    const/4 p2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x7

    move v1, p2

    move v1, p2

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public writeLazy(Ljava/nio/ByteBuffer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/nio/Buffer;->remaining()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->spaceLeft()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ge v1, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    add-int/2addr v1, v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput v1, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/google/protobuf/AllocatedBuffer;->wrap(Ljava/nio/ByteBuffer;)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    sub-int/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x5

    or-int/2addr v3, v2

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public writeLazy([BII)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "value",
            "offset",
            "length"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->spaceLeft()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ge v0, p3, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    add-int/2addr v0, p3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput v0, p0, Lcom/google/protobuf/BinaryWriter;->totalDoneBytes:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter;->buffers:Ljava/util/ArrayDeque;

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-static {p1, p2, p3}, Lcom/google/protobuf/AllocatedBuffer;->wrap([BII)Lcom/google/protobuf/AllocatedBuffer;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayDeque;->addFirst(Ljava/lang/Object;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->nextBuffer()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x3

    sub-int/2addr v0, p3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/google/protobuf/Java8Compatibility;->position(Ljava/nio/Buffer;I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p2, p3}, Ljava/nio/ByteBuffer;->put([BII)Ljava/nio/ByteBuffer;

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    return-void
.end method

.method public writeMessage(ILjava/lang/Object;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, p2, p0}, Lcom/google/protobuf/Protobuf;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    sub-int/2addr p2, v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/16 v0, 0xa

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p2, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public writeMessage(ILjava/lang/Object;Lcom/google/protobuf/Schema;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value",
            "schema"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {p3, p2, p0}, Lcom/google/protobuf/Schema;->writeTo(Ljava/lang/Object;Lcom/google/protobuf/Writer;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    sub-int/2addr p2, v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/16 p3, 0xa

    const/4 v2, 0x7

    invoke-virtual {p0, p3}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p2, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method writeSInt32(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag32(I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public writeSInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/16 v0, 0xa

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeSInt32(I)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p2, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public writeSInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 v0, 0xf

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeSInt64(J)V

    const/4 v1, 0x5

    move v2, v1

    const/4 p2, 0x0

    move v2, p2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method writeSInt64(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-static {p1, p2}, Lcom/google/protobuf/CodedOutputStream;->encodeZigZag64(J)J

    move-result-wide p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64(J)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public writeStartGroup(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fieldNumber"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public writeString(ILjava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->getTotalBytesWritten()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeString(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->getTotalBytesWritten()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    sub-int/2addr p2, v0

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/16 v0, 0xa

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p2, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method writeString(Ljava/lang/String;)V
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "in"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v1, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    sub-int/2addr v0, v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    sub-int/2addr v2, v0

    iput v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/16 v2, 0x80

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-ltz v0, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    if-ge v3, v2, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget v4, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/2addr v4, v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    int-to-byte v3, v3

    const/4 v8, 0x4

    and-int/2addr v9, v8

    invoke-virtual {v2, v4, v3}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v3, -0x1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-ne v0, v3, :cond_1

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x4

    const/4 v8, 0x1

    sub-int/2addr p1, v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    iput p1, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    return-void

    :cond_1
    const/4 v9, 0x5

    iget v4, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v8, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/2addr v4, v0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    iput v4, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-ltz v0, :cond_8

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-ge v4, v2, :cond_2

    const/4 v8, 0x1

    and-int/2addr v9, v8

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    if-ltz v5, :cond_2

    const/4 v8, 0x6

    move v9, v8

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    add-int/lit8 v7, v5, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    int-to-byte v4, v4

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v6, v5, v4}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x1

    goto/16 :goto_2

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/16 v5, 0x800

    const/4 v9, 0x5

    if-ge v4, v5, :cond_3

    const/4 v9, 0x1

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-lez v5, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    add-int/lit8 v7, v5, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    and-int/lit8 v7, v4, 0x3f

    const/4 v9, 0x5

    or-int/2addr v7, v2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    int-to-byte v7, v7

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v6, v5, v7}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x4

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    ushr-int/lit8 v4, v4, 0x6

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    or-int/lit16 v4, v4, 0x3c0

    const/4 v8, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    int-to-byte v4, v4

    const/4 v9, 0x0

    invoke-virtual {v5, v6, v4}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x7

    goto/16 :goto_2

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    const v5, 0xd800

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-lt v4, v5, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    const v5, 0xdfff

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-ge v5, v4, :cond_5

    :cond_4
    const/4 v8, 0x3

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    if-le v5, v1, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    add-int/lit8 v7, v5, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x5

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    and-int/lit8 v7, v4, 0x3f

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    or-int/2addr v7, v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    int-to-byte v7, v7

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v6, v5, v7}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x5

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    ushr-int/lit8 v7, v4, 0x6

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    and-int/lit8 v7, v7, 0x3f

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    or-int/2addr v7, v2

    const/4 v9, 0x3

    int-to-byte v7, v7

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v5, v6, v7}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    ushr-int/lit8 v4, v4, 0xc

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    or-int/lit16 v4, v4, 0x1e0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    int-to-byte v4, v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v5, v6, v4}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    goto/16 :goto_2

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x3

    iget v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v6, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x6

    if-le v5, v6, :cond_7

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v0, :cond_6

    const/4 v9, 0x7

    add-int/lit8 v5, v0, -0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v5, v4}, Ljava/lang/Character;->isSurrogatePair(CC)Z

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v6, :cond_6

    const/4 v9, 0x1

    const/4 v8, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v5, v4}, Ljava/lang/Character;->toCodePoint(CC)I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    and-int/lit8 v7, v4, 0x3f

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    or-int/2addr v7, v2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    int-to-byte v7, v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v5, v6, v7}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x1

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    ushr-int/lit8 v7, v4, 0x6

    const/4 v9, 0x4

    const/4 v8, 0x6

    and-int/lit8 v7, v7, 0x3f

    const/4 v9, 0x4

    const/4 v8, 0x5

    or-int/2addr v7, v2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    int-to-byte v7, v7

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v5, v6, v7}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    ushr-int/lit8 v7, v4, 0xc

    const/4 v9, 0x0

    and-int/lit8 v7, v7, 0x3f

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    or-int/2addr v7, v2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    int-to-byte v7, v7

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v5, v6, v7}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->buffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget v6, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    add-int/lit8 v7, v6, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    iput v7, p0, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->pos:I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    ushr-int/lit8 v4, v4, 0x12

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    or-int/lit16 v4, v4, 0xf0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    int-to-byte v4, v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v5, v6, v4}, Ljava/nio/ByteBuffer;->put(IB)Ljava/nio/ByteBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_2

    :cond_6
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance p1, Lcom/google/protobuf/Utf8$UnpairedSurrogateException;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    add-int/lit8 v1, v0, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {p1, v1, v0}, Lcom/google/protobuf/Utf8$UnpairedSurrogateException;-><init>(II)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    throw p1

    :cond_7
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    add-int/lit8 v0, v0, 0x1

    :goto_2
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-int/2addr v0, v3

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto/16 :goto_1

    :cond_8
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    return-void
.end method

.method writeTag(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "wireType"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/google/protobuf/WireFormat;->makeTag(II)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public writeUInt32(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/16 v0, 0xa

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32(I)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public writeUInt64(IJ)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fieldNumber",
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/16 v0, 0xf

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->requireSpace(I)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p2, p3}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64(J)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeTag(II)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method writeVarint32(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    and-int/lit8 v0, p1, -0x80

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32OneByte(I)V

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    and-int/lit16 v0, p1, -0x4000

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32TwoBytes(I)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/high16 v0, -0x200000

    const/4 v2, 0x6

    const/4 v1, 0x2

    and-int/2addr v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32ThreeBytes(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/high16 v0, -0x10000000

    const/4 v2, 0x5

    and-int/2addr v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32FourBytes(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_3
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint32FiveBytes(I)V

    :goto_0
    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method writeVarint64(J)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, p2}, Lcom/google/protobuf/BinaryWriter;->access$200(J)B

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    packed-switch v0, :pswitch_data_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :pswitch_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64TenBytes(J)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :pswitch_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64NineBytes(J)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :pswitch_2
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64EightBytes(J)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    goto :goto_0

    :pswitch_3
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64SevenBytes(J)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    goto :goto_0

    :pswitch_4
    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64SixBytes(J)V

    goto :goto_0

    :pswitch_5
    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64FiveBytes(J)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :pswitch_6
    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64FourBytes(J)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_0

    :pswitch_7
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64ThreeBytes(J)V

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_8
    const/4 v2, 0x3

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64TwoBytes(J)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :pswitch_9
    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BinaryWriter$SafeDirectWriter;->writeVarint64OneByte(J)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
