.class final Lcom/google/protobuf/LongArrayList;
.super Lcom/google/protobuf/AbstractProtobufList;

# interfaces
.implements Lcom/google/protobuf/Internal$LongList;
.implements Ljava/util/RandomAccess;
.implements Lcom/google/protobuf/PrimitiveNonBoxingCollection;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/AbstractProtobufList<",
        "Ljava/lang/Long;",
        ">;",
        "Lcom/google/protobuf/Internal$LongList;",
        "Ljava/util/RandomAccess;",
        "Lcom/google/protobuf/PrimitiveNonBoxingCollection;"
    }
.end annotation


# static fields
.field private static final EMPTY_LIST:Lcom/google/protobuf/LongArrayList;


# instance fields
.field private array:[J

.field private size:I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lcom/google/protobuf/LongArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v4, v3

    new-array v2, v1, [J

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0, v2, v1, v1}, Lcom/google/protobuf/LongArrayList;-><init>([JIZ)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    sput-object v0, Lcom/google/protobuf/LongArrayList;->EMPTY_LIST:Lcom/google/protobuf/LongArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method constructor <init>()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/16 v0, 0xa

    const/4 v4, 0x5

    const/4 v3, 0x0

    new-array v0, v0, [J

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x3

    invoke-direct {p0, v0, v1, v2}, Lcom/google/protobuf/LongArrayList;-><init>([JIZ)V

    const/4 v3, 0x4

    move v4, v3

    return-void
.end method

.method private constructor <init>([JIZ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "other",
            "size",
            "isMutable"
        }
    .end annotation

    const/4 v1, 0x6

    invoke-direct {p0, p3}, Lcom/google/protobuf/AbstractProtobufList;-><init>(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p2, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private addLong(IJ)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@s br~@s~~@o@@/@i i~~@vo@@@nu~~ ~ @~m~~~  -~l~ f@4~@   t~t Klo~@@ ~Mf~~  ~odc@o y@1/ob@ a~.S b@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ltz p1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-gt p1, v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v5, 0x0

    const/4 v4, 0x5

    array-length v2, v1

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ge v0, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    add-int/lit8 v2, p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    sub-int/2addr v0, p1

    invoke-static {v1, p1, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    mul-int/lit8 v0, v0, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    div-int/lit8 v0, v0, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-array v0, v0, [J

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x5

    invoke-static {v1, v2, v0, v2, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/lit8 v2, p1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v3, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    sub-int/2addr v3, p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-static {v1, p1, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v5, 0x7

    const/4 v4, 0x2

    aput-wide p2, v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget p1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput p1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance p2, Ljava/lang/IndexOutOfBoundsException;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/LongArrayList;->makeOutOfBoundsExceptionMessage(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p2, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    throw p2
.end method

.method public static emptyList()Lcom/google/protobuf/LongArrayList;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/LongArrayList;->EMPTY_LIST:Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method private ensureIndexInRange(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-ltz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-ge p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/LongArrayList;->makeOutOfBoundsExceptionMessage(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw v0
.end method

.method private makeOutOfBoundsExceptionMessage(I)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "xIdm:s"

    const-string v1, "dIsx:e"

    const/4 v3, 0x4

    const-string v1, "e:dnoI"

    const-string v1, "Index:"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string p1, ":iSmez,"

    const/4 v3, 0x6

    const-string p1, " S,zibe"

    const-string p1, ", Size:"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget p1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p1
.end method


# virtual methods
.method public add(ILjava/lang/Long;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0, p1, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(IJ)V

    return-void
.end method

.method public bridge synthetic add(ILjava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    check-cast p2, Ljava/lang/Long;

    const/4 v0, 0x4

    move v1, v0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/LongArrayList;->add(ILjava/lang/Long;)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public add(Ljava/lang/Long;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 p1, 0x1

    move v3, p1

    const/4 v2, 0x1

    move v3, v2

    return p1
.end method

.method public bridge synthetic add(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    check-cast p1, Ljava/lang/Long;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/LongArrayList;->add(Ljava/lang/Long;)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return p1
.end method

.method public addAll(Ljava/util/Collection;)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "collection"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+",
            "Ljava/lang/Long;",
            ">;)Z"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p1}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    instance-of v0, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractProtobufList;->addAll(Ljava/util/Collection;)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    return p1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    check-cast p1, Lcom/google/protobuf/LongArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x3

    iget v0, p1, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    return v1

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v2, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    const v3, 0x7fffffff

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    sub-int/2addr v3, v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-lt v3, v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/2addr v2, v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v6, 0x3

    array-length v3, v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-le v2, v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    :cond_2
    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v0, p1, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v4, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget p1, p1, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-static {v0, v1, v3, v4, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iput v2, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int/2addr p1, v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    return v0

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/OutOfMemoryError;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {p1}, Ljava/lang/OutOfMemoryError;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    throw p1
.end method

.method public addLong(J)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v5, 0x1

    iget v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    array-length v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne v0, v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    mul-int/lit8 v2, v0, 0x3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    div-int/lit8 v2, v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x5

    move v5, v4

    new-array v2, v2, [J

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v3, v2, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput v2, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v5, 0x2

    aput-wide p1, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/LongArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x6

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v0, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-ne p0, p1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    return v0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    instance-of v1, p1, Lcom/google/protobuf/LongArrayList;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-nez v1, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractProtobufList;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    return p1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    check-cast p1, Lcom/google/protobuf/LongArrayList;

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    iget v1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget v2, p1, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v9, 0x6

    const/4 v3, 0x0

    const/4 v9, 0x3

    shr-int/2addr v8, v3

    const/4 v9, 0x1

    if-eq v1, v2, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    return v3

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object p1, p1, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    move v1, v3

    const/4 v9, 0x0

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget v2, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-ge v1, v2, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v2, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    aget-wide v4, v2, v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    aget-wide v6, p1, v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    cmp-long v2, v4, v6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v2, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    return v3

    :cond_3
    const/4 v8, 0x7

    move v9, v8

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_0

    :cond_4
    const/4 v9, 0x6

    const/4 v8, 0x5

    return v0
.end method

.method public get(I)Ljava/lang/Long;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/google/protobuf/LongArrayList;->getLong(I)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p1
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/LongArrayList;->get(I)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-object p1
.end method

.method public getLong(I)J
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p0, p1}, Lcom/google/protobuf/LongArrayList;->ensureIndexInRange(I)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v3, 0x3

    move v4, v3

    aget-wide v1, v0, p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-wide v1
.end method

.method public hashCode()I
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    iget v2, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-ge v1, v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    mul-int/lit8 v0, v0, 0x1f

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    aget-wide v3, v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v3, v4}, Lcom/google/protobuf/Internal;->hashLong(J)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    add-int/2addr v0, v2

    const/4 v5, 0x2

    and-int/2addr v6, v5

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    return v0
.end method

.method public indexOf(Ljava/lang/Object;)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    instance-of v0, p1, Ljava/lang/Long;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v1, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    return v1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    check-cast p1, Ljava/lang/Long;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/LongArrayList;->size()I

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v0, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-ge v0, p1, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v4, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    aget-wide v5, v4, v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    cmp-long v4, v5, v2

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-nez v4, :cond_1

    const/4 v8, 0x1

    return v0

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    goto :goto_0

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x2

    return v1
.end method

.method public mutableCopyWithCapacity(I)Lcom/google/protobuf/Internal$LongList;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-lt p1, v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v0, Lcom/google/protobuf/LongArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v4, 0x7

    invoke-static {v1, p1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, p1, v1, v2}, Lcom/google/protobuf/LongArrayList;-><init>([JIZ)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    throw p1
.end method

.method public bridge synthetic mutableCopyWithCapacity(I)Lcom/google/protobuf/Internal$ProtobufList;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/LongArrayList;->mutableCopyWithCapacity(I)Lcom/google/protobuf/Internal$LongList;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public remove(I)Ljava/lang/Long;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/LongArrayList;->ensureIndexInRange(I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    aget-wide v1, v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    iget v3, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-int/lit8 v4, v3, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-ge p1, v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    add-int/lit8 v4, p1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    sub-int/2addr v3, p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    add-int/lit8 v3, v3, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v0, v4, v0, p1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget p1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    add-int/lit8 p1, p1, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput p1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object p1
.end method

.method public bridge synthetic remove(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/LongArrayList;->remove(I)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-object p1
.end method

.method protected removeRange(II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fromIndex",
            "toIndex"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-lt p2, p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v1, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v3, 0x0

    sub-int/2addr v1, p2

    const/4 v3, 0x0

    invoke-static {v0, p2, v0, p1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v2, 0x7

    move v3, v2

    sub-int/2addr p2, p1

    const/4 v2, 0x0

    move v3, v2

    sub-int/2addr v0, p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo p2, "xe<ooIuInf dmt edno"

    const-string p2, "Ie<eo fdrmdxnont oI"

    const/4 v3, 0x3

    const-string/jumbo p2, "xoedfxep d <ntIImon"

    const-string/jumbo p2, "toIndex < fromIndex"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p1
.end method

.method public set(ILjava/lang/Long;)Ljava/lang/Long;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p1, v0, v1}, Lcom/google/protobuf/LongArrayList;->setLong(IJ)J

    move-result-wide p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p1
.end method

.method public bridge synthetic set(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    check-cast p2, Ljava/lang/Long;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/LongArrayList;->set(ILjava/lang/Long;)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public setLong(IJ)J
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/google/protobuf/LongArrayList;->ensureIndexInRange(I)V

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/google/protobuf/LongArrayList;->array:[J

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    aget-wide v1, v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    aput-wide p2, v0, p1

    const/4 v4, 0x4

    return-wide v1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/google/protobuf/LongArrayList;->size:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method
