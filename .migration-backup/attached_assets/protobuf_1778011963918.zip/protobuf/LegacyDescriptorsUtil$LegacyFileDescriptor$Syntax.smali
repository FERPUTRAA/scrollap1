.class public final enum Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Syntax"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

.field public static final enum PROTO2:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

.field public static final enum PROTO3:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

.field public static final enum UNKNOWN:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;


# instance fields
.field final name:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v1, "ossnkuw"

    const-string/jumbo v1, "knsunow"

    const/4 v9, 0x1

    const-string/jumbo v1, "nwnmouk"

    const-string/jumbo v1, "unknown"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string v2, "KONNoWU"

    const-string v2, "OWKmNNU"

    const/4 v9, 0x7

    const-string v2, "WNNKUbN"

    const-string v2, "UNKNOWN"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {v0, v2, v3, v1}, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    sput-object v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->UNKNOWN:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x7

    new-instance v1, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v2, "uo2opo"

    const-string/jumbo v2, "p2ooor"

    const/4 v9, 0x3

    const-string/jumbo v2, "op2pro"

    const-string/jumbo v2, "proto2"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string v4, "TOqPb2"

    const-string v4, "TO2POb"

    const/4 v9, 0x3

    const-string v4, "PTsO2R"

    const-string v4, "PROTO2"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v5, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-direct {v1, v4, v5, v2}, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    sput-object v1, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->PROTO2:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    new-instance v2, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x5

    const-string/jumbo v4, "otumr3"

    const-string/jumbo v4, "uro3to"

    const-string/jumbo v4, "rt3poo"

    const-string/jumbo v4, "proto3"

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v6, "3pTPRb"

    const-string v6, "RpOP3T"

    const/4 v9, 0x0

    const-string/jumbo v6, "uRPT3O"

    const-string v6, "PROTO3"

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v7, 0x2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {v2, v6, v7, v4}, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    sput-object v2, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->PROTO3:Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    const/4 v4, 0x3

    const/4 v9, 0x6

    const/4 v8, 0x7

    new-array v4, v4, [Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    aput-object v0, v4, v3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    aput-object v1, v4, v5

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    aput-object v2, v4, v7

    const/4 v8, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    sput-object v4, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->$VALUES:[Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "name"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->name:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@.~ ~@ p @~~S~v 1~bf4 o  n@~ @@tol@o~/~ b@/ufo~@~~bd@l~i~o-K~o s~r~   ~@~m~t~@@yia@@c  @M@@ ~ i@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const-class v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const-class v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x3

    const-class v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const-class v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast p0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->$VALUES:[Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    check-cast v0, [Lcom/google/protobuf/LegacyDescriptorsUtil$LegacyFileDescriptor$Syntax;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method
