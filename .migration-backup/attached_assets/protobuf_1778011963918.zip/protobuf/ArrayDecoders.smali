.class final Lcom/google/protobuf/ArrayDecoders;
.super Ljava/lang/Object;


# annotations
.annotation runtime Lcom/google/protobuf/CheckReturnValue;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/ArrayDecoders$Registers;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method static decodeBoolList(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast p4, Lcom/google/protobuf/BooleanArrayList;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-wide v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v8, 0x6

    const/4 v7, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    cmp-long v0, v0, v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v1, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v4, 0x0

    const/4 v7, 0x3

    shr-int/2addr v8, v7

    if-eqz v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    move v0, v1

    move v0, v1

    const/4 v8, 0x5

    move v0, v1

    move v0, v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    move v0, v4

    move v0, v4

    const/4 v8, 0x2

    move v0, v4

    move v0, v4

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x0

    invoke-virtual {p4, v0}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(Z)V

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-ge p2, p3, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget v5, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eq p0, v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_3

    :cond_1
    const/4 v7, 0x0

    move v8, v7

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-wide v5, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    cmp-long v0, v5, v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-eqz v0, :cond_2

    const/4 v8, 0x1

    move v0, v1

    move v0, v1

    const/4 v8, 0x1

    move v0, v1

    move v0, v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    goto :goto_2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x7

    move v0, v4

    move v0, v4

    const/4 v8, 0x3

    move v0, v4

    move v0, v4

    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p4, v0}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(Z)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto :goto_1

    :cond_3
    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    return p2
.end method

.method static decodeBytes([BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0, p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x1

    if-ltz v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    array-length v1, p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    sub-int/2addr v1, p1

    const/4 v3, 0x2

    if-gt v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x7

    sget-object p0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object p0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-static {p0, p1, v0}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object p0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    add-int/2addr p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p1

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    throw p0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw p0
.end method

.method static decodeBytesList(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ltz v0, :cond_7

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    array-length v1, p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    sub-int/2addr v1, p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-gt v0, v1, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1, p2, v0}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/2addr p2, v0

    :goto_1
    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ge p2, p3, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eq p0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_2

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ltz v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    array-length v1, p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    sub-int/2addr v1, p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-gt v0, v1, :cond_3

    const/4 v2, 0x5

    move v3, v2

    if-nez v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {p4, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v2, 0x5

    move v3, v2

    invoke-static {p1, p2, v0}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw p0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p0

    :cond_5
    :goto_2
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p2

    :cond_6
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    throw p0

    :cond_7
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw p0
.end method

.method static decodeDouble([BI)D
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "position"
        }
    .end annotation

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed64([BI)J

    move-result-wide p0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-wide p0
.end method

.method static decodeDoubleList(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p4, Lcom/google/protobuf/DoubleArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeDouble([BI)D

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {p4, v0, v1}, Lcom/google/protobuf/DoubleArrayList;->addDouble(D)V

    const/4 v3, 0x5

    move v4, v3

    add-int/lit8 p2, p2, 0x8

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ge p2, p3, :cond_1

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eq p0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p1, v0}, Lcom/google/protobuf/ArrayDecoders;->decodeDouble([BI)D

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p4, v1, v2}, Lcom/google/protobuf/DoubleArrayList;->addDouble(D)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/lit8 p2, v0, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return p2
.end method

.method static decodeExtension(I[BIILcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "message",
            "extension",
            "unknownFieldSchema",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage<",
            "**>;",
            "Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension<",
            "**>;",
            "Lcom/google/protobuf/UnknownFieldSchema<",
            "Lcom/google/protobuf/UnknownFieldSetLite;",
            "Lcom/google/protobuf/UnknownFieldSetLite;",
            ">;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    iget-object v0, p4, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->extensions:Lcom/google/protobuf/FieldSet;

    ushr-int/lit8 v2, p0, 0x3

    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isRepeated()Z

    move-result p0

    if-eqz p0, :cond_0

    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->isPacked()Z

    move-result p0

    if-eqz p0, :cond_0

    sget-object p0, Lcom/google/protobuf/ArrayDecoders$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    move-result p3

    aget p0, p0, p3

    packed-switch p0, :pswitch_data_0

    new-instance p0, Ljava/lang/IllegalStateException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "  sasn tk:cppcb oTeydea"

    const-string p2, "eTsk ytcp:d ecpo  aaebn"

    const-string/jumbo p2, "ycnmebpct pae  nTadk eo"

    const-string p2, "Type cannot be packed: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {p2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_0
    new-instance p0, Lcom/google/protobuf/IntArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/IntArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedVarint32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {p2}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getEnumType()Lcom/google/protobuf/Internal$EnumLiteMap;

    move-result-object v4

    const/4 v5, 0x0

    move-object v1, p4

    move-object v1, p4

    move-object v1, p4

    move-object v1, p4

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    invoke-static/range {v1 .. v6}, Lcom/google/protobuf/SchemaUtil;->filterUnknownEnumList(Ljava/lang/Object;ILjava/util/List;Lcom/google/protobuf/Internal$EnumLiteMap;Ljava/lang/Object;Lcom/google/protobuf/UnknownFieldSchema;)Ljava/lang/Object;

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_1
    new-instance p0, Lcom/google/protobuf/LongArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/LongArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedSInt64List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_2
    new-instance p0, Lcom/google/protobuf/IntArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/IntArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedSInt32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_3
    new-instance p0, Lcom/google/protobuf/BooleanArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/BooleanArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedBoolList([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_4
    new-instance p0, Lcom/google/protobuf/IntArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/IntArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedFixed32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_5
    new-instance p0, Lcom/google/protobuf/LongArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/LongArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedFixed64List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_6
    new-instance p0, Lcom/google/protobuf/IntArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/IntArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedVarint32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_7
    new-instance p0, Lcom/google/protobuf/LongArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/LongArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedVarint64List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_8
    new-instance p0, Lcom/google/protobuf/FloatArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/FloatArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedFloatList([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :pswitch_9
    new-instance p0, Lcom/google/protobuf/DoubleArrayList;

    invoke-direct {p0}, Lcom/google/protobuf/DoubleArrayList;-><init>()V

    invoke-static {p1, p2, p0, p7}, Lcom/google/protobuf/ArrayDecoders;->decodePackedDoubleList([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-object p2, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p2, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto/16 :goto_7

    :cond_0
    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object p0

    sget-object v1, Lcom/google/protobuf/WireFormat$FieldType;->ENUM:Lcom/google/protobuf/WireFormat$FieldType;

    const/4 v3, 0x0

    if-ne p0, v1, :cond_2

    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {p0}, Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;->getEnumType()Lcom/google/protobuf/Internal$EnumLiteMap;

    move-result-object p0

    iget p1, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    invoke-interface {p0, p1}, Lcom/google/protobuf/Internal$EnumLiteMap;->findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;

    move-result-object p0

    if-nez p0, :cond_1

    iget p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    invoke-static {p4, v2, p0, v3, p6}, Lcom/google/protobuf/SchemaUtil;->storeUnknownEnum(Ljava/lang/Object;IILjava/lang/Object;Lcom/google/protobuf/UnknownFieldSchema;)Ljava/lang/Object;

    return p2

    :cond_1
    iget p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto/16 :goto_5

    :cond_2
    sget-object p0, Lcom/google/protobuf/ArrayDecoders$1;->$SwitchMap$com$google$protobuf$WireFormat$FieldType:[I

    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getLiteType()Lcom/google/protobuf/WireFormat$FieldType;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/Enum;->ordinal()I

    move-result p4

    aget p0, p0, p4

    packed-switch p0, :pswitch_data_1

    goto/16 :goto_5

    :pswitch_a
    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object p0

    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getMessageDefaultInstance()Lcom/google/protobuf/MessageLite;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p4

    invoke-virtual {p0, p4}, Lcom/google/protobuf/Protobuf;->schemaFor(Ljava/lang/Class;)Lcom/google/protobuf/Schema;

    move-result-object v2

    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->isRepeated()Z

    move-result p0

    if-eqz p0, :cond_3

    invoke-static {v2, p1, p2, p3, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeMessageField(Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    iget-object p1, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    iget-object p2, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto :goto_0

    :cond_3
    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/FieldSet;->getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_4

    invoke-interface {v2}, Lcom/google/protobuf/Schema;->newInstance()Ljava/lang/Object;

    move-result-object p0

    iget-object p4, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p4, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    :cond_4
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v3, p1

    move-object v3, p1

    move v4, p2

    move v4, p2

    move v5, p3

    move v5, p3

    move v5, p3

    move v5, p3

    move-object v6, p7

    move-object v6, p7

    invoke-static/range {v1 .. v6}, Lcom/google/protobuf/ArrayDecoders;->mergeMessageField(Ljava/lang/Object;Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    :goto_0
    return p0

    :pswitch_b
    shl-int/lit8 p0, v2, 0x3

    or-int/lit8 v6, p0, 0x4

    invoke-static {}, Lcom/google/protobuf/Protobuf;->getInstance()Lcom/google/protobuf/Protobuf;

    move-result-object p0

    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->getMessageDefaultInstance()Lcom/google/protobuf/MessageLite;

    move-result-object p4

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p4

    invoke-virtual {p0, p4}, Lcom/google/protobuf/Protobuf;->schemaFor(Ljava/lang/Class;)Lcom/google/protobuf/Schema;

    move-result-object v2

    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->isRepeated()Z

    move-result p0

    if-eqz p0, :cond_5

    move-object v1, v2

    move-object v1, v2

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move v3, p2

    move v3, p2

    move v4, p3

    move v4, p3

    move v4, p3

    move v4, p3

    move v5, v6

    move v5, v6

    move v5, v6

    move v5, v6

    move-object v6, p7

    move-object v6, p7

    move-object v6, p7

    invoke-static/range {v1 .. v6}, Lcom/google/protobuf/ArrayDecoders;->decodeGroupField(Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    iget-object p1, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    iget-object p2, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    invoke-virtual {v0, p1, p2}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto :goto_1

    :cond_5
    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p0}, Lcom/google/protobuf/FieldSet;->getField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;)Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_6

    invoke-interface {v2}, Lcom/google/protobuf/Schema;->newInstance()Ljava/lang/Object;

    move-result-object p0

    iget-object p4, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p4, p0}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    :cond_6
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move v4, p2

    move v4, p2

    move v4, p2

    move v4, p2

    move v5, p3

    move v5, p3

    move v5, p3

    move-object v7, p7

    move-object v7, p7

    move-object v7, p7

    move-object v7, p7

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/ArrayDecoders;->mergeGroupField(Ljava/lang/Object;Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    :goto_1
    return p0

    :pswitch_c
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeString([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget-object v3, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    goto/16 :goto_5

    :pswitch_d
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeBytes([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget-object v3, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    goto/16 :goto_5

    :pswitch_e
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string/jumbo p1, "o  no.Sradluc/ethher/h"

    const-string p1, "Shouldn\'t reach here."

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_f
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget-wide p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    invoke-static {p0, p1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    goto :goto_5

    :pswitch_10
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    invoke-static {p0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_5

    :pswitch_11
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget-wide p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    cmp-long p0, p0, p3

    if-eqz p0, :cond_7

    const/4 p0, 0x1

    goto :goto_2

    :cond_7
    const/4 p0, 0x0

    :goto_2
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    goto :goto_5

    :pswitch_12
    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed32([BI)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_3

    :pswitch_13
    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed64([BI)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    goto :goto_4

    :pswitch_14
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_5

    :pswitch_15
    invoke-static {p1, p2, p7}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget-wide p0, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    goto :goto_5

    :pswitch_16
    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFloat([BI)F

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    :goto_3
    add-int/lit8 p2, p2, 0x4

    goto :goto_5

    :pswitch_17
    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeDouble([BI)D

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    :goto_4
    add-int/lit8 p2, p2, 0x8

    :goto_5
    invoke-virtual {p5}, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->isRepeated()Z

    move-result p0

    if-eqz p0, :cond_8

    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p0, v3}, Lcom/google/protobuf/FieldSet;->addRepeatedField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    goto :goto_6

    :cond_8
    iget-object p0, p5, Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;->descriptor:Lcom/google/protobuf/GeneratedMessageLite$ExtensionDescriptor;

    invoke-virtual {v0, p0, v3}, Lcom/google/protobuf/FieldSet;->setField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;)V

    :goto_6
    move p1, p2

    move p1, p2

    move p1, p2

    move p1, p2

    :goto_7
    return p1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_7
        :pswitch_6
        :pswitch_6
        :pswitch_5
        :pswitch_5
        :pswitch_4
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x1
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_15
        :pswitch_14
        :pswitch_14
        :pswitch_13
        :pswitch_13
        :pswitch_12
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
    .end packed-switch
.end method

.method static decodeExtensionOrUnknownField(I[BIILjava/lang/Object;Lcom/google/protobuf/MessageLite;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "message",
            "defaultInstance",
            "unknownFieldSchema",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Ljava/lang/Object;",
            "Lcom/google/protobuf/MessageLite;",
            "Lcom/google/protobuf/UnknownFieldSchema<",
            "Lcom/google/protobuf/UnknownFieldSetLite;",
            "Lcom/google/protobuf/UnknownFieldSetLite;",
            ">;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    ushr-int/lit8 v0, p0, 0x3

    iget-object v1, p7, Lcom/google/protobuf/ArrayDecoders$Registers;->extensionRegistry:Lcom/google/protobuf/ExtensionRegistryLite;

    invoke-virtual {v1, p5, v0}, Lcom/google/protobuf/ExtensionRegistryLite;->findLiteExtensionByNumber(Lcom/google/protobuf/MessageLite;I)Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;

    move-result-object v5

    if-nez v5, :cond_0

    invoke-static {p4}, Lcom/google/protobuf/MessageSchema;->getMutableUnknownFields(Ljava/lang/Object;)Lcom/google/protobuf/UnknownFieldSetLite;

    move-result-object v4

    move v0, p0

    move v0, p0

    move v0, p0

    move v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move v2, p2

    move v2, p2

    move v2, p2

    move v3, p3

    move v3, p3

    move v3, p3

    move-object v5, p7

    move-object v5, p7

    move-object v5, p7

    move-object v5, p7

    invoke-static/range {v0 .. v5}, Lcom/google/protobuf/ArrayDecoders;->decodeUnknownField(I[BIILcom/google/protobuf/UnknownFieldSetLite;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    return v0

    :cond_0
    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    check-cast v4, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;

    invoke-virtual {v4}, Lcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;->ensureExtensionsAreMutable()Lcom/google/protobuf/FieldSet;

    move v0, p0

    move v0, p0

    move v0, p0

    move v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    move v3, p3

    move v3, p3

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v7, p7

    move-object v7, p7

    move-object v7, p7

    invoke-static/range {v0 .. v7}, Lcom/google/protobuf/ArrayDecoders;->decodeExtension(I[BIILcom/google/protobuf/GeneratedMessageLite$ExtendableMessage;Lcom/google/protobuf/GeneratedMessageLite$GeneratedExtension;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    return v0
.end method

.method static decodeFixed32([BI)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "position"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    aget-byte v0, p0, p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    and-int/lit16 v0, v0, 0xff

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    add-int/lit8 v1, p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    aget-byte v1, p0, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    and-int/lit16 v1, v1, 0xff

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    shl-int/lit8 v1, v1, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    or-int/2addr v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    add-int/lit8 v1, p1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    aget-byte v1, p0, v1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    and-int/lit16 v1, v1, 0xff

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    shl-int/lit8 v1, v1, 0x10

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    or-int/2addr v0, v1

    const/4 v2, 0x7

    const/4 v3, 0x1

    add-int/lit8 p1, p1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    aget-byte p0, p0, p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    and-int/lit16 p0, p0, 0xff

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    shl-int/lit8 p0, p0, 0x18

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    or-int/2addr p0, v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    return p0
.end method

.method static decodeFixed32List(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast p4, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed32([BI)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p4, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    add-int/lit8 p2, p2, 0x4

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    if-ge p2, p3, :cond_1

    const/4 v3, 0x1

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eq p0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed32([BI)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p4, p2}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/lit8 p2, v0, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return p2
.end method

.method static decodeFixed64([BI)J
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "position"
        }
    .end annotation

    const/4 v8, 0x7

    aget-byte v0, p0, p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    int-to-long v0, v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-wide/16 v2, 0xff

    const/4 v8, 0x1

    const-wide/16 v2, 0xff

    const-wide/16 v2, 0xff

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    and-long/2addr v0, v2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    add-int/lit8 v4, p1, 0x1

    const/4 v8, 0x2

    aget-byte v4, p0, v4

    const/4 v8, 0x2

    int-to-long v4, v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    and-long/2addr v4, v2

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/16 v6, 0x8

    const/4 v8, 0x4

    const/4 v7, 0x1

    shl-long/2addr v4, v6

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    or-long/2addr v0, v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    add-int/lit8 v4, p1, 0x2

    const/4 v8, 0x4

    aget-byte v4, p0, v4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    int-to-long v4, v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    and-long/2addr v4, v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/16 v6, 0x10

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    shl-long/2addr v4, v6

    const/4 v7, 0x1

    move v8, v7

    or-long/2addr v0, v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    add-int/lit8 v4, p1, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    aget-byte v4, p0, v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    int-to-long v4, v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    and-long/2addr v4, v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/16 v6, 0x18

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    shl-long/2addr v4, v6

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    or-long/2addr v0, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    add-int/lit8 v4, p1, 0x4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    aget-byte v4, p0, v4

    const/4 v8, 0x2

    int-to-long v4, v4

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    and-long/2addr v4, v2

    const/4 v8, 0x6

    const/16 v6, 0x20

    const/4 v7, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    shl-long/2addr v4, v6

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    or-long/2addr v0, v4

    const/4 v8, 0x2

    add-int/lit8 v4, p1, 0x5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    aget-byte v4, p0, v4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    int-to-long v4, v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    and-long/2addr v4, v2

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/16 v6, 0x28

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    shl-long/2addr v4, v6

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    or-long/2addr v0, v4

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    add-int/lit8 v4, p1, 0x6

    aget-byte v4, p0, v4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    int-to-long v4, v4

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    and-long/2addr v4, v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/16 v6, 0x30

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    shl-long/2addr v4, v6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    or-long/2addr v0, v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    add-int/lit8 p1, p1, 0x7

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    aget-byte p0, p0, p1

    const/4 v7, 0x0

    and-int/2addr v8, v7

    int-to-long p0, p0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    and-long/2addr p0, v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/16 v2, 0x38

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    shl-long/2addr p0, v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    or-long/2addr p0, v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-wide p0
.end method

.method static decodeFixed64List(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    check-cast p4, Lcom/google/protobuf/LongArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed64([BI)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p4, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    add-int/lit8 p2, p2, 0x8

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-ge p2, p3, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eq p0, v1, :cond_0

    const/4 v4, 0x7

    goto :goto_1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1, v0}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed64([BI)J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p4, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    add-int/lit8 p2, v0, 0x8

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    return p2
.end method

.method static decodeFloat([BI)F
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "position"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed32([BI)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p0
.end method

.method static decodeFloatList(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    check-cast p4, Lcom/google/protobuf/FloatArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFloat([BI)F

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p4, v0}, Lcom/google/protobuf/FloatArrayList;->addFloat(F)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    add-int/lit8 p2, p2, 0x4

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ge p2, p3, :cond_1

    const/4 v3, 0x2

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eq p0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/google/protobuf/ArrayDecoders;->decodeFloat([BI)F

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p4, p2}, Lcom/google/protobuf/FloatArrayList;->addFloat(F)V

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/lit8 p2, v0, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v2, 0x6

    const/4 v3, 0x5

    return p2
.end method

.method static decodeGroupField(Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "schema",
            "data",
            "position",
            "limit",
            "endGroup",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x2

    invoke-interface {p0}, Lcom/google/protobuf/Schema;->newInstance()Ljava/lang/Object;

    move-result-object v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v0, v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x6

    move v3, p2

    move v3, p2

    move v3, p2

    const/4 v8, 0x7

    move v4, p3

    move v4, p3

    move v4, p3

    const/4 v8, 0x1

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    move-object v6, p5

    move-object v6, p5

    const/4 v8, 0x1

    invoke-static/range {v0 .. v6}, Lcom/google/protobuf/ArrayDecoders;->mergeGroupField(Ljava/lang/Object;Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v8, 0x7

    invoke-interface {p0, v7}, Lcom/google/protobuf/Schema;->makeImmutable(Ljava/lang/Object;)V

    const/4 v8, 0x2

    iput-object v7, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    return p1
.end method

.method static decodeGroupList(Lcom/google/protobuf/Schema;I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "schema",
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/Schema;",
            "I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x4

    and-int/lit8 v0, p1, -0x8

    const/4 v7, 0x6

    or-int/lit8 v0, v0, 0x4

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x1

    move v3, p3

    move v3, p3

    move v3, p3

    move v3, p3

    const/4 v7, 0x2

    move v4, p4

    move v4, p4

    const/4 v7, 0x6

    move v5, v0

    move v5, v0

    move v5, v0

    move v5, v0

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v7, 0x0

    invoke-static/range {v1 .. v6}, Lcom/google/protobuf/ArrayDecoders;->decodeGroupField(Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p3

    const/4 v7, 0x2

    iget-object v1, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v7, 0x7

    invoke-interface {p5, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v7, 0x3

    if-ge p3, p4, :cond_1

    const/4 v7, 0x0

    invoke-static {p2, p3, p6}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v3

    const/4 v7, 0x0

    iget v1, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v7, 0x6

    if-eq p1, v1, :cond_0

    const/4 v7, 0x2

    goto :goto_1

    :cond_0
    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x2

    move v4, p4

    move v4, p4

    move v4, p4

    move v4, p4

    const/4 v7, 0x7

    move v5, v0

    move v5, v0

    move v5, v0

    move v5, v0

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    const/4 v7, 0x3

    invoke-static/range {v1 .. v6}, Lcom/google/protobuf/ArrayDecoders;->decodeGroupField(Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p3

    const/4 v7, 0x3

    iget-object v1, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-interface {p5, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v7, 0x2

    return p3
.end method

.method static decodeMessageField(Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "schema",
            "data",
            "position",
            "limit",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-interface {p0}, Lcom/google/protobuf/Schema;->newInstance()Ljava/lang/Object;

    move-result-object v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    move v3, p2

    move v3, p2

    const/4 v8, 0x6

    move v3, p2

    const/4 v7, 0x6

    move v8, v7

    move v4, p3

    move v4, p3

    const/4 v8, 0x6

    move v4, p3

    move v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static/range {v0 .. v5}, Lcom/google/protobuf/ArrayDecoders;->mergeMessageField(Ljava/lang/Object;Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-interface {p0, v6}, Lcom/google/protobuf/Schema;->makeImmutable(Ljava/lang/Object;)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    iput-object v6, p4, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    return p1
.end method

.method static decodeMessageList(Lcom/google/protobuf/Schema;I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "schema",
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/protobuf/Schema<",
            "*>;I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {p0, p2, p3, p4, p6}, Lcom/google/protobuf/ArrayDecoders;->decodeMessageField(Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-interface {p5, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ge p3, p4, :cond_1

    const/4 v3, 0x2

    invoke-static {p2, p3, p6}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    iget v1, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq p1, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-static {p0, p2, v0, p4, p6}, Lcom/google/protobuf/ArrayDecoders;->decodeMessageField(Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p5, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p3
.end method

.method static decodePackedBoolList([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    check-cast p2, Lcom/google/protobuf/BooleanArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget v0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v6, 0x1

    add-int/2addr v0, p1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-ge p1, v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-wide v1, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    cmp-long v1, v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v1, 0x0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p2, v1}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(Z)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne p1, v0, :cond_2

    const/4 v5, 0x7

    const/4 v5, 0x5

    return p1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    throw p0
.end method

.method static decodePackedDoubleList([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast p2, Lcom/google/protobuf/DoubleArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget p3, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    add-int/2addr p3, p1

    :goto_0
    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ge p1, p3, :cond_0

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lcom/google/protobuf/ArrayDecoders;->decodeDouble([BI)D

    move-result-wide v0

    const/4 v3, 0x4

    invoke-virtual {p2, v0, v1}, Lcom/google/protobuf/DoubleArrayList;->addDouble(D)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 p1, p1, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne p1, p3, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method

.method static decodePackedFixed32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v2, 0x2

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget p3, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    add-int/2addr p3, p1

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-ge p1, p3, :cond_0

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed32([BI)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    add-int/lit8 p1, p1, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-ne p1, p3, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    throw p0
.end method

.method static decodePackedFixed64List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast p2, Lcom/google/protobuf/LongArrayList;

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget p3, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/2addr p3, p1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ge p1, p3, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed64([BI)J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p2, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    add-int/lit8 p1, p1, 0x8

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne p1, p3, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    return p1

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    throw p0
.end method

.method static decodePackedFloatList([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    check-cast p2, Lcom/google/protobuf/FloatArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget p3, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    add-int/2addr p3, p1

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-ge p1, p3, :cond_0

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lcom/google/protobuf/ArrayDecoders;->decodeFloat([BI)F

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Lcom/google/protobuf/FloatArrayList;->addFloat(F)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    add-int/lit8 p1, p1, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    if-ne p1, p3, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw p0
.end method

.method static decodePackedSInt32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x5

    add-int/2addr v0, p1

    :goto_0
    const/4 v2, 0x6

    move v3, v2

    if-ge p1, v0, :cond_0

    const/4 v3, 0x0

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v1, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p2, v1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v2, 0x0

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne p1, v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw p0
.end method

.method static decodePackedSInt64List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast p2, Lcom/google/protobuf/LongArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    add-int/2addr v0, p1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ge p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-wide v1, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v4, 0x6

    invoke-static {v1, v2}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne p1, v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return p1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    throw p0
.end method

.method static decodePackedVarint32List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    check-cast p2, Lcom/google/protobuf/IntArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    add-int/2addr v0, p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    if-ge p1, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p2, v1}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ne p1, v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw p0
.end method

.method static decodePackedVarint64List([BILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BI",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast p2, Lcom/google/protobuf/LongArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    add-int/2addr v0, p1

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-ge p1, v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0, p1, p3}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-wide v1, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2, v1, v2}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-ne p1, v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p0
.end method

.method static decodeSInt32List(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast p4, Lcom/google/protobuf/IntArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p4, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    :goto_0
    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ge p2, p3, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    if-eq p0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag32(I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p4, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v2, 0x3

    const/4 v3, 0x7

    return p2
.end method

.method static decodeSInt64List(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast p4, Lcom/google/protobuf/LongArrayList;

    const/4 v3, 0x5

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-wide v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p4, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ge p2, p3, :cond_1

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eq p0, v1, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_1

    :cond_0
    const/4 v2, 0x1

    move v3, v2

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-wide v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/google/protobuf/CodedInputStream;->decodeZigZag64(J)J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p4, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p2
.end method

.method static decodeString([BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0, p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget v0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ltz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x5

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object p0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v4, 0x6

    return p1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v2, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-direct {v1, p0, p1, v0, v2}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v4, 0x5

    iput-object v1, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x7

    add-int/2addr p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    throw p0
.end method

.method static decodeStringList(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-ltz v0, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {p4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/String;

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    sget-object v3, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v2, p1, p2, v0, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    add-int/2addr p2, v0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ge p2, p3, :cond_4

    const/4 v5, 0x0

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v2, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eq p0, v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_2

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ltz v0, :cond_3

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {p4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_1

    :cond_2
    const/4 v5, 0x1

    new-instance v2, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    sget-object v3, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v5, 0x4

    invoke-direct {v2, p1, p2, v0, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {p4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    throw p0

    :cond_4
    :goto_2
    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    return p2

    :cond_5
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    throw p0
.end method

.method static decodeStringListRequireUtf8(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ltz v0, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {p4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    add-int v2, p2, v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1, p2, v2}, Lcom/google/protobuf/Utf8;->isValidUtf8([BII)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v3, :cond_6

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget-object v4, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v3, p1, p2, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {p4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    move p2, v2

    move p2, v2

    const/4 v6, 0x2

    move p2, v2

    move p2, v2

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    if-ge p2, p3, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget v2, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eq p0, v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_2

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    if-ltz v0, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez v0, :cond_2

    const/4 v5, 0x7

    const/4 v5, 0x2

    invoke-interface {p4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int v2, p2, v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p1, p2, v2}, Lcom/google/protobuf/Utf8;->isValidUtf8([BII)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v3, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object v4, Lcom/google/protobuf/Internal;->UTF_8:Ljava/nio/charset/Charset;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v3, p1, p2, v0, v4}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {p4, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    goto :goto_0

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidUtf8()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    throw p0

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    throw p0

    :cond_5
    :goto_2
    const/4 v5, 0x3

    move v6, v5

    return p2

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidUtf8()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    throw p0

    :cond_7
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x4

    throw p0
.end method

.method static decodeStringRequireUtf8([BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0, p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-ltz v0, :cond_1

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lcom/google/protobuf/Utf8;->decodeUtf8([BII)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p0, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    add-int/2addr p1, v0

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    throw p0
.end method

.method static decodeUnknownField(I[BIILcom/google/protobuf/UnknownFieldSetLite;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "unknownFields",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    invoke-static {p0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    if-eqz v0, :cond_b

    invoke-static {p0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    if-eqz v0, :cond_a

    const/4 v1, 0x1

    if-eq v0, v1, :cond_9

    const/4 v1, 0x2

    if-eq v0, v1, :cond_5

    const/4 v1, 0x3

    if-eq v0, v1, :cond_1

    const/4 p3, 0x5

    if-ne v0, p3, :cond_0

    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed32([BI)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p4, p0, p1}, Lcom/google/protobuf/UnknownFieldSetLite;->storeField(ILjava/lang/Object;)V

    add-int/lit8 p2, p2, 0x4

    return p2

    :cond_0
    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_1
    invoke-static {}, Lcom/google/protobuf/UnknownFieldSetLite;->newInstance()Lcom/google/protobuf/UnknownFieldSetLite;

    move-result-object v6

    and-int/lit8 v0, p0, -0x8

    or-int/lit8 v7, v0, 0x4

    const/4 v0, 0x0

    :goto_0
    if-ge p2, p3, :cond_3

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v2

    iget p2, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    if-ne p2, v7, :cond_2

    move v0, p2

    move v0, p2

    move v0, p2

    move v0, p2

    move p2, v2

    move p2, v2

    move p2, v2

    move p2, v2

    goto :goto_1

    :cond_2
    move v0, p2

    move v0, p2

    move v0, p2

    move v0, p2

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move v3, p3

    move v3, p3

    move v3, p3

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    invoke-static/range {v0 .. v5}, Lcom/google/protobuf/ArrayDecoders;->decodeUnknownField(I[BIILcom/google/protobuf/UnknownFieldSetLite;Lcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    move v8, v0

    move v8, v0

    move v8, v0

    move v0, p2

    move v0, p2

    move v0, p2

    move p2, v8

    move p2, v8

    move p2, v8

    move p2, v8

    goto :goto_0

    :cond_3
    :goto_1
    if-gt p2, p3, :cond_4

    if-ne v0, v7, :cond_4

    invoke-virtual {p4, p0, v6}, Lcom/google/protobuf/UnknownFieldSetLite;->storeField(ILjava/lang/Object;)V

    return p2

    :cond_4
    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_5
    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    iget p3, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    if-ltz p3, :cond_8

    array-length p5, p1

    sub-int/2addr p5, p2

    if-gt p3, p5, :cond_7

    if-nez p3, :cond_6

    sget-object p1, Lcom/google/protobuf/ByteString;->EMPTY:Lcom/google/protobuf/ByteString;

    invoke-virtual {p4, p0, p1}, Lcom/google/protobuf/UnknownFieldSetLite;->storeField(ILjava/lang/Object;)V

    goto :goto_2

    :cond_6
    invoke-static {p1, p2, p3}, Lcom/google/protobuf/ByteString;->copyFrom([BII)Lcom/google/protobuf/ByteString;

    move-result-object p1

    invoke-virtual {p4, p0, p1}, Lcom/google/protobuf/UnknownFieldSetLite;->storeField(ILjava/lang/Object;)V

    :goto_2
    add-int/2addr p2, p3

    return p2

    :cond_7
    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_8
    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->negativeSize()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0

    :cond_9
    invoke-static {p1, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeFixed64([BI)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {p4, p0, p1}, Lcom/google/protobuf/UnknownFieldSetLite;->storeField(ILjava/lang/Object;)V

    add-int/lit8 p2, p2, 0x8

    return p2

    :cond_a
    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    iget-wide p2, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    invoke-virtual {p4, p0, p2}, Lcom/google/protobuf/UnknownFieldSetLite;->storeField(ILjava/lang/Object;)V

    return p1

    :cond_b
    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    throw p0
.end method

.method static decodeVarint32(I[BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "firstByte",
            "data",
            "position",
            "registers"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    and-int/lit8 p0, p0, 0x7f

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    add-int/lit8 v0, p2, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    aget-byte p2, p1, p2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-ltz p2, :cond_0

    const/4 v2, 0x6

    shl-int/lit8 p1, p2, 0x7

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    or-int/2addr p0, p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput p0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    and-int/lit8 p2, p2, 0x7f

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    shl-int/lit8 p2, p2, 0x7

    const/4 v2, 0x6

    const/4 v1, 0x5

    or-int/2addr p0, p2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    add-int/lit8 p2, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    aget-byte v0, p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-ltz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    shl-int/lit8 p1, v0, 0xe

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    or-int/2addr p0, p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput p0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p2

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x7f

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    shl-int/lit8 v0, v0, 0xe

    const/4 v2, 0x5

    or-int/2addr p0, v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    add-int/lit8 v0, p2, 0x1

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    aget-byte p2, p1, p2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-ltz p2, :cond_2

    const/4 v1, 0x1

    move v2, v1

    shl-int/lit8 p1, p2, 0x15

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    or-int/2addr p0, p1

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    and-int/lit8 p2, p2, 0x7f

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    shl-int/lit8 p2, p2, 0x15

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    or-int/2addr p0, p2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    add-int/lit8 p2, v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    aget-byte v0, p1, v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-ltz v0, :cond_3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    shl-int/lit8 p1, v0, 0x1c

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    or-int/2addr p0, p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput p0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p2

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x7f

    const/4 v1, 0x0

    move v2, v1

    shl-int/lit8 v0, v0, 0x1c

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    or-int/2addr p0, v0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    add-int/lit8 v0, p2, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    aget-byte p2, p1, p2

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-gez p2, :cond_4

    const/4 v2, 0x6

    move p2, v0

    const/4 v2, 0x5

    move p2, v0

    move p2, v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_4
    const/4 v2, 0x0

    const/4 v1, 0x2

    iput p0, p3, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method static decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "registers"
        }
    .end annotation

    const/4 v2, 0x1

    add-int/lit8 v0, p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    aget-byte p1, p0, p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-ltz p1, :cond_0

    const/4 v1, 0x2

    move v2, v1

    iput p1, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {p1, p0, v0, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32(I[BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p0
.end method

.method static decodeVarint32List(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast p4, Lcom/google/protobuf/IntArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x0

    invoke-virtual {p4, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ge p2, p3, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eq p0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p4, v0}, Lcom/google/protobuf/IntArrayList;->addInt(I)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v2, 0x7

    const/4 v3, 0x0

    return p2
.end method

.method static decodeVarint64(J[BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "firstByte",
            "data",
            "position",
            "registers"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-wide/16 v0, 0x7f

    const-wide/16 v0, 0x7f

    const/4 v8, 0x0

    const-wide/16 v0, 0x7f

    const-wide/16 v0, 0x7f

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    and-long/2addr p0, v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    add-int/lit8 v0, p3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x7

    aget-byte p3, p2, p3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    and-int/lit8 v1, p3, 0x7f

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    int-to-long v1, v1

    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v3, 0x7

    const/4 v8, 0x6

    const/4 v7, 0x4

    shl-long/2addr v1, v3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    or-long/2addr p0, v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v1, v3

    move v1, v3

    const/4 v8, 0x1

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-gez p3, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    add-int/lit8 p3, v0, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    aget-byte v0, p2, v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    add-int/2addr v1, v3

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    and-int/lit8 v2, v0, 0x7f

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    int-to-long v4, v2

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    shl-long/2addr v4, v1

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    or-long/2addr p0, v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    move v0, p3

    move v0, p3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    move p3, v6

    move p3, v6

    const/4 v8, 0x4

    move p3, v6

    move p3, v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    iput-wide p0, p4, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    return v0
.end method

.method static decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "position",
            "registers"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-int/lit8 v0, p1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    aget-byte p1, p0, p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    int-to-long v1, p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    cmp-long p1, v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ltz p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput-wide v1, p2, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    return v0

    :cond_0
    const/4 v6, 0x4

    invoke-static {v1, v2, p0, v0, p2}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64(J[BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    return p0
.end method

.method static decodeVarint64List(I[BIILcom/google/protobuf/Internal$ProtobufList;Lcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "list",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I[BII",
            "Lcom/google/protobuf/Internal$ProtobufList<",
            "*>;",
            "Lcom/google/protobuf/ArrayDecoders$Registers;",
            ")I"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast p4, Lcom/google/protobuf/LongArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-wide v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p4, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ge p2, p3, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, p2, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eq p0, v1, :cond_0

    const/4 v3, 0x4

    goto :goto_1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-wide v0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->long1:J

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p4, v0, v1}, Lcom/google/protobuf/LongArrayList;->addLong(J)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p2
.end method

.method static mergeGroupField(Ljava/lang/Object;Lcom/google/protobuf/Schema;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "msg",
            "schema",
            "data",
            "position",
            "limit",
            "endGroup",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x0

    check-cast v0, Lcom/google/protobuf/MessageSchema;

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v7, 0x4

    move v3, p3

    move v3, p3

    move v3, p3

    move v3, p3

    const/4 v7, 0x1

    move v4, p4

    move v4, p4

    move v4, p4

    move v4, p4

    const/4 v7, 0x7

    move v5, p5

    move v5, p5

    move v5, p5

    move v5, p5

    move-object v6, p6

    move-object v6, p6

    const/4 v7, 0x4

    invoke-virtual/range {v0 .. v6}, Lcom/google/protobuf/MessageSchema;->parseMessage(Ljava/lang/Object;[BIIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p1

    const/4 v7, 0x4

    iput-object p0, p6, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v7, 0x6

    return p1
.end method

.method static mergeMessageField(Ljava/lang/Object;Lcom/google/protobuf/Schema;[BIILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "msg",
            "schema",
            "data",
            "position",
            "limit",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    add-int/lit8 v0, p3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget-byte p3, p2, p3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-gez p3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p3, p2, v0, p5}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32(I[BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget p3, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v3, v0

    const/4 v7, 0x4

    move v3, v0

    move v3, v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ltz p3, :cond_1

    const/4 v7, 0x6

    sub-int/2addr p4, v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-gt p3, p4, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/2addr p3, v3

    move-object v0, p1

    move-object v0, p1

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    move v4, p3

    move v4, p3

    const/4 v7, 0x7

    move v4, p3

    move v4, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface/range {v0 .. v5}, Lcom/google/protobuf/Schema;->mergeFrom(Ljava/lang/Object;[BIILcom/google/protobuf/ArrayDecoders$Registers;)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    iput-object p0, p5, Lcom/google/protobuf/ArrayDecoders$Registers;->object1:Ljava/lang/Object;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    return p3

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->truncatedMessage()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x1

    throw p0
.end method

.method static skipField(I[BIILcom/google/protobuf/ArrayDecoders$Registers;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "tag",
            "data",
            "position",
            "limit",
            "registers"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/InvalidProtocolBufferException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/google/protobuf/WireFormat;->getTagFieldNumber(I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_8

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/google/protobuf/WireFormat;->getTagWireType(I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_7

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eq v0, v1, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eq v0, v1, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eq v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x5

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ne v0, p0, :cond_0

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 p2, p2, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p2

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw p0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    and-int/lit8 p0, p0, -0x8

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    or-int/lit8 p0, p0, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    if-ge p2, p3, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1, p2, p4}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v0, p4, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x7

    if-ne v0, p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, p1, p2, p3, p4}, Lcom/google/protobuf/ArrayDecoders;->skipField(I[BIILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-gt p2, p3, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v0, p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return p2

    :cond_4
    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->parseFailure()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    throw p0

    :cond_5
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, p2, p4}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint32([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget p1, p4, Lcom/google/protobuf/ArrayDecoders$Registers;->int1:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    add-int/2addr p0, p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p0

    :cond_6
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    add-int/lit8 p2, p2, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return p2

    :cond_7
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1, p2, p4}, Lcom/google/protobuf/ArrayDecoders;->decodeVarint64([BILcom/google/protobuf/ArrayDecoders$Registers;)I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return p0

    :cond_8
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/InvalidProtocolBufferException;->invalidTag()Lcom/google/protobuf/InvalidProtocolBufferException;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p0
.end method
