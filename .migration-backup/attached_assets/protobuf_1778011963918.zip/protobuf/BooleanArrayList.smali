.class final Lcom/google/protobuf/BooleanArrayList;
.super Lcom/google/protobuf/AbstractProtobufList;

# interfaces
.implements Lcom/google/protobuf/Internal$BooleanList;
.implements Ljava/util/RandomAccess;
.implements Lcom/google/protobuf/PrimitiveNonBoxingCollection;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/AbstractProtobufList<",
        "Ljava/lang/Boolean;",
        ">;",
        "Lcom/google/protobuf/Internal$BooleanList;",
        "Ljava/util/RandomAccess;",
        "Lcom/google/protobuf/PrimitiveNonBoxingCollection;"
    }
.end annotation


# static fields
.field private static final EMPTY_LIST:Lcom/google/protobuf/BooleanArrayList;


# instance fields
.field private array:[Z

.field private size:I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Lcom/google/protobuf/BooleanArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-array v2, v1, [Z

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0, v2, v1, v1}, Lcom/google/protobuf/BooleanArrayList;-><init>([ZIZ)V

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    sput-object v0, Lcom/google/protobuf/BooleanArrayList;->EMPTY_LIST:Lcom/google/protobuf/BooleanArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-void
.end method

.method constructor <init>()V
    .locals 5

    const/4 v4, 0x4

    const/16 v0, 0xa

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-array v0, v0, [Z

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p0, v0, v1, v2}, Lcom/google/protobuf/BooleanArrayList;-><init>([ZIZ)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method private constructor <init>([ZIZ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "other",
            "size",
            "isMutable"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p3}, Lcom/google/protobuf/AbstractProtobufList;-><init>(Z)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method private addBoolean(IZ)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "t1s  @@ ~.@~/  ~o~d @o@@fS~@~~~ o@  @o@y@  M-@@m~~ b @~ @~ ~@ fa@bc~~~4obn~l@@~ ~l/iriu~~o~Ktis@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ltz p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    if-gt p1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    array-length v2, v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-ge v0, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/lit8 v2, p1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    sub-int/2addr v0, p1

    const/4 v4, 0x4

    move v5, v4

    invoke-static {v1, p1, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    mul-int/lit8 v0, v0, 0x3

    const/4 v5, 0x4

    div-int/lit8 v0, v0, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-array v0, v0, [Z

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    invoke-static {v1, v2, v0, v2, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v2, p1, 0x1

    const/4 v5, 0x4

    iget v3, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    sub-int/2addr v3, p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v1, p1, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    :goto_0
    const/4 v4, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    aput-boolean p2, v0, p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget p1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x1

    iput p1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance p2, Ljava/lang/IndexOutOfBoundsException;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->makeOutOfBoundsExceptionMessage(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {p2, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    throw p2
.end method

.method public static emptyList()Lcom/google/protobuf/BooleanArrayList;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/google/protobuf/BooleanArrayList;->EMPTY_LIST:Lcom/google/protobuf/BooleanArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method private ensureIndexInRange(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-ltz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ge p1, v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->makeOutOfBoundsExceptionMessage(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    throw v0
.end method

.method private makeOutOfBoundsExceptionMessage(I)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "x:emns"

    const-string v1, "e:sxnI"

    const/4 v3, 0x3

    const-string v1, "enxIod"

    const-string v1, "Index:"

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string p1, ":imz,bS"

    const-string p1, "e,:miSz"

    const/4 v3, 0x4

    const-string p1, " ,eiSzu"

    const-string p1, ", Size:"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget p1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p1
.end method


# virtual methods
.method public add(ILjava/lang/Boolean;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(IZ)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method public bridge synthetic add(ILjava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v1, 0x6

    check-cast p2, Ljava/lang/Boolean;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BooleanArrayList;->add(ILjava/lang/Boolean;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public add(Ljava/lang/Boolean;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->addBoolean(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p1
.end method

.method public bridge synthetic add(Ljava/lang/Object;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    check-cast p1, Ljava/lang/Boolean;

    const/4 v0, 0x0

    or-int/2addr v1, v0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->add(Ljava/lang/Boolean;)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p1
.end method

.method public addAll(Ljava/util/Collection;)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "collection"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection<",
            "+",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    instance-of v0, p1, Lcom/google/protobuf/BooleanArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractProtobufList;->addAll(Ljava/util/Collection;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    return p1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    check-cast p1, Lcom/google/protobuf/BooleanArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v0, p1, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    return v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget v2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    const v3, 0x7fffffff

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    sub-int/2addr v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-lt v3, v0, :cond_3

    const/4 v6, 0x0

    add-int/2addr v2, v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    array-length v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-le v2, v3, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([ZI)[Z

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v0, p1, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v4, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget p1, p1, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v0, v1, v3, v4, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput v2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x7

    move v6, v5

    const/4 v0, 0x1

    and-int/2addr v6, v0

    add-int/2addr p1, v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    return v0

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-instance p1, Ljava/lang/OutOfMemoryError;

    invoke-direct {p1}, Ljava/lang/OutOfMemoryError;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    throw p1
.end method

.method public addBoolean(Z)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    array-length v2, v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne v0, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    mul-int/lit8 v2, v0, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    div-int/lit8 v2, v2, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-array v2, v2, [Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    move v5, v4

    invoke-static {v1, v3, v2, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput v2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    aput-boolean p1, v0, v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void
.end method

.method public contains(Ljava/lang/Object;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->indexOf(Ljava/lang/Object;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return p1
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "o"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-ne p0, p1, :cond_0

    const/4 v6, 0x4

    return v0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    instance-of v1, p1, Lcom/google/protobuf/BooleanArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x6

    if-nez v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-super {p0, p1}, Lcom/google/protobuf/AbstractProtobufList;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x1

    return p1

    :cond_1
    const/4 v6, 0x3

    check-cast p1, Lcom/google/protobuf/BooleanArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    iget v2, p1, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eq v1, v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    return v3

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object p1, p1, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    move v1, v3

    move v1, v3

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    iget v2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v6, 0x1

    if-ge v1, v2, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x2

    move v6, v5

    aget-boolean v2, v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    aget-boolean v4, p1, v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    if-eq v2, v4, :cond_3

    return v3

    :cond_3
    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_4
    const/4 v6, 0x7

    return v0
.end method

.method public get(I)Ljava/lang/Boolean;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->getBoolean(I)Z

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method public bridge synthetic get(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->get(I)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public getBoolean(I)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->ensureIndexInRange(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    aget-boolean p1, v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method public hashCode()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-ge v1, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    mul-int/lit8 v0, v0, 0x1f

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    aget-boolean v2, v2, v1

    const/4 v4, 0x3

    invoke-static {v2}, Lcom/google/protobuf/Internal;->hashBoolean(Z)I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    add-int/2addr v0, v2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    return v0
.end method

.method public indexOf(Ljava/lang/Object;)I
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "element"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    instance-of v0, p1, Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    check-cast p1, Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/BooleanArrayList;->size()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ge v2, v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x1

    const/4 v4, 0x2

    aget-boolean v3, v3, v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-ne v3, p1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v1
.end method

.method public mutableCopyWithCapacity(I)Lcom/google/protobuf/Internal$BooleanList;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-lt p1, v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Lcom/google/protobuf/BooleanArrayList;

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    iget-object v1, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v1, p1}, Ljava/util/Arrays;->copyOf([ZI)[Z

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, p1, v1, v2}, Lcom/google/protobuf/BooleanArrayList;-><init>([ZIZ)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    throw p1
.end method

.method public bridge synthetic mutableCopyWithCapacity(I)Lcom/google/protobuf/Internal$ProtobufList;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "capacity"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->mutableCopyWithCapacity(I)Lcom/google/protobuf/Internal$BooleanList;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p1
.end method

.method public remove(I)Ljava/lang/Boolean;
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->ensureIndexInRange(I)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    aget-boolean v1, v0, p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v2, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/lit8 v3, v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ge p1, v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-int/lit8 v3, p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    sub-int/2addr v2, p1

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    add-int/lit8 v2, v2, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0, v3, v0, p1, v2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget p1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput p1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/lit8 p1, p1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object p1
.end method

.method public bridge synthetic remove(I)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->remove(I)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method protected removeRange(II)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fromIndex",
            "toIndex"
        }
    .end annotation

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-lt p2, p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    sub-int/2addr v1, p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, p2, v0, p1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    sub-int/2addr p2, p1

    const/4 v3, 0x0

    sub-int/2addr v0, p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v2, 0x7

    and-int/2addr v3, v2

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string p2, "entd xmpfIo rnodIx<"

    const-string p2, "dIxIooxnnrte<fe  dm"

    const/4 v3, 0x2

    const-string/jumbo p2, "x neIt oqdoedxr<Inf"

    const-string/jumbo p2, "toIndex < fromIndex"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p1
.end method

.method public set(ILjava/lang/Boolean;)Ljava/lang/Boolean;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BooleanArrayList;->setBoolean(IZ)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic set(ILjava/lang/Object;)Ljava/lang/Object;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    check-cast p2, Ljava/lang/Boolean;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/google/protobuf/BooleanArrayList;->set(ILjava/lang/Boolean;)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method public setBoolean(IZ)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "index",
            "element"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/google/protobuf/AbstractProtobufList;->ensureIsMutable()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/BooleanArrayList;->ensureIndexInRange(I)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/BooleanArrayList;->array:[Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    aget-boolean v1, v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    aput-boolean p2, v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v1
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/google/protobuf/BooleanArrayList;->size:I

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method
