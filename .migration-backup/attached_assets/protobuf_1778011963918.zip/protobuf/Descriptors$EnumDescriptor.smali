.class public final Lcom/google/protobuf/Descriptors$EnumDescriptor;
.super Lcom/google/protobuf/Descriptors$GenericDescriptor;

# interfaces
.implements Lcom/google/protobuf/Internal$EnumLiteMap;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/Descriptors;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "EnumDescriptor"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/Descriptors$EnumDescriptor$UnknownEnumValueReference;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/protobuf/Descriptors$GenericDescriptor;",
        "Lcom/google/protobuf/Internal$EnumLiteMap<",
        "Lcom/google/protobuf/Descriptors$EnumValueDescriptor;",
        ">;"
    }
.end annotation


# instance fields
.field private cleanupQueue:Ljava/lang/ref/ReferenceQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ref/ReferenceQueue<",
            "Lcom/google/protobuf/Descriptors$EnumValueDescriptor;",
            ">;"
        }
    .end annotation
.end field

.field private final containingType:Lcom/google/protobuf/Descriptors$Descriptor;

.field private final distinctNumbers:I

.field private final file:Lcom/google/protobuf/Descriptors$FileDescriptor;

.field private final fullName:Ljava/lang/String;

.field private final index:I

.field private proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

.field private unknownValues:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Integer;",
            "Ljava/lang/ref/WeakReference<",
            "Lcom/google/protobuf/Descriptors$EnumValueDescriptor;",
            ">;>;"
        }
    .end annotation
.end field

.field private final values:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

.field private final valuesSortedByNumber:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;


# direct methods
.method private constructor <init>(Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;I)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "proto",
            "file",
            "parent",
            "index"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v10, 0x3

    const/4 v0, 0x7

    const/4 v10, 0x6

    const/4 v0, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-direct {p0, v0}, Lcom/google/protobuf/Descriptors$GenericDescriptor;-><init>(Lcom/google/protobuf/Descriptors$1;)V

    const/4 v9, 0x7

    and-int/2addr v10, v9

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->unknownValues:Ljava/util/Map;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->cleanupQueue:Ljava/lang/ref/ReferenceQueue;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    iput p4, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->index:I

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getName()Ljava/lang/String;

    move-result-object p4

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p2, p3, p4}, Lcom/google/protobuf/Descriptors;->access$2300(Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->fullName:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    iput-object p2, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v10, 0x1

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValueCount()I

    move-result p3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz p3, :cond_3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValueCount()I

    move-result p3

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-array p3, p3, [Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    iput-object p3, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->values:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    const/4 p3, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    move p4, p3

    move p4, p3

    const/4 v10, 0x5

    move p4, p3

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValueCount()I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-ge p4, v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object v7, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->values:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x7

    new-instance v8, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {p1, p4}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValue(I)Lcom/google/protobuf/DescriptorProtos$EnumValueDescriptorProto;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v6, 0x0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    move v5, p4

    move v5, p4

    const/4 v10, 0x6

    move v5, p4

    move v5, p4

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct/range {v1 .. v6}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$EnumValueDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$EnumDescriptor;ILcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    aput-object v8, v7, p4

    const/4 v10, 0x5

    add-int/lit8 p4, p4, 0x1

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    goto :goto_0

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->values:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x7

    invoke-virtual {p4}, [Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->clone()Ljava/lang/Object;

    move-result-object p4

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    check-cast p4, [Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    iput-object p4, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->valuesSortedByNumber:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    sget-object v1, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->BY_NUMBER:Ljava/util/Comparator;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {p4, v1}, Ljava/util/Arrays;->sort([Ljava/lang/Object;Ljava/util/Comparator;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 p4, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x0

    move v1, p4

    move v1, p4

    const/4 v10, 0x4

    move v1, p4

    move v1, p4

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValueCount()I

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x0

    if-ge v1, v2, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->valuesSortedByNumber:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    aget-object v3, v2, p3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    aget-object v2, v2, v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v3}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getNumber()I

    move-result v3

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v2}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->getNumber()I

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eq v3, v4, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object v3, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->valuesSortedByNumber:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    add-int/lit8 p3, p3, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x7

    aput-object v2, v3, p3

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x5

    goto :goto_1

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    add-int/2addr p3, p4

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    iput p3, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->distinctNumbers:I

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object p4, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->valuesSortedByNumber:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValueCount()I

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {p4, p3, p1, v0}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {p2}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {p1, p0}, Lcom/google/protobuf/Descriptors$DescriptorPool;->addSymbol(Lcom/google/protobuf/Descriptors$GenericDescriptor;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x3

    return-void

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance p1, Lcom/google/protobuf/Descriptors$DescriptorValidationException;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string/jumbo p2, "sEsutmiau snnatuoc a s.tvlto mnen esle"

    const-string/jumbo p2, "o scilsattem nuuleat mnEusvaso .n et n"

    const/4 v10, 0x7

    const-string p2, "eElm nassntn a  use vua oln.ttcamumeot"

    const-string p2, "Enums must contain at least one value."

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-direct {p1, p0, p2, v0}, Lcom/google/protobuf/Descriptors$DescriptorValidationException;-><init>(Lcom/google/protobuf/Descriptors$GenericDescriptor;Ljava/lang/String;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    throw p1
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;ILcom/google/protobuf/Descriptors$1;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/google/protobuf/Descriptors$DescriptorValidationException;
        }
    .end annotation

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/google/protobuf/Descriptors$EnumDescriptor;-><init>(Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;Lcom/google/protobuf/Descriptors$FileDescriptor;Lcom/google/protobuf/Descriptors$Descriptor;I)V

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$1600(Lcom/google/protobuf/Descriptors$EnumDescriptor;Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o ~oor/@~~  u~~K~t~~1o~~ @@-@.~o@ ~@fi~~ @n @@b@o ~~/ob~l ~yi@c~ as@l@  @Mbfi@@ ~vm@S@d4 @ ~ @~t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->setProto(Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$3800(Lcom/google/protobuf/Descriptors$EnumDescriptor;)Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method private setProto(Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "proto"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object p1, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    move v4, v0

    :goto_0
    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->values:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    array-length v2, v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ge v0, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    aget-object v1, v1, v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getValue(I)Lcom/google/protobuf/DescriptorProtos$EnumValueDescriptorProto;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {v1, v2}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->access$3700(Lcom/google/protobuf/Descriptors$EnumValueDescriptor;Lcom/google/protobuf/DescriptorProtos$EnumValueDescriptorProto;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    move v4, v3

    return-void
.end method


# virtual methods
.method public findValueByName(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->access$1900(Lcom/google/protobuf/Descriptors$FileDescriptor;)Lcom/google/protobuf/Descriptors$DescriptorPool;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->fullName:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/16 v2, 0x2e

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Lcom/google/protobuf/Descriptors$DescriptorPool;->findSymbol(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$GenericDescriptor;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    instance-of v0, p1, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    check-cast p1, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    return-object p1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 p1, 0x0

    return-object p1
.end method

.method public findValueByNumber(I)Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->valuesSortedByNumber:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget v1, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->distinctNumbers:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget-object v2, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;->NUMBER_GETTER:Lcom/google/protobuf/Descriptors$NumberGetter;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v0, v1, v2, p1}, Lcom/google/protobuf/Descriptors;->access$2100([Ljava/lang/Object;ILcom/google/protobuf/Descriptors$NumberGetter;I)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    check-cast p1, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object p1
.end method

.method public bridge synthetic findValueByNumber(I)Lcom/google/protobuf/Internal$EnumLite;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->findValueByNumber(I)Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method public findValueByNumberCreatingIfUnknown(I)Lcom/google/protobuf/Descriptors$EnumValueDescriptor;
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->findValueByNumber(I)Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    return-object v0

    :cond_0
    const/4 v5, 0x2

    move v6, v5

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->cleanupQueue:Ljava/lang/ref/ReferenceQueue;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v0, :cond_1

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/ref/ReferenceQueue;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/ref/ReferenceQueue;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->cleanupQueue:Ljava/lang/ref/ReferenceQueue;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->unknownValues:Ljava/util/Map;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->cleanupQueue:Ljava/lang/ref/ReferenceQueue;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/ref/ReferenceQueue;->poll()Ljava/lang/ref/Reference;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumDescriptor$UnknownEnumValueReference;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v0, :cond_4

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->unknownValues:Ljava/util/Map;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    check-cast v0, Ljava/lang/ref/WeakReference;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-nez v0, :cond_2

    move-object v0, v1

    move-object v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    goto :goto_2

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    check-cast v0, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    :goto_2
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v0, :cond_3

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance v0, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v0, p0, v2, v1}, Lcom/google/protobuf/Descriptors$EnumValueDescriptor;-><init>(Lcom/google/protobuf/Descriptors$EnumDescriptor;Ljava/lang/Integer;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->unknownValues:Ljava/util/Map;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v4, Lcom/google/protobuf/Descriptors$EnumDescriptor$UnknownEnumValueReference;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v4, p1, v0, v1}, Lcom/google/protobuf/Descriptors$EnumDescriptor$UnknownEnumValueReference;-><init>(ILcom/google/protobuf/Descriptors$EnumValueDescriptor;Lcom/google/protobuf/Descriptors$1;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v2, v3, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-exit p0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-object v0

    :cond_4
    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->unknownValues:Ljava/util/Map;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/google/protobuf/Descriptors$EnumDescriptor$UnknownEnumValueReference;->access$3300(Lcom/google/protobuf/Descriptors$EnumDescriptor$UnknownEnumValueReference;)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    throw p1
.end method

.method public getContainingType()Lcom/google/protobuf/Descriptors$Descriptor;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->containingType:Lcom/google/protobuf/Descriptors$Descriptor;

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->file:Lcom/google/protobuf/Descriptors$FileDescriptor;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getFullName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->fullName:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public getIndex()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->index:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public getName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getOptions()Lcom/google/protobuf/DescriptorProtos$EnumOptions;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getOptions()Lcom/google/protobuf/DescriptorProtos$EnumOptions;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method getUnknownEnumValueDescriptorCount()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->unknownValues:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    return v0
.end method

.method public getValues()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/protobuf/Descriptors$EnumValueDescriptor;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->values:[Lcom/google/protobuf/Descriptors$EnumValueDescriptor;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public isClosed()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->getFile()Lcom/google/protobuf/Descriptors$FileDescriptor;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FileDescriptor;->getSyntax()Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v1, Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;->PROTO3:Lcom/google/protobuf/Descriptors$FileDescriptor$Syntax;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method public isReservedName(Ljava/lang/String;)Z
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getReservedNameList()Lcom/google/protobuf/ProtocolStringList;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x5

    shr-int/2addr v2, p1

    const/4 v3, 0x7

    return p1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    return p1
.end method

.method public isReservedNumber(I)Z
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "number"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;->getReservedRangeList()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    move v4, v3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v1, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto$EnumReservedRange;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto$EnumReservedRange;->getStart()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-gt v2, p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto$EnumReservedRange;->getEnd()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-gt p1, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    return p1
.end method

.method public toProto()Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/google/protobuf/Descriptors$EnumDescriptor;->proto:Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public bridge synthetic toProto()Lcom/google/protobuf/Message;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/google/protobuf/Descriptors$EnumDescriptor;->toProto()Lcom/google/protobuf/DescriptorProtos$EnumDescriptorProto;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method
