.class final Lcom/google/protobuf/ManifestSchemaFactory;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/protobuf/SchemaFactory;


# annotations
.annotation runtime Lcom/google/protobuf/CheckReturnValue;
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/google/protobuf/ManifestSchemaFactory$CompositeMessageInfoFactory;
    }
.end annotation


# static fields
.field private static final EMPTY_FACTORY:Lcom/google/protobuf/MessageInfoFactory;


# instance fields
.field private final messageInfoFactory:Lcom/google/protobuf/MessageInfoFactory;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    new-instance v0, Lcom/google/protobuf/ManifestSchemaFactory$1;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/google/protobuf/ManifestSchemaFactory$1;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Lcom/google/protobuf/ManifestSchemaFactory;->EMPTY_FACTORY:Lcom/google/protobuf/MessageInfoFactory;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/google/protobuf/ManifestSchemaFactory;->getDefaultMessageInfoFactory()Lcom/google/protobuf/MessageInfoFactory;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lcom/google/protobuf/ManifestSchemaFactory;-><init>(Lcom/google/protobuf/MessageInfoFactory;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>(Lcom/google/protobuf/MessageInfoFactory;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "messageInfoFactory"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string/jumbo v0, "nsssIFgosocytefeaa"

    const-string/jumbo v0, "yaseIoscoFgmfnetsa"

    const/4 v2, 0x7

    const-string/jumbo v0, "sfymtanesmoaeIFroc"

    const-string/jumbo v0, "messageInfoFactory"

    const/4 v1, 0x0

    and-int/2addr v2, v1

    invoke-static {p1, v0}, Lcom/google/protobuf/Internal;->checkNotNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p1, Lcom/google/protobuf/MessageInfoFactory;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/google/protobuf/ManifestSchemaFactory;->messageInfoFactory:Lcom/google/protobuf/MessageInfoFactory;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method private static allowExtensions(Lcom/google/protobuf/MessageInfo;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "messageInfo"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "oi@yoi~~c~    ~ @~fK@@ @  o ~vm ~i~o@@@~@o~~@tb-lf. @/S @~~~@bo n~@@@@ aslo~d/~tu~1r@b~~ @M@~4  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/google/protobuf/ManifestSchemaFactory$2;->$SwitchMap$com$google$protobuf$ProtoSyntax:[I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p0}, Lcom/google/protobuf/MessageInfo;->getSyntax()Lcom/google/protobuf/ProtoSyntax;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    aget p0, v0, p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eq p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0
.end method

.method private static getDefaultMessageInfoFactory()Lcom/google/protobuf/MessageInfoFactory;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v0, Lcom/google/protobuf/ManifestSchemaFactory$CompositeMessageInfoFactory;

    const/4 v5, 0x0

    const/4 v1, 0x2

    const/4 v5, 0x0

    move v4, v1

    move v4, v1

    const/4 v5, 0x3

    new-array v1, v1, [Lcom/google/protobuf/MessageInfoFactory;

    const/4 v5, 0x1

    const/4 v2, 0x7

    const/4 v2, 0x0

    move v5, v2

    const/4 v4, 0x6

    move v5, v4

    invoke-static {}, Lcom/google/protobuf/GeneratedMessageInfoFactory;->getInstance()Lcom/google/protobuf/GeneratedMessageInfoFactory;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput-object v3, v1, v2

    const/4 v5, 0x4

    const/4 v2, 0x3

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/google/protobuf/ManifestSchemaFactory;->getDescriptorMessageInfoFactory()Lcom/google/protobuf/MessageInfoFactory;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    aput-object v3, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v0, v1}, Lcom/google/protobuf/ManifestSchemaFactory$CompositeMessageInfoFactory;-><init>([Lcom/google/protobuf/MessageInfoFactory;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-object v0
.end method

.method private static getDescriptorMessageInfoFactory()Lcom/google/protobuf/MessageInfoFactory;
    .locals 6

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v0, "ugroobMayem.olo.gagorf.sFormccspInetDoiesfropceb"

    const-string v0, ".icmooee.DraoafoonFecbItopgmyrourgsMocgeslf.ptrs"

    const/4 v5, 0x2

    const-string/jumbo v0, "rryrmgufcgaosntcDoeiep.rFsgeboao.fseI.otopMuolct"

    const-string v0, "com.google.protobuf.DescriptorMessageInfoFactory"

    const/4 v5, 0x7

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v1, "ceantgIpneo"

    const-string v1, "gtenoInteca"

    const/4 v5, 0x1

    const-string v1, "eanegsIcqtn"

    const-string v1, "getInstance"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    new-array v1, v2, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    check-cast v0, Lcom/google/protobuf/MessageInfoFactory;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    return-object v0

    :catch_0
    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object v0, Lcom/google/protobuf/ManifestSchemaFactory;->EMPTY_FACTORY:Lcom/google/protobuf/MessageInfoFactory;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object v0
.end method

.method private static newSchema(Ljava/lang/Class;Lcom/google/protobuf/MessageInfo;)Lcom/google/protobuf/Schema;
    .locals 10
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "messageType",
            "messageInfo"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;",
            "Lcom/google/protobuf/MessageInfo;",
            ")",
            "Lcom/google/protobuf/Schema<",
            "TT;>;"
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-class v0, Lcom/google/protobuf/GeneratedMessageLite;

    const-class v0, Lcom/google/protobuf/GeneratedMessageLite;

    const/4 v9, 0x6

    const-class v0, Lcom/google/protobuf/GeneratedMessageLite;

    const-class v0, Lcom/google/protobuf/GeneratedMessageLite;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-eqz v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p1}, Lcom/google/protobuf/ManifestSchemaFactory;->allowExtensions(Lcom/google/protobuf/MessageInfo;)Z

    move-result v0

    const/4 v8, 0x3

    shl-int/2addr v9, v8

    if-eqz v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {}, Lcom/google/protobuf/NewInstanceSchemas;->lite()Lcom/google/protobuf/NewInstanceSchema;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {}, Lcom/google/protobuf/ListFieldSchema;->lite()Lcom/google/protobuf/ListFieldSchema;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {}, Lcom/google/protobuf/SchemaUtil;->unknownFieldSetLiteSchema()Lcom/google/protobuf/UnknownFieldSchema;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {}, Lcom/google/protobuf/ExtensionSchemas;->lite()Lcom/google/protobuf/ExtensionSchema;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {}, Lcom/google/protobuf/MapFieldSchemas;->lite()Lcom/google/protobuf/MapFieldSchema;

    move-result-object v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/MessageSchema;->newSchema(Ljava/lang/Class;Lcom/google/protobuf/MessageInfo;Lcom/google/protobuf/NewInstanceSchema;Lcom/google/protobuf/ListFieldSchema;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ExtensionSchema;Lcom/google/protobuf/MapFieldSchema;)Lcom/google/protobuf/MessageSchema;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {}, Lcom/google/protobuf/NewInstanceSchemas;->lite()Lcom/google/protobuf/NewInstanceSchema;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {}, Lcom/google/protobuf/ListFieldSchema;->lite()Lcom/google/protobuf/ListFieldSchema;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {}, Lcom/google/protobuf/SchemaUtil;->unknownFieldSetLiteSchema()Lcom/google/protobuf/UnknownFieldSchema;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v5, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {}, Lcom/google/protobuf/MapFieldSchemas;->lite()Lcom/google/protobuf/MapFieldSchema;

    move-result-object v6

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v0 .. v6}, Lcom/google/protobuf/MessageSchema;->newSchema(Ljava/lang/Class;Lcom/google/protobuf/MessageInfo;Lcom/google/protobuf/NewInstanceSchema;Lcom/google/protobuf/ListFieldSchema;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ExtensionSchema;Lcom/google/protobuf/MapFieldSchema;)Lcom/google/protobuf/MessageSchema;

    move-result-object p0

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    return-object p0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/google/protobuf/ManifestSchemaFactory;->allowExtensions(Lcom/google/protobuf/MessageInfo;)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {}, Lcom/google/protobuf/NewInstanceSchemas;->full()Lcom/google/protobuf/NewInstanceSchema;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Lcom/google/protobuf/ListFieldSchema;->full()Lcom/google/protobuf/ListFieldSchema;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {}, Lcom/google/protobuf/SchemaUtil;->unknownFieldSetFullSchema()Lcom/google/protobuf/UnknownFieldSchema;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {}, Lcom/google/protobuf/ExtensionSchemas;->full()Lcom/google/protobuf/ExtensionSchema;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {}, Lcom/google/protobuf/MapFieldSchemas;->full()Lcom/google/protobuf/MapFieldSchema;

    move-result-object v7

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static/range {v1 .. v7}, Lcom/google/protobuf/MessageSchema;->newSchema(Ljava/lang/Class;Lcom/google/protobuf/MessageInfo;Lcom/google/protobuf/NewInstanceSchema;Lcom/google/protobuf/ListFieldSchema;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ExtensionSchema;Lcom/google/protobuf/MapFieldSchema;)Lcom/google/protobuf/MessageSchema;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_1

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {}, Lcom/google/protobuf/NewInstanceSchemas;->full()Lcom/google/protobuf/NewInstanceSchema;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {}, Lcom/google/protobuf/ListFieldSchema;->full()Lcom/google/protobuf/ListFieldSchema;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {}, Lcom/google/protobuf/SchemaUtil;->unknownFieldSetFullSchema()Lcom/google/protobuf/UnknownFieldSchema;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/4 v5, 0x0

    const/4 v9, 0x6

    invoke-static {}, Lcom/google/protobuf/MapFieldSchemas;->full()Lcom/google/protobuf/MapFieldSchema;

    move-result-object v6

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static/range {v0 .. v6}, Lcom/google/protobuf/MessageSchema;->newSchema(Ljava/lang/Class;Lcom/google/protobuf/MessageInfo;Lcom/google/protobuf/NewInstanceSchema;Lcom/google/protobuf/ListFieldSchema;Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ExtensionSchema;Lcom/google/protobuf/MapFieldSchema;)Lcom/google/protobuf/MessageSchema;

    move-result-object p0

    :goto_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    return-object p0
.end method


# virtual methods
.method public createSchema(Ljava/lang/Class;)Lcom/google/protobuf/Schema;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "messageType"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Lcom/google/protobuf/Schema<",
            "TT;>;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/google/protobuf/SchemaUtil;->requireGeneratedMessage(Ljava/lang/Class;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/google/protobuf/ManifestSchemaFactory;->messageInfoFactory:Lcom/google/protobuf/MessageInfoFactory;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lcom/google/protobuf/MessageInfoFactory;->messageInfoFor(Ljava/lang/Class;)Lcom/google/protobuf/MessageInfo;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {v0}, Lcom/google/protobuf/MessageInfo;->isMessageSetWireFormat()Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-class v1, Lcom/google/protobuf/GeneratedMessageLite;

    const-class v1, Lcom/google/protobuf/GeneratedMessageLite;

    const/4 v3, 0x1

    const-class v1, Lcom/google/protobuf/GeneratedMessageLite;

    const-class v1, Lcom/google/protobuf/GeneratedMessageLite;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {}, Lcom/google/protobuf/SchemaUtil;->unknownFieldSetLiteSchema()Lcom/google/protobuf/UnknownFieldSchema;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/ExtensionSchemas;->lite()Lcom/google/protobuf/ExtensionSchema;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v0}, Lcom/google/protobuf/MessageInfo;->getDefaultInstance()Lcom/google/protobuf/MessageLite;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/MessageSetSchema;->newSchema(Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ExtensionSchema;Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/MessageSetSchema;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {}, Lcom/google/protobuf/SchemaUtil;->unknownFieldSetFullSchema()Lcom/google/protobuf/UnknownFieldSchema;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {}, Lcom/google/protobuf/ExtensionSchemas;->full()Lcom/google/protobuf/ExtensionSchema;

    move-result-object v1

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-interface {v0}, Lcom/google/protobuf/MessageInfo;->getDefaultInstance()Lcom/google/protobuf/MessageLite;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, v1, v0}, Lcom/google/protobuf/MessageSetSchema;->newSchema(Lcom/google/protobuf/UnknownFieldSchema;Lcom/google/protobuf/ExtensionSchema;Lcom/google/protobuf/MessageLite;)Lcom/google/protobuf/MessageSetSchema;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/google/protobuf/ManifestSchemaFactory;->newSchema(Ljava/lang/Class;Lcom/google/protobuf/MessageInfo;)Lcom/google/protobuf/Schema;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-object p1
.end method
