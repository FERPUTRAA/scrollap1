.class public Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4
    name = "ExtensionWriter"
.end annotation


# instance fields
.field private final iter:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator<",
            "Ljava/util/Map$Entry<",
            "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
            "Ljava/lang/Object;",
            ">;>;"
        }
    .end annotation
.end field

.field private final messageSetWireFormat:Z

.field private next:Ljava/util/Map$Entry;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map$Entry<",
            "Lcom/google/protobuf/Descriptors$FieldDescriptor;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic this$0:Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;


# direct methods
.method private constructor <init>(Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x10
        }
        names = {
            "this$0",
            "messageSetWireFormat"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->this$0:Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;->access$600(Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;)Lcom/google/protobuf/FieldSet;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Lcom/google/protobuf/FieldSet;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;

    const/4 v2, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p1, Ljava/util/Map$Entry;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-boolean p2, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->messageSetWireFormat:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method synthetic constructor <init>(Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;ZLcom/google/protobuf/GeneratedMessage$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0, p1, p2}, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;-><init>(Lcom/google/protobuf/GeneratedMessage$ExtendableMessage;Z)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public writeUntil(ILcom/google/protobuf/CodedOutputStream;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "end",
            "output"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v0, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    if-ge v0, p1, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    check-cast v0, Lcom/google/protobuf/Descriptors$FieldDescriptor;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->messageSetWireFormat:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getLiteJavaType()Lcom/google/protobuf/WireFormat$JavaType;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v2, Lcom/google/protobuf/WireFormat$JavaType;->MESSAGE:Lcom/google/protobuf/WireFormat$JavaType;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-ne v1, v2, :cond_1

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->isRepeated()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x4

    and-int/2addr v4, v3

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    instance-of v1, v1, Lcom/google/protobuf/LazyField$LazyEntry;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x5

    check-cast v1, Lcom/google/protobuf/LazyField$LazyEntry;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/protobuf/LazyField$LazyEntry;->getField()Lcom/google/protobuf/LazyField;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1}, Lcom/google/protobuf/LazyFieldLite;->toByteString()Lcom/google/protobuf/ByteString;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeRawMessageSetExtension(ILcom/google/protobuf/ByteString;)V

    const/4 v4, 0x5

    goto :goto_1

    :cond_0
    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0}, Lcom/google/protobuf/Descriptors$FieldDescriptor;->getNumber()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x6

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    check-cast v1, Lcom/google/protobuf/Message;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p2, v0, v1}, Lcom/google/protobuf/CodedOutputStream;->writeMessageSetExtension(ILcom/google/protobuf/MessageLite;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_1

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0, v1, p2}, Lcom/google/protobuf/FieldSet;->writeField(Lcom/google/protobuf/FieldSet$FieldDescriptorLite;Ljava/lang/Object;Lcom/google/protobuf/CodedOutputStream;)V

    :goto_1
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->iter:Ljava/util/Iterator;

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v0, Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/google/protobuf/GeneratedMessage$ExtendableMessage$ExtensionWriter;->next:Ljava/util/Map$Entry;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method
