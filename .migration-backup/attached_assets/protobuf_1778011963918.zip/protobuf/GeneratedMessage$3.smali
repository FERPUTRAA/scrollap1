.class Lcom/google/protobuf/GeneratedMessage$3;
.super Lcom/google/protobuf/GeneratedMessage$CachedDescriptorRetriever;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/protobuf/GeneratedMessage;->newMessageScopedGeneratedExtension(Lcom/google/protobuf/Message;Ljava/lang/String;Ljava/lang/Class;Lcom/google/protobuf/Message;)Lcom/google/protobuf/GeneratedMessage$GeneratedExtension;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$name:Ljava/lang/String;

.field final synthetic val$scope:Lcom/google/protobuf/Message;


# direct methods
.method constructor <init>(Lcom/google/protobuf/Message;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$scope",
            "val$name"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/google/protobuf/GeneratedMessage$3;->val$scope:Lcom/google/protobuf/Message;

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-object p2, p0, Lcom/google/protobuf/GeneratedMessage$3;->val$name:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/google/protobuf/GeneratedMessage$CachedDescriptorRetriever;-><init>(Lcom/google/protobuf/GeneratedMessage$1;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method protected loadDescriptor()Lcom/google/protobuf/Descriptors$FieldDescriptor;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s~o@i@l1Mo   vo@ u~f Kl@@~ofb~oi@dn ~~@t@y~ @-~@ . /@@ @t~~~b ~@~@Sa ~m4c~~@b  ~r~~ @~~@s i@/o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/google/protobuf/GeneratedMessage$3;->val$scope:Lcom/google/protobuf/Message;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0}, Lcom/google/protobuf/MessageOrBuilder;->getDescriptorForType()Lcom/google/protobuf/Descriptors$Descriptor;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/google/protobuf/GeneratedMessage$3;->val$name:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/google/protobuf/Descriptors$Descriptor;->findFieldByName(Ljava/lang/String;)Lcom/google/protobuf/Descriptors$FieldDescriptor;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method
