.class final enum Lcom/google/protobuf/MapField$StorageMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/protobuf/MapField;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x401a
    name = "StorageMode"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/google/protobuf/MapField$StorageMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/google/protobuf/MapField$StorageMode;

.field public static final enum BOTH:Lcom/google/protobuf/MapField$StorageMode;

.field public static final enum LIST:Lcom/google/protobuf/MapField$StorageMode;

.field public static final enum MAP:Lcom/google/protobuf/MapField$StorageMode;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x5

    new-instance v0, Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string v1, "AMP"

    const-string v1, "MAP"

    const/4 v8, 0x5

    const-string v1, "MPA"

    const-string v1, "MAP"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    invoke-direct {v0, v1, v2}, Lcom/google/protobuf/MapField$StorageMode;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    sput-object v0, Lcom/google/protobuf/MapField$StorageMode;->MAP:Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v1, Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v3, "TILS"

    const-string v3, "STLI"

    const/4 v8, 0x2

    const-string v3, "ITSL"

    const-string v3, "LIST"

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v1, v3, v4}, Lcom/google/protobuf/MapField$StorageMode;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    sput-object v1, Lcom/google/protobuf/MapField$StorageMode;->LIST:Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v3, Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const-string v5, "HTBO"

    const-string v5, "HBOT"

    const/4 v8, 0x3

    const-string v5, "TOHB"

    const-string v5, "BOTH"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v6, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v3, v5, v6}, Lcom/google/protobuf/MapField$StorageMode;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    sput-object v3, Lcom/google/protobuf/MapField$StorageMode;->BOTH:Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v5, 0x3

    const/4 v8, 0x5

    new-array v5, v5, [Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x4

    const/4 v7, 0x3

    aput-object v0, v5, v2

    const/4 v7, 0x1

    move v8, v7

    aput-object v1, v5, v4

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    aput-object v3, v5, v6

    const/4 v7, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    sput-object v5, Lcom/google/protobuf/MapField$StorageMode;->$VALUES:[Lcom/google/protobuf/MapField$StorageMode;

    const/4 v8, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000
        }
        names = {
            "$enum$name",
            "$enum$ordinal"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/google/protobuf/MapField$StorageMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "n s~o@~@i@~ o@~~@@o@mf bMl@/~ ~  ~ ~c1ti  u~@@~S@~l @@ fdy~. bt~~@o @@@~is-bo~@v4a /@@o~~r K ~ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-class v0, Lcom/google/protobuf/MapField$StorageMode;

    const-class v0, Lcom/google/protobuf/MapField$StorageMode;

    const/4 v2, 0x1

    const-class v0, Lcom/google/protobuf/MapField$StorageMode;

    const-class v0, Lcom/google/protobuf/MapField$StorageMode;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p0, Lcom/google/protobuf/MapField$StorageMode;

    const/4 v1, 0x7

    move v2, v1

    return-object p0
.end method

.method public static values()[Lcom/google/protobuf/MapField$StorageMode;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/google/protobuf/MapField$StorageMode;->$VALUES:[Lcom/google/protobuf/MapField$StorageMode;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/google/protobuf/MapField$StorageMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast v0, [Lcom/google/protobuf/MapField$StorageMode;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method
