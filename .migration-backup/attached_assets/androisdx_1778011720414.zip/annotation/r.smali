.class public interface abstract annotation Landroidx/annotation/r;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime La8/c;
.end annotation

.annotation runtime La8/e;
    value = .enum La8/a;->b:La8/a;
.end annotation

.annotation runtime La8/f;
    allowedTargets = {
        .enum La8/b;->i:La8/b;,
        .enum La8/b;->j:La8/b;,
        .enum La8/b;->k:La8/b;,
        .enum La8/b;->g:La8/b;,
        .enum La8/b;->e:La8/b;,
        .enum La8/b;->f:La8/b;,
        .enum La8/b;->b:La8/b;
    }
.end annotation

.annotation system Ldalvik/annotation/AnnotationDefault;
    value = .subannotation Landroidx/annotation/r;
        unit = 0x1
    .end subannotation
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/annotation/r$a;
    }
.end annotation

.annotation runtime Ljava/lang/annotation/Documented;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->CLASS:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {
        .enum Ljava/lang/annotation/ElementType;->FIELD:Ljava/lang/annotation/ElementType;,
        .enum Ljava/lang/annotation/ElementType;->METHOD:Ljava/lang/annotation/ElementType;,
        .enum Ljava/lang/annotation/ElementType;->PARAMETER:Ljava/lang/annotation/ElementType;,
        .enum Ljava/lang/annotation/ElementType;->LOCAL_VARIABLE:Ljava/lang/annotation/ElementType;,
        .enum Ljava/lang/annotation/ElementType;->ANNOTATION_TYPE:Ljava/lang/annotation/ElementType;
    }
.end annotation


# static fields
.field public static final a:Landroidx/annotation/r$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final b:I = 0x0

.field public static final c:I = 0x1

.field public static final d:I = 0x2


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Landroidx/annotation/r$a;->a:Landroidx/annotation/r$a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput-object v0, Landroidx/annotation/r;->a:Landroidx/annotation/r$a;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public abstract unit()I
.end method
