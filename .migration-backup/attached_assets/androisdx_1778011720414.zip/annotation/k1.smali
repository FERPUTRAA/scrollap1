.class public interface abstract annotation Landroidx/annotation/k1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime La8/e;
    value = .enum La8/a;->b:La8/a;
.end annotation

.annotation system Ldalvik/annotation/AnnotationDefault;
    value = .subannotation Landroidx/annotation/k1;
        otherwise = 0x2
    .end subannotation
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/annotation/k1$a;
    }
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->CLASS:Ljava/lang/annotation/RetentionPolicy;
.end annotation


# static fields
.field public static final e:Landroidx/annotation/k1$a;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final f:I = 0x2

.field public static final g:I = 0x3

.field public static final h:I = 0x4

.field public static final i:I = 0x5


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Landroidx/annotation/k1$a;->a:Landroidx/annotation/k1$a;

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Landroidx/annotation/k1;->e:Landroidx/annotation/k1$a;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public abstract otherwise()I
.end method
