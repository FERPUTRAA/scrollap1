.class public Landroidx/activity/l;
.super Landroid/app/Dialog;

# interfaces
.implements Landroidx/lifecycle/i0;
.implements Landroidx/activity/u;
.implements Landroidx/savedstate/d;


# instance fields
.field private a:Landroidx/lifecycle/k0;
    .annotation build Lia/e;
    .end annotation
.end field

.field private final b:Landroidx/savedstate/c;
    .annotation build Lia/d;
    .end annotation
.end field

.field private final c:Landroidx/activity/OnBackPressedDispatcher;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v0, "ctsntoe"

    const-string v0, "cestotn"

    const/4 v4, 0x5

    const-string/jumbo v0, "xnemotc"

    const-string v0, "context"

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p0, p1, v2, v0, v1}, Landroidx/activity/l;-><init>(Landroid/content/Context;IILkotlin/jvm/internal/w;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param
    .annotation build Lh8/i;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, "cnttoxo"

    const-string/jumbo v0, "xcnmtto"

    const-string/jumbo v0, "otnxebc"

    const-string v0, "context"

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object p1, Landroidx/savedstate/c;->d:Landroidx/savedstate/c$a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1, p0}, Landroidx/savedstate/c$a;->a(Landroidx/savedstate/d;)Landroidx/savedstate/c;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/activity/l;->b:Landroidx/savedstate/c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Landroidx/activity/OnBackPressedDispatcher;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p2, Landroidx/activity/k;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p2, p0}, Landroidx/activity/k;-><init>(Landroidx/activity/l;)V

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {p1, p2}, Landroidx/activity/OnBackPressedDispatcher;-><init>(Ljava/lang/Runnable;)V

    iput-object p1, p0, Landroidx/activity/l;->c:Landroidx/activity/OnBackPressedDispatcher;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public synthetic constructor <init>(Landroid/content/Context;IILkotlin/jvm/internal/w;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    and-int/lit8 p3, p3, 0x2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p2, 0x0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Landroidx/activity/l;-><init>(Landroid/content/Context;I)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static synthetic a(Landroidx/activity/l;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~@@4Mu@@@~~@ ~~ ~Sf~@~ ofc~m/t ~ u  @~d~~i@~l ~@~ ao~l.ob b ~  t @ ~ os@~ 1oi~n@o@/@yK@b@~i-v@r"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {p0}, Landroidx/activity/l;->e(Landroidx/activity/l;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method private final b()Landroidx/lifecycle/k0;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Landroidx/activity/l;->a:Landroidx/lifecycle/k0;

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Landroidx/lifecycle/k0;

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Landroidx/lifecycle/k0;-><init>(Landroidx/lifecycle/i0;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/activity/l;->a:Landroidx/lifecycle/k0;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public static synthetic c()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method private final d()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "iecie!wpnoVwwor!.o"

    const-string v1, "d!neowieoVo!wrciw."

    const/4 v3, 0x4

    const-string v1, "d!e!wr.cqiwewdooVi"

    const-string/jumbo v1, "window!!.decorView"

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-static {v0, p0}, Landroidx/lifecycle/w1;->b(Landroid/view/View;Landroidx/lifecycle/i0;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p0}, Landroidx/activity/z;->b(Landroid/view/View;Landroidx/activity/u;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, p0}, Landroidx/savedstate/f;->b(Landroid/view/View;Landroidx/savedstate/d;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method private static final e(Landroidx/activity/l;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "its0$h"

    const-string/jumbo v0, "th0i$b"

    const/4 v2, 0x5

    const-string v0, "0ihmts"

    const-string/jumbo v0, "this$0"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/app/Dialog;->onBackPressed()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "view"

    const-string/jumbo v0, "iwev"

    const/4 v2, 0x4

    const-string/jumbo v0, "view"

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Landroidx/activity/l;->d()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public getLifecycle()Landroidx/lifecycle/y;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    invoke-direct {p0}, Landroidx/activity/l;->b()Landroidx/lifecycle/k0;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public final getOnBackPressedDispatcher()Landroidx/activity/OnBackPressedDispatcher;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/activity/l;->c:Landroidx/activity/OnBackPressedDispatcher;

    const/4 v2, 0x5

    const/4 v1, 0x2

    return-object v0
.end method

.method public getSavedStateRegistry()Landroidx/savedstate/b;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/activity/l;->b:Landroidx/savedstate/c;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/savedstate/c;->b()Landroidx/savedstate/b;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public onBackPressed()V
    .locals 3
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/activity/l;->c:Landroidx/activity/OnBackPressedDispatcher;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/activity/OnBackPressedDispatcher;->f()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1    # Landroid/os/Bundle;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-super {p0, p1}, Landroid/app/Dialog;->onCreate(Landroid/os/Bundle;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/16 v1, 0x21

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-lt v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/activity/l;->c:Landroidx/activity/OnBackPressedDispatcher;

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-static {p0}, Landroidx/activity/j;->a(Landroidx/activity/l;)Landroid/window/OnBackInvokedDispatcher;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v2, "BsopoDkcvicatruedIeaknn"

    const-string/jumbo v2, "pvsociueonncrIktBadeaDk"

    const/4 v4, 0x2

    const-string/jumbo v2, "knIpebakvBrDnsidcecoath"

    const-string/jumbo v2, "onBackInvokedDispatcher"

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroidx/activity/OnBackPressedDispatcher;->g(Landroid/window/OnBackInvokedDispatcher;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/activity/l;->b:Landroidx/savedstate/c;

    const/4 v3, 0x4

    and-int/2addr v4, v3

    invoke-virtual {v0, p1}, Landroidx/savedstate/c;->d(Landroid/os/Bundle;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0}, Landroidx/activity/l;->b()Landroidx/lifecycle/k0;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v0, Landroidx/lifecycle/y$a;->ON_CREATE:Landroidx/lifecycle/y$a;

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroidx/lifecycle/k0;->l(Landroidx/lifecycle/y$a;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method public onSaveInstanceState()Landroid/os/Bundle;
    .locals 4
    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    invoke-super {p0}, Landroid/app/Dialog;->onSaveInstanceState()Landroid/os/Bundle;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "Saotusuvet)papneSa.nceerItn"

    const-string v1, "cn.eavnprpeI)astnSeaett(oSu"

    const/4 v3, 0x0

    const-string v1, "esn(v)aproSuSapeeatn.cItstn"

    const-string/jumbo v1, "super.onSaveInstanceState()"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/activity/l;->b:Landroidx/savedstate/c;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Landroidx/savedstate/c;->e(Landroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method protected onStart()V
    .locals 4
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/app/Dialog;->onStart()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Landroidx/activity/l;->b()Landroidx/lifecycle/k0;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v1, Landroidx/lifecycle/y$a;->ON_RESUME:Landroidx/lifecycle/y$a;

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Landroidx/lifecycle/k0;->l(Landroidx/lifecycle/y$a;)V

    const/4 v3, 0x1

    return-void
.end method

.method protected onStop()V
    .locals 4
    .annotation build Landroidx/annotation/i;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0}, Landroidx/activity/l;->b()Landroidx/lifecycle/k0;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v1, Landroidx/lifecycle/y$a;->ON_DESTROY:Landroidx/lifecycle/y$a;

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroidx/lifecycle/k0;->l(Landroidx/lifecycle/y$a;)V

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/activity/l;->a:Landroidx/lifecycle/k0;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-super {p0}, Landroid/app/Dialog;->onStop()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public setContentView(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Landroidx/activity/l;->d()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroid/app/Dialog;->setContentView(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x2

    const-string/jumbo v0, "vewi"

    const-string/jumbo v0, "ivew"

    const/4 v2, 0x4

    const-string v0, "eviw"

    const-string/jumbo v0, "view"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    invoke-direct {p0}, Landroidx/activity/l;->d()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/view/ViewGroup$LayoutParams;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo v0, "viwe"

    const-string v0, "ewvi"

    const/4 v2, 0x1

    const-string/jumbo v0, "view"

    const-string/jumbo v0, "view"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Landroidx/activity/l;->d()V

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0, p1, p2}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method
