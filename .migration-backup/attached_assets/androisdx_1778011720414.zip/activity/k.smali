.class public final synthetic Landroidx/activity/k;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Landroidx/activity/l;


# direct methods
.method public synthetic constructor <init>(Landroidx/activity/l;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/activity/k;->a:Landroidx/activity/l;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@snm@~o@d@  @~c~oKSv~ f~if@@/@b~ ~ ~b@b t  ~o@ ~-~./i yl~~o1o~ o@~~@t @ur  M~@i l~~ ~4@@a~@@s @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/activity/k;->a:Landroidx/activity/l;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/activity/l;->a(Landroidx/activity/l;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method
