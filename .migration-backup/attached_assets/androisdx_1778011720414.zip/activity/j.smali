.class public final synthetic Landroidx/activity/j;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroidx/activity/l;)Landroid/window/OnBackInvokedDispatcher;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@sbrl~~o~ ~ @@ic@voai M~yuo1f/. ~ -@dl @m4bs~~i~t /~ o~~~n@@  ~f@ @ ~ S@~~@t@@@ b @~~oo@ ~ ~@@K"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/app/Dialog;->getOnBackInvokedDispatcher()Landroid/window/OnBackInvokedDispatcher;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-object p0
.end method
