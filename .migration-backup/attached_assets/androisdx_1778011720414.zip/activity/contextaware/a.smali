.class public interface abstract Landroidx/activity/contextaware/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract addOnContextAvailableListener(Landroidx/activity/contextaware/d;)V
    .param p1    # Landroidx/activity/contextaware/d;
        .annotation build Lia/d;
        .end annotation
    .end param
.end method

.method public abstract peekAvailableContext()Landroid/content/Context;
    .annotation build Lia/e;
    .end annotation
.end method

.method public abstract removeOnContextAvailableListener(Landroidx/activity/contextaware/d;)V
    .param p1    # Landroidx/activity/contextaware/d;
        .annotation build Lia/d;
        .end annotation
    .end param
.end method
