.class public final synthetic Landroidx/activity/result/d;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/activity/result/a;


# instance fields
.field public final synthetic a:Li8/l;


# direct methods
.method public synthetic constructor <init>(Li8/l;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/activity/result/d;->a:Li8/l;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l s~~n~i  b@yduM @ ~@~@@b @@  msr~t~/S1@~c@@~oo~@@ @oi  ~@@l@~ovo~~@fK .~~ t@~ ba@ o~/ ~i4@~~f-~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/activity/result/d;->a:Li8/l;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p1}, Landroidx/activity/result/e;->b(Li8/l;Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
