.class public final Landroidx/activity/c;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x1a
.end annotation


# static fields
.field public static final a:Landroidx/activity/c;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance v0, Landroidx/activity/c;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {v0}, Landroidx/activity/c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object v0, Landroidx/activity/c;->a:Landroidx/activity/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public final a(Landroid/app/Activity;Landroid/graphics/Rect;)V
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/Rect;
        .annotation build Lia/d;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s@ ~ @~f@@~@a~~o ob~~@~b. @m-~@vS@b i@yr~ 4 @~lo ~@~@i to~ ~~o~c @ ~1 ~@u~i@f~tsl ~dn@@ K@//Mo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "asvmttyc"

    const-string/jumbo v0, "icsvytta"

    const/4 v2, 0x5

    const-string v0, "avicoitt"

    const-string v0, "activity"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const-string/jumbo v0, "itnh"

    const-string/jumbo v0, "nhti"

    const/4 v2, 0x7

    const-string/jumbo v0, "inth"

    const-string v0, "hint"

    const/4 v2, 0x6

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance v0, Landroid/app/PictureInPictureParams$Builder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Landroid/app/PictureInPictureParams$Builder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-virtual {v0, p2}, Landroid/app/PictureInPictureParams$Builder;->setSourceRectHint(Landroid/graphics/Rect;)Landroid/app/PictureInPictureParams$Builder;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p2}, Landroid/app/PictureInPictureParams$Builder;->build()Landroid/app/PictureInPictureParams;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Landroid/app/Activity;->setPictureInPictureParams(Landroid/app/PictureInPictureParams;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
