.class public final Landroidx/appcompat/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final actionBarDivider:I = 0x7f040005

.field public static final actionBarItemBackground:I = 0x7f040006

.field public static final actionBarPopupTheme:I = 0x7f040007

.field public static final actionBarSize:I = 0x7f040008

.field public static final actionBarSplitStyle:I = 0x7f040009

.field public static final actionBarStyle:I = 0x7f04000a

.field public static final actionBarTabBarStyle:I = 0x7f04000b

.field public static final actionBarTabStyle:I = 0x7f04000c

.field public static final actionBarTabTextStyle:I = 0x7f04000d

.field public static final actionBarTheme:I = 0x7f04000e

.field public static final actionBarWidgetTheme:I = 0x7f04000f

.field public static final actionButtonStyle:I = 0x7f040010

.field public static final actionDropDownStyle:I = 0x7f040011

.field public static final actionLayout:I = 0x7f040012

.field public static final actionMenuTextAppearance:I = 0x7f040013

.field public static final actionMenuTextColor:I = 0x7f040014

.field public static final actionModeBackground:I = 0x7f040015

.field public static final actionModeCloseButtonStyle:I = 0x7f040016

.field public static final actionModeCloseContentDescription:I = 0x7f040017

.field public static final actionModeCloseDrawable:I = 0x7f040018

.field public static final actionModeCopyDrawable:I = 0x7f040019

.field public static final actionModeCutDrawable:I = 0x7f04001a

.field public static final actionModeFindDrawable:I = 0x7f04001b

.field public static final actionModePasteDrawable:I = 0x7f04001c

.field public static final actionModePopupWindowStyle:I = 0x7f04001d

.field public static final actionModeSelectAllDrawable:I = 0x7f04001e

.field public static final actionModeShareDrawable:I = 0x7f04001f

.field public static final actionModeSplitBackground:I = 0x7f040020

.field public static final actionModeStyle:I = 0x7f040021

.field public static final actionModeTheme:I = 0x7f040022

.field public static final actionModeWebSearchDrawable:I = 0x7f040023

.field public static final actionOverflowButtonStyle:I = 0x7f040024

.field public static final actionOverflowMenuStyle:I = 0x7f040025

.field public static final actionProviderClass:I = 0x7f040026

.field public static final actionViewClass:I = 0x7f040028

.field public static final activityChooserViewStyle:I = 0x7f040029

.field public static final alertDialogButtonGroupStyle:I = 0x7f04002a

.field public static final alertDialogCenterButtons:I = 0x7f04002b

.field public static final alertDialogStyle:I = 0x7f04002c

.field public static final alertDialogTheme:I = 0x7f04002d

.field public static final allowStacking:I = 0x7f040030

.field public static final alphabeticModifiers:I = 0x7f040035

.field public static final arrowHeadLength:I = 0x7f04003e

.field public static final arrowShaftLength:I = 0x7f04003f

.field public static final autoCompleteTextViewStyle:I = 0x7f040043

.field public static final autoSizeMaxTextSize:I = 0x7f040045

.field public static final autoSizeMinTextSize:I = 0x7f040046

.field public static final autoSizePresetSizes:I = 0x7f040047

.field public static final autoSizeStepGranularity:I = 0x7f040048

.field public static final autoSizeTextType:I = 0x7f040049

.field public static final background:I = 0x7f04004d

.field public static final backgroundSplit:I = 0x7f040054

.field public static final backgroundStacked:I = 0x7f040055

.field public static final backgroundTint:I = 0x7f040056

.field public static final backgroundTintMode:I = 0x7f040057

.field public static final barLength:I = 0x7f040074

.field public static final borderlessButtonStyle:I = 0x7f04008a

.field public static final buttonBarButtonStyle:I = 0x7f04009d

.field public static final buttonBarNegativeButtonStyle:I = 0x7f04009e

.field public static final buttonBarNeutralButtonStyle:I = 0x7f04009f

.field public static final buttonBarPositiveButtonStyle:I = 0x7f0400a0

.field public static final buttonBarStyle:I = 0x7f0400a1

.field public static final buttonCompat:I = 0x7f0400a2

.field public static final buttonGravity:I = 0x7f0400a3

.field public static final buttonIconDimen:I = 0x7f0400a4

.field public static final buttonPanelSideLayout:I = 0x7f0400a5

.field public static final buttonStyle:I = 0x7f0400a7

.field public static final buttonStyleSmall:I = 0x7f0400a8

.field public static final buttonTint:I = 0x7f0400a9

.field public static final buttonTintMode:I = 0x7f0400aa

.field public static final checkMarkCompat:I = 0x7f0400c0

.field public static final checkMarkTint:I = 0x7f0400c1

.field public static final checkMarkTintMode:I = 0x7f0400c2

.field public static final checkboxStyle:I = 0x7f0400c3

.field public static final checkedTextViewStyle:I = 0x7f0400cd

.field public static final closeIcon:I = 0x7f0400f2

.field public static final closeItemLayout:I = 0x7f0400f9

.field public static final collapseContentDescription:I = 0x7f040100

.field public static final collapseIcon:I = 0x7f040101

.field public static final color:I = 0x7f04010b

.field public static final colorAccent:I = 0x7f04010c

.field public static final colorBackgroundFloating:I = 0x7f04010d

.field public static final colorButtonNormal:I = 0x7f04010e

.field public static final colorControlActivated:I = 0x7f040110

.field public static final colorControlHighlight:I = 0x7f040111

.field public static final colorControlNormal:I = 0x7f040112

.field public static final colorError:I = 0x7f040113

.field public static final colorPrimary:I = 0x7f040124

.field public static final colorPrimaryDark:I = 0x7f040126

.field public static final colorSwitchThumbNormal:I = 0x7f040131

.field public static final commitIcon:I = 0x7f040138

.field public static final contentDescription:I = 0x7f040141

.field public static final contentInsetEnd:I = 0x7f040142

.field public static final contentInsetEndWithActions:I = 0x7f040143

.field public static final contentInsetLeft:I = 0x7f040144

.field public static final contentInsetRight:I = 0x7f040145

.field public static final contentInsetStart:I = 0x7f040146

.field public static final contentInsetStartWithNavigation:I = 0x7f040147

.field public static final controlBackground:I = 0x7f040154

.field public static final customNavigationLayout:I = 0x7f04017d

.field public static final defaultQueryHint:I = 0x7f040188

.field public static final dialogCornerRadius:I = 0x7f04018e

.field public static final dialogPreferredPadding:I = 0x7f04018f

.field public static final dialogTheme:I = 0x7f040190

.field public static final displayOptions:I = 0x7f040191

.field public static final divider:I = 0x7f040192

.field public static final dividerHorizontal:I = 0x7f040197

.field public static final dividerPadding:I = 0x7f04019a

.field public static final dividerVertical:I = 0x7f04019c

.field public static final drawableBottomCompat:I = 0x7f0401a1

.field public static final drawableEndCompat:I = 0x7f0401a2

.field public static final drawableLeftCompat:I = 0x7f0401a3

.field public static final drawableRightCompat:I = 0x7f0401a4

.field public static final drawableSize:I = 0x7f0401a5

.field public static final drawableStartCompat:I = 0x7f0401a6

.field public static final drawableTint:I = 0x7f0401a7

.field public static final drawableTintMode:I = 0x7f0401a8

.field public static final drawableTopCompat:I = 0x7f0401a9

.field public static final drawerArrowStyle:I = 0x7f0401aa

.field public static final dropDownListViewStyle:I = 0x7f0401ad

.field public static final dropdownListPreferredItemHeight:I = 0x7f0401ae

.field public static final editTextBackground:I = 0x7f0401b1

.field public static final editTextColor:I = 0x7f0401b2

.field public static final editTextStyle:I = 0x7f0401b3

.field public static final elevation:I = 0x7f0401b4

.field public static final emojiCompatEnabled:I = 0x7f0401b8

.field public static final expandActivityOverflowButtonDrawable:I = 0x7f0401cc

.field public static final firstBaselineToTopHeight:I = 0x7f0401ef

.field public static final fontFamily:I = 0x7f040210

.field public static final fontVariationSettings:I = 0x7f040219

.field public static final gapBetweenBars:I = 0x7f04021f

.field public static final goIcon:I = 0x7f040221

.field public static final height:I = 0x7f04022e

.field public static final hideOnContentScroll:I = 0x7f040235

.field public static final homeAsUpIndicator:I = 0x7f04023b

.field public static final homeLayout:I = 0x7f04023c

.field public static final icon:I = 0x7f040240

.field public static final iconTint:I = 0x7f040246

.field public static final iconTintMode:I = 0x7f040247

.field public static final iconifiedByDefault:I = 0x7f040248

.field public static final imageButtonStyle:I = 0x7f04024d

.field public static final indeterminateProgressStyle:I = 0x7f040253

.field public static final initialActivityCount:I = 0x7f04025e

.field public static final isLightTheme:I = 0x7f040264

.field public static final itemPadding:I = 0x7f040277

.field public static final lastBaselineToBottomHeight:I = 0x7f040293

.field public static final layout:I = 0x7f040295

.field public static final lineHeight:I = 0x7f0402ef

.field public static final listChoiceBackgroundIndicator:I = 0x7f0402f2

.field public static final listChoiceIndicatorMultipleAnimated:I = 0x7f0402f3

.field public static final listChoiceIndicatorSingleAnimated:I = 0x7f0402f4

.field public static final listDividerAlertDialog:I = 0x7f0402f5

.field public static final listItemLayout:I = 0x7f0402f6

.field public static final listLayout:I = 0x7f0402f7

.field public static final listMenuViewStyle:I = 0x7f0402f8

.field public static final listPopupWindowStyle:I = 0x7f0402f9

.field public static final listPreferredItemHeight:I = 0x7f0402fa

.field public static final listPreferredItemHeightLarge:I = 0x7f0402fb

.field public static final listPreferredItemHeightSmall:I = 0x7f0402fc

.field public static final listPreferredItemPaddingEnd:I = 0x7f0402fd

.field public static final listPreferredItemPaddingLeft:I = 0x7f0402fe

.field public static final listPreferredItemPaddingRight:I = 0x7f0402ff

.field public static final listPreferredItemPaddingStart:I = 0x7f040300

.field public static final logo:I = 0x7f040303

.field public static final logoDescription:I = 0x7f040305

.field public static final maxButtonHeight:I = 0x7f040334

.field public static final measureWithLargestChild:I = 0x7f04033c

.field public static final menu:I = 0x7f04033d

.field public static final multiChoiceItemLayout:I = 0x7f04036d

.field public static final navigationContentDescription:I = 0x7f040376

.field public static final navigationIcon:I = 0x7f040377

.field public static final navigationMode:I = 0x7f040379

.field public static final numericModifiers:I = 0x7f040381

.field public static final overlapAnchor:I = 0x7f04038d

.field public static final paddingBottomNoButtons:I = 0x7f04038f

.field public static final paddingEnd:I = 0x7f040391

.field public static final paddingStart:I = 0x7f040394

.field public static final paddingTopNoTitle:I = 0x7f040395

.field public static final panelBackground:I = 0x7f04039c

.field public static final panelMenuListTheme:I = 0x7f04039d

.field public static final panelMenuListWidth:I = 0x7f04039e

.field public static final popupMenuStyle:I = 0x7f0403c4

.field public static final popupTheme:I = 0x7f0403c5

.field public static final popupWindowStyle:I = 0x7f0403c6

.field public static final preserveIconSpacing:I = 0x7f0403ca

.field public static final progressBarPadding:I = 0x7f0403cc

.field public static final progressBarStyle:I = 0x7f0403cd

.field public static final queryBackground:I = 0x7f0403f9

.field public static final queryHint:I = 0x7f0403fa

.field public static final radioButtonStyle:I = 0x7f0403fd

.field public static final ratingBarStyle:I = 0x7f040400

.field public static final ratingBarStyleIndicator:I = 0x7f040401

.field public static final ratingBarStyleSmall:I = 0x7f040402

.field public static final searchHintIcon:I = 0x7f040427

.field public static final searchIcon:I = 0x7f040428

.field public static final searchViewStyle:I = 0x7f040429

.field public static final seekBarStyle:I = 0x7f04042a

.field public static final selectableItemBackground:I = 0x7f04042b

.field public static final selectableItemBackgroundBorderless:I = 0x7f04042c

.field public static final showAsAction:I = 0x7f040443

.field public static final showDividers:I = 0x7f040448

.field public static final showText:I = 0x7f04044b

.field public static final showTitle:I = 0x7f04044c

.field public static final singleChoiceItemLayout:I = 0x7f040453

.field public static final spinBars:I = 0x7f04045d

.field public static final spinnerDropDownItemStyle:I = 0x7f04045e

.field public static final spinnerStyle:I = 0x7f04045f

.field public static final splitTrack:I = 0x7f040460

.field public static final srcCompat:I = 0x7f040467

.field public static final state_above_anchor:I = 0x7f0404ae

.field public static final subMenuArrow:I = 0x7f0404bd

.field public static final submitBackground:I = 0x7f0404c2

.field public static final subtitle:I = 0x7f0404c3

.field public static final subtitleTextAppearance:I = 0x7f0404c5

.field public static final subtitleTextColor:I = 0x7f0404c6

.field public static final subtitleTextStyle:I = 0x7f0404c7

.field public static final suggestionRowLayout:I = 0x7f0404cb

.field public static final switchMinWidth:I = 0x7f0404cd

.field public static final switchPadding:I = 0x7f0404ce

.field public static final switchStyle:I = 0x7f0404cf

.field public static final switchTextAppearance:I = 0x7f0404d0

.field public static final textAllCaps:I = 0x7f0404f6

.field public static final textAppearanceLargePopupMenu:I = 0x7f04050d

.field public static final textAppearanceListItem:I = 0x7f04050f

.field public static final textAppearanceListItemSecondary:I = 0x7f040510

.field public static final textAppearanceListItemSmall:I = 0x7f040511

.field public static final textAppearancePopupMenuHeader:I = 0x7f040513

.field public static final textAppearanceSearchResultSubtitle:I = 0x7f040514

.field public static final textAppearanceSearchResultTitle:I = 0x7f040515

.field public static final textAppearanceSmallPopupMenu:I = 0x7f040516

.field public static final textColorAlertDialogListItem:I = 0x7f040522

.field public static final textColorSearchUrl:I = 0x7f040523

.field public static final textLocale:I = 0x7f04052e

.field public static final theme:I = 0x7f040539

.field public static final thickness:I = 0x7f04053b

.field public static final thumbTextPadding:I = 0x7f040541

.field public static final thumbTint:I = 0x7f040542

.field public static final thumbTintMode:I = 0x7f040543

.field public static final tickMark:I = 0x7f040547

.field public static final tickMarkTint:I = 0x7f040548

.field public static final tickMarkTintMode:I = 0x7f040549

.field public static final tint:I = 0x7f04054c

.field public static final tintMode:I = 0x7f04054d

.field public static final title:I = 0x7f04054e

.field public static final titleMargin:I = 0x7f040553

.field public static final titleMarginBottom:I = 0x7f040554

.field public static final titleMarginEnd:I = 0x7f040555

.field public static final titleMarginStart:I = 0x7f040556

.field public static final titleMarginTop:I = 0x7f040557

.field public static final titleMargins:I = 0x7f040558

.field public static final titleTextAppearance:I = 0x7f04055b

.field public static final titleTextColor:I = 0x7f04055c

.field public static final titleTextStyle:I = 0x7f04055d

.field public static final toolbarNavigationButtonStyle:I = 0x7f04055f

.field public static final toolbarStyle:I = 0x7f040560

.field public static final tooltipForegroundColor:I = 0x7f040562

.field public static final tooltipFrameBackground:I = 0x7f040563

.field public static final tooltipText:I = 0x7f040565

.field public static final track:I = 0x7f04056b

.field public static final trackTint:I = 0x7f040572

.field public static final trackTintMode:I = 0x7f040573

.field public static final viewInflaterClass:I = 0x7f040587

.field public static final voiceIcon:I = 0x7f04058d

.field public static final windowActionBar:I = 0x7f04059c

.field public static final windowActionBarOverlay:I = 0x7f04059d

.field public static final windowActionModeOverlay:I = 0x7f04059e

.field public static final windowFixedHeightMajor:I = 0x7f04059f

.field public static final windowFixedHeightMinor:I = 0x7f0405a0

.field public static final windowFixedWidthMajor:I = 0x7f0405a1

.field public static final windowFixedWidthMinor:I = 0x7f0405a2

.field public static final windowMinWidthMajor:I = 0x7f0405a3

.field public static final windowMinWidthMinor:I = 0x7f0405a4

.field public static final windowNoTitle:I = 0x7f0405a5


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method
