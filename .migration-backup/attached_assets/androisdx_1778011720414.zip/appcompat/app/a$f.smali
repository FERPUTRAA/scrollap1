.class public abstract Landroidx/appcompat/app/a$f;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/app/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "f"
.end annotation

.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final a:I = -0x1


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public abstract a()Ljava/lang/CharSequence;
.end method

.method public abstract b()Landroid/view/View;
.end method

.method public abstract c()Landroid/graphics/drawable/Drawable;
.end method

.method public abstract d()I
.end method

.method public abstract e()Ljava/lang/Object;
.end method

.method public abstract f()Ljava/lang/CharSequence;
.end method

.method public abstract g()V
.end method

.method public abstract h(I)Landroidx/appcompat/app/a$f;
    .param p1    # I
        .annotation build Landroidx/annotation/e1;
        .end annotation
    .end param
.end method

.method public abstract i(Ljava/lang/CharSequence;)Landroidx/appcompat/app/a$f;
.end method

.method public abstract j(I)Landroidx/appcompat/app/a$f;
.end method

.method public abstract k(Landroid/view/View;)Landroidx/appcompat/app/a$f;
.end method

.method public abstract l(I)Landroidx/appcompat/app/a$f;
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param
.end method

.method public abstract m(Landroid/graphics/drawable/Drawable;)Landroidx/appcompat/app/a$f;
.end method

.method public abstract n(Landroidx/appcompat/app/a$g;)Landroidx/appcompat/app/a$f;
.end method

.method public abstract o(Ljava/lang/Object;)Landroidx/appcompat/app/a$f;
.end method

.method public abstract p(I)Landroidx/appcompat/app/a$f;
.end method

.method public abstract q(Ljava/lang/CharSequence;)Landroidx/appcompat/app/a$f;
.end method
