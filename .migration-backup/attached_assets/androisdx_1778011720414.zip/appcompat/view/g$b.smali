.class Landroidx/appcompat/view/g$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# static fields
.field private static final G:I = 0x0

.field private static final H:I = 0x0

.field private static final I:I = 0x0

.field private static final J:I = 0x0

.field private static final K:I = 0x0

.field private static final L:Z = false

.field private static final M:Z = true

.field private static final N:Z = true


# instance fields
.field A:Landroidx/core/view/b;

.field private B:Ljava/lang/CharSequence;

.field private C:Ljava/lang/CharSequence;

.field private D:Landroid/content/res/ColorStateList;

.field private E:Landroid/graphics/PorterDuff$Mode;

.field final synthetic F:Landroidx/appcompat/view/g;

.field private a:Landroid/view/Menu;

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:Z

.field private g:Z

.field private h:Z

.field private i:I

.field private j:I

.field private k:Ljava/lang/CharSequence;

.field private l:Ljava/lang/CharSequence;

.field private m:I

.field private n:C

.field private o:I

.field private p:C

.field private q:I

.field private r:I

.field private s:Z

.field private t:Z

.field private u:Z

.field private v:I

.field private w:I

.field private x:Ljava/lang/String;

.field private y:Ljava/lang/String;

.field private z:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/g;Landroid/view/Menu;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x1

    or-int/2addr v0, p1

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/g$b;->D:Landroid/content/res/ColorStateList;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/g$b;->E:Landroid/graphics/PorterDuff$Mode;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Landroidx/appcompat/view/g$b;->a:Landroid/view/Menu;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/g$b;->h()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private c(Ljava/lang/String;)C
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "tbsoa@~~i  ~ /@M@l i.@o c@K@~@@~y  @ fi - ~~~~@lo/ doo n~  u@~~@ ~~s~~@1@@bS~ ~t@m~r @v4@o~b@~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x4

    return v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method private e(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/Class<",
            "*>;[",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v3, 0x6

    iget-object v0, v0, Landroidx/appcompat/view/g;->c:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1, v1, v0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p2, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1

    :catch_0
    move-exception p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v0, "aanmnln:ttctsseat osa inC "

    const-string v0, "eosiCn nasac stastnnt ta:l"

    const/4 v3, 0x1

    const-string v0, "Cannot instantiate class: "

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo p3, "tfameuetuoMnnprplIS"

    const/4 v3, 0x4

    const-string p3, "SupportMenuInflater"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p3, p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x0

    const/4 p1, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x0

    return-object p1
.end method

.method private i(Landroid/view/MenuItem;)V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/view/g$b;->s:Z

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-boolean v1, p0, Landroidx/appcompat/view/g$b;->t:Z

    const/4 v6, 0x7

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-boolean v1, p0, Landroidx/appcompat/view/g$b;->u:Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget v1, p0, Landroidx/appcompat/view/g$b;->r:I

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-lt v1, v3, :cond_0

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    const/4 v6, 0x1

    move v1, v3

    move v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    move v1, v2

    move v1, v2

    const/4 v6, 0x4

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/g$b;->l:Ljava/lang/CharSequence;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget v1, p0, Landroidx/appcompat/view/g$b;->m:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget v0, p0, Landroidx/appcompat/view/g$b;->v:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    if-ltz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setShowAsAction(I)V

    :cond_1
    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->z:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v0, :cond_3

    const/4 v5, 0x7

    and-int/2addr v6, v5

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, v0, Landroidx/appcompat/view/g;->c:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v0, Landroidx/appcompat/view/g$a;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroidx/appcompat/view/g;->b()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v4, p0, Landroidx/appcompat/view/g$b;->z:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v0, v1, v4}, Landroidx/appcompat/view/g$a;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v0, "ndttoatnC nicuorxbor sdeahcitce setoudrow nlnanoeet Ta :icti te ibhrtdk "

    const-string/jumbo v0, "needoaobtteia nasbnntTdcdcarrcti  idttxos ke:tohwhenet    rno iitruilucC"

    const/4 v6, 0x0

    const-string/jumbo v0, "uo tbbblhoenieanrCttitsodte sditui  kxcnae  er tthwaeodnira cncTrnc dtie"

    const-string v0, "The android:onClick attribute cannot be used within a restricted context"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    throw p1

    :cond_3
    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v0, p0, Landroidx/appcompat/view/g$b;->r:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v1, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-lt v0, v1, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    instance-of v0, p1, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v0, :cond_4

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v0, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v3}, Landroidx/appcompat/view/menu/j;->w(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    goto :goto_2

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    instance-of v0, p1, Landroidx/appcompat/view/menu/k;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v0, :cond_5

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    check-cast v0, Landroidx/appcompat/view/menu/k;

    const/4 v5, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Landroidx/appcompat/view/menu/k;->j(Z)V

    :cond_5
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->x:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v1, Landroidx/appcompat/view/g;->j:[Ljava/lang/Class;

    const/4 v6, 0x3

    iget-object v2, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, v2, Landroidx/appcompat/view/g;->a:[Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0, v0, v1, v2}, Landroidx/appcompat/view/g$b;->e(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v0, Landroid/view/View;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    move v2, v3

    move v2, v3

    const/4 v6, 0x2

    move v2, v3

    move v2, v3

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v0, p0, Landroidx/appcompat/view/g$b;->w:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    if-lez v0, :cond_8

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v2, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setActionView(I)Landroid/view/MenuItem;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_3

    :cond_7
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v0, "pfpeutunbtMueaolSrn"

    const-string/jumbo v0, "nufptbruIaMnlpSoete"

    const/4 v6, 0x2

    const-string v0, "ItafurppSMpneutoenr"

    const-string v0, "SupportMenuInflater"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v1, " ttryiunoeetettrtwni/r.un/bele aigp osAitVayiiiId /iwAcicnodL fao.c egvu/em"

    const/4 v6, 0x1

    const-string v1, "ein VaLtqt A/drugeli.i oiy uaeeieItioAtnye/tpco.tgcmeobrasiwvd/tirw ca/nnfi"

    const-string v1, "Ignoring attribute \'itemActionViewLayout\'. Action view already specified."

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_8
    :goto_3
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->A:Landroidx/core/view/b;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1, v0}, Landroidx/core/view/m0;->l(Landroid/view/MenuItem;Landroidx/core/view/b;)Landroid/view/MenuItem;

    :cond_9
    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->B:Ljava/lang/CharSequence;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p1, v0}, Landroidx/core/view/m0;->p(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->C:Ljava/lang/CharSequence;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1, v0}, Landroidx/core/view/m0;->w(Landroid/view/MenuItem;Ljava/lang/CharSequence;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-char v0, p0, Landroidx/appcompat/view/g$b;->n:C

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget v1, p0, Landroidx/appcompat/view/g$b;->o:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1, v0, v1}, Landroidx/core/view/m0;->o(Landroid/view/MenuItem;CI)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-char v0, p0, Landroidx/appcompat/view/g$b;->p:C

    const/4 v5, 0x3

    move v6, v5

    iget v1, p0, Landroidx/appcompat/view/g$b;->q:I

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1, v0, v1}, Landroidx/core/view/m0;->s(Landroid/view/MenuItem;CI)V

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->E:Landroid/graphics/PorterDuff$Mode;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_a

    const/4 v6, 0x7

    invoke-static {p1, v0}, Landroidx/core/view/m0;->r(Landroid/view/MenuItem;Landroid/graphics/PorterDuff$Mode;)V

    :cond_a
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->D:Landroid/content/res/ColorStateList;

    const/4 v6, 0x5

    const/4 v5, 0x4

    if-eqz v0, :cond_b

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1, v0}, Landroidx/core/view/m0;->q(Landroid/view/MenuItem;Landroid/content/res/ColorStateList;)V

    :cond_b
    const/4 v6, 0x6

    const/4 v5, 0x5

    return-void
.end method


# virtual methods
.method public a()V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->h:Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->a:Landroid/view/Menu;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget v1, p0, Landroidx/appcompat/view/g$b;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v2, p0, Landroidx/appcompat/view/g$b;->i:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget v3, p0, Landroidx/appcompat/view/g$b;->j:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v4, p0, Landroidx/appcompat/view/g$b;->k:Ljava/lang/CharSequence;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {p0, v0}, Landroidx/appcompat/view/g$b;->i(Landroid/view/MenuItem;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void
.end method

.method public b()Landroid/view/SubMenu;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->h:Z

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->a:Landroid/view/Menu;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v1, p0, Landroidx/appcompat/view/g$b;->b:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v2, p0, Landroidx/appcompat/view/g$b;->i:I

    const/4 v6, 0x4

    iget v3, p0, Landroidx/appcompat/view/g$b;->j:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v4, p0, Landroidx/appcompat/view/g$b;->k:Ljava/lang/CharSequence;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v0}, Landroid/view/SubMenu;->getItem()Landroid/view/MenuItem;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {p0, v1}, Landroidx/appcompat/view/g$b;->i(Landroid/view/MenuItem;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-object v0
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/view/g$b;->h:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public f(Landroid/util/AttributeSet;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, v0, Landroidx/appcompat/view/g;->c:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Landroidx/appcompat/R$styleable;->MenuGroup:[I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget v0, Landroidx/appcompat/R$styleable;->MenuGroup_android_id:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v0, p0, Landroidx/appcompat/view/g$b;->b:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget v0, Landroidx/appcompat/R$styleable;->MenuGroup_android_menuCategory:I

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Landroidx/appcompat/view/g$b;->c:I

    const/4 v2, 0x7

    or-int/2addr v3, v2

    sget v0, Landroidx/appcompat/R$styleable;->MenuGroup_android_orderInCategory:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput v0, p0, Landroidx/appcompat/view/g$b;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget v0, Landroidx/appcompat/R$styleable;->MenuGroup_android_checkableBehavior:I

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v0, p0, Landroidx/appcompat/view/g$b;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget v0, Landroidx/appcompat/R$styleable;->MenuGroup_android_visible:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->f:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget v0, Landroidx/appcompat/R$styleable;->MenuGroup_android_enabled:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->g:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public g(Landroid/util/AttributeSet;)V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v0, v0, Landroidx/appcompat/view/g;->c:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget-object v1, Landroidx/appcompat/R$styleable;->MenuItem:[I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0, p1, v1}, Landroidx/appcompat/widget/n2;->F(Landroid/content/Context;Landroid/util/AttributeSet;[I)Landroidx/appcompat/widget/n2;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_id:I

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x7

    move v6, v1

    move v6, v1

    const/4 v7, 0x5

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    iput v0, p0, Landroidx/appcompat/view/g$b;->i:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_menuCategory:I

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget v2, p0, Landroidx/appcompat/view/g$b;->c:I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    sget v2, Landroidx/appcompat/R$styleable;->MenuItem_android_orderInCategory:I

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget v3, p0, Landroidx/appcompat/view/g$b;->d:I

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    invoke-virtual {p1, v2, v3}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/high16 v3, -0x10000

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    and-int/2addr v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    const v3, 0xffff

    const/4 v7, 0x5

    and-int/2addr v2, v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    or-int/2addr v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    iput v0, p0, Landroidx/appcompat/view/g$b;->j:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_title:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->x(I)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->k:Ljava/lang/CharSequence;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_titleCondensed:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->x(I)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->l:Ljava/lang/CharSequence;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_icon:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput v0, p0, Landroidx/appcompat/view/g$b;->m:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_alphabeticShortcut:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->w(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-direct {p0, v0}, Landroidx/appcompat/view/g$b;->c(Ljava/lang/String;)C

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    iput-char v0, p0, Landroidx/appcompat/view/g$b;->n:C

    const/4 v6, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_alphabeticModifiers:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/16 v2, 0x1000

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    iput v0, p0, Landroidx/appcompat/view/g$b;->o:I

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_numericShortcut:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->w(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {p0, v0}, Landroidx/appcompat/view/g$b;->c(Ljava/lang/String;)C

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput-char v0, p0, Landroidx/appcompat/view/g$b;->p:C

    const/4 v7, 0x6

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_numericModifiers:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput v0, p0, Landroidx/appcompat/view/g$b;->q:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_checkable:I

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput v0, p0, Landroidx/appcompat/view/g$b;->r:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget v0, p0, Landroidx/appcompat/view/g$b;->e:I

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput v0, p0, Landroidx/appcompat/view/g$b;->r:I

    :goto_0
    const/4 v6, 0x2

    move v7, v6

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_checked:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->s:Z

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_visible:I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-boolean v2, p0, Landroidx/appcompat/view/g$b;->f:Z

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->t:Z

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_enabled:I

    const/4 v7, 0x5

    const/4 v6, 0x5

    iget-boolean v2, p0, Landroidx/appcompat/view/g$b;->g:Z

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->u:Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_showAsAction:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v2, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput v0, p0, Landroidx/appcompat/view/g$b;->v:I

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_android_onClick:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->w(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->z:Ljava/lang/String;

    const/4 v7, 0x0

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_actionLayout:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    iput v0, p0, Landroidx/appcompat/view/g$b;->w:I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_actionViewClass:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->w(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->x:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_actionProviderClass:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->w(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->y:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    move v3, v1

    move v3, v1

    const/4 v7, 0x7

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v3, :cond_2

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget v5, p0, Landroidx/appcompat/view/g$b;->w:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez v5, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v5, p0, Landroidx/appcompat/view/g$b;->x:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v5, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object v3, Landroidx/appcompat/view/g;->k:[Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v5, p0, Landroidx/appcompat/view/g$b;->F:Landroidx/appcompat/view/g;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v5, v5, Landroidx/appcompat/view/g;->b:[Ljava/lang/Object;

    const/4 v7, 0x1

    invoke-direct {p0, v0, v3, v5}, Landroidx/appcompat/view/g$b;->e(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    check-cast v0, Landroidx/core/view/b;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->A:Landroidx/core/view/b;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_2

    :cond_2
    const/4 v6, 0x5

    if-eqz v3, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const-string v0, "ensrlpeMnStIpufaopt"

    const-string/jumbo v0, "rlanuoupIeMpttSfpen"

    const/4 v7, 0x2

    const-string/jumbo v0, "npemSttrlInuuoMaefp"

    const-string v0, "SupportMenuInflater"

    const/4 v7, 0x6

    const-string/jumbo v3, "oyggodod/vir.nqCni/t  enrneeeiasolecsfpiriAtdtaesoba/ iu P/lrvrctt iwc.iIa"

    const-string/jumbo v3, "lp icarrqiA/io..tbciCo rn/sier/erI dosta/ugvedytosd ente iai cagtewlfnnPvi"

    const/4 v7, 0x5

    const-string v3, ".i/t.bvrrir  oe etacgrtCpaodeluascnfnPtAai/e/vsde /iyI casnbwiliigdio ortn"

    const-string v3, "Ignoring attribute \'actionProviderClass\'. Action view already specified."

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    iput-object v4, p0, Landroidx/appcompat/view/g$b;->A:Landroidx/core/view/b;

    :goto_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_contentDescription:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->x(I)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->B:Ljava/lang/CharSequence;

    const/4 v7, 0x4

    const/4 v6, 0x6

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_tooltipText:I

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->x(I)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->C:Ljava/lang/CharSequence;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_iconTintMode:I

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x7

    if-eqz v3, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1, v0, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Landroidx/appcompat/view/g$b;->E:Landroid/graphics/PorterDuff$Mode;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v0, v2}, Landroidx/appcompat/widget/e1;->e(ILandroid/graphics/PorterDuff$Mode;)Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->E:Landroid/graphics/PorterDuff$Mode;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_3

    :cond_4
    const/4 v7, 0x0

    iput-object v4, p0, Landroidx/appcompat/view/g$b;->E:Landroid/graphics/PorterDuff$Mode;

    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    sget v0, Landroidx/appcompat/R$styleable;->MenuItem_iconTint:I

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->C(I)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v2, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/n2;->d(I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    iput-object v0, p0, Landroidx/appcompat/view/g$b;->D:Landroid/content/res/ColorStateList;

    const/4 v7, 0x3

    goto :goto_4

    :cond_5
    const/4 v7, 0x3

    iput-object v4, p0, Landroidx/appcompat/view/g$b;->D:Landroid/content/res/ColorStateList;

    :goto_4
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/widget/n2;->I()V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-boolean v1, p0, Landroidx/appcompat/view/g$b;->h:Z

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method

.method public h()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    iput v0, p0, Landroidx/appcompat/view/g$b;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput v0, p0, Landroidx/appcompat/view/g$b;->c:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Landroidx/appcompat/view/g$b;->d:I

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Landroidx/appcompat/view/g$b;->e:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->f:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/view/g$b;->g:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    return-void
.end method
