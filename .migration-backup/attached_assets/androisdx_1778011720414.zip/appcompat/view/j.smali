.class public final synthetic Landroidx/appcompat/view/j;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/view/Window$Callback;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "los@~@~ao~r@c ~4 t~o i ~~@o@S @ b~/@ ~@i ~ ~M @~b@n ~uod  ~@@f- oyKvs@~~~ @l/~~@@tm@.@i@ ~@f~b ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    invoke-interface {p0, p1}, Landroid/view/Window$Callback;->onPointerCaptureChanged(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method
