.class public abstract Landroidx/appcompat/view/menu/b;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/appcompat/view/menu/n;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field protected a:Landroid/content/Context;

.field protected b:Landroid/content/Context;

.field protected c:Landroidx/appcompat/view/menu/g;

.field protected d:Landroid/view/LayoutInflater;

.field protected e:Landroid/view/LayoutInflater;

.field private f:Landroidx/appcompat/view/menu/n$a;

.field private g:I

.field private h:I

.field protected i:Landroidx/appcompat/view/menu/o;

.field private j:I


# direct methods
.method public constructor <init>(Landroid/content/Context;II)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->d:Landroid/view/LayoutInflater;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p2, p0, Landroidx/appcompat/view/menu/b;->g:I

    const/4 v1, 0x2

    iput p3, p0, Landroidx/appcompat/view/menu/b;->h:I

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method protected b(Landroid/view/View;I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public c(Landroidx/appcompat/view/menu/g;Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->f:Landroidx/appcompat/view/menu/n$a;

    const/4 v2, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/view/menu/n$a;->c(Landroidx/appcompat/view/menu/g;Z)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public d(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z
    .locals 2

    const/4 p1, 0x5

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method public e(Landroidx/appcompat/view/menu/n$a;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->f:Landroidx/appcompat/view/menu/n$a;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public g(Landroidx/appcompat/view/menu/s;)Z
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->f:Landroidx/appcompat/view/menu/n$a;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/n$a;->d(Landroidx/appcompat/view/menu/g;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x1

    move v2, v1

    return p1
.end method

.method public getId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Landroidx/appcompat/view/menu/b;->j:I

    const/4 v2, 0x6

    return v0
.end method

.method public h(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->d:Landroid/view/LayoutInflater;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget v1, p0, Landroidx/appcompat/view/menu/b;->g:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v2, 0x0

    move v4, v2

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast p1, Landroidx/appcompat/view/menu/o;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {p1, v0}, Landroidx/appcompat/view/menu/o;->a(Landroidx/appcompat/view/menu/g;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/b;->j(Z)V

    :cond_0
    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object p1
.end method

.method public j(Z)V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v10, 0x7

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-nez p1, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    return-void

    :cond_0
    const/4 v10, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v0, :cond_6

    const/4 v10, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->u()V

    const/4 v10, 0x6

    const/4 v9, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v9, 0x3

    and-int/2addr v10, v9

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    move v3, v1

    move v3, v1

    const/4 v10, 0x2

    move v3, v1

    move v3, v1

    const/4 v9, 0x3

    const/4 v10, 0x5

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-ge v3, v2, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    check-cast v5, Landroidx/appcompat/view/menu/j;

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {p0, v4, v5}, Landroidx/appcompat/view/menu/b;->t(ILandroidx/appcompat/view/menu/j;)Z

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v6, :cond_4

    invoke-virtual {p1, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    instance-of v7, v6, Landroidx/appcompat/view/menu/o$a;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v7, :cond_1

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    check-cast v7, Landroidx/appcompat/view/menu/o$a;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-interface {v7}, Landroidx/appcompat/view/menu/o$a;->getItemData()Landroidx/appcompat/view/menu/j;

    move-result-object v7

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_1

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v7, 0x0

    :goto_1
    const/4 v9, 0x2

    move v10, v9

    invoke-virtual {p0, v5, v6, p1}, Landroidx/appcompat/view/menu/b;->r(Landroidx/appcompat/view/menu/j;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v8

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eq v5, v7, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v8, v1}, Landroid/view/View;->setPressed(Z)V

    const/4 v10, 0x5

    invoke-virtual {v8}, Landroid/view/View;->jumpDrawablesToCurrentState()V

    :cond_2
    const/4 v9, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eq v8, v6, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p0, v8, v4}, Landroidx/appcompat/view/menu/b;->b(Landroid/view/View;I)V

    :cond_3
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    add-int/lit8 v4, v4, 0x1

    :cond_4
    const/4 v9, 0x0

    move v10, v9

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x5

    goto :goto_0

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x7

    move v1, v4

    move v1, v4

    const/4 v10, 0x0

    move v1, v4

    move v1, v4

    :cond_6
    :goto_2
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-ge v1, v0, :cond_7

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p0, p1, v1}, Landroidx/appcompat/view/menu/b;->p(Landroid/view/ViewGroup;I)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-nez v0, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto :goto_2

    :cond_7
    const/4 v10, 0x3

    const/4 v9, 0x5

    return-void
.end method

.method public k()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v0, 0x3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public l(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 p1, 0x0

    shr-int/2addr v1, p1

    return p1
.end method

.method public m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->e:Landroid/view/LayoutInflater;

    const/4 v1, 0x5

    iput-object p2, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public abstract n(Landroidx/appcompat/view/menu/j;Landroidx/appcompat/view/menu/o$a;)V
.end method

.method public o(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o$a;
    .locals 5

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->d:Landroid/view/LayoutInflater;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Landroidx/appcompat/view/menu/b;->h:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    check-cast p1, Landroidx/appcompat/view/menu/o$a;

    const/4 v4, 0x7

    const/4 v3, 0x6

    return-object p1
.end method

.method protected p(Landroid/view/ViewGroup;I)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->removeViewAt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p1
.end method

.method public q()Landroidx/appcompat/view/menu/n$a;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->f:Landroidx/appcompat/view/menu/n$a;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public r(Landroidx/appcompat/view/menu/j;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 3

    const/4 v2, 0x3

    instance-of v0, p2, Landroidx/appcompat/view/menu/o$a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p2, Landroidx/appcompat/view/menu/o$a;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p3}, Landroidx/appcompat/view/menu/b;->o(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o$a;

    move-result-object p2

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/b;->n(Landroidx/appcompat/view/menu/j;Landroidx/appcompat/view/menu/o$a;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p2, Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p2
.end method

.method public s(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Landroidx/appcompat/view/menu/b;->j:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public t(ILandroidx/appcompat/view/menu/j;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x4

    return p1
.end method
