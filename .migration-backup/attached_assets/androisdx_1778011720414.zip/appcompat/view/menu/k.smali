.class public Landroidx/appcompat/view/menu/k;
.super Landroidx/appcompat/view/menu/c;

# interfaces
.implements Landroid/view/MenuItem;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/k$c;,
        Landroidx/appcompat/view/menu/k$b;,
        Landroidx/appcompat/view/menu/k$a;,
        Landroidx/appcompat/view/menu/k$d;,
        Landroidx/appcompat/view/menu/k$e;
    }
.end annotation


# static fields
.field static final q:Ljava/lang/String; = "MenuItemWrapper"


# instance fields
.field private final o:Lm/c;

.field private p:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lm/c;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/c;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p2, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string p2, ".psljnuer stO oeW bn cdpacb tne"

    const-string p2, "dtsonneWb arpn   tpjO.lcblee cu"

    const/4 v1, 0x7

    const-string p2, ".ncmbWbtjau rdan o pnl eOepct l"

    const-string p2, "Wrapped Object can not be null."

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    throw p1
.end method


# virtual methods
.method public collapseActionView()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~s o@idr@ ~boMb@@@bl~~t ~~.1 @@c@~~u~K n4~~o@i~o @~~f@  l-~@o / @~o~ o f~v~ @  @/~y@~~ Sa@@@ @m"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0}, Lm/c;->collapseActionView()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public expandActionView()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0}, Lm/c;->expandActionView()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public getActionProvider()Landroid/view/ActionProvider;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0}, Lm/c;->a()Landroidx/core/view/b;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    instance-of v1, v0, Landroidx/appcompat/view/menu/k$a;

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast v0, Landroidx/appcompat/view/menu/k$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, v0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    move v2, v0

    move v2, v0

    const/4 v3, 0x6

    return-object v0
.end method

.method public getActionView()Landroid/view/View;
    .locals 4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x4

    invoke-interface {v0}, Lm/c;->getActionView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    instance-of v1, v0, Landroidx/appcompat/view/menu/k$c;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v2, 0x5

    and-int/2addr v3, v2

    check-cast v0, Landroidx/appcompat/view/menu/k$c;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/k$c;->a()Landroid/view/View;

    move-result-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0
.end method

.method public getAlphabeticModifiers()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0}, Lm/c;->getAlphabeticModifiers()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    return v0
.end method

.method public getAlphabeticShortcut()C
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {v0}, Landroid/view/MenuItem;->getAlphabeticShortcut()C

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public getContentDescription()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {v0}, Lm/c;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public getGroupId()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Landroid/view/MenuItem;->getGroupId()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {v0}, Lm/c;->getIconTintList()Landroid/content/res/ColorStateList;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x0

    invoke-interface {v0}, Lm/c;->getIconTintMode()Landroid/graphics/PorterDuff$Mode;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0}, Landroid/view/MenuItem;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getItemId()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0}, Landroid/view/MenuItem;->getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public getNumericModifiers()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {v0}, Lm/c;->getNumericModifiers()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public getNumericShortcut()C
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-interface {v0}, Landroid/view/MenuItem;->getNumericShortcut()C

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public getOrder()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0}, Landroid/view/MenuItem;->getOrder()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public getSubMenu()Landroid/view/SubMenu;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v1, 0x3

    const/4 v1, 0x1

    invoke-interface {v0}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/c;->f(Landroid/view/SubMenu;)Landroid/view/SubMenu;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {v0}, Landroid/view/MenuItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTitleCondensed()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-interface {v0}, Landroid/view/MenuItem;->getTitleCondensed()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public getTooltipText()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0}, Lm/c;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public hasSubMenu()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-interface {v0}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public isActionViewExpanded()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0}, Lm/c;->isActionViewExpanded()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public isCheckable()Z
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Landroid/view/MenuItem;->isCheckable()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public isChecked()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-interface {v0}, Landroid/view/MenuItem;->isChecked()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public isEnabled()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-interface {v0}, Landroid/view/MenuItem;->isEnabled()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public isVisible()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0}, Landroid/view/MenuItem;->isVisible()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public j(Z)V
    .locals 8

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->p:Ljava/lang/reflect/Method;

    const/4 v6, 0x5

    and-int/2addr v7, v6

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v3, "tcsesbvECkxeblaelmecu"

    const-string/jumbo v3, "kelmevslbxcctEaseieCu"

    const/4 v7, 0x0

    const-string v3, "eveEeculkheilxsatbCcs"

    const-string/jumbo v3, "setExclusiveCheckable"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    aput-object v5, v4, v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/menu/k;->p:Ljava/lang/reflect/Method;

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->p:Ljava/lang/reflect/Method;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v3, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    aput-object p1, v2, v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const-string v0, "eIMnormpeutrWpp"

    const-string/jumbo v0, "meeuoIrWntpprMe"

    const/4 v7, 0x3

    const-string/jumbo v0, "merpWInequMpetr"

    const-string v0, "MenuItemWrapper"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v1, "txsoeh ceiwckusrnebCihllee vagErilasErllc"

    const-string v1, "Error while calling setExclusiveCheckable"

    const/4 v7, 0x6

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-void
.end method

.method public setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x2

    new-instance v0, Landroidx/appcompat/view/menu/k$b;

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->l:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1, p1}, Landroidx/appcompat/view/menu/k$b;-><init>(Landroidx/appcompat/view/menu/k;Landroid/content/Context;Landroid/view/ActionProvider;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x2

    invoke-interface {v1, v0}, Lm/c;->c(Landroidx/core/view/b;)Lm/c;

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0
.end method

.method public setActionView(I)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x0

    invoke-interface {v0, p1}, Lm/c;->setActionView(I)Landroid/view/MenuItem;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object p1, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p1}, Lm/c;->getActionView()Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    instance-of v0, p1, Landroid/view/CollapsibleActionView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance v1, Landroidx/appcompat/view/menu/k$c;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v1, p1}, Landroidx/appcompat/view/menu/k$c;-><init>(Landroid/view/View;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Lm/c;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p0
.end method

.method public setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    instance-of v0, p1, Landroid/view/CollapsibleActionView;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Landroidx/appcompat/view/menu/k$c;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Landroidx/appcompat/view/menu/k$c;-><init>(Landroid/view/View;)V

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    move-object p1, v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lm/c;->setActionView(Landroid/view/View;)Landroid/view/MenuItem;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setAlphabeticShortcut(C)Landroid/view/MenuItem;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-interface {v0, p1, p2}, Lm/c;->setAlphabeticShortcut(CI)Landroid/view/MenuItem;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public setCheckable(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0
.end method

.method public setChecked(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lm/c;->setContentDescription(Ljava/lang/CharSequence;)Lm/c;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-object p0
.end method

.method public setEnabled(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v1, 0x6

    move v2, v1

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    const/4 v1, 0x0

    return-object p0
.end method

.method public setIcon(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lm/c;->setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Lm/c;->setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setNumericShortcut(C)Landroid/view/MenuItem;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Lm/c;->setNumericShortcut(CI)Landroid/view/MenuItem;

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v1, Landroidx/appcompat/view/menu/k$d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v1, p0, p1}, Landroidx/appcompat/view/menu/k$d;-><init>(Landroidx/appcompat/view/menu/k;Landroid/view/MenuItem$OnActionExpandListener;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;

    const/4 v3, 0x2

    return-object p0
.end method

.method public setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v1, Landroidx/appcompat/view/menu/k$e;

    const/4 v2, 0x2

    move v3, v2

    invoke-direct {v1, p0, p1}, Landroidx/appcompat/view/menu/k$e;-><init>(Landroidx/appcompat/view/menu/k;Landroid/view/MenuItem$OnMenuItemClickListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-interface {v0, v1}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p0
.end method

.method public setShortcut(CC)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Landroid/view/MenuItem;->setShortcut(CC)Landroid/view/MenuItem;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public setShortcut(CCII)Landroid/view/MenuItem;
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {v0, p1, p2, p3, p4}, Lm/c;->setShortcut(CCII)Landroid/view/MenuItem;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public setShowAsAction(I)V
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lm/c;->setShowAsAction(I)V

    return-void
.end method

.method public setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x2

    invoke-interface {v0, p1}, Lm/c;->setShowAsActionFlags(I)Landroid/view/MenuItem;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0
.end method

.method public setTitle(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setTitle(I)Landroid/view/MenuItem;

    const/4 v2, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Lm/c;->setTooltipText(Ljava/lang/CharSequence;)Lm/c;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public setVisible(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k;->o:Lm/c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1
.end method
