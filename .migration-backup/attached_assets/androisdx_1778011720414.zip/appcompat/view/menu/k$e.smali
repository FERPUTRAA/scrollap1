.class Landroidx/appcompat/view/menu/k$e;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/MenuItem$OnMenuItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "e"
.end annotation


# instance fields
.field private final a:Landroid/view/MenuItem$OnMenuItemClickListener;

.field final synthetic b:Landroidx/appcompat/view/menu/k;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/k;Landroid/view/MenuItem$OnMenuItemClickListener;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/k$e;->b:Landroidx/appcompat/view/menu/k;

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Landroidx/appcompat/view/menu/k$e;->a:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onMenuItemClick(Landroid/view/MenuItem;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ sv@@a m oSK~ -.~l~ ~yMo@ srfloub@@@~@@@ @/i~f~ ~i@~    bt1oc@~@@bo@@o~ d/~ ~ ~@4~~~@ ~~~in@~@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$e;->a:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Landroidx/appcompat/view/menu/k$e;->b:Landroidx/appcompat/view/menu/k;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Landroidx/appcompat/view/menu/c;->e(Landroid/view/MenuItem;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1}, Landroid/view/MenuItem$OnMenuItemClickListener;->onMenuItemClick(Landroid/view/MenuItem;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p1
.end method
