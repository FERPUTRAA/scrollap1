.class public Landroidx/appcompat/view/menu/a;
.super Ljava/lang/Object;

# interfaces
.implements Lm/c;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final F:I = 0x1

.field private static final G:I = 0x2

.field private static final H:I = 0x4

.field private static final I:I = 0x8

.field private static final J:I = 0x10


# instance fields
.field private A:Landroid/content/res/ColorStateList;

.field private B:Landroid/graphics/PorterDuff$Mode;

.field private C:Z

.field private D:Z

.field private E:I

.field private final l:I

.field private final m:I

.field private final n:I

.field private o:Ljava/lang/CharSequence;

.field private p:Ljava/lang/CharSequence;

.field private q:Landroid/content/Intent;

.field private r:C

.field private s:I

.field private t:C

.field private u:I

.field private v:Landroid/graphics/drawable/Drawable;

.field private w:Landroid/content/Context;

.field private x:Landroid/view/MenuItem$OnMenuItemClickListener;

.field private y:Ljava/lang/CharSequence;

.field private z:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>(Landroid/content/Context;IIIILjava/lang/CharSequence;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/16 p4, 0x1000

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p4, p0, Landroidx/appcompat/view/menu/a;->s:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p4, p0, Landroidx/appcompat/view/menu/a;->u:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p4, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p4, p0, Landroidx/appcompat/view/menu/a;->A:Landroid/content/res/ColorStateList;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p4, p0, Landroidx/appcompat/view/menu/a;->B:Landroid/graphics/PorterDuff$Mode;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    const/4 p4, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-boolean p4, p0, Landroidx/appcompat/view/menu/a;->C:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-boolean p4, p0, Landroidx/appcompat/view/menu/a;->D:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/16 p4, 0x10

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p4, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->w:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p3, p0, Landroidx/appcompat/view/menu/a;->l:I

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p2, p0, Landroidx/appcompat/view/menu/a;->m:I

    iput p5, p0, Landroidx/appcompat/view/menu/a;->n:I

    const/4 v0, 0x0

    xor-int/2addr v1, v0

    iput-object p6, p0, Landroidx/appcompat/view/menu/a;->o:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private e()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~so@t@@y@~@oo@l@@u     @s ~   ~t~@@@ ~~4rbof~~~~@ @ @@@bl~b~ viMc1/~~i a@~~ f~~ ~/.~@oi-~mdK@on"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/a;->C:Z

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    if-nez v1, :cond_0

    const/4 v3, 0x3

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/a;->D:Z

    const/4 v2, 0x3

    move v3, v2

    if-eqz v1, :cond_2

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/a;->C:Z

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/a;->A:Landroid/content/res/ColorStateList;

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/a;->D:Z

    const/4 v2, 0x3

    or-int/2addr v3, v2

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/a;->B:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0, v1}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public a()Landroidx/core/view/b;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public c(Landroidx/core/view/b;)Lm/c;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    throw p1
.end method

.method public collapseActionView()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/4 v1, 0x3

    return v0
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public expandActionView()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    return v0
.end method

.method public f()Z
    .locals 5

    const/4 v3, 0x7

    move v4, v3

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->x:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnMenuItemClickListener;->onMenuItemClick(Landroid/view/MenuItem;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    return v1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->q:Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    iget-object v2, p0, Landroidx/appcompat/view/menu/a;->w:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    return v0
.end method

.method public g(I)Lm/c;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    throw p1
.end method

.method public getActionProvider()Landroid/view/ActionProvider;
    .locals 3

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    throw v0
.end method

.method public getActionView()Landroid/view/View;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public getAlphabeticModifiers()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/view/menu/a;->u:I

    const/4 v1, 0x2

    move v2, v1

    return v0
.end method

.method public getAlphabeticShortcut()C
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-char v0, p0, Landroidx/appcompat/view/menu/a;->t:C

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public getContentDescription()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->y:Ljava/lang/CharSequence;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public getGroupId()I
    .locals 3

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/a;->m:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->A:Landroid/content/res/ColorStateList;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->B:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->q:Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public getItemId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/a;->l:I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getNumericModifiers()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/a;->s:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    return v0
.end method

.method public getNumericShortcut()C
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-char v0, p0, Landroidx/appcompat/view/menu/a;->r:C

    const/4 v2, 0x0

    return v0
.end method

.method public getOrder()I
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/view/menu/a;->n:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public getSubMenu()Landroid/view/SubMenu;
    .locals 3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->o:Ljava/lang/CharSequence;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method public getTitleCondensed()Ljava/lang/CharSequence;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->p:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->o:Ljava/lang/CharSequence;

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTooltipText()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->z:Ljava/lang/CharSequence;

    const/4 v1, 0x7

    move v2, v1

    return-object v0
.end method

.method public h(Landroid/view/View;)Lm/c;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    throw p1
.end method

.method public hasSubMenu()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public i(Z)Landroidx/appcompat/view/menu/a;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p1, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    or-int/2addr p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public isActionViewExpanded()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public isCheckable()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    and-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v1
.end method

.method public isChecked()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    and-int/lit8 v0, v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public isEnabled()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public isVisible()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    and-int/lit8 v0, v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    return v0
.end method

.method public j(I)Lm/c;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/a;->setShowAsAction(I)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    throw p1
.end method

.method public bridge synthetic setActionView(I)Landroid/view/MenuItem;
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/a;->g(I)Lm/c;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method public bridge synthetic setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/a;->h(Landroid/view/View;)Lm/c;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->t:C

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-object p0
.end method

.method public setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->t:C

    const/4 v1, 0x1

    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Landroidx/appcompat/view/menu/a;->u:I

    const/4 v1, 0x2

    return-object p0
.end method

.method public setCheckable(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    and-int/lit8 v0, v0, -0x2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    or-int/2addr p1, v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput p1, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0
.end method

.method public setChecked(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    and-int/lit8 v0, v0, -0x3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p1, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    move v2, p1

    :goto_0
    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p1, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public bridge synthetic setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/a;->setContentDescription(Ljava/lang/CharSequence;)Lm/c;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)Lm/c;
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->y:Ljava/lang/CharSequence;

    const/4 v1, 0x3

    return-object p0
.end method

.method public setEnabled(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    and-int/lit8 v0, v0, -0x11

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/16 p1, 0x10

    const/4 v2, 0x3

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    or-int/2addr p1, v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput p1, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v2, 0x1

    return-object p0
.end method

.method public setIcon(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->w:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p1}, Landroidx/core/content/d;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Landroidx/appcompat/view/menu/a;->e()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->v:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Landroidx/appcompat/view/menu/a;->e()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 2
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->A:Landroid/content/res/ColorStateList;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/a;->C:Z

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Landroidx/appcompat/view/menu/a;->e()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->B:Landroid/graphics/PorterDuff$Mode;

    const/4 v1, 0x5

    const/4 p1, 0x3

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/a;->D:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Landroidx/appcompat/view/menu/a;->e()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->q:Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->r:C

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method public setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->r:C

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Landroidx/appcompat/view/menu/a;->s:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-object p0
.end method

.method public setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p1}, Ljava/lang/UnsupportedOperationException;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    throw p1
.end method

.method public setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->x:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public setShortcut(CC)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->r:C

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->t:C

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public setShortcut(CCII)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->r:C

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/a;->s:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v1, 0x5

    iput-char p1, p0, Landroidx/appcompat/view/menu/a;->t:C

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Landroidx/appcompat/view/menu/a;->u:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-object p0
.end method

.method public setShowAsAction(I)V
    .locals 2

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/a;->j(I)Lm/c;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p1
.end method

.method public setTitle(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/a;->w:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->o:Ljava/lang/CharSequence;

    const/4 v1, 0x7

    move v2, v1

    return-object p0
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->o:Ljava/lang/CharSequence;

    return-object p0
.end method

.method public setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->p:Ljava/lang/CharSequence;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public bridge synthetic setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/a;->setTooltipText(Ljava/lang/CharSequence;)Lm/c;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p1
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)Lm/c;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/a;->z:Ljava/lang/CharSequence;

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-object p0
.end method

.method public setVisible(Z)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v0, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/16 v1, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x5

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    move v2, v1

    move v2, v1

    :cond_0
    const/4 v3, 0x2

    or-int p1, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput p1, p0, Landroidx/appcompat/view/menu/a;->E:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p0
.end method
