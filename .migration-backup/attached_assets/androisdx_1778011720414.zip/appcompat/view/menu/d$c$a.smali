.class Landroidx/appcompat/view/menu/d$c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/view/menu/d$c;->e(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/view/menu/d$d;

.field final synthetic b:Landroid/view/MenuItem;

.field final synthetic c:Landroidx/appcompat/view/menu/g;

.field final synthetic d:Landroidx/appcompat/view/menu/d$c;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/d$c;Landroidx/appcompat/view/menu/d$d;Landroid/view/MenuItem;Landroidx/appcompat/view/menu/g;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/d$c$a;->d:Landroidx/appcompat/view/menu/d$c;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p2, p0, Landroidx/appcompat/view/menu/d$c$a;->a:Landroidx/appcompat/view/menu/d$d;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p3, p0, Landroidx/appcompat/view/menu/d$c$a;->b:Landroid/view/MenuItem;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p4, p0, Landroidx/appcompat/view/menu/d$c$a;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "y s~ol~~@n @ td@@@~@K~~o.@@@ r-f~o~ oM @~ ~  voiS@@@~~~c ~ u b~~ib@@/@4btf~s@ ~i@l@o~a1 ~ ~ m/ ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c$a;->a:Landroidx/appcompat/view/menu/d$d;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/d$c$a;->d:Landroidx/appcompat/view/menu/d$c;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, v1, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v2, v1, Landroidx/appcompat/view/menu/d;->A:Z

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, v0, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    and-int/2addr v3, v1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c$a;->d:Landroidx/appcompat/view/menu/d$c;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, v0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-boolean v1, v0, Landroidx/appcompat/view/menu/d;->A:Z

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c$a;->b:Landroid/view/MenuItem;

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0}, Landroid/view/MenuItem;->isEnabled()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c$a;->b:Landroid/view/MenuItem;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v0}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c$a;->c:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x6

    and-int/2addr v4, v3

    iget-object v1, p0, Landroidx/appcompat/view/menu/d$c$a;->b:Landroid/view/MenuItem;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v2, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/view/menu/g;->O(Landroid/view/MenuItem;I)Z

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method
