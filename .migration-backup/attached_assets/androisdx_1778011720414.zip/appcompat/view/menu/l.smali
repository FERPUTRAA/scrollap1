.class abstract Landroidx/appcompat/view/menu/l;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/appcompat/view/menu/q;
.implements Landroidx/appcompat/view/menu/n;
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field private a:Landroid/graphics/Rect;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    return-void
.end method

.method protected static A(Landroidx/appcompat/view/menu/g;)Z
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "4us/ ot ~ Sb~o~fn@~. @@  Myfr@@@@~~@~@  ta1~ ~@  ~md@/@~o~b@~~@@l- ~Ki~@v~~@o  l~bs@o o ci@@~~i "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ge v2, v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0, v2}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-interface {v3}, Landroid/view/MenuItem;->isVisible()Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v3}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_1

    :cond_0
    const/4 v5, 0x5

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v5, 0x1

    return v1
.end method

.method protected static B(Landroid/widget/ListAdapter;)Landroidx/appcompat/view/menu/f;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    instance-of v0, p0, Landroid/widget/HeaderViewListAdapter;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Landroid/widget/HeaderViewListAdapter;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    check-cast p0, Landroidx/appcompat/view/menu/f;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p0, Landroidx/appcompat/view/menu/f;

    const/4 v2, 0x3

    return-object p0
.end method

.method protected static r(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v0, 0x0

    move v10, v0

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {v0, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v0, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {p0}, Landroid/widget/Adapter;->getCount()I

    move-result v3

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v4, 0x0

    const/4 v10, 0x3

    move v5, v0

    move v5, v0

    const/4 v10, 0x7

    move v5, v0

    const/4 v9, 0x6

    move v10, v9

    move v6, v5

    move v6, v5

    const/4 v10, 0x1

    move v6, v5

    move v6, v5

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-ge v0, v3, :cond_4

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-interface {p0, v0}, Landroid/widget/Adapter;->getItemViewType(I)I

    move-result v8

    const/4 v10, 0x3

    if-eq v8, v6, :cond_0

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    move v6, v8

    move v6, v8

    const/4 v10, 0x3

    move v6, v8

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-nez p1, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x6

    new-instance p1, Landroid/widget/FrameLayout;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-direct {p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-interface {p0, v0, v7, p1}, Landroid/widget/Adapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v7, v1, v2}, Landroid/view/View;->measure(II)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I

    move-result v8

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-lt v8, p3, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    return p3

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-le v8, v5, :cond_3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    move v5, v8

    move v5, v8

    move v5, v8

    move v5, v8

    :cond_3
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v10, 0x4

    goto :goto_0

    :cond_4
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    return v5
.end method


# virtual methods
.method public d(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method public getId()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public h(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "ooamargi pesmu pPinnnsewwehM uvte"

    const-string v0, "MenuPopups manage their own views"

    const/4 v1, 0x5

    move v2, v1

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    throw p1
.end method

.method public l(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method public m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method public abstract n(Landroidx/appcompat/view/menu/g;)V
.end method

.method protected o()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1}, Landroid/widget/AdapterView;->getAdapter()Landroid/widget/Adapter;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    check-cast p1, Landroid/widget/ListAdapter;

    const/4 v1, 0x2

    invoke-static {p1}, Landroidx/appcompat/view/menu/l;->B(Landroid/widget/ListAdapter;)Landroidx/appcompat/view/menu/f;

    move-result-object p2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p2, p2, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-interface {p1, p3}, Landroid/widget/Adapter;->getItem(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    check-cast p1, Landroid/view/MenuItem;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/l;->o()Z

    move-result p3

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p3, 0x0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p3, 0x4

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p2, p1, p0, p3}, Landroidx/appcompat/view/menu/g;->P(Landroid/view/MenuItem;Landroidx/appcompat/view/menu/n;I)Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method

.method public q()Landroid/graphics/Rect;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/l;->a:Landroid/graphics/Rect;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public abstract s(Landroid/view/View;)V
.end method

.method public t(Landroid/graphics/Rect;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/l;->a:Landroid/graphics/Rect;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public abstract u(Z)V
.end method

.method public abstract v(I)V
.end method

.method public abstract w(I)V
.end method

.method public abstract x(Landroid/widget/PopupWindow$OnDismissListener;)V
.end method

.method public abstract y(Z)V
.end method

.method public abstract z(I)V
.end method
