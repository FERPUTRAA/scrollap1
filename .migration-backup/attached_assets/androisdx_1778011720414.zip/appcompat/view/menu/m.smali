.class public Landroidx/appcompat/view/menu/m;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/appcompat/view/menu/i;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final m:I = 0x30


# instance fields
.field private final a:Landroid/content/Context;

.field private final b:Landroidx/appcompat/view/menu/g;

.field private final c:Z

.field private final d:I

.field private final e:I

.field private f:Landroid/view/View;

.field private g:I

.field private h:Z

.field private i:Landroidx/appcompat/view/menu/n$a;

.field private j:Landroidx/appcompat/view/menu/l;

.field private k:Landroid/widget/PopupWindow$OnDismissListener;

.field private final l:Landroid/widget/PopupWindow$OnDismissListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x3

    move v7, v4

    move v7, v4

    const/4 v8, 0x6

    sget v5, Landroidx/appcompat/R$attr;->popupMenuStyle:I

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v6, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct/range {v0 .. v6}, Landroidx/appcompat/view/menu/m;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;ZII)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v7, 0x6

    move v8, v7

    const/4 v4, 0x0

    or-int/2addr v8, v4

    sget v5, Landroidx/appcompat/R$attr;->popupMenuStyle:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct/range {v0 .. v6}, Landroidx/appcompat/view/menu/m;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;ZII)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;ZI)V
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v6, 0x0

    shl-int/2addr v8, v6

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v4, p4

    move v4, p4

    const/4 v8, 0x2

    move v4, p4

    move v4, p4

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v5, p5

    move v5, p5

    const/4 v8, 0x6

    move v5, p5

    move v5, p5

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v6}, Landroidx/appcompat/view/menu/m;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;ZII)V

    const/4 v7, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;ZII)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p6    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    const v0, 0x800003

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Landroidx/appcompat/view/menu/m;->g:I

    const/4 v2, 0x7

    new-instance v0, Landroidx/appcompat/view/menu/m$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/m$a;-><init>(Landroidx/appcompat/view/menu/m;)V

    const/4 v1, 0x5

    move v2, v1

    iput-object v0, p0, Landroidx/appcompat/view/menu/m;->l:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/m;->a:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput-object p2, p0, Landroidx/appcompat/view/menu/m;->b:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object p3, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-boolean p4, p0, Landroidx/appcompat/view/menu/m;->c:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput p5, p0, Landroidx/appcompat/view/menu/m;->d:I

    const/4 v2, 0x6

    iput p6, p0, Landroidx/appcompat/view/menu/m;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private b()Landroidx/appcompat/view/menu/l;
    .locals 15
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const-string/jumbo v14, "oys ~/ft@@vf@~ o@@oi@~  ~ @~~d o ~~M@  ~~ @~@~@.4bl @@1tnri/Kom@~  bl@-~cos~S~ab@ ~  ~~@i~ @@u~~"

    const-string v14, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->a:Landroid/content/Context;

    const/4 v14, 0x7

    const-string/jumbo v1, "noimsw"

    const-string/jumbo v1, "wnsiow"

    const-string/jumbo v1, "wndiow"

    const-string/jumbo v1, "window"

    const/4 v14, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v14, 0x6

    check-cast v0, Landroid/view/WindowManager;

    const/4 v14, 0x2

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v14, 0x1

    new-instance v1, Landroid/graphics/Point;

    const/4 v14, 0x1

    invoke-direct {v1}, Landroid/graphics/Point;-><init>()V

    const/4 v14, 0x5

    invoke-virtual {v0, v1}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    const/4 v14, 0x4

    iget v0, v1, Landroid/graphics/Point;->x:I

    const/4 v14, 0x1

    iget v1, v1, Landroid/graphics/Point;->y:I

    const/4 v14, 0x5

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    const/4 v14, 0x1

    iget-object v1, p0, Landroidx/appcompat/view/menu/m;->a:Landroid/content/Context;

    const/4 v14, 0x0

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v14, 0x5

    sget v2, Landroidx/appcompat/R$dimen;->abc_cascading_menus_min_smallest_width:I

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v1

    const/4 v14, 0x7

    if-lt v0, v1, :cond_0

    const/4 v14, 0x5

    const/4 v0, 0x1

    const/4 v14, 0x3

    goto :goto_0

    :cond_0
    const/4 v14, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v14, 0x5

    if-eqz v0, :cond_1

    const/4 v14, 0x0

    new-instance v0, Landroidx/appcompat/view/menu/d;

    iget-object v2, p0, Landroidx/appcompat/view/menu/m;->a:Landroid/content/Context;

    iget-object v3, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v14, 0x4

    iget v4, p0, Landroidx/appcompat/view/menu/m;->d:I

    const/4 v14, 0x3

    iget v5, p0, Landroidx/appcompat/view/menu/m;->e:I

    const/4 v14, 0x4

    iget-boolean v6, p0, Landroidx/appcompat/view/menu/m;->c:Z

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v14, 0x0

    invoke-direct/range {v1 .. v6}, Landroidx/appcompat/view/menu/d;-><init>(Landroid/content/Context;Landroid/view/View;IIZ)V

    goto :goto_1

    :cond_1
    new-instance v0, Landroidx/appcompat/view/menu/r;

    const/4 v14, 0x2

    iget-object v8, p0, Landroidx/appcompat/view/menu/m;->a:Landroid/content/Context;

    const/4 v14, 0x6

    iget-object v9, p0, Landroidx/appcompat/view/menu/m;->b:Landroidx/appcompat/view/menu/g;

    const/4 v14, 0x4

    iget-object v10, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v14, 0x7

    iget v11, p0, Landroidx/appcompat/view/menu/m;->d:I

    const/4 v14, 0x0

    iget v12, p0, Landroidx/appcompat/view/menu/m;->e:I

    iget-boolean v13, p0, Landroidx/appcompat/view/menu/m;->c:Z

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    move-object v7, v0

    const/4 v14, 0x7

    invoke-direct/range {v7 .. v13}, Landroidx/appcompat/view/menu/r;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;IIZ)V

    :goto_1
    const/4 v14, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/m;->b:Landroidx/appcompat/view/menu/g;

    const/4 v14, 0x3

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/l;->n(Landroidx/appcompat/view/menu/g;)V

    const/4 v14, 0x3

    iget-object v1, p0, Landroidx/appcompat/view/menu/m;->l:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v14, 0x4

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/l;->x(Landroid/widget/PopupWindow$OnDismissListener;)V

    const/4 v14, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v14, 0x2

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/l;->s(Landroid/view/View;)V

    const/4 v14, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/m;->i:Landroidx/appcompat/view/menu/n$a;

    const/4 v14, 0x3

    invoke-interface {v0, v1}, Landroidx/appcompat/view/menu/n;->e(Landroidx/appcompat/view/menu/n$a;)V

    const/4 v14, 0x2

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/m;->h:Z

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/l;->u(Z)V

    const/4 v14, 0x7

    iget v1, p0, Landroidx/appcompat/view/menu/m;->g:I

    const/4 v14, 0x3

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/l;->v(I)V

    const/4 v14, 0x5

    return-object v0
.end method

.method private n(IIZZ)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/m;->e()Landroidx/appcompat/view/menu/l;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, p4}, Landroidx/appcompat/view/menu/l;->y(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz p3, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget p3, p0, Landroidx/appcompat/view/menu/m;->g:I

    const/4 v4, 0x3

    iget-object p4, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-static {p4}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p4

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p3, p4}, Landroidx/core/view/b0;->d(II)I

    move-result p3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    and-int/lit8 p3, p3, 0x7

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 p4, 0x5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-ne p3, p4, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p3, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    move-result p3

    const/4 v3, 0x6

    const/4 v3, 0x5

    sub-int/2addr p1, p3

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/l;->w(I)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p2}, Landroidx/appcompat/view/menu/l;->z(I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p3, p0, Landroidx/appcompat/view/menu/m;->a:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget p3, p3, Landroid/util/DisplayMetrics;->density:F

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/high16 p4, 0x42400000    # 48.0f

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    mul-float/2addr p3, p4

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/high16 p4, 0x40000000    # 2.0f

    const/4 v4, 0x1

    const/4 v3, 0x6

    div-float/2addr p3, p4

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    float-to-int p3, p3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance p4, Landroid/graphics/Rect;

    const/4 v4, 0x7

    sub-int v1, p1, p3

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    sub-int v2, p2, p3

    const/4 v3, 0x4

    move v4, v3

    add-int/2addr p1, p3

    const/4 v3, 0x4

    move v4, v3

    add-int/2addr p2, p3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p4, v1, v2, p1, p2}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, p4}, Landroidx/appcompat/view/menu/l;->t(Landroid/graphics/Rect;)V

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0}, Landroidx/appcompat/view/menu/q;->a()V

    const/4 v4, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroidx/appcompat/view/menu/n$a;)V
    .locals 3
    .param p1    # Landroidx/appcompat/view/menu/n$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/m;->i:Landroidx/appcompat/view/menu/n$a;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/n;->e(Landroidx/appcompat/view/menu/n$a;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public c()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Landroidx/appcompat/view/menu/m;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public d()Landroid/widget/ListView;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/m;->e()Landroidx/appcompat/view/menu/l;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0}, Landroidx/appcompat/view/menu/q;->p()Landroid/widget/ListView;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public dismiss()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/m;->f()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {v0}, Landroidx/appcompat/view/menu/q;->dismiss()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public e()Landroidx/appcompat/view/menu/l;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p0}, Landroidx/appcompat/view/menu/m;->b()Landroidx/appcompat/view/menu/l;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    iput-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    :cond_0
    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {v0}, Landroidx/appcompat/view/menu/q;->b()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v0, 0x0

    move v2, v0

    :goto_0
    const/4 v1, 0x0

    const/4 v1, 0x3

    return v0
.end method

.method protected g()V
    .locals 3

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->k:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {v0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public h(Landroid/view/View;)V
    .locals 2
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public i(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/m;->h:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->j:Landroidx/appcompat/view/menu/l;

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/l;->u(Z)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public j(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Landroidx/appcompat/view/menu/m;->g:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public k(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 2
    .param p1    # Landroid/widget/PopupWindow$OnDismissListener;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/appcompat/view/menu/m;->k:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v0, 0x7

    const/4 v0, 0x7

    return-void
.end method

.method public l()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/m;->o()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, " eptMbwebe  rdhhopPanapmosocuicatlten rHuu nn ou"

    const-string/jumbo v1, "ncampuobnsre rH ttaM ouch nou taniePo pupwedlehe"

    const/4 v3, 0x2

    const-string v1, " e htcudeouetl  HunM nsnnpPupaoiuoaocrr thwpbnee"

    const-string v1, "MenuPopupHelper cannot be used without an anchor"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw v0
.end method

.method public m(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/m;->p(II)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    const-string/jumbo p2, "wr liutpntunt co aah doso urupManneen ePhceboepp"

    const-string/jumbo p2, "ooMdoecrt Ppeuoe u eenonplpncnt rt hu nawbahiusa"

    const/4 v1, 0x2

    const-string/jumbo p2, "u eslho qnneoa unetd Mh Hn apwutapotcnorubrpcePe"

    const-string p2, "MenuPopupHelper cannot be used without an anchor"

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    throw p1
.end method

.method public o()Z
    .locals 5

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/m;->f()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x6

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v2

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p0, v2, v2, v2, v2}, Landroidx/appcompat/view/menu/m;->n(IIZZ)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v1
.end method

.method public p(II)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/m;->f()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/m;->f:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v1, v1}, Landroidx/appcompat/view/menu/m;->n(IIZZ)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    return v1
.end method
