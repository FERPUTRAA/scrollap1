.class Landroidx/appcompat/view/menu/d$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/appcompat/widget/w1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/view/menu/d;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/d;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public e(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
    .locals 7
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@s @M r@ @-~fo~@@@f@ @t@~s~~o@  @n@ ~~ cmdbo~io~~o~4ilKt/~.@@~@@~ o~iy / @ @l1@  ~u~S~~b~a~  b "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v6, 0x4

    const/4 v5, 0x0

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->g:Landroid/os/Handler;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v3, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ge v2, v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v4, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v4, v4, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v5, 0x5

    move v6, v5

    invoke-interface {v4, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v4, Landroidx/appcompat/view/menu/d$d;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v4, v4, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x7

    move v6, v5

    if-ne p1, v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_1

    :cond_0
    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    move v2, v3

    move v2, v3

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-ne v2, v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void

    :cond_2
    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v6, 0x6

    const/4 v5, 0x3

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-ge v2, v0, :cond_3

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v6, 0x1

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    move-object v1, v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast v1, Landroidx/appcompat/view/menu/d$d;

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v0, Landroidx/appcompat/view/menu/d$c$a;

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-direct {v0, p0, v1, p2, p1}, Landroidx/appcompat/view/menu/d$c$a;-><init>(Landroidx/appcompat/view/menu/d$c;Landroidx/appcompat/view/menu/d$d;Landroid/view/MenuItem;Landroidx/appcompat/view/menu/g;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v6, 0x5

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-long/2addr v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p2, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v6, 0x7

    const/4 v5, 0x6

    iget-object p2, p2, Landroidx/appcompat/view/menu/d;->g:Landroid/os/Handler;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p2, v0, p1, v1, v2}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;Ljava/lang/Object;J)Z

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method

.method public o(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
    .locals 2
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    iget-object p2, p0, Landroidx/appcompat/view/menu/d$c;->a:Landroidx/appcompat/view/menu/d;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    iget-object p2, p2, Landroidx/appcompat/view/menu/d;->g:Landroid/os/Handler;

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-virtual {p2, p1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method
