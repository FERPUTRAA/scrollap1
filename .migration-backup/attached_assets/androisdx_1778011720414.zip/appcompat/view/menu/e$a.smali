.class Landroidx/appcompat/view/menu/e$a;
.super Landroid/widget/BaseAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field private a:I

.field final synthetic b:Landroidx/appcompat/view/menu/e;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/e;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, -0x1

    const/4 v0, 0x2

    move v1, v0

    iput p1, p0, Landroidx/appcompat/view/menu/e$a;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/e$a;->a()V

    const/4 v0, 0x3

    shr-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method a()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "l@s@@ Mi@v@  ri~ @ ~bsbt@~~n~o/~~~~1Ko @4  @ ~-@@@@b~o o ay~@ i~ ~@~t~.lf~ @fo~c~/~~@ S u@mo@d~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v6, 0x5

    const/4 v5, 0x4

    iget-object v0, v0, Landroidx/appcompat/view/menu/e;->c:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->y()Landroidx/appcompat/view/menu/j;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, v1, Landroidx/appcompat/view/menu/e;->c:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    if-ge v3, v2, :cond_1

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-ne v4, v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput v3, p0, Landroidx/appcompat/view/menu/e$a;->a:I

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v5, 0x0

    move v6, v5

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v0, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    iput v0, p0, Landroidx/appcompat/view/menu/e$a;->a:I

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-void
.end method

.method public b(I)Landroidx/appcompat/view/menu/j;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, v0, Landroidx/appcompat/view/menu/e;->c:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v3, 0x2

    const/4 v2, 0x6

    iget v1, v1, Landroidx/appcompat/view/menu/e;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    add-int/2addr p1, v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, p0, Landroidx/appcompat/view/menu/e$a;->a:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-ltz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-lt p1, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    add-int/lit8 p1, p1, 0x1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p1
.end method

.method public getCount()I
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, v0, Landroidx/appcompat/view/menu/e;->c:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v3, 0x0

    const/4 v2, 0x4

    iget v1, v1, Landroidx/appcompat/view/menu/e;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    sub-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, p0, Landroidx/appcompat/view/menu/e$a;->a:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    if-gez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/e$a;->b(I)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public getItemId(I)J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    int-to-long v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p2, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p2, p0, Landroidx/appcompat/view/menu/e$a;->b:Landroidx/appcompat/view/menu/e;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p2, Landroidx/appcompat/view/menu/e;->b:Landroid/view/LayoutInflater;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget p2, p2, Landroidx/appcompat/view/menu/e;->g:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v1, p2, p3, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    :cond_0
    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast p3, Landroidx/appcompat/view/menu/o$a;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/e$a;->b(I)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {p3, p1, v0}, Landroidx/appcompat/view/menu/o$a;->d(Landroidx/appcompat/view/menu/j;I)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p2
.end method

.method public notifyDataSetChanged()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/e$a;->a()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-super {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
