.class public Landroidx/appcompat/view/menu/f;
.super Landroid/widget/BaseAdapter;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field a:Landroidx/appcompat/view/menu/g;

.field private b:I

.field private c:Z

.field private final d:Z

.field private final e:Landroid/view/LayoutInflater;

.field private final f:I


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/g;Landroid/view/LayoutInflater;ZI)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, -0x1

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput v0, p0, Landroidx/appcompat/view/menu/f;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    iput-boolean p3, p0, Landroidx/appcompat/view/menu/f;->d:Z

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p2, p0, Landroidx/appcompat/view/menu/f;->e:Landroid/view/LayoutInflater;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x4

    iput p4, p0, Landroidx/appcompat/view/menu/f;->f:I

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/f;->a()V

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method a()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "l sf~or~db @  o@@oo@ @ @~~ @~@@~i~~~Ml  @@ny~@ui1@t~v~4Sc.-@b~ @i  ~~  Ktm~@@@ @~ f~a/o~~/@ ~ob~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->y()Landroidx/appcompat/view/menu/j;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v1, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ge v3, v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x3

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-ne v4, v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput v3, p0, Landroidx/appcompat/view/menu/f;->b:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v0, -0x1

    const/4 v6, 0x3

    iput v0, p0, Landroidx/appcompat/view/menu/f;->b:I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-void
.end method

.method public b()Landroidx/appcompat/view/menu/g;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/f;->c:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public d(I)Landroidx/appcompat/view/menu/j;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/f;->d:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    iget v1, p0, Landroidx/appcompat/view/menu/f;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ltz v1, :cond_1

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    if-lt p1, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/lit8 p1, p1, 0x1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p1
.end method

.method public e(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/f;->c:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public getCount()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/f;->d:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, p0, Landroidx/appcompat/view/menu/f;->b:I

    if-gez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v0
.end method

.method public bridge synthetic getItem(I)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/f;->d(I)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p1
.end method

.method public getItemId(I)J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    int-to-long v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-nez p2, :cond_0

    iget-object p2, p0, Landroidx/appcompat/view/menu/f;->e:Landroid/view/LayoutInflater;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget v1, p0, Landroidx/appcompat/view/menu/f;->f:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p2, v1, p3, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p2

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/f;->d(I)Landroidx/appcompat/view/menu/j;

    move-result-object p3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p3}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result p3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    add-int/lit8 v1, p1, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    if-ltz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p0, v1}, Landroidx/appcompat/view/menu/f;->d(I)Landroidx/appcompat/view/menu/j;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    move v1, p3

    move v1, p3

    const/4 v6, 0x5

    move v1, p3

    :goto_0
    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    check-cast v2, Landroidx/appcompat/view/menu/ListMenuItemView;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Landroidx/appcompat/view/menu/f;->a:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/g;->I()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eq p3, v1, :cond_2

    const/4 v5, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    move p3, v4

    move p3, v4

    const/4 v6, 0x0

    move p3, v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    move p3, v0

    move p3, v0

    const/4 v6, 0x5

    move p3, v0

    move p3, v0

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2, p3}, Landroidx/appcompat/view/menu/ListMenuItemView;->setGroupDividerEnabled(Z)V

    move-object p3, p2

    move-object p3, p2

    move-object p3, p2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    check-cast p3, Landroidx/appcompat/view/menu/o$a;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/f;->c:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz v1, :cond_3

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v2, v4}, Landroidx/appcompat/view/menu/ListMenuItemView;->setForceShowIcon(Z)V

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/f;->d(I)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {p3, p1, v0}, Landroidx/appcompat/view/menu/o$a;->d(Landroidx/appcompat/view/menu/j;I)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-object p2
.end method

.method public notifyDataSetChanged()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/f;->a()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-super {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
