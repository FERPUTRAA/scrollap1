.class abstract Landroidx/appcompat/view/menu/c;
.super Ljava/lang/Object;


# instance fields
.field final l:Landroid/content/Context;

.field private m:Landroidx/collection/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/m<",
            "Lm/c;",
            "Landroid/view/MenuItem;",
            ">;"
        }
    .end annotation
.end field

.field private n:Landroidx/collection/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/m<",
            "Lm/d;",
            "Landroid/view/SubMenu;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/c;->l:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method final e(Landroid/view/MenuItem;)Landroid/view/MenuItem;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@s s~@ i @~l@o yt~d~ @f@  o~S~@t~@/ M~@@ ~r~  @@~@ fi @4o~ ~~l.- @~mKv  /bo1~@~@~no~~@b~~bc@u@a"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    instance-of v0, p1, Lm/c;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Lm/c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v1, Landroidx/collection/m;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1}, Landroidx/collection/m;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    check-cast p1, Landroid/view/MenuItem;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    new-instance p1, Landroidx/appcompat/view/menu/k;

    const/4 v3, 0x3

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->l:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p1, v1, v0}, Landroidx/appcompat/view/menu/k;-><init>(Landroid/content/Context;Lm/c;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v1, v0, p1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method final f(Landroid/view/SubMenu;)Landroid/view/SubMenu;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    instance-of v0, p1, Lm/d;

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    check-cast p1, Lm/d;

    const/4 v3, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/c;->n:Landroidx/collection/m;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Landroidx/collection/m;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0}, Landroidx/collection/m;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/c;->n:Landroidx/collection/m;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/c;->n:Landroidx/collection/m;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroidx/collection/m;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    check-cast v0, Landroid/view/SubMenu;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    new-instance v0, Landroidx/appcompat/view/menu/t;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->l:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, v1, p1}, Landroidx/appcompat/view/menu/t;-><init>(Landroid/content/Context;Lm/d;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->n:Landroidx/collection/m;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1, p1, v0}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p1
.end method

.method final g()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/collection/m;->clear()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/c;->n:Landroidx/collection/m;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/collection/m;->clear()V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method final h(I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1}, Landroidx/collection/m;->size()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ge v0, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Landroidx/collection/m;->i(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    check-cast v1, Lm/c;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-interface {v1}, Landroid/view/MenuItem;->getGroupId()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    if-ne v1, p1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroidx/collection/m;->n(I)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method final i(I)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroidx/collection/m;->size()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ge v0, v1, :cond_2

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Landroidx/collection/m;->i(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    check-cast v1, Lm/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {v1}, Landroid/view/MenuItem;->getItemId()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v1, p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/c;->m:Landroidx/collection/m;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroidx/collection/m;->n(I)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method
