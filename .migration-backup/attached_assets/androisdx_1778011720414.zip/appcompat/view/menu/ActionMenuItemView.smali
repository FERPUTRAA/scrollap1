.class public Landroidx/appcompat/view/menu/ActionMenuItemView;
.super Landroidx/appcompat/widget/AppCompatTextView;

# interfaces
.implements Landroidx/appcompat/view/menu/o$a;
.implements Landroid/view/View$OnClickListener;
.implements Landroidx/appcompat/widget/ActionMenuView$a;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/ActionMenuItemView$b;,
        Landroidx/appcompat/view/menu/ActionMenuItemView$a;
    }
.end annotation


# static fields
.field private static final l:Ljava/lang/String; = "ActionMenuItemView"

.field private static final m:I = 0x20


# instance fields
.field a:Landroidx/appcompat/view/menu/j;

.field private b:Ljava/lang/CharSequence;

.field private c:Landroid/graphics/drawable/Drawable;

.field d:Landroidx/appcompat/view/menu/g$b;

.field private e:Landroidx/appcompat/widget/i1;

.field f:Landroidx/appcompat/view/menu/ActionMenuItemView$b;

.field private g:Z

.field private h:Z

.field private i:I

.field private j:I

.field private k:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/view/menu/ActionMenuItemView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    invoke-direct {p0, p1, p2, v0}, Landroidx/appcompat/view/menu/ActionMenuItemView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/widget/AppCompatTextView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->i()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->g:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v1, Landroidx/appcompat/R$styleable;->ActionMenuItemView:[I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, p2, v1, p3, v2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    sget p2, Landroidx/appcompat/R$styleable;->ActionMenuItemView_android_minWidth:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p2, v2}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput p2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->i:I

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/high16 p2, 0x42000000    # 32.0f

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    mul-float/2addr p1, p2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/high16 p2, 0x3f000000    # 0.5f

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-float/2addr p1, p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    float-to-int p1, p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->k:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->j:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v2}, Landroid/view/View;->setSaveEnabled(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method private i()Z
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@s~d~@~   i~f@~sS@@~~~i@4@b@  @mo~  c~@@~@@oKy@~@-ob ~M~@~ao nl~t@/rb  ~l .v~ fuo i~~@1o/  ~@ t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget v1, v0, Landroid/content/res/Configuration;->screenWidthDp:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    iget v2, v0, Landroid/content/res/Configuration;->screenHeightDp:I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/16 v3, 0x1e0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-ge v1, v3, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/16 v4, 0x280

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-lt v1, v4, :cond_0

    const/4 v6, 0x6

    if-ge v2, v3, :cond_2

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget v0, v0, Landroid/content/res/Configuration;->orientation:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v1, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-ne v0, v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v0, 0x1

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    return v0
.end method

.method private j()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->b:Ljava/lang/CharSequence;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x0

    xor-int/2addr v0, v1

    const/4 v5, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->c:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x5

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->E()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->g:Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->h:Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    or-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v1, 0x0

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    and-int/2addr v0, v1

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->b:Ljava/lang/CharSequence;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_1

    :cond_2
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_3

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_2

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object v2

    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_3

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, v2}, Landroid/view/View;->setContentDescription(Ljava/lang/CharSequence;)V

    :goto_3
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getTooltipText()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v3, :cond_6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_4

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object v1

    :goto_4
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0, v1}, Landroidx/appcompat/widget/u2;->a(Landroid/view/View;Ljava/lang/CharSequence;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_5

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-static {p0, v2}, Landroidx/appcompat/widget/u2;->a(Landroid/view/View;Ljava/lang/CharSequence;)V

    :goto_5
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->h()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public b(ZC)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->h()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public d(Landroidx/appcompat/view/menu/j;I)V
    .locals 2

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p2}, Landroidx/appcompat/view/menu/ActionMenuItemView;->setIcon(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/j;->l(Landroidx/appcompat/view/menu/o$a;)Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Landroidx/appcompat/view/menu/ActionMenuItemView;->setTitle(Ljava/lang/CharSequence;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getItemId()I

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p2}, Landroid/view/View;->setId(I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isVisible()Z

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eqz p2, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/16 p2, 0x8

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p2}, Landroid/view/View;->setVisibility(I)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isEnabled()Z

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p2}, Landroid/view/View;->setEnabled(Z)V

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eqz p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->e:Landroidx/appcompat/widget/i1;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-nez p1, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    new-instance p1, Landroidx/appcompat/view/menu/ActionMenuItemView$a;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p1, p0}, Landroidx/appcompat/view/menu/ActionMenuItemView$a;-><init>(Landroidx/appcompat/view/menu/ActionMenuItemView;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->e:Landroidx/appcompat/widget/i1;

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public g()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public getItemData()Landroidx/appcompat/view/menu/j;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public h()Z
    .locals 3

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/widget/AppCompatTextView;->getText()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    xor-int/lit8 v0, v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public onClick(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->d:Landroidx/appcompat/view/menu/g$b;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x6

    invoke-interface {p1, v0}, Landroidx/appcompat/view/menu/g$b;->e(Landroidx/appcompat/view/menu/j;)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    invoke-super {p0, p1}, Landroid/widget/TextView;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->i()Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->g:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->j()V

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method protected onMeasure(II)V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->h()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->j:I

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ltz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-super {p0, v1, v2, v3, v4}, Landroid/widget/TextView;->setPadding(IIII)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/AppCompatTextView;->onMeasure(II)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/high16 v3, -0x80000000

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-ne v1, v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget v3, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->i:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1, v3}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->i:I

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/high16 v3, 0x40000000    # 2.0f

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eq v1, v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget v1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->i:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-lez v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ge v2, p1, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p1, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/AppCompatTextView;->onMeasure(II)V

    :cond_2
    const/4 v6, 0x5

    if-nez v0, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->c:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz p1, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object p2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->c:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p2}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p2}, Landroid/graphics/Rect;->width()I

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    sub-int/2addr p1, p2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    div-int/lit8 p1, p1, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-super {p0, p1, p2, v0, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void
.end method

.method public onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroid/widget/TextView;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->e:Landroidx/appcompat/widget/i1;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p0, p1}, Landroidx/appcompat/widget/i1;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroid/widget/TextView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    return p1
.end method

.method public setCheckable(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public setChecked(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public setExpandedFormat(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->h:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->h:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->a:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->e()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 6

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->c:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget v2, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->k:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-le v0, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    int-to-float v3, v2

    const/4 v5, 0x7

    int-to-float v0, v0

    const/4 v4, 0x7

    move v5, v4

    div-float/2addr v3, v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    int-to-float v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    mul-float/2addr v0, v3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    float-to-int v1, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x6

    move v0, v2

    move v0, v2

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x2

    if-le v1, v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    int-to-float v3, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    int-to-float v1, v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    div-float/2addr v3, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    int-to-float v0, v0

    const/4 v5, 0x4

    mul-float/2addr v0, v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    float-to-int v0, v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    const/4 v5, 0x7

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1, v1, v1, v0, v2}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    :cond_2
    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0, p1, v0, v0, v0}, Landroidx/appcompat/widget/AppCompatTextView;->setCompoundDrawables(Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->j()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method public setItemInvoker(Landroidx/appcompat/view/menu/g$b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->d:Landroidx/appcompat/view/menu/g$b;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public setPadding(IIII)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->j:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v1, 0x3

    return-void
.end method

.method public setPopupCallback(Landroidx/appcompat/view/menu/ActionMenuItemView$b;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->f:Landroidx/appcompat/view/menu/ActionMenuItemView$b;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;->b:Ljava/lang/CharSequence;

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Landroidx/appcompat/view/menu/ActionMenuItemView;->j()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method
