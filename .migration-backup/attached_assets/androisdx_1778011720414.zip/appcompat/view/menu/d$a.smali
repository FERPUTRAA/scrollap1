.class Landroidx/appcompat/view/menu/d$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/view/menu/d;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@bs ~1 ~ @i b~f@@@~~ d@~m /t~c@lK -@ a@~~@oM~@n/r o~4 f.i ~@obo ~@@~ o u@~t ~~l@@y~~is@v ~@ ~o~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/d;->b()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v3, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-lez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x1

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Landroidx/appcompat/view/menu/d$d;

    const/4 v2, 0x1

    move v3, v2

    iget-object v0, v0, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->K()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-nez v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->p:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x7

    goto :goto_1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v2, 0x6

    move v3, v2

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v2, 0x2

    move v3, v2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v1, Landroidx/appcompat/view/menu/d$d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v1, v1, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1}, Landroidx/appcompat/widget/v1;->a()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$a;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/d;->dismiss()V

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method
