.class Landroidx/appcompat/view/menu/m$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/m;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/view/menu/m;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/m;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput-object p1, p0, Landroidx/appcompat/view/menu/m$a;->a:Landroidx/appcompat/view/menu/m;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onDismiss()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "r~s oy@ Sv~c  ~@~f@md@@~ ~@~ t@@ o@  o ~t@of@@.l @@~~b@~~4o-  ~~ ~~ ~bi~i~@on@@/s/i ~KM~l@aub1@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/m$a;->a:Landroidx/appcompat/view/menu/m;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/m;->g()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
