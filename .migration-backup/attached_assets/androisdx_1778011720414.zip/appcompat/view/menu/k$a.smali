.class Landroidx/appcompat/view/menu/k$a;
.super Landroidx/core/view/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final e:Landroid/view/ActionProvider;

.field final synthetic f:Landroidx/appcompat/view/menu/k;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/k;Landroid/content/Context;Landroid/view/ActionProvider;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/k$a;->f:Landroidx/appcompat/view/menu/k;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p2}, Landroidx/core/view/b;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p3, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public b()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " csi b@~Ko~4 @v@s~ b~o@S@y@@@  @i~~i ~~f @ /@ l-M~~al o~~~ rm@~ut@ @~bf~~~oo~@ @~@  /~n@d~t1o @@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/view/ActionProvider;->hasSubMenu()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public d()Landroid/view/View;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/ActionProvider;->onCreateActionView()Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public f()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {v0}, Landroid/view/ActionProvider;->onPerformDefaultAction()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    return v0
.end method

.method public g(Landroid/view/SubMenu;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/appcompat/view/menu/k$a;->f:Landroidx/appcompat/view/menu/k;

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {v1, p1}, Landroidx/appcompat/view/menu/c;->f(Landroid/view/SubMenu;)Landroid/view/SubMenu;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Landroid/view/ActionProvider;->onPrepareSubMenu(Landroid/view/SubMenu;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method
