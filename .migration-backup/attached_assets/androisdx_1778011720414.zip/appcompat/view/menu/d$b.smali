.class Landroidx/appcompat/view/menu/d$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnAttachStateChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/view/menu/d;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/d;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/d$b;->a:Landroidx/appcompat/view/menu/d;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onViewAttachedToWindow(Landroid/view/View;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i.s 4 rc~~~ ~i@l~oo@-M @@@~@~outaf@@ @s f  o/@ @@n~ t~ ~~o~~bd@/ ~~ lv@o~@mK@y~~ @~i~@  ~1 b~@bS"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public onViewDetachedFromWindow(Landroid/view/View;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$b;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$b;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v1, v0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d$b;->a:Landroidx/appcompat/view/menu/d;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, v0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    const/4 v3, 0x3

    const/4 v2, 0x4

    iget-object v0, v0, Landroidx/appcompat/view/menu/d;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {v1, v0}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_1
    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method
