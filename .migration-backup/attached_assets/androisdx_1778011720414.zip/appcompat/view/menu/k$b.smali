.class Landroidx/appcompat/view/menu/k$b;
.super Landroidx/appcompat/view/menu/k$a;

# interfaces
.implements Landroid/view/ActionProvider$VisibilityListener;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field private g:Landroidx/core/view/b$b;

.field final synthetic h:Landroidx/appcompat/view/menu/k;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/k;Landroid/content/Context;Landroid/view/ActionProvider;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/k$b;->h:Landroidx/appcompat/view/menu/k;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/view/menu/k$a;-><init>(Landroidx/appcompat/view/menu/k;Landroid/content/Context;Landroid/view/ActionProvider;)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public c()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  s v b ~~ fb~ ~@i@M~s~ S l b1@o@i~@~m/ ~t@~l~~@o-@@ofo@o~~@~~~@~@ cr@  i  oKu@@~@t4~@@~d ~a/@yn"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v1, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/view/ActionProvider;->isVisible()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public e(Landroid/view/MenuItem;)Landroid/view/View;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/view/ActionProvider;->onCreateActionView(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object p1
.end method

.method public h()Z
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x4

    const/4 v1, 0x3

    invoke-virtual {v0}, Landroid/view/ActionProvider;->overridesItemVisibility()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public i()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/view/ActionProvider;->refreshVisibility()V

    const/4 v2, 0x6

    return-void
.end method

.method public l(Landroidx/core/view/b$b;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object p1, p0, Landroidx/appcompat/view/menu/k$b;->g:Landroidx/core/view/b$b;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$a;->e:Landroid/view/ActionProvider;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    move-object p1, p0

    move-object p1, p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/view/ActionProvider;->setVisibilityListener(Landroid/view/ActionProvider$VisibilityListener;)V

    const/4 v2, 0x4

    return-void
.end method

.method public onActionProviderVisibilityChanged(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/k$b;->g:Landroidx/core/view/b$b;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    invoke-interface {v0, p1}, Landroidx/core/view/b$b;->onActionProviderVisibilityChanged(Z)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method
