.class public final Landroidx/appcompat/view/menu/j;
.super Ljava/lang/Object;

# interfaces
.implements Lm/c;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# static fields
.field private static final Q:Ljava/lang/String; = "MenuItemImpl"

.field private static final R:I = 0x3

.field private static final S:I = 0x1

.field private static final T:I = 0x2

.field private static final U:I = 0x4

.field private static final V:I = 0x8

.field private static final W:I = 0x10

.field private static final X:I = 0x20

.field static final Y:I


# instance fields
.field private A:Ljava/lang/Runnable;

.field private B:Landroid/view/MenuItem$OnMenuItemClickListener;

.field private C:Ljava/lang/CharSequence;

.field private D:Ljava/lang/CharSequence;

.field private E:Landroid/content/res/ColorStateList;

.field private F:Landroid/graphics/PorterDuff$Mode;

.field private G:Z

.field private H:Z

.field private I:Z

.field private J:I

.field private K:I

.field private L:Landroid/view/View;

.field private M:Landroidx/core/view/b;

.field private N:Landroid/view/MenuItem$OnActionExpandListener;

.field private O:Z

.field private P:Landroid/view/ContextMenu$ContextMenuInfo;

.field private final l:I

.field private final m:I

.field private final n:I

.field private final o:I

.field private p:Ljava/lang/CharSequence;

.field private q:Ljava/lang/CharSequence;

.field private r:Landroid/content/Intent;

.field private s:C

.field private t:I

.field private u:C

.field private v:I

.field private w:Landroid/graphics/drawable/Drawable;

.field private x:I

.field y:Landroidx/appcompat/view/menu/g;

.field private z:Landroidx/appcompat/view/menu/s;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/g;IIIILjava/lang/CharSequence;I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/16 v0, 0x1000

    const/4 v3, 0x5

    const/4 v2, 0x0

    iput v0, p0, Landroidx/appcompat/view/menu/j;->t:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput v0, p0, Landroidx/appcompat/view/menu/j;->v:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v0, p0, Landroidx/appcompat/view/menu/j;->x:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v1, p0, Landroidx/appcompat/view/menu/j;->E:Landroid/content/res/ColorStateList;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Landroidx/appcompat/view/menu/j;->F:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/j;->G:Z

    const/4 v3, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/j;->H:Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/j;->I:Z

    const/4 v3, 0x6

    const/16 v1, 0x10

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/j;->O:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput p3, p0, Landroidx/appcompat/view/menu/j;->l:I

    const/4 v3, 0x7

    iput p2, p0, Landroidx/appcompat/view/menu/j;->m:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput p4, p0, Landroidx/appcompat/view/menu/j;->n:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput p5, p0, Landroidx/appcompat/view/menu/j;->o:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p6, p0, Landroidx/appcompat/view/menu/j;->p:Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput p7, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method private static f(Ljava/lang/StringBuilder;IILjava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~isd~o~@S~t~@~ 1~~@ @o  s@y/@@i i ~n b@~@~~o ~bo@ l@ v a~.t/l@ r@M c@@o ~@@@- o~4@~f~~~fK ~u@~b "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    and-int/2addr p1, p2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    if-ne p1, p2, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method private g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/j;->I:Z

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/j;->G:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/j;->H:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz v0, :cond_3

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Landroidx/core/graphics/drawable/d;->r(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/j;->G:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->E:Landroid/content/res/ColorStateList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_1
    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/j;->H:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v1, 0x3

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->F:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/j;->I:Z

    :cond_3
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p1
.end method


# virtual methods
.method public A(Landroidx/appcompat/view/menu/s;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->z:Landroidx/appcompat/view/menu/s;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/s;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method B(Z)Z
    .locals 5

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v4, 0x3

    and-int/lit8 v1, v0, -0x9

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    move p1, v2

    move p1, v2

    move p1, v2

    move p1, v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/16 p1, 0x8

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    or-int/2addr p1, v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eq v0, p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    return v2
.end method

.method public C()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->D()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method D()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->K()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->j()C

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public E()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x4

    and-int/2addr v0, v1

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public a()Landroidx/core/view/b;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget v0, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v0
.end method

.method public c(Landroidx/core/view/b;)Lm/c;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/core/view/b;->j()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Landroidx/appcompat/view/menu/j$a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/j$a;-><init>(Landroidx/appcompat/view/menu/j;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroidx/core/view/b;->l(Landroidx/core/view/b$b;)V

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public collapseActionView()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v0, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    and-int/lit8 v0, v0, 0x8

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->N:Landroid/view/MenuItem$OnActionExpandListener;

    const/4 v3, 0x6

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionCollapse(Landroid/view/MenuItem;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    return v1

    :cond_3
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    invoke-virtual {v0, p0}, Landroidx/appcompat/view/menu/g;->g(Landroidx/appcompat/view/menu/j;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return v0
.end method

.method public d()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->b()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->q()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public e()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    invoke-virtual {v0, p0}, Landroidx/appcompat/view/menu/g;->L(Landroidx/appcompat/view/menu/j;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public expandActionView()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->m()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    return v1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->N:Landroid/view/MenuItem$OnActionExpandListener;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnActionExpandListener;->onMenuItemActionExpand(Landroid/view/MenuItem;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v1

    :cond_2
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Landroidx/appcompat/view/menu/g;->n(Landroidx/appcompat/view/menu/j;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public getActionProvider()Landroid/view/ActionProvider;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "impmaiv.teu(MPserAsuioid Tnopmteret)nurotpeIsh ocCd nttss e ,"

    const-string v1, "e ssdnretAumoopieiIa.htostsuCvu prM)io,tctTP  i dnee(oertsmpn"

    const/4 v3, 0x5

    const-string/jumbo v1, "tut.os dipotvoi )ete MnaCsncsT(pmeropeg eriums odhAeo,utIitPr"

    const-string v1, "This is not supported, use MenuItemCompat.getActionProvider()"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw v0
.end method

.method public getActionView()Landroid/view/View;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Landroidx/core/view/b;->e(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getAlphabeticModifiers()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/view/menu/j;->v:I

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getAlphabeticShortcut()C
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public getContentDescription()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->C:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public getGroupId()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/view/menu/j;->m:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public getIcon()Landroid/graphics/drawable/Drawable;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->w:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Landroidx/appcompat/view/menu/j;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v0, p0, Landroidx/appcompat/view/menu/j;->x:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, p0, Landroidx/appcompat/view/menu/j;->x:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    move v3, v2

    iput v1, p0, Landroidx/appcompat/view/menu/j;->x:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Landroidx/appcompat/view/menu/j;->w:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Landroidx/appcompat/view/menu/j;->g(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_1
    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0
.end method

.method public getIconTintList()Landroid/content/res/ColorStateList;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->E:Landroid/content/res/ColorStateList;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getIconTintMode()Landroid/graphics/PorterDuff$Mode;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->F:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->r:Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x1

    return-object v0
.end method

.method public getItemId()I
    .locals 3
    .annotation runtime Landroid/view/ViewDebug$CapturedViewProperty;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/view/menu/j;->l:I

    const/4 v2, 0x4

    return v0
.end method

.method public getMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .locals 3

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->P:Landroid/view/ContextMenu$ContextMenuInfo;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public getNumericModifiers()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/view/menu/j;->t:I

    const/4 v2, 0x5

    return v0
.end method

.method public getNumericShortcut()C
    .locals 3

    const/4 v2, 0x2

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getOrder()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget v0, p0, Landroidx/appcompat/view/menu/j;->n:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getSubMenu()Landroid/view/SubMenu;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->z:Landroidx/appcompat/view/menu/s;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 3
    .annotation runtime Landroid/view/ViewDebug$CapturedViewProperty;
    .end annotation

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->p:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getTitleCondensed()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->q:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->p:Ljava/lang/CharSequence;

    :goto_0
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTooltipText()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->D:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method h()Ljava/lang/Runnable;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->A:Ljava/lang/Runnable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public hasSubMenu()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->z:Landroidx/appcompat/view/menu/s;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public i()I
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/j;->o:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public isActionViewExpanded()Z
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/j;->O:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public isCheckable()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    and-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    return v1
.end method

.method public isChecked()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    shr-int/2addr v3, v1

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    and-int/2addr v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v0
.end method

.method public isEnabled()Z
    .locals 3

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    and-int/lit8 v0, v0, 0x10

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public isVisible()Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroidx/core/view/b;->h()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v4, 0x1

    and-int/lit8 v0, v0, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroidx/core/view/b;->c()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x3

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    return v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    and-int/lit8 v0, v0, 0x8

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez v0, :cond_2

    const/4 v3, 0x0

    move v4, v3

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    move v1, v2

    move v1, v2

    const/4 v4, 0x4

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v1
.end method

.method j()C
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->J()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    const/4 v1, 0x0

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v2, 0x0

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->s:C

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method k()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->j()C

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v0, ""

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-object v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    iget-object v3, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v3}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v3}, Landroid/view/ViewConfiguration;->hasPermanentMenuKey()Z

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v3, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget v3, Landroidx/appcompat/R$string;->abc_prepend_shortcut_label:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    iget-object v3, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/g;->J()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget v3, p0, Landroidx/appcompat/view/menu/j;->v:I

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget v3, p0, Landroidx/appcompat/view/menu/j;->t:I

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    sget v4, Landroidx/appcompat/R$string;->abc_menu_meta_shortcut_label:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/high16 v5, 0x10000

    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-static {v2, v3, v5, v4}, Landroidx/appcompat/view/menu/j;->f(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v7, 0x4

    sget v4, Landroidx/appcompat/R$string;->abc_menu_ctrl_shortcut_label:I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/16 v5, 0x1000

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-static {v2, v3, v5, v4}, Landroidx/appcompat/view/menu/j;->f(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v7, 0x4

    sget v4, Landroidx/appcompat/R$string;->abc_menu_alt_shortcut_label:I

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v5, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v2, v3, v5, v4}, Landroidx/appcompat/view/menu/j;->f(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v7, 0x3

    sget v4, Landroidx/appcompat/R$string;->abc_menu_shift_shortcut_label:I

    const/4 v7, 0x2

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {v2, v3, v5, v4}, Landroidx/appcompat/view/menu/j;->f(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    sget v4, Landroidx/appcompat/R$string;->abc_menu_sym_shortcut_label:I

    const/4 v7, 0x5

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v5, 0x4

    const/4 v7, 0x3

    invoke-static {v2, v3, v5, v4}, Landroidx/appcompat/view/menu/j;->f(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget v4, Landroidx/appcompat/R$string;->abc_menu_function_shortcut_label:I

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/16 v5, 0x8

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v2, v3, v5, v4}, Landroidx/appcompat/view/menu/j;->f(Ljava/lang/StringBuilder;IILjava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eq v0, v5, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/16 v3, 0xa

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eq v0, v3, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/16 v3, 0x20

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eq v0, v3, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    goto :goto_1

    :cond_3
    const/4 v6, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget v0, Landroidx/appcompat/R$string;->abc_menu_space_shortcut_label:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_1

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$string;->abc_menu_enter_shortcut_label:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_1

    :cond_5
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    sget v0, Landroidx/appcompat/R$string;->abc_menu_delete_shortcut_label:I

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v1, v0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    return-object v0
.end method

.method l(Landroidx/appcompat/view/menu/o$a;)Ljava/lang/CharSequence;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-interface {p1}, Landroidx/appcompat/view/menu/o$a;->f()Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->getTitleCondensed()Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/j;->getTitle()Ljava/lang/CharSequence;

    move-result-object p1

    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p1
.end method

.method public m()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    and-int/lit8 v0, v0, 0x8

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Landroidx/core/view/b;->e(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public n()Z
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->B:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v5, 0x1

    const/4 v1, 0x1

    const/4 v5, 0x0

    move v4, v1

    move v4, v1

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v0, p0}, Landroid/view/MenuItem$OnMenuItemClickListener;->onMenuItemClick(Landroid/view/MenuItem;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v1

    :cond_0
    const/4 v4, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v0, p0}, Landroidx/appcompat/view/menu/g;->i(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->A:Ljava/lang/Runnable;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    return v1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->r:Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_3

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Landroidx/appcompat/view/menu/j;->r:Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v1

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v2, "IMputbmeenmI"

    const-string v2, "etpmulIInMem"

    const/4 v5, 0x4

    const-string/jumbo v2, "tIeupmuMlIen"

    const-string v2, "MenuItemImpl"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v3, "y  ntt ptileo;dntgtnhvi gn rna/Cioieaifi/ctonn "

    const-string v3, "hty/oino   gCnnfetinr/nit n nlaaeticitgot; vaid"

    const/4 v5, 0x6

    const-string v3, "Can\'t find activity to handle intent; ignoring"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v2, v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :cond_3
    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroidx/core/view/b;->f()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v1

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v0
.end method

.method public o()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/16 v1, 0x20

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    and-int/2addr v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x2

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0
.end method

.method public p()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public q()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v0, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    and-int/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return v1
.end method

.method public r(I)Lm/c;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v2, Landroid/widget/LinearLayout;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v2, v0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, p1, v2, v0}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->s(Landroid/view/View;)Lm/c;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object p0
.end method

.method public s(Landroid/view/View;)Lm/c;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->L:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/menu/j;->M:Landroidx/core/view/b;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v0, p0, Landroidx/appcompat/view/menu/j;->l:I

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-lez v0, :cond_0

    const/4 v2, 0x7

    or-int/2addr v3, v2

    invoke-virtual {p1, v0}, Landroid/view/View;->setId(I)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/g;->L(Landroidx/appcompat/view/menu/j;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-object p0
.end method

.method public setActionProvider(Landroid/view/ActionProvider;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/UnsupportedOperationException;

    const/4 v1, 0x4

    const-string v0, ")otrs(,uqpPMmc pbetnCi testumepsu.niosdoA onvseteTIit ioreadr"

    const-string/jumbo v0, "rstCobiAhu ct,nameIt. npmerds pouMvsiuTo( rPotieensi)epodtset"

    const/4 v2, 0x7

    const-string/jumbo v0, "rIsi msatcdetpuA(hvodr).so,setsrMito insCoppPm onin eu tuTtee"

    const-string v0, "This is not supported, use MenuItemCompat.setActionProvider()"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    throw p1
.end method

.method public bridge synthetic setActionView(I)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->r(I)Lm/c;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p1
.end method

.method public bridge synthetic setActionView(Landroid/view/View;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->s(Landroid/view/View;)Lm/c;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p1
.end method

.method public setAlphabeticShortcut(C)Landroid/view/MenuItem;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-ne v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object p0
.end method

.method public setAlphabeticShortcut(CI)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-ne v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/view/menu/j;->v:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-ne v0, p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput p1, p0, Landroidx/appcompat/view/menu/j;->v:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p2, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object p0
.end method

.method public setCheckable(Z)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    and-int/lit8 v1, v0, -0x2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    or-int/2addr p1, v1

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eq v0, p1, :cond_0

    const/4 v3, 0x2

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0
.end method

.method public setChecked(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    and-int/lit8 v0, v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/g;->a0(Landroid/view/MenuItem;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->v(Z)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public bridge synthetic setContentDescription(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->setContentDescription(Ljava/lang/CharSequence;)Lm/c;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p1
.end method

.method public setContentDescription(Ljava/lang/CharSequence;)Lm/c;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->C:Ljava/lang/CharSequence;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public setEnabled(Z)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    or-int/lit8 p1, p1, 0x10

    const/4 v2, 0x1

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    and-int/lit8 p1, p1, -0x11

    const/4 v2, 0x0

    const/4 v1, 0x7

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    :goto_0
    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public setIcon(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/appcompat/view/menu/j;->w:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput p1, p0, Landroidx/appcompat/view/menu/j;->x:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->I:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Landroidx/appcompat/view/menu/j;->x:I

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->w:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x2

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->I:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public setIconTintList(Landroid/content/res/ColorStateList;)Landroid/view/MenuItem;
    .locals 3
    .param p1    # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->E:Landroid/content/res/ColorStateList;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->G:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->I:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public setIconTintMode(Landroid/graphics/PorterDuff$Mode;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->F:Landroid/graphics/PorterDuff$Mode;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->H:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->I:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->r:Landroid/content/Intent;

    const/4 v1, 0x6

    return-object p0
.end method

.method public setNumericShortcut(C)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-ne v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public setNumericShortcut(CI)Landroid/view/MenuItem;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-char v0, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-ne v0, p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Landroidx/appcompat/view/menu/j;->t:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-ne v0, p2, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p2}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/j;->t:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x3

    or-int/2addr v2, v1

    const/4 p2, 0x0

    xor-int/2addr v2, p2

    const/4 v1, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public setOnActionExpandListener(Landroid/view/MenuItem$OnActionExpandListener;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->N:Landroid/view/MenuItem$OnActionExpandListener;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->B:Landroid/view/MenuItem$OnMenuItemClickListener;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method public setShortcut(CC)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p2, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public setShortcut(CCII)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->s:C

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p3}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Landroidx/appcompat/view/menu/j;->t:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p2}, Ljava/lang/Character;->toLowerCase(C)C

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-char p1, p0, Landroidx/appcompat/view/menu/j;->u:C

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-static {p4}, Landroid/view/KeyEvent;->normalizeMetaState(I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Landroidx/appcompat/view/menu/j;->v:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public setShowAsAction(I)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    and-int/lit8 v0, p1, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const-string v0, "I_Tm,ycLSe AaIun  AN_xaI__lOOYudOsvCWSOMeT N,.ROHRAuaCTE_SA_iA_SN OIWeNAAu_ FWSEm_AOVltSHHSl_CO"

    const-string v0, "TS_IHAuLn tOAIOlC_SAENA_FAN__,VWOOmWee_uACO_luex OSSI_dI R_ W_lTiaCa sSWvONcT.YaES,S uNHRAHMOyA"

    const/4 v3, 0x0

    const-string v0, "I_aHoFSOuV_S,EdtvnSNTA_RY_O.RWNSHlusOueaAMI _W_I_ACASCl OxHEcAIA WS_OO ClTAyN_r AW am,eTONieO_L"

    const-string v0, "SHOW_AS_ACTION_ALWAYS, SHOW_AS_ACTION_IF_ROOM, and SHOW_AS_ACTION_NEVER are mutually exclusive."

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/j;->K:I

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/g;->L(Landroidx/appcompat/view/menu/j;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public bridge synthetic setShowAsActionFlags(I)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->z(I)Lm/c;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p1
.end method

.method public setTitle(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p1
.end method

.method public setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->p:Ljava/lang/CharSequence;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->z:Landroidx/appcompat/view/menu/s;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/s;->setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p0
.end method

.method public setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->q:Ljava/lang/CharSequence;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x5

    move v2, v1

    return-object p0
.end method

.method public bridge synthetic setTooltipText(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->setTooltipText(Ljava/lang/CharSequence;)Lm/c;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p1
.end method

.method public setTooltipText(Ljava/lang/CharSequence;)Lm/c;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->D:Ljava/lang/CharSequence;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p0
.end method

.method public setVisible(Z)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->B(Z)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p1, p0}, Landroidx/appcompat/view/menu/g;->M(Landroidx/appcompat/view/menu/j;)V

    :cond_0
    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method public t(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/j;->O:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/j;->p:Ljava/lang/CharSequence;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public u(Ljava/lang/Runnable;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->A:Ljava/lang/Runnable;

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method v(Z)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    and-int/lit8 v1, v0, -0x3

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 p1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    move p1, v2

    move p1, v2

    const/4 v4, 0x3

    move p1, v2

    move p1, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    or-int/2addr p1, v1

    const/4 v4, 0x7

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eq v0, p1, :cond_1

    const/4 v4, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/j;->y:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, v2}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public w(Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    and-int/lit8 v0, v0, -0x5

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    or-int/2addr v2, v1

    const/4 p1, 0x4

    move v2, p1

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x5

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public x(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    or-int/lit8 p1, p1, 0x20

    const/4 v1, 0x6

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iget p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    and-int/lit8 p1, p1, -0x21

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p1, p0, Landroidx/appcompat/view/menu/j;->J:I

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method y(Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/j;->P:Landroid/view/ContextMenu$ContextMenuInfo;

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-void
.end method

.method public z(I)Lm/c;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/j;->setShowAsAction(I)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method
