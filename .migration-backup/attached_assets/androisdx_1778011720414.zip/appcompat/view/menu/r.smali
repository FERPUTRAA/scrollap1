.class final Landroidx/appcompat/view/menu/r;
.super Landroidx/appcompat/view/menu/l;

# interfaces
.implements Landroid/widget/PopupWindow$OnDismissListener;
.implements Landroid/widget/AdapterView$OnItemClickListener;
.implements Landroidx/appcompat/view/menu/n;
.implements Landroid/view/View$OnKeyListener;


# static fields
.field private static final v:I


# instance fields
.field private final b:Landroid/content/Context;

.field private final c:Landroidx/appcompat/view/menu/g;

.field private final d:Landroidx/appcompat/view/menu/f;

.field private final e:Z

.field private final f:I

.field private final g:I

.field private final h:I

.field final i:Landroidx/appcompat/widget/MenuPopupWindow;

.field final j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field private final k:Landroid/view/View$OnAttachStateChangeListener;

.field private l:Landroid/widget/PopupWindow$OnDismissListener;

.field private m:Landroid/view/View;

.field n:Landroid/view/View;

.field private o:Landroidx/appcompat/view/menu/n$a;

.field p:Landroid/view/ViewTreeObserver;

.field private q:Z

.field private r:Z

.field private s:I

.field private t:I

.field private u:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget v0, Landroidx/appcompat/R$layout;->abc_popup_menu_item_layout:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput v0, Landroidx/appcompat/view/menu/r;->v:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;IIZ)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0}, Landroidx/appcompat/view/menu/l;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance v0, Landroidx/appcompat/view/menu/r$a;

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/r$a;-><init>(Landroidx/appcompat/view/menu/r;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v0, p0, Landroidx/appcompat/view/menu/r;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v0, Landroidx/appcompat/view/menu/r$b;

    const/4 v4, 0x7

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/r$b;-><init>(Landroidx/appcompat/view/menu/r;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/r;->k:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput v0, p0, Landroidx/appcompat/view/menu/r;->t:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/r;->b:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object p2, p0, Landroidx/appcompat/view/menu/r;->c:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-boolean p6, p0, Landroidx/appcompat/view/menu/r;->e:Z

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v1, Landroidx/appcompat/view/menu/f;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget v2, Landroidx/appcompat/view/menu/r;->v:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v1, p2, v0, p6, v2}, Landroidx/appcompat/view/menu/f;-><init>(Landroidx/appcompat/view/menu/g;Landroid/view/LayoutInflater;ZI)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v1, p0, Landroidx/appcompat/view/menu/r;->d:Landroidx/appcompat/view/menu/f;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput p4, p0, Landroidx/appcompat/view/menu/r;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput p5, p0, Landroidx/appcompat/view/menu/r;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p6

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    div-int/lit8 v0, v0, 0x2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget v1, Landroidx/appcompat/R$dimen;->abc_config_prefDialogWidth:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p6, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p6

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0, p6}, Ljava/lang/Math;->max(II)I

    move-result p6

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput p6, p0, Landroidx/appcompat/view/menu/r;->f:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-object p3, p0, Landroidx/appcompat/view/menu/r;->m:Landroid/view/View;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p3, Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 p6, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p3, p1, p6, p4, p5}, Landroidx/appcompat/widget/MenuPopupWindow;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object p3, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v3, 0x6

    or-int/2addr v4, v3

    invoke-virtual {p2, p0, p1}, Landroidx/appcompat/view/menu/g;->c(Landroidx/appcompat/view/menu/n;Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void
.end method

.method private C()Z
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~~s~~Kd@  ~~~l@b~@ nstf @ 1~~/M i@ @b~vmo@o@f@@4~@~y @~i~~@c @@~@@Sou    t@l~r@~~ob~ / @a~o  oi-"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/r;->b()Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v1, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    return v1

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/r;->q:Z

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-nez v0, :cond_7

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->m:Landroid/view/View;

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    if-nez v0, :cond_1

    const/4 v7, 0x0

    move v8, v7

    goto/16 :goto_1

    :cond_1
    const/4 v7, 0x5

    const/4 v8, 0x2

    iput-object v0, p0, Landroidx/appcompat/view/menu/r;->n:Landroid/view/View;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x6

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/v1;->d0(Landroid/widget/PopupWindow$OnDismissListener;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/v1;->e0(Landroid/widget/AdapterView$OnItemClickListener;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/v1;->c0(Z)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->n:Landroid/view/View;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v3, p0, Landroidx/appcompat/view/menu/r;->p:Landroid/view/ViewTreeObserver;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-nez v3, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    move v3, v1

    move v3, v1

    const/4 v8, 0x0

    move v3, v1

    move v3, v1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_0

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    move v3, v2

    move v3, v2

    const/4 v8, 0x2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    iput-object v4, p0, Landroidx/appcompat/view/menu/r;->p:Landroid/view/ViewTreeObserver;

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v3, :cond_3

    iget-object v3, p0, Landroidx/appcompat/view/menu/r;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v7, 0x1

    or-int/2addr v8, v7

    invoke-virtual {v4, v3}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v3, p0, Landroidx/appcompat/view/menu/r;->k:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0, v3}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v3, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v3, v0}, Landroidx/appcompat/widget/v1;->R(Landroid/view/View;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget v3, p0, Landroidx/appcompat/view/menu/r;->t:I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0, v3}, Landroidx/appcompat/widget/v1;->V(I)V

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/r;->r:Z

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-nez v0, :cond_4

    const/4 v8, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->d:Landroidx/appcompat/view/menu/f;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v4, p0, Landroidx/appcompat/view/menu/r;->b:Landroid/content/Context;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget v5, p0, Landroidx/appcompat/view/menu/r;->f:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v0, v3, v4, v5}, Landroidx/appcompat/view/menu/l;->r(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    iput v0, p0, Landroidx/appcompat/view/menu/r;->s:I

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/r;->r:Z

    :cond_4
    const/4 v8, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget v4, p0, Landroidx/appcompat/view/menu/r;->s:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v0, v4}, Landroidx/appcompat/widget/v1;->T(I)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x4

    const/4 v4, 0x2

    const/4 v8, 0x7

    move v7, v4

    invoke-virtual {v0, v4}, Landroidx/appcompat/widget/v1;->Z(I)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x3

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/l;->q()Landroid/graphics/Rect;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v0, v4}, Landroidx/appcompat/widget/v1;->W(Landroid/graphics/Rect;)V

    const/4 v8, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->a()V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->p()Landroid/widget/ListView;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0, p0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-boolean v4, p0, Landroidx/appcompat/view/menu/r;->u:Z

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v4, :cond_6

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object v4, p0, Landroidx/appcompat/view/menu/r;->c:Landroidx/appcompat/view/menu/g;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/g;->A()Ljava/lang/CharSequence;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    if-eqz v4, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v4, p0, Landroidx/appcompat/view/menu/r;->b:Landroid/content/Context;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v4}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    sget v5, Landroidx/appcompat/R$layout;->abc_popup_menu_header_item_layout:I

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v4, v5, v0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x3

    check-cast v4, Landroid/widget/FrameLayout;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    const v5, 0x1020016

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v4, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    check-cast v5, Landroid/widget/TextView;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eqz v5, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v6, p0, Landroidx/appcompat/view/menu/r;->c:Landroidx/appcompat/view/menu/g;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v6}, Landroidx/appcompat/view/menu/g;->A()Ljava/lang/CharSequence;

    move-result-object v6

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v5, v6}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    :cond_5
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v4, v2}, Landroid/view/View;->setEnabled(Z)V

    const/4 v8, 0x0

    invoke-virtual {v0, v4, v3, v2}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    :cond_6
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/r;->d:Landroidx/appcompat/view/menu/f;

    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, v2}, Landroidx/appcompat/widget/v1;->n(Landroid/widget/ListAdapter;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v8, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->a()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    return v1

    :cond_7
    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    return v2
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Landroidx/appcompat/view/menu/r;->C()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v1, "sucmetdnotna rM otiSdoatac userhne  puP huwaodbnnp"

    const-string/jumbo v1, "r sndbn tcoa dntepetawhounoPhotcdsuanpeMr uuna iS "

    const/4 v3, 0x3

    const-string v1, "P ohosMneaannoduentupha wu d poeuaantornc dittc rb"

    const-string v1, "StandardMenuPopup cannot be used without an anchor"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw v0
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/r;->q:Z

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->b()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public c(Landroidx/appcompat/view/menu/g;Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->c:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/r;->dismiss()V

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->o:Landroidx/appcompat/view/menu/n$a;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/view/menu/n$a;->c(Landroidx/appcompat/view/menu/g;Z)V

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public dismiss()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/r;->b()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->dismiss()V

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public e(Landroidx/appcompat/view/menu/n$a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/r;->o:Landroidx/appcompat/view/menu/n$a;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public f(Landroid/os/Parcelable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public g(Landroidx/appcompat/view/menu/s;)Z
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->hasVisibleItems()Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-eqz v0, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v0, Landroidx/appcompat/view/menu/m;

    const/4 v9, 0x0

    and-int/2addr v10, v9

    iget-object v3, p0, Landroidx/appcompat/view/menu/r;->b:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v5, p0, Landroidx/appcompat/view/menu/r;->n:Landroid/view/View;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-boolean v6, p0, Landroidx/appcompat/view/menu/r;->e:Z

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget v7, p0, Landroidx/appcompat/view/menu/r;->g:I

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget v8, p0, Landroidx/appcompat/view/menu/r;->h:I

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-direct/range {v2 .. v8}, Landroidx/appcompat/view/menu/m;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;ZII)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v2, p0, Landroidx/appcompat/view/menu/r;->o:Landroidx/appcompat/view/menu/n$a;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/m;->a(Landroidx/appcompat/view/menu/n$a;)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {p1}, Landroidx/appcompat/view/menu/l;->A(Landroidx/appcompat/view/menu/g;)Z

    move-result v2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/m;->i(Z)V

    const/4 v9, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v2, p0, Landroidx/appcompat/view/menu/r;->l:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/m;->k(Landroid/widget/PopupWindow$OnDismissListener;)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v2, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    iput-object v2, p0, Landroidx/appcompat/view/menu/r;->l:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v10, 0x6

    iget-object v2, p0, Landroidx/appcompat/view/menu/r;->c:Landroidx/appcompat/view/menu/g;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v2, v1}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v9, 0x4

    and-int/2addr v10, v9

    iget-object v2, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v10, 0x4

    const/4 v9, 0x5

    invoke-virtual {v2}, Landroidx/appcompat/widget/v1;->d()I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v3, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v3}, Landroidx/appcompat/widget/v1;->l()I

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x7

    iget v4, p0, Landroidx/appcompat/view/menu/r;->t:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v5, p0, Landroidx/appcompat/view/menu/r;->m:Landroid/view/View;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v5}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v5

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v4, v5}, Landroid/view/Gravity;->getAbsoluteGravity(II)I

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    and-int/lit8 v4, v4, 0x7

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v5, 0x5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-ne v4, v5, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x7

    iget-object v4, p0, Landroidx/appcompat/view/menu/r;->m:Landroid/view/View;

    const/4 v10, 0x6

    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    add-int/2addr v2, v4

    :cond_0
    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v2, v3}, Landroidx/appcompat/view/menu/m;->p(II)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v0, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->o:Landroidx/appcompat/view/menu/n$a;

    const/4 v10, 0x3

    const/4 v9, 0x7

    if-eqz v0, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/n$a;->d(Landroidx/appcompat/view/menu/g;)Z

    :cond_1
    const/4 v9, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 p1, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    return p1

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    return v1
.end method

.method public i()Landroid/os/Parcelable;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public j(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/r;->r:Z

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    iget-object p1, p0, Landroidx/appcompat/view/menu/r;->d:Landroidx/appcompat/view/menu/f;

    const/4 v0, 0x0

    move v1, v0

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/f;->notifyDataSetChanged()V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public k()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public n(Landroidx/appcompat/view/menu/g;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public onDismiss()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/r;->q:Z

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->c:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->close()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->p:Landroid/view/ViewTreeObserver;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->n:Landroid/view/View;

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/r;->p:Landroid/view/ViewTreeObserver;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->p:Landroid/view/ViewTreeObserver;

    const/4 v3, 0x0

    const/4 v2, 0x5

    iget-object v1, p0, Landroidx/appcompat/view/menu/r;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/appcompat/view/menu/r;->p:Landroid/view/ViewTreeObserver;

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->n:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/appcompat/view/menu/r;->k:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {v0, v1}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->l:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 2

    const/4 v1, 0x2

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    const/4 p3, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-ne p1, p3, :cond_0

    const/4 v1, 0x6

    const/16 p1, 0x52

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-ne p2, p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/r;->dismiss()V

    const/4 v1, 0x2

    return p3

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 p1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x2

    return p1
.end method

.method public p()Landroid/widget/ListView;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->p()Landroid/widget/ListView;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method public s(Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/r;->m:Landroid/view/View;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public u(Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->d:Landroidx/appcompat/view/menu/f;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/f;->e(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public v(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p1, p0, Landroidx/appcompat/view/menu/r;->t:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public w(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/v1;->f(I)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public x(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/r;->l:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public y(Z)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/r;->u:Z

    const/4 v0, 0x5

    xor-int/2addr v1, v0

    return-void
.end method

.method public z(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/v1;->i(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method
