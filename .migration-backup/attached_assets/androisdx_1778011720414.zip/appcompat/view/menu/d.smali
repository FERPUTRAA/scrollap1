.class final Landroidx/appcompat/view/menu/d;
.super Landroidx/appcompat/view/menu/l;

# interfaces
.implements Landroidx/appcompat/view/menu/n;
.implements Landroid/view/View$OnKeyListener;
.implements Landroid/widget/PopupWindow$OnDismissListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/d$d;,
        Landroidx/appcompat/view/menu/d$e;
    }
.end annotation


# static fields
.field private static final B:I

.field static final C:I = 0x0

.field static final D:I = 0x1

.field static final E:I = 0xc8


# instance fields
.field A:Z

.field private final b:Landroid/content/Context;

.field private final c:I

.field private final d:I

.field private final e:I

.field private final f:Z

.field final g:Landroid/os/Handler;

.field private final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/appcompat/view/menu/g;",
            ">;"
        }
    .end annotation
.end field

.field final i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Landroidx/appcompat/view/menu/d$d;",
            ">;"
        }
    .end annotation
.end field

.field final j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

.field private final k:Landroid/view/View$OnAttachStateChangeListener;

.field private final l:Landroidx/appcompat/widget/w1;

.field private m:I

.field private n:I

.field private o:Landroid/view/View;

.field p:Landroid/view/View;

.field private q:I

.field private r:Z

.field private s:Z

.field private t:I

.field private u:I

.field private v:Z

.field private w:Z

.field private x:Landroidx/appcompat/view/menu/n$a;

.field y:Landroid/view/ViewTreeObserver;

.field private z:Landroid/widget/PopupWindow$OnDismissListener;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    sget v0, Landroidx/appcompat/R$layout;->abc_cascading_menu_item_layout:I

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput v0, Landroidx/appcompat/view/menu/d;->B:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/view/View;IIZ)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # I
        .annotation build Landroidx/annotation/f;
        .end annotation
    .end param
    .param p4    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Landroidx/appcompat/view/menu/l;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->h:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Landroidx/appcompat/view/menu/d$a;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/d$a;-><init>(Landroidx/appcompat/view/menu/d;)V

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    new-instance v0, Landroidx/appcompat/view/menu/d$b;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/d$b;-><init>(Landroidx/appcompat/view/menu/d;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->k:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v2, 0x2

    const/4 v1, 0x3

    new-instance v0, Landroidx/appcompat/view/menu/d$c;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Landroidx/appcompat/view/menu/d$c;-><init>(Landroidx/appcompat/view/menu/d;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->l:Landroidx/appcompat/widget/w1;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Landroidx/appcompat/view/menu/d;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput v0, p0, Landroidx/appcompat/view/menu/d;->n:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/d;->b:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object p2, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput p3, p0, Landroidx/appcompat/view/menu/d;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput p4, p0, Landroidx/appcompat/view/menu/d;->e:I

    const/4 v2, 0x5

    iput-boolean p5, p0, Landroidx/appcompat/view/menu/d;->f:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/d;->v:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0}, Landroidx/appcompat/view/menu/d;->G()I

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p2, p0, Landroidx/appcompat/view/menu/d;->q:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget p2, p2, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    div-int/lit8 p2, p2, 0x2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget p3, Landroidx/appcompat/R$dimen;->abc_config_prefDialogWidth:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1, p3}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput p1, p0, Landroidx/appcompat/view/menu/d;->c:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    new-instance p1, Landroid/os/Handler;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    iput-object p1, p0, Landroidx/appcompat/view/menu/d;->g:Landroid/os/Handler;

    const/4 v1, 0x0

    move v2, v1

    return-void
.end method

.method private C()Landroidx/appcompat/widget/MenuPopupWindow;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@ts~@@@~bl~ ~  @i@@~n~ S~M .co~ o@u a4i~o  @l~~d~~s~@ ~f@   @~/vr fo~m@ /~Kt-@y~b@~ @~1o~@i@ ob@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    new-instance v0, Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->b:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v2, p0, Landroidx/appcompat/view/menu/d;->d:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v3, p0, Landroidx/appcompat/view/menu/d;->e:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v0, v1, v4, v2, v3}, Landroidx/appcompat/widget/MenuPopupWindow;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->l:Landroidx/appcompat/widget/w1;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/MenuPopupWindow;->q0(Landroidx/appcompat/widget/w1;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/v1;->e0(Landroid/widget/AdapterView$OnItemClickListener;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/v1;->d0(Landroid/widget/PopupWindow$OnDismissListener;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/v1;->R(Landroid/view/View;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v1, p0, Landroidx/appcompat/view/menu/d;->n:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/v1;->V(I)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/v1;->c0(Z)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/v1;->Z(I)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object v0
.end method

.method private D(Landroidx/appcompat/view/menu/g;)I
    .locals 5
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ge v1, v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v2, Landroidx/appcompat/view/menu/d$d;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, v2, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    if-ne p1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 p1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    return p1
.end method

.method private E(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/g;)Landroid/view/MenuItem;
    .locals 6
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ge v1, v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p1, v1}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-interface {v2}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v2}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-ne p2, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    return-object p1
.end method

.method private F(Landroidx/appcompat/view/menu/d$d;Landroidx/appcompat/view/menu/g;)Landroid/view/View;
    .locals 9
    .param p1    # Landroidx/appcompat/view/menu/d$d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v0, p1, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v8, 0x7

    invoke-direct {p0, v0, p2}, Landroidx/appcompat/view/menu/d;->E(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/g;)Landroid/view/MenuItem;

    move-result-object p2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v0, 0x0

    const/4 v7, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez p2, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    return-object v0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/d$d;->a()Landroid/widget/ListView;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x1

    instance-of v2, v1, Landroid/widget/HeaderViewListAdapter;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v3, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    check-cast v1, Landroid/widget/HeaderViewListAdapter;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v1}, Landroid/widget/HeaderViewListAdapter;->getHeadersCount()I

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {v1}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    check-cast v1, Landroidx/appcompat/view/menu/f;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    check-cast v1, Landroidx/appcompat/view/menu/f;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    move v2, v3

    const/4 v8, 0x0

    move v2, v3

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/f;->getCount()I

    move-result v4

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v5, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    if-ge v3, v4, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1, v3}, Landroidx/appcompat/view/menu/f;->d(I)Landroidx/appcompat/view/menu/j;

    move-result-object v6

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-ne p2, v6, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    goto :goto_2

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_1

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x1

    move v3, v5

    move v3, v5

    const/4 v8, 0x7

    move v3, v5

    move v3, v5

    :goto_2
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-ne v3, v5, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-object v0

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    add-int/2addr v3, v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroid/widget/AdapterView;->getFirstVisiblePosition()I

    move-result p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    sub-int/2addr v3, p2

    const/4 v7, 0x7

    const/4 v7, 0x4

    if-ltz v3, :cond_6

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p1}, Landroid/view/ViewGroup;->getChildCount()I

    move-result p2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-lt v3, p2, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_3

    :cond_5
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p1, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    return-object p1

    :cond_6
    :goto_3
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-object v0
.end method

.method private G()I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v1
.end method

.method private H(I)I
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v2, 0x1

    or-int/2addr v7, v2

    const/4 v6, 0x6

    move v7, v6

    sub-int/2addr v1, v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    check-cast v0, Landroidx/appcompat/view/menu/d$d;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/d$d;->a()Landroid/widget/ListView;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v1, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-array v1, v1, [I

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v3, Landroid/graphics/Rect;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v3}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v4, p0, Landroidx/appcompat/view/menu/d;->p:Landroid/view/View;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Landroid/view/View;->getWindowVisibleDisplayFrame(Landroid/graphics/Rect;)V

    const/4 v7, 0x7

    iget v4, p0, Landroidx/appcompat/view/menu/d;->q:I

    const/4 v6, 0x4

    move v7, v6

    const/4 v5, 0x0

    shr-int/2addr v7, v5

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-ne v4, v2, :cond_1

    const/4 v6, 0x3

    move v7, v6

    aget v1, v1, v5

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-int/2addr v1, v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    add-int/2addr v1, p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget p1, v3, Landroid/graphics/Rect;->right:I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-le v1, p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    return v5

    :cond_0
    const/4 v6, 0x0

    move v7, v6

    return v2

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    aget v0, v1, v5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    sub-int/2addr v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-gez v0, :cond_2

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    return v2

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    return v5
.end method

.method private I(Landroidx/appcompat/view/menu/g;)V
    .locals 14
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->b:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    new-instance v1, Landroidx/appcompat/view/menu/f;

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/d;->f:Z

    sget v3, Landroidx/appcompat/view/menu/d;->B:I

    invoke-direct {v1, p1, v0, v2, v3}, Landroidx/appcompat/view/menu/f;-><init>(Landroidx/appcompat/view/menu/g;Landroid/view/LayoutInflater;ZI)V

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/d;->b()Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_0

    iget-boolean v2, p0, Landroidx/appcompat/view/menu/d;->v:Z

    if-eqz v2, :cond_0

    invoke-virtual {v1, v3}, Landroidx/appcompat/view/menu/f;->e(Z)V

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/d;->b()Z

    move-result v2

    if-eqz v2, :cond_1

    invoke-static {p1}, Landroidx/appcompat/view/menu/l;->A(Landroidx/appcompat/view/menu/g;)Z

    move-result v2

    invoke-virtual {v1, v2}, Landroidx/appcompat/view/menu/f;->e(Z)V

    :cond_1
    :goto_0
    iget-object v2, p0, Landroidx/appcompat/view/menu/d;->b:Landroid/content/Context;

    iget v4, p0, Landroidx/appcompat/view/menu/d;->c:I

    const/4 v5, 0x0

    invoke-static {v1, v5, v2, v4}, Landroidx/appcompat/view/menu/l;->r(Landroid/widget/ListAdapter;Landroid/view/ViewGroup;Landroid/content/Context;I)I

    move-result v2

    invoke-direct {p0}, Landroidx/appcompat/view/menu/d;->C()Landroidx/appcompat/widget/MenuPopupWindow;

    move-result-object v4

    invoke-virtual {v4, v1}, Landroidx/appcompat/widget/v1;->n(Landroid/widget/ListAdapter;)V

    invoke-virtual {v4, v2}, Landroidx/appcompat/widget/v1;->T(I)V

    iget v1, p0, Landroidx/appcompat/view/menu/d;->n:I

    invoke-virtual {v4, v1}, Landroidx/appcompat/widget/v1;->V(I)V

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-lez v1, :cond_2

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v6

    sub-int/2addr v6, v3

    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroidx/appcompat/view/menu/d$d;

    invoke-direct {p0, v1, p1}, Landroidx/appcompat/view/menu/d;->F(Landroidx/appcompat/view/menu/d$d;Landroidx/appcompat/view/menu/g;)Landroid/view/View;

    move-result-object v6

    goto :goto_1

    :cond_2
    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v1, v5

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    :goto_1
    const/4 v7, 0x0

    if-eqz v6, :cond_9

    invoke-virtual {v4, v7}, Landroidx/appcompat/widget/MenuPopupWindow;->r0(Z)V

    invoke-virtual {v4, v5}, Landroidx/appcompat/widget/MenuPopupWindow;->o0(Ljava/lang/Object;)V

    invoke-direct {p0, v2}, Landroidx/appcompat/view/menu/d;->H(I)I

    move-result v8

    if-ne v8, v3, :cond_3

    move v9, v3

    move v9, v3

    move v9, v3

    goto :goto_2

    :cond_3
    move v9, v7

    move v9, v7

    move v9, v7

    move v9, v7

    :goto_2
    iput v8, p0, Landroidx/appcompat/view/menu/d;->q:I

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v10, 0x1a

    const/4 v11, 0x5

    if-lt v8, v10, :cond_4

    invoke-virtual {v4, v6}, Landroidx/appcompat/widget/v1;->R(Landroid/view/View;)V

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    move v12, v8

    move v12, v8

    move v12, v8

    move v12, v8

    goto :goto_3

    :cond_4
    const/4 v8, 0x2

    new-array v10, v8, [I

    iget-object v12, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    invoke-virtual {v12, v10}, Landroid/view/View;->getLocationOnScreen([I)V

    new-array v8, v8, [I

    invoke-virtual {v6, v8}, Landroid/view/View;->getLocationOnScreen([I)V

    iget v12, p0, Landroidx/appcompat/view/menu/d;->n:I

    and-int/lit8 v12, v12, 0x7

    if-ne v12, v11, :cond_5

    aget v12, v10, v7

    iget-object v13, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    invoke-virtual {v13}, Landroid/view/View;->getWidth()I

    move-result v13

    add-int/2addr v12, v13

    aput v12, v10, v7

    aget v12, v8, v7

    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    move-result v13

    add-int/2addr v12, v13

    aput v12, v8, v7

    :cond_5
    aget v12, v8, v7

    aget v13, v10, v7

    sub-int/2addr v12, v13

    aget v8, v8, v3

    aget v10, v10, v3

    sub-int/2addr v8, v10

    :goto_3
    iget v10, p0, Landroidx/appcompat/view/menu/d;->n:I

    and-int/2addr v10, v11

    if-ne v10, v11, :cond_7

    if-eqz v9, :cond_6

    goto :goto_4

    :cond_6
    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    move-result v2

    goto :goto_5

    :cond_7
    if-eqz v9, :cond_8

    invoke-virtual {v6}, Landroid/view/View;->getWidth()I

    move-result v2

    :goto_4
    add-int/2addr v12, v2

    goto :goto_6

    :cond_8
    :goto_5
    sub-int/2addr v12, v2

    :goto_6
    invoke-virtual {v4, v12}, Landroidx/appcompat/widget/v1;->f(I)V

    invoke-virtual {v4, v3}, Landroidx/appcompat/widget/v1;->g0(Z)V

    invoke-virtual {v4, v8}, Landroidx/appcompat/widget/v1;->i(I)V

    goto :goto_7

    :cond_9
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/d;->r:Z

    if-eqz v2, :cond_a

    iget v2, p0, Landroidx/appcompat/view/menu/d;->t:I

    invoke-virtual {v4, v2}, Landroidx/appcompat/widget/v1;->f(I)V

    :cond_a
    iget-boolean v2, p0, Landroidx/appcompat/view/menu/d;->s:Z

    if-eqz v2, :cond_b

    iget v2, p0, Landroidx/appcompat/view/menu/d;->u:I

    invoke-virtual {v4, v2}, Landroidx/appcompat/widget/v1;->i(I)V

    :cond_b
    invoke-virtual {p0}, Landroidx/appcompat/view/menu/l;->q()Landroid/graphics/Rect;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroidx/appcompat/widget/v1;->W(Landroid/graphics/Rect;)V

    :goto_7
    new-instance v2, Landroidx/appcompat/view/menu/d$d;

    iget v3, p0, Landroidx/appcompat/view/menu/d;->q:I

    invoke-direct {v2, v4, p1, v3}, Landroidx/appcompat/view/menu/d$d;-><init>(Landroidx/appcompat/widget/MenuPopupWindow;Landroidx/appcompat/view/menu/g;I)V

    iget-object v3, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    invoke-interface {v3, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4}, Landroidx/appcompat/widget/v1;->a()V

    invoke-virtual {v4}, Landroidx/appcompat/widget/v1;->p()Landroid/widget/ListView;

    move-result-object v2

    invoke-virtual {v2, p0}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    if-nez v1, :cond_c

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/d;->w:Z

    if-eqz v1, :cond_c

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->A()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_c

    sget v1, Landroidx/appcompat/R$layout;->abc_popup_menu_header_item_layout:I

    invoke-virtual {v0, v1, v2, v7}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout;

    const v1, 0x1020016

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/widget/TextView;

    invoke-virtual {v0, v7}, Landroid/view/View;->setEnabled(Z)V

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->A()Ljava/lang/CharSequence;

    move-result-object p1

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {v2, v0, v5, v7}, Landroid/widget/ListView;->addHeaderView(Landroid/view/View;Ljava/lang/Object;Z)V

    invoke-virtual {v4}, Landroidx/appcompat/widget/v1;->a()V

    :cond_c
    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/d;->b()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->h:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v1, Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0, v1}, Landroidx/appcompat/view/menu/d;->I(Landroidx/appcompat/view/menu/g;)V

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->h:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->p:Landroid/view/View;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x1

    goto :goto_1

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->p:Landroid/view/View;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->k:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v1, 0x0

    or-int/2addr v3, v1

    const/4 v2, 0x2

    move v3, v2

    if-lez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Landroidx/appcompat/view/menu/d$d;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v0, v0, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->b()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x1

    :cond_0
    const/4 v2, 0x7

    const/4 v3, 0x0

    return v1
.end method

.method public c(Landroidx/appcompat/view/menu/g;Z)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/d;->D(Landroidx/appcompat/view/menu/g;)I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-gez v0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    add-int/lit8 v1, v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v2, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-ge v1, v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    check-cast v1, Landroidx/appcompat/view/menu/d$d;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, v1, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    check-cast v0, Landroidx/appcompat/view/menu/d$d;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, v0, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1, p0}, Landroidx/appcompat/view/menu/g;->S(Landroidx/appcompat/view/menu/n;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/d;->A:Z

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x3

    iget-object v1, v0, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Landroidx/appcompat/widget/MenuPopupWindow;->p0(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, v0, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v3}, Landroidx/appcompat/widget/v1;->S(I)V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, v0, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->dismiss()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-lez v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/lit8 v4, v0, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v1, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    check-cast v1, Landroidx/appcompat/view/menu/d$d;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v1, v1, Landroidx/appcompat/view/menu/d$d;->c:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput v1, p0, Landroidx/appcompat/view/menu/d;->q:I

    const/4 v6, 0x6

    goto :goto_0

    :cond_3
    const/4 v5, 0x7

    move v6, v5

    invoke-direct {p0}, Landroidx/appcompat/view/menu/d;->G()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput v1, p0, Landroidx/appcompat/view/menu/d;->q:I

    :goto_0
    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v0, :cond_7

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/d;->dismiss()V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object p2, p0, Landroidx/appcompat/view/menu/d;->x:Landroidx/appcompat/view/menu/n$a;

    const/4 v6, 0x7

    const/4 v5, 0x3

    if-eqz p2, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {p2, p1, v0}, Landroidx/appcompat/view/menu/n$a;->c(Landroidx/appcompat/view/menu/g;Z)V

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz p1, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/view/ViewTreeObserver;->isAlive()Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    if-eqz p1, :cond_5

    const/4 v6, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p2, p0, Landroidx/appcompat/view/menu/d;->j:Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Landroid/view/ViewTreeObserver;->removeGlobalOnLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-object v2, p0, Landroidx/appcompat/view/menu/d;->y:Landroid/view/ViewTreeObserver;

    :cond_6
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/d;->p:Landroid/view/View;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object p2, p0, Landroidx/appcompat/view/menu/d;->k:Landroid/view/View$OnAttachStateChangeListener;

    const/4 v5, 0x0

    and-int/2addr v6, v5

    invoke-virtual {p1, p2}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/d;->z:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {p1}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_1

    :cond_7
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz p2, :cond_8

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {p1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast p1, Landroidx/appcompat/view/menu/d$d;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object p1, p1, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p1, v3}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_8
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-void
.end method

.method public dismiss()V
    .locals 6

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x0

    if-lez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-array v2, v0, [Landroidx/appcompat/view/menu/d$d;

    const/4 v4, 0x3

    move v5, v4

    invoke-interface {v1, v2}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast v1, [Landroidx/appcompat/view/menu/d$d;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ltz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    aget-object v2, v1, v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, v2, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v3}, Landroidx/appcompat/widget/v1;->b()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v2, v2, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroidx/appcompat/widget/v1;->dismiss()V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void
.end method

.method public e(Landroidx/appcompat/view/menu/n$a;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/d;->x:Landroidx/appcompat/view/menu/n$a;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public f(Landroid/os/Parcelable;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-void
.end method

.method public g(Landroidx/appcompat/view/menu/s;)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    check-cast v1, Landroidx/appcompat/view/menu/d$d;

    const/4 v5, 0x4

    const/4 v4, 0x0

    iget-object v3, v1, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    if-ne p1, v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/d$d;->a()Landroid/widget/ListView;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    return v2

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->hasVisibleItems()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/d;->n(Landroidx/appcompat/view/menu/g;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->x:Landroidx/appcompat/view/menu/n$a;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/n$a;->d(Landroidx/appcompat/view/menu/g;)Z

    :cond_2
    const/4 v5, 0x2

    return v2

    :cond_3
    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    return p1
.end method

.method public i()Landroid/os/Parcelable;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public j(Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast v0, Landroidx/appcompat/view/menu/d$d;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/d$d;->a()Landroid/widget/ListView;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/appcompat/view/menu/l;->B(Landroid/widget/ListAdapter;)Landroidx/appcompat/view/menu/f;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->notifyDataSetChanged()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public k()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public n(Landroidx/appcompat/view/menu/g;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->b:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, p0, v0}, Landroidx/appcompat/view/menu/g;->c(Landroidx/appcompat/view/menu/n;Landroid/content/Context;)V

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/d;->b()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/d;->I(Landroidx/appcompat/view/menu/g;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->h:Ljava/util/List;

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method protected o()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    return v0
.end method

.method public onDismiss()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v5, 0x7

    move v2, v1

    move v2, v1

    const/4 v6, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-ge v2, v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    iget-object v3, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v3, Landroidx/appcompat/view/menu/d$d;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v4, v3, Landroidx/appcompat/view/menu/d$d;->a:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v4}, Landroidx/appcompat/widget/v1;->b()Z

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v4, :cond_0

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    move v6, v5

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-object v0, v3, Landroidx/appcompat/view/menu/d$d;->b:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_2
    const/4 v5, 0x3

    move v6, v5

    return-void
.end method

.method public onKey(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p3, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-ne p1, p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/16 p1, 0x52

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    if-ne p2, p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/d;->dismiss()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p3

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 p1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p1
.end method

.method public p()Landroid/widget/ListView;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->i:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/lit8 v1, v1, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast v0, Landroidx/appcompat/view/menu/d$d;

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/d$d;->a()Landroid/widget/ListView;

    move-result-object v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0
.end method

.method public s(Landroid/view/View;)V
    .locals 3
    .param p1    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/view/menu/d;->m:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroidx/core/view/b0;->d(II)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput p1, p0, Landroidx/appcompat/view/menu/d;->n:I

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public u(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/d;->v:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public v(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/view/menu/d;->m:I

    const/4 v1, 0x1

    move v2, v1

    if-eq v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput p1, p0, Landroidx/appcompat/view/menu/d;->m:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/d;->o:Landroid/view/View;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1, v0}, Landroidx/core/view/b0;->d(II)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput p1, p0, Landroidx/appcompat/view/menu/d;->n:I

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public w(I)V
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/d;->r:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput p1, p0, Landroidx/appcompat/view/menu/d;->t:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public x(Landroid/widget/PopupWindow$OnDismissListener;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/menu/d;->z:Landroid/widget/PopupWindow$OnDismissListener;

    const/4 v1, 0x6

    return-void
.end method

.method public y(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/d;->w:Z

    const/4 v1, 0x2

    return-void
.end method

.method public z(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/d;->s:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput p1, p0, Landroidx/appcompat/view/menu/d;->u:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method
