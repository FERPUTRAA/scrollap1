.class Landroidx/appcompat/view/menu/r$a;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/menu/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/view/menu/r;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/menu/r;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/r$a;->a:Landroidx/appcompat/view/menu/r;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onGlobalLayout()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@bs@@sK~~~  /~va1@@- odyoS@@nu~ @.~  i@~~   t~Mc~l~@o@m   @b ~~~~~@4o~b~ @@~lt@ @ ~r~~@@ off/@io"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/r$a;->a:Landroidx/appcompat/view/menu/r;

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/r;->b()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/r$a;->a:Landroidx/appcompat/view/menu/r;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, v0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->K()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez v0, :cond_2

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/r$a;->a:Landroidx/appcompat/view/menu/r;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, v0, Landroidx/appcompat/view/menu/r;->n:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/view/View;->isShown()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/r$a;->a:Landroidx/appcompat/view/menu/r;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, v0, Landroidx/appcompat/view/menu/r;->i:Landroidx/appcompat/widget/MenuPopupWindow;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/widget/v1;->a()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/r$a;->a:Landroidx/appcompat/view/menu/r;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/r;->dismiss()V

    :cond_2
    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method
