.class Landroidx/appcompat/view/menu/h;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnKeyListener;
.implements Landroid/content/DialogInterface$OnClickListener;
.implements Landroid/content/DialogInterface$OnDismissListener;
.implements Landroidx/appcompat/view/menu/n$a;


# instance fields
.field private a:Landroidx/appcompat/view/menu/g;

.field private b:Landroidx/appcompat/app/d;

.field c:Landroidx/appcompat/view/menu/e;

.field private d:Landroidx/appcompat/view/menu/n$a;


# direct methods
.method public constructor <init>(Landroidx/appcompat/view/menu/g;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l~sS~ ~v@fM~ ~@4oo~Ki@ o1@@~b@~~nt@~@~ ~/ ~~@@/l~~y  @~@s-ud@~c~ a~o.r@ ~io@ t@b  f i o b@@~ @@m"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->b:Landroidx/appcompat/app/d;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/app/l;->dismiss()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public b(Landroidx/appcompat/view/menu/n$a;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/view/menu/h;->d:Landroidx/appcompat/view/menu/n$a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-void
.end method

.method public c(Landroidx/appcompat/view/menu/g;Z)V
    .locals 3
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-ne p1, v0, :cond_1

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/h;->a()V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->d:Landroidx/appcompat/view/menu/n$a;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/view/menu/n$a;->c(Landroidx/appcompat/view/menu/g;Z)V

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public d(Landroidx/appcompat/view/menu/g;)Z
    .locals 3
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->d:Landroidx/appcompat/view/menu/n$a;

    const/4 v1, 0x1

    or-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-interface {v0, p1}, Landroidx/appcompat/view/menu/n$a;->d(Landroidx/appcompat/view/menu/g;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    return p1
.end method

.method public e(Landroid/os/IBinder;)V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v1, Landroidx/appcompat/app/d$a;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v1, v2}, Landroidx/appcompat/app/d$a;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance v2, Landroidx/appcompat/view/menu/e;

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroidx/appcompat/app/d$a;->b()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    sget v4, Landroidx/appcompat/R$layout;->abc_list_menu_item_layout:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v2, v3, v4}, Landroidx/appcompat/view/menu/e;-><init>(Landroid/content/Context;I)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    iput-object v2, p0, Landroidx/appcompat/view/menu/h;->c:Landroidx/appcompat/view/menu/e;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2, p0}, Landroidx/appcompat/view/menu/e;->e(Landroidx/appcompat/view/menu/n$a;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v3, p0, Landroidx/appcompat/view/menu/h;->c:Landroidx/appcompat/view/menu/e;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v2, v3}, Landroidx/appcompat/view/menu/g;->b(Landroidx/appcompat/view/menu/n;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-object v2, p0, Landroidx/appcompat/view/menu/h;->c:Landroidx/appcompat/view/menu/e;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/e;->a()Landroid/widget/ListAdapter;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1, v2, p0}, Landroidx/appcompat/app/d$a;->c(Landroid/widget/ListAdapter;Landroid/content/DialogInterface$OnClickListener;)Landroidx/appcompat/app/d$a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->B()Landroid/view/View;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v2, :cond_0

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Landroidx/appcompat/app/d$a;->f(Landroid/view/View;)Landroidx/appcompat/app/d$a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->z()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Landroidx/appcompat/app/d$a;->h(Landroid/graphics/drawable/Drawable;)Landroidx/appcompat/app/d$a;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->A()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v0}, Landroidx/appcompat/app/d$a;->K(Ljava/lang/CharSequence;)Landroidx/appcompat/app/d$a;

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1, p0}, Landroidx/appcompat/app/d$a;->A(Landroid/content/DialogInterface$OnKeyListener;)Landroidx/appcompat/app/d$a;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroidx/appcompat/app/d$a;->a()Landroidx/appcompat/app/d;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput-object v0, p0, Landroidx/appcompat/view/menu/h;->b:Landroidx/appcompat/app/d;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v0, p0}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->b:Landroidx/appcompat/app/d;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/16 v1, 0x3eb

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput v1, v0, Landroid/view/WindowManager$LayoutParams;->type:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object p1, v0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/high16 v1, 0x20000

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    or-int/2addr p1, v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput p1, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/h;->b:Landroidx/appcompat/app/d;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-void
.end method

.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->c:Landroidx/appcompat/view/menu/e;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/e;->a()Landroid/widget/ListAdapter;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-interface {v0, p2}, Landroid/widget/Adapter;->getItem(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast p2, Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, p2, v0}, Landroidx/appcompat/view/menu/g;->O(Landroid/view/MenuItem;I)Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public onDismiss(Landroid/content/DialogInterface;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/h;->c:Landroidx/appcompat/view/menu/e;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, v0, v1}, Landroidx/appcompat/view/menu/e;->c(Landroidx/appcompat/view/menu/g;Z)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public onKey(Landroid/content/DialogInterface;ILandroid/view/KeyEvent;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v0, 0x52

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eq p2, v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x4

    const/4 v3, 0x1

    if-ne p2, v0, :cond_2

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getRepeatCount()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p1, p0, Landroidx/appcompat/view/menu/h;->b:Landroidx/appcompat/app/d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    if-eqz p1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p1, p3, p0}, Landroid/view/KeyEvent$DispatcherState;->startTracking(Landroid/view/KeyEvent;Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-ne v0, v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p3}, Landroid/view/KeyEvent;->isCanceled()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/h;->b:Landroidx/appcompat/app/d;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_2

    invoke-virtual {v0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p3}, Landroid/view/KeyEvent$DispatcherState;->isTracking(Landroid/view/KeyEvent;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_2

    const/4 v2, 0x6

    const/4 v2, 0x4

    iget-object p2, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, v1}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v3, 0x6

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v1

    :cond_2
    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/menu/h;->a:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, p2, p3, v0}, Landroidx/appcompat/view/menu/g;->performShortcut(ILandroid/view/KeyEvent;I)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p1
.end method
