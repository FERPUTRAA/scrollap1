.class public Landroidx/appcompat/view/menu/g;
.super Ljava/lang/Object;

# interfaces
.implements Lm/a;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/menu/g$b;,
        Landroidx/appcompat/view/menu/g$a;
    }
.end annotation


# static fields
.field private static final L:Ljava/lang/String; = "MenuBuilder"

.field private static final M:Ljava/lang/String; = "android:menu:presenters"

.field private static final N:Ljava/lang/String; = "android:menu:actionviewstates"

.field private static final O:Ljava/lang/String; = "android:menu:expandedactionview"

.field private static final P:[I


# instance fields
.field A:Landroid/view/View;

.field private B:Z

.field private C:Z

.field private D:Z

.field private E:Z

.field private F:Z

.field private G:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation
.end field

.field private H:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList<",
            "Ljava/lang/ref/WeakReference<",
            "Landroidx/appcompat/view/menu/n;",
            ">;>;"
        }
    .end annotation
.end field

.field private I:Landroidx/appcompat/view/menu/j;

.field private J:Z

.field private K:Z

.field private final l:Landroid/content/Context;

.field private final m:Landroid/content/res/Resources;

.field private n:Z

.field private o:Z

.field private p:Landroidx/appcompat/view/menu/g$a;

.field private q:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation
.end field

.field private r:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation
.end field

.field private s:Z

.field private t:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation
.end field

.field private u:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation
.end field

.field private v:Z

.field private w:I

.field private x:Landroid/view/ContextMenu$ContextMenuInfo;

.field y:Ljava/lang/CharSequence;

.field z:Landroid/graphics/drawable/Drawable;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x6

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-array v0, v0, [I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    fill-array-data v0, :array_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object v0, Landroidx/appcompat/view/menu/g;->P:[I

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-void

    nop

    :array_0
    .array-data 4
        0x1
        0x4
        0x5
        0x3
        0x2
        0x0
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput v0, p0, Landroidx/appcompat/view/menu/g;->w:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->C:Z

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->D:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->E:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->F:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v1, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v1, p0, Landroidx/appcompat/view/menu/g;->G:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v1, Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v1, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->J:Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p1, Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->r:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->s:Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Landroidx/appcompat/view/menu/g;->t:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/appcompat/view/menu/g;->u:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->v:Z

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/g;->k0(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private static E(I)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~sub@~ot41@~i @@c~@omKyd~M@~@ aor @i@@n@/~ vof   ~t~o~~b~~.S~ ~~l~ @@~ ~ l ~/@ib @  ~@o  @f@-~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/high16 v0, -0x10000

    and-int/2addr v0, p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    shr-int/lit8 v0, v0, 0x10

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-ltz v0, :cond_0

    const/4 v4, 0x2

    sget-object v1, Landroidx/appcompat/view/menu/g;->P:[I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    array-length v2, v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-ge v0, v2, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    aget v0, v1, v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    shl-int/lit8 v0, v0, 0x10

    const/4 v4, 0x4

    const v1, 0xffff

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    and-int/2addr p0, v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    or-int/2addr p0, v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return p0

    :cond_0
    const/4 v4, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string v0, "dgdmetto ti dcoo.er nlsoavren yanicr aa "

    const-string/jumbo v0, "order does not contain a valid category."

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    throw p0
.end method

.method private R(IZ)V
    .locals 3

    const/4 v2, 0x7

    if-ltz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-lt p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p2, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 p1, 0x1

    move v2, p1

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method private d0(ILjava/lang/CharSequence;ILandroid/graphics/drawable/Drawable;Landroid/view/View;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->F()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz p5, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p5, p0, Landroidx/appcompat/view/menu/g;->A:Landroid/view/View;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v1, p0, Landroidx/appcompat/view/menu/g;->y:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v1, p0, Landroidx/appcompat/view/menu/g;->z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    goto :goto_2

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-lez p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->y:Ljava/lang/CharSequence;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p2, :cond_2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object p2, p0, Landroidx/appcompat/view/menu/g;->y:Ljava/lang/CharSequence;

    :cond_2
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-lez p3, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, p3}, Landroidx/core/content/d;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->z:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_1

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz p4, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-object p4, p0, Landroidx/appcompat/view/menu/g;->z:Landroid/graphics/drawable/Drawable;

    :cond_4
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v1, p0, Landroidx/appcompat/view/menu/g;->A:Landroid/view/View;

    :goto_2
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method private h(IIIILjava/lang/CharSequence;I)Landroidx/appcompat/view/menu/j;
    .locals 9

    new-instance v8, Landroidx/appcompat/view/menu/j;

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move v3, p2

    move v3, p2

    move v3, p2

    move v3, p2

    move v4, p3

    move v4, p3

    move v5, p4

    move v5, p4

    move v5, p4

    move v5, p4

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move-object v6, p5

    move v7, p6

    move v7, p6

    move v7, p6

    move v7, p6

    invoke-direct/range {v0 .. v7}, Landroidx/appcompat/view/menu/j;-><init>(Landroidx/appcompat/view/menu/g;IIIILjava/lang/CharSequence;I)V

    return-object v8
.end method

.method private j(Z)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->m0()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    check-cast v1, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    check-cast v2, Landroidx/appcompat/view/menu/n;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-nez v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v2, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    move v4, v3

    invoke-interface {v2, p1}, Landroidx/appcompat/view/menu/n;->j(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->l0()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method

.method private k(Landroid/os/Bundle;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v0, "pnsiosaeedm:rondrnt:ees"

    const-string/jumbo v0, "tesrerpdsondinesn:uea:m"

    const/4 v4, 0x7

    const-string v0, "apn:rbtrn:rnsdeeeeuismo"

    const-string v0, "android:menu:presenters"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz p1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast v1, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v2, Landroidx/appcompat/view/menu/n;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v2}, Landroidx/appcompat/view/menu/n;->getId()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-lez v1, :cond_1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    check-cast v1, Landroid/os/Parcelable;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {v2, v1}, Landroidx/appcompat/view/menu/n;->f(Landroid/os/Parcelable;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method private k0(Z)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget p1, p1, Landroid/content/res/Configuration;->keyboard:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eq p1, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1, v1}, Landroidx/core/view/m1;->g(Landroid/view/ViewConfiguration;Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->o:Z

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method private l(Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Landroid/util/SparseArray;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_3

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    check-cast v2, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast v3, Landroidx/appcompat/view/menu/n;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v3, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v3, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    invoke-interface {v3}, Landroidx/appcompat/view/menu/n;->getId()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-lez v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-interface {v3}, Landroidx/appcompat/view/menu/n;->i()Landroid/os/Parcelable;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v1, "dretnnuu:oesdprie:aerns"

    const-string v1, "android:menu:presenters"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method private m(Landroidx/appcompat/view/menu/s;Landroidx/appcompat/view/menu/n;)Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-interface {p2, p1}, Landroidx/appcompat/view/menu/n;->g(Landroidx/appcompat/view/menu/s;)Z

    move-result v1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object p2, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_2
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast v0, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    check-cast v2, Landroidx/appcompat/view/menu/n;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez v2, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v2, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-interface {v2, p1}, Landroidx/appcompat/view/menu/n;->g(Landroidx/appcompat/view/menu/s;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    move v1, v0

    move v1, v0

    const/4 v4, 0x1

    move v1, v0

    move v1, v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_4
    const/4 v4, 0x0

    return v1
.end method

.method private static q(Ljava/util/ArrayList;I)I
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;I)I"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ltz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v1, Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/j;->i()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-gt v1, p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0

    :cond_0
    const/4 v3, 0x7

    add-int/lit8 v0, v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    return p0
.end method


# virtual methods
.method public A()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->y:Ljava/lang/CharSequence;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public B()Landroid/view/View;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->A:Landroid/view/View;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public C()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->u()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->u:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method D()Z
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->E:Z

    const/4 v2, 0x3

    return v0
.end method

.method F()Landroid/content/res/Resources;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public G()Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method public H()Ljava/util/ArrayList;
    .locals 7
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x5

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->s:Z

    const/4 v5, 0x0

    move v6, v5

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->r:Ljava/util/ArrayList;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-object v0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->r:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v1, 0x0

    shl-int/2addr v6, v1

    const/4 v5, 0x6

    const/4 v6, 0x3

    move v2, v1

    const/4 v6, 0x0

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-ge v2, v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v3, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast v3, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x6

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/j;->isVisible()Z

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v4, p0, Landroidx/appcompat/view/menu/g;->r:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x0

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->s:Z

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->v:Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->r:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-object v0
.end method

.method public I()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->J:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method J()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->n:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public K()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->o:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method L(Landroidx/appcompat/view/menu/j;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->v:Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method M(Landroidx/appcompat/view/menu/j;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->s:Z

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public N(Z)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->s:Z

    const/4 v3, 0x3

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->v:Z

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/g;->j(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->C:Z

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->D:Z

    :cond_2
    :goto_0
    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public O(Landroid/view/MenuItem;I)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    move v1, v0

    move v1, v0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0, p2}, Landroidx/appcompat/view/menu/g;->P(Landroid/view/MenuItem;Landroidx/appcompat/view/menu/n;I)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method

.method public P(Landroid/view/MenuItem;Landroidx/appcompat/view/menu/n;I)Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz p1, :cond_9

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isEnabled()Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-nez v1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    goto/16 :goto_3

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->n()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->a()Landroidx/core/view/b;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v3, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-virtual {v2}, Landroidx/core/view/b;->b()Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v4, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    move v4, v3

    move v4, v3

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    move v4, v0

    move v4, v0

    const/4 v7, 0x2

    move v4, v0

    move v4, v0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->m()Z

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v5, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->expandActionView()Z

    move-result p1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    or-int/2addr v1, p1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz v1, :cond_8

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0, v3}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_2

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x0

    if-nez v5, :cond_4

    const/4 v7, 0x1

    if-eqz v4, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x0

    goto :goto_1

    :cond_3
    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    and-int/lit8 p1, p3, 0x1

    const/4 v7, 0x0

    if-nez p1, :cond_8

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0, v3}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    and-int/lit8 p3, p3, 0x4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-nez p3, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result p3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-nez p3, :cond_6

    new-instance p3, Landroidx/appcompat/view/menu/s;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->x()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p3, v0, p0, p1}, Landroidx/appcompat/view/menu/s;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p1, p3}, Landroidx/appcompat/view/menu/j;->A(Landroidx/appcompat/view/menu/s;)V

    :cond_6
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getSubMenu()Landroid/view/SubMenu;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast p1, Landroidx/appcompat/view/menu/s;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v4, :cond_7

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v2, p1}, Landroidx/core/view/b;->g(Landroid/view/SubMenu;)V

    :cond_7
    const/4 v7, 0x4

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/view/menu/g;->m(Landroidx/appcompat/view/menu/s;Landroidx/appcompat/view/menu/n;)Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    or-int/2addr v1, p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    if-nez v1, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0, v3}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_8
    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    return v1

    :cond_9
    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    return v0
.end method

.method public Q(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/view/menu/g;->R(IZ)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public S(Landroidx/appcompat/view/menu/n;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    check-cast v1, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    check-cast v2, Landroidx/appcompat/view/menu/n;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x6

    if-ne v2, p1, :cond_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v2, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public T(Landroid/os/Bundle;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-nez p1, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->w()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v2, 0x0

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-ge v2, v1, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0, v2}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-interface {v3}, Landroid/view/MenuItem;->getActionView()Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v4, :cond_1

    const/4 v7, 0x5

    xor-int/2addr v8, v7

    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v6, -0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eq v5, v6, :cond_1

    const/4 v7, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v4, v0}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-interface {v3}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v4

    const/4 v7, 0x0

    move v8, v7

    if-eqz v4, :cond_2

    const/4 v7, 0x3

    move v8, v7

    invoke-interface {v3}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    check-cast v3, Landroidx/appcompat/view/menu/s;

    const/4 v8, 0x7

    invoke-virtual {v3, p1}, Landroidx/appcompat/view/menu/g;->T(Landroid/os/Bundle;)V

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x0

    goto :goto_0

    :cond_3
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string v0, "aenemnvprniaiiodcwod:dumepxaend"

    const-string v0, "exnmdnaeteov:erdimipdaionanwudc"

    const/4 v8, 0x1

    const-string v0, "android:menu:expandedactionview"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p1, v0}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-lez p1, :cond_4

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz p1, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {p1}, Landroid/view/MenuItem;->expandActionView()Z

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    return-void
.end method

.method public U(Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/g;->k(Landroid/os/Bundle;)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public V(Landroid/os/Bundle;)V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    if-ge v2, v0, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p0, v2}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-interface {v3}, Landroid/view/MenuItem;->getActionView()Landroid/view/View;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz v4, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v5

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v6, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eq v5, v6, :cond_1

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-nez v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v1, Landroid/util/SparseArray;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v4, v1}, Landroid/view/View;->saveHierarchyState(Landroid/util/SparseArray;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-interface {v3}, Landroid/view/MenuItem;->isActionViewExpanded()Z

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v4, :cond_1

    const/4 v8, 0x2

    const-string/jumbo v4, "wouieneoqn:dd:otaaanvednicpreix"

    const-string v4, "adnuoprceonn:itmdeavi:ewxanedio"

    const/4 v8, 0x5

    const-string/jumbo v4, "insmecantwnapdevirdd:duxi:oaeno"

    const-string v4, "android:menu:expandedactionview"

    const/4 v8, 0x1

    invoke-interface {v3}, Landroid/view/MenuItem;->getItemId()I

    move-result v5

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p1, v4, v5}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-interface {v3}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v4, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-interface {v3}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    check-cast v3, Landroidx/appcompat/view/menu/s;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v3, p1}, Landroidx/appcompat/view/menu/g;->V(Landroid/os/Bundle;)V

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v8, 0x0

    const/4 v7, 0x6

    if-eqz v1, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->w()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V

    :cond_4
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-void
.end method

.method public W(Landroid/os/Bundle;)V
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/g;->l(Landroid/os/Bundle;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public X(Landroidx/appcompat/view/menu/g$a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->p:Landroidx/appcompat/view/menu/g$a;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public Y(Landroid/view/ContextMenu$ContextMenuInfo;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->x:Landroid/view/ContextMenu$ContextMenuInfo;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public Z(I)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput p1, p0, Landroidx/appcompat/view/menu/g;->w:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method protected a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {p3}, Landroidx/appcompat/view/menu/g;->E(I)I

    move-result v7

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget v6, p0, Landroidx/appcompat/view/menu/g;->w:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    move v1, p1

    const/4 v9, 0x4

    move v1, p1

    move v1, p1

    const/4 v9, 0x2

    move v2, p2

    move v2, p2

    const/4 v9, 0x5

    move v2, p2

    move v2, p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    move v3, p3

    move v3, p3

    const/4 v9, 0x2

    move v3, p3

    move v3, p3

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    move v4, v7

    move v4, v7

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct/range {v0 .. v6}, Landroidx/appcompat/view/menu/g;->h(IIIILjava/lang/CharSequence;I)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    iget-object p2, p0, Landroidx/appcompat/view/menu/g;->x:Landroid/view/ContextMenu$ContextMenuInfo;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz p2, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/j;->y(Landroid/view/ContextMenu$ContextMenuInfo;)V

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object p2, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p2, v7}, Landroidx/appcompat/view/menu/g;->q(Ljava/util/ArrayList;I)I

    move-result p3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p2, p3, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 p2, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p0, p2}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    return-object p1
.end method

.method a0(Landroid/view/MenuItem;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {p1}, Landroid/view/MenuItem;->getGroupId()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->m0()V

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-ge v3, v1, :cond_4

    const/4 v7, 0x4

    iget-object v4, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ne v5, v0, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->p()Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v5, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_2

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->isCheckable()Z

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-nez v5, :cond_1

    const/4 v7, 0x5

    goto :goto_2

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ne v4, p1, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v5, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_1

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    move v5, v2

    move v5, v2

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Landroidx/appcompat/view/menu/j;->v(Z)V

    :cond_3
    :goto_2
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->l0()V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-void
.end method

.method public add(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, v0, v0, v0, p1}, Landroidx/appcompat/view/menu/g;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-object p1
.end method

.method public add(IIII)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p4

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/appcompat/view/menu/g;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p1
.end method

.method public add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/appcompat/view/menu/g;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0, v0, v0, p1}, Landroidx/appcompat/view/menu/g;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1
.end method

.method public addIntentOptions(IIILandroid/content/ComponentName;[Landroid/content/Intent;Landroid/content/Intent;I[Landroid/view/MenuItem;)I
    .locals 7

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, p4, p5, p6, v1}, Landroid/content/pm/PackageManager;->queryIntentActivityOptions(Landroid/content/ComponentName;[Landroid/content/Intent;Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p4

    if-eqz p4, :cond_0

    invoke-interface {p4}, Ljava/util/List;->size()I

    move-result v2

    goto :goto_0

    :cond_0
    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    and-int/lit8 p7, p7, 0x1

    if-nez p7, :cond_1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->removeGroup(I)V

    :cond_1
    :goto_1
    if-ge v1, v2, :cond_4

    invoke-interface {p4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p7

    check-cast p7, Landroid/content/pm/ResolveInfo;

    new-instance v3, Landroid/content/Intent;

    iget v4, p7, Landroid/content/pm/ResolveInfo;->specificIndex:I

    if-gez v4, :cond_2

    move-object v4, p6

    move-object v4, p6

    move-object v4, p6

    move-object v4, p6

    goto :goto_2

    :cond_2
    aget-object v4, p5, v4

    :goto_2
    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    new-instance v4, Landroid/content/ComponentName;

    iget-object v5, p7, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v6, v5, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object v6, v6, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget-object v5, v5, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-direct {v4, v6, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    invoke-virtual {p7, v0}, Landroid/content/pm/ResolveInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {p0, p1, p2, p3, v4}, Landroidx/appcompat/view/menu/g;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v4

    invoke-virtual {p7, v0}, Landroid/content/pm/ResolveInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    invoke-interface {v4, v5}, Landroid/view/MenuItem;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    move-result-object v4

    invoke-interface {v4, v3}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;

    move-result-object v3

    if-eqz p8, :cond_3

    iget p7, p7, Landroid/content/pm/ResolveInfo;->specificIndex:I

    if-ltz p7, :cond_3

    aput-object v3, p8, p7

    :cond_3
    add-int/lit8 v1, v1, 0x1

    goto :goto_1

    :cond_4
    return v2
.end method

.method public addSubMenu(I)Landroid/view/SubMenu;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0, v0, v0, p1}, Landroidx/appcompat/view/menu/g;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p1
.end method

.method public addSubMenu(IIII)Landroid/view/SubMenu;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->m:Landroid/content/res/Resources;

    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-virtual {v0, p4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p4

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/appcompat/view/menu/g;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p1
.end method

.method public addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p2, p3, p4}, Landroidx/appcompat/view/menu/g;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p2, Landroidx/appcompat/view/menu/s;

    const/4 v1, 0x0

    const/4 v0, 0x5

    iget-object p3, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-direct {p2, p3, p0, p1}, Landroidx/appcompat/view/menu/s;-><init>(Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/j;->A(Landroidx/appcompat/view/menu/s;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-object p2
.end method

.method public addSubMenu(Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0, v0, v0, p1}, Landroidx/appcompat/view/menu/g;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p1
.end method

.method public b(Landroidx/appcompat/view/menu/n;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/view/menu/g;->c(Landroidx/appcompat/view/menu/n;Landroid/content/Context;)V

    return-void
.end method

.method protected b0(I)Landroidx/appcompat/view/menu/g;
    .locals 8

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x1

    move v6, v1

    move v6, v1

    const/4 v2, 0x0

    move v7, v2

    and-int/2addr v6, v2

    const/4 v7, 0x3

    const/4 v4, 0x0

    const/4 v7, 0x6

    const/4 v4, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    move v3, p1

    move v3, p1

    const/4 v7, 0x1

    move v3, p1

    move v3, p1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/g;->d0(ILjava/lang/CharSequence;ILandroid/graphics/drawable/Drawable;Landroid/view/View;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-object p0
.end method

.method public c(Landroidx/appcompat/view/menu/n;Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Ljava/lang/ref/WeakReference;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p1, p2, p0}, Landroidx/appcompat/view/menu/n;->m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->v:Z

    const/4 v2, 0x1

    move v3, v2

    return-void
.end method

.method protected c0(Landroid/graphics/drawable/Drawable;)Landroidx/appcompat/view/menu/g;
    .locals 8

    const/4 v7, 0x6

    const/4 v1, 0x4

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/g;->d0(ILjava/lang/CharSequence;ILandroid/graphics/drawable/Drawable;Landroid/view/View;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-object p0
.end method

.method public clear()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->I:Landroidx/appcompat/view/menu/j;

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->g(Landroidx/appcompat/view/menu/j;)Z

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public clearHeader()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/appcompat/view/menu/g;->z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Landroidx/appcompat/view/menu/g;->y:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Landroidx/appcompat/view/menu/g;->A:Landroid/view/View;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public close()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->p:Landroidx/appcompat/view/menu/g$a;

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p0}, Landroidx/appcompat/view/menu/g$a;->b(Landroidx/appcompat/view/menu/g;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->clear()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->clearHeader()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->clear()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->C:Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    iput-boolean v1, p0, Landroidx/appcompat/view/menu/g;->D:Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method protected e0(I)Landroidx/appcompat/view/menu/g;
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v5, 0x0

    move v7, v5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    move v1, p1

    move v1, p1

    const/4 v7, 0x5

    move v1, p1

    move v1, p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/g;->d0(ILjava/lang/CharSequence;ILandroid/graphics/drawable/Drawable;Landroid/view/View;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    return-object p0
.end method

.method public final f(Z)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->F:Z

    const/4 v3, 0x4

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->F:Z

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    or-int/2addr v4, v3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v1, Ljava/lang/ref/WeakReference;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast v2, Landroidx/appcompat/view/menu/n;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez v2, :cond_1

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v2, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v2, p0, p1}, Landroidx/appcompat/view/menu/n;->c(Landroidx/appcompat/view/menu/g;Z)V

    const/4 v4, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->F:Z

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method

.method protected f0(Ljava/lang/CharSequence;)Landroidx/appcompat/view/menu/g;
    .locals 8

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v7, 0x1

    move v6, v1

    move v6, v1

    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v7, 0x5

    shr-int/2addr v6, v3

    const/4 v7, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x3

    or-int/2addr v6, v4

    const/4 v7, 0x0

    const/4 v5, 0x7

    const/4 v7, 0x5

    const/4 v5, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/g;->d0(ILjava/lang/CharSequence;ILandroid/graphics/drawable/Drawable;Landroid/view/View;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-object p0
.end method

.method public findItem(I)Landroid/view/MenuItem;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-ge v1, v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    check-cast v2, Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getItemId()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ne v3, p1, :cond_0

    const/4 v4, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object v2

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v2, p1}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object v2

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    move v5, v4

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object p1
.end method

.method public g(Landroidx/appcompat/view/menu/j;)Z
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v1, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez v0, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->I:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x1

    if-eq v0, p1, :cond_0

    const/4 v4, 0x0

    move v5, v4

    goto :goto_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->m0()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v2, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast v3, Landroidx/appcompat/view/menu/n;

    const/4 v4, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v3, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-interface {v3, p0, p1}, Landroidx/appcompat/view/menu/n;->l(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->l0()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v1, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 p1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->I:Landroidx/appcompat/view/menu/j;

    :cond_4
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    return v1
.end method

.method protected g0(Landroid/view/View;)Landroidx/appcompat/view/menu/g;
    .locals 8

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v4, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v5, p1

    move-object v5, p1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/view/menu/g;->d0(ILjava/lang/CharSequence;ILandroid/graphics/drawable/Drawable;Landroid/view/View;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-object p0
.end method

.method public getItem(I)Landroid/view/MenuItem;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p1, Landroid/view/MenuItem;

    const/4 v1, 0x3

    const/4 v1, 0x6

    return-object p1
.end method

.method public h0(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->E:Z

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public hasVisibleItems()Z
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->K:Z

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x7

    move v5, v1

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    return v1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    move v3, v2

    move v3, v2

    const/4 v6, 0x3

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ge v3, v0, :cond_2

    const/4 v6, 0x6

    iget-object v4, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v6, 0x1

    invoke-virtual {v4, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->isVisible()Z

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v4, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    return v1

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_2
    const/4 v6, 0x7

    return v2
.end method

.method i(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)Z
    .locals 3
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->p:Landroidx/appcompat/view/menu/g$a;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/view/menu/g$a;->a(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p1
.end method

.method public i0(Z)V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->K:Z

    const/4 v1, 0x1

    return-void
.end method

.method public isShortcutKey(ILandroid/view/KeyEvent;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/g;->s(ILandroid/view/KeyEvent;)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p1
.end method

.method public j0(Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->o:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    if-ne v0, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Landroidx/appcompat/view/menu/g;->k0(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method public l0()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/g;->C:Z

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->C:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->D:Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_0
    return-void
.end method

.method public m0()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->B:Z

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->C:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/view/menu/g;->D:Z

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public n(Landroidx/appcompat/view/menu/j;)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    return v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->m0()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast v2, Ljava/lang/ref/WeakReference;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast v3, Landroidx/appcompat/view/menu/n;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v3, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v3, v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v3, p0, p1}, Landroidx/appcompat/view/menu/n;->d(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->l0()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    if-eqz v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object p1, p0, Landroidx/appcompat/view/menu/g;->I:Landroidx/appcompat/view/menu/j;

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v1
.end method

.method public o(I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/view/menu/g;->p(II)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method

.method public p(II)I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-gez p2, :cond_0

    const/4 v2, 0x0

    move v3, v2

    const/4 p2, 0x0

    :cond_0
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ge p2, v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v1, Landroidx/appcompat/view/menu/j;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v1, p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p2

    :cond_1
    const/4 v2, 0x1

    const/4 v3, 0x5

    add-int/lit8 p2, p2, 0x1

    const/4 v2, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return p1
.end method

.method public performIdentifierAction(II)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/g;->O(Landroid/view/MenuItem;I)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return p1
.end method

.method public performShortcut(ILandroid/view/KeyEvent;I)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/view/menu/g;->s(ILandroid/view/KeyEvent;)Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p0, p1, p3}, Landroidx/appcompat/view/menu/g;->O(Landroid/view/MenuItem;I)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 p1, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x3

    and-int/lit8 p2, p3, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    if-eqz p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p2, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1
.end method

.method public r(I)I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-ge v1, v0, :cond_1

    const/4 v3, 0x2

    move v4, v3

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    check-cast v2, Landroidx/appcompat/view/menu/j;

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getItemId()I

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne v2, p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p1, -0x1

    const/4 v4, 0x4

    return p1
.end method

.method public removeGroup(I)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->o(I)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ltz v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    sub-int/2addr v1, v0

    const/4 v5, 0x4

    shl-int/2addr v6, v5

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    const/4 v6, 0x6

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    add-int/lit8 v4, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ge v3, v1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v3, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v3, Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-ne v3, p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {p0, v0, v2}, Landroidx/appcompat/view/menu/g;->R(IZ)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    move v3, v4

    move v3, v4

    const/4 v6, 0x2

    move v3, v4

    move v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 p1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method

.method public removeItem(I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->r(I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/view/menu/g;->R(IZ)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method s(ILandroid/view/KeyEvent;)Landroidx/appcompat/view/menu/j;
    .locals 13

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->G:Ljava/util/ArrayList;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {p0, v0, p1, p2}, Landroidx/appcompat/view/menu/g;->t(Ljava/util/List;ILandroid/view/KeyEvent;)V

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    const/4 v2, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-eqz v1, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    return-object v2

    :cond_0
    const/4 v11, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {p2}, Landroid/view/KeyEvent;->getMetaState()I

    move-result v1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x5

    new-instance v3, Landroid/view/KeyCharacterMap$KeyData;

    const/4 v11, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {v3}, Landroid/view/KeyCharacterMap$KeyData;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {p2, v3}, Landroid/view/KeyEvent;->getKeyData(Landroid/view/KeyCharacterMap$KeyData;)Z

    const/4 v12, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    const/4 v4, 0x1

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-ne p2, v4, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    return-object p1

    :cond_1
    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->J()Z

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x2

    move v6, v5

    move v6, v5

    const/4 v12, 0x6

    move v6, v5

    move v6, v5

    :goto_0
    const/4 v11, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-ge v6, p2, :cond_7

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    check-cast v7, Landroidx/appcompat/view/menu/j;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    if-eqz v4, :cond_2

    const/4 v12, 0x0

    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getAlphabeticShortcut()C

    move-result v8

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    goto :goto_1

    :cond_2
    const/4 v12, 0x4

    const/4 v11, 0x0

    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getNumericShortcut()C

    move-result v8

    :goto_1
    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-object v9, v3, Landroid/view/KeyCharacterMap$KeyData;->meta:[C

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    aget-char v10, v9, v5

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-ne v8, v10, :cond_3

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x7

    and-int/lit8 v10, v1, 0x2

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-eqz v10, :cond_5

    :cond_3
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    const/4 v10, 0x2

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    aget-char v9, v9, v10

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    if-ne v8, v9, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    and-int/lit8 v9, v1, 0x2

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-nez v9, :cond_5

    :cond_4
    const/4 v12, 0x3

    if-eqz v4, :cond_6

    const/4 v11, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x3

    const/16 v9, 0x8

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-ne v8, v9, :cond_6

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    const/16 v8, 0x43

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    if-ne p1, v8, :cond_6

    :cond_5
    const/4 v12, 0x0

    const/4 v11, 0x7

    return-object v7

    :cond_6
    const/4 v12, 0x1

    const/4 v11, 0x7

    add-int/lit8 v6, v6, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x3

    goto :goto_0

    :cond_7
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    return-object v2
.end method

.method public setGroupCheckable(IZZ)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-ge v1, v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    check-cast v2, Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-ne v3, p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v2, p3}, Landroidx/appcompat/view/menu/j;->w(Z)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, p2}, Landroidx/appcompat/view/menu/j;->setCheckable(Z)Landroid/view/MenuItem;

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method public setGroupDividerEnabled(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->J:Z

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method public setGroupEnabled(IZ)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ge v1, v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v2, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    check-cast v2, Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne v3, p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2, p2}, Landroidx/appcompat/view/menu/j;->setEnabled(Z)Landroid/view/MenuItem;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void
.end method

.method public setGroupVisible(IZ)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    move v2, v1

    move v2, v1

    const/4 v7, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ge v1, v0, :cond_1

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v4, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v4, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-ne v5, p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, p2}, Landroidx/appcompat/view/menu/j;->B(Z)Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    if-eqz v4, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    move v2, v3

    move v2, v3

    const/4 v7, 0x6

    move v2, v3

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-eqz v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0, v3}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-void
.end method

.method public setQwertyMode(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/view/menu/g;->n:Z

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/view/menu/g;->N(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    return-void
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method t(Ljava/util/List;ILandroid/view/KeyEvent;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroidx/appcompat/view/menu/j;",
            ">;I",
            "Landroid/view/KeyEvent;",
            ")V"
        }
    .end annotation

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->J()Z

    move-result v0

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getModifiers()I

    move-result v1

    new-instance v2, Landroid/view/KeyCharacterMap$KeyData;

    invoke-direct {v2}, Landroid/view/KeyCharacterMap$KeyData;-><init>()V

    invoke-virtual {p3, v2}, Landroid/view/KeyEvent;->getKeyData(Landroid/view/KeyCharacterMap$KeyData;)Z

    move-result v3

    const/16 v4, 0x43

    if-nez v3, :cond_0

    if-eq p2, v4, :cond_0

    return-void

    :cond_0
    iget-object v3, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v5, 0x0

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    :goto_0
    if-ge v6, v3, :cond_7

    iget-object v7, p0, Landroidx/appcompat/view/menu/g;->q:Ljava/util/ArrayList;

    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Landroidx/appcompat/view/menu/j;

    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result v8

    if-eqz v8, :cond_1

    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v8

    check-cast v8, Landroidx/appcompat/view/menu/g;

    invoke-virtual {v8, p1, p2, p3}, Landroidx/appcompat/view/menu/g;->t(Ljava/util/List;ILandroid/view/KeyEvent;)V

    :cond_1
    if-eqz v0, :cond_2

    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getAlphabeticShortcut()C

    move-result v8

    goto :goto_1

    :cond_2
    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getNumericShortcut()C

    move-result v8

    :goto_1
    if-eqz v0, :cond_3

    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getAlphabeticModifiers()I

    move-result v9

    goto :goto_2

    :cond_3
    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->getNumericModifiers()I

    move-result v9

    :goto_2
    const v10, 0x1100f

    and-int v11, v1, v10

    and-int/2addr v9, v10

    if-ne v11, v9, :cond_4

    const/4 v9, 0x1

    goto :goto_3

    :cond_4
    move v9, v5

    move v9, v5

    move v9, v5

    move v9, v5

    :goto_3
    if-eqz v9, :cond_6

    if-eqz v8, :cond_6

    iget-object v9, v2, Landroid/view/KeyCharacterMap$KeyData;->meta:[C

    aget-char v10, v9, v5

    if-eq v8, v10, :cond_5

    const/4 v10, 0x2

    aget-char v9, v9, v10

    if-eq v8, v9, :cond_5

    if-eqz v0, :cond_6

    const/16 v9, 0x8

    if-ne v8, v9, :cond_6

    if-ne p2, v4, :cond_6

    :cond_5
    invoke-virtual {v7}, Landroidx/appcompat/view/menu/j;->isEnabled()Z

    move-result v8

    if-eqz v8, :cond_6

    invoke-interface {p1, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_6
    add-int/lit8 v6, v6, 0x1

    goto :goto_0

    :cond_7
    return-void
.end method

.method public u()V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    iget-boolean v1, p0, Landroidx/appcompat/view/menu/g;->v:Z

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x6

    and-int/2addr v7, v6

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast v4, Ljava/lang/ref/WeakReference;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    check-cast v5, Landroidx/appcompat/view/menu/n;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-nez v5, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v5, p0, Landroidx/appcompat/view/menu/g;->H:Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v5, v4}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-interface {v5}, Landroidx/appcompat/view/menu/n;->k()Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    or-int/2addr v3, v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v3, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->t:Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/g;->u:Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x2

    move v3, v2

    move v3, v2

    const/4 v7, 0x3

    move v3, v2

    move v3, v2

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    if-ge v3, v1, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    check-cast v4, Landroidx/appcompat/view/menu/j;

    const/4 v6, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v4}, Landroidx/appcompat/view/menu/j;->o()Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v5, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v5, p0, Landroidx/appcompat/view/menu/g;->t:Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x5

    const/4 v6, 0x5

    goto :goto_2

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v5, p0, Landroidx/appcompat/view/menu/g;->u:Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_2
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_1

    :cond_4
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->t:Ljava/util/ArrayList;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->u:Ljava/util/ArrayList;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->u:Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_5
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-boolean v2, p0, Landroidx/appcompat/view/menu/g;->v:Z

    return-void
.end method

.method public v()Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList<",
            "Landroidx/appcompat/view/menu/j;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/view/menu/g;->u()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->t:Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method protected w()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const-string/jumbo v0, "weimebaasodtrcnnnutmsio:itae:"

    const-string/jumbo v0, "tws:cbrnnuttdia:ieeonsiaoedam"

    const-string/jumbo v0, "weddoavitienrsa:nt:nueotaisom"

    const-string v0, "android:menu:actionviewstates"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public x()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->l:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public y()Landroidx/appcompat/view/menu/j;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->I:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public z()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/menu/g;->z:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method
