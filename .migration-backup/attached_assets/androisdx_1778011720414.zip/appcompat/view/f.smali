.class public Landroidx/appcompat/view/f;
.super Landroid/view/ActionMode;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/view/f$a;
    }
.end annotation


# instance fields
.field final a:Landroid/content/Context;

.field final b:Landroidx/appcompat/view/b;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroidx/appcompat/view/b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Landroid/view/ActionMode;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/f;->a:Landroid/content/Context;

    const/4 v0, 0x3

    move v1, v0

    iput-object p2, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public finish()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s @uot@r t~~@i@@o fof ~.@~Siy ~@  ~~ ~@@ @~~bboi@~@/@ ~/ 1 Klm @~s-~~o~o~n@@~v@@~b@  4~cd~~al "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->c()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public getCustomView()Landroid/view/View;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->d()Landroid/view/View;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v0, Landroidx/appcompat/view/menu/p;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Landroidx/appcompat/view/f;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v2}, Landroidx/appcompat/view/b;->e()Landroid/view/Menu;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    check-cast v2, Lm/a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v1, v2}, Landroidx/appcompat/view/menu/p;-><init>(Landroid/content/Context;Lm/a;)V

    const/4 v4, 0x3

    return-object v0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->f()Landroid/view/MenuInflater;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public getSubtitle()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->g()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public getTag()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->h()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->i()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object v0
.end method

.method public getTitleOptionalHint()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->j()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public invalidate()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->k()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public isTitleOptional()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/b;->l()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public setCustomView(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->n(Landroid/view/View;)V

    const/4 v2, 0x1

    return-void
.end method

.method public setSubtitle(I)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->o(I)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public setSubtitle(Ljava/lang/CharSequence;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->p(Ljava/lang/CharSequence;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public setTag(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->q(Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setTitle(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->r(I)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public setTitle(Ljava/lang/CharSequence;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->s(Ljava/lang/CharSequence;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public setTitleOptionalHint(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/view/f;->b:Landroidx/appcompat/view/b;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/b;->t(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method
