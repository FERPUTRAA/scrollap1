.class Landroidx/appcompat/view/h$a;
.super Landroidx/core/view/u1;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/view/h;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field private a:Z

.field private b:I

.field final synthetic c:Landroidx/appcompat/view/h;


# direct methods
.method constructor <init>(Landroidx/appcompat/view/h;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/view/h$a;->c:Landroidx/appcompat/view/h;

    invoke-direct {p0}, Landroidx/core/view/u1;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/view/h$a;->a:Z

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Landroidx/appcompat/view/h$a;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public b(Landroid/view/View;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@osf@ ~t foyMc @b@S @~@~ i4~/~~~o~  o ~@~~@o@ ~n- a~ @@u~~~~m~~   @@ ~dib@@v@l.l@t@@1io/K~@brs  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget p1, p0, Landroidx/appcompat/view/h$a;->b:I

    const/4 v2, 0x3

    add-int/lit8 p1, p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput p1, p0, Landroidx/appcompat/view/h$a;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/h$a;->c:Landroidx/appcompat/view/h;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, v0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-ne p1, v0, :cond_1

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/view/h$a;->c:Landroidx/appcompat/view/h;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object p1, p1, Landroidx/appcompat/view/h;->d:Landroidx/core/view/t1;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    shr-int/2addr v1, v0

    const/4 v2, 0x1

    invoke-interface {p1, v0}, Landroidx/core/view/t1;->b(Landroid/view/View;)V

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/view/h$a;->d()V

    :cond_1
    const/4 v2, 0x0

    return-void
.end method

.method public c(Landroid/view/View;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-boolean p1, p0, Landroidx/appcompat/view/h$a;->a:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/view/h$a;->a:Z

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/h$a;->c:Landroidx/appcompat/view/h;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p1, Landroidx/appcompat/view/h;->d:Landroidx/core/view/t1;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    invoke-interface {p1, v0}, Landroidx/core/view/t1;->c(Landroid/view/View;)V

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method d()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput v0, p0, Landroidx/appcompat/view/h$a;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/view/h$a;->a:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/h$a;->c:Landroidx/appcompat/view/h;

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/view/h;->b()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method
