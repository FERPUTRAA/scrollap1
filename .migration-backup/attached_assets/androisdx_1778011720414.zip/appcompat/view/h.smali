.class public Landroidx/appcompat/view/h;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation


# instance fields
.field final a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroidx/core/view/s1;",
            ">;"
        }
    .end annotation
.end field

.field private b:J

.field private c:Landroid/view/animation/Interpolator;

.field d:Landroidx/core/view/t1;

.field private e:Z

.field private final f:Landroidx/core/view/u1;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-wide v0, p0, Landroidx/appcompat/view/h;->b:J

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Landroidx/appcompat/view/h$a;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Landroidx/appcompat/view/h$a;-><init>(Landroidx/appcompat/view/h;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Landroidx/appcompat/view/h;->f:Landroidx/core/view/u1;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~/s  ~~bib.o@~ M~S~/if~@ vr@~ ~t @~-@@m ~@l~@ @o Ko 4yi@@ut~nlf@@@a~1c ~@@s~~~@~ o b ~ o@~ o @@d"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast v1, Landroidx/core/view/s1;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1}, Landroidx/core/view/s1;->d()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v3, v2

    iput-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method b()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public c(Landroidx/core/view/s1;)Landroidx/appcompat/view/h;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method

.method public d(Landroidx/core/view/s1;Landroidx/core/view/s1;)Landroidx/appcompat/view/h;
    .locals 4

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroidx/core/view/s1;->e()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p2, v0, v1}, Landroidx/core/view/s1;->w(J)Landroidx/core/view/s1;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0
.end method

.method public e(J)Landroidx/appcompat/view/h;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    iput-wide p1, p0, Landroidx/appcompat/view/h;->b:J

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public f(Landroid/view/animation/Interpolator;)Landroidx/appcompat/view/h;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/h;->c:Landroid/view/animation/Interpolator;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public g(Landroidx/core/view/t1;)Landroidx/appcompat/view/h;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/h;->d:Landroidx/core/view/t1;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public h()V
    .locals 8

    iget-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v7, 0x3

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    return-void

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/h;->a:Ljava/util/ArrayList;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v1, :cond_4

    const/4 v6, 0x7

    move v7, v6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    check-cast v1, Landroidx/core/view/s1;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-wide v2, p0, Landroidx/appcompat/view/h;->b:J

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x0

    const/4 v7, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    cmp-long v4, v2, v4

    const/4 v7, 0x1

    if-ltz v4, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v3}, Landroidx/core/view/s1;->s(J)Landroidx/core/view/s1;

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Landroidx/appcompat/view/h;->c:Landroid/view/animation/Interpolator;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Landroidx/core/view/s1;->t(Landroid/view/animation/Interpolator;)Landroidx/core/view/s1;

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v2, p0, Landroidx/appcompat/view/h;->d:Landroidx/core/view/t1;

    const/4 v7, 0x0

    const/4 v6, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v2, p0, Landroidx/appcompat/view/h;->f:Landroidx/core/view/u1;

    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1, v2}, Landroidx/core/view/s1;->u(Landroidx/core/view/t1;)Landroidx/core/view/s1;

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1}, Landroidx/core/view/s1;->y()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_0

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v0, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/view/h;->e:Z

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-void
.end method
