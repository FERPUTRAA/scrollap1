.class public Landroidx/appcompat/graphics/drawable/d;
.super Landroid/graphics/drawable/Drawable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/graphics/drawable/d$a;
    }
.end annotation


# static fields
.field public static final m:I = 0x0

.field public static final n:I = 0x1

.field public static final o:I = 0x2

.field public static final p:I = 0x3

.field private static final q:F


# instance fields
.field private final a:Landroid/graphics/Paint;

.field private b:F

.field private c:F

.field private d:F

.field private e:F

.field private f:Z

.field private final g:Landroid/graphics/Path;

.field private final h:I

.field private i:Z

.field private j:F

.field private k:F

.field private l:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    const-wide v0, 0x4046800000000000L    # 45.0

    const-wide v0, 0x4046800000000000L    # 45.0

    const/4 v3, 0x7

    const-wide v0, 0x4046800000000000L    # 45.0

    const-wide v0, 0x4046800000000000L    # 45.0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v0

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    double-to-float v0, v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    sput v0, Landroidx/appcompat/graphics/drawable/d;->q:F

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v0, Landroid/graphics/Paint;

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-direct {v0}, Landroid/graphics/Paint;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v7, 0x6

    const/4 v6, 0x3

    new-instance v1, Landroid/graphics/Path;

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    invoke-direct {v1}, Landroid/graphics/Path;-><init>()V

    const/4 v7, 0x3

    iput-object v1, p0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/d;->i:Z

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x2

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput v2, p0, Landroidx/appcompat/graphics/drawable/d;->l:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object v2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget-object v2, Landroid/graphics/Paint$Join;->MITER:Landroid/graphics/Paint$Join;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    const/4 v6, 0x5

    shl-int/2addr v7, v6

    sget-object v2, Landroid/graphics/Paint$Cap;->BUTT:Landroid/graphics/Paint$Cap;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle:[I

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    sget v3, Landroidx/appcompat/R$attr;->drawerArrowStyle:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget v4, Landroidx/appcompat/R$style;->Base_Widget_AppCompat_DrawerArrowToggle:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p1, v5, v0, v3, v4}, Landroid/content/res/Resources$Theme;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_color:I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/d;->p(I)V

    const/4 v7, 0x2

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_thickness:I

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/d;->o(F)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_spinBars:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/d;->t(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_gapBetweenBars:I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    int-to-float v0, v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/d;->r(F)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_drawableSize:I

    const/4 v6, 0x1

    or-int/2addr v7, v6

    invoke-virtual {p1, v0, v1}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput v0, p0, Landroidx/appcompat/graphics/drawable/d;->h:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_barLength:I

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    int-to-float v0, v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    iput v0, p0, Landroidx/appcompat/graphics/drawable/d;->c:F

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_arrowHeadLength:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    int-to-float v0, v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput v0, p0, Landroidx/appcompat/graphics/drawable/d;->b:F

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget v0, Landroidx/appcompat/R$styleable;->DrawerArrowToggle_arrowShaftLength:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    iput v0, p0, Landroidx/appcompat/graphics/drawable/d;->d:F

    const/4 v7, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    return-void
.end method

.method private static k(FFF)F
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "Sos@ci~@@@~~sf M@i    b4 ooo  to.~d~~@ / l of @ @t/~@1@n~@~u ~l@yi@@@~r~ mb~-~~@@~ ~~~~ b~@va~K@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    sub-float/2addr p1, p0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    mul-float/2addr p1, p2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    add-float/2addr p0, p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return p0
.end method


# virtual methods
.method public a()F
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->b:F

    const/4 v2, 0x5

    const/4 v1, 0x2

    return v0
.end method

.method public b()F
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->d:F

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public c()F
    .locals 3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->c:F

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public d()F
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    invoke-virtual/range {p0 .. p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v2

    iget v3, v0, Landroidx/appcompat/graphics/drawable/d;->l:I

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_2

    if-eq v3, v5, :cond_1

    const/4 v6, 0x3

    if-eq v3, v6, :cond_0

    invoke-static/range {p0 .. p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v3

    if-ne v3, v5, :cond_2

    goto :goto_0

    :cond_0
    invoke-static/range {p0 .. p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v3

    if-nez v3, :cond_2

    :cond_1
    :goto_0
    move v4, v5

    move v4, v5

    move v4, v5

    :cond_2
    iget v3, v0, Landroidx/appcompat/graphics/drawable/d;->b:F

    mul-float/2addr v3, v3

    const/high16 v6, 0x40000000    # 2.0f

    mul-float/2addr v3, v6

    float-to-double v7, v3

    invoke-static {v7, v8}, Ljava/lang/Math;->sqrt(D)D

    move-result-wide v7

    double-to-float v3, v7

    iget v7, v0, Landroidx/appcompat/graphics/drawable/d;->c:F

    iget v8, v0, Landroidx/appcompat/graphics/drawable/d;->j:F

    invoke-static {v7, v3, v8}, Landroidx/appcompat/graphics/drawable/d;->k(FFF)F

    move-result v3

    iget v7, v0, Landroidx/appcompat/graphics/drawable/d;->c:F

    iget v8, v0, Landroidx/appcompat/graphics/drawable/d;->d:F

    iget v9, v0, Landroidx/appcompat/graphics/drawable/d;->j:F

    invoke-static {v7, v8, v9}, Landroidx/appcompat/graphics/drawable/d;->k(FFF)F

    move-result v7

    iget v8, v0, Landroidx/appcompat/graphics/drawable/d;->k:F

    iget v9, v0, Landroidx/appcompat/graphics/drawable/d;->j:F

    const/4 v10, 0x0

    invoke-static {v10, v8, v9}, Landroidx/appcompat/graphics/drawable/d;->k(FFF)F

    move-result v8

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    int-to-float v8, v8

    sget v9, Landroidx/appcompat/graphics/drawable/d;->q:F

    iget v11, v0, Landroidx/appcompat/graphics/drawable/d;->j:F

    invoke-static {v10, v9, v11}, Landroidx/appcompat/graphics/drawable/d;->k(FFF)F

    move-result v9

    if-eqz v4, :cond_3

    move v11, v10

    move v11, v10

    move v11, v10

    move v11, v10

    goto :goto_1

    :cond_3
    const/high16 v11, -0x3ccc0000    # -180.0f

    :goto_1
    const/high16 v12, 0x43340000    # 180.0f

    if-eqz v4, :cond_4

    move v13, v12

    move v13, v12

    move v13, v12

    move v13, v12

    goto :goto_2

    :cond_4
    move v13, v10

    move v13, v10

    :goto_2
    iget v14, v0, Landroidx/appcompat/graphics/drawable/d;->j:F

    invoke-static {v11, v13, v14}, Landroidx/appcompat/graphics/drawable/d;->k(FFF)F

    move-result v11

    float-to-double v13, v3

    move v15, v11

    move v15, v11

    move v15, v11

    move v15, v11

    float-to-double v10, v9

    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    move-result-wide v16

    mul-double v16, v16, v13

    move v9, v4

    move v9, v4

    move v9, v4

    move v9, v4

    invoke-static/range {v16 .. v17}, Ljava/lang/Math;->round(D)J

    move-result-wide v3

    long-to-float v3, v3

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    mul-double/2addr v13, v10

    invoke-static {v13, v14}, Ljava/lang/Math;->round(D)J

    move-result-wide v10

    long-to-float v4, v10

    iget-object v10, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    invoke-virtual {v10}, Landroid/graphics/Path;->rewind()V

    iget v10, v0, Landroidx/appcompat/graphics/drawable/d;->e:F

    iget-object v11, v0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    invoke-virtual {v11}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v11

    add-float/2addr v10, v11

    iget v11, v0, Landroidx/appcompat/graphics/drawable/d;->k:F

    neg-float v11, v11

    iget v13, v0, Landroidx/appcompat/graphics/drawable/d;->j:F

    invoke-static {v10, v11, v13}, Landroidx/appcompat/graphics/drawable/d;->k(FFF)F

    move-result v10

    neg-float v11, v7

    div-float/2addr v11, v6

    iget-object v13, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    add-float v14, v11, v8

    const/4 v5, 0x0

    invoke-virtual {v13, v14, v5}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v13, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    mul-float/2addr v8, v6

    sub-float/2addr v7, v8

    invoke-virtual {v13, v7, v5}, Landroid/graphics/Path;->rLineTo(FF)V

    iget-object v5, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    invoke-virtual {v5, v11, v10}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v5, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    invoke-virtual {v5, v3, v4}, Landroid/graphics/Path;->rLineTo(FF)V

    iget-object v5, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    neg-float v7, v10

    invoke-virtual {v5, v11, v7}, Landroid/graphics/Path;->moveTo(FF)V

    iget-object v5, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    neg-float v4, v4

    invoke-virtual {v5, v3, v4}, Landroid/graphics/Path;->rLineTo(FF)V

    iget-object v3, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    invoke-virtual {v3}, Landroid/graphics/Path;->close()V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->save()I

    iget-object v3, v0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    invoke-virtual {v3}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v3

    invoke-virtual {v2}, Landroid/graphics/Rect;->height()I

    move-result v4

    int-to-float v4, v4

    const/high16 v5, 0x40400000    # 3.0f

    mul-float/2addr v5, v3

    sub-float/2addr v4, v5

    iget v5, v0, Landroidx/appcompat/graphics/drawable/d;->e:F

    mul-float/2addr v6, v5

    sub-float/2addr v4, v6

    float-to-int v4, v4

    div-int/lit8 v4, v4, 0x4

    mul-int/lit8 v4, v4, 0x2

    int-to-float v4, v4

    const/high16 v6, 0x3fc00000    # 1.5f

    mul-float/2addr v3, v6

    add-float/2addr v3, v5

    add-float/2addr v4, v3

    invoke-virtual {v2}, Landroid/graphics/Rect;->centerX()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {v1, v2, v4}, Landroid/graphics/Canvas;->translate(FF)V

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/d;->f:Z

    if-eqz v2, :cond_6

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/d;->i:Z

    xor-int/2addr v2, v9

    if-eqz v2, :cond_5

    const/4 v5, -0x1

    goto :goto_3

    :cond_5
    const/4 v5, 0x1

    :goto_3
    int-to-float v2, v5

    mul-float v11, v15, v2

    invoke-virtual {v1, v11}, Landroid/graphics/Canvas;->rotate(F)V

    goto :goto_4

    :cond_6
    if-eqz v9, :cond_7

    invoke-virtual {v1, v12}, Landroid/graphics/Canvas;->rotate(F)V

    :cond_7
    :goto_4
    iget-object v2, v0, Landroidx/appcompat/graphics/drawable/d;->g:Landroid/graphics/Path;

    iget-object v3, v0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/Canvas;->restore()V

    return-void
.end method

.method public e()I
    .locals 3
    .annotation build Landroidx/annotation/l;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->l:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    return v0
.end method

.method public g()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->e:F

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->h:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->h:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    return v0
.end method

.method public getOpacity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v0, -0x3

    const/4 v2, 0x3

    move v1, v0

    const/4 v2, 0x4

    return v0
.end method

.method public final h()Landroid/graphics/Paint;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public i()F
    .locals 3
    .annotation build Landroidx/annotation/x;
        from = 0.0
        to = 1.0
    .end annotation

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->j:F

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public j()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/d;->f:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public l(F)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->b:F

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    cmpl-float v0, v0, p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->b:F

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public m(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->d:F

    const/4 v2, 0x7

    cmpl-float v0, v0, p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->d:F

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public n(F)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->c:F

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    cmpl-float v0, v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->c:F

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public o(F)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/graphics/Paint;->getStrokeWidth()F

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    cmpl-float v0, v0, p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/high16 v0, 0x40000000    # 2.0f

    const/4 v5, 0x2

    const/4 v4, 0x7

    div-float/2addr p1, v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    float-to-double v0, p1

    const/4 v5, 0x0

    sget p1, Landroidx/appcompat/graphics/drawable/d;->q:F

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    float-to-double v2, p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v2, v3}, Ljava/lang/Math;->cos(D)D

    move-result-wide v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    mul-double/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    double-to-float p1, v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->k:F

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method public p(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/l;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0}, Landroid/graphics/Paint;->getColor()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eq p1, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public q(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->l:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->l:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public r(F)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->e:F

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    cmpl-float v0, p1, v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->e:F

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public s(F)V
    .locals 3
    .param p1    # F
        .annotation build Landroidx/annotation/x;
            from = 0.0
            to = 1.0
        .end annotation
    .end param

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/graphics/drawable/d;->j:F

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    cmpl-float v0, v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/d;->j:F

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public setAlpha(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/graphics/Paint;->getAlpha()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eq p1, v0, :cond_0

    const/4 v1, 0x0

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setAlpha(I)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x0

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/d;->a:Landroid/graphics/Paint;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/Paint;->setColorFilter(Landroid/graphics/ColorFilter;)Landroid/graphics/ColorFilter;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public t(Z)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/d;->f:Z

    const/4 v2, 0x5

    if-eq v0, p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/graphics/drawable/d;->f:Z

    const/4 v1, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public u(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/d;->i:Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/graphics/drawable/d;->i:Z

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_0
    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method
