.class Landroidx/appcompat/graphics/drawable/a$b;
.super Landroidx/appcompat/graphics/drawable/a$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# instance fields
.field private final a:Landroid/graphics/drawable/Animatable;


# direct methods
.method constructor <init>(Landroid/graphics/drawable/Animatable;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/a$g;-><init>(Landroidx/appcompat/graphics/drawable/a$a;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a$b;->a:Landroid/graphics/drawable/Animatable;

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public c()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/sn@a@r ~f@bo~1 ~o~M b~oSmloi~u~v~~~  ~@@@i@ @@@@~@  i~~@s~o@l4tdft oK@@ @c-  b~  ~~y~~~@@ /@ ."

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$b;->a:Landroid/graphics/drawable/Animatable;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-interface {v0}, Landroid/graphics/drawable/Animatable;->start()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$b;->a:Landroid/graphics/drawable/Animatable;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0}, Landroid/graphics/drawable/Animatable;->stop()V

    const/4 v1, 0x0

    return-void
.end method
