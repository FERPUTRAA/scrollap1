.class abstract Landroidx/appcompat/graphics/drawable/b$d;
.super Landroid/graphics/drawable/Drawable$ConstantState;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x408
    name = "d"
.end annotation


# instance fields
.field A:I

.field B:I

.field C:Z

.field D:Landroid/graphics/ColorFilter;

.field E:Z

.field F:Landroid/content/res/ColorStateList;

.field G:Landroid/graphics/PorterDuff$Mode;

.field H:Z

.field I:Z

.field final a:Landroidx/appcompat/graphics/drawable/b;

.field b:Landroid/content/res/Resources;

.field c:I

.field d:I

.field e:I

.field f:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Landroid/graphics/drawable/Drawable$ConstantState;",
            ">;"
        }
    .end annotation
.end field

.field g:[Landroid/graphics/drawable/Drawable;

.field h:I

.field i:Z

.field j:Z

.field k:Landroid/graphics/Rect;

.field l:Z

.field m:Z

.field n:I

.field o:I

.field p:I

.field q:I

.field r:Z

.field s:I

.field t:Z

.field u:Z

.field v:Z

.field w:Z

.field x:Z

.field y:Z

.field z:I


# direct methods
.method constructor <init>(Landroidx/appcompat/graphics/drawable/b$d;Landroidx/appcompat/graphics/drawable/b;Landroid/content/res/Resources;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable$ConstantState;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->a:Landroidx/appcompat/graphics/drawable/b;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 p2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p3, :cond_0

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->b:Landroid/content/res/Resources;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->b:Landroid/content/res/Resources;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->c:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_1

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    move v2, v0

    move v2, v0

    const/4 v4, 0x1

    move v2, v0

    move v2, v0

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p3, v2}, Landroidx/appcompat/graphics/drawable/b;->g(Landroid/content/res/Resources;I)I

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput p3, p0, Landroidx/appcompat/graphics/drawable/b$d;->c:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p1, :cond_b

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v3, 0x2

    move v4, v3

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->v:Z

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->w:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->y:Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->y:Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->z:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->z:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v4, 0x7

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->C:Z

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->C:Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->D:Landroid/graphics/ColorFilter;

    const/4 v3, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->D:Landroid/graphics/ColorFilter;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->E:Z

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->E:Z

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->F:Landroid/content/res/ColorStateList;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->F:Landroid/content/res/ColorStateList;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->G:Landroid/graphics/PorterDuff$Mode;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->G:Landroid/graphics/PorterDuff$Mode;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->H:Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->H:Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-boolean v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->I:Z

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->I:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v2, p1, Landroidx/appcompat/graphics/drawable/b$d;->c:I

    const/4 v4, 0x5

    if-ne v2, p3, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-boolean p3, p1, Landroidx/appcompat/graphics/drawable/b$d;->j:Z

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz p3, :cond_4

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object p3, p1, Landroidx/appcompat/graphics/drawable/b$d;->k:Landroid/graphics/Rect;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz p3, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p2, Landroid/graphics/Rect;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p3, p1, Landroidx/appcompat/graphics/drawable/b$d;->k:Landroid/graphics/Rect;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p2, p3}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->k:Landroid/graphics/Rect;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->j:Z

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-boolean p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz p2, :cond_5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->n:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->n:I

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->o:I

    const/4 v4, 0x3

    iput p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->o:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->p:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->p:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->q:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    iput p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->q:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-boolean p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->r:Z

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p2, :cond_6

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->s:I

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->s:I

    const/4 v4, 0x6

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->r:Z

    :cond_6
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-boolean p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->t:Z

    const/4 v3, 0x4

    move v4, v3

    if-eqz p2, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-boolean p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->u:Z

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-boolean p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->u:Z

    const/4 v4, 0x3

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->t:Z

    :cond_7
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object p2, p1, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    array-length p3, p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-array p3, p3, [Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object p3, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x1

    const/4 v3, 0x3

    iget p3, p1, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput p3, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p1, p1, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz p1, :cond_8

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/util/SparseArray;->clone()Landroid/util/SparseArray;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_2

    :cond_8
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance p1, Landroid/util/SparseArray;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget p3, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-direct {p1, p3}, Landroid/util/SparseArray;-><init>(I)V

    const/4 v4, 0x6

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    :goto_2
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    :goto_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-ge v0, p1, :cond_c

    const/4 v4, 0x0

    const/4 v3, 0x3

    aget-object p3, p2, v0

    const/4 v4, 0x5

    if-eqz p3, :cond_a

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p3}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object p3

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz p3, :cond_9

    const/4 v4, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v0, p3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_4

    :cond_9
    const/4 v4, 0x0

    iget-object p3, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    aget-object v1, p2, v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    aput-object v1, p3, v0

    :cond_a
    :goto_4
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_3

    :cond_b
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/16 p1, 0xa

    const/4 v4, 0x1

    new-array p1, p1, [Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    :cond_c
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method

.method private f()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@~s@ M 1~~~@~~~~~f.llio@@o v@ti@ f @~~@Kbs ~~@4ry@ Si~~ c @@o@~ ~ m@~@~ob@- b/ au/d  to ~~@ ~@@n"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v7, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/util/SparseArray;->size()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v1, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ge v1, v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {v3, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    check-cast v3, Landroid/graphics/drawable/Drawable$ConstantState;

    iget-object v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v5, p0, Landroidx/appcompat/graphics/drawable/b$d;->b:Landroid/content/res/Resources;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v3, v5}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p0, v3}, Landroidx/appcompat/graphics/drawable/b$d;->w(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    aput-object v3, v4, v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x7

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    return-void
.end method

.method private w(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->z:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->a:Landroidx/appcompat/graphics/drawable/b;

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1
.end method


# virtual methods
.method final A(II)Z
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v2, 0x0

    shl-int/2addr v6, v2

    const/4 v5, 0x1

    move v6, v5

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ge v2, v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    aget-object v4, v1, v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v4, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v4, p1}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-ne v2, p2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    move v3, v4

    move v3, v4

    move v3, v4

    :cond_0
    const/4 v6, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->z:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    return v3
.end method

.method public final B(Z)V
    .locals 2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method final C(Landroid/content/res/Resources;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->b:Landroid/content/res/Resources;

    const/4 v1, 0x5

    move v2, v1

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1, v0}, Landroidx/appcompat/graphics/drawable/b;->g(Landroid/content/res/Resources;I)I

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->c:I

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->c:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->j:Z

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public final a(Landroid/graphics/drawable/Drawable;)I
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    array-length v1, v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-lt v0, v1, :cond_0

    const/4 v5, 0x2

    add-int/lit8 v1, v0, 0xa

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, v0, v1}, Landroidx/appcompat/graphics/drawable/b$d;->r(II)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {p1, v1, v2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->a:Landroidx/appcompat/graphics/drawable/b;

    const/4 v5, 0x3

    invoke-virtual {p1, v3}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    aput-object p1, v3, v0

    const/4 v5, 0x5

    iget v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    add-int/2addr v3, v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    or-int/2addr p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->s()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->k:Landroid/graphics/Rect;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->j:Z

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-boolean v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->v:Z

    const/4 v5, 0x3

    const/4 v4, 0x3

    return v0
.end method

.method final b(Landroid/content/res/Resources$Theme;)V
    .locals 7
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v6, 0x5

    if-eqz p1, :cond_2

    const/4 v5, 0x1

    move v6, v5

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b$d;->f()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ge v2, v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    aget-object v3, v1, v2

    const/4 v5, 0x7

    move v6, v5

    if-eqz v3, :cond_0

    const/4 v6, 0x2

    invoke-static {v3}, Landroidx/core/graphics/drawable/d;->b(Landroid/graphics/drawable/Drawable;)Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    aget-object v3, v1, v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v3, p1}, Landroidx/core/graphics/drawable/d;->a(Landroid/graphics/drawable/Drawable;Landroid/content/res/Resources$Theme;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    aget-object v4, v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    or-int/2addr v3, v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p1}, Landroidx/appcompat/graphics/drawable/b$b;->c(Landroid/content/res/Resources$Theme;)Landroid/content/res/Resources;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/b$d;->C(Landroid/content/res/Resources;)V

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method

.method public c()Z
    .locals 8

    const/4 v7, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->v:Z

    const/4 v7, 0x1

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->w:Z

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    return v0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b$d;->f()V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->v:Z

    const/4 v7, 0x3

    iget v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    move v4, v3

    const/4 v7, 0x2

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ge v4, v1, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    aget-object v5, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v5, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    iput-boolean v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->w:Z

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    return v3

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->w:Z

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    return v0
.end method

.method public canApplyTheme()Z
    .locals 8
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x4

    move v7, v6

    const/4 v2, 0x0

    xor-int/2addr v7, v2

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    const/4 v7, 0x6

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    if-ge v3, v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    aget-object v4, v1, v3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v5, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v4}, Landroidx/core/graphics/drawable/d;->b(Landroid/graphics/drawable/Drawable;)Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v4, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    return v5

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v4, v3}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    check-cast v4, Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v4}, Landroidx/appcompat/graphics/drawable/b$b;->a(Landroid/graphics/drawable/Drawable$ConstantState;)Z

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    return v5

    :cond_1
    const/4 v6, 0x3

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    return v2
.end method

.method final d()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->y:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method protected e()V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v0, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b$d;->f()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v2, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->o:I

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->n:I

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->q:I

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->p:I

    :goto_0
    const/4 v6, 0x2

    const/4 v7, 0x0

    if-ge v2, v0, :cond_4

    const/4 v7, 0x2

    aget-object v3, v1, v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget v5, p0, Landroidx/appcompat/graphics/drawable/b$d;->n:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-le v4, v5, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->n:I

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget v5, p0, Landroidx/appcompat/graphics/drawable/b$d;->o:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-le v4, v5, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->o:I

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget v5, p0, Landroidx/appcompat/graphics/drawable/b$d;->p:I

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-le v4, v5, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->p:I

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->q:I

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-le v3, v4, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->q:I

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x6

    return-void
.end method

.method final g()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    array-length v0, v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public getChangingConfigurations()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->e:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    or-int/2addr v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v0
.end method

.method public final h(I)Landroid/graphics/drawable/Drawable;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    aget-object v0, v0, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->indexOfKey(I)I

    move-result v0

    const/4 v5, 0x2

    if-ltz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    check-cast v2, Landroid/graphics/drawable/Drawable$ConstantState;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->b:Landroid/content/res/Resources;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {p0, v2}, Landroidx/appcompat/graphics/drawable/b$d;->w(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    aput-object v2, v3, p1

    const/4 v5, 0x7

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Landroid/util/SparseArray;->removeAt(I)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez p1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->f:Landroid/util/SparseArray;

    :cond_1
    const/4 v5, 0x4

    return-object v2

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object v1
.end method

.method public final i()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public final j()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->e()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->o:I

    const/4 v2, 0x1

    return v0
.end method

.method public final k()I
    .locals 3

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->e()V

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->q:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public final l()I
    .locals 3

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    if-nez v0, :cond_0

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->e()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->p:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method public final m()Landroid/graphics/Rect;
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    move v9, v8

    return-object v1

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->k:Landroid/graphics/Rect;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez v0, :cond_8

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->j:Z

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v2, :cond_1

    const/4 v9, 0x1

    goto/16 :goto_1

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b$d;->f()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance v0, Landroid/graphics/Rect;

    const/4 v9, 0x2

    const/4 v8, 0x1

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v9, 0x0

    const/4 v8, 0x6

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v4, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    move v5, v4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-ge v5, v2, :cond_7

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    aget-object v6, v3, v5

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v6, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    move-result v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-eqz v6, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez v1, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-instance v1, Landroid/graphics/Rect;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {v1, v4, v4, v4, v4}, Landroid/graphics/Rect;-><init>(IIII)V

    :cond_2
    const/4 v9, 0x5

    iget v6, v0, Landroid/graphics/Rect;->left:I

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget v7, v1, Landroid/graphics/Rect;->left:I

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-le v6, v7, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    iput v6, v1, Landroid/graphics/Rect;->left:I

    :cond_3
    const/4 v8, 0x7

    const/4 v9, 0x2

    iget v6, v0, Landroid/graphics/Rect;->top:I

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget v7, v1, Landroid/graphics/Rect;->top:I

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-le v6, v7, :cond_4

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    iput v6, v1, Landroid/graphics/Rect;->top:I

    :cond_4
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget v6, v0, Landroid/graphics/Rect;->right:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget v7, v1, Landroid/graphics/Rect;->right:I

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-le v6, v7, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    iput v6, v1, Landroid/graphics/Rect;->right:I

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget v6, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget v7, v1, Landroid/graphics/Rect;->bottom:I

    const/4 v9, 0x0

    if-le v6, v7, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    iput v6, v1, Landroid/graphics/Rect;->bottom:I

    :cond_6
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    add-int/lit8 v5, v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_0

    :cond_7
    const/4 v9, 0x6

    const/4 v0, 0x7

    const/4 v9, 0x6

    const/4 v0, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->j:Z

    const/4 v8, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    iput-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->k:Landroid/graphics/Rect;

    const/4 v9, 0x4

    return-object v1

    :cond_8
    :goto_1
    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    return-object v0
.end method

.method public final n()I
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->m:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->e()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->n:I

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public final o()I
    .locals 3

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public final p()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public final q()I
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->r:Z

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->s:I

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    return v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b$d;->f()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-lez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    aget-object v2, v1, v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v2, -0x2

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v4, v3

    move v4, v3

    :goto_1
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-ge v4, v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    aget-object v5, v1, v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getOpacity()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v2, v5}, Landroid/graphics/drawable/Drawable;->resolveOpacity(II)I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    iput v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->s:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput-boolean v3, p0, Landroidx/appcompat/graphics/drawable/b$d;->r:Z

    const/4 v7, 0x0

    return v2
.end method

.method public r(II)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-array p2, p2, [Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1, p2, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p2, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method s()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->r:Z

    const/4 v1, 0x3

    move v2, v1

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->t:Z

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public final t()Z
    .locals 3

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public final u()Z
    .locals 8

    const/4 v6, 0x5

    move v7, v6

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->t:Z

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->u:Z

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    return v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b$d;->f()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x3

    const/4 v4, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-ge v3, v0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    aget-object v5, v1, v3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v5, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    move v2, v4

    move v2, v4

    const/4 v7, 0x0

    move v2, v4

    move v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b$d;->u:Z

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-boolean v4, p0, Landroidx/appcompat/graphics/drawable/b$d;->t:Z

    const/4 v6, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    return v2
.end method

.method v()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b$d;->g:[Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    if-ge v2, v0, :cond_1

    const/4 v4, 0x5

    const/4 v5, 0x3

    aget-object v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v3}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x6

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b$d;->y:Z

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method

.method public final x(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public final y(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public final z(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method
