.class Landroidx/appcompat/graphics/drawable/b;
.super Landroid/graphics/drawable/Drawable;

# interfaces
.implements Landroid/graphics/drawable/Drawable$Callback;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/graphics/drawable/b$b;,
        Landroidx/appcompat/graphics/drawable/b$c;,
        Landroidx/appcompat/graphics/drawable/b$d;
    }
.end annotation


# static fields
.field private static final m:Z = false

.field private static final n:Ljava/lang/String; = "DrawableContainer"

.field private static final o:Z = true


# instance fields
.field private a:Landroidx/appcompat/graphics/drawable/b$d;

.field private b:Landroid/graphics/Rect;

.field private c:Landroid/graphics/drawable/Drawable;

.field private d:Landroid/graphics/drawable/Drawable;

.field private e:I

.field private f:Z

.field private g:I

.field private h:Z

.field private i:Ljava/lang/Runnable;

.field private j:J

.field private k:J

.field private l:Landroidx/appcompat/graphics/drawable/b$c;


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Landroid/graphics/drawable/Drawable;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/16 v0, 0xff

    const/4 v1, 0x5

    move v2, v1

    iput v0, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput v0, p0, Landroidx/appcompat/graphics/drawable/b;->g:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private e(Landroid/graphics/drawable/Drawable;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@lso@/~  S~@@ri@~@ fbm@d~ Mf @ @~~i~l~oKo.@@ ot@c~-~ v@@ @~4~~@@@ bu~ ~ n  ~1~  @io~@/o~~tab~y~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->l:Landroidx/appcompat/graphics/drawable/b$c;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    new-instance v0, Landroidx/appcompat/graphics/drawable/b$c;

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v0}, Landroidx/appcompat/graphics/drawable/b$c;-><init>()V

    const/4 v5, 0x2

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->l:Landroidx/appcompat/graphics/drawable/b$c;

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->l:Landroidx/appcompat/graphics/drawable/b$c;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroidx/appcompat/graphics/drawable/b$c;->b(Landroid/graphics/drawable/Drawable$Callback;)Landroidx/appcompat/graphics/drawable/b$c;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-gtz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->f:Z

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_1
    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->E:Z

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->D:Landroid/graphics/ColorFilter;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->H:Z

    const/4 v4, 0x5

    move v5, v4

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->F:Landroid/content/res/ColorStateList;

    const/4 v5, 0x3

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->I:Z

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->G:Landroid/graphics/PorterDuff$Mode;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_4
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-boolean v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setDither(Z)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getLevel()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->m(Landroid/graphics/drawable/Drawable;I)Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v5, 0x6

    iget-boolean v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->C:Z

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1, v0}, Landroidx/core/graphics/drawable/d;->j(Landroid/graphics/drawable/Drawable;Z)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->b:Landroid/graphics/Rect;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x2

    iget v1, v0, Landroid/graphics/Rect;->left:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v2, v0, Landroid/graphics/Rect;->top:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget v3, v0, Landroid/graphics/Rect;->right:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, v1, v2, v3, v0}, Landroidx/core/graphics/drawable/d;->l(Landroid/graphics/drawable/Drawable;IIII)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->l:Landroidx/appcompat/graphics/drawable/b$c;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$c;->a()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-void

    :catchall_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b;->l:Landroidx/appcompat/graphics/drawable/b$c;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroidx/appcompat/graphics/drawable/b$c;->a()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    throw v0
.end method

.method private f()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b;->isAutoMirrored()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0}, Landroidx/core/graphics/drawable/d;->f(Landroid/graphics/drawable/Drawable;)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v1
.end method

.method static g(Landroid/content/res/Resources;I)I
    .locals 2
    .param p0    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-nez p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget p1, p0, Landroid/util/DisplayMetrics;->densityDpi:I

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-nez p1, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/16 p1, 0xa0

    :cond_1
    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method


# virtual methods
.method a(Z)V
    .locals 14

    const/4 v13, 0x0

    const/4 v0, 0x1

    const/4 v13, 0x6

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->f:Z

    const/4 v13, 0x3

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    const/4 v13, 0x5

    iget-object v3, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const-wide/16 v4, 0xff

    const/4 v13, 0x6

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v13, 0x0

    const/4 v8, 0x0

    const/4 v13, 0x6

    if-eqz v3, :cond_1

    const/4 v13, 0x2

    iget-wide v9, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    const/4 v13, 0x4

    cmp-long v11, v9, v6

    const/4 v13, 0x5

    if-eqz v11, :cond_2

    const/4 v13, 0x5

    cmp-long v11, v9, v1

    const/4 v13, 0x7

    if-gtz v11, :cond_0

    const/4 v13, 0x4

    iget v9, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v13, 0x5

    invoke-virtual {v3, v9}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    iput-wide v6, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    const/4 v13, 0x3

    goto :goto_0

    :cond_0
    const/4 v13, 0x3

    sub-long/2addr v9, v1

    const/4 v13, 0x7

    mul-long/2addr v9, v4

    const/4 v13, 0x3

    long-to-int v9, v9

    const/4 v13, 0x1

    iget-object v10, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v13, 0x6

    iget v10, v10, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v13, 0x3

    div-int/2addr v9, v10

    const/4 v13, 0x2

    rsub-int v9, v9, 0xff

    const/4 v13, 0x1

    iget v10, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v13, 0x7

    mul-int/2addr v9, v10

    const/4 v13, 0x3

    div-int/lit16 v9, v9, 0xff

    const/4 v13, 0x2

    invoke-virtual {v3, v9}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    const/4 v13, 0x0

    move v3, v0

    move v3, v0

    move v3, v0

    move v3, v0

    const/4 v13, 0x4

    goto :goto_1

    :cond_1
    const/4 v13, 0x6

    iput-wide v6, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    :cond_2
    :goto_0
    const/4 v13, 0x2

    move v3, v8

    move v3, v8

    move v3, v8

    move v3, v8

    :goto_1
    const/4 v13, 0x0

    iget-object v9, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    if-eqz v9, :cond_4

    const/4 v13, 0x1

    iget-wide v10, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v13, 0x3

    cmp-long v12, v10, v6

    const/4 v13, 0x1

    if-eqz v12, :cond_5

    const/4 v13, 0x0

    cmp-long v12, v10, v1

    const/4 v13, 0x4

    if-gtz v12, :cond_3

    const/4 v13, 0x3

    invoke-virtual {v9, v8, v8}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    const/4 v13, 0x1

    const/4 v0, 0x0

    const/4 v13, 0x7

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v13, 0x4

    iput-wide v6, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v13, 0x4

    goto :goto_2

    :cond_3
    const/4 v13, 0x0

    sub-long/2addr v10, v1

    const/4 v13, 0x7

    mul-long/2addr v10, v4

    const/4 v13, 0x5

    long-to-int v3, v10

    const/4 v13, 0x7

    iget-object v4, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v13, 0x5

    iget v4, v4, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v13, 0x7

    div-int/2addr v3, v4

    const/4 v13, 0x2

    iget v4, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    mul-int/2addr v3, v4

    const/4 v13, 0x7

    div-int/lit16 v3, v3, 0xff

    const/4 v13, 0x4

    invoke-virtual {v9, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    goto :goto_3

    :cond_4
    const/4 v13, 0x5

    iput-wide v6, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    :cond_5
    :goto_2
    const/4 v13, 0x2

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    :goto_3
    const/4 v13, 0x3

    if-eqz p1, :cond_6

    const/4 v13, 0x4

    if-eqz v0, :cond_6

    const/4 v13, 0x7

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->i:Ljava/lang/Runnable;

    const/4 v13, 0x2

    const-wide/16 v3, 0x10

    const-wide/16 v3, 0x10

    const-wide/16 v3, 0x10

    const-wide/16 v3, 0x10

    add-long/2addr v1, v3

    const/4 v13, 0x7

    invoke-virtual {p0, p1, v1, v2}, Landroid/graphics/drawable/Drawable;->scheduleSelf(Ljava/lang/Runnable;J)V

    :cond_6
    const/4 v13, 0x4

    return-void
.end method

.method public applyTheme(Landroid/content/res/Resources$Theme;)V
    .locals 3
    .param p1    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/b$d;->b(Landroid/content/res/Resources$Theme;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method b()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->d()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->h:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method c()Landroidx/appcompat/graphics/drawable/b$d;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method

.method public canApplyTheme()Z
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->canApplyTheme()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method d()I
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b;->g:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .locals 3
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x7

    shl-int/2addr v2, v1

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public getAlpha()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return v0
.end method

.method public getChangingConfigurations()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->getChangingConfigurations()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroidx/appcompat/graphics/drawable/b$d;->getChangingConfigurations()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    or-int/2addr v0, v1

    const/4 v3, 0x6

    return v0
.end method

.method public final getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->c()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b;->getChangingConfigurations()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0
.end method

.method public getCurrent()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public getHotspotBounds(Landroid/graphics/Rect;)V
    .locals 3
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->b:Landroid/graphics/Rect;

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->getHotspotBounds(Landroid/graphics/Rect;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->t()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->j()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, -0x1

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public getIntrinsicWidth()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v1, 0x1

    const/4 v1, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->t()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->n()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v1, 0x7

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v1, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_1
    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v2, 0x0

    return v0
.end method

.method public getMinimumHeight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->t()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->k()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public getMinimumWidth()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->t()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->l()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getMinimumWidth()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getOpacity()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->isVisible()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->q()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, -0x2

    :goto_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getOutline(Landroid/graphics/Outline;)V
    .locals 3
    .param p1    # Landroid/graphics/Outline;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p1}, Landroidx/appcompat/graphics/drawable/b$b;->b(Landroid/graphics/drawable/Drawable;Landroid/graphics/Outline;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public getPadding(Landroid/graphics/Rect;)Z
    .locals 5
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->m()Landroid/graphics/Rect;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v1, v0, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v2, v0, Landroid/graphics/Rect;->top:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    or-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v2, v0, Landroid/graphics/Rect;->bottom:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    or-int/2addr v1, v2

    iget v0, v0, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    or-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x1

    shr-int/2addr v3, v0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-super {p0, p1}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    move-result v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b;->f()Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v1, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget v2, p1, Landroid/graphics/Rect;->right:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput v2, p1, Landroid/graphics/Rect;->left:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput v1, p1, Landroid/graphics/Rect;->right:I

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0
.end method

.method h(I)Z
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b;->g:I

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v1, 0x0

    const/4 v10, 0x5

    if-ne p1, v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    return v1

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v10, 0x5

    iget v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v4, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-lez v0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v0, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v0, v1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_1
    const/4 v10, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz v0, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    int-to-long v0, v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    add-long/2addr v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    iput-wide v0, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    goto :goto_0

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    iput-object v4, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x3

    iput-wide v5, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v9, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    goto :goto_0

    :cond_3
    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v0, :cond_4

    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v1, v1}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_4
    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-ltz p1, :cond_6

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->h:I

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-ge p1, v1, :cond_6

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/b$d;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b;->g:I

    const/4 v9, 0x0

    move v10, v9

    if-eqz v0, :cond_7

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget p1, p1, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v10, 0x2

    if-lez p1, :cond_5

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    int-to-long v7, p1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    add-long/2addr v2, v7

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput-wide v2, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    :cond_5
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/b;->e(Landroid/graphics/drawable/Drawable;)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto :goto_1

    :cond_6
    const/4 v10, 0x2

    const/4 v9, 0x3

    iput-object v4, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 p1, -0x7

    const/4 p1, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b;->g:I

    :cond_7
    :goto_1
    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-wide v0, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    cmp-long p1, v0, v5

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v0, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-nez p1, :cond_8

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-wide v1, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    cmp-long p1, v1, v5

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-eqz p1, :cond_a

    :cond_8
    const/4 v10, 0x5

    const/4 v9, 0x2

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->i:Ljava/lang/Runnable;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez p1, :cond_9

    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    new-instance p1, Landroidx/appcompat/graphics/drawable/b$a;

    const/4 v10, 0x4

    const/4 v9, 0x3

    invoke-direct {p1, p0}, Landroidx/appcompat/graphics/drawable/b$a;-><init>(Landroidx/appcompat/graphics/drawable/b;)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->i:Ljava/lang/Runnable;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_2

    :cond_9
    const/4 v10, 0x6

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->unscheduleSelf(Ljava/lang/Runnable;)V

    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/b;->a(Z)V

    :cond_a
    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    return v0
.end method

.method i(Landroidx/appcompat/graphics/drawable/b$d;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b;->g:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-ltz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroidx/appcompat/graphics/drawable/b$d;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->e(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->s()V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-ne p1, v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-interface {p1, p0}, Landroid/graphics/drawable/Drawable$Callback;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public isAutoMirrored()Z
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-boolean v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->C:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public isStateful()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->u()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method j(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->h(I)Z

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public jumpToCurrentState()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v0, v1

    move v0, v1

    const/4 v7, 0x4

    move v0, v1

    move v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v0, 0x7

    const/4 v7, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v2, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    if-eqz v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-boolean v2, p0, Landroidx/appcompat/graphics/drawable/b;->f:Z

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v2, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget v3, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-wide v2, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput-wide v4, p0, Landroidx/appcompat/graphics/drawable/b;->k:J

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v0, v1

    move v0, v1

    const/4 v7, 0x0

    move v0, v1

    move v0, v1

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-wide v2, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v2, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-wide v4, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_1

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v1, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void
.end method

.method public k(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public l(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v1, 0x3

    move v2, v1

    iput p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method final m(Landroid/content/res/Resources;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/b$d;->C(Landroid/content/res/Resources;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->h:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0}, Landroid/graphics/drawable/Drawable;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-ne v0, p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b;->c()Landroidx/appcompat/graphics/drawable/b$d;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->v()V

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/b;->i(Landroidx/appcompat/graphics/drawable/b$d;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    move v2, v1

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->h:Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p0
.end method

.method protected onBoundsChange(Landroid/graphics/Rect;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public onLayoutDirectionChanged(I)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b;->d()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p1, v1}, Landroidx/appcompat/graphics/drawable/b$d;->A(II)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p1
.end method

.method protected onLevelChange(I)Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1
.end method

.method protected onStateChange([I)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1

    :cond_1
    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1
.end method

.method public scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {p1, p0, p2, p3, p4}, Landroid/graphics/drawable/Drawable$Callback;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setAlpha(I)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->f:Z

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v0, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eq v0, p1, :cond_2

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/b;->f:Z

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput p1, p0, Landroidx/appcompat/graphics/drawable/b;->e:I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-wide v1, p0, Landroidx/appcompat/graphics/drawable/b;->j:J

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    cmp-long v1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 p1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->a(Z)V

    :cond_2
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void
.end method

.method public setAutoMirrored(Z)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x5

    const/4 v2, 0x0

    iget-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->C:Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    if-eq v1, p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    iput-boolean p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->C:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->j(Landroid/graphics/drawable/Drawable;Z)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->E:Z

    const/4 v3, 0x5

    iget-object v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->D:Landroid/graphics/ColorFilter;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eq v1, p1, :cond_0

    const/4 v3, 0x3

    iput-object p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->D:Landroid/graphics/ColorFilter;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    move v3, v2

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setColorFilter(Landroid/graphics/ColorFilter;)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public setDither(Z)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eq v1, p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-boolean p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setDither(Z)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public setHotspot(FF)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {v0, p1, p2}, Landroidx/core/graphics/drawable/d;->k(Landroid/graphics/drawable/Drawable;FF)V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public setHotspotBounds(IIII)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->b:Landroid/graphics/Rect;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Landroid/graphics/Rect;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2, p3, p4}, Landroid/graphics/Rect;-><init>(IIII)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->b:Landroid/graphics/Rect;

    const/4 v2, 0x1

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x7

    invoke-virtual {v0, p1, p2, p3, p4}, Landroid/graphics/Rect;->set(IIII)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0, p1, p2, p3, p4}, Landroidx/core/graphics/drawable/d;->l(Landroid/graphics/drawable/Drawable;IIII)V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setTintList(Landroid/content/res/ColorStateList;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->H:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->F:Landroid/content/res/ColorStateList;

    const/4 v3, 0x6

    if-eq v1, p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->F:Landroid/content/res/ColorStateList;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->o(Landroid/graphics/drawable/Drawable;Landroid/content/res/ColorStateList;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public setTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 4
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->a:Landroidx/appcompat/graphics/drawable/b$d;

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->I:Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->G:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eq v1, p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->G:Landroid/graphics/PorterDuff$Mode;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/d;->p(Landroid/graphics/drawable/Drawable;Landroid/graphics/PorterDuff$Mode;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public setVisible(ZZ)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-super {p0, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b;->d:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, p1, p2}, Landroid/graphics/drawable/Drawable;->setVisible(ZZ)Z

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method public unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b;->c:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x6

    const/4 v1, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getCallback()Landroid/graphics/drawable/Drawable$Callback;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-interface {p1, p0, p2}, Landroid/graphics/drawable/Drawable$Callback;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
