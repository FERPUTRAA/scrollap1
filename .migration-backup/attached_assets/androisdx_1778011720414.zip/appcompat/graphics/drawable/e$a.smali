.class Landroidx/appcompat/graphics/drawable/e$a;
.super Landroidx/appcompat/graphics/drawable/b$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field J:[[I


# direct methods
.method constructor <init>(Landroidx/appcompat/graphics/drawable/e$a;Landroidx/appcompat/graphics/drawable/e;Landroid/content/res/Resources;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/graphics/drawable/b$d;-><init>(Landroidx/appcompat/graphics/drawable/b$d;Landroidx/appcompat/graphics/drawable/b;Landroid/content/res/Resources;)V

    const/4 v0, 0x0

    xor-int/2addr v1, v0

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iget-object p1, p1, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->g()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    new-array p1, p1, [[I

    const/4 v0, 0x1

    or-int/2addr v1, v0

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method D([ILandroid/graphics/drawable/Drawable;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-virtual {p0, p2}, Landroidx/appcompat/graphics/drawable/b$d;->a(Landroid/graphics/drawable/Drawable;)I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    aput-object p1, v0, p2

    const/4 v2, 0x0

    return p2
.end method

.method E([I)I
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b$d;->i()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-ge v2, v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    aget-object v3, v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v3, p1}, Landroid/util/StateSet;->stateSetMatches([I[I)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v2

    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 p1, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    return p1
.end method

.method public newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    new-instance v0, Landroidx/appcompat/graphics/drawable/e;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1}, Landroidx/appcompat/graphics/drawable/e;-><init>(Landroidx/appcompat/graphics/drawable/e$a;Landroid/content/res/Resources;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0
.end method

.method public newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Landroidx/appcompat/graphics/drawable/e;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Landroidx/appcompat/graphics/drawable/e;-><init>(Landroidx/appcompat/graphics/drawable/e$a;Landroid/content/res/Resources;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public r(II)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-super {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/b$d;->r(II)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-array p2, p2, [[I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {v0, v1, p2, v1, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x0

    iput-object p2, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v3, 0x0

    return-void
.end method

.method v()V
    .locals 5

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    array-length v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-array v1, v1, [[I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    array-length v0, v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-int/lit8 v0, v0, -0x1

    :goto_0
    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ltz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    aget-object v2, v2, v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2}, [I->clone()Ljava/lang/Object;

    move-result-object v2

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    check-cast v2, [I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 v2, 0x0

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    aput-object v2, v1, v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    add-int/lit8 v0, v0, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method
