.class Landroidx/appcompat/graphics/drawable/a$e;
.super Landroidx/appcompat/graphics/drawable/a$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "e"
.end annotation


# instance fields
.field private final a:Landroid/animation/ObjectAnimator;

.field private final b:Z


# direct methods
.method constructor <init>(Landroid/graphics/drawable/AnimationDrawable;ZZ)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/a$g;-><init>(Landroidx/appcompat/graphics/drawable/a$a;)V

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/graphics/drawable/AnimationDrawable;->getNumberOfFrames()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz p2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    add-int/lit8 v2, v0, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v3, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v1, v0, -0x1

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Landroidx/appcompat/graphics/drawable/a$f;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v0, p1, p2}, Landroidx/appcompat/graphics/drawable/a$f;-><init>(Landroid/graphics/drawable/AnimationDrawable;Z)V

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo p2, "xnsdteescnru"

    const-string/jumbo p2, "nesxcIenudtr"

    const/4 v5, 0x7

    const-string/jumbo p2, "ntrmexrnedIc"

    const-string p2, "currentIndex"

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    filled-new-array {v2, v1}, [I

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1, p2, v1}, Landroid/animation/ObjectAnimator;->ofInt(Ljava/lang/Object;Ljava/lang/String;[I)Landroid/animation/ObjectAnimator;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p1, v3}, Lg/a$b;->a(Landroid/animation/ObjectAnimator;Z)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/a$f;->a()I

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    int-to-long v1, p2

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/animation/ObjectAnimator;->setDuration(J)Landroid/animation/ObjectAnimator;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Landroid/animation/Animator;->setInterpolator(Landroid/animation/TimeInterpolator;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput-boolean p3, p0, Landroidx/appcompat/graphics/drawable/a$e;->b:Z

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a$e;->a:Landroid/animation/ObjectAnimator;

    const/4 v5, 0x5

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@S~o./4 ~ ofstf@ub i~/   ~@alo@@~t1 @o~~@ vo~d@bby~l~~ @  ~@ m @@ oii@~ o@~@n~K@ ~~~~~@c@-~@@ M"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/a$e;->b:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$e;->a:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/animation/ValueAnimator;->reverse()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public c()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$e;->a:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Landroid/animation/ObjectAnimator;->start()V

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$e;->a:Landroid/animation/ObjectAnimator;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroid/animation/Animator;->cancel()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method
