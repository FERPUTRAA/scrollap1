.class Landroidx/appcompat/graphics/drawable/a$f;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/animation/TimeInterpolator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "f"
.end annotation


# instance fields
.field private a:[I

.field private b:I

.field private c:I


# direct methods
.method constructor <init>(Landroid/graphics/drawable/AnimationDrawable;Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/a$f;->b(Landroid/graphics/drawable/AnimationDrawable;Z)I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@sr @@K~~~@ ~ @  @ @d~.@t@nb~ l~~Sl~@- fb /i~a@  o@~~@o~~i4  ot@i~ @@~@~oumo@~@@cf/1v syM ~~o b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/graphics/drawable/a$f;->c:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method b(Landroid/graphics/drawable/AnimationDrawable;Z)I
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/graphics/drawable/AnimationDrawable;->getNumberOfFrames()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a$f;->b:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/a$f;->a:[I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    array-length v1, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-ge v1, v0, :cond_1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-array v1, v0, [I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v1, p0, Landroidx/appcompat/graphics/drawable/a$f;->a:[I

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/a$f;->a:[I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x0

    move v6, v2

    const/4 v5, 0x7

    and-int/2addr v6, v5

    move v3, v2

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-ge v2, v0, :cond_3

    const/4 v5, 0x2

    move v6, v5

    if-eqz p2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    sub-int v4, v0, v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int/lit8 v4, v4, -0x1

    const/4 v5, 0x7

    move v6, v5

    goto :goto_1

    :cond_2
    const/4 v6, 0x1

    move v4, v2

    move v4, v2

    const/4 v6, 0x3

    move v4, v2

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1, v4}, Landroid/graphics/drawable/AnimationDrawable;->getDuration(I)I

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    aput v4, v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    add-int/2addr v3, v4

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_0

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput v3, p0, Landroidx/appcompat/graphics/drawable/a$f;->c:I

    const/4 v5, 0x0

    return v3
.end method

.method public getInterpolation(F)F
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v0, p0, Landroidx/appcompat/graphics/drawable/a$f;->c:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    int-to-float v0, v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    mul-float/2addr p1, v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/high16 v0, 0x3f000000    # 0.5f

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    add-float/2addr p1, v0

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    float-to-int p1, p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget v0, p0, Landroidx/appcompat/graphics/drawable/a$f;->b:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/a$f;->a:[I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    if-ge v2, v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    aget v3, v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-lt p1, v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    sub-int/2addr p1, v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-ge v2, v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    int-to-float p1, p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget v1, p0, Landroidx/appcompat/graphics/drawable/a$f;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    int-to-float v1, v1

    const/4 v5, 0x1

    div-float/2addr p1, v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/4 p1, 0x0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    int-to-float v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    int-to-float v0, v0

    const/4 v4, 0x5

    move v5, v4

    div-float/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    add-float/2addr v1, p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v1
.end method
