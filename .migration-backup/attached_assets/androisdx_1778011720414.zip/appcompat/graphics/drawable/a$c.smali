.class Landroidx/appcompat/graphics/drawable/a$c;
.super Landroidx/appcompat/graphics/drawable/e$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# static fields
.field private static final M:J = 0x100000000L

.field private static final N:J = 0x200000000L


# instance fields
.field K:Landroidx/collection/h;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/h<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field L:Landroidx/collection/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/n<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroidx/appcompat/graphics/drawable/a$c;Landroidx/appcompat/graphics/drawable/a;Landroid/content/res/Resources;)V
    .locals 2
    .param p1    # Landroidx/appcompat/graphics/drawable/a$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/graphics/drawable/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Landroidx/appcompat/graphics/drawable/e$a;-><init>(Landroidx/appcompat/graphics/drawable/e$a;Landroidx/appcompat/graphics/drawable/e;Landroid/content/res/Resources;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-object p2, p1, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget-object p1, p1, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    move v1, v0

    new-instance p1, Landroidx/collection/h;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p1}, Landroidx/collection/h;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v1, 0x0

    const/4 v0, 0x7

    new-instance p1, Landroidx/collection/n;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p1}, Landroidx/collection/n;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method private static H(II)J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "u~s @t@@~~@ ~@/ o ny@b~ @i@ rt@m@floc~o~@  ~lfM@~~@d/  @-@v ~ i~@~1~  .~S@s~ia ~b o~Ko~@~@~ @~b4"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    int-to-long v0, p0

    const/4 v3, 0x0

    const/16 p0, 0x20

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    shl-long/2addr v0, p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    int-to-long p0, p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    or-long/2addr p0, v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-wide p0
.end method


# virtual methods
.method F([ILandroid/graphics/drawable/Drawable;I)I
    .locals 2
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/e$a;->D([ILandroid/graphics/drawable/Drawable;)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p2, p0, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-virtual {p2, p1, p3}, Landroidx/collection/n;->n(ILjava/lang/Object;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p1
.end method

.method G(IILandroid/graphics/drawable/Drawable;Z)I
    .locals 11
    .param p3    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-super {p0, p3}, Landroidx/appcompat/graphics/drawable/b$d;->a(Landroid/graphics/drawable/Drawable;)I

    move-result p3

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {p1, p2}, Landroidx/appcompat/graphics/drawable/a$c;->H(II)J

    move-result-wide v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-eqz p4, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-wide v2, 0x200000000L

    const-wide v2, 0x200000000L

    const/4 v10, 0x4

    const-wide v2, 0x200000000L

    const-wide v2, 0x200000000L

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v4, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    int-to-long v5, p3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    or-long v7, v5, v2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v7

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v4, v0, v1, v7}, Landroidx/collection/h;->a(JLjava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    if-eqz p4, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {p2, p1}, Landroidx/appcompat/graphics/drawable/a$c;->H(II)J

    move-result-wide p1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-object p4, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-wide v0, 0x100000000L

    const-wide v0, 0x100000000L

    const/4 v10, 0x6

    const-wide v0, 0x100000000L

    const-wide v0, 0x100000000L

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    or-long/2addr v0, v5

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    or-long/2addr v0, v2

    const/4 v10, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {p4, p1, p2, v0}, Landroidx/collection/h;->a(JLjava/lang/Object;)V

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    return p3
.end method

.method I(I)I
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-gez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, p1, v0}, Landroidx/collection/n;->i(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result v0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method J([I)I
    .locals 2
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/e$a;->E([I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-ltz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return p1

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    sget-object p1, Landroid/util/StateSet;->WILD_CARD:[I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/e$a;->E([I)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p1
.end method

.method K(II)I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-static {p1, p2}, Landroidx/appcompat/graphics/drawable/a$c;->H(II)J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-wide/16 v1, -0x1

    const/4 v4, 0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p2, v1}, Landroidx/collection/h;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast p1, Ljava/lang/Long;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    long-to-int p1, p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    return p1
.end method

.method L(II)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, p2}, Landroidx/appcompat/graphics/drawable/a$c;->H(II)J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, p1, p2, v1}, Landroidx/collection/h;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast p1, Ljava/lang/Long;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-wide v0, 0x100000000L

    const-wide v0, 0x100000000L

    const/4 v4, 0x3

    const-wide v0, 0x100000000L

    const-wide v0, 0x100000000L

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    and-long/2addr p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    cmp-long p1, p1, v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 p1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    return p1
.end method

.method M(II)Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, p2}, Landroidx/appcompat/graphics/drawable/a$c;->H(II)J

    move-result-wide p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x4

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v3, 0x5

    or-int/2addr v4, v3

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1, p2, v1}, Landroidx/collection/h;->i(JLjava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    check-cast p1, Ljava/lang/Long;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-wide v0, 0x200000000L

    const/4 v4, 0x0

    const-wide v0, 0x200000000L

    const-wide v0, 0x200000000L

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    and-long/2addr p1, v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    cmp-long p1, p1, v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return p1
.end method

.method public newDrawable()Landroid/graphics/drawable/Drawable;
    .locals 4
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Landroidx/appcompat/graphics/drawable/a;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x0

    and-int/2addr v3, v1

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-direct {v0, p0, v1}, Landroidx/appcompat/graphics/drawable/a;-><init>(Landroidx/appcompat/graphics/drawable/a$c;Landroid/content/res/Resources;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Landroidx/appcompat/graphics/drawable/a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0, p0, p1}, Landroidx/appcompat/graphics/drawable/a;-><init>(Landroidx/appcompat/graphics/drawable/a$c;Landroid/content/res/Resources;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method v()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/collection/h;->c()Landroidx/collection/h;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->K:Landroidx/collection/h;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/collection/n;->c()Landroidx/collection/n;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/a$c;->L:Landroidx/collection/n;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method
