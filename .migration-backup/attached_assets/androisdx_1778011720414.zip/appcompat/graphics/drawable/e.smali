.class Landroidx/appcompat/graphics/drawable/e;
.super Landroidx/appcompat/graphics/drawable/b;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "RestrictedAPI"
    }
.end annotation

.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/graphics/drawable/e$a;
    }
.end annotation


# static fields
.field private static final r:Ljava/lang/String; = "StateListDrawable"

.field private static final s:Z


# instance fields
.field private p:Landroidx/appcompat/graphics/drawable/e$a;

.field private q:Z


# direct methods
.method constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    move v1, v0

    move v1, v0

    const/4 v2, 0x7

    invoke-direct {p0, v0, v0}, Landroidx/appcompat/graphics/drawable/e;-><init>(Landroidx/appcompat/graphics/drawable/e$a;Landroid/content/res/Resources;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method constructor <init>(Landroidx/appcompat/graphics/drawable/e$a;)V
    .locals 2
    .param p1    # Landroidx/appcompat/graphics/drawable/e$a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->i(Landroidx/appcompat/graphics/drawable/b$d;)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method constructor <init>(Landroidx/appcompat/graphics/drawable/e$a;Landroid/content/res/Resources;)V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/b;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    new-instance v0, Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v1, 0x6

    move v2, v1

    invoke-direct {v0, p1, p0, p2}, Landroidx/appcompat/graphics/drawable/e$a;-><init>(Landroidx/appcompat/graphics/drawable/e$a;Landroidx/appcompat/graphics/drawable/e;Landroid/content/res/Resources;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/e;->i(Landroidx/appcompat/graphics/drawable/b$d;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->onStateChange([I)Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method private w(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " ~s @ ~~ .@r@@o~@fo@co@bnli~@ @o  @t~f~4~@@i~  ~~b~-~ ~ ooKM@m /vau1~y  S@/~@d@b i~@s~@~t@ @~~~ "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v2, 0x1

    move v8, v2

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    add-int/2addr v1, v2

    :cond_0
    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eq v3, v2, :cond_8

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-ge v4, v1, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v5, 0x3

    const/4 v8, 0x2

    if-eq v3, v5, :cond_8

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v5, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-eq v3, v5, :cond_2

    const/4 v8, 0x1

    goto :goto_0

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-gt v4, v1, :cond_0

    const/4 v7, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v4, "mtie"

    const-string/jumbo v4, "ietm"

    const/4 v8, 0x1

    const-string/jumbo v4, "imet"

    const-string/jumbo v4, "item"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    if-nez v3, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_0

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    sget-object v3, Landroidx/appcompat/resources/R$styleable;->StateListDrawableItem:[I

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {p2, p5, p4, v3}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget v4, Landroidx/appcompat/resources/R$styleable;->StateListDrawableItem_android_drawable:I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v6, -0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v3, v4, v6}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-lez v4, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {}, Landroidx/appcompat/widget/z1;->h()Landroidx/appcompat/widget/z1;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v6, p1, v4}, Landroidx/appcompat/widget/z1;->j(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_1

    :cond_4
    const/4 v8, 0x4

    const/4 v4, 0x0

    const/4 v8, 0x1

    move v7, v4

    :goto_1
    const/4 v8, 0x1

    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p0, p4}, Landroidx/appcompat/graphics/drawable/e;->p(Landroid/util/AttributeSet;)[I

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-nez v4, :cond_7

    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v6, 0x4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ne v4, v6, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_2

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-ne v4, v5, :cond_6

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p2, p3, p4, p5}, Lg/a$c;->a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_3

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo p3, "ltami/t lac/eter/ge/fibbr<samwir  giqaeeu iddeestb ho:  aawnrg >nl  dri adatrtu"

    const-string p3, " /s/ lia:ueadla/twidgraetrii  aa  di hrmgqrb>aeue esc <nttltatga/e  bredrfnwboi"

    const/4 v8, 0x6

    const-string/jumbo p3, "luaqoge/g> enrniu/la wr atdtteih:ttgii r b/ aafamr as/rdc ei<rde  eiwtaolba  be"

    const-string p3, ": <item> tag requires a \'drawable\' attribute or child tag defining a drawable"

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    throw p1

    :cond_7
    :goto_3
    const/4 v8, 0x3

    invoke-virtual {v0, v3, v4}, Landroidx/appcompat/graphics/drawable/e$a;->D([ILandroid/graphics/drawable/Drawable;)I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto/16 :goto_0

    :cond_8
    const/4 v8, 0x1

    return-void
.end method

.method private x(Landroid/content/res/TypedArray;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p1}, Lg/a$c;->b(Landroid/content/res/TypedArray;)I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    or-int/2addr v1, v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    sget v1, Landroidx/appcompat/resources/R$styleable;->StateListDrawable_android_variablePadding:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    sget v1, Landroidx/appcompat/resources/R$styleable;->StateListDrawable_android_constantSize:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-boolean v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget v1, Landroidx/appcompat/resources/R$styleable;->StateListDrawable_android_enterFadeDuration:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget v1, Landroidx/appcompat/resources/R$styleable;->StateListDrawable_android_exitFadeDuration:I

    const/4 v3, 0x7

    move v4, v3

    iget v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v4, 0x4

    sget v1, Landroidx/appcompat/resources/R$styleable;->StateListDrawable_android_dither:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v4, 0x5

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-boolean p1, v0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method


# virtual methods
.method public applyTheme(Landroid/content/res/Resources$Theme;)V
    .locals 2
    .param p1    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->applyTheme(Landroid/content/res/Resources$Theme;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->onStateChange([I)Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method

.method b()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->b()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/e;->q:Z

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-void
.end method

.method bridge synthetic c()Landroidx/appcompat/graphics/drawable/b$d;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/e;->o()Landroidx/appcompat/graphics/drawable/e$a;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method i(Landroidx/appcompat/graphics/drawable/b$d;)V
    .locals 3
    .param p1    # Landroidx/appcompat/graphics/drawable/b$d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->i(Landroidx/appcompat/graphics/drawable/b$d;)V

    const/4 v2, 0x3

    instance-of v0, p1, Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast p1, Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public isStateful()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/e;->q:Z

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-ne v0, p0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/e$a;->v()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/e;->q:Z

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object p0
.end method

.method public n([ILandroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p2, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Landroidx/appcompat/graphics/drawable/e$a;->D([ILandroid/graphics/drawable/Drawable;)I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->onStateChange([I)Z

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method o()Landroidx/appcompat/graphics/drawable/e$a;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v1, p0, v2}, Landroidx/appcompat/graphics/drawable/e$a;-><init>(Landroidx/appcompat/graphics/drawable/e$a;Landroidx/appcompat/graphics/drawable/e;Landroid/content/res/Resources;)V

    return-object v0
.end method

.method protected onStateChange([I)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->onStateChange([I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, p1}, Landroidx/appcompat/graphics/drawable/e$a;->E([I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    if-gez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v1, Landroid/util/StateSet;->WILD_CARD:[I

    invoke-virtual {p1, v1}, Landroidx/appcompat/graphics/drawable/e$a;->E([I)I

    move-result p1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->h(I)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v3, 0x4

    const/4 p1, 0x2

    const/4 v3, 0x5

    const/4 p1, 0x1

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p1
.end method

.method p(Landroid/util/AttributeSet;)[I
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-interface {p1}, Landroid/util/AttributeSet;->getAttributeCount()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    new-array v1, v0, [I

    const/4 v8, 0x3

    move v9, v8

    const/4 v2, 0x0

    move v9, v2

    const/4 v8, 0x2

    move v9, v8

    move v3, v2

    move v3, v2

    const/4 v9, 0x7

    move v3, v2

    move v3, v2

    const/4 v9, 0x4

    const/4 v8, 0x5

    move v4, v3

    move v4, v3

    const/4 v9, 0x4

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-ge v3, v0, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-interface {p1, v3}, Landroid/util/AttributeSet;->getAttributeNameResource(I)I

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    if-eqz v5, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    const v6, 0x10100d0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eq v5, v6, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const v6, 0x1010199

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eq v5, v6, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    add-int/lit8 v6, v4, 0x1

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-interface {p1, v3, v2}, Landroid/util/AttributeSet;->getAttributeBooleanValue(IZ)Z

    move-result v7

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v7, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    goto :goto_1

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    neg-int v5, v5

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    aput v5, v1, v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    move v4, v6

    move v4, v6

    const/4 v9, 0x0

    move v4, v6

    move v4, v6

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    goto :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v1, v4}, Landroid/util/StateSet;->trimStateSet([II)[I

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    return-object p1
.end method

.method q()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/b$d;->i()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method r(I)Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/b$d;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object p1
.end method

.method s([I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/e$a;->E([I)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p1
.end method

.method t()Landroidx/appcompat/graphics/drawable/e$a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method u(I)[I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/e;->p:Landroidx/appcompat/graphics/drawable/e$a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, v0, Landroidx/appcompat/graphics/drawable/e$a;->J:[[I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    aget-object p1, v0, p1

    const/4 v2, 0x2

    return-object p1
.end method

.method public v(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v0, Landroidx/appcompat/resources/R$styleable;->StateListDrawable:[I

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    invoke-static {p2, p5, p4, v0}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget v1, Landroidx/appcompat/resources/R$styleable;->StateListDrawable_android_visible:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0, v1, v2}, Landroidx/appcompat/graphics/drawable/b;->setVisible(ZZ)Z

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/e;->x(Landroid/content/res/TypedArray;)V

    const/4 v4, 0x4

    invoke-virtual {p0, p2}, Landroidx/appcompat/graphics/drawable/b;->m(Landroid/content/res/Resources;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct/range {p0 .. p5}, Landroidx/appcompat/graphics/drawable/e;->w(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->onStateChange([I)Z

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    return-void
.end method
