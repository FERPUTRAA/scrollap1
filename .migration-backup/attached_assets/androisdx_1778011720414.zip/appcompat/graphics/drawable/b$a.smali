.class Landroidx/appcompat/graphics/drawable/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/graphics/drawable/b;->h(I)Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/graphics/drawable/b;


# direct methods
.method constructor <init>(Landroidx/appcompat/graphics/drawable/b;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/b$a;->a:Landroidx/appcompat/graphics/drawable/b;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s@ ~@ @@ @ @  ~@~io~@  b@a@l@ ~o /b~/c4~obKv @-lM~tso~~y~~~@fdi r~.in~St  ~fo~@1 @@~ ~@@~o~~mu"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$a;->a:Landroidx/appcompat/graphics/drawable/b;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Landroidx/appcompat/graphics/drawable/b;->a(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/b$a;->a:Landroidx/appcompat/graphics/drawable/b;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method
