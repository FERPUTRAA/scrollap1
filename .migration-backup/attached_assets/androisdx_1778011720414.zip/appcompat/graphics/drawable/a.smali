.class public Landroidx/appcompat/graphics/drawable/a;
.super Landroidx/appcompat/graphics/drawable/e;

# interfaces
.implements Landroidx/core/graphics/drawable/k;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "RestrictedAPI"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/graphics/drawable/a$f;,
        Landroidx/appcompat/graphics/drawable/a$c;,
        Landroidx/appcompat/graphics/drawable/a$d;,
        Landroidx/appcompat/graphics/drawable/a$e;,
        Landroidx/appcompat/graphics/drawable/a$b;,
        Landroidx/appcompat/graphics/drawable/a$g;
    }
.end annotation


# static fields
.field private static final A:Ljava/lang/String; = "item"

.field private static final B:Ljava/lang/String; = ": <transition> tag requires a \'drawable\' attribute or child tag defining a drawable"

.field private static final C:Ljava/lang/String; = ": <transition> tag requires \'fromId\' & \'toId\' attributes"

.field private static final D:Ljava/lang/String; = ": <item> tag requires a \'drawable\' attribute or child tag defining a drawable"

.field private static final y:Ljava/lang/String; = "a"

.field private static final z:Ljava/lang/String; = "transition"


# instance fields
.field private t:Landroidx/appcompat/graphics/drawable/a$c;

.field private u:Landroidx/appcompat/graphics/drawable/a$g;

.field private v:I

.field private w:I

.field private x:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x5

    and-int/2addr v2, v1

    invoke-direct {p0, v0, v0}, Landroidx/appcompat/graphics/drawable/a;-><init>(Landroidx/appcompat/graphics/drawable/a$c;Landroid/content/res/Resources;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method constructor <init>(Landroidx/appcompat/graphics/drawable/a$c;Landroid/content/res/Resources;)V
    .locals 3
    .param p1    # Landroidx/appcompat/graphics/drawable/a$c;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/e;-><init>(Landroidx/appcompat/graphics/drawable/e$a;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v1, 0x6

    move v2, v1

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p1, p0, p2}, Landroidx/appcompat/graphics/drawable/a$c;-><init>(Landroidx/appcompat/graphics/drawable/a$c;Landroidx/appcompat/graphics/drawable/a;Landroid/content/res/Resources;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/a;->i(Landroidx/appcompat/graphics/drawable/b$d;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/a;->onStateChange([I)Z

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/a;->jumpToCurrentState()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static B(Landroid/content/Context;ILandroid/content/res/Resources$Theme;)Landroidx/appcompat/graphics/drawable/a;
    .locals 8
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/v;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "b s~~  @@ @~ t~/ 1i@~~ @M~ vt @@i@oS~@r.n@~b~ ~fadoc@obo ~~@@@~@~-l@ ~mo 4~f Ki~~@luo sy @~~@ /@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    const-string/jumbo v0, "r smsrropere"

    const-string/jumbo v0, "resrrr psore"

    const/4 v7, 0x0

    const-string/jumbo v0, "orrsore epar"

    const-string/jumbo v0, "parser error"

    :try_start_0
    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v1, p1}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v2

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v4, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eq v3, v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v5, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eq v3, v5, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ne v3, v4, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p0, v1, p1, v2, p2}, Landroidx/appcompat/graphics/drawable/a;->C(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/appcompat/graphics/drawable/a;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    return-object p0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string p1, "foattbNntmu  or ag"

    const-string/jumbo p1, "natmu r of Ntgdtoa"

    const/4 v7, 0x6

    const-string p1, " gus rudtao Ntoaft"

    const-string p1, "No start tag found"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    throw p0
    :try_end_0
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-object p1, Landroidx/appcompat/graphics/drawable/a;->y:Ljava/lang/String;

    const/4 v7, 0x4

    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_1

    :catch_1
    move-exception p0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    sget-object p1, Landroidx/appcompat/graphics/drawable/a;->y:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 p0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object p0
.end method

.method public static C(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/appcompat/graphics/drawable/a;
    .locals 10
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lorg/xmlpull/v1/XmlPullParserException;
        }
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string/jumbo v1, "omseeacpol-tiernd"

    const-string v1, "einaomcrelsdaeto-"

    const/4 v9, 0x2

    const-string v1, "etatmrelq-oaecnsd"

    const-string v1, "animated-selector"

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz v1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance v0, Landroidx/appcompat/graphics/drawable/a;

    const/4 v8, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v0}, Landroidx/appcompat/graphics/drawable/a;-><init>()V

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v6, p3

    move-object v7, p4

    move-object v7, p4

    move-object v7, p4

    move-object v7, p4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual/range {v2 .. v7}, Landroidx/appcompat/graphics/drawable/a;->v(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-object v0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {p2}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string p2, "desatiimcol :vgtdeann e- ta ibls"

    const-string/jumbo p2, "le :dbnet aienco-  ltadasmgvitai"

    const/4 v9, 0x1

    const-string p2, ": invalid animated-selector tag "

    const/4 v8, 0x5

    shl-int/2addr v9, v8

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x6

    invoke-direct {p0, p1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    throw p0
.end method

.method private D()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/a;->onStateChange([I)Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private E(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v0, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableItem:[I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p2, p5, p4, v0}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableItem_android_id:I

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget v2, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableItem_android_drawable:I

    const/4 v4, 0x1

    or-int/2addr v5, v4

    const/4 v3, -0x1

    and-int/2addr v5, v3

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v3}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-lez v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-static {}, Landroidx/appcompat/widget/z1;->h()Landroidx/appcompat/widget/z1;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v3, p1, v2}, Landroidx/appcompat/widget/z1;->j(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0, p4}, Landroidx/appcompat/graphics/drawable/e;->p(Landroid/util/AttributeSet;)[I

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const-string v2, "h/amre t eeaatri:lrsdc wmt ef>bl atat/i ug dd/w  enatabrgirirnil/ugei <ad ueo q"

    const-string v2, "aaq reubt alomdr/ rhnitbut  rg  fareg  ig i>i<e/ :dewbdaiiec adlstne/t/rawuatel"

    const/4 v5, 0x6

    const-string/jumbo v2, "radqoe:>mfiurrcada/s end  bt  i/ba <tiiwahuatnll/ lad   grrwii/ae egeebrtoaetg "

    const-string v2, ": <item> tag requires a \'drawable\' attribute or child tag defining a drawable"

    const/4 v5, 0x4

    if-nez p1, :cond_4

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v3, 0x4

    shr-int/2addr v5, v3

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    if-ne p1, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_1

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v3, 0x2

    const/4 v5, 0x0

    if-ne p1, v3, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string v3, "cvtepb"

    const-string v3, "eptcov"

    const/4 v5, 0x6

    const-string/jumbo v3, "uervto"

    const-string/jumbo v3, "vector"

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    invoke-static {p2, p3, p4, p5}, Landroidx/vectordrawable/graphics/drawable/i;->f(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/vectordrawable/graphics/drawable/i;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    goto :goto_2

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p2, p3, p4, p5}, Lg/a$c;->a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_2

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v4, 0x4

    move v5, v4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    throw p1

    :cond_4
    :goto_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz p1, :cond_5

    const/4 v5, 0x6

    iget-object p2, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p2, v0, p1, v1}, Landroidx/appcompat/graphics/drawable/a$c;->F([ILandroid/graphics/drawable/Drawable;I)I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    return p1

    :cond_5
    const/4 v5, 0x7

    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p1
.end method

.method private F(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I
    .locals 9
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    sget-object v0, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableTransition:[I

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p2, p5, p4, v0}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableTransition_android_fromId:I

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v2, -0x1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    sget v3, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableTransition_android_toId:I

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    sget v4, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableTransition_android_drawable:I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v0, v4, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-lez v4, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {}, Landroidx/appcompat/widget/z1;->h()Landroidx/appcompat/widget/z1;

    move-result-object v5

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v5, p1, v4}, Landroidx/appcompat/widget/z1;->j(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x3

    sget v5, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableTransition_android_reversible:I

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x4

    invoke-virtual {v0, v5, v6}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string v0, "/rtf rdpgo /ods stteildwlrraai qe<abqtae:di rneuaeb/  tgauwrcibain igna l/t  ana h>ie"

    const-string v0, "drrairhnqa tei /tas /l>/g on /i actble: eqardrot gs eita fuidrabdl etai<unigwwtbn eaa"

    const/4 v8, 0x6

    const-string/jumbo v0, "ra/wieauqiebwboirrd /aret agtn qaaio hdbelc:<ndat geetag rt r lasilusr di>t  /in/ tnf"

    const-string v0, ": <transition> tag requires a \'drawable\' attribute or child tag defining a drawable"

    const/4 v8, 0x0

    const/4 v7, 0x7

    if-nez v4, :cond_4

    :goto_1
    const/4 v8, 0x3

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v6, 0x4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-ne v4, v6, :cond_1

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ne v4, v6, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v6, "trstasdveaoicem"

    const-string v6, "atsmrdecvetnaio"

    const/4 v8, 0x5

    const-string/jumbo v6, "ndemtaveiormta-"

    const-string v6, "animated-vector"

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz v4, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {p1, p2, p3, p4, p5}, Landroidx/vectordrawable/graphics/drawable/c;->f(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroidx/vectordrawable/graphics/drawable/c;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto :goto_2

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {p2, p3, p4, p5}, Lg/a$c;->a(Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    goto :goto_2

    :cond_3
    const/4 v8, 0x7

    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    move v8, v7

    throw p1

    :cond_4
    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v4, :cond_6

    const/4 v8, 0x6

    const/4 v7, 0x1

    if-eq v1, v2, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eq v3, v2, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    iget-object p1, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1, v1, v3, v4, v5}, Landroidx/appcompat/graphics/drawable/a$c;->G(IILandroid/graphics/drawable/Drawable;Z)I

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    return p1

    :cond_5
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string p3, "at<note as&todn/q  r/ rti tiomrgIuItsae/i//>/r //m:isted buo"

    const-string p3, "gram/ uto/a i// srtont Is>neurtoi<d/i traemIb://ted&  srtq/i"

    const/4 v8, 0x3

    const-string p3, ":tgnabb/rs aIet>//dasn/i<I urru s/mtei/ tt fioqo/r&/tei o td"

    const-string p3, ": <transition> tag requires \'fromId\' & \'toId\' attributes"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    move v8, v7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    throw p1

    :cond_6
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const/4 v7, 0x7

    or-int/2addr v8, v7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getPositionDescription()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {p1, p2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    throw p1
.end method

.method private G(I)Z
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->u:Landroidx/appcompat/graphics/drawable/a$g;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-eqz v0, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget v2, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-ne p1, v2, :cond_0

    const/4 v10, 0x6

    return v1

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget v2, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-ne p1, v2, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/a$g;->a()Z

    move-result v2

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz v2, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/a$g;->b()V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget v0, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x4

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    iput p1, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    return v1

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget v2, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/a$g;->d()V

    const/4 v9, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_0

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b;->d()I

    move-result v2

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/4 v0, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x3

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->u:Landroidx/appcompat/graphics/drawable/a$g;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v0, -0x5

    const/4 v0, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v10, 0x5

    const/4 v9, 0x6

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v0, v2}, Landroidx/appcompat/graphics/drawable/a$c;->I(I)I

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/a$c;->I(I)I

    move-result v4

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v5, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-eqz v4, :cond_7

    const/4 v9, 0x0

    const/4 v9, 0x1

    if-nez v3, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto/16 :goto_2

    :cond_3
    const/4 v9, 0x3

    move v10, v9

    invoke-virtual {v0, v3, v4}, Landroidx/appcompat/graphics/drawable/a$c;->K(II)I

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-gez v6, :cond_4

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    return v5

    :cond_4
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v0, v3, v4}, Landroidx/appcompat/graphics/drawable/a$c;->M(II)Z

    move-result v7

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p0, v6}, Landroidx/appcompat/graphics/drawable/b;->h(I)Z

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/a;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    instance-of v8, v6, Landroid/graphics/drawable/AnimationDrawable;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-eqz v8, :cond_5

    const/4 v10, 0x1

    invoke-virtual {v0, v3, v4}, Landroidx/appcompat/graphics/drawable/a$c;->L(II)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance v3, Landroidx/appcompat/graphics/drawable/a$e;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    check-cast v6, Landroid/graphics/drawable/AnimationDrawable;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {v3, v6, v0, v7}, Landroidx/appcompat/graphics/drawable/a$e;-><init>(Landroid/graphics/drawable/AnimationDrawable;ZZ)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_1

    :cond_5
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    instance-of v0, v6, Landroidx/vectordrawable/graphics/drawable/c;

    const/4 v10, 0x4

    const/4 v9, 0x5

    if-eqz v0, :cond_6

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-instance v3, Landroidx/appcompat/graphics/drawable/a$d;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    check-cast v6, Landroidx/vectordrawable/graphics/drawable/c;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {v3, v6}, Landroidx/appcompat/graphics/drawable/a$d;-><init>(Landroidx/vectordrawable/graphics/drawable/c;)V

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_1

    :cond_6
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x3

    instance-of v0, v6, Landroid/graphics/drawable/Animatable;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz v0, :cond_7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    new-instance v3, Landroidx/appcompat/graphics/drawable/a$b;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x6

    check-cast v6, Landroid/graphics/drawable/Animatable;

    const/4 v10, 0x3

    invoke-direct {v3, v6}, Landroidx/appcompat/graphics/drawable/a$b;-><init>(Landroid/graphics/drawable/Animatable;)V

    :goto_1
    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v3}, Landroidx/appcompat/graphics/drawable/a$g;->c()V

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput-object v3, p0, Landroidx/appcompat/graphics/drawable/a;->u:Landroidx/appcompat/graphics/drawable/a$g;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput v2, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    const/4 v9, 0x3

    or-int/2addr v10, v9

    iput p1, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x6

    return v1

    :cond_7
    :goto_2
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    return v5
.end method

.method private w(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 7
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    add-int/2addr v0, v1

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eq v2, v1, :cond_5

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ge v3, v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v4, 0x3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eq v2, v4, :cond_5

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v4, 0x2

    const/4 v6, 0x6

    if-eq v2, v4, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-le v3, v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v3, "mite"

    const-string/jumbo v3, "imet"

    const/4 v6, 0x7

    const-string v3, "etim"

    const-string/jumbo v3, "item"

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v2, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct/range {p0 .. p5}, Landroidx/appcompat/graphics/drawable/a;->E(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_0

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {p3}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v3, "sniinourta"

    const-string/jumbo v3, "nnisoartio"

    const/4 v6, 0x0

    const-string/jumbo v3, "tnroaitpsn"

    const-string/jumbo v3, "transition"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct/range {p0 .. p5}, Landroidx/appcompat/graphics/drawable/a;->F(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)I

    const/4 v6, 0x0

    const/4 v5, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void
.end method

.method private x(Landroid/content/res/TypedArray;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v3, 0x1

    move v4, v3

    iget v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v4, 0x4

    invoke-static {p1}, Lg/a$c;->b(Landroid/content/res/TypedArray;)I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    or-int/2addr v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v1, v0, Landroidx/appcompat/graphics/drawable/b$d;->d:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat_android_variablePadding:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->i:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/graphics/drawable/b$d;->B(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat_android_constantSize:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-boolean v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->l:Z

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroidx/appcompat/graphics/drawable/b$d;->x(Z)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat_android_enterFadeDuration:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->A:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroidx/appcompat/graphics/drawable/b$d;->y(I)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat_android_exitFadeDuration:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v2, v0, Landroidx/appcompat/graphics/drawable/b$d;->B:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroidx/appcompat/graphics/drawable/b$d;->z(I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat_android_dither:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-boolean v0, v0, Landroidx/appcompat/graphics/drawable/b$d;->x:Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/a;->setDither(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method


# virtual methods
.method A()Landroidx/appcompat/graphics/drawable/a$c;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    const/4 v2, 0x0

    shr-int/2addr v4, v2

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0, v1, p0, v2}, Landroidx/appcompat/graphics/drawable/a$c;-><init>(Landroidx/appcompat/graphics/drawable/a$c;Landroidx/appcompat/graphics/drawable/a;Landroid/content/res/Resources;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object v0
.end method

.method public bridge synthetic applyTheme(Landroid/content/res/Resources$Theme;)V
    .locals 2
    .param p1    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->applyTheme(Landroid/content/res/Resources$Theme;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method b()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/e;->b()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    move v2, v1

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/a;->x:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method bridge synthetic c()Landroidx/appcompat/graphics/drawable/b$d;
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/a;->A()Landroidx/appcompat/graphics/drawable/a$c;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public bridge synthetic canApplyTheme()Z
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->canApplyTheme()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public bridge synthetic draw(Landroid/graphics/Canvas;)V
    .locals 2
    .param p1    # Landroid/graphics/Canvas;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->draw(Landroid/graphics/Canvas;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic getAlpha()I
    .locals 3

    const/4 v2, 0x5

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getAlpha()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public bridge synthetic getChangingConfigurations()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getChangingConfigurations()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public bridge synthetic getCurrent()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic getHotspotBounds(Landroid/graphics/Rect;)V
    .locals 2
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->getHotspotBounds(Landroid/graphics/Rect;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic getIntrinsicHeight()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getIntrinsicHeight()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic getIntrinsicWidth()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getIntrinsicWidth()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public bridge synthetic getMinimumHeight()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getMinimumHeight()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    return v0
.end method

.method public bridge synthetic getMinimumWidth()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getMinimumWidth()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public bridge synthetic getOpacity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->getOpacity()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public bridge synthetic getOutline(Landroid/graphics/Outline;)V
    .locals 2
    .param p1    # Landroid/graphics/Outline;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x15
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->getOutline(Landroid/graphics/Outline;)V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public bridge synthetic getPadding(Landroid/graphics/Rect;)Z
    .locals 2
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->getPadding(Landroid/graphics/Rect;)Z

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method i(Landroidx/appcompat/graphics/drawable/b$d;)V
    .locals 3
    .param p1    # Landroidx/appcompat/graphics/drawable/b$d;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/e;->i(Landroidx/appcompat/graphics/drawable/b$d;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    instance-of v0, p1, Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    move v2, v1

    check-cast p1, Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public bridge synthetic invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic isAutoMirrored()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->isAutoMirrored()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public isStateful()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public jumpToCurrentState()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/b;->jumpToCurrentState()V

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->u:Landroidx/appcompat/graphics/drawable/a$g;

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/a$g;->d()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->u:Landroidx/appcompat/graphics/drawable/a$g;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/b;->h(I)Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->v:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput v0, p0, Landroidx/appcompat/graphics/drawable/a;->w:I

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public bridge synthetic k(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->k(I)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic l(I)V
    .locals 2

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->l(I)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method

.method public mutate()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/graphics/drawable/a;->x:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v1, 0x7

    const/4 v1, 0x5

    invoke-super {p0}, Landroidx/appcompat/graphics/drawable/e;->mutate()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-ne v0, p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {v0}, Landroidx/appcompat/graphics/drawable/a$c;->v()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean v0, p0, Landroidx/appcompat/graphics/drawable/a;->x:Z

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0
.end method

.method public bridge synthetic n([ILandroid/graphics/drawable/Drawable;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-super {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/e;->n([ILandroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x2

    return-void
.end method

.method bridge synthetic o()Landroidx/appcompat/graphics/drawable/e$a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/a;->A()Landroidx/appcompat/graphics/drawable/a$c;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public bridge synthetic onLayoutDirectionChanged(I)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->onLayoutDirectionChanged(I)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return p1
.end method

.method protected onStateChange([I)Z
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Landroidx/appcompat/graphics/drawable/a$c;->J([I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/b;->d()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eq v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/a;->G(I)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroidx/appcompat/graphics/drawable/b;->h(I)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/a;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    or-int/2addr v0, p1

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0
.end method

.method public bridge synthetic scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroidx/appcompat/graphics/drawable/b;->scheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;J)V

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic setAlpha(I)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->setAlpha(I)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic setAutoMirrored(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->setAutoMirrored(Z)V

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic setColorFilter(Landroid/graphics/ColorFilter;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->setColorFilter(Landroid/graphics/ColorFilter;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public bridge synthetic setDither(Z)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->setDither(Z)V

    const/4 v0, 0x5

    move v1, v0

    return-void
.end method

.method public bridge synthetic setHotspot(FF)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/b;->setHotspot(FF)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public bridge synthetic setHotspotBounds(IIII)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Landroidx/appcompat/graphics/drawable/b;->setHotspotBounds(IIII)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public bridge synthetic setTintList(Landroid/content/res/ColorStateList;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->setTintList(Landroid/content/res/ColorStateList;)V

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public bridge synthetic setTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .locals 2
    .param p1    # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/graphics/drawable/b;->setTintMode(Landroid/graphics/PorterDuff$Mode;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public setVisible(ZZ)Z
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-super {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/b;->setVisible(ZZ)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/appcompat/graphics/drawable/a;->u:Landroidx/appcompat/graphics/drawable/a$g;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz p2, :cond_2

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroidx/appcompat/graphics/drawable/a$g;->c()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/graphics/drawable/a;->jumpToCurrentState()V

    :cond_2
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public bridge synthetic unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V
    .locals 2
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Runnable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-super {p0, p1, p2}, Landroidx/appcompat/graphics/drawable/b;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;Ljava/lang/Runnable;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public v(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/res/Resources;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Lorg/xmlpull/v1/XmlPullParser;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p5    # Landroid/content/res/Resources$Theme;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lorg/xmlpull/v1/XmlPullParserException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object v0, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat:[I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p2, p5, p4, v0}, Landroidx/core/content/res/n;->s(Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat_android_visible:I

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0, v1, v2}, Landroidx/appcompat/graphics/drawable/a;->setVisible(ZZ)Z

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/a;->x(Landroid/content/res/TypedArray;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0, p2}, Landroidx/appcompat/graphics/drawable/b;->m(Landroid/content/res/Resources;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct/range {p0 .. p5}, Landroidx/appcompat/graphics/drawable/a;->w(Landroid/content/Context;Landroid/content/res/Resources;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/content/res/Resources$Theme;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0}, Landroidx/appcompat/graphics/drawable/a;->D()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method public y([ILandroid/graphics/drawable/Drawable;I)V
    .locals 3
    .param p1    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2, p3}, Landroidx/appcompat/graphics/drawable/a$c;->F([ILandroid/graphics/drawable/Drawable;I)I

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->getState()[I

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/graphics/drawable/a;->onStateChange([I)Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string/jumbo p2, "stluweuaqm l o Dnalnbtreb"

    const-string/jumbo p2, "urullbntltbD eaoenbaws m "

    const/4 v2, 0x3

    const-string p2, " uswl treob Dnmn tuaseall"

    const-string p2, "Drawable must not be null"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    throw p1
.end method

.method public z(IILandroid/graphics/drawable/Drawable;Z)V
    .locals 3
    .param p3    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroid/graphics/drawable/Drawable;",
            ":",
            "Landroid/graphics/drawable/Animatable;",
            ">(IITT;Z)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eqz p3, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a;->t:Landroidx/appcompat/graphics/drawable/a$c;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2, p3, p4}, Landroidx/appcompat/graphics/drawable/a$c;->G(IILandroid/graphics/drawable/Drawable;Z)I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo p2, "u rmnu wsiulolsTtnbd ao li nbaentrma"

    const-string/jumbo p2, "n ornwul ndnulibt Tumrolsatbaisat  e"

    const/4 v2, 0x6

    const-string/jumbo p2, "lurnob rTtnb mi wlot tleaannaoidssue"

    const-string p2, "Transition drawable must not be null"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw p1
.end method
