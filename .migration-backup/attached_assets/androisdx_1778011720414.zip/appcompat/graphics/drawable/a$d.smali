.class Landroidx/appcompat/graphics/drawable/a$d;
.super Landroidx/appcompat/graphics/drawable/a$g;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/graphics/drawable/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# instance fields
.field private final a:Landroidx/vectordrawable/graphics/drawable/c;


# direct methods
.method constructor <init>(Landroidx/vectordrawable/graphics/drawable/c;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    move v1, v0

    move v1, v0

    invoke-direct {p0, v0}, Landroidx/appcompat/graphics/drawable/a$g;-><init>(Landroidx/appcompat/graphics/drawable/a$a;)V

    const/4 v2, 0x1

    iput-object p1, p0, Landroidx/appcompat/graphics/drawable/a$d;->a:Landroidx/vectordrawable/graphics/drawable/c;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public c()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$d;->a:Landroidx/vectordrawable/graphics/drawable/c;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/vectordrawable/graphics/drawable/c;->start()V

    const/4 v1, 0x5

    move v2, v1

    return-void
.end method

.method public d()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/graphics/drawable/a$d;->a:Landroidx/vectordrawable/graphics/drawable/c;

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {v0}, Landroidx/vectordrawable/graphics/drawable/c;->stop()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method
