.class Landroidx/appcompat/widget/SearchView$f;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/SearchView;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/SearchView;)V
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView$f;->a:Landroidx/appcompat/widget/SearchView;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~os4@@S@1@~@ @fsobd@@ .~-~ a~~yM~/r cl@~of~~o~@ m @ @~n~~tb@~K@v /  ~i oo~  @ ~ ~@@u@ii~ ~@ltb~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView$f;->a:Landroidx/appcompat/widget/SearchView;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, v0, Landroidx/appcompat/widget/SearchView;->F:Landroid/widget/ImageView;

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne p1, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->c0()V

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, v0, Landroidx/appcompat/widget/SearchView;->H:Landroid/widget/ImageView;

    const/4 v3, 0x3

    if-ne p1, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->Y()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, v0, Landroidx/appcompat/widget/SearchView;->G:Landroid/widget/ImageView;

    const/4 v2, 0x1

    move v3, v2

    if-ne p1, v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->d0()V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x3

    iget-object v1, v0, Landroidx/appcompat/widget/SearchView;->I:Landroid/widget/ImageView;

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne p1, v1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->h0()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_3
    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, v0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne p1, v1, :cond_4

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/widget/SearchView;->L()V

    :cond_4
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method
