.class public Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;
.super Landroidx/appcompat/widget/f1;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/MenuPopupWindow;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "MenuDropDownListView"
.end annotation


# instance fields
.field final q:I

.field final r:I

.field private s:Landroidx/appcompat/widget/w1;

.field private t:Landroid/view/MenuItem;


# direct methods
.method public constructor <init>(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/widget/f1;-><init>(Landroid/content/Context;Z)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p2, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/content/res/Configuration;->getLayoutDirection()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 v0, 0x15

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v1, 0x16

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne p2, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v0, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->q:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput v1, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->r:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput v1, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->q:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput v0, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->r:I

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public bridge synthetic d(IZ)I
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "4@s bm~l/~@ @ @M@@~ @i @@ Svt~/o~.@@oi@@ o~1- ~nK  @@l@tuba  ~ ~sy~~~~cr@io~bof o~~ @ ~~@ f~~~d~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/f1;->d(IZ)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic e(IIIII)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-super/range {p0 .. p5}, Landroidx/appcompat/widget/f1;->e(IIIII)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic f(Landroid/view/MotionEvent;I)Z
    .locals 2

    const/4 v1, 0x6

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/f1;->f(Landroid/view/MotionEvent;I)Z

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return p1
.end method

.method public bridge synthetic hasFocus()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-super {p0}, Landroidx/appcompat/widget/f1;->hasFocus()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public bridge synthetic hasWindowFocus()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-super {p0}, Landroidx/appcompat/widget/f1;->hasWindowFocus()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public bridge synthetic isFocused()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-super {p0}, Landroidx/appcompat/widget/f1;->isFocused()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    return v0
.end method

.method public bridge synthetic isInTouchMode()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-super {p0}, Landroidx/appcompat/widget/f1;->isInTouchMode()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public n()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/widget/AdapterView;->setSelection(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public onHoverEvent(Landroid/view/MotionEvent;)Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->s:Landroidx/appcompat/widget/w1;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    instance-of v1, v0, Landroid/widget/HeaderViewListAdapter;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    move v5, v4

    check-cast v0, Landroid/widget/HeaderViewListAdapter;

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v0}, Landroid/widget/HeaderViewListAdapter;->getHeadersCount()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast v0, Landroidx/appcompat/view/menu/f;

    const/4 v5, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    check-cast v0, Landroidx/appcompat/view/menu/f;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/16 v3, 0xa

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eq v2, v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    float-to-int v2, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    float-to-int v3, v3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0, v2, v3}, Landroid/widget/AbsListView;->pointToPosition(II)I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eq v2, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    sub-int/2addr v2, v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-ltz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->getCount()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ge v2, v1, :cond_1

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Landroidx/appcompat/view/menu/f;->d(I)Landroidx/appcompat/view/menu/j;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x2

    iget-object v2, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->t:Landroid/view/MenuItem;

    const/4 v4, 0x7

    const/4 v4, 0x1

    if-eq v2, v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/f;->b()Landroidx/appcompat/view/menu/g;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v3, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->s:Landroidx/appcompat/widget/w1;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {v3, v0, v2}, Landroidx/appcompat/widget/w1;->o(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v1, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->t:Landroid/view/MenuItem;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v2, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->s:Landroidx/appcompat/widget/w1;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v2, v0, v1}, Landroidx/appcompat/widget/w1;->e(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-super {p0, p1}, Landroidx/appcompat/widget/f1;->onHoverEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    return p1
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedView()Landroid/view/View;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    check-cast v0, Landroidx/appcompat/view/menu/ListMenuItemView;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget v2, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->q:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne p1, v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/view/View;->isEnabled()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/ListMenuItemView;->getItemData()Landroidx/appcompat/view/menu/j;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->hasSubMenu()Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/widget/AdapterView;->getSelectedItemId()J

    move-result-wide v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0, v0, p1, v2, v3}, Landroid/widget/AdapterView;->performItemClick(Landroid/view/View;IJ)Z

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x3

    return v1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget v0, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->r:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ne p1, v0, :cond_3

    const/4 v4, 0x7

    and-int/2addr v5, v4

    const/4 p1, -0x1

    or-int/2addr v5, p1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, p1}, Landroid/widget/AdapterView;->setSelection(I)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/widget/ListView;->getAdapter()Landroid/widget/ListAdapter;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    instance-of p2, p1, Landroid/widget/HeaderViewListAdapter;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz p2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast p1, Landroid/widget/HeaderViewListAdapter;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/widget/HeaderViewListAdapter;->getWrappedAdapter()Landroid/widget/ListAdapter;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast p1, Landroidx/appcompat/view/menu/f;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast p1, Landroidx/appcompat/view/menu/f;

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/f;->b()Landroidx/appcompat/view/menu/g;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 p2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Landroidx/appcompat/view/menu/g;->f(Z)V

    const/4 v5, 0x4

    return v1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-super {p0, p1, p2}, Landroid/widget/ListView;->onKeyDown(ILandroid/view/KeyEvent;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    return p1
.end method

.method public bridge synthetic onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-super {p0, p1}, Landroidx/appcompat/widget/f1;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p1
.end method

.method public setHoverListener(Landroidx/appcompat/widget/w1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->s:Landroidx/appcompat/widget/w1;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public bridge synthetic setSelector(Landroid/graphics/drawable/Drawable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-super {p0, p1}, Landroidx/appcompat/widget/f1;->setSelector(Landroid/graphics/drawable/Drawable;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method
