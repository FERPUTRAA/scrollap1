.class public Landroidx/appcompat/widget/Toolbar$e;
.super Landroidx/appcompat/app/a$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/Toolbar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "e"
.end annotation


# static fields
.field static final c:I = 0x0

.field static final d:I = 0x1

.field static final e:I = 0x2


# instance fields
.field b:I


# direct methods
.method public constructor <init>(I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v0, -0x2

    const/4 v0, -0x2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-direct {p0, v0, v1, p1}, Landroidx/appcompat/widget/Toolbar$e;-><init>(III)V

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/app/a$b;-><init>(II)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    const p1, 0x800013

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput p1, p0, Landroidx/appcompat/app/a$b;->a:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(III)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/app/a$b;-><init>(II)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 p1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p1, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    iput p3, p0, Landroidx/appcompat/app/a$b;->a:I

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/app/a$b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 p1, 0x0

    move v1, p1

    const/4 v0, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Landroidx/appcompat/app/a$b;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p1, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Landroidx/appcompat/app/a$b;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput v0, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/Toolbar$e;->a(Landroid/view/ViewGroup$MarginLayoutParams;)V

    return-void
.end method

.method public constructor <init>(Landroidx/appcompat/app/a$b;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Landroidx/appcompat/app/a$b;-><init>(Landroidx/appcompat/app/a$b;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p1, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroidx/appcompat/widget/Toolbar$e;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Landroidx/appcompat/app/a$b;-><init>(Landroidx/appcompat/app/a$b;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput v0, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget p1, p1, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v1, 0x5

    move v2, v1

    iput p1, p0, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method a(Landroid/view/ViewGroup$MarginLayoutParams;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~s@~-~ /lta~v ~~@@@@d @~@@  ~~4@oto~u~f~i@~K ~ o r ~ @@ @ obmS@bn~@M f@~b@1ici @o@ ~/l~ ~.@o~s "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput v0, p0, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget p1, p1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput p1, p0, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method
