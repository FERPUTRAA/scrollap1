.class Landroidx/appcompat/widget/ActionMenuPresenter;
.super Landroidx/appcompat/view/menu/b;

# interfaces
.implements Landroidx/core/view/b$a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/ActionMenuPresenter$b;,
        Landroidx/appcompat/widget/ActionMenuPresenter$c;,
        Landroidx/appcompat/widget/ActionMenuPresenter$f;,
        Landroidx/appcompat/widget/ActionMenuPresenter$a;,
        Landroidx/appcompat/widget/ActionMenuPresenter$e;,
        Landroidx/appcompat/widget/ActionMenuPresenter$d;,
        Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;
    }
.end annotation


# static fields
.field private static final E:Ljava/lang/String; = "ActionMenuPresenter"


# instance fields
.field A:Landroidx/appcompat/widget/ActionMenuPresenter$c;

.field private B:Landroidx/appcompat/widget/ActionMenuPresenter$b;

.field final C:Landroidx/appcompat/widget/ActionMenuPresenter$f;

.field D:I

.field k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

.field private l:Landroid/graphics/drawable/Drawable;

.field private m:Z

.field private n:Z

.field private o:Z

.field private p:I

.field private q:I

.field private r:I

.field private s:Z

.field private t:Z

.field private u:Z

.field private v:Z

.field private w:I

.field private final x:Landroid/util/SparseBooleanArray;

.field y:Landroidx/appcompat/widget/ActionMenuPresenter$e;

.field z:Landroidx/appcompat/widget/ActionMenuPresenter$a;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget v0, Landroidx/appcompat/R$layout;->abc_action_menu_layout:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget v1, Landroidx/appcompat/R$layout;->abc_action_menu_item_layout:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0, p1, v0, v1}, Landroidx/appcompat/view/menu/b;-><init>(Landroid/content/Context;II)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance p1, Landroid/util/SparseBooleanArray;

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-direct {p1}, Landroid/util/SparseBooleanArray;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->x:Landroid/util/SparseBooleanArray;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p1, Landroidx/appcompat/widget/ActionMenuPresenter$f;

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-direct {p1, p0}, Landroidx/appcompat/widget/ActionMenuPresenter$f;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->C:Landroidx/appcompat/widget/ActionMenuPresenter$f;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic A(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/o;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~ ~~@ @al@m@~@@@yf  @ ~~s~-@~ ibv@ ~n@o~M~ ~b~@ ~~fc b@i  oo /o@@ld /o@4@utr@.~ ~@SKi ~t~~@o1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method private C(Landroid/view/MenuItem;)Landroid/view/View;
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-nez v0, :cond_0

    const/4 v7, 0x7

    return-object v1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v3, 0x0

    xor-int/2addr v7, v3

    :goto_0
    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ge v3, v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    instance-of v5, v4, Landroidx/appcompat/view/menu/o$a;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v5, :cond_1

    move-object v5, v4

    move-object v5, v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    check-cast v5, Landroidx/appcompat/view/menu/o$a;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-interface {v5}, Landroidx/appcompat/view/menu/o$a;->getItemData()Landroidx/appcompat/view/menu/j;

    move-result-object v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-ne v5, p1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-object v4

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-object v1
.end method

.method static synthetic u(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic v(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic w(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/o;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic x(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x0

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic y(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic z(Landroidx/appcompat/widget/ActionMenuPresenter;)Landroidx/appcompat/view/menu/g;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public B()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->E()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->F()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    or-int/2addr v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v0
.end method

.method public D()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->m:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v1, 0x6

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->l:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public E()Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->A:Landroidx/appcompat/widget/ActionMenuPresenter$c;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v2, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    check-cast v2, Landroid/view/View;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v2, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->A:Landroidx/appcompat/widget/ActionMenuPresenter$c;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->y:Landroidx/appcompat/widget/ActionMenuPresenter$e;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/m;->dismiss()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    return v1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    return v0
.end method

.method public F()Z
    .locals 3

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->z:Landroidx/appcompat/widget/ActionMenuPresenter$a;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/m;->dismiss()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    return v0
.end method

.method public G()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->A:Landroidx/appcompat/widget/ActionMenuPresenter$c;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->H()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    move v2, v1

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public H()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->y:Landroidx/appcompat/widget/ActionMenuPresenter$e;

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/m;->f()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public I()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public J(Landroid/content/res/Configuration;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->s:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1}, Landroidx/appcompat/view/a;->b(Landroid/content/Context;)Landroidx/appcompat/view/a;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->d()I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->r:I

    :cond_0
    const/4 v1, 0x1

    move v2, v1

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public K(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->v:Z

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public L(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->r:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->s:Z

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public M(Landroidx/appcompat/widget/ActionMenuView;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/ActionMenuView;->a(Landroidx/appcompat/view/menu/g;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public N(Landroid/graphics/drawable/Drawable;)V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/AppCompatImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->m:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->l:Landroid/graphics/drawable/Drawable;

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public O(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->o:Z

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public P(IZ)V
    .locals 2

    const/4 v1, 0x5

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->p:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-boolean p2, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->t:Z

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->u:Z

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public Q()Z
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    const/4 v8, 0x4

    const/4 v7, 0x7

    if-eqz v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->H()Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-nez v0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    iget-object v1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-eqz v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->A:Landroidx/appcompat/widget/ActionMenuPresenter$c;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-nez v1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-nez v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v0, Landroidx/appcompat/widget/ActionMenuPresenter$e;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v4, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v8, 0x6

    iget-object v5, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-direct/range {v1 .. v6}, Landroidx/appcompat/widget/ActionMenuPresenter$e;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;Landroid/content/Context;Landroidx/appcompat/view/menu/g;Landroid/view/View;Z)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance v1, Landroidx/appcompat/widget/ActionMenuPresenter$c;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {v1, p0, v0}, Landroidx/appcompat/widget/ActionMenuPresenter$c;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;Landroidx/appcompat/widget/ActionMenuPresenter$e;)V

    const/4 v8, 0x1

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->A:Landroidx/appcompat/widget/ActionMenuPresenter$c;

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    check-cast v0, Landroid/view/View;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v0, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    return v0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    return v0
.end method

.method public a(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/b;->g(Landroidx/appcompat/view/menu/s;)Z

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->f(Z)V

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public c(Landroidx/appcompat/view/menu/g;Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->B()Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/b;->c(Landroidx/appcompat/view/menu/g;Z)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public f(Landroid/os/Parcelable;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    instance-of v0, p1, Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p1, Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget p1, p1, Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-lez p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Landroidx/appcompat/view/menu/g;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {p1}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p1, Landroidx/appcompat/view/menu/s;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionMenuPresenter;->g(Landroidx/appcompat/view/menu/s;)Z

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public g(Landroidx/appcompat/view/menu/s;)Z
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->hasVisibleItems()Z

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x4

    return v1

    :cond_0
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/s;->n0()Landroid/view/Menu;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eq v2, v3, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/s;->n0()Landroid/view/Menu;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    check-cast v0, Landroidx/appcompat/view/menu/s;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto :goto_0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/s;->getItem()Landroid/view/MenuItem;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->C(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-nez v0, :cond_2

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    return v1

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/s;->getItem()Landroid/view/MenuItem;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-interface {v2}, Landroid/view/MenuItem;->getItemId()I

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput v2, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->D:I

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->size()I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    move v3, v1

    move v3, v1

    const/4 v8, 0x6

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v4, 0x1

    const/4 v8, 0x6

    if-ge v3, v2, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1, v3}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {v5}, Landroid/view/MenuItem;->isVisible()Z

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x7

    if-eqz v6, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-interface {v5}, Landroid/view/MenuItem;->getIcon()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x4

    if-eqz v5, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    move v1, v4

    move v1, v4

    const/4 v8, 0x3

    move v1, v4

    move v1, v4

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_2

    :cond_3
    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x4

    goto :goto_1

    :cond_4
    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v2, Landroidx/appcompat/widget/ActionMenuPresenter$a;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v3, p0, Landroidx/appcompat/view/menu/b;->b:Landroid/content/Context;

    const/4 v7, 0x3

    move v8, v7

    invoke-direct {v2, p0, v3, p1, v0}, Landroidx/appcompat/widget/ActionMenuPresenter$a;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;Landroid/content/Context;Landroidx/appcompat/view/menu/s;Landroid/view/View;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    iput-object v2, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->z:Landroidx/appcompat/widget/ActionMenuPresenter$a;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v2, v1}, Landroidx/appcompat/view/menu/m;->i(Z)V

    const/4 v7, 0x7

    move v8, v7

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->z:Landroidx/appcompat/widget/ActionMenuPresenter$a;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/view/menu/m;->l()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/b;->g(Landroidx/appcompat/view/menu/s;)Z

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    return v4
.end method

.method public h(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/b;->h(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eq v0, p1, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast v0, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/ActionMenuView;->setPresenter(Landroidx/appcompat/widget/ActionMenuPresenter;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method public i()Landroid/os/Parcelable;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->D:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput v1, v0, Landroidx/appcompat/widget/ActionMenuPresenter$SavedState;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method public j(Z)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-super {p0, p1}, Landroidx/appcompat/view/menu/b;->j(Z)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    check-cast p1, Landroid/view/View;

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->v()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    move v2, v0

    move v2, v0

    const/4 v5, 0x7

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-ge v2, v1, :cond_1

    const/4 v5, 0x2

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    check-cast v3, Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/j;->a()Landroidx/core/view/b;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v3, p0}, Landroidx/core/view/b;->k(Landroidx/core/view/b$a;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->C()Ljava/util/ArrayList;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 p1, 0x0

    const/4 p1, 0x0

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-boolean v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    const/4 v5, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    if-eqz p1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-ne v1, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    check-cast p1, Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isActionViewExpanded()Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    xor-int/lit8 v0, p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_2

    :cond_3
    if-lez v1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x0

    move v0, v2

    move v0, v2

    const/4 v5, 0x5

    move v0, v2

    move v0, v2

    :cond_4
    :goto_2
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez p1, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance p1, Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->a:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {p1, p0, v0}, Landroidx/appcompat/widget/ActionMenuPresenter$d;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;Landroid/content/Context;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    :cond_5
    const/4 v5, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    check-cast p1, Landroid/view/ViewGroup;

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eq p1, v0, :cond_8

    const/4 v4, 0x6

    or-int/2addr v5, v4

    if-eqz p1, :cond_6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v5, 0x0

    const/4 v4, 0x0

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/widget/ActionMenuView;->J()Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_3

    :cond_7
    const/4 v5, 0x6

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz p1, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v5, 0x1

    if-ne p1, v0, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    check-cast v0, Landroid/view/ViewGroup;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_8
    :goto_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/ActionMenuView;->setOverflowReserved(Z)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-void
.end method

.method public k()Z
    .locals 20

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    iget-object v1, v0, Landroidx/appcompat/view/menu/b;->c:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    invoke-virtual {v1}, Landroidx/appcompat/view/menu/g;->H()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    goto :goto_0

    :cond_0
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_0
    iget v5, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->r:I

    iget v6, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->q:I

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    iget-object v8, v0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    check-cast v8, Landroid/view/ViewGroup;

    move v9, v3

    move v9, v3

    move v9, v3

    move v9, v3

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    move v11, v10

    move v11, v10

    move v11, v10

    move v11, v10

    move v12, v11

    move v12, v11

    move v12, v11

    move v12, v11

    :goto_1
    if-ge v9, v4, :cond_4

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Landroidx/appcompat/view/menu/j;

    invoke-virtual {v14}, Landroidx/appcompat/view/menu/j;->b()Z

    move-result v15

    if-eqz v15, :cond_1

    add-int/lit8 v11, v11, 0x1

    goto :goto_2

    :cond_1
    invoke-virtual {v14}, Landroidx/appcompat/view/menu/j;->q()Z

    move-result v15

    if-eqz v15, :cond_2

    add-int/lit8 v12, v12, 0x1

    goto :goto_2

    :cond_2
    const/4 v10, 0x1

    :goto_2
    iget-boolean v13, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->v:Z

    if-eqz v13, :cond_3

    invoke-virtual {v14}, Landroidx/appcompat/view/menu/j;->isActionViewExpanded()Z

    move-result v13

    if-eqz v13, :cond_3

    move v5, v3

    move v5, v3

    :cond_3
    add-int/lit8 v9, v9, 0x1

    goto :goto_1

    :cond_4
    iget-boolean v9, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    if-eqz v9, :cond_6

    if-nez v10, :cond_5

    add-int/2addr v12, v11

    if-le v12, v5, :cond_6

    :cond_5
    add-int/lit8 v5, v5, -0x1

    :cond_6
    sub-int/2addr v5, v11

    iget-object v9, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->x:Landroid/util/SparseBooleanArray;

    invoke-virtual {v9}, Landroid/util/SparseBooleanArray;->clear()V

    iget-boolean v10, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->t:Z

    if-eqz v10, :cond_7

    iget v10, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->w:I

    div-int v11, v6, v10

    rem-int v12, v6, v10

    div-int/2addr v12, v11

    add-int/2addr v10, v12

    goto :goto_3

    :cond_7
    move v10, v3

    move v10, v3

    move v10, v3

    move v10, v3

    move v11, v10

    move v11, v10

    move v11, v10

    move v11, v10

    :goto_3
    move v12, v3

    move v12, v3

    move v12, v3

    move v12, v3

    move v14, v12

    move v14, v12

    move v14, v12

    move v14, v12

    :goto_4
    if-ge v12, v4, :cond_1b

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroidx/appcompat/view/menu/j;

    invoke-virtual {v15}, Landroidx/appcompat/view/menu/j;->b()Z

    move-result v16

    if-eqz v16, :cond_b

    invoke-virtual {v0, v15, v2, v8}, Landroidx/appcompat/widget/ActionMenuPresenter;->r(Landroidx/appcompat/view/menu/j;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v13

    iget-boolean v2, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->t:Z

    if-eqz v2, :cond_8

    invoke-static {v13, v10, v11, v7, v3}, Landroidx/appcompat/widget/ActionMenuView;->P(Landroid/view/View;IIII)I

    move-result v2

    sub-int/2addr v11, v2

    goto :goto_5

    :cond_8
    invoke-virtual {v13, v7, v7}, Landroid/view/View;->measure(II)V

    :goto_5
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    sub-int/2addr v6, v2

    if-nez v14, :cond_9

    move v14, v2

    move v14, v2

    move v14, v2

    move v14, v2

    :cond_9
    invoke-virtual {v15}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v2

    const/4 v13, 0x1

    if-eqz v2, :cond_a

    invoke-virtual {v9, v2, v13}, Landroid/util/SparseBooleanArray;->put(IZ)V

    :cond_a
    invoke-virtual {v15, v13}, Landroidx/appcompat/view/menu/j;->x(Z)V

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    goto/16 :goto_c

    :cond_b
    invoke-virtual {v15}, Landroidx/appcompat/view/menu/j;->q()Z

    move-result v2

    if-eqz v2, :cond_1a

    invoke-virtual {v15}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v2

    invoke-virtual {v9, v2}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v13

    if-gtz v5, :cond_c

    if-eqz v13, :cond_e

    :cond_c
    if-lez v6, :cond_e

    iget-boolean v3, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->t:Z

    if-eqz v3, :cond_d

    if-lez v11, :cond_e

    :cond_d
    const/4 v3, 0x1

    goto :goto_6

    :cond_e
    const/4 v3, 0x0

    :goto_6
    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    if-eqz v3, :cond_14

    const/4 v3, 0x0

    invoke-virtual {v0, v15, v3, v8}, Landroidx/appcompat/widget/ActionMenuPresenter;->r(Landroidx/appcompat/view/menu/j;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v4

    iget-boolean v3, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->t:Z

    if-eqz v3, :cond_f

    const/4 v3, 0x0

    invoke-static {v4, v10, v11, v7, v3}, Landroidx/appcompat/widget/ActionMenuView;->P(Landroid/view/View;IIII)I

    move-result v19

    sub-int v11, v11, v19

    if-nez v19, :cond_10

    const/16 v18, 0x0

    goto :goto_7

    :cond_f
    invoke-virtual {v4, v7, v7}, Landroid/view/View;->measure(II)V

    :cond_10
    :goto_7
    move/from16 v3, v18

    move/from16 v3, v18

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    sub-int/2addr v6, v4

    if-nez v14, :cond_11

    move v14, v4

    move v14, v4

    move v14, v4

    move v14, v4

    :cond_11
    iget-boolean v4, v0, Landroidx/appcompat/widget/ActionMenuPresenter;->t:Z

    if-eqz v4, :cond_12

    if-ltz v6, :cond_13

    goto :goto_8

    :cond_12
    add-int v4, v6, v14

    if-lez v4, :cond_13

    :goto_8
    const/4 v4, 0x1

    goto :goto_9

    :cond_13
    const/4 v4, 0x0

    :goto_9
    and-int/2addr v3, v4

    :cond_14
    if-eqz v3, :cond_15

    if-eqz v2, :cond_15

    const/4 v4, 0x1

    invoke-virtual {v9, v2, v4}, Landroid/util/SparseBooleanArray;->put(IZ)V

    goto :goto_b

    :cond_15
    if-eqz v13, :cond_18

    const/4 v4, 0x0

    invoke-virtual {v9, v2, v4}, Landroid/util/SparseBooleanArray;->put(IZ)V

    const/4 v4, 0x0

    :goto_a
    if-ge v4, v12, :cond_18

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroidx/appcompat/view/menu/j;

    invoke-virtual {v13}, Landroidx/appcompat/view/menu/j;->getGroupId()I

    move-result v0

    if-ne v0, v2, :cond_17

    invoke-virtual {v13}, Landroidx/appcompat/view/menu/j;->o()Z

    move-result v0

    if-eqz v0, :cond_16

    add-int/lit8 v5, v5, 0x1

    :cond_16
    const/4 v0, 0x0

    invoke-virtual {v13, v0}, Landroidx/appcompat/view/menu/j;->x(Z)V

    :cond_17
    add-int/lit8 v4, v4, 0x1

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    goto :goto_a

    :cond_18
    :goto_b
    if-eqz v3, :cond_19

    add-int/lit8 v5, v5, -0x1

    :cond_19
    invoke-virtual {v15, v3}, Landroidx/appcompat/view/menu/j;->x(Z)V

    const/4 v0, 0x0

    goto :goto_c

    :cond_1a
    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    invoke-virtual {v15, v0}, Landroidx/appcompat/view/menu/j;->x(Z)V

    :goto_c
    add-int/lit8 v12, v12, 0x1

    move v3, v0

    move v3, v0

    move v3, v0

    move/from16 v4, v17

    move/from16 v4, v17

    move/from16 v4, v17

    const/4 v2, 0x0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    goto/16 :goto_4

    :cond_1b
    const/4 v2, 0x1

    return v2
.end method

.method public m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V
    .locals 6
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/b;->m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1}, Landroidx/appcompat/view/a;->b(Landroid/content/Context;)Landroidx/appcompat/view/a;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->o:Z

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->h()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->u:Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->c()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->p:I

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->s:Z

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->d()I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->r:I

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->p:I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->n:Z

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v0, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v0, Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v2, p0, Landroidx/appcompat/view/menu/b;->a:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v0, p0, v2}, Landroidx/appcompat/widget/ActionMenuPresenter$d;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-boolean v2, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->m:Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x0

    move v5, v3

    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-eqz v2, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x7

    iget-object v2, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->l:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Landroidx/appcompat/widget/AppCompatImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->l:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-boolean v3, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->m:Z

    :cond_3
    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v3, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, v0, v0}, Landroid/view/View;->measure(II)V

    :cond_4
    const/4 v5, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    sub-int/2addr p1, v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->q:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/high16 p2, 0x42600000    # 56.0f

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    mul-float/2addr p1, p2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    float-to-int p1, p1

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->w:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method

.method public n(Landroidx/appcompat/view/menu/j;Landroidx/appcompat/view/menu/o$a;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-interface {p2, p1, v0}, Landroidx/appcompat/view/menu/o$a;->d(Landroidx/appcompat/view/menu/j;I)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/view/menu/b;->i:Landroidx/appcompat/view/menu/o;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p2, Landroidx/appcompat/view/menu/ActionMenuItemView;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/ActionMenuItemView;->setItemInvoker(Landroidx/appcompat/view/menu/g$b;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->B:Landroidx/appcompat/widget/ActionMenuPresenter$b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    new-instance p1, Landroidx/appcompat/widget/ActionMenuPresenter$b;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p1, p0}, Landroidx/appcompat/widget/ActionMenuPresenter$b;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->B:Landroidx/appcompat/widget/ActionMenuPresenter$b;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->B:Landroidx/appcompat/widget/ActionMenuPresenter$b;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/ActionMenuItemView;->setPopupCallback(Landroidx/appcompat/view/menu/ActionMenuItemView$b;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public p(Landroid/view/ViewGroup;I)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/ActionMenuPresenter;->k:Landroidx/appcompat/widget/ActionMenuPresenter$d;

    const/4 v3, 0x0

    const/4 v2, 0x1

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-super {p0, p1, p2}, Landroidx/appcompat/view/menu/b;->p(Landroid/view/ViewGroup;I)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1
.end method

.method public r(Landroidx/appcompat/view/menu/j;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->getActionView()Landroid/view/View;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->m()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    :cond_0
    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-super {p0, p1, p2, p3}, Landroidx/appcompat/view/menu/b;->r(Landroidx/appcompat/view/menu/j;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    :cond_1
    const/4 v3, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/j;->isActionViewExpanded()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/16 p1, 0x8

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast p3, Landroidx/appcompat/widget/ActionMenuView;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p3, p1}, Landroidx/appcompat/widget/ActionMenuView;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p2, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {p3, p1}, Landroidx/appcompat/widget/ActionMenuView;->I(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_3
    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0
.end method

.method public t(ILandroidx/appcompat/view/menu/j;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p2}, Landroidx/appcompat/view/menu/j;->o()Z

    move-result p1

    const/4 v1, 0x4

    return p1
.end method
