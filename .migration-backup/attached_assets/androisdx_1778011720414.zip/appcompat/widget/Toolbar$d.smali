.class Landroidx/appcompat/widget/Toolbar$d;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/appcompat/view/menu/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/Toolbar;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "d"
.end annotation


# instance fields
.field a:Landroidx/appcompat/view/menu/g;

.field b:Landroidx/appcompat/view/menu/j;

.field final synthetic c:Landroidx/appcompat/widget/Toolbar;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/Toolbar;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public c(Landroidx/appcompat/view/menu/g;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s ~otfi4  / @~ ~ .@~@M @@1/@@mr@@s b~~la~@ ~o@i@~cK~@~~f ~yo~@@~v@ itl~no @ bo~~ u@dS -~ ~b ~~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-void
.end method

.method public d(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->g()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->h:Landroid/widget/ImageButton;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eq p1, v0, :cond_1

    const/4 v4, 0x0

    instance-of v1, p1, Landroid/view/ViewGroup;

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->h:Landroid/widget/ImageButton;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->h:Landroid/widget/ImageButton;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2}, Landroidx/appcompat/view/menu/j;->getActionView()Landroid/view/View;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-object v0, p1, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-object p2, p0, Landroidx/appcompat/widget/Toolbar$d;->b:Landroidx/appcompat/view/menu/j;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eq p1, v0, :cond_3

    const/4 v4, 0x3

    instance-of v1, p1, Landroid/view/ViewGroup;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    check-cast p1, Landroid/view/ViewGroup;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->m()Landroidx/appcompat/widget/Toolbar$e;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v1, v0, Landroidx/appcompat/widget/Toolbar;->n:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    and-int/lit8 v1, v1, 0x70

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    const v2, 0x800003

    const/4 v3, 0x4

    move v4, v3

    or-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v1, p1, Landroidx/appcompat/app/a$b;->a:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput v1, p1, Landroidx/appcompat/widget/Toolbar$e;->b:I

    const/4 v4, 0x3

    iget-object v0, v0, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->I()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x1

    and-int/2addr v3, p1

    const/4 v4, 0x6

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/j;->t(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object p2, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p2, p2, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    instance-of v0, p2, Landroidx/appcompat/view/c;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    check-cast p2, Landroidx/appcompat/view/c;

    const/4 v4, 0x2

    invoke-interface {p2}, Landroidx/appcompat/view/c;->c()V

    :cond_4
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    return p1
.end method

.method public e(Landroidx/appcompat/view/menu/n$a;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public f(Landroid/os/Parcelable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public g(Landroidx/appcompat/view/menu/s;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return p1
.end method

.method public getId()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    return v0
.end method

.method public h(Landroid/view/ViewGroup;)Landroidx/appcompat/view/menu/o;
    .locals 2

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-object p1
.end method

.method public i()Landroid/os/Parcelable;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public j(Z)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->b:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->a:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/view/menu/g;->size()I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    move v1, v0

    move v1, v0

    const/4 v5, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-ge v1, p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Landroidx/appcompat/widget/Toolbar$d;->a:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Landroidx/appcompat/view/menu/g;->getItem(I)Landroid/view/MenuItem;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    iget-object v3, p0, Landroidx/appcompat/widget/Toolbar$d;->b:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ne v2, v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v4, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->a:Landroidx/appcompat/view/menu/g;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$d;->b:Landroidx/appcompat/view/menu/j;

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/widget/Toolbar$d;->l(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void
.end method

.method public k()Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public l(Landroidx/appcompat/view/menu/g;Landroidx/appcompat/view/menu/j;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p1, p1, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    instance-of v0, p1, Landroidx/appcompat/view/c;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p1, Landroidx/appcompat/view/c;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-interface {p1}, Landroidx/appcompat/view/c;->h()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x7

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-object v0, p1, Landroidx/appcompat/widget/Toolbar;->h:Landroid/widget/ImageButton;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    iput-object v0, p1, Landroidx/appcompat/widget/Toolbar;->i:Landroid/view/View;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/widget/Toolbar;->a()V

    const/4 v1, 0x6

    move v2, v1

    iput-object v0, p0, Landroidx/appcompat/widget/Toolbar$d;->b:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->c:Landroidx/appcompat/widget/Toolbar;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/view/View;->requestLayout()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p2, p1}, Landroidx/appcompat/view/menu/j;->t(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method public m(Landroid/content/Context;Landroidx/appcompat/view/menu/g;)V
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/Toolbar$d;->a:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/Toolbar$d;->b:Landroidx/appcompat/view/menu/j;

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroidx/appcompat/view/menu/g;->g(Landroidx/appcompat/view/menu/j;)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p2, p0, Landroidx/appcompat/widget/Toolbar$d;->a:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method
