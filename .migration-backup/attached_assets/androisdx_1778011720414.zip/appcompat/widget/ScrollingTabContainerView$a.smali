.class Landroidx/appcompat/widget/ScrollingTabContainerView$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroidx/appcompat/widget/ScrollingTabContainerView;->c(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/view/View;

.field final synthetic b:Landroidx/appcompat/widget/ScrollingTabContainerView;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/ScrollingTabContainerView;Landroid/view/View;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->b:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v1, 0x6

    const/4 v0, 0x3

    iput-object p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->a:Landroid/view/View;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s@t@ i ~ M~-@@ ~u~ov~ @a~tb@c o   Kos / fm@ @@@~l. ~~@r~4@~@ diyf~@@ ~oSbo~~i n~ol~/@~ b1@@~~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->a:Landroid/view/View;

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->b:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->a:Landroid/view/View;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v2}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    sub-int/2addr v1, v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    div-int/lit8 v1, v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    sub-int/2addr v0, v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->b:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v0, v2}, Landroid/widget/HorizontalScrollView;->smoothScrollTo(II)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;->b:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-object v1, v0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    const/4 v4, 0x7

    return-void
.end method
