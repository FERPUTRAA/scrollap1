.class Landroidx/appcompat/widget/ScrollingTabContainerView$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/ScrollingTabContainerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/ScrollingTabContainerView;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/ScrollingTabContainerView;)V
    .locals 2

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$c;->a:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 7

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast v0, Landroidx/appcompat/widget/ScrollingTabContainerView$d;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/widget/ScrollingTabContainerView$d;->b()Landroidx/appcompat/app/a$f;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/app/a$f;->g()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$c;->a:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v0, v0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    move v2, v1

    move v2, v1

    const/4 v6, 0x4

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-ge v2, v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v3, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$c;->a:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v3, v3, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v6, 0x0

    const/4 v5, 0x3

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne v3, p1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    move v4, v1

    move v4, v1

    const/4 v6, 0x7

    move v4, v1

    move v4, v1

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Landroid/view/View;->setSelected(Z)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void
.end method
