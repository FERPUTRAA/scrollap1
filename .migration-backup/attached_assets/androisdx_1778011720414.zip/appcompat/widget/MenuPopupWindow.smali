.class public Landroidx/appcompat/widget/MenuPopupWindow;
.super Landroidx/appcompat/widget/v1;

# interfaces
.implements Landroidx/appcompat/widget/w1;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;
    }
.end annotation


# static fields
.field private static final U:Ljava/lang/String; = "MenuPopupWindow"

.field private static V:Ljava/lang/reflect/Method;


# instance fields
.field private T:Landroidx/appcompat/widget/w1;


# direct methods
.method static constructor <clinit>()V
    .locals 7

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/16 v1, 0x1c

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-gt v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-class v0, Landroid/widget/PopupWindow;

    const-class v0, Landroid/widget/PopupWindow;

    const/4 v6, 0x7

    const-class v0, Landroid/widget/PopupWindow;

    const-class v0, Landroid/widget/PopupWindow;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v1, "odslhusTcaste"

    const-string v1, "assTlchedouot"

    const/4 v6, 0x7

    const-string v1, "etomaudlohMTc"

    const-string/jumbo v1, "setTouchModal"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v2, 0x1

    const/4 v6, 0x4

    new-array v2, v2, [Ljava/lang/Class;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget-object v3, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x3

    aput-object v3, v2, v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    sput-object v0, Landroidx/appcompat/widget/MenuPopupWindow;->V:Ljava/lang/reflect/Method;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :catch_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v0, "dWenoPpiowuupoM"

    const-string v0, "euPmWMoiupowpdn"

    const/4 v6, 0x3

    const-string v0, "ewpWuboudpnnPio"

    const-string v0, "MenuPopupWindow"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v1, "iudadeu lW.hC odohw i)lt fh uoo.Mooelsd l nutwncdtnmno (PeTOop"

    const-string v1, "hTnCo.n ctdleufw )WPho.toph olie dlw  ne(udtodliOnaosoouMmdo  "

    const/4 v6, 0x5

    const-string/jumbo v1, "tho ofdpdTel enmoiowP s.lMuuedlo.pt  )pdohCda(out winl nOnc oW"

    const-string v1, "Could not find method setTouchModal() on PopupWindow. Oh well."

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 2
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3, p4}, Landroidx/appcompat/widget/v1;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public e(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
    .locals 3
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f~@@ @~~q@~@ ~df@  ~1@ M o-@o~ ~o~mo @4 t /~@~~o~/.@ b~il~ ry@~@  ~Ki@@ba@t~nS~s~v@@ ~@l ~u ob@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Landroidx/appcompat/widget/MenuPopupWindow;->T:Landroidx/appcompat/widget/w1;

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/widget/w1;->e(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public o(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V
    .locals 3
    .param p1    # Landroidx/appcompat/view/menu/g;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/MenuItem;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/MenuPopupWindow;->T:Landroidx/appcompat/widget/w1;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/widget/w1;->o(Landroidx/appcompat/view/menu/g;Landroid/view/MenuItem;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public o0(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/v1;->F:Landroid/widget/PopupWindow;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p1, Landroid/transition/Transition;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/widget/PopupWindow;->setEnterTransition(Landroid/transition/Transition;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public p0(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/v1;->F:Landroid/widget/PopupWindow;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p1, Landroid/transition/Transition;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/widget/PopupWindow;->setExitTransition(Landroid/transition/Transition;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public q0(Landroidx/appcompat/widget/w1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/MenuPopupWindow;->T:Landroidx/appcompat/widget/w1;

    const/4 v0, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public r0(Z)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/16 v1, 0x1c

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-gt v0, v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v0, Landroidx/appcompat/widget/MenuPopupWindow;->V:Ljava/lang/reflect/Method;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Landroidx/appcompat/widget/v1;->F:Landroid/widget/PopupWindow;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x5

    aput-object p1, v2, v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo p1, "nusbPnpMoWowipd"

    const-string p1, "PinuWbonopwpMud"

    const/4 v5, 0x0

    const-string/jumbo p1, "ieomdpwPuuWMnno"

    const-string p1, "MenuPopupWindow"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v0, "dletoc ohn v MiCdwoaOodul.  htpuw )o ukn(iuosoPTlp.leoonW"

    const-string/jumbo v0, "lMe t uwnudounplo( olkno ilaohsc.p.iehTu OvPWwt ododC)on "

    const-string/jumbo v0, "locePbTnwoon e(otuv dtoOw ) u olulkapoWshn oMdi npi.l.ehC"

    const-string v0, "Could not invoke setTouchModal() on PopupWindow. Oh well."

    const/4 v5, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/v1;->F:Landroid/widget/PopupWindow;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v0, p1}, Landroidx/appcompat/widget/x1;->a(Landroid/widget/PopupWindow;Z)V

    :cond_1
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void
.end method

.method t(Landroid/content/Context;Z)Landroidx/appcompat/widget/f1;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2}, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;-><init>(Landroid/content/Context;Z)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/MenuPopupWindow$MenuDropDownListView;->setHoverListener(Landroidx/appcompat/widget/w1;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method
