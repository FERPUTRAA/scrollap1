.class public Landroidx/appcompat/widget/ActionMenuView;
.super Landroidx/appcompat/widget/LinearLayoutCompat;

# interfaces
.implements Landroidx/appcompat/view/menu/g$b;
.implements Landroidx/appcompat/view/menu/o;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/ActionMenuView$c;,
        Landroidx/appcompat/widget/ActionMenuView$a;,
        Landroidx/appcompat/widget/ActionMenuView$b;,
        Landroidx/appcompat/widget/ActionMenuView$d;,
        Landroidx/appcompat/widget/ActionMenuView$e;
    }
.end annotation


# static fields
.field private static final N:Ljava/lang/String; = "ActionMenuView"

.field static final O:I = 0x38

.field static final P:I = 0x4


# instance fields
.field private B:Landroidx/appcompat/view/menu/g;

.field private C:Landroid/content/Context;

.field private D:I

.field private E:Z

.field private F:Landroidx/appcompat/widget/ActionMenuPresenter;

.field private G:Landroidx/appcompat/view/menu/n$a;

.field H:Landroidx/appcompat/view/menu/g$a;

.field private I:Z

.field private J:I

.field private K:I

.field private L:I

.field M:Landroidx/appcompat/widget/ActionMenuView$e;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/widget/ActionMenuView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x3

    const/4 p2, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;->setBaselineAligned(Z)V

    const/4 v3, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/high16 v1, 0x42600000    # 56.0f

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    mul-float/2addr v1, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    float-to-int v1, v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v1, p0, Landroidx/appcompat/widget/ActionMenuView;->K:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/high16 v1, 0x40800000    # 4.0f

    const/4 v3, 0x6

    mul-float/2addr v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    float-to-int v0, v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput v0, p0, Landroidx/appcompat/widget/ActionMenuView;->L:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->C:Landroid/content/Context;

    const/4 v3, 0x3

    iput p2, p0, Landroidx/appcompat/widget/ActionMenuView;->D:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method static P(Landroid/view/View;IIII)I
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "m~s~o~@ani@o ~s@~o@ S d4@~  ~y1@ M@~  Kl -b~~b@@ /.@ @~~ lco@@~@   @i~toi~@r~u ~b@~v~ fo~t@f/@~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast v0, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p3}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    sub-int/2addr v1, p4

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p3}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v1, p3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    instance-of p4, p0, Landroidx/appcompat/view/menu/ActionMenuItemView;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz p4, :cond_0

    move-object p4, p0

    move-object p4, p0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    check-cast p4, Landroidx/appcompat/view/menu/ActionMenuItemView;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 p4, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v1, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x4

    if-eqz p4, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p4}, Landroidx/appcompat/view/menu/ActionMenuItemView;->h()Z

    move-result p4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz p4, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    move p4, v1

    move p4, v1

    const/4 v6, 0x1

    move p4, v1

    move p4, v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_1

    :cond_1
    const/4 v6, 0x3

    move p4, v2

    move p4, v2

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-lez p2, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz p4, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x4

    if-lt p2, v3, :cond_5

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    mul-int/2addr p2, p1

    const/high16 v4, -0x80000000

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p2, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0, p2, p3}, Landroid/view/View;->measure(II)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    div-int v4, p2, p1

    const/4 v6, 0x7

    rem-int/2addr p2, p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eqz p2, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    add-int/lit8 v4, v4, 0x1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz p4, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ge v4, v3, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_2

    :cond_4
    const/4 v6, 0x5

    move v3, v4

    const/4 v6, 0x1

    move v3, v4

    move v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    goto :goto_2

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    move v3, v2

    move v3, v2

    const/4 v6, 0x3

    move v3, v2

    move v3, v2

    :goto_2
    const/4 v6, 0x7

    iget-boolean p2, v0, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    const/4 v6, 0x7

    const/4 v5, 0x6

    if-nez p2, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz p4, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_3

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v1, v2

    move v1, v2

    const/4 v6, 0x3

    move v1, v2

    move v1, v2

    :goto_3
    const/4 v6, 0x7

    const/4 v5, 0x2

    iput-boolean v1, v0, Landroidx/appcompat/widget/ActionMenuView$c;->d:Z

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput v3, v0, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    mul-int/2addr p1, v3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/high16 p2, 0x40000000    # 2.0f

    const/4 v6, 0x2

    invoke-static {p1, p2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0, p1, p3}, Landroid/view/View;->measure(II)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    return v3
.end method

.method private Q(II)V
    .locals 29

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    add-int/2addr v4, v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v6

    add-int/2addr v5, v6

    const/4 v6, -0x2

    move/from16 v7, p2

    move/from16 v7, p2

    move/from16 v7, p2

    move/from16 v7, p2

    invoke-static {v7, v5, v6}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v6

    sub-int/2addr v2, v4

    iget v4, v0, Landroidx/appcompat/widget/ActionMenuView;->K:I

    div-int v7, v2, v4

    rem-int v8, v2, v4

    const/4 v9, 0x0

    if-nez v7, :cond_0

    invoke-virtual {v0, v2, v9}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :cond_0
    div-int/2addr v8, v7

    add-int/2addr v4, v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v8

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    move v12, v10

    move v12, v10

    move v12, v10

    move v12, v10

    move v13, v12

    move v13, v12

    move v13, v12

    move v13, v12

    move v14, v13

    move v14, v13

    move v14, v13

    move v14, v13

    move v15, v14

    move v15, v14

    move/from16 v16, v15

    move/from16 v16, v15

    move/from16 v16, v15

    const-wide/16 v17, 0x0

    const-wide/16 v17, 0x0

    :goto_0
    if-ge v12, v8, :cond_8

    invoke-virtual {v0, v12}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    invoke-virtual {v11}, Landroid/view/View;->getVisibility()I

    move-result v9

    move/from16 v19, v3

    move/from16 v19, v3

    move/from16 v19, v3

    move/from16 v19, v3

    const/16 v3, 0x8

    if-ne v9, v3, :cond_1

    goto/16 :goto_5

    :cond_1
    instance-of v3, v11, Landroidx/appcompat/view/menu/ActionMenuItemView;

    add-int/lit8 v14, v14, 0x1

    if-eqz v3, :cond_2

    iget v9, v0, Landroidx/appcompat/widget/ActionMenuView;->L:I

    move/from16 v20, v14

    move/from16 v20, v14

    move/from16 v20, v14

    const/4 v14, 0x0

    invoke-virtual {v11, v9, v14, v9, v14}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_1

    :cond_2
    move/from16 v20, v14

    move/from16 v20, v14

    move/from16 v20, v14

    move/from16 v20, v14

    const/4 v14, 0x0

    :goto_1
    invoke-virtual {v11}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroidx/appcompat/widget/ActionMenuView$c;

    iput-boolean v14, v9, Landroidx/appcompat/widget/ActionMenuView$c;->f:Z

    iput v14, v9, Landroidx/appcompat/widget/ActionMenuView$c;->c:I

    iput v14, v9, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    iput-boolean v14, v9, Landroidx/appcompat/widget/ActionMenuView$c;->d:Z

    iput v14, v9, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iput v14, v9, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    if-eqz v3, :cond_3

    move-object v3, v11

    move-object v3, v11

    move-object v3, v11

    check-cast v3, Landroidx/appcompat/view/menu/ActionMenuItemView;

    invoke-virtual {v3}, Landroidx/appcompat/view/menu/ActionMenuItemView;->h()Z

    move-result v3

    if-eqz v3, :cond_3

    const/4 v3, 0x1

    goto :goto_2

    :cond_3
    const/4 v3, 0x0

    :goto_2
    iput-boolean v3, v9, Landroidx/appcompat/widget/ActionMenuView$c;->e:Z

    iget-boolean v3, v9, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    if-eqz v3, :cond_4

    const/4 v3, 0x1

    goto :goto_3

    :cond_4
    move v3, v7

    move v3, v7

    move v3, v7

    move v3, v7

    :goto_3
    invoke-static {v11, v4, v3, v6, v5}, Landroidx/appcompat/widget/ActionMenuView;->P(Landroid/view/View;IIII)I

    move-result v3

    invoke-static {v15, v3}, Ljava/lang/Math;->max(II)I

    move-result v15

    iget-boolean v14, v9, Landroidx/appcompat/widget/ActionMenuView$c;->d:Z

    if-eqz v14, :cond_5

    add-int/lit8 v16, v16, 0x1

    :cond_5
    iget-boolean v9, v9, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    if-eqz v9, :cond_6

    const/4 v13, 0x1

    :cond_6
    sub-int/2addr v7, v3

    invoke-virtual {v11}, Landroid/view/View;->getMeasuredHeight()I

    move-result v9

    invoke-static {v10, v9}, Ljava/lang/Math;->max(II)I

    move-result v10

    const/4 v9, 0x1

    if-ne v3, v9, :cond_7

    shl-int v3, v9, v12

    move v11, v10

    move v11, v10

    move v11, v10

    int-to-long v9, v3

    or-long v9, v17, v9

    move-wide/from16 v17, v9

    move v10, v11

    move v10, v11

    move v10, v11

    move v10, v11

    goto :goto_4

    :cond_7
    move v11, v10

    move v11, v10

    move v11, v10

    move v11, v10

    :goto_4
    move/from16 v14, v20

    move/from16 v14, v20

    move/from16 v14, v20

    move/from16 v14, v20

    :goto_5
    add-int/lit8 v12, v12, 0x1

    move/from16 v3, v19

    move/from16 v3, v19

    move/from16 v3, v19

    move/from16 v3, v19

    const/4 v9, 0x0

    goto/16 :goto_0

    :cond_8
    move/from16 v19, v3

    move/from16 v19, v3

    move/from16 v19, v3

    move/from16 v19, v3

    const/4 v3, 0x2

    if-eqz v13, :cond_9

    if-ne v14, v3, :cond_9

    const/4 v5, 0x1

    goto :goto_6

    :cond_9
    const/4 v5, 0x0

    :goto_6
    const/4 v9, 0x0

    :goto_7
    if-lez v16, :cond_13

    if-lez v7, :cond_13

    const v20, 0x7fffffff

    move/from16 v12, v20

    move/from16 v12, v20

    move/from16 v12, v20

    const/4 v3, 0x0

    const/4 v11, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v20, 0x0

    :goto_8
    if-ge v11, v8, :cond_d

    invoke-virtual {v0, v11}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v24

    invoke-virtual/range {v24 .. v24}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v24

    move/from16 v25, v9

    move/from16 v25, v9

    move-object/from16 v9, v24

    move-object/from16 v9, v24

    move-object/from16 v9, v24

    move-object/from16 v9, v24

    check-cast v9, Landroidx/appcompat/widget/ActionMenuView$c;

    move/from16 v24, v10

    move/from16 v24, v10

    move/from16 v24, v10

    move/from16 v24, v10

    iget-boolean v10, v9, Landroidx/appcompat/widget/ActionMenuView$c;->d:Z

    if-nez v10, :cond_a

    goto :goto_9

    :cond_a
    iget v9, v9, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    if-ge v9, v12, :cond_b

    const-wide/16 v22, 0x1

    const-wide/16 v22, 0x1

    shl-long v20, v22, v11

    move v12, v9

    move v12, v9

    move v12, v9

    move v12, v9

    const/4 v3, 0x1

    goto :goto_9

    :cond_b
    const-wide/16 v22, 0x1

    const-wide/16 v22, 0x1

    if-ne v9, v12, :cond_c

    shl-long v9, v22, v11

    or-long v9, v20, v9

    add-int/lit8 v3, v3, 0x1

    move-wide/from16 v20, v9

    :cond_c
    :goto_9
    add-int/lit8 v11, v11, 0x1

    move/from16 v10, v24

    move/from16 v10, v24

    move/from16 v10, v24

    move/from16 v10, v24

    move/from16 v9, v25

    move/from16 v9, v25

    move/from16 v9, v25

    move/from16 v9, v25

    goto :goto_8

    :cond_d
    move/from16 v25, v9

    move/from16 v25, v9

    move/from16 v25, v9

    move/from16 v24, v10

    move/from16 v24, v10

    move/from16 v24, v10

    or-long v17, v17, v20

    if-le v3, v7, :cond_e

    move v11, v1

    move v11, v1

    move v11, v1

    move v11, v1

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    goto/16 :goto_d

    :cond_e
    add-int/lit8 v12, v12, 0x1

    const/4 v3, 0x0

    :goto_a
    if-ge v3, v8, :cond_12

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    invoke-virtual {v9}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v10

    check-cast v10, Landroidx/appcompat/widget/ActionMenuView$c;

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    const/4 v11, 0x1

    shl-int v2, v11, v3

    move v11, v1

    move v11, v1

    move v11, v1

    move v11, v1

    int-to-long v1, v2

    and-long v22, v20, v1

    const-wide/16 v27, 0x0

    const-wide/16 v27, 0x0

    cmp-long v22, v22, v27

    if-nez v22, :cond_10

    iget v9, v10, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    if-ne v9, v12, :cond_f

    or-long v17, v17, v1

    :cond_f
    move/from16 v27, v5

    goto :goto_c

    :cond_10
    if-eqz v5, :cond_11

    iget-boolean v1, v10, Landroidx/appcompat/widget/ActionMenuView$c;->e:Z

    if-eqz v1, :cond_11

    const/4 v1, 0x1

    if-ne v7, v1, :cond_11

    iget v2, v0, Landroidx/appcompat/widget/ActionMenuView;->L:I

    add-int v1, v2, v4

    move/from16 v27, v5

    move/from16 v27, v5

    move/from16 v27, v5

    move/from16 v27, v5

    const/4 v5, 0x0

    invoke-virtual {v9, v1, v5, v2, v5}, Landroid/view/View;->setPadding(IIII)V

    goto :goto_b

    :cond_11
    move/from16 v27, v5

    move/from16 v27, v5

    move/from16 v27, v5

    move/from16 v27, v5

    :goto_b
    iget v1, v10, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, v10, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    iput-boolean v2, v10, Landroidx/appcompat/widget/ActionMenuView$c;->f:Z

    add-int/lit8 v7, v7, -0x1

    :goto_c
    add-int/lit8 v3, v3, 0x1

    move v1, v11

    move v1, v11

    move v1, v11

    move v1, v11

    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v5, v27

    move/from16 v5, v27

    move/from16 v5, v27

    move/from16 v5, v27

    goto :goto_a

    :cond_12
    move/from16 v10, v24

    move/from16 v10, v24

    move/from16 v10, v24

    move/from16 v10, v24

    const/4 v3, 0x2

    const/4 v9, 0x1

    goto/16 :goto_7

    :cond_13
    move v11, v1

    move v11, v1

    move v11, v1

    move v11, v1

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v25, v9

    move/from16 v25, v9

    move/from16 v25, v9

    move/from16 v25, v9

    move/from16 v24, v10

    move/from16 v24, v10

    move/from16 v24, v10

    move/from16 v24, v10

    :goto_d
    const/4 v1, 0x1

    if-nez v13, :cond_14

    if-ne v14, v1, :cond_14

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    goto :goto_e

    :cond_14
    const/4 v2, 0x0

    :goto_e
    if-lez v7, :cond_20

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    cmp-long v3, v17, v9

    if-eqz v3, :cond_20

    sub-int/2addr v14, v1

    if-lt v7, v14, :cond_15

    if-nez v2, :cond_15

    if-le v15, v1, :cond_20

    :cond_15
    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->bitCount(J)I

    move-result v1

    int-to-float v1, v1

    if-nez v2, :cond_17

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    const-wide/16 v2, 0x1

    and-long v2, v17, v2

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    cmp-long v2, v2, v9

    const/high16 v3, 0x3f000000    # 0.5f

    const/4 v14, 0x0

    if-eqz v2, :cond_16

    invoke-virtual {v0, v14}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroidx/appcompat/widget/ActionMenuView$c;

    iget-boolean v2, v2, Landroidx/appcompat/widget/ActionMenuView$c;->e:Z

    if-nez v2, :cond_16

    sub-float/2addr v1, v3

    :cond_16
    add-int/lit8 v2, v8, -0x1

    const/4 v5, 0x1

    shl-int v9, v5, v2

    int-to-long v9, v9

    and-long v9, v17, v9

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    cmp-long v5, v9, v12

    if-eqz v5, :cond_18

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroidx/appcompat/widget/ActionMenuView$c;

    iget-boolean v2, v2, Landroidx/appcompat/widget/ActionMenuView$c;->e:Z

    if-nez v2, :cond_18

    sub-float/2addr v1, v3

    goto :goto_f

    :cond_17
    const/4 v14, 0x0

    :cond_18
    :goto_f
    const/4 v2, 0x0

    cmpl-float v2, v1, v2

    if-lez v2, :cond_19

    mul-int/2addr v7, v4

    int-to-float v2, v7

    div-float/2addr v2, v1

    float-to-int v1, v2

    goto :goto_10

    :cond_19
    move v1, v14

    move v1, v14

    move v1, v14

    move v1, v14

    :goto_10
    move v2, v14

    move v2, v14

    move v2, v14

    move/from16 v9, v25

    move/from16 v9, v25

    move/from16 v9, v25

    move/from16 v9, v25

    :goto_11
    if-ge v2, v8, :cond_21

    const/4 v3, 0x1

    shl-int v5, v3, v2

    int-to-long v12, v5

    and-long v12, v17, v12

    const-wide/16 v15, 0x0

    const-wide/16 v15, 0x0

    const-wide/16 v15, 0x0

    const-wide/16 v15, 0x0

    cmp-long v3, v12, v15

    if-nez v3, :cond_1a

    const/4 v3, 0x1

    const/4 v7, 0x2

    goto :goto_13

    :cond_1a
    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/appcompat/widget/ActionMenuView$c;

    instance-of v3, v3, Landroidx/appcompat/view/menu/ActionMenuItemView;

    if-eqz v3, :cond_1c

    iput v1, v5, Landroidx/appcompat/widget/ActionMenuView$c;->c:I

    const/4 v3, 0x1

    iput-boolean v3, v5, Landroidx/appcompat/widget/ActionMenuView$c;->f:Z

    if-nez v2, :cond_1b

    iget-boolean v3, v5, Landroidx/appcompat/widget/ActionMenuView$c;->e:Z

    if-nez v3, :cond_1b

    neg-int v3, v1

    const/4 v7, 0x2

    div-int/2addr v3, v7

    iput v3, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    goto :goto_12

    :cond_1b
    const/4 v7, 0x2

    :goto_12
    const/4 v3, 0x1

    const/4 v9, 0x1

    goto :goto_13

    :cond_1c
    const/4 v7, 0x2

    iget-boolean v3, v5, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    if-eqz v3, :cond_1d

    iput v1, v5, Landroidx/appcompat/widget/ActionMenuView$c;->c:I

    const/4 v3, 0x1

    iput-boolean v3, v5, Landroidx/appcompat/widget/ActionMenuView$c;->f:Z

    neg-int v9, v1

    div-int/2addr v9, v7

    iput v9, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    move v9, v3

    move v9, v3

    move v9, v3

    move v9, v3

    goto :goto_13

    :cond_1d
    const/4 v3, 0x1

    if-eqz v2, :cond_1e

    div-int/lit8 v10, v1, 0x2

    iput v10, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    :cond_1e
    add-int/lit8 v10, v8, -0x1

    if-eq v2, v10, :cond_1f

    div-int/lit8 v10, v1, 0x2

    iput v10, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    :cond_1f
    :goto_13
    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    :cond_20
    const/4 v14, 0x0

    move/from16 v9, v25

    move/from16 v9, v25

    move/from16 v9, v25

    move/from16 v9, v25

    :cond_21
    const/high16 v1, 0x40000000    # 2.0f

    if-eqz v9, :cond_23

    move v9, v14

    move v9, v14

    move v9, v14

    :goto_14
    if-ge v9, v8, :cond_23

    invoke-virtual {v0, v9}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    check-cast v3, Landroidx/appcompat/widget/ActionMenuView$c;

    iget-boolean v5, v3, Landroidx/appcompat/widget/ActionMenuView$c;->f:Z

    if-nez v5, :cond_22

    goto :goto_15

    :cond_22
    iget v5, v3, Landroidx/appcompat/widget/ActionMenuView$c;->b:I

    mul-int/2addr v5, v4

    iget v3, v3, Landroidx/appcompat/widget/ActionMenuView$c;->c:I

    add-int/2addr v5, v3

    invoke-static {v5, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v2, v3, v6}, Landroid/view/View;->measure(II)V

    :goto_15
    add-int/lit8 v9, v9, 0x1

    goto :goto_14

    :cond_23
    if-eq v11, v1, :cond_24

    move/from16 v3, v24

    move/from16 v3, v24

    move/from16 v3, v24

    move/from16 v3, v24

    goto :goto_16

    :cond_24
    move/from16 v3, v19

    move/from16 v3, v19

    move/from16 v3, v19

    move/from16 v3, v19

    :goto_16
    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    invoke-virtual {v0, v2, v3}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void
.end method


# virtual methods
.method public F()V
    .locals 3

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->B()Z

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method protected G()Landroidx/appcompat/widget/ActionMenuView$c;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, -0x2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, v1, v1}, Landroidx/appcompat/widget/ActionMenuView$c;-><init>(II)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v1, 0x10

    iput v1, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0
.end method

.method public H(Landroid/util/AttributeSet;)Landroidx/appcompat/widget/ActionMenuView$c;
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, v1, p1}, Landroidx/appcompat/widget/ActionMenuView$c;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0
.end method

.method protected I(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/ActionMenuView$c;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p1, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    instance-of v0, p1, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    new-instance v0, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v1, 0x7

    xor-int/2addr v2, v1

    check-cast p1, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Landroidx/appcompat/widget/ActionMenuView$c;-><init>(Landroidx/appcompat/widget/ActionMenuView$c;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    new-instance v0, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Landroidx/appcompat/widget/ActionMenuView$c;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget p1, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-gtz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/16 p1, 0x10

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput p1, v0, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0

    :cond_2
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->G()Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object p1
.end method

.method public J()Landroidx/appcompat/widget/ActionMenuView$c;
    .locals 4
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->G()Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-boolean v1, v0, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    const/4 v3, 0x7

    return-object v0
.end method

.method protected K(I)Z
    .locals 6
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    add-int/lit8 v1, p1, -0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-ge p1, v3, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    instance-of v3, v1, Landroidx/appcompat/widget/ActionMenuView$a;

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    check-cast v1, Landroidx/appcompat/widget/ActionMenuView$a;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v1}, Landroidx/appcompat/widget/ActionMenuView$a;->a()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    or-int/2addr v0, v1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    if-lez p1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    instance-of p1, v2, Landroidx/appcompat/widget/ActionMenuView$a;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    check-cast v2, Landroidx/appcompat/widget/ActionMenuView$a;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v2}, Landroidx/appcompat/widget/ActionMenuView$a;->c()Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    or-int/2addr v0, p1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0
.end method

.method public L()Z
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->E()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    or-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public M()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x6

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->G()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x2

    move v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x3

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public N()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->H()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    return v0
.end method

.method public O()Z
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuView;->E:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public R()Landroidx/appcompat/view/menu/g;
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v2, 0x6

    return-object v0
.end method

.method public S(Landroidx/appcompat/view/menu/n$a;Landroidx/appcompat/view/menu/g$a;)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->G:Landroidx/appcompat/view/menu/n$a;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Landroidx/appcompat/widget/ActionMenuView;->H:Landroidx/appcompat/view/menu/g$a;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public T()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->Q()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x3

    and-int/2addr v1, v0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public a(Landroidx/appcompat/view/menu/g;)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    instance-of p1, p1, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method public dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p1, 0x0

    return p1
.end method

.method public e(Landroidx/appcompat/view/menu/j;)Z
    .locals 4
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p1, v1}, Landroidx/appcompat/view/menu/g;->O(Landroid/view/MenuItem;I)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p1
.end method

.method protected bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->G()Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionMenuView;->H(Landroid/util/AttributeSet;)Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-object p1
.end method

.method protected bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionMenuView;->I(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method

.method public getMenu()Landroid/view/Menu;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v1, Landroidx/appcompat/view/menu/g;

    const/4 v3, 0x5

    shr-int/2addr v4, v3

    invoke-direct {v1, v0}, Landroidx/appcompat/view/menu/g;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v2, Landroidx/appcompat/widget/ActionMenuView$d;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v2, p0}, Landroidx/appcompat/widget/ActionMenuView$d;-><init>(Landroidx/appcompat/widget/ActionMenuView;)V

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Landroidx/appcompat/view/menu/g;->X(Landroidx/appcompat/view/menu/g$a;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v1, Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {v1, v0}, Landroidx/appcompat/widget/ActionMenuPresenter;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->O(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->G:Landroidx/appcompat/view/menu/n$a;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Landroidx/appcompat/widget/ActionMenuView$b;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1}, Landroidx/appcompat/widget/ActionMenuView$b;-><init>()V

    :goto_0
    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroidx/appcompat/view/menu/b;->e(Landroidx/appcompat/view/menu/n$a;)V

    const/4 v4, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v2, p0, Landroidx/appcompat/widget/ActionMenuView;->C:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroidx/appcompat/view/menu/g;->c(Landroidx/appcompat/view/menu/n;Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->M(Landroidx/appcompat/widget/ActionMenuView;)V

    :cond_1
    const/4 v3, 0x3

    move v4, v3

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method public getOverflowIcon()Landroid/graphics/drawable/Drawable;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->getMenu()Landroid/view/Menu;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->D()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getPopupTheme()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/widget/ActionMenuView;->D:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public getWindowAnimations()I
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method protected bridge synthetic o()Landroidx/appcompat/widget/LinearLayoutCompat$b;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->G()Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->j(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/widget/ActionMenuPresenter;->H()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    and-int/2addr v2, v1

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroidx/appcompat/widget/ActionMenuPresenter;->E()Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/widget/ActionMenuPresenter;->Q()Z

    :cond_0
    const/4 v2, 0x6

    return-void
.end method

.method public onDetachedFromWindow()V
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->F()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 17

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    iget-boolean v1, v0, Landroidx/appcompat/widget/ActionMenuView;->I:Z

    if-nez v1, :cond_0

    invoke-super/range {p0 .. p5}, Landroidx/appcompat/widget/LinearLayoutCompat;->onLayout(ZIIII)V

    return-void

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    sub-int v2, p5, p3

    div-int/lit8 v2, v2, 0x2

    invoke-virtual/range {p0 .. p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getDividerWidth()I

    move-result v3

    sub-int v4, p4, p2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    sub-int v5, v4, v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v6

    sub-int/2addr v5, v6

    invoke-static/range {p0 .. p0}, Landroidx/appcompat/widget/y2;->b(Landroid/view/View;)Z

    move-result v6

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    :goto_0
    const/16 v11, 0x8

    const/4 v12, 0x1

    if-ge v8, v1, :cond_5

    invoke-virtual {v0, v8}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    move-result v14

    if-ne v14, v11, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v11

    check-cast v11, Landroidx/appcompat/widget/ActionMenuView$c;

    iget-boolean v14, v11, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    if-eqz v14, :cond_4

    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v9

    invoke-virtual {v0, v8}, Landroidx/appcompat/widget/ActionMenuView;->K(I)Z

    move-result v14

    if-eqz v14, :cond_2

    add-int/2addr v9, v3

    :cond_2
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    move-result v14

    if-eqz v6, :cond_3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v15

    iget v11, v11, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v15, v11

    add-int v11, v15, v9

    goto :goto_1

    :cond_3
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v15

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v16

    sub-int v15, v15, v16

    iget v11, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    sub-int v11, v15, v11

    sub-int v15, v11, v9

    :goto_1
    div-int/lit8 v16, v14, 0x2

    sub-int v7, v2, v16

    add-int/2addr v14, v7

    invoke-virtual {v13, v15, v7, v11, v14}, Landroid/view/View;->layout(IIII)V

    sub-int/2addr v5, v9

    move v9, v12

    move v9, v12

    move v9, v12

    move v9, v12

    goto :goto_2

    :cond_4
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v7

    iget v12, v11, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v7, v12

    iget v11, v11, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v7, v11

    sub-int/2addr v5, v7

    invoke-virtual {v0, v8}, Landroidx/appcompat/widget/ActionMenuView;->K(I)Z

    add-int/lit8 v10, v10, 0x1

    :goto_2
    add-int/lit8 v8, v8, 0x1

    goto :goto_0

    :cond_5
    if-ne v1, v12, :cond_6

    if-nez v9, :cond_6

    const/4 v3, 0x0

    invoke-virtual {v0, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredWidth()I

    move-result v3

    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v5

    div-int/lit8 v4, v4, 0x2

    div-int/lit8 v6, v3, 0x2

    sub-int/2addr v4, v6

    div-int/lit8 v6, v5, 0x2

    sub-int/2addr v2, v6

    add-int/2addr v3, v4

    add-int/2addr v5, v2

    invoke-virtual {v1, v4, v2, v3, v5}, Landroid/view/View;->layout(IIII)V

    return-void

    :cond_6
    xor-int/lit8 v3, v9, 0x1

    sub-int/2addr v10, v3

    if-lez v10, :cond_7

    div-int v3, v5, v10

    goto :goto_3

    :cond_7
    const/4 v3, 0x0

    :goto_3
    const/4 v4, 0x0

    invoke-static {v4, v3}, Ljava/lang/Math;->max(II)I

    move-result v3

    if-eqz v6, :cond_a

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    move-result v5

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v6

    sub-int/2addr v5, v6

    move v7, v4

    move v7, v4

    :goto_4
    if-ge v7, v1, :cond_d

    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroidx/appcompat/widget/ActionMenuView$c;

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v8

    if-eq v8, v11, :cond_9

    iget-boolean v8, v6, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    if-eqz v8, :cond_8

    goto :goto_5

    :cond_8
    iget v8, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    sub-int/2addr v5, v8

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v8

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v9

    div-int/lit8 v10, v9, 0x2

    sub-int v10, v2, v10

    sub-int v12, v5, v8

    add-int/2addr v9, v10

    invoke-virtual {v4, v12, v10, v5, v9}, Landroid/view/View;->layout(IIII)V

    iget v4, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v8, v4

    add-int/2addr v8, v3

    sub-int/2addr v5, v8

    :cond_9
    :goto_5
    add-int/lit8 v7, v7, 0x1

    goto :goto_4

    :cond_a
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v5

    move v7, v4

    move v7, v4

    move v7, v4

    move v7, v4

    :goto_6
    if-ge v7, v1, :cond_d

    invoke-virtual {v0, v7}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v6

    check-cast v6, Landroidx/appcompat/widget/ActionMenuView$c;

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v8

    if-eq v8, v11, :cond_c

    iget-boolean v8, v6, Landroidx/appcompat/widget/ActionMenuView$c;->a:Z

    if-eqz v8, :cond_b

    goto :goto_7

    :cond_b
    iget v8, v6, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v5, v8

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v8

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredHeight()I

    move-result v9

    div-int/lit8 v10, v9, 0x2

    sub-int v10, v2, v10

    add-int v12, v5, v8

    add-int/2addr v9, v10

    invoke-virtual {v4, v5, v10, v12, v9}, Landroid/view/View;->layout(IIII)V

    iget v4, v6, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v8, v4

    add-int/2addr v8, v3

    add-int/2addr v5, v8

    :cond_c
    :goto_7
    add-int/lit8 v7, v7, 0x1

    goto :goto_6

    :cond_d
    return-void
.end method

.method protected onMeasure(II)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/ActionMenuView;->I:Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x0

    shr-int/2addr v6, v4

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    if-ne v1, v2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v1, v3

    move v1, v3

    const/4 v6, 0x0

    move v1, v3

    move v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v1, v4

    move v1, v4

    const/4 v6, 0x2

    move v1, v4

    move v1, v4

    :goto_0
    const/4 v6, 0x3

    iput-boolean v1, p0, Landroidx/appcompat/widget/ActionMenuView;->I:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eq v0, v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput v4, p0, Landroidx/appcompat/widget/ActionMenuView;->J:I

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-boolean v1, p0, Landroidx/appcompat/widget/ActionMenuView;->I:Z

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/ActionMenuView;->B:Landroidx/appcompat/view/menu/g;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x4

    iget v2, p0, Landroidx/appcompat/widget/ActionMenuView;->J:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eq v0, v2, :cond_2

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v0, p0, Landroidx/appcompat/widget/ActionMenuView;->J:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1, v3}, Landroidx/appcompat/view/menu/g;->N(Z)V

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-boolean v1, p0, Landroidx/appcompat/widget/ActionMenuView;->I:Z

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v1, :cond_3

    const/4 v6, 0x7

    if-lez v0, :cond_3

    const/4 v6, 0x2

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/widget/ActionMenuView;->Q(II)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto :goto_2

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    move v1, v4

    move v1, v4

    const/4 v6, 0x0

    move v1, v4

    move v1, v4

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-ge v1, v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v2, Landroidx/appcompat/widget/ActionMenuView$c;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput v4, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto :goto_1

    :cond_4
    const/4 v5, 0x0

    move v6, v5

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;->onMeasure(II)V

    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void
.end method

.method public bridge synthetic p(Landroid/util/AttributeSet;)Landroidx/appcompat/widget/LinearLayoutCompat$b;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionMenuView;->H(Landroid/util/AttributeSet;)Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method protected bridge synthetic q(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/LinearLayoutCompat$b;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ActionMenuView;->I(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/ActionMenuView$c;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public setExpandedActionViewsExclusive(Z)V
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionMenuPresenter;->K(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public setOnMenuItemClickListener(Landroidx/appcompat/widget/ActionMenuView$e;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->M:Landroidx/appcompat/widget/ActionMenuView$e;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public setOverflowIcon(Landroid/graphics/drawable/Drawable;)V
    .locals 3
    .param p1    # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/widget/ActionMenuView;->getMenu()Landroid/view/Menu;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/ActionMenuPresenter;->N(Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public setOverflowReserved(Z)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/widget/ActionMenuView;->E:Z

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public setPopupTheme(I)V
    .locals 4
    .param p1    # I
        .annotation build Landroidx/annotation/f1;
        .end annotation
    .end param

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Landroidx/appcompat/widget/ActionMenuView;->D:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-eq v0, p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput p1, p0, Landroidx/appcompat/widget/ActionMenuView;->D:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->C:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Landroid/view/ContextThemeWrapper;

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0, v1, p1}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Landroidx/appcompat/widget/ActionMenuView;->C:Landroid/content/Context;

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method public setPresenter(Landroidx/appcompat/widget/ActionMenuPresenter;)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuView;->F:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1, p0}, Landroidx/appcompat/widget/ActionMenuPresenter;->M(Landroidx/appcompat/widget/ActionMenuView;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
