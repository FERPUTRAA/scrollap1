.class Landroidx/appcompat/widget/SearchView$n;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/SearchView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "n"
.end annotation


# instance fields
.field private a:Ljava/lang/reflect/Method;

.field private b:Ljava/lang/reflect/Method;

.field private c:Ljava/lang/reflect/Method;


# direct methods
.method constructor <init>()V
    .locals 8
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "DiscouragedPrivateApi",
            "SoonBlockedPrivateApi"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-class v0, Landroid/widget/AutoCompleteTextView;

    const-class v0, Landroid/widget/AutoCompleteTextView;

    const/4 v7, 0x3

    const-class v0, Landroid/widget/AutoCompleteTextView;

    const-class v0, Landroid/widget/AutoCompleteTextView;

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x5

    iput-object v1, p0, Landroidx/appcompat/widget/SearchView$n;->a:Ljava/lang/reflect/Method;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object v1, p0, Landroidx/appcompat/widget/SearchView$n;->b:Ljava/lang/reflect/Method;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    iput-object v1, p0, Landroidx/appcompat/widget/SearchView$n;->c:Ljava/lang/reflect/Method;

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {}, Landroidx/appcompat/widget/SearchView$n;->d()V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v2, 0x1

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const-string v3, "dBsfxhgdTetoCoenaee"

    const-string v3, "gtsefxeeahoTCeonddB"

    const/4 v7, 0x4

    const-string/jumbo v3, "xeemTnredoedhBaCtfo"

    const-string v3, "doBeforeTextChanged"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-array v4, v1, [Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    iput-object v3, p0, Landroidx/appcompat/widget/SearchView$n;->a:Ljava/lang/reflect/Method;

    invoke-virtual {v3, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v3, "thoroexdAgedCaTfnm"

    const-string v3, "dCamoThrfdengxttAe"

    const/4 v7, 0x1

    const-string v3, "doAfterTextChanged"

    const/4 v7, 0x4

    const/4 v6, 0x6

    new-array v4, v1, [Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-object v3, p0, Landroidx/appcompat/widget/SearchView$n;->b:Ljava/lang/reflect/Method;

    const/4 v7, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v3, "biuslbrVieeesemI"

    const-string v3, "esmloeiseburVIei"

    const/4 v7, 0x5

    const-string v3, "eeeireumbsIVnusi"

    const-string v3, "ensureImeVisible"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-array v4, v2, [Ljava/lang/Class;

    const/4 v6, 0x6

    move v7, v6

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    aput-object v5, v4, v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object v0, p0, Landroidx/appcompat/widget/SearchView$n;->c:Ljava/lang/reflect/Method;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void
.end method

.method private static d()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~Syc~ipit4sno~@@@~  ~@  d~~~ lib~ ~~/M @@~.~@/vb @K@ @~uo- b ~@o~to@1 @rmo @~@ ~@~o @~@@ ~lf @f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/16 v1, 0x1d

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ge v0, v1, :cond_0

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x6

    new-instance v0, Ljava/lang/UnsupportedClassVersionError;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo v1, "socL.eATqndi 9os  auub tIfbc <i ef vnnlyloe  2 rnP"

    const-string v1, "9 2v.b on nueclhon<L bnPIisel fia ryu fo se AtT dc"

    const/4 v3, 0x5

    const-string v1, "This function can only be used for API Level < 29."

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedClassVersionError;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw v0
.end method


# virtual methods
.method a(Landroid/widget/AutoCompleteTextView;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {}, Landroidx/appcompat/widget/SearchView$n;->d()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView$n;->b:Ljava/lang/reflect/Method;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    :try_start_0
    const/4 v2, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method b(Landroid/widget/AutoCompleteTextView;)V
    .locals 4

    const/4 v3, 0x0

    invoke-static {}, Landroidx/appcompat/widget/SearchView$n;->d()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView$n;->a:Ljava/lang/reflect/Method;

    const/4 v2, 0x2

    and-int/2addr v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x0

    move v3, v1

    :try_start_0
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method c(Landroid/widget/AutoCompleteTextView;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {}, Landroidx/appcompat/widget/SearchView$n;->d()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView$n;->c:Ljava/lang/reflect/Method;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x1

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x7

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x3

    aput-object v2, v1, v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method
