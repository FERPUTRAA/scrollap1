.class Landroidx/appcompat/widget/ActionMenuPresenter$d;
.super Landroidx/appcompat/widget/AppCompatImageView;

# interfaces
.implements Landroidx/appcompat/widget/ActionMenuView$a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/ActionMenuPresenter;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "d"
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/ActionMenuPresenter;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/ActionMenuPresenter;Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/ActionMenuPresenter$d;->a:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    sget v1, Landroidx/appcompat/R$attr;->actionOverflowButtonStyle:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, p2, v0, v1}, Landroidx/appcompat/widget/AppCompatImageView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p2, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, p2}, Landroid/view/View;->setClickable(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, p2}, Landroid/view/View;->setFocusable(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Landroid/view/View;->setEnabled(Z)V

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, p2}, Landroidx/appcompat/widget/u2;->a(Landroid/view/View;Ljava/lang/CharSequence;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance p2, Landroidx/appcompat/widget/ActionMenuPresenter$d$a;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p2, p0, p0, p1}, Landroidx/appcompat/widget/ActionMenuPresenter$d$a;-><init>(Landroidx/appcompat/widget/ActionMenuPresenter$d;Landroid/view/View;Landroidx/appcompat/widget/ActionMenuPresenter;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~os~o@@ @d @~ /~a@l@~boK~n l~-i@~@sm@@~ M ~~1~oSiv 4ru/t  ~b~@@io@@t y c~@~@~f fo b@@.@@~ ~~~   "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public performClick()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-super {p0}, Landroid/widget/ImageView;->performClick()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    or-int/2addr v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/view/View;->playSoundEffect(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ActionMenuPresenter$d;->a:Landroidx/appcompat/widget/ActionMenuPresenter;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroidx/appcompat/widget/ActionMenuPresenter;->Q()Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v1
.end method

.method protected setFrame(IIII)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/widget/ImageView;->setFrame(IIII)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz p2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p3, :cond_0

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p4

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p2, p4}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    div-int/lit8 v0, v0, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    sub-int/2addr v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    sub-int/2addr v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    add-int/2addr p2, v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    div-int/lit8 p2, p2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    add-int/2addr p4, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    div-int/lit8 p4, p4, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    sub-int v1, p2, v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    sub-int v2, p4, v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    add-int/2addr p2, v0

    const/4 v5, 0x5

    add-int/2addr p4, v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p3, v1, v2, p2, p4}, Landroidx/core/graphics/drawable/d;->l(Landroid/graphics/drawable/Drawable;IIII)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x1

    return p1
.end method
