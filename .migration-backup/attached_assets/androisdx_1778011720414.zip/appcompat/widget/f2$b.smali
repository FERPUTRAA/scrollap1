.class Landroidx/appcompat/widget/f2$b;
.super Ljava/lang/Object;

# interfaces
.implements Landroidx/appcompat/widget/c$f;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/f2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/f2;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/f2;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/f2$b;->a:Landroidx/appcompat/widget/f2;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Landroidx/appcompat/widget/c;Landroid/content/Intent;)Z
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~~ oM@@1@d o@o~@  u  l4i ~ @@  @ ~S / v@ @b~/bncar~~@~.lym@-@~~@~~oo~ Kbit@f~~~i@~@~os@f t~~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object p1, p0, Landroidx/appcompat/widget/f2$b;->a:Landroidx/appcompat/widget/f2;

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p1, Landroidx/appcompat/widget/f2;->i:Landroidx/appcompat/widget/f2$a;

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-interface {v0, p1, p2}, Landroidx/appcompat/widget/f2$a;->a(Landroidx/appcompat/widget/f2;Landroid/content/Intent;)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x2

    move v2, v1

    return p1
.end method
