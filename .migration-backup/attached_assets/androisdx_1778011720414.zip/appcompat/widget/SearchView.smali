.class public Landroidx/appcompat/widget/SearchView;
.super Landroidx/appcompat/widget/LinearLayoutCompat;

# interfaces
.implements Landroidx/appcompat/view/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/SearchView$n;,
        Landroidx/appcompat/widget/SearchView$SearchAutoComplete;,
        Landroidx/appcompat/widget/SearchView$o;,
        Landroidx/appcompat/widget/SearchView$SavedState;,
        Landroidx/appcompat/widget/SearchView$m;,
        Landroidx/appcompat/widget/SearchView$k;,
        Landroidx/appcompat/widget/SearchView$l;
    }
.end annotation


# static fields
.field static final b1:Z = false

.field static final c1:Ljava/lang/String; = "SearchView"

.field private static final d1:Ljava/lang/String; = "nm"

.field static final e1:Landroidx/appcompat/widget/SearchView$n;


# instance fields
.field A0:Landroid/view/View$OnFocusChangeListener;

.field final B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

.field private B0:Landroidx/appcompat/widget/SearchView$m;

.field private final C:Landroid/view/View;

.field private C0:Landroid/view/View$OnClickListener;

.field private final D:Landroid/view/View;

.field private D0:Z

.field private final E:Landroid/view/View;

.field private E0:Z

.field final F:Landroid/widget/ImageView;

.field F0:Landroidx/cursoradapter/widget/a;

.field final G:Landroid/widget/ImageView;

.field private G0:Z

.field final H:Landroid/widget/ImageView;

.field private H0:Ljava/lang/CharSequence;

.field final I:Landroid/widget/ImageView;

.field private I0:Z

.field private final J:Landroid/view/View;

.field private J0:Z

.field private K:Landroidx/appcompat/widget/SearchView$o;

.field private K0:I

.field private L:Landroid/graphics/Rect;

.field private L0:Z

.field private M:Landroid/graphics/Rect;

.field private M0:Ljava/lang/CharSequence;

.field private N:[I

.field private N0:Ljava/lang/CharSequence;

.field private O:[I

.field private O0:Z

.field private final P:Landroid/widget/ImageView;

.field private P0:I

.field private final Q:Landroid/graphics/drawable/Drawable;

.field Q0:Landroid/app/SearchableInfo;

.field private final R:I

.field private R0:Landroid/os/Bundle;

.field private final S:I

.field private final S0:Ljava/lang/Runnable;

.field private final T:Landroid/content/Intent;

.field private T0:Ljava/lang/Runnable;

.field private final U:Landroid/content/Intent;

.field private final U0:Ljava/util/WeakHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/WeakHashMap<",
            "Ljava/lang/String;",
            "Landroid/graphics/drawable/Drawable$ConstantState;",
            ">;"
        }
    .end annotation
.end field

.field private final V:Ljava/lang/CharSequence;

.field private final V0:Landroid/view/View$OnClickListener;

.field private W:Landroidx/appcompat/widget/SearchView$l;

.field W0:Landroid/view/View$OnKeyListener;

.field private final X0:Landroid/widget/TextView$OnEditorActionListener;

.field private final Y0:Landroid/widget/AdapterView$OnItemClickListener;

.field private final Z0:Landroid/widget/AdapterView$OnItemSelectedListener;

.field private a1:Landroid/text/TextWatcher;

.field private k0:Landroidx/appcompat/widget/SearchView$k;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 v1, 0x1d

    const/4 v2, 0x4

    move v3, v2

    if-ge v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Landroidx/appcompat/widget/SearchView$n;

    const/4 v3, 0x0

    invoke-direct {v0}, Landroidx/appcompat/widget/SearchView$n;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    move v3, v2

    sput-object v0, Landroidx/appcompat/widget/SearchView;->e1:Landroidx/appcompat/widget/SearchView$n;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/widget/SearchView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x0

    sget v0, Landroidx/appcompat/R$attr;->searchViewStyle:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, p1, p2, v0}, Landroidx/appcompat/widget/SearchView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 16
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    invoke-direct/range {p0 .. p3}, Landroidx/appcompat/widget/LinearLayoutCompat;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->L:Landroid/graphics/Rect;

    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->M:Landroid/graphics/Rect;

    const/4 v0, 0x2

    new-array v1, v0, [I

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->N:[I

    new-array v0, v0, [I

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->O:[I

    new-instance v0, Landroidx/appcompat/widget/SearchView$b;

    invoke-direct {v0, v7}, Landroidx/appcompat/widget/SearchView$b;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->S0:Ljava/lang/Runnable;

    new-instance v0, Landroidx/appcompat/widget/SearchView$c;

    invoke-direct {v0, v7}, Landroidx/appcompat/widget/SearchView$c;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->T0:Ljava/lang/Runnable;

    new-instance v0, Ljava/util/WeakHashMap;

    invoke-direct {v0}, Ljava/util/WeakHashMap;-><init>()V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->U0:Ljava/util/WeakHashMap;

    new-instance v8, Landroidx/appcompat/widget/SearchView$f;

    invoke-direct {v8, v7}, Landroidx/appcompat/widget/SearchView$f;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v8, v7, Landroidx/appcompat/widget/SearchView;->V0:Landroid/view/View$OnClickListener;

    new-instance v0, Landroidx/appcompat/widget/SearchView$g;

    invoke-direct {v0, v7}, Landroidx/appcompat/widget/SearchView$g;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->W0:Landroid/view/View$OnKeyListener;

    new-instance v9, Landroidx/appcompat/widget/SearchView$h;

    invoke-direct {v9, v7}, Landroidx/appcompat/widget/SearchView$h;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v9, v7, Landroidx/appcompat/widget/SearchView;->X0:Landroid/widget/TextView$OnEditorActionListener;

    new-instance v10, Landroidx/appcompat/widget/SearchView$i;

    invoke-direct {v10, v7}, Landroidx/appcompat/widget/SearchView$i;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v10, v7, Landroidx/appcompat/widget/SearchView;->Y0:Landroid/widget/AdapterView$OnItemClickListener;

    new-instance v11, Landroidx/appcompat/widget/SearchView$j;

    invoke-direct {v11, v7}, Landroidx/appcompat/widget/SearchView$j;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v11, v7, Landroidx/appcompat/widget/SearchView;->Z0:Landroid/widget/AdapterView$OnItemSelectedListener;

    new-instance v0, Landroidx/appcompat/widget/SearchView$a;

    invoke-direct {v0, v7}, Landroidx/appcompat/widget/SearchView$a;-><init>(Landroidx/appcompat/widget/SearchView;)V

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->a1:Landroid/text/TextWatcher;

    sget-object v2, Landroidx/appcompat/R$styleable;->SearchView:[I

    const/4 v12, 0x0

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move/from16 v5, p3

    move/from16 v5, p3

    invoke-static {v13, v3, v2, v5, v12}, Landroidx/appcompat/widget/n2;->G(Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/n2;

    move-result-object v14

    invoke-virtual {v14}, Landroidx/appcompat/widget/n2;->B()Landroid/content/res/TypedArray;

    move-result-object v4

    const/4 v6, 0x0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    invoke-static/range {v0 .. v6}, Landroidx/core/view/k1;->z1(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    invoke-static/range {p1 .. p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_layout:I

    sget v2, Landroidx/appcompat/R$layout;->abc_search_view:I

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v1

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v7, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    sget v0, Landroidx/appcompat/R$id;->search_src_text:I

    invoke-virtual {v7, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    invoke-virtual {v0, v7}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setSearchView(Landroidx/appcompat/widget/SearchView;)V

    sget v1, Landroidx/appcompat/R$id;->search_edit_frame:I

    invoke-virtual {v7, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->C:Landroid/view/View;

    sget v1, Landroidx/appcompat/R$id;->search_plate:I

    invoke-virtual {v7, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v1

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->D:Landroid/view/View;

    sget v3, Landroidx/appcompat/R$id;->submit_area:I

    invoke-virtual {v7, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v3

    iput-object v3, v7, Landroidx/appcompat/widget/SearchView;->E:Landroid/view/View;

    sget v4, Landroidx/appcompat/R$id;->search_button:I

    invoke-virtual {v7, v4}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v4

    check-cast v4, Landroid/widget/ImageView;

    iput-object v4, v7, Landroidx/appcompat/widget/SearchView;->F:Landroid/widget/ImageView;

    sget v5, Landroidx/appcompat/R$id;->search_go_btn:I

    invoke-virtual {v7, v5}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v5

    check-cast v5, Landroid/widget/ImageView;

    iput-object v5, v7, Landroidx/appcompat/widget/SearchView;->G:Landroid/widget/ImageView;

    sget v6, Landroidx/appcompat/R$id;->search_close_btn:I

    invoke-virtual {v7, v6}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v6

    check-cast v6, Landroid/widget/ImageView;

    iput-object v6, v7, Landroidx/appcompat/widget/SearchView;->H:Landroid/widget/ImageView;

    sget v13, Landroidx/appcompat/R$id;->search_voice_btn:I

    invoke-virtual {v7, v13}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v13

    check-cast v13, Landroid/widget/ImageView;

    iput-object v13, v7, Landroidx/appcompat/widget/SearchView;->I:Landroid/widget/ImageView;

    sget v15, Landroidx/appcompat/R$id;->search_mag_icon:I

    invoke-virtual {v7, v15}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v15

    check-cast v15, Landroid/widget/ImageView;

    iput-object v15, v7, Landroidx/appcompat/widget/SearchView;->P:Landroid/widget/ImageView;

    sget v2, Landroidx/appcompat/R$styleable;->SearchView_queryBackground:I

    invoke-virtual {v14, v2}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-static {v1, v2}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_submitBackground:I

    invoke-virtual {v14, v1}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-static {v3, v1}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_searchIcon:I

    invoke-virtual {v14, v1}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget v2, Landroidx/appcompat/R$styleable;->SearchView_goIcon:I

    invoke-virtual {v14, v2}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v5, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget v2, Landroidx/appcompat/R$styleable;->SearchView_closeIcon:I

    invoke-virtual {v14, v2}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v6, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget v2, Landroidx/appcompat/R$styleable;->SearchView_voiceIcon:I

    invoke-virtual {v14, v2}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    invoke-virtual {v13, v2}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    invoke-virtual {v14, v1}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v15, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_searchHintIcon:I

    invoke-virtual {v14, v1}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->Q:Landroid/graphics/drawable/Drawable;

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Landroidx/appcompat/R$string;->abc_searchview_description_search:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v4, v1}, Landroidx/appcompat/widget/u2;->a(Landroid/view/View;Ljava/lang/CharSequence;)V

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_suggestionRowLayout:I

    sget v2, Landroidx/appcompat/R$layout;->abc_search_dropdown_item_icons_2line:I

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v1

    iput v1, v7, Landroidx/appcompat/widget/SearchView;->R:I

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_commitIcon:I

    invoke-virtual {v14, v1, v12}, Landroidx/appcompat/widget/n2;->u(II)I

    move-result v1

    iput v1, v7, Landroidx/appcompat/widget/SearchView;->S:I

    invoke-virtual {v4, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v6, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v5, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v13, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {v0, v8}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object v1, v7, Landroidx/appcompat/widget/SearchView;->a1:Landroid/text/TextWatcher;

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setOnEditorActionListener(Landroid/widget/TextView$OnEditorActionListener;)V

    invoke-virtual {v0, v10}, Landroid/widget/AutoCompleteTextView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    invoke-virtual {v0, v11}, Landroid/widget/AutoCompleteTextView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    iget-object v1, v7, Landroidx/appcompat/widget/SearchView;->W0:Landroid/view/View$OnKeyListener;

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnKeyListener(Landroid/view/View$OnKeyListener;)V

    new-instance v1, Landroidx/appcompat/widget/SearchView$d;

    invoke-direct {v1, v7}, Landroidx/appcompat/widget/SearchView$d;-><init>(Landroidx/appcompat/widget/SearchView;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->setOnFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_iconifiedByDefault:I

    const/4 v2, 0x1

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v1

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/SearchView;->setIconifiedByDefault(Z)V

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_android_maxWidth:I

    const/4 v2, -0x1

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result v1

    if-eq v1, v2, :cond_0

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/SearchView;->setMaxWidth(I)V

    :cond_0
    sget v1, Landroidx/appcompat/R$styleable;->SearchView_defaultQueryHint:I

    invoke-virtual {v14, v1}, Landroidx/appcompat/widget/n2;->x(I)Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->V:Ljava/lang/CharSequence;

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_queryHint:I

    invoke-virtual {v14, v1}, Landroidx/appcompat/widget/n2;->x(I)Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->H0:Ljava/lang/CharSequence;

    sget v1, Landroidx/appcompat/R$styleable;->SearchView_android_imeOptions:I

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v1

    if-eq v1, v2, :cond_1

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/SearchView;->setImeOptions(I)V

    :cond_1
    sget v1, Landroidx/appcompat/R$styleable;->SearchView_android_inputType:I

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result v1

    if-eq v1, v2, :cond_2

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/SearchView;->setInputType(I)V

    :cond_2
    sget v1, Landroidx/appcompat/R$styleable;->SearchView_android_focusable:I

    const/4 v2, 0x1

    invoke-virtual {v14, v1, v2}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result v1

    invoke-virtual {v7, v1}, Landroid/view/View;->setFocusable(Z)V

    invoke-virtual {v14}, Landroidx/appcompat/widget/n2;->I()V

    new-instance v1, Landroid/content/Intent;

    const-string v2, "cRsdSEtnpecohrWHeCnsd.oBaiisA.._"

    const-string/jumbo v2, "posEhCtd.Es_oeWBSa.nRdHi.rincAce"

    const-string v2, "..cm.dBWaAhHoiiseRcaero_tEEnCnSp"

    const-string v2, "android.speech.action.WEB_SEARCH"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->T:Landroid/content/Intent;

    const/high16 v2, 0x10000000

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const-string v3, "aAxeoG.MG.DpLeUntErdrONae.cLodEmihs"

    const-string v3, "G.amUoNGEeirEeM_a.pnDLdOxtcerd.sLhA"

    const-string v3, ".dcxtbnrALipDaALGE.hEesGr.eMed_UONa"

    const-string v3, "android.speech.extra.LANGUAGE_MODEL"

    const-string v4, "ahceb_uswe"

    const-string v4, "cbeso_hwea"

    const-string v4, "he_screpab"

    const-string/jumbo v4, "web_search"

    invoke-virtual {v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    new-instance v1, Landroid/content/Intent;

    const-string/jumbo v3, "iaG._CCpqnEoZ.dRhc.atdPEcEiSsHeEnNOobe"

    const-string/jumbo v3, "o.Sdobd_theenOiEGHE.nICERaiENZ.CpsPcac"

    const-string/jumbo v3, "rCsien.hGcaaIEP.EEidC.eZdnHstNpcERo_So"

    const-string v3, "android.speech.action.RECOGNIZE_SPEECH"

    invoke-direct {v1, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iput-object v1, v7, Landroidx/appcompat/widget/SearchView;->U:Landroid/content/Intent;

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v0}, Landroid/widget/AutoCompleteTextView;->getDropDownAnchor()I

    move-result v0

    invoke-virtual {v7, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, v7, Landroidx/appcompat/widget/SearchView;->J:Landroid/view/View;

    if-eqz v0, :cond_3

    new-instance v1, Landroidx/appcompat/widget/SearchView$e;

    invoke-direct {v1, v7}, Landroidx/appcompat/widget/SearchView$e;-><init>(Landroidx/appcompat/widget/SearchView;)V

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnLayoutChangeListener(Landroid/view/View$OnLayoutChangeListener;)V

    :cond_3
    iget-boolean v0, v7, Landroidx/appcompat/widget/SearchView;->D0:Z

    invoke-direct {v7, v0}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    invoke-direct/range {p0 .. p0}, Landroidx/appcompat/widget/SearchView;->n0()V

    return-void
.end method

.method private G(Ljava/lang/String;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/content/Intent;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/high16 p1, 0x10000000

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {v0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v2, 0x1

    if-eqz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo p1, "yuem_usurr"

    const-string p1, "_suryruueq"

    const/4 v2, 0x3

    const-string/jumbo p1, "yueeo_rsqr"

    const-string/jumbo p1, "user_query"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->N0:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/CharSequence;)Landroid/content/Intent;

    const/4 v2, 0x4

    const/4 v1, 0x3

    if-eqz p4, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const-string p1, "bequr"

    const-string/jumbo p1, "query"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_1
    const/4 v2, 0x1

    if-eqz p3, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo p1, "y_akn_uexit_ptaerante"

    const-string p1, "are_i_apxny_tadknteet"

    const/4 v2, 0x3

    const-string/jumbo p1, "tiaxtyepnntke__e_arad"

    const-string/jumbo p1, "intent_extra_data_key"

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->R0:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz p1, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo p2, "qtpaapda"

    const-string/jumbo p2, "qdpaptaa"

    const-string p2, "app_data"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    :cond_3
    const/4 v2, 0x1

    const/4 v1, 0x7

    if-eqz p5, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo p1, "y_stasknic"

    const-string p1, "_nscekiayt"

    const/4 v2, 0x2

    const-string p1, "action_key"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const-string p1, "coamm_nsmi"

    const-string p1, "cnimasm_go"

    const/4 v2, 0x5

    const-string p1, "_sgnoioacm"

    const-string p1, "action_msg"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_4
    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/app/SearchableInfo;->getSearchActivity()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method private H(Landroid/database/Cursor;ILjava/lang/String;)Landroid/content/Intent;
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v1, "_eionbgs_ttnnagisoutc"

    const-string/jumbo v1, "tcseontes_oig_gniautn"

    const/4 v9, 0x2

    const-string/jumbo v1, "tt_tniueusanit_gcogse"

    const-string/jumbo v1, "suggest_intent_action"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {p1, v1}, Landroidx/appcompat/widget/g2;->u(Landroid/database/Cursor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-nez v1, :cond_0

    const/4 v8, 0x3

    and-int/2addr v9, v8

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {v1}, Landroid/app/SearchableInfo;->getSuggestIntentAction()Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-nez v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string v1, ".ndtRniptia.SnotHCorAndiec.a"

    const-string v1, "android.intent.action.SEARCH"

    :cond_1
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v1, "a_stadetqneuitstgn_"

    const-string v1, "astngbduate_sntit_e"

    const/4 v9, 0x0

    const-string/jumbo v1, "ues_segtgitd_asntan"

    const-string/jumbo v1, "suggest_intent_data"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p1, v1}, Landroidx/appcompat/widget/g2;->u(Landroid/database/Cursor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-nez v1, :cond_2

    const/4 v9, 0x0

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v1}, Landroid/app/SearchableInfo;->getSuggestIntentData()Ljava/lang/String;

    move-result-object v1

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v1, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string/jumbo v3, "unemtagd_deui_a_singtt"

    const-string v3, "anans_u_sgetugitdeid_t"

    const/4 v9, 0x5

    const-string/jumbo v3, "suggest_intent_data_id"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p1, v3}, Landroidx/appcompat/widget/g2;->u(Landroid/database/Cursor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eqz v3, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v1, "/"

    const-string v1, "/"

    const/4 v9, 0x7

    const-string v1, "/"

    const-string v1, "/"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v3}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-nez v1, :cond_4

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_0

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string/jumbo v1, "ueepo_sitryquttngsne"

    const-string v1, "equgs_tpeutyetni_srn"

    const/4 v9, 0x1

    const-string v1, "gegrubnsq_untieyttse"

    const-string/jumbo v1, "suggest_intent_query"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {p1, v1}, Landroidx/appcompat/widget/g2;->u(Landroid/database/Cursor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string/jumbo v1, "ti_dseuqae_aatgxnrttgues_"

    const-string v1, "_exg_t_sqaettatnaiertsgdu"

    const/4 v9, 0x2

    const-string/jumbo v1, "reittgepnan_gtsdtuta__sxa"

    const-string/jumbo v1, "suggest_intent_extra_data"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1, v1}, Landroidx/appcompat/widget/g2;->u(Landroid/database/Cursor;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    move v6, p2

    const/4 v9, 0x1

    move v6, p2

    move v6, p2

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x4

    const/4 v8, 0x0

    invoke-direct/range {v1 .. v7}, Landroidx/appcompat/widget/SearchView;->G(Ljava/lang/String;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    return-object p1

    :catch_0
    move-exception p2

    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-interface {p1}, Landroid/database/Cursor;->getPosition()I

    move-result p1
    :try_end_1
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto :goto_1

    :catch_1
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 p1, -0x1

    :goto_1
    const/4 v8, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string v1, "Sitsarroqetnrsug gscsu o w ros ah"

    const-string v1, "aSsotasus r   sou ecrcognhgritswr"

    const/4 v9, 0x0

    const-string/jumbo v1, "toseagtassre ou rsisc   rncorwguh"

    const-string v1, "Search suggestions cursor at row "

    const/4 v9, 0x0

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const-string p1, "crtm o nxptmiendreeu"

    const-string p1, "etpmicu rnx edntro.e"

    const/4 v9, 0x6

    const-string/jumbo p1, "irr oncnpetxu.et oed"

    const-string p1, " returned exception."

    const/4 v9, 0x5

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string p3, "ehrioceSVa"

    const/4 v9, 0x2

    const-string/jumbo p3, "ierSVbhawe"

    const-string p3, "SearchView"

    const/4 v9, 0x3

    const/4 v8, 0x2

    invoke-static {p3, p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x1

    const/4 v9, 0x5

    return-object v0
.end method

.method private I(Landroid/content/Intent;Landroid/app/SearchableInfo;)Landroid/content/Intent;
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getSearchActivity()Landroid/content/ComponentName;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    new-instance v1, Landroid/content/Intent;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v2, "aHnCtnudSRdoobatieiAn.t.riEc"

    const-string v2, "H..CnbntieR.taSdAaitcodiornE"

    const/4 v9, 0x7

    const-string v2, "CanRESapcniAtoin.e.rotdiH.td"

    const-string v2, "android.intent.action.SEARCH"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/high16 v4, 0x42000000    # 32.0f

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v2, v3, v1, v4}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    new-instance v2, Landroid/os/Bundle;

    const/4 v9, 0x7

    const/4 v8, 0x6

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const/4 v8, 0x3

    move v9, v8

    iget-object v3, p0, Landroidx/appcompat/widget/SearchView;->R0:Landroid/os/Bundle;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v3, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string/jumbo v4, "qadpt_au"

    const-string v4, "aatpdau_"

    const/4 v9, 0x7

    const-string/jumbo v4, "past_pad"

    const-string v4, "app_data"

    const/4 v9, 0x3

    invoke-virtual {v2, v4, v3}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_0
    const/4 v8, 0x3

    new-instance v3, Landroid/content/Intent;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {v3, p1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoiceLanguageModeId()I

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz v4, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoiceLanguageModeId()I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p1, v4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    goto :goto_0

    :cond_1
    const/4 v9, 0x6

    const-string/jumbo v4, "ofem_mrfe"

    const-string v4, "free_form"

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoicePromptTextId()I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    const/4 v6, 0x0

    const/4 v9, 0x1

    if-eqz v5, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoicePromptTextId()I

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p1, v5}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_1

    :cond_2
    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x5

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoiceLanguageId()I

    move-result v7

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz v7, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoiceLanguageId()I

    move-result v7

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p1, v7}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    goto :goto_2

    :cond_3
    move-object p1, v6

    move-object p1, v6

    move-object p1, v6

    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoiceMaxResults()I

    move-result v7

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v7, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getVoiceMaxResults()I

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_3

    :cond_4
    const/4 v8, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 p2, 0x1

    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string/jumbo v7, "pNxao.iGaUMhAEOsrDErddeLe_topneA.L."

    const-string v7, "GdeedxrpiaeGsr.aO_tLNA.hnoDpEUMLEA."

    const/4 v9, 0x7

    const-string v7, "android.speech.extra.LANGUAGE_MODEL"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v3, v7, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v4, "..PrebTeidRocraOsPpeahd.xnt"

    const-string v4, "android.speech.extra.PROMPT"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string v4, "EApxaAuedGcdGhtn..sio.eqraerL"

    const-string/jumbo v4, "tGUder.Aqnxei.cLaapeEAGr.dohs"

    const/4 v9, 0x1

    const-string v4, "c.GNArUptLepoaExAdGaid.rn.see"

    const-string v4, "android.speech.extra.LANGUAGE"

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v3, v4, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string p1, "arra.X.AqnxesieSpoSL_.ehsRdMtTcE"

    const-string p1, "hcsSsE._aMUdSXxAiteTLreReanpo..r"

    const/4 v9, 0x6

    const-string/jumbo p1, "pAsLceheiT_EndrdXr.SaSxMUao.Rs.e"

    const-string p1, "android.speech.extra.MAX_RESULTS"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v3, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-nez v0, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_4

    :cond_5
    const/4 v9, 0x3

    invoke-virtual {v0}, Landroid/content/ComponentName;->flattenToShortString()Ljava/lang/String;

    move-result-object v6

    :goto_4
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo p1, "pgmmelaga_incac"

    const-string/jumbo p1, "lapmkgcng_iacae"

    const/4 v9, 0x0

    const-string p1, "gaacog_knalipec"

    const-string p1, "calling_package"

    const/4 v9, 0x4

    invoke-virtual {v3, p1, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string p1, "android.speech.extra.RESULTS_PENDINGINTENT"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v3, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string p1, "NNIT_biodt_DsThN.SBpINeGxcadTERUE.era.LESNUnoeDEP"

    const-string p1, "aNedoBntIGsI.d.N.SLTDNchiEPEETUTDpxoRaeL_N_UeErSN"

    const/4 v9, 0x0

    const-string p1, "DDroxNuErTTeGIU.TLhet_PLBnSUcdSNI_REEsEpiNa.da.NN"

    const-string p1, "android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v3, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    return-object v3
.end method

.method private J(Landroid/content/Intent;Landroid/app/SearchableInfo;)Landroid/content/Intent;
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v1, 0x3

    invoke-direct {v0, p1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p2}, Landroid/app/SearchableInfo;->getSearchActivity()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 p1, 0x5

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/ComponentName;->flattenToShortString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string p2, "c_alebapgkpgiln"

    const-string p2, "gniapbl_agacelk"

    const/4 v2, 0x6

    const-string/jumbo p2, "lpecklgaq_gaain"

    const-string p2, "calling_package"

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-virtual {v0, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method

.method private K()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/widget/AutoCompleteTextView;->dismissDropDown()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method private M(Landroid/view/View;Landroid/graphics/Rect;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->N:[I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Landroid/view/View;->getLocationInWindow([I)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->O:[I

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->getLocationInWindow([I)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->N:[I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    aget v2, v0, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v3, p0, Landroidx/appcompat/widget/SearchView;->O:[I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    aget v1, v3, v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    sub-int/2addr v2, v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    aget v0, v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    aget v1, v3, v1

    const/4 v4, 0x6

    or-int/2addr v5, v4

    sub-int/2addr v0, v1

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    add-int/2addr v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    add-int/2addr p1, v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p2, v0, v2, v1, p1}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-void
.end method

.method private N(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/widget/TextView;->getTextSize()F

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    float-to-double v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-wide/high16 v2, 0x3ff4000000000000L    # 1.25

    const-wide/high16 v2, 0x3ff4000000000000L    # 1.25

    const-wide/high16 v2, 0x3ff4000000000000L    # 1.25

    const-wide/high16 v2, 0x3ff4000000000000L    # 1.25

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    mul-double/2addr v0, v2

    const/4 v6, 0x7

    double-to-int v0, v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v2, v0, v0}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v0, Landroid/text/SpannableStringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v1, "   "

    const/4 v6, 0x4

    const-string v1, "   "

    const-string v1, "   "

    const/4 v5, 0x3

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Landroid/text/SpannableStringBuilder;-><init>(Ljava/lang/CharSequence;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    new-instance v1, Landroid/text/style/ImageSpan;

    const/4 v6, 0x0

    iget-object v2, p0, Landroidx/appcompat/widget/SearchView;->Q:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x6

    move v6, v5

    invoke-direct {v1, v2}, Landroid/text/style/ImageSpan;-><init>(Landroid/graphics/drawable/Drawable;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 v2, 0x2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/16 v3, 0x21

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v4, v2, v3}, Landroid/text/SpannableStringBuilder;->setSpan(Ljava/lang/Object;III)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Landroid/text/SpannableStringBuilder;->append(Ljava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-object v0

    :cond_1
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-object p1
.end method

.method private O()Z
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getVoiceSearchEnabled()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getVoiceSearchLaunchWebSearch()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->T:Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getVoiceSearchLaunchRecognizer()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->U:Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/high16 v3, 0x10000

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, v0, v3}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v0, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v1, 0x1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    return v1
.end method

.method static R(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget p0, p0, Landroid/content/res/Configuration;->orientation:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-ne p0, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 p0, 0x1

    const/4 v1, 0x7

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0
.end method

.method private T()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->G0:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->L0:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method private V(Landroid/content/Intent;)V
    .locals 5

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-nez p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "eusyi t: Flccdai itnaual"

    const-string/jumbo v2, "nha ucuyc i aaltiledFi:t"

    const/4 v4, 0x1

    const-string/jumbo v2, "icnm du Fec tahl:avlytii"

    const-string v2, "Failed launch activity: "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v1, "aVhpoieSer"

    const-string v1, "eSrawhepiV"

    const/4 v4, 0x2

    const-string v1, "herwibeacV"

    const-string v1, "SearchView"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1, p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v4, 0x1

    return-void
.end method

.method private X(IILjava/lang/String;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Landroidx/cursoradapter/widget/a;->d()Landroid/database/Cursor;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    invoke-interface {v0, p1}, Landroid/database/Cursor;->moveToPosition(I)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    invoke-direct {p0, v0, p2, p3}, Landroidx/appcompat/widget/SearchView;->H(Landroid/database/Cursor;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->V(Landroid/content/Intent;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x7

    return p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return p1
.end method

.method private getPreferredHeight()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget v1, Landroidx/appcompat/R$dimen;->abc_search_view_preferred_height:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method private getPreferredWidth()I
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    sget v1, Landroidx/appcompat/R$dimen;->abc_search_view_preferred_width:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method private i0()V
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->S0:Ljava/lang/Runnable;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method private j0(I)V
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v1}, Landroidx/cursoradapter/widget/a;->d()Landroid/database/Cursor;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v1, p1}, Landroid/database/Cursor;->moveToPosition(I)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v1}, Landroidx/cursoradapter/widget/a;->a(Landroid/database/Cursor;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->setQuery(Ljava/lang/CharSequence;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->setQuery(Ljava/lang/CharSequence;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->setQuery(Ljava/lang/CharSequence;)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method private l0()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x4

    xor-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x5

    iget-boolean v3, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-boolean v3, p0, Landroidx/appcompat/widget/SearchView;->O0:Z

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    move v1, v2

    move v1, v2

    const/4 v5, 0x7

    move v1, v2

    move v1, v2

    :cond_1
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v3, p0, Landroidx/appcompat/widget/SearchView;->H:Landroid/widget/ImageView;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/16 v2, 0x8

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v3, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->H:Landroid/widget/ImageView;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz v1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    move v5, v4

    sget-object v0, Landroid/view/ViewGroup;->ENABLED_STATE_SET:[I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto :goto_2

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object v0, Landroid/view/ViewGroup;->EMPTY_STATE_SET:[I

    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_4
    const/4 v5, 0x7

    return-void
.end method

.method private n0()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->getQueryHint()Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    :cond_0
    const/4 v3, 0x7

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->N(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setHint(Ljava/lang/CharSequence;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private o0()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/app/SearchableInfo;->getSuggestThreshold()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setThreshold(I)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/app/SearchableInfo;->getImeOptions()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setImeOptions(I)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getInputType()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    and-int/lit8 v1, v0, 0xf

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x1

    if-ne v1, v2, :cond_0

    const/4 v5, 0x5

    move v6, v5

    const v1, -0x10001

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    and-int/2addr v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/app/SearchableInfo;->getSuggestAuthority()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/high16 v1, 0x10000

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    or-int/2addr v0, v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/high16 v1, 0x80000

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    or-int/2addr v0, v1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setInputType(I)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v5, 0x5

    or-int/2addr v6, v5

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroidx/cursoradapter/widget/a;->b(Landroid/database/Cursor;)V

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getSuggestAuthority()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance v0, Landroidx/appcompat/widget/g2;

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v3, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v4, p0, Landroidx/appcompat/widget/SearchView;->U0:Ljava/util/WeakHashMap;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v0, v1, p0, v3, v4}, Landroidx/appcompat/widget/g2;-><init>(Landroid/content/Context;Landroidx/appcompat/widget/SearchView;Landroid/app/SearchableInfo;Ljava/util/WeakHashMap;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-object v0, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v6, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1, v0}, Landroid/widget/AutoCompleteTextView;->setAdapter(Landroid/widget/ListAdapter;)V

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v6, 0x3

    check-cast v0, Landroidx/appcompat/widget/g2;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-boolean v1, p0, Landroidx/appcompat/widget/SearchView;->I0:Z

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v2, 0x5

    const/4 v2, 0x2

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v0, v2}, Landroidx/appcompat/widget/g2;->E(I)V

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-void
.end method

.method private p0()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->T()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->G:Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->I:Landroid/widget/ImageView;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v0, :cond_1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/16 v0, 0x8

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->E:Landroid/view/View;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private q0(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->G0:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->T()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->L0:Z

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez p1, :cond_1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/16 p1, 0x8

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->G:Landroid/widget/ImageView;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v2, 0x2

    return-void
.end method

.method private r0(Z)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->E0:Z

    const/4 v5, 0x3

    and-int/2addr v6, v5

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    const/16 v1, 0x8

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz p1, :cond_0

    const/4 v6, 0x0

    move v2, v0

    move v2, v0

    const/4 v6, 0x0

    move v2, v0

    move v2, v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    move v2, v1

    move v2, v1

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v3, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x2

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    xor-int/lit8 v3, v3, 0x1

    const/4 v5, 0x2

    move v6, v5

    iget-object v4, p0, Landroidx/appcompat/widget/SearchView;->F:Landroid/widget/ImageView;

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v4, v2}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {p0, v3}, Landroidx/appcompat/widget/SearchView;->q0(Z)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object v2, p0, Landroidx/appcompat/widget/SearchView;->C:Landroid/view/View;

    const/4 v6, 0x6

    if-eqz p1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    move p1, v1

    move p1, v1

    const/4 v6, 0x4

    move p1, v1

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    move p1, v0

    move p1, v0

    const/4 v6, 0x5

    move p1, v0

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Landroid/view/View;->setVisibility(I)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->P:Landroid/widget/ImageView;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz p1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz p1, :cond_3

    :cond_2
    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    const/4 v6, 0x7

    move v0, v1

    move v0, v1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->P:Landroid/widget/ImageView;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->l0()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    xor-int/lit8 p1, v3, 0x1

    const/4 v5, 0x5

    or-int/2addr v6, v5

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->s0(Z)V

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->p0()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void
.end method

.method private s0(Z)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->L0:Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 v1, 0x8

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->G:Landroid/widget/ImageView;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->I:Landroid/widget/ImageView;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, v1}, Landroid/widget/ImageView;->setVisibility(I)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method private setQuery(Ljava/lang/CharSequence;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p1

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/EditText;->setSelection(I)V

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method F()V
    .locals 8

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->J:Landroid/view/View;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-le v0, v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->D:Landroid/view/View;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v2, Landroid/graphics/Rect;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v2}, Landroid/graphics/Rect;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p0}, Landroidx/appcompat/widget/y2;->b(Landroid/view/View;)Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-boolean v4, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v4, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    sget v4, Landroidx/appcompat/R$dimen;->abc_dropdownitem_icon_width:I

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {v0, v4}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget v5, Landroidx/appcompat/R$dimen;->abc_dropdownitem_text_padding_left:I

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v5}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    add-int/2addr v4, v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v4, 0x0

    :goto_0
    const/4 v7, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/widget/AutoCompleteTextView;->getDropDownBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    const/4 v7, 0x5

    if-eqz v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget v0, v2, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    neg-int v0, v0

    const/4 v6, 0x5

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget v0, v2, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-int/2addr v0, v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    sub-int v0, v1, v0

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v3, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v7, 0x5

    invoke-virtual {v3, v0}, Landroid/widget/AutoCompleteTextView;->setDropDownHorizontalOffset(I)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->J:Landroid/view/View;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v3, v2, Landroid/graphics/Rect;->left:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    add-int/2addr v0, v3

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    iget v2, v2, Landroid/graphics/Rect;->right:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    add-int/2addr v0, v2

    const/4 v7, 0x7

    add-int/2addr v0, v4

    const/4 v7, 0x1

    const/4 v6, 0x5

    sub-int/2addr v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v1, v0}, Landroid/widget/AutoCompleteTextView;->setDropDownWidth(I)V

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-void
.end method

.method L()V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v1, 0x1d

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0}, Landroidx/appcompat/widget/c2;->a(Landroidx/appcompat/widget/SearchView$SearchAutoComplete;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    sget-object v0, Landroidx/appcompat/widget/SearchView;->e1:Landroidx/appcompat/widget/SearchView$n;

    const/4 v2, 0x4

    move v3, v2

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SearchView$n;->b(Landroid/widget/AutoCompleteTextView;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SearchView$n;->a(Landroid/widget/AutoCompleteTextView;)V

    :goto_0
    const/4 v2, 0x6

    move v3, v2

    return-void
.end method

.method public P()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public Q()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->E0:Z

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public S()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->I0:Z

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method

.method public U()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->G0:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method W(ILjava/lang/String;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v1, ".dAc.RuiCSiaoatonnnqEieHt.td"

    const-string v1, "a.iroAtcqidiCaEnn.deSottnR.H"

    const-string/jumbo v1, "odtiRiap.e.ACrHnndEtnn.Sioct"

    const-string v1, "android.intent.action.SEARCH"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v3, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    move-object v4, p3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    move v5, p1

    move v5, p1

    const/4 v8, 0x5

    move v5, p1

    move v5, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v6}, Landroidx/appcompat/widget/SearchView;->G(Ljava/lang/String;Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p2, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-void
.end method

.method Y()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x2

    move v4, v3

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->k0:Landroidx/appcompat/widget/SearchView$k;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0}, Landroidx/appcompat/widget/SearchView$k;->a()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_2

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->clearFocus()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, v1}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setImeVisibility(Z)V

    :cond_2
    :goto_0
    const/4 v3, 0x4

    move v4, v3

    return-void
.end method

.method Z(IILjava/lang/String;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->B0:Landroidx/appcompat/widget/SearchView$m;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    const/4 p3, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x1

    if-eqz p2, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-interface {p2, p1}, Landroidx/appcompat/widget/SearchView$m;->onSuggestionClick(I)Z

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    if-nez p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    return p3

    :cond_1
    :goto_0
    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1, p3, p2}, Landroidx/appcompat/widget/SearchView;->X(IILjava/lang/String;)Z

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1, p3}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setImeVisibility(Z)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->K()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method a0(I)Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B0:Landroidx/appcompat/widget/SearchView$m;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {v0, p1}, Landroidx/appcompat/widget/SearchView$m;->onSuggestionSelect(I)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    return p1

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->j0(I)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return p1
.end method

.method b0(Ljava/lang/CharSequence;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->setQuery(Ljava/lang/CharSequence;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public c()V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->O0:Z

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->O0:Z

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Landroid/widget/TextView;->getImeOptions()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v0, p0, Landroidx/appcompat/widget/SearchView;->P0:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/high16 v2, 0x2000000

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    or-int/2addr v0, v2

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Landroid/widget/TextView;->setImeOptions(I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/SearchView;->setIconified(Z)V

    const/4 v3, 0x6

    move v4, v3

    return-void
.end method

.method c0()V
    .locals 4

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/view/View;->requestFocus()Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setImeVisibility(Z)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->C0:Landroid/view/View$OnClickListener;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v0, p0}, Landroid/view/View$OnClickListener;->onClick(Landroid/view/View;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public clearFocus()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x3

    iput-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->J0:Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-super {p0}, Landroid/view/ViewGroup;->clearFocus()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/view/View;->clearFocus()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setImeVisibility(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-boolean v1, p0, Landroidx/appcompat/widget/SearchView;->J0:Z

    return-void
.end method

.method d0()V
    .locals 5

    const/4 v4, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->getTrimmedLength(Ljava/lang/CharSequence;)I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-lez v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->W:Landroidx/appcompat/widget/SearchView$l;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v1, v2}, Landroidx/appcompat/widget/SearchView$l;->onQueryTextSubmit(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v1, :cond_2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0, v2, v1, v0}, Landroidx/appcompat/widget/SearchView;->W(ILjava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->setImeVisibility(Z)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->K()V

    :cond_2
    const/4 v3, 0x6

    move v4, v3

    return-void
.end method

.method e0(Landroid/view/View;ILandroid/view/KeyEvent;)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v1, 0x3

    move v2, v1

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x1

    return v0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p3}, Landroid/view/KeyEvent;->getAction()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p1, :cond_7

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p3}, Landroid/view/KeyEvent;->hasNoModifiers()Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p1, :cond_7

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/16 p1, 0x42

    const/4 v2, 0x0

    if-eq p2, p1, :cond_6

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 p1, 0x54

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq p2, p1, :cond_6

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/16 p1, 0x3d

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-ne p2, p1, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_2

    :cond_2
    const/4 v1, 0x5

    move v2, v1

    const/16 p1, 0x15

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eq p2, p1, :cond_4

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/16 p3, 0x16

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-ne p2, p3, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/16 p1, 0x13

    const/4 v2, 0x1

    const/4 v1, 0x6

    if-ne p2, p1, :cond_7

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/widget/AutoCompleteTextView;->getListSelection()I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0

    :cond_4
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-ne p2, p1, :cond_5

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    move p1, v0

    move p1, v0

    move p1, v0

    move p1, v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    goto :goto_1

    :cond_5
    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/widget/TextView;->length()I

    move-result p1

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Landroid/widget/EditText;->setSelection(I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/widget/AutoCompleteTextView;->setListSelection(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/widget/AutoCompleteTextView;->clearListSelection()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->b()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return p1

    :cond_6
    :goto_2
    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/widget/AutoCompleteTextView;->getListSelection()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 p2, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v0, p2}, Landroidx/appcompat/widget/SearchView;->Z(IILjava/lang/String;)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1

    :cond_7
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method f0(Ljava/lang/CharSequence;)V
    .locals 4

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x2

    move v3, v2

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-object v0, p0, Landroidx/appcompat/widget/SearchView;->N0:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    xor-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->q0(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    xor-int/lit8 v0, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->s0(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->l0()V

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->p0()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->W:Landroidx/appcompat/widget/SearchView$l;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->M0:Ljava/lang/CharSequence;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, v0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->W:Landroidx/appcompat/widget/SearchView$l;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-interface {v0, v1}, Landroidx/appcompat/widget/SearchView$l;->onQueryTextChange(Ljava/lang/String;)Z

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->M0:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method g0()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->i0()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->L()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public getImeOptions()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/widget/TextView;->getImeOptions()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public getInputType()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x7

    invoke-virtual {v0}, Landroid/widget/TextView;->getInputType()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    return v0
.end method

.method public getMaxWidth()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/widget/SearchView;->K0:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    return v0
.end method

.method public getQuery()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object v0
.end method

.method public getQueryHint()Ljava/lang/CharSequence;
    .locals 4
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->H0:Ljava/lang/CharSequence;

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getHintId()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1}, Landroid/app/SearchableInfo;->getHintId()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->V:Ljava/lang/CharSequence;

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method getSuggestionCommitIconResId()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/widget/SearchView;->S:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method getSuggestionRowLayout()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/widget/SearchView;->R:I

    const/4 v1, 0x3

    and-int/2addr v2, v1

    return v0
.end method

.method public getSuggestionsAdapter()Landroidx/cursoradapter/widget/a;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-object v0
.end method

.method public h()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v0, v1}, Landroidx/appcompat/widget/SearchView;->k0(Ljava/lang/CharSequence;Z)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->clearFocus()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v0, 0x1

    xor-int/2addr v4, v0

    const/4 v3, 0x0

    move v4, v3

    invoke-direct {p0, v0}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v4, 0x0

    iget v2, p0, Landroidx/appcompat/widget/SearchView;->P0:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setImeOptions(I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-boolean v1, p0, Landroidx/appcompat/widget/SearchView;->O0:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method h0()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getVoiceSearchLaunchWebSearch()Z

    move-result v1

    const/4 v2, 0x1

    move v3, v2

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->T:Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, v1, v0}, Landroidx/appcompat/widget/SearchView;->J(Landroid/content/Intent;Landroid/app/SearchableInfo;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0}, Landroid/app/SearchableInfo;->getVoiceSearchLaunchRecognizer()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->U:Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, v1, v0}, Landroidx/appcompat/widget/SearchView;->I(Landroid/content/Intent;Landroid/app/SearchableInfo;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v0, "heVasciSqe"

    const-string v0, "eisaSrechV"

    const/4 v3, 0x0

    const-string/jumbo v0, "rcsaiwVShe"

    const-string v0, "SearchView"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "vuvmooClcmahdtiyosnie t c i dcnetar "

    const-string/jumbo v1, "s emyivurhtte c oaCio  alcfiodncvdnt"

    const-string/jumbo v1, "ic aoonrutislodiovaCtc  v th ednfeiy"

    const-string v1, "Could not find voice search activity"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    return-void
.end method

.method public k0(Ljava/lang/CharSequence;Z)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/widget/TextView;->length()I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/widget/EditText;->setSelection(I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->N0:Ljava/lang/CharSequence;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz p2, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->d0()V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method m0()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-virtual {v0}, Landroid/view/View;->hasFocus()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Landroid/view/ViewGroup;->FOCUSED_STATE_SET:[I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Landroid/view/ViewGroup;->EMPTY_STATE_SET:[I

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->D:Landroid/view/View;

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Landroidx/appcompat/widget/SearchView;->E:Landroid/view/View;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method protected onDetachedFromWindow()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->S0:Ljava/lang/Runnable;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->T0:Ljava/lang/Runnable;

    const/4 v1, 0x0

    or-int/2addr v2, v1

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-super/range {p0 .. p5}, Landroidx/appcompat/widget/LinearLayoutCompat;->onLayout(ZIIII)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    if-eqz p1, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->L:Landroid/graphics/Rect;

    const/4 v1, 0x7

    const/4 v0, 0x7

    invoke-direct {p0, p1, p2}, Landroidx/appcompat/widget/SearchView;->M(Landroid/view/View;Landroid/graphics/Rect;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->M:Landroid/graphics/Rect;

    const/4 v0, 0x7

    move v1, v0

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->L:Landroid/graphics/Rect;

    const/4 v1, 0x5

    const/4 v0, 0x3

    iget p4, p2, Landroid/graphics/Rect;->left:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget p2, p2, Landroid/graphics/Rect;->right:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    sub-int/2addr p5, p3

    const/4 v1, 0x6

    const/4 p3, 0x0

    const/4 v1, 0x6

    move v0, p3

    move v0, p3

    const/4 v1, 0x5

    invoke-virtual {p1, p4, p3, p2, p5}, Landroid/graphics/Rect;->set(IIII)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->K:Landroidx/appcompat/widget/SearchView$o;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-nez p1, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p1, Landroidx/appcompat/widget/SearchView$o;

    const/4 v1, 0x2

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->M:Landroid/graphics/Rect;

    const/4 v1, 0x0

    iget-object p3, p0, Landroidx/appcompat/widget/SearchView;->L:Landroid/graphics/Rect;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget-object p4, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p1, p2, p3, p4}, Landroidx/appcompat/widget/SearchView$o;-><init>(Landroid/graphics/Rect;Landroid/graphics/Rect;Landroid/view/View;)V

    const/4 v1, 0x0

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->K:Landroidx/appcompat/widget/SearchView$o;

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Landroid/view/View;->setTouchDelegate(Landroid/view/TouchDelegate;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->M:Landroid/graphics/Rect;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p3, p0, Landroidx/appcompat/widget/SearchView;->L:Landroid/graphics/Rect;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1, p2, p3}, Landroidx/appcompat/widget/SearchView$o;->a(Landroid/graphics/Rect;Landroid/graphics/Rect;)V

    :cond_1
    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method protected onMeasure(II)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;->onMeasure(II)V

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/high16 v1, -0x80000000

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eq v0, v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eq v0, v2, :cond_1

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    iget v0, p0, Landroidx/appcompat/widget/SearchView;->K0:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-lez v0, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget p1, p0, Landroidx/appcompat/widget/SearchView;->K0:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-lez p1, :cond_3

    const/4 v3, 0x4

    and-int/2addr v4, v3

    goto :goto_0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->getPreferredWidth()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v0, p0, Landroidx/appcompat/widget/SearchView;->K0:I

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-lez v0, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_5
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->getPreferredWidth()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    :cond_6
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eq v0, v1, :cond_8

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto :goto_1

    :cond_7
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->getPreferredHeight()I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_1

    :cond_8
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->getPreferredHeight()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0, p2}, Ljava/lang/Math;->min(II)I

    move-result p2

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p2, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-super {p0, p1, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;->onMeasure(II)V

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method protected onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of v0, p1, Landroidx/appcompat/widget/SearchView$SavedState;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p1, Landroidx/appcompat/widget/SearchView$SavedState;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroidx/customview/view/AbsSavedState;->a()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-super {p0, v0}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-boolean p1, p1, Landroidx/appcompat/widget/SearchView$SavedState;->c:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method protected onSaveInstanceState()Landroid/os/Parcelable;
    .locals 4

    const/4 v3, 0x5

    invoke-super {p0}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance v1, Landroidx/appcompat/widget/SearchView$SavedState;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v1, v0}, Landroidx/appcompat/widget/SearchView$SavedState;-><init>(Landroid/os/Parcelable;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-boolean v0, v1, Landroidx/appcompat/widget/SearchView$SavedState;->c:Z

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v1
.end method

.method public onWindowFocusChanged(Z)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onWindowFocusChanged(Z)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->i0()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public requestFocus(ILandroid/graphics/Rect;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->J0:Z

    const/4 v2, 0x7

    move v3, v2

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/view/View;->isFocusable()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_3

    const/4 v3, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p2}, Landroid/view/View;->requestFocus(ILandroid/graphics/Rect;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, v1}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return p1

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->requestFocus(ILandroid/graphics/Rect;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return p1
.end method

.method public setAppSearchData(Landroid/os/Bundle;)V
    .locals 2
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->R0:Landroid/os/Bundle;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setIconified(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-eqz p1, :cond_0

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Y()V

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->c0()V

    :goto_0
    const/4 v1, 0x1

    return-void
.end method

.method public setIconifiedByDefault(Z)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-boolean v0, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-ne v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->D0:Z

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->n0()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setImeOptions(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setImeOptions(I)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public setInputType(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setInputType(I)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public setMaxWidth(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Landroidx/appcompat/widget/SearchView;->K0:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public setOnCloseListener(Landroidx/appcompat/widget/SearchView$k;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->k0:Landroidx/appcompat/widget/SearchView$k;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setOnQueryTextFocusChangeListener(Landroid/view/View$OnFocusChangeListener;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->A0:Landroid/view/View$OnFocusChangeListener;

    const/4 v1, 0x1

    return-void
.end method

.method public setOnQueryTextListener(Landroidx/appcompat/widget/SearchView$l;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->W:Landroidx/appcompat/widget/SearchView$l;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public setOnSearchClickListener(Landroid/view/View$OnClickListener;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->C0:Landroid/view/View$OnClickListener;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public setOnSuggestionListener(Landroidx/appcompat/widget/SearchView$m;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->B0:Landroidx/appcompat/widget/SearchView$m;

    const/4 v1, 0x7

    const/4 v0, 0x2

    return-void
.end method

.method public setQueryHint(Ljava/lang/CharSequence;)V
    .locals 2
    .param p1    # Ljava/lang/CharSequence;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->H0:Ljava/lang/CharSequence;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->n0()V

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public setQueryRefinementEnabled(Z)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->I0:Z

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    instance-of v1, v0, Landroidx/appcompat/widget/g2;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    check-cast v0, Landroidx/appcompat/widget/g2;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 p1, 0x1

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/g2;->E(I)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method public setSearchableInfo(Landroid/app/SearchableInfo;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->Q0:Landroid/app/SearchableInfo;

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->o0()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->n0()V

    :cond_0
    const/4 v2, 0x2

    invoke-direct {p0}, Landroidx/appcompat/widget/SearchView;->O()Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->L0:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "nm"

    const-string/jumbo v0, "mn"

    const/4 v2, 0x7

    const-string/jumbo v0, "nm"

    const-string/jumbo v0, "nm"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setPrivateImeOptions(Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public setSubmitButtonEnabled(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/widget/SearchView;->G0:Z

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroidx/appcompat/widget/SearchView;->Q()Z

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Landroidx/appcompat/widget/SearchView;->r0(Z)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public setSuggestionsAdapter(Landroidx/cursoradapter/widget/a;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Landroidx/appcompat/widget/SearchView;->F0:Landroidx/cursoradapter/widget/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/SearchView;->B:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/AutoCompleteTextView;->setAdapter(Landroid/widget/ListAdapter;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
