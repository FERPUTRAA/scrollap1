.class public Landroidx/appcompat/widget/ScrollingTabContainerView;
.super Landroid/widget/HorizontalScrollView;

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# annotations
.annotation build Landroidx/annotation/a1;
    value = {
        .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/ScrollingTabContainerView$e;,
        Landroidx/appcompat/widget/ScrollingTabContainerView$c;,
        Landroidx/appcompat/widget/ScrollingTabContainerView$b;,
        Landroidx/appcompat/widget/ScrollingTabContainerView$d;
    }
.end annotation


# static fields
.field private static final l:Ljava/lang/String; = "ScrollingTabContainerView"

.field private static final m:Landroid/view/animation/Interpolator;

.field private static final n:I = 0xc8


# instance fields
.field a:Ljava/lang/Runnable;

.field private b:Landroidx/appcompat/widget/ScrollingTabContainerView$c;

.field c:Landroidx/appcompat/widget/LinearLayoutCompat;

.field private d:Landroid/widget/Spinner;

.field private e:Z

.field f:I

.field g:I

.field private h:I

.field private i:I

.field protected j:Landroid/view/ViewPropertyAnimator;

.field protected final k:Landroidx/appcompat/widget/ScrollingTabContainerView$e;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Landroid/view/animation/DecelerateInterpolator;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    const/4 v2, 0x4

    sput-object v0, Landroidx/appcompat/widget/ScrollingTabContainerView;->m:Landroid/view/animation/Interpolator;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Landroid/widget/HorizontalScrollView;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Landroidx/appcompat/widget/ScrollingTabContainerView$e;-><init>(Landroidx/appcompat/widget/ScrollingTabContainerView;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->k:Landroidx/appcompat/widget/ScrollingTabContainerView$e;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0, v0}, Landroid/view/View;->setHorizontalScrollBarEnabled(Z)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p1}, Landroidx/appcompat/view/a;->b(Landroid/content/Context;)Landroidx/appcompat/view/a;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->f()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->setContentHeight(I)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->e()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->g:I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->f()Landroidx/appcompat/widget/LinearLayoutCompat;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, -0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v2, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v0, v1, v2}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0, p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method

.method private e()Landroid/widget/Spinner;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "/ s1 .~~t@o@  ~b@oMn @ y@ ~i@S-~@d@ o~mbs~@~ /~@~~ f~lv@@~b~ ~~of  oi@@ aK@~cit@@@u ~~lo @@~ ~~r"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    new-instance v0, Landroidx/appcompat/widget/AppCompatSpinner;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget v3, Landroidx/appcompat/R$attr;->actionDropDownStyle:I

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    invoke-direct {v0, v1, v2, v3}, Landroidx/appcompat/widget/AppCompatSpinner;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v2, -0x2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, -0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1, v2, v3}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(II)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    return-object v0
.end method

.method private f()Landroidx/appcompat/widget/LinearLayoutCompat;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v0, Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget v3, Landroidx/appcompat/R$attr;->actionBarTabBarStyle:I

    const/4 v5, 0x3

    invoke-direct {v0, v1, v2, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->setMeasureWithLargestChildEnabled(Z)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/16 v1, 0x11

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->setGravity(I)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v1, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, -0x2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v3, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v1, v2, v3}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(II)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-object v0
.end method

.method private h()Z
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-ne v0, p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method private i()V
    .locals 6

    const/4 v5, 0x5

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->h()Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->e()Landroid/widget/Spinner;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v5, 0x4

    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, -0x2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v3, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v1, v2, v3}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p0, v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v1, Landroidx/appcompat/widget/ScrollingTabContainerView$b;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v1, p0}, Landroidx/appcompat/widget/ScrollingTabContainerView$b;-><init>(Landroidx/appcompat/widget/ScrollingTabContainerView;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget v1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->i:I

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v0, v1}, Landroid/widget/AdapterView;->setSelection(I)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method private j()Z
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->h()Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    return v1

    :cond_0
    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v6, 0x6

    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v3, -0x2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v4, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v2, v3, v4}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->setTabSelected(I)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    return v1
.end method


# virtual methods
.method public a(Landroidx/appcompat/app/a$f;IZ)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->g(Landroidx/appcompat/app/a$f;Z)Landroidx/appcompat/widget/ScrollingTabContainerView$d;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance v2, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v5, 0x2

    and-int/2addr v6, v5

    const/4 v3, -0x6

    const/4 v3, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v2, v0, v3, v4}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(IIF)V

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, p1, p2, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz p2, :cond_0

    const/4 v6, 0x7

    invoke-virtual {p2}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x0

    check-cast p2, Landroidx/appcompat/widget/ScrollingTabContainerView$b;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p2}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v5, 0x2

    move v6, v5

    if-eqz p3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 p2, 0x1

    const/4 v5, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1, p2}, Landroidx/appcompat/widget/ScrollingTabContainerView$d;->setSelected(Z)V

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz p1, :cond_2

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-void
.end method

.method public b(Landroidx/appcompat/app/a$f;Z)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/4 v0, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->g(Landroidx/appcompat/app/a$f;Z)Landroidx/appcompat/widget/ScrollingTabContainerView$d;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v2, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v5, 0x2

    move v6, v5

    const/4 v3, -0x5

    const/4 v3, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/high16 v4, 0x3f800000    # 1.0f

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v2, v0, v3, v4}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(IIF)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1, p1, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v0, Landroidx/appcompat/widget/ScrollingTabContainerView$b;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    if-eqz p2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 p2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {p1, p2}, Landroidx/appcompat/widget/ScrollingTabContainerView$d;->setSelected(Z)V

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    if-eqz p1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return-void
.end method

.method public c(I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    const/4 v2, 0x1

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Landroidx/appcompat/widget/ScrollingTabContainerView$a;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {v0, p0, p1}, Landroidx/appcompat/widget/ScrollingTabContainerView$a;-><init>(Landroidx/appcompat/widget/ScrollingTabContainerView;Landroid/view/View;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    iput-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public d(I)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->j:Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/view/ViewPropertyAnimator;->cancel()V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-wide/16 v0, 0xc8

    const-wide/16 v0, 0xc8

    const/4 v5, 0x7

    const-wide/16 v0, 0xc8

    const-wide/16 v0, 0xc8

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0, v2}, Landroid/view/View;->setAlpha(F)V

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/high16 v3, 0x3f800000    # 1.0f

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-object v0, Landroidx/appcompat/widget/ScrollingTabContainerView;->m:Landroid/view/animation/Interpolator;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->k:Landroidx/appcompat/widget/ScrollingTabContainerView$e;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v2, p1}, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->a(Landroid/view/ViewPropertyAnimator;I)Landroidx/appcompat/widget/ScrollingTabContainerView$e;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2, p1}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Landroid/view/ViewPropertyAnimator;->start()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/view/View;->animate()Landroid/view/ViewPropertyAnimator;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v3, v2}, Landroid/view/ViewPropertyAnimator;->alpha(F)Landroid/view/ViewPropertyAnimator;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2, v0, v1}, Landroid/view/ViewPropertyAnimator;->setDuration(J)Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    sget-object v0, Landroidx/appcompat/widget/ScrollingTabContainerView;->m:Landroid/view/animation/Interpolator;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2, v0}, Landroid/view/ViewPropertyAnimator;->setInterpolator(Landroid/animation/TimeInterpolator;)Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->k:Landroidx/appcompat/widget/ScrollingTabContainerView$e;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v2, p1}, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->a(Landroid/view/ViewPropertyAnimator;I)Landroidx/appcompat/widget/ScrollingTabContainerView$e;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2, p1}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v2}, Landroid/view/ViewPropertyAnimator;->start()V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-void
.end method

.method g(Landroidx/appcompat/app/a$f;Z)Landroidx/appcompat/widget/ScrollingTabContainerView$d;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Landroidx/appcompat/widget/ScrollingTabContainerView$d;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, p0, v1, p1, p2}, Landroidx/appcompat/widget/ScrollingTabContainerView$d;-><init>(Landroidx/appcompat/widget/ScrollingTabContainerView;Landroid/content/Context;Landroidx/appcompat/app/a$f;Z)V

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance p1, Landroid/widget/AbsListView$LayoutParams;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p2, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->h:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p1, p2, v1}, Landroid/widget/AbsListView$LayoutParams;-><init>(II)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/view/View;->setFocusable(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->b:Landroidx/appcompat/widget/ScrollingTabContainerView$c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p1, Landroidx/appcompat/widget/ScrollingTabContainerView$c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p1, p0}, Landroidx/appcompat/widget/ScrollingTabContainerView$c;-><init>(Landroidx/appcompat/widget/ScrollingTabContainerView;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->b:Landroidx/appcompat/widget/ScrollingTabContainerView$c;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->b:Landroidx/appcompat/widget/ScrollingTabContainerView$c;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public k()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v2, 0x1

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast v0, Landroidx/appcompat/widget/ScrollingTabContainerView$b;

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {v0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-boolean v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public l(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v2, 0x0

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->removeViewAt(I)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    check-cast p1, Landroidx/appcompat/widget/ScrollingTabContainerView$b;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v2, 0x4

    iget-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public m(I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    check-cast p1, Landroidx/appcompat/widget/ScrollingTabContainerView$d;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroidx/appcompat/widget/ScrollingTabContainerView$d;->c()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/widget/AbsSpinner;->getAdapter()Landroid/widget/SpinnerAdapter;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast p1, Landroidx/appcompat/widget/ScrollingTabContainerView$b;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public onAttachedToWindow()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-super {p0}, Landroid/widget/HorizontalScrollView;->onAttachedToWindow()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method protected onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/widget/HorizontalScrollView;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1}, Landroidx/appcompat/view/a;->b(Landroid/content/Context;)Landroidx/appcompat/view/a;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->f()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->setContentHeight(I)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroidx/appcompat/view/a;->e()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->g:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public onDetachedFromWindow()V
    .locals 3

    const/4 v2, 0x2

    invoke-super {p0}, Landroid/widget/HorizontalScrollView;->onDetachedFromWindow()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->a:Ljava/lang/Runnable;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    check-cast p2, Landroidx/appcompat/widget/ScrollingTabContainerView$d;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p2}, Landroidx/appcompat/widget/ScrollingTabContainerView$d;->b()Landroidx/appcompat/app/a$f;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1}, Landroidx/appcompat/app/a$f;->g()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public onMeasure(II)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result p2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v0, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ne p2, v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    move v3, v0

    move v3, v0

    const/4 v7, 0x6

    move v3, v0

    move v3, v0

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    move v3, v1

    move v3, v1

    const/4 v7, 0x0

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    invoke-virtual {p0, v3}, Landroid/widget/HorizontalScrollView;->setFillViewport(Z)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v4, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v4}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-le v4, v0, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eq p2, v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/high16 v5, -0x80000000

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ne p2, v5, :cond_3

    :cond_1
    const/4 v6, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 p2, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-le v4, p2, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    int-to-float p2, p2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    const v4, 0x3ecccccd    # 0.4f

    const/4 v6, 0x5

    const/4 v7, 0x0

    mul-float/2addr p2, v4

    const/4 v6, 0x0

    const/4 v7, 0x5

    float-to-int p2, p2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->f:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    goto :goto_1

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    div-int/2addr v4, p2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput v4, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->f:I

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->f:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget v4, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->g:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p2, v4}, Ljava/lang/Math;->min(II)I

    move-result p2

    const/4 v7, 0x7

    const/4 v6, 0x1

    iput p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->f:I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_2

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 p2, -0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    iput p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->f:I

    :goto_2
    const/4 v7, 0x7

    iget p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->h:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {p2, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result p2

    const/4 v7, 0x0

    const/4 v6, 0x4

    if-nez v3, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x1

    iget-boolean v2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v2, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x0

    goto :goto_3

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    move v0, v1

    move v0, v1

    const/4 v7, 0x0

    move v0, v1

    move v0, v1

    :goto_3
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v0, :cond_6

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v1, p2}, Landroid/view/View;->measure(II)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-le v0, v1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->i()V

    const/4 v7, 0x7

    goto :goto_4

    :cond_5
    const/4 v7, 0x1

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->j()Z

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_4

    :cond_6
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {p0}, Landroidx/appcompat/widget/ScrollingTabContainerView;->j()Z

    :goto_4
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v6, 0x2

    move v7, v6

    invoke-super {p0, p1, p2}, Landroid/widget/HorizontalScrollView;->onMeasure(II)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v3, :cond_7

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eq v0, p1, :cond_7

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->i:I

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ScrollingTabContainerView;->setTabSelected(I)V

    :cond_7
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void
.end method

.method public onNothingSelected(Landroid/widget/AdapterView;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView<",
            "*>;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public setAllowCollapse(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->e:Z

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public setContentHeight(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->h:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public setTabSelected(I)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->i:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    move v2, v1

    move v2, v1

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-ge v2, v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v3, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->c:Landroidx/appcompat/widget/LinearLayoutCompat;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v3, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ne v2, p1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_1

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v4, v1

    move v4, v1

    const/4 v6, 0x2

    move v4, v1

    move v4, v1

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Landroid/view/View;->setSelected(Z)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v4, :cond_1

    const/4 v5, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/ScrollingTabContainerView;->c(I)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView;->d:Landroid/widget/Spinner;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ltz p1, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/AdapterView;->setSelection(I)V

    :cond_3
    return-void
.end method
