.class public Landroidx/appcompat/widget/LinearLayoutCompat;
.super Landroid/view/ViewGroup;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/LinearLayoutCompat$b;,
        Landroidx/appcompat/widget/LinearLayoutCompat$a;,
        Landroidx/appcompat/widget/LinearLayoutCompat$c;
    }
.end annotation


# static fields
.field private static final A:Ljava/lang/String; = "androidx.appcompat.widget.LinearLayoutCompat"

.field public static final p:I = 0x0

.field public static final q:I = 0x1

.field public static final r:I = 0x0

.field public static final s:I = 0x1

.field public static final t:I = 0x2

.field public static final u:I = 0x4

.field private static final v:I = 0x4

.field private static final w:I = 0x0

.field private static final x:I = 0x1

.field private static final y:I = 0x2

.field private static final z:I = 0x3


# instance fields
.field private a:Z

.field private b:I

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:F

.field private h:Z

.field private i:[I

.field private j:[I

.field private k:Landroid/graphics/drawable/Drawable;

.field private l:I

.field private m:I

.field private n:I

.field private o:I


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, p1, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    invoke-direct {p0, p1, p2, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .locals 12
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/AttributeSet;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v11, 0x0

    invoke-direct {p0, p1, p2, p3}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 v11, 0x0

    const/4 v0, 0x1

    const/4 v11, 0x6

    iput-boolean v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->a:Z

    const/4 v11, 0x0

    const/4 v1, -0x1

    const/4 v11, 0x2

    iput v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v11, 0x3

    const/4 v2, 0x0

    const/4 v11, 0x3

    iput v2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->c:I

    const/4 v11, 0x4

    const v3, 0x800033

    const/4 v11, 0x4

    iput v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v11, 0x3

    sget-object v6, Landroidx/appcompat/R$styleable;->LinearLayoutCompat:[I

    const/4 v11, 0x5

    invoke-static {p1, p2, v6, p3, v2}, Landroidx/appcompat/widget/n2;->G(Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/n2;

    move-result-object v3

    const/4 v11, 0x3

    invoke-virtual {v3}, Landroidx/appcompat/widget/n2;->B()Landroid/content/res/TypedArray;

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v11, 0x3

    move v9, p3

    move v9, p3

    move v9, p3

    move v9, p3

    const/4 v11, 0x2

    invoke-static/range {v4 .. v10}, Landroidx/core/view/k1;->z1(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    const/4 v11, 0x6

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_android_orientation:I

    const/4 v11, 0x7

    invoke-virtual {v3, p1, v1}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result p1

    const/4 v11, 0x4

    if-ltz p1, :cond_0

    const/4 v11, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->setOrientation(I)V

    :cond_0
    const/4 v11, 0x3

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_android_gravity:I

    const/4 v11, 0x2

    invoke-virtual {v3, p1, v1}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result p1

    const/4 v11, 0x1

    if-ltz p1, :cond_1

    const/4 v11, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->setGravity(I)V

    :cond_1
    const/4 v11, 0x2

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_android_baselineAligned:I

    const/4 v11, 0x0

    invoke-virtual {v3, p1, v0}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result p1

    const/4 v11, 0x5

    if-nez p1, :cond_2

    const/4 v11, 0x5

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->setBaselineAligned(Z)V

    :cond_2
    const/4 v11, 0x6

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_android_weightSum:I

    const/4 v11, 0x2

    const/high16 p2, -0x40800000    # -1.0f

    const/4 v11, 0x4

    invoke-virtual {v3, p1, p2}, Landroidx/appcompat/widget/n2;->j(IF)F

    move-result p1

    const/4 v11, 0x3

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->g:F

    const/4 v11, 0x0

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_android_baselineAlignedChildIndex:I

    const/4 v11, 0x6

    invoke-virtual {v3, p1, v1}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result p1

    const/4 v11, 0x2

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v11, 0x2

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_measureWithLargestChild:I

    const/4 v11, 0x2

    invoke-virtual {v3, p1, v2}, Landroidx/appcompat/widget/n2;->a(IZ)Z

    move-result p1

    const/4 v11, 0x5

    iput-boolean p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->h:Z

    const/4 v11, 0x5

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_divider:I

    const/4 v11, 0x6

    invoke-virtual {v3, p1}, Landroidx/appcompat/widget/n2;->h(I)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    const/4 v11, 0x0

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->setDividerDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v11, 0x1

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_showDividers:I

    const/4 v11, 0x1

    invoke-virtual {v3, p1, v2}, Landroidx/appcompat/widget/n2;->o(II)I

    move-result p1

    const/4 v11, 0x4

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    const/4 v11, 0x2

    sget p1, Landroidx/appcompat/R$styleable;->LinearLayoutCompat_dividerPadding:I

    const/4 v11, 0x4

    invoke-virtual {v3, p1, v2}, Landroidx/appcompat/widget/n2;->g(II)I

    move-result p1

    const/4 v11, 0x5

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v11, 0x5

    invoke-virtual {v3}, Landroidx/appcompat/widget/n2;->I()V

    const/4 v11, 0x4

    return-void
.end method

.method private E(Landroid/view/View;IIII)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "/ts~byl~ iob.~   ~@~uo~~@ @@ r d~a~1v~f~@K o  @~@@@o @@c4 o @~ i@~@n i-bms@@@/~~ MStl~@~~~ f@~~o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    add-int/2addr p4, p2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    add-int/2addr p5, p3

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-virtual {p1, p2, p3, p4, p5}, Landroid/view/View;->layout(IIII)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method private m(II)V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-ge v1, p1, :cond_1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v3

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    const/16 v4, 0x8

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-eq v2, v4, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    move-object v8, v2

    move-object v8, v2

    move-object v8, v2

    move-object v8, v2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    check-cast v8, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    iget v2, v8, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    const/4 v4, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-ne v2, v4, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    iget v9, v8, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredWidth()I

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    iput v2, v8, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    const/4 v5, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    move v4, p2

    move v4, p2

    const/4 v11, 0x7

    move v4, p2

    move v4, p2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    move v6, v0

    move v6, v0

    const/4 v11, 0x3

    move v6, v0

    move v6, v0

    const/4 v11, 0x0

    const/4 v10, 0x4

    invoke-virtual/range {v2 .. v7}, Landroid/view/ViewGroup;->measureChildWithMargins(Landroid/view/View;IIII)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    iput v9, v8, Landroid/widget/LinearLayout$LayoutParams;->width:I

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_0

    :cond_1
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    return-void
.end method

.method private n(II)V
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/high16 v1, 0x40000000    # 2.0f

    const/4 v11, 0x6

    const/4 v10, 0x5

    invoke-static {v0, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-ge v1, p1, :cond_1

    const/4 v11, 0x5

    invoke-virtual {p0, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v3

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/16 v4, 0x8

    const/4 v11, 0x5

    if-eq v2, v4, :cond_0

    const/4 v10, 0x7

    move v11, v10

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    move-object v8, v2

    move-object v8, v2

    move-object v8, v2

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    check-cast v8, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget v2, v8, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v4, -0x1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-ne v2, v4, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x1

    iget v9, v8, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v10, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredHeight()I

    move-result v2

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    iput v2, v8, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 v5, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    move v4, v0

    move v4, v0

    const/4 v11, 0x5

    move v4, v0

    move v4, v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    move v6, p2

    const/4 v11, 0x0

    move v6, p2

    move v6, p2

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual/range {v2 .. v7}, Landroid/view/ViewGroup;->measureChildWithMargins(Landroid/view/View;IIII)V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    iput v9, v8, Landroid/widget/LinearLayout$LayoutParams;->height:I

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    goto :goto_0

    :cond_1
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x3

    return-void
.end method


# virtual methods
.method A(Landroid/view/View;IIIII)V
    .locals 8

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    move v2, p3

    move v2, p3

    const/4 v7, 0x7

    move v2, p3

    move v2, p3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v3, p4

    move v3, p4

    const/4 v7, 0x3

    move v3, p4

    move v3, p4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    move v4, p5

    move v4, p5

    move v4, p5

    move v4, p5

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    move v5, p6

    move v5, p6

    const/4 v7, 0x5

    move v5, p6

    move v5, p6

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual/range {v0 .. v5}, Landroid/view/ViewGroup;->measureChildWithMargins(Landroid/view/View;IIII)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void
.end method

.method B(II)V
    .locals 38

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    const/4 v10, 0x0

    iput v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getVirtualChildCount()I

    move-result v11

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v12

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v13

    iget-object v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->i:[I

    const/4 v14, 0x4

    if-eqz v0, :cond_0

    iget-object v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->j:[I

    if-nez v0, :cond_1

    :cond_0
    new-array v0, v14, [I

    iput-object v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->i:[I

    new-array v0, v14, [I

    iput-object v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->j:[I

    :cond_1
    iget-object v15, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->i:[I

    iget-object v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->j:[I

    const/16 v16, 0x3

    const/4 v5, -0x1

    aput v5, v15, v16

    const/16 v17, 0x2

    aput v5, v15, v17

    const/16 v18, 0x1

    aput v5, v15, v18

    aput v5, v15, v10

    aput v5, v6, v16

    aput v5, v6, v17

    aput v5, v6, v18

    aput v5, v6, v10

    iget-boolean v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->a:Z

    iget-boolean v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->h:Z

    const/high16 v2, 0x40000000    # 2.0f

    if-ne v12, v2, :cond_2

    move/from16 v19, v18

    move/from16 v19, v18

    move/from16 v19, v18

    move/from16 v19, v18

    goto :goto_0

    :cond_2
    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    :goto_0
    const/16 v20, 0x0

    move v1, v10

    move v1, v10

    move v1, v10

    move v1, v10

    move v14, v1

    move v14, v1

    move v14, v1

    move v14, v1

    move/from16 v21, v14

    move/from16 v21, v14

    move/from16 v21, v14

    move/from16 v21, v14

    move/from16 v22, v21

    move/from16 v22, v21

    move/from16 v22, v21

    move/from16 v23, v22

    move/from16 v23, v22

    move/from16 v23, v22

    move/from16 v23, v22

    move/from16 v24, v23

    move/from16 v24, v23

    move/from16 v24, v23

    move/from16 v24, v23

    move/from16 v25, v24

    move/from16 v25, v24

    move/from16 v25, v24

    move/from16 v25, v24

    move/from16 v27, v25

    move/from16 v27, v25

    move/from16 v27, v25

    move/from16 v26, v18

    move/from16 v26, v18

    move/from16 v0, v20

    move/from16 v0, v20

    :goto_1
    move-object/from16 v28, v6

    move-object/from16 v28, v6

    move-object/from16 v28, v6

    move-object/from16 v28, v6

    const/16 v5, 0x8

    if-ge v1, v11, :cond_15

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v6

    if-nez v6, :cond_3

    iget v5, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->C(I)I

    move-result v6

    add-int/2addr v5, v6

    iput v5, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :goto_2
    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v37, v2

    move/from16 v37, v2

    move/from16 v37, v2

    move/from16 v37, v2

    move v2, v1

    move v2, v1

    move/from16 v1, v37

    move/from16 v1, v37

    move/from16 v1, v37

    move/from16 v1, v37

    goto/16 :goto_e

    :cond_3
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v10

    if-ne v10, v5, :cond_4

    invoke-virtual {v7, v6, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v5

    add-int/2addr v1, v5

    goto :goto_2

    :cond_4
    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v5

    if-eqz v5, :cond_5

    iget v5, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    add-int/2addr v5, v10

    iput v5, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :cond_5
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    move-object v10, v5

    check-cast v10, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v5, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    add-float v31, v0, v5

    if-ne v12, v2, :cond_8

    iget v0, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    if-nez v0, :cond_8

    cmpl-float v0, v5, v20

    if-lez v0, :cond_8

    if-eqz v19, :cond_6

    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v5, v10, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget v2, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v5, v2

    add-int/2addr v0, v5

    iput v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    goto :goto_3

    :cond_6
    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v2, v10, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v2, v0

    iget v5, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v2, v5

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :goto_3
    if-eqz v4, :cond_7

    const/4 v0, 0x0

    invoke-static {v0, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-virtual {v6, v2, v2}, Landroid/view/View;->measure(II)V

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move-object v3, v6

    move-object v3, v6

    move-object v3, v6

    move-object v3, v6

    const/16 v30, -0x2

    goto/16 :goto_7

    :cond_7
    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move-object v3, v6

    move-object v3, v6

    move/from16 v24, v18

    move/from16 v24, v18

    move/from16 v24, v18

    const/high16 v1, 0x40000000    # 2.0f

    const/16 v30, -0x2

    goto/16 :goto_8

    :cond_8
    iget v0, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    if-nez v0, :cond_9

    cmpl-float v0, v5, v20

    if-lez v0, :cond_9

    const/4 v5, -0x2

    iput v5, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v2, 0x0

    goto :goto_4

    :cond_9
    const/4 v5, -0x2

    const/high16 v2, -0x80000000

    :goto_4
    cmpl-float v0, v31, v20

    if-nez v0, :cond_a

    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move/from16 v29, v0

    move/from16 v29, v0

    goto :goto_5

    :cond_a
    const/16 v29, 0x0

    :goto_5
    const/16 v33, 0x0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v34, v1

    move/from16 v34, v1

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move/from16 v35, v2

    move/from16 v35, v2

    move/from16 v35, v2

    move/from16 v35, v2

    move/from16 v2, v34

    move/from16 v2, v34

    move/from16 v2, v34

    move/from16 v2, v34

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v4, v29

    move/from16 v4, v29

    move/from16 v4, v29

    move/from16 v4, v29

    move/from16 v29, v5

    move/from16 v29, v5

    const/4 v9, -0x1

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v30, v29

    move/from16 v30, v29

    move/from16 v30, v29

    const/high16 v9, -0x80000000

    move-object/from16 v29, v6

    move-object/from16 v29, v6

    move-object/from16 v29, v6

    move/from16 v6, v33

    move/from16 v6, v33

    move/from16 v6, v33

    move/from16 v6, v33

    invoke-virtual/range {v0 .. v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->A(Landroid/view/View;IIIII)V

    move/from16 v0, v35

    move/from16 v0, v35

    move/from16 v0, v35

    if-eq v0, v9, :cond_b

    iput v0, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    :cond_b
    invoke-virtual/range {v29 .. v29}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    if-eqz v19, :cond_c

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v2, v10, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v2, v0

    iget v3, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v2, v3

    move-object/from16 v3, v29

    move-object/from16 v3, v29

    move-object/from16 v3, v29

    move-object/from16 v3, v29

    invoke-virtual {v7, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v4

    add-int/2addr v2, v4

    add-int/2addr v1, v2

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    goto :goto_6

    :cond_c
    move-object/from16 v3, v29

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    add-int v2, v1, v0

    iget v4, v10, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v2, v4

    iget v4, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v2, v4

    invoke-virtual {v7, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v4

    add-int/2addr v2, v4

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :goto_6
    if-eqz v32, :cond_d

    invoke-static {v0, v14}, Ljava/lang/Math;->max(II)I

    move-result v14

    :cond_d
    :goto_7
    const/high16 v1, 0x40000000    # 2.0f

    :goto_8
    if-eq v13, v1, :cond_e

    iget v0, v10, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v2, -0x1

    if-ne v0, v2, :cond_e

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v27, v0

    move/from16 v27, v0

    move/from16 v27, v0

    move/from16 v27, v0

    goto :goto_9

    :cond_e
    const/4 v0, 0x0

    :goto_9
    iget v2, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget v4, v10, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v2, v4

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredHeight()I

    move-result v4

    add-int/2addr v4, v2

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredState()I

    move-result v5

    move/from16 v6, v25

    move/from16 v6, v25

    move/from16 v6, v25

    move/from16 v6, v25

    invoke-static {v6, v5}, Landroid/view/View;->combineMeasuredStates(II)I

    move-result v25

    if-eqz v36, :cond_10

    invoke-virtual {v3}, Landroid/view/View;->getBaseline()I

    move-result v5

    const/4 v6, -0x1

    if-eq v5, v6, :cond_10

    iget v6, v10, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    if-gez v6, :cond_f

    iget v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    :cond_f
    and-int/lit8 v6, v6, 0x70

    const/4 v9, 0x4

    shr-int/2addr v6, v9

    and-int/lit8 v6, v6, -0x2

    shr-int/lit8 v6, v6, 0x1

    aget v9, v15, v6

    invoke-static {v9, v5}, Ljava/lang/Math;->max(II)I

    move-result v9

    aput v9, v15, v6

    aget v9, v28, v6

    sub-int v5, v4, v5

    invoke-static {v9, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    aput v5, v28, v6

    :cond_10
    move/from16 v5, v21

    move/from16 v5, v21

    move/from16 v5, v21

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v21

    if-eqz v26, :cond_11

    iget v5, v10, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v6, -0x1

    if-ne v5, v6, :cond_11

    move/from16 v26, v18

    move/from16 v26, v18

    move/from16 v26, v18

    move/from16 v26, v18

    goto :goto_a

    :cond_11
    const/16 v26, 0x0

    :goto_a
    iget v5, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v5, v5, v20

    if-lez v5, :cond_13

    if-eqz v0, :cond_12

    goto :goto_b

    :cond_12
    move v2, v4

    move v2, v4

    move v2, v4

    move v2, v4

    :goto_b
    move/from16 v10, v23

    move/from16 v10, v23

    move/from16 v10, v23

    move/from16 v10, v23

    invoke-static {v10, v2}, Ljava/lang/Math;->max(II)I

    move-result v23

    goto :goto_d

    :cond_13
    move/from16 v10, v23

    move/from16 v10, v23

    move/from16 v10, v23

    move/from16 v10, v23

    if-eqz v0, :cond_14

    goto :goto_c

    :cond_14
    move v2, v4

    move v2, v4

    move v2, v4

    move v2, v4

    :goto_c
    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    invoke-static {v4, v2}, Ljava/lang/Math;->max(II)I

    move-result v22

    move/from16 v23, v10

    move/from16 v23, v10

    move/from16 v23, v10

    move/from16 v23, v10

    :goto_d
    move/from16 v10, v34

    move/from16 v10, v34

    move/from16 v10, v34

    move/from16 v10, v34

    invoke-virtual {v7, v3, v10}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v0

    add-int/2addr v0, v10

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    move/from16 v0, v31

    move/from16 v0, v31

    move/from16 v0, v31

    move/from16 v0, v31

    :goto_e
    add-int/lit8 v2, v2, 0x1

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    move-object/from16 v6, v28

    move-object/from16 v6, v28

    move-object/from16 v6, v28

    move-object/from16 v6, v28

    move/from16 v3, v32

    move/from16 v3, v32

    move/from16 v3, v32

    move/from16 v3, v32

    move/from16 v4, v36

    move/from16 v4, v36

    move/from16 v4, v36

    move/from16 v4, v36

    const/4 v5, -0x1

    const/4 v10, 0x0

    move/from16 v37, v2

    move/from16 v37, v2

    move/from16 v37, v2

    move/from16 v37, v2

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    move/from16 v1, v37

    move/from16 v1, v37

    move/from16 v1, v37

    goto/16 :goto_1

    :cond_15
    move v1, v2

    move v1, v2

    move v1, v2

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v32, v3

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v36, v4

    move/from16 v2, v21

    move/from16 v2, v21

    move/from16 v2, v21

    move/from16 v2, v21

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v10, v23

    move/from16 v10, v23

    move/from16 v10, v23

    move/from16 v6, v25

    move/from16 v6, v25

    move/from16 v6, v25

    move/from16 v6, v25

    const/high16 v9, -0x80000000

    const/16 v30, -0x2

    iget v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    if-lez v3, :cond_16

    invoke-virtual {v7, v11}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v3

    if-eqz v3, :cond_16

    iget v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    add-int/2addr v3, v1

    iput v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :cond_16
    aget v1, v15, v18

    const/4 v3, -0x1

    if-ne v1, v3, :cond_18

    const/16 v21, 0x0

    aget v5, v15, v21

    if-ne v5, v3, :cond_18

    aget v5, v15, v17

    if-ne v5, v3, :cond_18

    aget v5, v15, v16

    if-eq v5, v3, :cond_17

    goto :goto_f

    :cond_17
    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    move/from16 v23, v6

    move/from16 v23, v6

    move/from16 v23, v6

    move/from16 v23, v6

    goto :goto_10

    :cond_18
    :goto_f
    aget v3, v15, v16

    const/4 v5, 0x0

    aget v9, v15, v5

    aget v5, v15, v17

    invoke-static {v1, v5}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v9, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-static {v3, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    aget v3, v28, v16

    const/4 v5, 0x0

    aget v9, v28, v5

    aget v5, v28, v18

    move/from16 v23, v6

    move/from16 v23, v6

    move/from16 v23, v6

    move/from16 v23, v6

    aget v6, v28, v17

    invoke-static {v5, v6}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static {v9, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v3

    add-int/2addr v1, v3

    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    :goto_10
    if-eqz v32, :cond_1d

    const/high16 v2, -0x80000000

    if-eq v12, v2, :cond_19

    if-nez v12, :cond_1d

    :cond_19
    const/4 v2, 0x0

    iput v2, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    const/4 v2, 0x0

    :goto_11
    if-ge v2, v11, :cond_1d

    invoke-virtual {v7, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v3

    if-nez v3, :cond_1a

    iget v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v7, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->C(I)I

    move-result v5

    add-int/2addr v3, v5

    iput v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    goto :goto_12

    :cond_1a
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/16 v6, 0x8

    if-ne v5, v6, :cond_1b

    invoke-virtual {v7, v3, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v3

    add-int/2addr v2, v3

    :goto_12
    move/from16 v21, v1

    move/from16 v21, v1

    move/from16 v21, v1

    move/from16 v21, v1

    goto :goto_13

    :cond_1b
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    if-eqz v19, :cond_1c

    iget v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v9, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v9, v14

    iget v5, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v9, v5

    invoke-virtual {v7, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v3

    add-int/2addr v9, v3

    add-int/2addr v6, v9

    iput v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    goto :goto_12

    :cond_1c
    iget v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    add-int v9, v6, v14

    move/from16 v21, v1

    move/from16 v21, v1

    iget v1, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v9, v1

    iget v1, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v9, v1

    invoke-virtual {v7, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v1

    add-int/2addr v9, v1

    invoke-static {v6, v9}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :goto_13
    add-int/lit8 v2, v2, 0x1

    move/from16 v1, v21

    move/from16 v1, v21

    move/from16 v1, v21

    move/from16 v1, v21

    goto :goto_11

    :cond_1d
    move/from16 v21, v1

    move/from16 v21, v1

    move/from16 v21, v1

    move/from16 v21, v1

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v3

    add-int/2addr v2, v3

    add-int/2addr v1, v2

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getSuggestedMinimumWidth()I

    move-result v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    const/4 v2, 0x0

    invoke-static {v1, v8, v2}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result v1

    const v2, 0xffffff

    and-int/2addr v2, v1

    iget v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    sub-int/2addr v2, v3

    if-nez v24, :cond_22

    if-eqz v2, :cond_1e

    cmpl-float v5, v0, v20

    if-lez v5, :cond_1e

    goto :goto_16

    :cond_1e
    invoke-static {v4, v10}, Ljava/lang/Math;->max(II)I

    move-result v0

    if-eqz v32, :cond_21

    const/high16 v2, 0x40000000    # 2.0f

    if-eq v12, v2, :cond_21

    const/4 v10, 0x0

    :goto_14
    if-ge v10, v11, :cond_21

    invoke-virtual {v7, v10}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v2

    if-eqz v2, :cond_20

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v4

    const/16 v5, 0x8

    if-ne v4, v5, :cond_1f

    goto :goto_15

    :cond_1f
    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    check-cast v4, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v4, v4, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v4, v4, v20

    if-lez v4, :cond_20

    const/high16 v4, 0x40000000    # 2.0f

    invoke-static {v14, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v5

    invoke-virtual {v2}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    invoke-static {v6, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    invoke-virtual {v2, v5, v6}, Landroid/view/View;->measure(II)V

    :cond_20
    :goto_15
    add-int/lit8 v10, v10, 0x1

    goto :goto_14

    :cond_21
    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v3, v21

    move/from16 v3, v21

    move/from16 v3, v21

    move/from16 v3, v21

    goto/16 :goto_24

    :cond_22
    :goto_16
    iget v5, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->g:F

    cmpl-float v6, v5, v20

    if-lez v6, :cond_23

    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    :cond_23
    const/4 v5, -0x1

    aput v5, v15, v16

    aput v5, v15, v17

    aput v5, v15, v18

    const/4 v6, 0x0

    aput v5, v15, v6

    aput v5, v28, v16

    aput v5, v28, v17

    aput v5, v28, v18

    aput v5, v28, v6

    iput v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move v6, v4

    move v6, v4

    move v6, v4

    move v6, v4

    move v4, v5

    move v4, v5

    move v4, v5

    move v4, v5

    move/from16 v9, v23

    move/from16 v9, v23

    move/from16 v9, v23

    move/from16 v9, v23

    const/4 v10, 0x0

    :goto_17
    if-ge v10, v11, :cond_32

    invoke-virtual {v7, v10}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v14

    if-eqz v14, :cond_31

    invoke-virtual {v14}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/16 v3, 0x8

    if-ne v5, v3, :cond_24

    goto/16 :goto_20

    :cond_24
    invoke-virtual {v14}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v5

    check-cast v5, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v3, v5, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v23, v3, v20

    if-lez v23, :cond_29

    int-to-float v8, v2

    mul-float/2addr v8, v3

    div-float/2addr v8, v0

    float-to-int v8, v8

    sub-float/2addr v0, v3

    sub-int/2addr v2, v8

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v23

    add-int v3, v3, v23

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    iget v0, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v3, v0

    iget v0, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v3, v0

    iget v0, v5, Landroid/widget/LinearLayout$LayoutParams;->height:I

    move/from16 v24, v2

    move/from16 v24, v2

    move/from16 v24, v2

    move/from16 v24, v2

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    const/4 v11, -0x1

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    invoke-static {v2, v3, v0}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v0

    iget v3, v5, Landroid/widget/LinearLayout$LayoutParams;->width:I

    if-nez v3, :cond_27

    const/high16 v3, 0x40000000    # 2.0f

    if-eq v12, v3, :cond_25

    goto :goto_19

    :cond_25
    if-lez v8, :cond_26

    goto :goto_18

    :cond_26
    const/4 v8, 0x0

    :goto_18
    invoke-static {v8, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    invoke-virtual {v14, v8, v0}, Landroid/view/View;->measure(II)V

    goto :goto_1a

    :cond_27
    const/high16 v3, 0x40000000    # 2.0f

    :goto_19
    invoke-virtual {v14}, Landroid/view/View;->getMeasuredWidth()I

    move-result v29

    add-int v8, v29, v8

    if-gez v8, :cond_28

    const/4 v8, 0x0

    :cond_28
    invoke-static {v8, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    invoke-virtual {v14, v8, v0}, Landroid/view/View;->measure(II)V

    :goto_1a
    invoke-virtual {v14}, Landroid/view/View;->getMeasuredState()I

    move-result v0

    const/high16 v3, -0x1000000

    and-int/2addr v0, v3

    invoke-static {v9, v0}, Landroid/view/View;->combineMeasuredStates(II)I

    move-result v9

    move/from16 v0, v23

    move/from16 v0, v23

    move/from16 v0, v23

    move/from16 v0, v23

    move/from16 v3, v24

    move/from16 v3, v24

    move/from16 v3, v24

    move/from16 v3, v24

    goto :goto_1b

    :cond_29
    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    const/4 v11, -0x1

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    :goto_1b
    if-eqz v19, :cond_2a

    iget v8, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v14}, Landroid/view/View;->getMeasuredWidth()I

    move-result v23

    iget v11, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int v23, v23, v11

    iget v11, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int v23, v23, v11

    invoke-virtual {v7, v14}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v11

    add-int v23, v23, v11

    add-int v8, v8, v23

    iput v8, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    goto :goto_1c

    :cond_2a
    iget v8, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v14}, Landroid/view/View;->getMeasuredWidth()I

    move-result v11

    add-int/2addr v11, v8

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    iget v0, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v11, v0

    iget v0, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v11, v0

    invoke-virtual {v7, v14}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v0

    add-int/2addr v11, v0

    invoke-static {v8, v11}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :goto_1c
    const/high16 v0, 0x40000000    # 2.0f

    if-eq v13, v0, :cond_2b

    iget v0, v5, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v8, -0x1

    if-ne v0, v8, :cond_2b

    move/from16 v0, v18

    move/from16 v0, v18

    goto :goto_1d

    :cond_2b
    const/4 v0, 0x0

    :goto_1d
    iget v8, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    iget v11, v5, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v8, v11

    invoke-virtual {v14}, Landroid/view/View;->getMeasuredHeight()I

    move-result v11

    add-int/2addr v11, v8

    invoke-static {v4, v11}, Ljava/lang/Math;->max(II)I

    move-result v4

    if-eqz v0, :cond_2c

    goto :goto_1e

    :cond_2c
    move v8, v11

    move v8, v11

    move v8, v11

    move v8, v11

    :goto_1e
    invoke-static {v6, v8}, Ljava/lang/Math;->max(II)I

    move-result v0

    if-eqz v26, :cond_2d

    iget v6, v5, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v8, -0x1

    if-ne v6, v8, :cond_2e

    move/from16 v6, v18

    move/from16 v6, v18

    move/from16 v6, v18

    move/from16 v6, v18

    goto :goto_1f

    :cond_2d
    const/4 v8, -0x1

    :cond_2e
    const/4 v6, 0x0

    :goto_1f
    if-eqz v36, :cond_30

    invoke-virtual {v14}, Landroid/view/View;->getBaseline()I

    move-result v14

    if-eq v14, v8, :cond_30

    iget v5, v5, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    if-gez v5, :cond_2f

    iget v5, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    :cond_2f
    and-int/lit8 v5, v5, 0x70

    const/4 v8, 0x4

    shr-int/2addr v5, v8

    and-int/lit8 v5, v5, -0x2

    shr-int/lit8 v5, v5, 0x1

    aget v8, v15, v5

    invoke-static {v8, v14}, Ljava/lang/Math;->max(II)I

    move-result v8

    aput v8, v15, v5

    aget v8, v28, v5

    sub-int/2addr v11, v14

    invoke-static {v8, v11}, Ljava/lang/Math;->max(II)I

    move-result v8

    aput v8, v28, v5

    :cond_30
    move/from16 v26, v6

    move/from16 v26, v6

    move/from16 v26, v6

    move/from16 v26, v6

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    move/from16 v0, v23

    move/from16 v0, v23

    move/from16 v0, v23

    move/from16 v0, v23

    goto :goto_21

    :cond_31
    :goto_20
    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    :goto_21
    add-int/lit8 v10, v10, 0x1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    move/from16 v11, v25

    move/from16 v11, v25

    move/from16 v11, v25

    move/from16 v11, v25

    const/4 v5, -0x1

    goto/16 :goto_17

    :cond_32
    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    move/from16 v25, v11

    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    add-int/2addr v3, v5

    add-int/2addr v0, v3

    iput v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    aget v0, v15, v18

    const/4 v3, -0x1

    if-ne v0, v3, :cond_34

    const/4 v5, 0x0

    aget v8, v15, v5

    if-ne v8, v3, :cond_34

    aget v5, v15, v17

    if-ne v5, v3, :cond_34

    aget v5, v15, v16

    if-eq v5, v3, :cond_33

    goto :goto_22

    :cond_33
    move v0, v4

    move v0, v4

    move v0, v4

    move v0, v4

    goto :goto_23

    :cond_34
    :goto_22
    aget v3, v15, v16

    const/4 v5, 0x0

    aget v8, v15, v5

    aget v10, v15, v17

    invoke-static {v0, v10}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {v8, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    aget v3, v28, v16

    aget v5, v28, v5

    aget v8, v28, v18

    aget v10, v28, v17

    invoke-static {v8, v10}, Ljava/lang/Math;->max(II)I

    move-result v8

    invoke-static {v5, v8}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v3

    add-int/2addr v0, v3

    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    :goto_23
    move v3, v0

    move v3, v0

    move v3, v0

    move v3, v0

    move v0, v6

    move v0, v6

    move v0, v6

    move v0, v6

    move/from16 v23, v9

    move/from16 v23, v9

    :goto_24
    if-nez v26, :cond_35

    const/high16 v4, 0x40000000    # 2.0f

    if-eq v13, v4, :cond_35

    goto :goto_25

    :cond_35
    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    :goto_25
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    add-int/2addr v3, v4

    add-int/2addr v0, v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getSuggestedMinimumHeight()I

    move-result v3

    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/high16 v3, -0x1000000

    and-int v3, v23, v3

    or-int/2addr v1, v3

    shl-int/lit8 v3, v23, 0x10

    invoke-static {v0, v2, v3}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result v0

    invoke-virtual {v7, v1, v0}, Landroid/view/View;->setMeasuredDimension(II)V

    if-eqz v27, :cond_36

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v1, v25

    move/from16 v1, v25

    move/from16 v1, v25

    invoke-direct {v7, v1, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->m(II)V

    :cond_36
    return-void
.end method

.method C(I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return p1
.end method

.method D(II)V
    .locals 33

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    const/4 v10, 0x0

    iput v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getVirtualChildCount()I

    move-result v11

    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v12

    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v13

    iget v14, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    iget-boolean v15, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->h:Z

    const/16 v16, 0x1

    const/16 v17, 0x0

    move v1, v10

    move v1, v10

    move v1, v10

    move v1, v10

    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    move v3, v2

    move v3, v2

    move v4, v3

    move v4, v3

    move v4, v3

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    move v6, v5

    move v6, v5

    move v6, v5

    move v6, v5

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v18, v6

    move/from16 v20, v18

    move/from16 v20, v18

    move/from16 v20, v18

    move/from16 v20, v18

    move/from16 v19, v16

    move/from16 v19, v16

    move/from16 v19, v16

    move/from16 v19, v16

    move/from16 v0, v17

    move/from16 v0, v17

    move/from16 v0, v17

    move/from16 v0, v17

    :goto_0
    const/16 v10, 0x8

    move/from16 v22, v4

    move/from16 v22, v4

    if-ge v6, v11, :cond_10

    invoke-virtual {v7, v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v4

    if-nez v4, :cond_0

    iget v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v7, v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->C(I)I

    move-result v10

    add-int/2addr v4, v10

    iput v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    goto/16 :goto_a

    :cond_0
    move/from16 v24, v1

    move/from16 v24, v1

    move/from16 v24, v1

    move/from16 v24, v1

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-ne v1, v10, :cond_1

    invoke-virtual {v7, v4, v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v1

    add-int/2addr v6, v1

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v4, v22

    move/from16 v1, v24

    move/from16 v1, v24

    move/from16 v1, v24

    move/from16 v1, v24

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    goto/16 :goto_a

    :cond_1
    invoke-virtual {v7, v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v1

    if-eqz v1, :cond_2

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    add-int/2addr v1, v10

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :cond_2
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    move-object v10, v1

    check-cast v10, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v1, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    add-float v25, v0, v1

    const/high16 v0, 0x40000000    # 2.0f

    if-ne v13, v0, :cond_3

    iget v0, v10, Landroid/widget/LinearLayout$LayoutParams;->height:I

    if-nez v0, :cond_3

    cmpl-float v0, v1, v17

    if-lez v0, :cond_3

    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v1, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v1, v0

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    iget v2, v10, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move/from16 v31, v5

    move/from16 v31, v5

    move/from16 v31, v5

    move/from16 v31, v5

    move/from16 v18, v16

    move/from16 v18, v16

    move/from16 v18, v16

    move/from16 v18, v16

    move/from16 v8, v24

    move/from16 v8, v24

    move/from16 v29, v26

    move/from16 v29, v26

    move/from16 v29, v26

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v13, v22

    move v11, v6

    move v11, v6

    move v11, v6

    move v11, v6

    goto/16 :goto_3

    :cond_3
    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    move/from16 v26, v2

    iget v0, v10, Landroid/widget/LinearLayout$LayoutParams;->height:I

    if-nez v0, :cond_4

    cmpl-float v0, v1, v17

    if-lez v0, :cond_4

    const/4 v0, -0x2

    iput v0, v10, Landroid/widget/LinearLayout$LayoutParams;->height:I

    const/4 v2, 0x0

    goto :goto_1

    :cond_4
    const/high16 v2, -0x80000000

    :goto_1
    const/16 v27, 0x0

    cmpl-float v0, v25, v17

    if-nez v0, :cond_5

    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move/from16 v23, v0

    move/from16 v23, v0

    move/from16 v23, v0

    goto :goto_2

    :cond_5
    const/16 v23, 0x0

    :goto_2
    const/high16 v28, 0x40000000    # 2.0f

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move/from16 v8, v24

    move/from16 v8, v24

    move/from16 v8, v24

    move/from16 v8, v24

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move-object v1, v4

    move/from16 v30, v2

    move/from16 v30, v2

    move/from16 v30, v2

    move/from16 v30, v2

    move/from16 v29, v26

    move/from16 v29, v26

    move/from16 v29, v26

    move/from16 v29, v26

    move v2, v6

    move v2, v6

    move v2, v6

    move v2, v6

    move v9, v3

    move v9, v3

    move v9, v3

    move v9, v3

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v11, v28

    move/from16 v11, v28

    move/from16 v11, v28

    move/from16 v11, v28

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move/from16 v4, v27

    move/from16 v4, v27

    move/from16 v4, v27

    move/from16 v4, v27

    move/from16 v31, v5

    move/from16 v31, v5

    move/from16 v31, v5

    move/from16 v31, v5

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v5, p2

    move v11, v6

    move v11, v6

    move v11, v6

    move v11, v6

    move/from16 v6, v23

    move/from16 v6, v23

    move/from16 v6, v23

    invoke-virtual/range {v0 .. v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->A(Landroid/view/View;IIIII)V

    move/from16 v0, v30

    move/from16 v0, v30

    move/from16 v0, v30

    move/from16 v0, v30

    const/high16 v1, -0x80000000

    if-eq v0, v1, :cond_6

    iput v0, v10, Landroid/widget/LinearLayout$LayoutParams;->height:I

    :cond_6
    invoke-virtual/range {v22 .. v22}, Landroid/view/View;->getMeasuredHeight()I

    move-result v0

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    add-int v2, v1, v0

    iget v3, v10, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v2, v3

    iget v3, v10, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v2, v3

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    invoke-virtual {v7, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v4

    add-int/2addr v2, v4

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    if-eqz v15, :cond_7

    invoke-static {v0, v9}, Ljava/lang/Math;->max(II)I

    move-result v0

    goto :goto_3

    :cond_7
    move v0, v9

    move v0, v9

    move v0, v9

    move v0, v9

    :goto_3
    if-ltz v14, :cond_8

    add-int/lit8 v6, v11, 0x1

    if-ne v14, v6, :cond_8

    iget v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->c:I

    :cond_8
    if-ge v11, v14, :cond_a

    iget v1, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v1, v1, v17

    if-gtz v1, :cond_9

    goto :goto_4

    :cond_9
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "ed m,tIwsgt i ieiirdntntdnhehB istoBwts  rA hav n ,ioh  dxasai.gnflohiAld>Elhoeaieemegeri/h0htno wdi el eacdrmt nAha  llyn nuCgow /n/ioCeLnhsieke cdehsI xwlweeisehtd/   mrL.lx"

    const-string/jumbo v1, "nosh ioweiml ie ah i a isgtiohdIhtn v cnlstcrdhe  me/ dAi oknxhntwhiyigwllIeae    ir a.Ldn .AdxlssAsrgw lhltt/esCLBgin,nEhr ede df/teireaet olh nC Baoenwienhe>iddtmuhexewto/0,"

    const-string v1, "Cg hoehn eLwi fon ntlc/ne,neei,iioye glwh/rCdadtedin l  itwoheg ev eahecAh  iE .lsmtiAonr/n0ex atws x edsimki.sd/aonetx>l ILlthnrughthlirdd s ei hrh oBtn alsawBImiehAiwd ote e"

    const-string v1, "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won\'t work.  Either remove the weight, or don\'t set mBaselineAlignedChildIndex."

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a
    :goto_4
    const/high16 v1, 0x40000000    # 2.0f

    if-eq v12, v1, :cond_b

    iget v1, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_b

    move/from16 v1, v16

    move/from16 v1, v16

    move/from16 v1, v16

    move/from16 v1, v16

    move/from16 v20, v1

    move/from16 v20, v1

    goto :goto_5

    :cond_b
    const/4 v1, 0x0

    :goto_5
    iget v2, v10, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget v4, v10, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v2, v4

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    add-int/2addr v4, v2

    move/from16 v5, v29

    move/from16 v5, v29

    move/from16 v5, v29

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredState()I

    move-result v6

    invoke-static {v8, v6}, Landroid/view/View;->combineMeasuredStates(II)I

    move-result v6

    if-eqz v19, :cond_c

    iget v8, v10, Landroid/widget/LinearLayout$LayoutParams;->width:I

    const/4 v9, -0x1

    if-ne v8, v9, :cond_c

    move/from16 v19, v16

    move/from16 v19, v16

    goto :goto_6

    :cond_c
    const/16 v19, 0x0

    :goto_6
    iget v8, v10, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v8, v8, v17

    if-lez v8, :cond_e

    if-eqz v1, :cond_d

    goto :goto_7

    :cond_d
    move v2, v4

    move v2, v4

    move v2, v4

    move v2, v4

    :goto_7
    invoke-static {v13, v2}, Ljava/lang/Math;->max(II)I

    move-result v4

    move/from16 v1, v31

    move/from16 v1, v31

    move/from16 v1, v31

    goto :goto_9

    :cond_e
    if-eqz v1, :cond_f

    goto :goto_8

    :cond_f
    move v2, v4

    move v2, v4

    move v2, v4

    move v2, v4

    :goto_8
    move/from16 v1, v31

    move/from16 v1, v31

    move/from16 v1, v31

    move/from16 v1, v31

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    move-result v1

    move v4, v13

    move v4, v13

    move v4, v13

    move v4, v13

    :goto_9
    invoke-virtual {v7, v3, v11}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v2

    add-int/2addr v2, v11

    move v3, v0

    move v3, v0

    move v3, v0

    move v3, v0

    move/from16 v0, v25

    move/from16 v0, v25

    move/from16 v0, v25

    move/from16 v0, v25

    move/from16 v32, v5

    move/from16 v32, v5

    move/from16 v32, v5

    move/from16 v32, v5

    move v5, v1

    move v5, v1

    move v5, v1

    move v5, v1

    move v1, v6

    move v1, v6

    move v1, v6

    move v1, v6

    move v6, v2

    move v6, v2

    move v6, v2

    move v6, v2

    move/from16 v2, v32

    move/from16 v2, v32

    move/from16 v2, v32

    move/from16 v2, v32

    :goto_a
    add-int/lit8 v6, v6, 0x1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v8, p1

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v9, p2

    move/from16 v13, v24

    move/from16 v13, v24

    move/from16 v13, v24

    move/from16 v13, v24

    move/from16 v11, v26

    move/from16 v11, v26

    move/from16 v11, v26

    move/from16 v11, v26

    goto/16 :goto_0

    :cond_10
    move v8, v1

    move v8, v1

    move v8, v1

    move v8, v1

    move v9, v3

    move v9, v3

    move v9, v3

    move v9, v3

    move v1, v5

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v26, v11

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v24, v13

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v13, v22

    move/from16 v13, v22

    move v5, v2

    move v5, v2

    move v5, v2

    move v5, v2

    iget v2, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    if-lez v2, :cond_11

    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    invoke-virtual {v7, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v3

    if-eqz v3, :cond_12

    iget v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    iget v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    add-int/2addr v3, v4

    iput v3, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    goto :goto_b

    :cond_11
    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    move/from16 v2, v26

    :cond_12
    :goto_b
    move/from16 v3, v24

    move/from16 v3, v24

    move/from16 v3, v24

    move/from16 v3, v24

    if-eqz v15, :cond_16

    const/high16 v4, -0x80000000

    if-eq v3, v4, :cond_13

    if-nez v3, :cond_16

    :cond_13
    const/4 v4, 0x0

    iput v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    const/4 v4, 0x0

    :goto_c
    if-ge v4, v2, :cond_16

    invoke-virtual {v7, v4}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v6

    if-nez v6, :cond_14

    iget v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v7, v4}, Landroidx/appcompat/widget/LinearLayoutCompat;->C(I)I

    move-result v11

    add-int/2addr v6, v11

    iput v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    goto :goto_d

    :cond_14
    invoke-virtual {v6}, Landroid/view/View;->getVisibility()I

    move-result v11

    if-ne v11, v10, :cond_15

    invoke-virtual {v7, v6, v4}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v6

    add-int/2addr v4, v6

    goto :goto_d

    :cond_15
    invoke-virtual {v6}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v11

    check-cast v11, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v14, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    add-int v21, v14, v9

    iget v10, v11, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int v21, v21, v10

    iget v10, v11, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int v21, v21, v10

    invoke-virtual {v7, v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v6

    add-int v6, v21, v6

    invoke-static {v14, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    iput v6, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    :goto_d
    add-int/lit8 v4, v4, 0x1

    const/16 v10, 0x8

    goto :goto_c

    :cond_16
    iget v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v10

    add-int/2addr v6, v10

    add-int/2addr v4, v6

    iput v4, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getSuggestedMinimumHeight()I

    move-result v6

    invoke-static {v4, v6}, Ljava/lang/Math;->max(II)I

    move-result v4

    move/from16 v6, p2

    move/from16 v6, p2

    move/from16 v6, p2

    move/from16 v6, p2

    move v10, v9

    move v10, v9

    move v10, v9

    move v10, v9

    const/4 v9, 0x0

    invoke-static {v4, v6, v9}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result v4

    const v9, 0xffffff

    and-int/2addr v9, v4

    iget v11, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    sub-int/2addr v9, v11

    if-nez v18, :cond_1b

    if-eqz v9, :cond_17

    cmpl-float v11, v0, v17

    if-lez v11, :cond_17

    goto :goto_10

    :cond_17
    invoke-static {v1, v13}, Ljava/lang/Math;->max(II)I

    move-result v0

    if-eqz v15, :cond_1a

    const/high16 v1, 0x40000000    # 2.0f

    if-eq v3, v1, :cond_1a

    const/4 v1, 0x0

    :goto_e
    if-ge v1, v2, :cond_1a

    invoke-virtual {v7, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_19

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v9

    const/16 v11, 0x8

    if-ne v9, v11, :cond_18

    goto :goto_f

    :cond_18
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v9

    check-cast v9, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v9, v9, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v9, v9, v17

    if-lez v9, :cond_19

    invoke-virtual {v3}, Landroid/view/View;->getMeasuredWidth()I

    move-result v9

    const/high16 v11, 0x40000000    # 2.0f

    invoke-static {v9, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v9

    invoke-static {v10, v11}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v13

    invoke-virtual {v3, v9, v13}, Landroid/view/View;->measure(II)V

    :cond_19
    :goto_f
    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    :cond_1a
    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    move v1, v8

    move v1, v8

    move v1, v8

    move v1, v8

    goto/16 :goto_1a

    :cond_1b
    :goto_10
    iget v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->g:F

    cmpl-float v11, v10, v17

    if-lez v11, :cond_1c

    move v0, v10

    move v0, v10

    move v0, v10

    move v0, v10

    :cond_1c
    const/4 v10, 0x0

    iput v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move v11, v9

    move v11, v9

    move v11, v9

    move v11, v9

    move v9, v1

    move v9, v1

    move v9, v1

    move v1, v8

    move v1, v8

    move v1, v8

    move v1, v8

    move v8, v10

    move v8, v10

    :goto_11
    if-ge v8, v2, :cond_27

    invoke-virtual {v7, v8}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v13

    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    move-result v14

    const/16 v15, 0x8

    if-ne v14, v15, :cond_1d

    move/from16 v21, v11

    move/from16 v21, v11

    move/from16 v21, v11

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    goto/16 :goto_19

    :cond_1d
    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v14

    check-cast v14, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v10, v14, Landroid/widget/LinearLayout$LayoutParams;->weight:F

    cmpl-float v18, v10, v17

    if-lez v18, :cond_22

    int-to-float v15, v11

    mul-float/2addr v15, v10

    div-float/2addr v15, v0

    float-to-int v15, v15

    sub-float/2addr v0, v10

    sub-int/2addr v11, v15

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v10

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v18

    add-int v10, v10, v18

    move/from16 v18, v0

    move/from16 v18, v0

    iget v0, v14, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v10, v0

    iget v0, v14, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v10, v0

    iget v0, v14, Landroid/widget/LinearLayout$LayoutParams;->width:I

    move/from16 v21, v11

    move/from16 v21, v11

    move/from16 v21, v11

    move/from16 v21, v11

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    invoke-static {v11, v10, v0}, Landroid/view/ViewGroup;->getChildMeasureSpec(III)I

    move-result v0

    iget v10, v14, Landroid/widget/LinearLayout$LayoutParams;->height:I

    if-nez v10, :cond_20

    const/high16 v10, 0x40000000    # 2.0f

    if-eq v3, v10, :cond_1e

    goto :goto_13

    :cond_1e
    if-lez v15, :cond_1f

    goto :goto_12

    :cond_1f
    const/4 v15, 0x0

    :goto_12
    invoke-static {v15, v10}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v15

    invoke-virtual {v13, v0, v15}, Landroid/view/View;->measure(II)V

    goto :goto_14

    :cond_20
    const/high16 v10, 0x40000000    # 2.0f

    :goto_13
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    move-result v23

    add-int v15, v23, v15

    if-gez v15, :cond_21

    const/4 v15, 0x0

    :cond_21
    invoke-static {v15, v10}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v15

    invoke-virtual {v13, v0, v15}, Landroid/view/View;->measure(II)V

    :goto_14
    invoke-virtual {v13}, Landroid/view/View;->getMeasuredState()I

    move-result v0

    and-int/lit16 v0, v0, -0x100

    invoke-static {v1, v0}, Landroid/view/View;->combineMeasuredStates(II)I

    move-result v1

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v0, v18

    goto :goto_15

    :cond_22
    move v10, v11

    move v10, v11

    move v10, v11

    move v10, v11

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v21, v10

    move/from16 v21, v10

    move/from16 v21, v10

    move/from16 v21, v10

    :goto_15
    iget v10, v14, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    iget v15, v14, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v10, v15

    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v15

    add-int/2addr v15, v10

    invoke-static {v5, v15}, Ljava/lang/Math;->max(II)I

    move-result v5

    move/from16 v18, v0

    move/from16 v18, v0

    move/from16 v18, v0

    move/from16 v18, v0

    const/high16 v0, 0x40000000    # 2.0f

    if-eq v12, v0, :cond_23

    iget v0, v14, Landroid/widget/LinearLayout$LayoutParams;->width:I

    move/from16 v23, v1

    move/from16 v23, v1

    const/4 v1, -0x1

    if-ne v0, v1, :cond_24

    move/from16 v0, v16

    move/from16 v0, v16

    move/from16 v0, v16

    goto :goto_16

    :cond_23
    move/from16 v23, v1

    move/from16 v23, v1

    move/from16 v23, v1

    move/from16 v23, v1

    const/4 v1, -0x1

    :cond_24
    const/4 v0, 0x0

    :goto_16
    if-eqz v0, :cond_25

    goto :goto_17

    :cond_25
    move v10, v15

    move v10, v15

    move v10, v15

    move v10, v15

    :goto_17
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v0

    if-eqz v19, :cond_26

    iget v9, v14, Landroid/widget/LinearLayout$LayoutParams;->width:I

    if-ne v9, v1, :cond_26

    move/from16 v9, v16

    move/from16 v9, v16

    goto :goto_18

    :cond_26
    const/4 v9, 0x0

    :goto_18
    iget v10, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    move-result v15

    add-int/2addr v15, v10

    iget v1, v14, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v15, v1

    iget v1, v14, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v15, v1

    invoke-virtual {v7, v13}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v1

    add-int/2addr v15, v1

    invoke-static {v10, v15}, Ljava/lang/Math;->max(II)I

    move-result v1

    iput v1, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move/from16 v19, v9

    move/from16 v19, v9

    move/from16 v19, v9

    move/from16 v19, v9

    move/from16 v1, v23

    move/from16 v1, v23

    move/from16 v1, v23

    move/from16 v1, v23

    move v9, v0

    move v9, v0

    move v9, v0

    move v9, v0

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v0, v18

    move/from16 v0, v18

    :goto_19
    add-int/lit8 v8, v8, 0x1

    move/from16 v11, v21

    move/from16 v11, v21

    move/from16 v11, v21

    move/from16 v11, v21

    const/4 v10, 0x0

    goto/16 :goto_11

    :cond_27
    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    move/from16 v11, p1

    iget v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v8

    add-int/2addr v3, v8

    add-int/2addr v0, v3

    iput v0, v7, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    move v0, v9

    move v0, v9

    move v0, v9

    move v0, v9

    :goto_1a
    if-nez v19, :cond_28

    const/high16 v3, 0x40000000    # 2.0f

    if-eq v12, v3, :cond_28

    goto :goto_1b

    :cond_28
    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    :goto_1b
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v5

    add-int/2addr v3, v5

    add-int/2addr v0, v3

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getSuggestedMinimumWidth()I

    move-result v3

    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-static {v0, v11, v1}, Landroid/view/View;->resolveSizeAndState(III)I

    move-result v0

    invoke-virtual {v7, v0, v4}, Landroid/view/View;->setMeasuredDimension(II)V

    if-eqz v20, :cond_29

    invoke-direct {v7, v2, v6}, Landroidx/appcompat/widget/LinearLayoutCompat;->n(II)V

    :cond_29
    return-void
.end method

.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 2

    const/4 v1, 0x1

    instance-of p1, p1, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p1
.end method

.method protected bridge synthetic generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->o()Landroidx/appcompat/widget/LinearLayoutCompat$b;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public bridge synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->p(Landroid/util/AttributeSet;)Landroidx/appcompat/widget/LinearLayoutCompat$b;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p1
.end method

.method protected bridge synthetic generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->q(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/LinearLayoutCompat$b;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method public getBaseline()I
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-gez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-super {p0}, Landroid/view/ViewGroup;->getBaseline()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    iget v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-le v0, v1, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/view/View;->getBaseline()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v2, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ne v1, v2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v6, 0x3

    if-nez v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return v2

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v1, "lekBebtlia r d i godwwoh.dxs LVelLienast hntwstf eaitbn einnteh/eoyei Ao tl /noop onetsmiamuCtigodns  I"

    const-string v1, "dxemltesydooss isL lndtrnuoedenhpeiah n.kbto/  oitntoatw  miCtf  e l agloweIeh /ttni asaneAeiLo wViingB"

    const-string v1, " edin uaee dwad sbha   ete Cenelaai/mBIta/wirsniioltntAo yttinfo stuVodnnhxloigLsttsen ek ioeog.Lhl wop"

    const-string/jumbo v1, "mBaselineAlignedChildIndex of LinearLayout points to a View that doesn\'t know how to get its baseline."

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    throw v0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->c:I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-ne v3, v4, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x6

    iget v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    and-int/lit8 v3, v3, 0x70

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v4, 0x30

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eq v3, v4, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/16 v4, 0x10

    const/4 v6, 0x0

    const/4 v5, 0x5

    if-eq v3, v4, :cond_4

    const/4 v6, 0x5

    const/16 v4, 0x50

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq v3, v4, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    sub-int/2addr v2, v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    sub-int/2addr v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    sub-int/2addr v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    sub-int/2addr v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    sub-int/2addr v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    sub-int/2addr v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v4, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    sub-int/2addr v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    div-int/lit8 v3, v3, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    add-int/2addr v2, v3

    :cond_5
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    check-cast v0, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget v0, v0, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    add-int/2addr v2, v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    add-int/2addr v2, v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    return v2

    :cond_6
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "dtas tfprnm diIlt tninLoandd sf n . ets ghLeeouhoiuiseon dbeeCo nay BtaaAouxxioel"

    const-string/jumbo v1, "stn.on eoieAeCanaeau dtl  ngunniLotysotiesxoti de n sdx oBf moaetfILrhbludi hdi a"

    const-string/jumbo v1, "oiotL Brqosyb.oa  daidtinefu  tI xa ideuf nAloteilah eCdoLenem nndxns ithluneatsg"

    const-string/jumbo v1, "mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds."

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    throw v0
.end method

.method public getBaselineAlignedChildIndex()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public getDividerDrawable()Landroid/graphics/drawable/Drawable;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getDividerPadding()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public getDividerWidth()I
    .locals 3
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->c:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v2, 0x6

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public getGravity()I
    .locals 3
    .annotation build Landroidx/annotation/a0;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public getOrientation()I
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return v0
.end method

.method public getShowDividers()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method getVirtualChildCount()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public getWeightSum()F
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->g:F

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method i(Landroid/graphics/Canvas;)V
    .locals 8

    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getVirtualChildCount()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p0}, Landroidx/appcompat/widget/y2;->b(Landroid/view/View;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ge v2, v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/16 v5, 0x8

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eq v4, v5, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    check-cast v4, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3}, Landroid/view/View;->getRight()I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget v4, v4, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    const/4 v7, 0x7

    add-int/2addr v3, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x7

    iget v4, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    sub-int/2addr v3, v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget v4, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    sub-int/2addr v3, v4

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0, p1, v3}, Landroidx/appcompat/widget/LinearLayoutCompat;->l(Landroid/graphics/Canvas;I)V

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-eqz v2, :cond_6

    const/4 v6, 0x4

    and-int/2addr v7, v6

    add-int/lit8 v0, v0, -0x1

    const/4 v7, 0x0

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-nez v0, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v1, :cond_3

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    goto :goto_3

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    sub-int/2addr v0, v1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_2

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast v2, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-eqz v1, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget v1, v2, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v7, 0x7

    sub-int/2addr v0, v1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    sub-int/2addr v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_3

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget v1, v2, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    add-int/2addr v0, v1

    :goto_3
    const/4 v7, 0x7

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->l(Landroid/graphics/Canvas;I)V

    :cond_6
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-void
.end method

.method j(Landroid/graphics/Canvas;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getVirtualChildCount()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ge v1, v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v2, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v4, 0x8

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eq v3, v4, :cond_0

    invoke-virtual {p0, v1}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    check-cast v3, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Landroid/view/View;->getTop()I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v3, v3, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    sub-int/2addr v2, v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    sub-int/2addr v2, v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0, p1, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->k(Landroid/graphics/Canvas;I)V

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v0, v0, -0x1

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    sub-int/2addr v0, v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    sub-int/2addr v0, v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_1

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v1, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v1, v1, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    add-int/2addr v0, v1

    :goto_1
    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0, p1, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->k(Landroid/graphics/Canvas;I)V

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method k(Landroid/graphics/Canvas;I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget v2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    add-int/2addr v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    sub-int/2addr v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    sub-int/2addr v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    iget v3, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    const/4 v5, 0x7

    add-int/2addr v3, p2

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p2, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object p2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p2, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void
.end method

.method l(Landroid/graphics/Canvas;I)V
    .locals 7

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget v2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/2addr v1, v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    const/4 v5, 0x7

    move v6, v5

    add-int/2addr v2, p2

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    sub-int/2addr v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget v4, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    sub-int/2addr v3, v4

    const/4 v6, 0x0

    invoke-virtual {v0, p2, v1, v2, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object p2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p2, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-void
.end method

.method protected o()Landroidx/appcompat/widget/LinearLayoutCompat$b;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v1, -0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x7

    new-instance v0, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0, v1, v1}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(II)V

    const/4 v4, 0x6

    return-object v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v2, 0x1

    move v4, v2

    const/4 v3, 0x3

    or-int/2addr v4, v3

    if-ne v0, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0, v2, v1}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(II)V

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object v0
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->j(Landroid/graphics/Canvas;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat;->i(Landroid/graphics/Canvas;)V

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method public onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 3

    const/4 v2, 0x0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "odsmcgbpraLt.riodpwtadopiLxC.ienanateayt.mao"

    const-string/jumbo v0, "mdaoab.oopCcrLamtartip.a.Lwitdoapidtenpgenyx"

    const/4 v2, 0x4

    const-string v0, "apomaao..tyu.wocgpneLiptdndamireitoartCxLapd"

    const-string v0, "androidx.appcompat.widget.LinearLayoutCompat"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setClassName(Ljava/lang/CharSequence;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 3

    const/4 v2, 0x2

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "m.aoodudtrpeonyipiwrxtCpadmaetotgaaLLupnicao"

    const-string/jumbo v0, "matauLueoanpaganpycrddpxipmor.i.iaweCootdLtt"

    const/4 v2, 0x5

    const-string/jumbo v0, "pia.cbpioL.deadwnamp.iomtxgnaeyotdruroCLaptt"

    const-string v0, "androidx.appcompat.widget.LinearLayoutCompat"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method protected onLayout(ZIIII)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v1, 0x5

    move v2, v1

    const/4 v0, 0x1

    move v2, v0

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-ne p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p2, p3, p4, p5}, Landroidx/appcompat/widget/LinearLayoutCompat;->z(IIII)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    invoke-virtual {p0, p2, p3, p4, p5}, Landroidx/appcompat/widget/LinearLayoutCompat;->y(IIII)V

    :goto_0
    const/4 v2, 0x4

    return-void
.end method

.method protected onMeasure(II)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    move v2, v1

    move v2, v1

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;->D(II)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2}, Landroidx/appcompat/widget/LinearLayoutCompat;->B(II)V

    :goto_0
    const/4 v2, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method public p(Landroid/util/AttributeSet;)Landroidx/appcompat/widget/LinearLayoutCompat$b;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-direct {v0, v1, p1}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method protected q(Landroid/view/ViewGroup$LayoutParams;)Landroidx/appcompat/widget/LinearLayoutCompat$b;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    new-instance v0, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {v0, p1}, Landroidx/appcompat/widget/LinearLayoutCompat$b;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method r(Landroid/view/View;I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p1, 0x0

    return p1
.end method

.method s(Landroid/view/View;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return p1
.end method

.method public setBaselineAligned(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->a:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public setBaselineAlignedChildIndex(I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-ltz p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-ge p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->b:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "base aligned child index out of range (0, "

    const-string v1, "base aligned child index out of range (0, "

    const/4 v3, 0x0

    const-string v1, "base aligned child index out of range (0, "

    const-string v1, "base aligned child index out of range (0, "

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const-string v1, ")"

    const-string v1, ")"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    throw p1
.end method

.method public setDividerDrawable(Landroid/graphics/drawable/Drawable;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x2

    if-ne p1, v0, :cond_0

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->k:Landroid/graphics/drawable/Drawable;

    const/4 v3, 0x6

    const/4 v0, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p1, :cond_2

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public setDividerPadding(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->o:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public setGravity(I)V
    .locals 3
    .param p1    # I
        .annotation build Landroidx/annotation/a0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-eq v0, p1, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    const v0, 0x800007

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    and-int/2addr v0, p1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    const v0, 0x800003

    const/4 v2, 0x1

    or-int/2addr p1, v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    and-int/lit8 v0, p1, 0x70

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    or-int/lit8 p1, p1, 0x30

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setHorizontalGravity(I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const v0, 0x800007

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    and-int/2addr p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    and-int/2addr v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eq v0, p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const v0, -0x800008

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    and-int/2addr v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    or-int/2addr p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public setMeasureWithLargestChildEnabled(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-boolean p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->h:Z

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public setOrientation(I)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-eq v0, p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->d:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public setShowDividers(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    const/4 v2, 0x3

    if-eq p1, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public setVerticalGravity(I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    and-int/lit8 p1, p1, 0x70

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    and-int/lit8 v1, v0, 0x70

    const/4 v3, 0x7

    if-eq v1, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    and-int/lit8 v0, v0, -0x71

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    or-int/2addr p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public setWeightSum(F)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {v0, p1}, Ljava/lang/Math;->max(FF)F

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->g:F

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public shouldDelayChildPressedState()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method t(Landroid/view/View;)I
    .locals 2

    const/4 v1, 0x2

    const/4 p1, 0x7

    const/4 p1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p1
.end method

.method u(I)Landroid/view/View;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method protected v(I)Z
    .locals 6
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->a:Landroidx/annotation/a1$a;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    and-int/2addr p1, v1

    const/4 v5, 0x1

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v0

    :cond_1
    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-ne p1, v2, :cond_3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget p1, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    and-int/lit8 p1, p1, 0x4

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz p1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    const/4 v5, 0x5

    move v0, v1

    move v0, v1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget v2, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->n:I

    and-int/lit8 v2, v2, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v2, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    sub-int/2addr p1, v1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-ltz p1, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/16 v3, 0x8

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v2, v3, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    move v0, v1

    move v0, v1

    const/4 v5, 0x1

    move v0, v1

    move v0, v1

    const/4 v5, 0x1

    goto :goto_1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    add-int/lit8 p1, p1, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_5
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v0
.end method

.method public w()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-boolean v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->a:Z

    const/4 v1, 0x2

    const/4 v1, 0x6

    return v0
.end method

.method public x()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Landroidx/appcompat/widget/LinearLayoutCompat;->h:Z

    const/4 v1, 0x0

    shr-int/2addr v2, v1

    return v0
.end method

.method y(IIII)V
    .locals 24

    move-object/from16 v6, p0

    move-object/from16 v6, p0

    move-object/from16 v6, p0

    move-object/from16 v6, p0

    invoke-static/range {p0 .. p0}, Landroidx/appcompat/widget/y2;->b(Landroid/view/View;)Z

    move-result v0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v7

    sub-int v1, p4, p2

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    sub-int v8, v1, v2

    sub-int/2addr v1, v7

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingBottom()I

    move-result v2

    sub-int v9, v1, v2

    invoke-virtual/range {p0 .. p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getVirtualChildCount()I

    move-result v10

    iget v1, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    const v2, 0x800007

    and-int/2addr v2, v1

    and-int/lit8 v11, v1, 0x70

    iget-boolean v12, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->a:Z

    iget-object v13, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->i:[I

    iget-object v14, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->j:[I

    invoke-static/range {p0 .. p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v1

    invoke-static {v2, v1}, Landroidx/core/view/b0;->d(II)I

    move-result v1

    const/4 v15, 0x2

    const/4 v5, 0x1

    if-eq v1, v5, :cond_1

    const/4 v2, 0x5

    if-eq v1, v2, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    add-int v1, v1, p3

    sub-int v1, v1, p1

    iget v2, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    sub-int/2addr v1, v2

    goto :goto_0

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v1

    sub-int v2, p3, p1

    iget v3, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    sub-int/2addr v2, v3

    div-int/2addr v2, v15

    add-int/2addr v1, v2

    :goto_0
    const/4 v2, 0x0

    if-eqz v0, :cond_2

    add-int/lit8 v0, v10, -0x1

    move/from16 v16, v0

    move/from16 v16, v0

    move/from16 v16, v0

    move/from16 v16, v0

    const/16 v17, -0x1

    goto :goto_1

    :cond_2
    move/from16 v16, v2

    move/from16 v16, v2

    move/from16 v16, v2

    move/from16 v16, v2

    move/from16 v17, v5

    move/from16 v17, v5

    move/from16 v17, v5

    move/from16 v17, v5

    :goto_1
    move v3, v2

    move v3, v2

    move v3, v2

    move v3, v2

    :goto_2
    if-ge v3, v10, :cond_d

    mul-int v0, v17, v3

    add-int v2, v16, v0

    invoke-virtual {v6, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v0

    if-nez v0, :cond_3

    invoke-virtual {v6, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->C(I)I

    move-result v0

    add-int/2addr v1, v0

    move/from16 v21, v5

    move/from16 v21, v5

    move/from16 v21, v5

    move/from16 v21, v5

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v20, v11

    move/from16 v20, v11

    move/from16 v20, v11

    move/from16 v20, v11

    goto/16 :goto_6

    :cond_3
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v5

    const/16 v15, 0x8

    if-eq v5, v15, :cond_c

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v15

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v5

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v18

    move-object/from16 v4, v18

    move-object/from16 v4, v18

    move-object/from16 v4, v18

    move-object/from16 v4, v18

    check-cast v4, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    if-eqz v12, :cond_4

    iget v3, v4, Landroid/widget/LinearLayout$LayoutParams;->height:I

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    const/4 v10, -0x1

    if-eq v3, v10, :cond_5

    invoke-virtual {v0}, Landroid/view/View;->getBaseline()I

    move-result v10

    goto :goto_3

    :cond_4
    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    :cond_5
    const/4 v10, -0x1

    :goto_3
    iget v3, v4, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    if-gez v3, :cond_6

    move v3, v11

    move v3, v11

    move v3, v11

    move v3, v11

    :cond_6
    and-int/lit8 v3, v3, 0x70

    move/from16 v20, v11

    move/from16 v20, v11

    move/from16 v20, v11

    move/from16 v20, v11

    const/16 v11, 0x10

    if-eq v3, v11, :cond_a

    const/16 v11, 0x30

    if-eq v3, v11, :cond_8

    const/16 v11, 0x50

    if-eq v3, v11, :cond_7

    move v3, v7

    move v3, v7

    move v3, v7

    move v3, v7

    const/4 v11, -0x1

    goto :goto_4

    :cond_7
    sub-int v3, v8, v5

    iget v11, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    sub-int/2addr v3, v11

    const/4 v11, -0x1

    if-eq v10, v11, :cond_9

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredHeight()I

    move-result v21

    sub-int v21, v21, v10

    const/4 v10, 0x2

    aget v22, v14, v10

    sub-int v22, v22, v21

    sub-int v3, v3, v22

    goto :goto_4

    :cond_8
    const/4 v11, -0x1

    iget v3, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v3, v7

    if-eq v10, v11, :cond_9

    const/16 v21, 0x1

    aget v22, v13, v21

    sub-int v22, v22, v10

    add-int v3, v3, v22

    goto :goto_5

    :cond_9
    :goto_4
    const/16 v21, 0x1

    goto :goto_5

    :cond_a
    const/4 v11, -0x1

    const/16 v21, 0x1

    sub-int v3, v9, v5

    const/4 v10, 0x2

    div-int/2addr v3, v10

    add-int/2addr v3, v7

    iget v10, v4, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int/2addr v3, v10

    iget v10, v4, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    sub-int/2addr v3, v10

    :goto_5
    invoke-virtual {v6, v2}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v10

    if-eqz v10, :cond_b

    iget v10, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->l:I

    add-int/2addr v1, v10

    :cond_b
    iget v10, v4, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v10, v1

    invoke-virtual {v6, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->s(Landroid/view/View;)I

    move-result v1

    add-int v22, v10, v1

    move-object/from16 p1, v0

    move-object/from16 p1, v0

    move-object/from16 p1, v0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move v11, v2

    move v11, v2

    move v11, v2

    move v11, v2

    move/from16 v2, v22

    move/from16 v2, v22

    move/from16 v2, v22

    move/from16 v2, v22

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    const/16 v23, -0x1

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move v4, v15

    move v4, v15

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/widget/LinearLayoutCompat;->E(Landroid/view/View;IIII)V

    iget v0, v7, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    add-int/2addr v15, v0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    invoke-virtual {v6, v0}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v1

    add-int/2addr v15, v1

    add-int/2addr v10, v15

    invoke-virtual {v6, v0, v11}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v0

    add-int v3, v18, v0

    move v1, v10

    move v1, v10

    move v1, v10

    move v1, v10

    goto :goto_7

    :cond_c
    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v22, v7

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v19, v10

    move/from16 v20, v11

    move/from16 v20, v11

    move/from16 v20, v11

    move/from16 v20, v11

    const/16 v21, 0x1

    :goto_6
    const/16 v23, -0x1

    :goto_7
    add-int/lit8 v3, v3, 0x1

    move/from16 v10, v19

    move/from16 v10, v19

    move/from16 v10, v19

    move/from16 v11, v20

    move/from16 v11, v20

    move/from16 v11, v20

    move/from16 v11, v20

    move/from16 v5, v21

    move/from16 v5, v21

    move/from16 v5, v21

    move/from16 v5, v21

    move/from16 v7, v22

    move/from16 v7, v22

    move/from16 v7, v22

    move/from16 v7, v22

    const/4 v15, 0x2

    goto/16 :goto_2

    :cond_d
    return-void
.end method

.method z(IIII)V
    .locals 17

    move-object/from16 v6, p0

    move-object/from16 v6, p0

    move-object/from16 v6, p0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingLeft()I

    move-result v7

    sub-int v0, p3, p1

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v1

    sub-int v8, v0, v1

    sub-int/2addr v0, v7

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingRight()I

    move-result v1

    sub-int v9, v0, v1

    invoke-virtual/range {p0 .. p0}, Landroidx/appcompat/widget/LinearLayoutCompat;->getVirtualChildCount()I

    move-result v10

    iget v0, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->e:I

    and-int/lit8 v1, v0, 0x70

    const v2, 0x800007

    and-int v11, v0, v2

    const/16 v0, 0x10

    if-eq v1, v0, :cond_1

    const/16 v0, 0x50

    if-eq v1, v0, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    goto :goto_0

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    add-int v0, v0, p4

    sub-int v0, v0, p2

    iget v1, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    sub-int/2addr v0, v1

    goto :goto_0

    :cond_1
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getPaddingTop()I

    move-result v0

    sub-int v1, p4, p2

    iget v2, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->f:I

    sub-int/2addr v1, v2

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v0, v1

    :goto_0
    const/4 v1, 0x0

    move v12, v1

    move v12, v1

    move v12, v1

    move v12, v1

    :goto_1
    if-ge v12, v10, :cond_8

    invoke-virtual {v6, v12}, Landroidx/appcompat/widget/LinearLayoutCompat;->u(I)Landroid/view/View;

    move-result-object v13

    const/4 v14, 0x1

    if-nez v13, :cond_2

    invoke-virtual {v6, v12}, Landroidx/appcompat/widget/LinearLayoutCompat;->C(I)I

    move-result v1

    add-int/2addr v0, v1

    goto/16 :goto_4

    :cond_2
    invoke-virtual {v13}, Landroid/view/View;->getVisibility()I

    move-result v1

    const/16 v2, 0x8

    if-eq v1, v2, :cond_7

    invoke-virtual {v13}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    invoke-virtual {v13}, Landroid/view/View;->getMeasuredHeight()I

    move-result v15

    invoke-virtual {v13}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    check-cast v5, Landroidx/appcompat/widget/LinearLayoutCompat$b;

    iget v1, v5, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    if-gez v1, :cond_3

    move v1, v11

    move v1, v11

    move v1, v11

    move v1, v11

    :cond_3
    invoke-static/range {p0 .. p0}, Landroidx/core/view/k1;->Z(Landroid/view/View;)I

    move-result v2

    invoke-static {v1, v2}, Landroidx/core/view/b0;->d(II)I

    move-result v1

    and-int/lit8 v1, v1, 0x7

    if-eq v1, v14, :cond_5

    const/4 v2, 0x5

    if-eq v1, v2, :cond_4

    iget v1, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v1, v7

    goto :goto_3

    :cond_4
    sub-int v1, v8, v4

    iget v2, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    goto :goto_2

    :cond_5
    sub-int v1, v9, v4

    div-int/lit8 v1, v1, 0x2

    add-int/2addr v1, v7

    iget v2, v5, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    add-int/2addr v1, v2

    iget v2, v5, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    :goto_2
    sub-int/2addr v1, v2

    :goto_3
    move v2, v1

    move v2, v1

    move v2, v1

    move v2, v1

    invoke-virtual {v6, v12}, Landroidx/appcompat/widget/LinearLayoutCompat;->v(I)Z

    move-result v1

    if-eqz v1, :cond_6

    iget v1, v6, Landroidx/appcompat/widget/LinearLayoutCompat;->m:I

    add-int/2addr v0, v1

    :cond_6
    iget v1, v5, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    add-int v16, v0, v1

    invoke-virtual {v6, v13}, Landroidx/appcompat/widget/LinearLayoutCompat;->s(Landroid/view/View;)I

    move-result v0

    add-int v3, v16, v0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object v1, v13

    move-object v1, v13

    move-object v1, v13

    move-object v1, v13

    move-object v14, v5

    move-object v14, v5

    move v5, v15

    move v5, v15

    move v5, v15

    move v5, v15

    invoke-direct/range {v0 .. v5}, Landroidx/appcompat/widget/LinearLayoutCompat;->E(Landroid/view/View;IIII)V

    iget v0, v14, Landroid/widget/LinearLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v15, v0

    invoke-virtual {v6, v13}, Landroidx/appcompat/widget/LinearLayoutCompat;->t(Landroid/view/View;)I

    move-result v0

    add-int/2addr v15, v0

    add-int v16, v16, v15

    invoke-virtual {v6, v13, v12}, Landroidx/appcompat/widget/LinearLayoutCompat;->r(Landroid/view/View;I)I

    move-result v0

    add-int/2addr v12, v0

    move/from16 v0, v16

    move/from16 v0, v16

    move/from16 v0, v16

    move/from16 v0, v16

    const/4 v1, 0x1

    goto :goto_5

    :cond_7
    :goto_4
    move v1, v14

    move v1, v14

    :goto_5
    add-int/2addr v12, v1

    goto/16 :goto_1

    :cond_8
    return-void
.end method
