.class Landroidx/appcompat/widget/f1$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/f1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/f1;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/f1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/widget/f1$b;->a:Landroidx/appcompat/widget/f1;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/f1$b;->a:Landroidx/appcompat/widget/f1;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v1, v0, Landroidx/appcompat/widget/f1;->n:Landroidx/appcompat/widget/f1$b;

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public b()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/f1$b;->a:Landroidx/appcompat/widget/f1;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public run()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/f1$b;->a:Landroidx/appcompat/widget/f1;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v1, v0, Landroidx/appcompat/widget/f1;->n:Landroidx/appcompat/widget/f1$b;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroidx/appcompat/widget/f1;->drawableStateChanged()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method
