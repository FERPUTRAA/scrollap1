.class Landroidx/appcompat/widget/f2$c;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/MenuItem$OnMenuItemClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/f2;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Landroidx/appcompat/widget/f2;


# direct methods
.method constructor <init>(Landroidx/appcompat/widget/f2;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Landroidx/appcompat/widget/f2$c;->a:Landroidx/appcompat/widget/f2;

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onMenuItemClick(Landroid/view/MenuItem;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " fs@ /m~-t~f@i ~@~Mo@~Sot@ ~/K@a 1o  viisc @b ~@@@ ~~l~@d l~~~@n~ @@@@b~~@ o o~ .~o4~~ @bury@@~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Landroidx/appcompat/widget/f2$c;->a:Landroidx/appcompat/widget/f2;

    const/4 v3, 0x6

    const/4 v2, 0x4

    iget-object v1, v0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v0, v0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v1, v0}, Landroidx/appcompat/widget/c;->d(Landroid/content/Context;Ljava/lang/String;)Landroidx/appcompat/widget/c;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/c;->b(I)Landroid/content/Intent;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const-string/jumbo v1, "sDnmit.N.t.SnninodcEriaoad"

    const-string v1, ".tsoDnnNdinac.i.ndSaoirEtt"

    const/4 v3, 0x2

    const-string v1, "Dntioa..attnoioeiEScnddrN."

    const-string v1, "android.intent.action.SEND"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string/jumbo v1, "onm.LbEPiStUnaiILn_Dan.eTMddo.tctNi"

    const-string/jumbo v1, "iL.mtEoeTUonPnNdtLDiM.n.nd_citIaESa"

    const/4 v3, 0x1

    const-string v1, "DTdtdLutcorE.ne_In.iiaLNna.MtSPUiEo"

    const-string v1, "android.intent.action.SEND_MULTIPLE"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/f2$c;->a:Landroidx/appcompat/widget/f2;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/f2;->r(Landroid/content/Intent;)V

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/f2$c;->a:Landroidx/appcompat/widget/f2;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, v0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_2
    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    return p1
.end method
