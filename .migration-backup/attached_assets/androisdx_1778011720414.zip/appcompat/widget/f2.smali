.class public Landroidx/appcompat/widget/f2;
.super Landroidx/core/view/b;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroidx/appcompat/widget/f2$b;,
        Landroidx/appcompat/widget/f2$c;,
        Landroidx/appcompat/widget/f2$a;
    }
.end annotation


# static fields
.field private static final k:I = 0x4

.field public static final l:Ljava/lang/String; = "share_history.xml"


# instance fields
.field private e:I

.field private final f:Landroidx/appcompat/widget/f2$c;

.field final g:Landroid/content/Context;

.field h:Ljava/lang/String;

.field i:Landroidx/appcompat/widget/f2$a;

.field private j:Landroidx/appcompat/widget/c$f;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Landroidx/core/view/b;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    or-int/2addr v2, v1

    iput v0, p0, Landroidx/appcompat/widget/f2;->e:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Landroidx/appcompat/widget/f2$c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Landroidx/appcompat/widget/f2$c;-><init>(Landroidx/appcompat/widget/f2;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Landroidx/appcompat/widget/f2;->f:Landroidx/appcompat/widget/f2$c;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "_ysex.lhrirsosshm"

    const-string/jumbo v0, "irsasmrsyel_h.ohx"

    const/4 v2, 0x7

    const-string/jumbo v0, "share_history.xml"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v2, 0x4

    iput-object p1, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method private n()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~S~mi@-~ d@~@n.l~~fb@~@~~@b@~ @v yo@~   ms@ u@@ ai/  @t~~ @@M  i co1~~~@ flo4@~or o/@~to ~~~~b@K"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Landroidx/appcompat/widget/f2;->i:Landroidx/appcompat/widget/f2$a;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x7

    iget-object v0, p0, Landroidx/appcompat/widget/f2;->j:Landroidx/appcompat/widget/c$f;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v0, Landroidx/appcompat/widget/f2$b;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, p0}, Landroidx/appcompat/widget/f2$b;-><init>(Landroidx/appcompat/widget/f2;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Landroidx/appcompat/widget/f2;->j:Landroidx/appcompat/widget/c$f;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroidx/appcompat/widget/c;->d(Landroid/content/Context;Ljava/lang/String;)Landroidx/appcompat/widget/c;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->j:Landroidx/appcompat/widget/c$f;

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/c;->u(Landroidx/appcompat/widget/c$f;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public b()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x7

    return v0
.end method

.method public d()Landroid/view/View;
    .locals 7

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v0, Landroidx/appcompat/widget/ActivityChooserView;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v6, 0x3

    invoke-direct {v0, v1}, Landroidx/appcompat/widget/ActivityChooserView;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/view/View;->isInEditMode()Z

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v2, p0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v1, v2}, Landroidx/appcompat/widget/c;->d(Landroid/content/Context;Ljava/lang/String;)Landroidx/appcompat/widget/c;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/ActivityChooserView;->setActivityChooserModel(Landroidx/appcompat/widget/c;)V

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-instance v1, Landroid/util/TypedValue;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v1}, Landroid/util/TypedValue;-><init>()V

    const/4 v5, 0x7

    move v6, v5

    iget-object v2, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget v3, Landroidx/appcompat/R$attr;->actionModeShareDrawable:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2, v3, v1, v4}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget-object v2, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget v1, v1, Landroid/util/TypedValue;->resourceId:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v2, v1}, Lf/a;->b(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/ActivityChooserView;->setExpandActivityOverflowButtonDrawable(Landroid/graphics/drawable/Drawable;)V

    const/4 v6, 0x7

    invoke-virtual {v0, p0}, Landroidx/appcompat/widget/ActivityChooserView;->setProvider(Landroidx/core/view/b;)V

    const/4 v6, 0x0

    sget v1, Landroidx/appcompat/R$string;->abc_shareactionprovider_share_with_application:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/ActivityChooserView;->setDefaultActionButtonContentDescription(I)V

    const/4 v6, 0x0

    sget v1, Landroidx/appcompat/R$string;->abc_shareactionprovider_share_with:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/ActivityChooserView;->setExpandActivityOverflowButtonContentDescription(I)V

    const/4 v5, 0x7

    move v6, v5

    return-object v0
.end method

.method public g(Landroid/view/SubMenu;)V
    .locals 10

    const/4 v9, 0x3

    invoke-interface {p1}, Landroid/view/Menu;->clear()V

    const/4 v9, 0x5

    const/4 v8, 0x5

    iget-object v0, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {v0, v1}, Landroidx/appcompat/widget/c;->d(Landroid/content/Context;Ljava/lang/String;)Landroidx/appcompat/widget/c;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0}, Landroidx/appcompat/widget/c;->f()I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget v3, p0, Landroidx/appcompat/widget/f2;->e:I

    const/4 v8, 0x1

    move v9, v8

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v4, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v5, v4

    move v5, v4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-ge v5, v3, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v0, v5}, Landroidx/appcompat/widget/c;->e(I)Landroid/content/pm/ResolveInfo;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v6, v1}, Landroid/content/pm/ResolveInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v7

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {p1, v4, v5, v5, v7}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v7

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v6, v1}, Landroid/content/pm/ResolveInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v7, v6}, Landroid/view/MenuItem;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    move-result-object v6

    const/4 v8, 0x7

    move v9, v8

    iget-object v7, p0, Landroidx/appcompat/widget/f2;->f:Landroidx/appcompat/widget/f2$c;

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-interface {v6, v7}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    add-int/lit8 v5, v5, 0x1

    const/4 v8, 0x6

    shl-int/2addr v9, v8

    goto :goto_0

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-ge v3, v2, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v5, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    sget v6, Landroidx/appcompat/R$string;->abc_activity_chooser_view_see_all:I

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v5, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-interface {p1, v4, v3, v3, v5}, Landroid/view/Menu;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    move v3, v4

    move v3, v4

    const/4 v9, 0x3

    move v3, v4

    move v3, v4

    :goto_1
    const/4 v9, 0x0

    if-ge v3, v2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v3}, Landroidx/appcompat/widget/c;->e(I)Landroid/content/pm/ResolveInfo;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v5, v1}, Landroid/content/pm/ResolveInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-interface {p1, v4, v3, v3, v6}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v5, v1}, Landroid/content/pm/ResolveInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v6, v5}, Landroid/view/MenuItem;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v6, p0, Landroidx/appcompat/widget/f2;->f:Landroidx/appcompat/widget/f2$c;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-interface {v5, v6}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    return-void
.end method

.method public o(Landroidx/appcompat/widget/f2$a;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Landroidx/appcompat/widget/f2;->i:Landroidx/appcompat/widget/f2$a;

    const/4 v1, 0x0

    invoke-direct {p0}, Landroidx/appcompat/widget/f2;->n()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public p(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Landroidx/appcompat/widget/f2;->n()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public q(Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "ei.noD.SotamnddnrcnitEatio"

    const-string/jumbo v1, "ndDmidraoi.t.ctnienoaSEn.t"

    const/4 v3, 0x6

    const-string v1, "dEaeDbnidotSin.ctrat.Noni."

    const-string v1, "android.intent.action.SEND"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v1, "do.nnNuTntceonLiiMUttS.IaEirLoa_PE."

    const-string v1, "dStEocniatTN.LPLoInEdnoM.ern_.iaitU"

    const/4 v3, 0x7

    const-string v1, "EiordnapiL.taSIDnTiP.nLNn.EeModtcUt"

    const-string v1, "android.intent.action.SEND_MULTIPLE"

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroidx/appcompat/widget/f2;->r(Landroid/content/Intent;)V

    :cond_1
    const/4 v3, 0x4

    iget-object v0, p0, Landroidx/appcompat/widget/f2;->g:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Landroidx/appcompat/widget/f2;->h:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, v1}, Landroidx/appcompat/widget/c;->d(Landroid/content/Context;Ljava/lang/String;)Landroidx/appcompat/widget/c;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroidx/appcompat/widget/c;->t(Landroid/content/Intent;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method r(Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/high16 v0, 0x8080000

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method
