.class public Landroidx/appcompat/widget/ScrollingTabContainerView$e;
.super Landroid/animation/AnimatorListenerAdapter;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/widget/ScrollingTabContainerView;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4
    name = "e"
.end annotation


# instance fields
.field private a:Z

.field private b:I

.field final synthetic c:Landroidx/appcompat/widget/ScrollingTabContainerView;


# direct methods
.method protected constructor <init>(Landroidx/appcompat/widget/ScrollingTabContainerView;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    iput-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->c:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->a:Z

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(Landroid/view/ViewPropertyAnimator;I)Landroidx/appcompat/widget/ScrollingTabContainerView$e;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~us~otb~//~ ~@@ @ ao.fo@m@t-~o@ o~~lnb@~@ @ @@@yM @@~Kr ~ 4 ~@~ @~ @~dof~@  ~sbvcl~ @~1ii ~i~ S~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iput p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iget-object p2, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->c:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    iput-object p1, p2, Landroidx/appcompat/widget/ScrollingTabContainerView;->j:Landroid/view/ViewPropertyAnimator;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method public onAnimationCancel(Landroid/animation/Animator;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 p1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->a:Z

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public onAnimationEnd(Landroid/animation/Animator;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->a:Z

    const/4 v2, 0x1

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->c:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p1, Landroidx/appcompat/widget/ScrollingTabContainerView;->j:Landroid/view/ViewPropertyAnimator;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public onAnimationStart(Landroid/animation/Animator;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object p1, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->c:Landroidx/appcompat/widget/ScrollingTabContainerView;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    iput-boolean v0, p0, Landroidx/appcompat/widget/ScrollingTabContainerView$e;->a:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method
