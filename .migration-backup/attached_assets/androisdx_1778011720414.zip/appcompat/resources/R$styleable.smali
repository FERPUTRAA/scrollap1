.class public final Landroidx/appcompat/resources/R$styleable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/resources/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static final AnimatedStateListDrawableCompat:[I

.field public static final AnimatedStateListDrawableCompat_android_constantSize:I = 0x3

.field public static final AnimatedStateListDrawableCompat_android_dither:I = 0x0

.field public static final AnimatedStateListDrawableCompat_android_enterFadeDuration:I = 0x4

.field public static final AnimatedStateListDrawableCompat_android_exitFadeDuration:I = 0x5

.field public static final AnimatedStateListDrawableCompat_android_variablePadding:I = 0x2

.field public static final AnimatedStateListDrawableCompat_android_visible:I = 0x1

.field public static final AnimatedStateListDrawableItem:[I

.field public static final AnimatedStateListDrawableItem_android_drawable:I = 0x1

.field public static final AnimatedStateListDrawableItem_android_id:I = 0x0

.field public static final AnimatedStateListDrawableTransition:[I

.field public static final AnimatedStateListDrawableTransition_android_drawable:I = 0x0

.field public static final AnimatedStateListDrawableTransition_android_fromId:I = 0x2

.field public static final AnimatedStateListDrawableTransition_android_reversible:I = 0x3

.field public static final AnimatedStateListDrawableTransition_android_toId:I = 0x1

.field public static final StateListDrawable:[I

.field public static final StateListDrawableItem:[I

.field public static final StateListDrawableItem_android_drawable:I = 0x0

.field public static final StateListDrawable_android_constantSize:I = 0x3

.field public static final StateListDrawable_android_dither:I = 0x0

.field public static final StateListDrawable_android_enterFadeDuration:I = 0x4

.field public static final StateListDrawable_android_exitFadeDuration:I = 0x5

.field public static final StateListDrawable_android_variablePadding:I = 0x2

.field public static final StateListDrawable_android_visible:I = 0x1


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x5

    const/4 v0, 0x6

    const/4 v6, 0x3

    move v5, v0

    const/4 v6, 0x5

    new-array v1, v0, [I

    const/4 v5, 0x6

    move v6, v5

    fill-array-data v1, :array_0

    const/4 v6, 0x5

    sput-object v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableCompat:[I

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const v1, 0x10100d0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    const v2, 0x1010199

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    filled-new-array {v1, v2}, [I

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    sput-object v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableItem:[I

    const/4 v6, 0x6

    const v1, 0x101044a

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    const v3, 0x101044b

    const/4 v6, 0x7

    const/4 v5, 0x4

    const v4, 0x1010449

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    filled-new-array {v2, v4, v1, v3}, [I

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    sput-object v1, Landroidx/appcompat/resources/R$styleable;->AnimatedStateListDrawableTransition:[I

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-array v0, v0, [I

    const/4 v6, 0x4

    fill-array-data v0, :array_1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    sput-object v0, Landroidx/appcompat/resources/R$styleable;->StateListDrawable:[I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    filled-new-array {v2}, [I

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    sput-object v0, Landroidx/appcompat/resources/R$styleable;->StateListDrawableItem:[I

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void

    nop

    :array_0
    .array-data 4
        0x101011c
        0x1010194
        0x1010195
        0x1010196
        0x101030c
        0x101030d
    .end array-data

    :array_1
    .array-data 4
        0x101011c
        0x1010194
        0x1010195
        0x1010196
        0x101030c
        0x101030d
    .end array-data
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
