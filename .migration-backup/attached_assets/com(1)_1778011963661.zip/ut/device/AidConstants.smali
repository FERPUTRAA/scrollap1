.class public Lcom/ut/device/AidConstants;
.super Ljava/lang/Object;


# static fields
.field public static final EVENT_NETWORK_ERROR:I = 0x3eb

.field public static final EVENT_REQUEST_FAILED:I = 0x3ea

.field public static final EVENT_REQUEST_STARTED:I = 0x3e8

.field public static final EVENT_REQUEST_SUCCESS:I = 0x3e9


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
