.class Lcom/voiceengine/NTAudioRecord$AudioRecordThread;
.super Ljava/lang/Thread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/voiceengine/NTAudioRecord;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "AudioRecordThread"
.end annotation


# instance fields
.field private volatile keepAlive:Z

.field final synthetic this$0:Lcom/voiceengine/NTAudioRecord;


# direct methods
.method public constructor <init>(Lcom/voiceengine/NTAudioRecord;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v0, 0x7

    and-int/2addr v1, v0

    invoke-direct {p0, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->keepAlive:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public joinThread()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @siot~ ~@m ~@ @usl/@ c~@/~o@S@ to~@.~@   M @~o o~ivbb@@  ~ ~ raf@~-o@@1~~ K~4~by~l@ ~@fn~id@~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->keepAlive:Z

    :catch_0
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Thread;->isAlive()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    return-void

    :cond_0
    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Thread;->join()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    goto :goto_0
.end method

.method public run()V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/16 v0, -0x13

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v0}, Landroid/os/Process;->setThreadPriority(I)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo v1, "rTimochRdsradduoA"

    const-string/jumbo v1, "risRohcTAaoudderd"

    const/4 v7, 0x7

    const-string/jumbo v1, "eurdoadRoheidrTAo"

    const-string v1, "AudioRecordThread"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const-string v1, "dedorbuTreARcoN"

    const-string/jumbo v1, "rodmorAecdReNuT"

    const/4 v7, 0x2

    const-string v1, "AioeucueRrdroTN"

    const-string v1, "NTAudioRecorder"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->access$0(Lcom/voiceengine/NTAudioRecord;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    const/4 v2, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    if-ne v0, v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v0, 0x1

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    move v0, v3

    const/4 v7, 0x4

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->access$1(Z)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    :cond_1
    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-boolean v0, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->keepAlive:Z

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-nez v0, :cond_2

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->access$0(Lcom/voiceengine/NTAudioRecord;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/media/AudioRecord;->stop()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    goto :goto_2

    :catch_0
    move-exception v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v3, "oiA:fedp ed dproo.iosulRt"

    const-string/jumbo v3, "olo.odieduirftedoA a sp:R"

    const/4 v7, 0x3

    const-string/jumbo v3, "seAlirceqfau td:i.ddoop R"

    const-string v3, "AudioRecord.stop failed: "

    const/4 v7, 0x6

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :goto_2
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-void

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->access$0(Lcom/voiceengine/NTAudioRecord;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v2}, Lcom/voiceengine/NTAudioRecord;->access$2(Lcom/voiceengine/NTAudioRecord;)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v4}, Lcom/voiceengine/NTAudioRecord;->access$2(Lcom/voiceengine/NTAudioRecord;)Ljava/nio/ByteBuffer;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0, v2, v4}, Landroid/media/AudioRecord;->read(Ljava/nio/ByteBuffer;I)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/voiceengine/NTAudioRecord;->access$2(Lcom/voiceengine/NTAudioRecord;)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-ne v0, v2, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->this$0:Lcom/voiceengine/NTAudioRecord;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v2}, Lcom/voiceengine/NTAudioRecord;->access$3(Lcom/voiceengine/NTAudioRecord;)J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v2, v0, v4, v5}, Lcom/voiceengine/NTAudioRecord;->access$4(Lcom/voiceengine/NTAudioRecord;IJ)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto/16 :goto_1

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v4, " oserlAe:coRr.dd uidaibad"

    const-string v4, "aRrldbecieoae ri dd.Aud:o"

    const/4 v7, 0x7

    const-string v4, "dAcmdleRduoo:ieiaf r.da r"

    const-string v4, "AudioRecord.read failed: "

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v2, -0x3

    const/4 v7, 0x7

    const/4 v6, 0x0

    if-ne v0, v2, :cond_1

    const/4 v7, 0x7

    iput-boolean v3, p0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->keepAlive:Z

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto/16 :goto_1
.end method
