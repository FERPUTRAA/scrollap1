.class public interface abstract Lcom/voiceengine/NTAudioRecordV2Callback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onNTAudioRecordV2Frame(Ljava/nio/ByteBuffer;IIII)V
.end method
