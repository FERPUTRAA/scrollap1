.class public Lcom/voiceengine/NTAudioRecordV2;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "NewApi"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;
    }
.end annotation


# static fields
.field private static final BITS_PER_SAMPLE:I = 0x10

.field private static final BUFFERS_PER_SECOND:I = 0x64

.field private static final CALLBACK_BUFFER_SIZE_MS:I = 0xa

.field private static final DEBUG:Z = false

.field private static final TAG:Ljava/lang/String; = "NTAudioRecorderV2"


# instance fields
.field private aec:Landroid/media/audiofx/AcousticEchoCanceler;

.field private audioRecord:Landroid/media/AudioRecord;

.field private audioThread:Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

.field private byteBuffer:Ljava/nio/ByteBuffer;

.field private callback_list_:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/voiceengine/NTAudioRecordV2Callback;",
            ">;"
        }
    .end annotation
.end field

.field private channels_:I

.field private final context:Landroid/content/Context;

.field private is_mic_source_:Z

.field private is_remote_submix_source_:Z

.field private per_channel_sample_number_:I

.field private sample_rate_:I

.field private useBuiltInAEC:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v2, 0x0

    move v3, v2

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioThread:Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-boolean v1, p0, Lcom/voiceengine/NTAudioRecordV2;->useBuiltInAEC:Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v2, 0x3

    move v3, v2

    iput v1, p0, Lcom/voiceengine/NTAudioRecordV2;->sample_rate_:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput v1, p0, Lcom/voiceengine/NTAudioRecordV2;->channels_:I

    const/4 v3, 0x5

    iput v1, p0, Lcom/voiceengine/NTAudioRecordV2;->per_channel_sample_number_:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    iput-boolean v1, p0, Lcom/voiceengine/NTAudioRecordV2;->is_remote_submix_source_:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    iput-boolean v1, p0, Lcom/voiceengine/NTAudioRecordV2;->is_mic_source_:Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "rtoc"

    const-string v1, "ctor"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v1, "sAsucN2ReoiTderVd"

    const-string v1, "2csriVNAueTReodod"

    const/4 v3, 0x5

    const-string v1, "NTAudioRecorderV2"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->context:Landroid/content/Context;

    const/4 v3, 0x0

    new-instance p1, Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method private FireRecordFrame(Ljava/nio/ByteBuffer;IIII)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~~ mK ~@~   ~~@b@ @  @v l/s@@~oo~ @@@M@mo@l o@@/~ r4oSc.~~f~i  ~y~ba@f@i~ ou~@@~~ -b~t~ 1t~~@nid"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    check-cast v0, Ljava/util/ArrayList;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    check-cast v0, Ljava/util/List;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v0, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-nez v1, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto :goto_2

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    check-cast v2, Lcom/voiceengine/NTAudioRecordV2Callback;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v2, :cond_1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    move v4, p2

    move v4, p2

    const/4 v9, 0x0

    move v4, p2

    move v4, p2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v5, p3

    move v5, p3

    const/4 v9, 0x0

    move v5, p3

    move v5, p3

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    move v6, p4

    move v6, p4

    const/4 v9, 0x6

    move v6, p4

    move v6, p4

    const/4 v8, 0x3

    move v9, v8

    move v7, p5

    move v7, p5

    const/4 v9, 0x0

    move v7, p5

    move v7, p5

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-interface/range {v2 .. v7}, Lcom/voiceengine/NTAudioRecordV2Callback;->onNTAudioRecordV2Frame(Ljava/nio/ByteBuffer;IIII)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    goto :goto_1

    :cond_3
    :goto_2
    const/4 v9, 0x5

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    throw p1
.end method

.method private InitRecording(II)I
    .locals 13

    const/4 v12, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "aeiooiemctpra=leRsRnd(gIn"

    const-string v1, "InitRecording(sampleRate="

    const/4 v12, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v1, "smechb=lnna"

    const-string v1, "=scmnnale h"

    const-string v1, ", channels="

    const/4 v12, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string v1, ")"

    const-string v1, ")"

    const-string v1, ")"

    const-string v1, ")"

    const/4 v12, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x0

    const-string/jumbo v1, "o2NuTRuedVderoori"

    const-string v1, "drTAoeoeVoidr2uNR"

    const-string/jumbo v1, "rucdTeApVrRdoo2iN"

    const-string v1, "NTAudioRecorderV2"

    const/4 v12, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->context:Landroid/content/Context;

    const/4 v12, 0x3

    const-string v2, "Oo_inEsdqp.bRi.sODimrUaCDIeArdo"

    const-string v2, "aDdnRbRDCAiU.mrr_dOiOo.EIpossei"

    const-string/jumbo v2, "pessCoin.rD_IiADsrOmindREdaU.RO"

    const-string v2, "android.permission.RECORD_AUDIO"

    const/4 v12, 0x6

    invoke-static {v0, v2}, Lcom/voiceengine/NTAudioUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v12, 0x1

    const/4 v2, -0x1

    if-nez v0, :cond_0

    const/4 v12, 0x0

    const-string/jumbo p1, "sDmmsunmIUCie Rr osOgROsAnspiED ii"

    const-string p1, "esmCROuprnisAoisDigRsIDsOiEm  iU n"

    const-string/jumbo p1, "nsDoosIms ssCiEiiORepAn rDi UmO_Ri"

    const-string p1, "RECORD_AUDIO permission is missing"

    const/4 v12, 0x3

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x6

    return v2

    :cond_0
    const/4 v12, 0x4

    mul-int/lit8 v0, p2, 0x2

    const/4 v12, 0x4

    div-int/lit8 v3, p1, 0x64

    const/4 v12, 0x4

    mul-int/2addr v0, v3

    invoke-static {v0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v12, 0x0

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string v4, "cf.rpbb Bfeyaua:ieyct"

    const-string v4, "Bte rcypfcaf:u.yaipbe"

    const-string/jumbo v4, "tr:Batuic buaefcfy.py"

    const-string v4, "byteBuffer.capacity: "

    const/4 v12, 0x3

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecordV2;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x6

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    const/4 v12, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const-string/jumbo v4, "f  rPmrpu;efrsaqeeB"

    const-string v4, "efmarPr qeB urf:se;"

    const-string v4, "eemffuP qrf:ar;Be s"

    const-string v4, "; framesPerBuffer: "

    const/4 v12, 0x6

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x1

    iput p1, p0, Lcom/voiceengine/NTAudioRecordV2;->sample_rate_:I

    iput p2, p0, Lcom/voiceengine/NTAudioRecordV2;->channels_:I

    iput v3, p0, Lcom/voiceengine/NTAudioRecordV2;->per_channel_sample_number_:I

    const/4 v12, 0x1

    const/16 p2, 0x10

    const/4 v12, 0x2

    const/4 v0, 0x2

    const/4 v12, 0x0

    invoke-static {p1, p2, v0}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result p2

    const/4 v12, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string/jumbo v4, "sAs.i:oifuuiodcreM SRnzeterfgB"

    const-string/jumbo v4, "nisBfteifSdrMcrARgoi e:eueo.zu"

    const-string v4, "drBm.eef iuinAMioocRte:fdSzurg"

    const-string v4, "AudioRecord.getMinBufferSize: "

    const/4 v12, 0x3

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x3

    if-eqz v0, :cond_1

    const/4 v12, 0x2

    invoke-virtual {v0}, Landroid/media/audiofx/AudioEffect;->release()V

    const/4 v12, 0x1

    const/4 v0, 0x0

    const/4 v12, 0x1

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    :cond_1
    const/4 v12, 0x3

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x7

    const/4 v4, 0x0

    const/4 v12, 0x1

    const/4 v5, 0x1

    const/4 v12, 0x0

    if-nez v0, :cond_2

    const/4 v12, 0x3

    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    const/4 v12, 0x3

    goto :goto_0

    :cond_2
    const/4 v12, 0x4

    move v0, v4

    move v0, v4

    move v0, v4

    move v0, v4

    :goto_0
    const/4 v12, 0x5

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result v0

    const/4 v12, 0x5

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result v11

    const/4 v12, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const-string/jumbo v0, "f:bSozeyftIuisrBem "

    const-string v0, "IfsmbSzeu: teriyfBe"

    const-string v0, "SIzibb fseur:tByfen"

    const-string v0, "bufferSizeInBytes: "

    const/4 v12, 0x7

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x7

    invoke-virtual {p2, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x7

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_0
    const/4 v12, 0x1

    iget-boolean p2, p0, Lcom/voiceengine/NTAudioRecordV2;->is_mic_source_:Z

    const/4 v12, 0x3

    if-nez p2, :cond_4

    const/4 v12, 0x6

    invoke-static {}, Lcom/voiceengine/NTAudioRecordV2;->chkNewDev()Z

    move-result p2

    const/4 v12, 0x7

    if-eqz p2, :cond_4

    const/4 v12, 0x3

    const-string p2, "eeicrouk necDhwtwe vtu "

    const-string/jumbo p2, "w htoewneic terukc v eD"

    const-string p2, "check new Dev with true"

    const/4 v12, 0x0

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x3

    iget-boolean p2, p0, Lcom/voiceengine/NTAudioRecordV2;->is_remote_submix_source_:Z

    const/4 v12, 0x2

    if-nez p2, :cond_3

    const/4 v12, 0x6

    new-instance p2, Landroid/media/AudioRecord;

    const/4 v12, 0x0

    const/4 v7, 0x7

    const/4 v12, 0x5

    const/16 v9, 0x10

    const/4 v12, 0x1

    const/4 v10, 0x2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v12, 0x0

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v12, 0x4

    invoke-direct/range {v6 .. v11}, Landroid/media/AudioRecord;-><init>(IIIII)V

    const/4 v12, 0x3

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x2

    goto/16 :goto_1

    :cond_3
    const/4 v12, 0x2

    const-string p2, "SBuTcUrpRM_eMesEboE  IXu"

    const-string p2, "OE uBbIu EMcMR_XUsoTSeer"

    const-string/jumbo p2, "reMMIoSEqsOTeRU  cXusuEB"

    const-string/jumbo p2, "use REMOTE_SUBMIX source"

    const/4 v12, 0x1

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x2

    new-instance p2, Landroid/media/AudioRecord;

    const/4 v12, 0x4

    const/16 v7, 0x8

    const/4 v12, 0x1

    const/16 v9, 0x10

    const/4 v12, 0x0

    const/4 v10, 0x2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v12, 0x1

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v12, 0x0

    invoke-direct/range {v6 .. v11}, Landroid/media/AudioRecord;-><init>(IIIII)V

    const/4 v12, 0x2

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x6

    goto :goto_1

    :cond_4
    const/4 v12, 0x4

    const-string/jumbo p2, "hlsswhkDiceafc eetnev wu"

    const-string p2, "afesnDutlhewvccikew h e "

    const-string p2, "Dcemw  ewnlckhf savheite"

    const-string p2, "check new Dev with false"

    const/4 v12, 0x0

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x7

    iget-boolean p2, p0, Lcom/voiceengine/NTAudioRecordV2;->is_remote_submix_source_:Z

    const/4 v12, 0x5

    if-nez p2, :cond_5

    const/4 v12, 0x0

    const-string p2, "MsuSoiCcu.doeropueI"

    const-string/jumbo p2, "oeucu.Sp MCseIoirud"

    const-string p2, "ei uSbu.cuoeAodIMsC"

    const-string/jumbo p2, "use AudioSource.MIC"

    const/4 v12, 0x3

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x3

    new-instance p2, Landroid/media/AudioRecord;

    const/4 v7, 0x1

    move v12, v7

    move v12, v7

    const/16 v9, 0x10

    const/4 v12, 0x5

    const/4 v10, 0x2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v12, 0x6

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v12, 0x5

    invoke-direct/range {v6 .. v11}, Landroid/media/AudioRecord;-><init>(IIIII)V

    const/4 v12, 0x7

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    goto :goto_1

    :cond_5
    const/4 v12, 0x0

    const-string/jumbo p2, "qTs rEu_sR eMEOoXucU2uSMI"

    const-string p2, "c_OXe 2EqMsTUruoeuIM ESsR"

    const-string p2, "B_sruEMp UR MXoTecOSsuE2I"

    const-string/jumbo p2, "use REMOTE_SUBMIX source2"

    const/4 v12, 0x4

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x2

    new-instance p2, Landroid/media/AudioRecord;

    const/16 v7, 0x8

    const/4 v12, 0x5

    const/16 v9, 0x10

    const/4 v12, 0x4

    const/4 v10, 0x2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v12, 0x1

    move v8, p1

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v12, 0x1

    invoke-direct/range {v6 .. v11}, Landroid/media/AudioRecord;-><init>(IIIII)V

    const/4 v12, 0x4

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1

    :goto_1
    const/4 v12, 0x2

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x5

    invoke-virtual {p1}, Landroid/media/AudioRecord;->getState()I

    move-result p1

    const/4 v12, 0x6

    if-ne p1, v5, :cond_6

    const/4 v12, 0x6

    move v4, v5

    move v4, v5

    move v4, v5

    move v4, v5

    :cond_6
    const/4 v12, 0x5

    invoke-static {v4}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    const/4 v12, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string/jumbo p2, "n eo dcuqAiIDsRdios essr"

    const-string p2, " usR IDrseins csodied:Ao"

    const-string/jumbo p2, "iAssRsIs eDocudoodein : "

    const-string p2, "AudioRecord session ID: "

    const/4 v12, 0x4

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    iget-object p2, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x0

    invoke-virtual {p2}, Landroid/media/AudioRecord;->getAudioSessionId()I

    move-result p2

    const/4 v12, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const-string p2, ", "

    const-string p2, ", "

    const-string p2, ", "

    const-string p2, ", "

    const/4 v12, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string v0, "a mmoti muoard"

    const-string/jumbo v0, "rfdmiuaoat  om"

    const-string v0, ":fimoo otr adu"

    const-string v0, "audio format: "

    const/4 v12, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x0

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getAudioFormat()I

    move-result v0

    const/4 v12, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v0, "olehcba:sn"

    const-string/jumbo v0, "lcnaoshn:e"

    const-string/jumbo v0, "nhnsleua :"

    const-string v0, "channels: "

    const/4 v12, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x3

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getChannelCount()I

    move-result v0

    const/4 v12, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string/jumbo v0, "m braa ps:pee"

    const-string/jumbo v0, "rpaasb : etem"

    const-string/jumbo v0, "mlret: eqas a"

    const-string/jumbo v0, "sample rate: "

    const/4 v12, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getSampleRate()I

    move-result v0

    const/4 v12, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v0, "scsoho:bncu aAcirsvl.taeEauieCAlei"

    const-string v0, ":AnlhAuisoileoccvrceEtbi ualCea.as"

    const-string v0, ".ismlca:nC aiAcelAatclEehrbiovseuo"

    const-string v0, "AcousticEchoCanceler.isAvailable: "

    const/4 v12, 0x1

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-static {}, Lcom/voiceengine/NTAudioRecordV2;->builtInAECIsAvailable()Z

    move-result v0

    const/4 v12, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x1

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x0

    invoke-static {}, Lcom/voiceengine/NTAudioRecordV2;->builtInAECIsAvailable()Z

    move-result p1

    const/4 v12, 0x2

    if-nez p1, :cond_7

    const/4 v12, 0x2

    return v3

    :cond_7
    const/4 v12, 0x4

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->deviceIsBlacklistedForHwAecUsage()Z

    move-result p1

    const/4 v12, 0x0

    if-eqz p1, :cond_8

    const/4 v12, 0x3

    iget-boolean p1, p0, Lcom/voiceengine/NTAudioRecordV2;->useBuiltInAEC:Z

    const/4 v12, 0x5

    xor-int/2addr p1, v5

    const/4 v12, 0x2

    invoke-static {p1}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    :cond_8
    const/4 v12, 0x1

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x6

    invoke-virtual {p1}, Landroid/media/AudioRecord;->getAudioSessionId()I

    move-result p1

    const/4 v12, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string/jumbo v4, "sih opidinsao twuoS"

    const-string v4, "aisidsepo ihutSown "

    const-string/jumbo v4, "i tSdbwiehuioa:sn o"

    const-string v4, "audioSession with: "

    const/4 v12, 0x4

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecordV2;->NTLOGI(Ljava/lang/String;)V

    :try_start_1
    const/4 v12, 0x4

    invoke-static {p1}, Landroid/media/audiofx/AcousticEchoCanceler;->create(I)Landroid/media/audiofx/AcousticEchoCanceler;

    move-result-object p1

    const/4 v12, 0x0

    iput-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    const/4 v12, 0x3

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x6

    if-nez p1, :cond_9

    const/4 v12, 0x3

    const-string/jumbo p1, "leArutualhnCeccea.rediEatiooqcsfce"

    const-string p1, "cclunifhqaeoEtCeotcesecie.cAdlraar"

    const-string/jumbo p1, "teEcferpha .acocdlcAaniletoeeiCrcs"

    const-string p1, "AcousticEchoCanceler.create failed"

    const/4 v12, 0x5

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x2

    return v2

    :cond_9
    const/4 v12, 0x2

    iget-boolean v0, p0, Lcom/voiceengine/NTAudioRecordV2;->useBuiltInAEC:Z

    const/4 v12, 0x2

    invoke-virtual {p1, v0}, Landroid/media/audiofx/AudioEffect;->setEnabled(Z)I

    move-result p1

    const/4 v12, 0x1

    if-eqz p1, :cond_a

    const/4 v12, 0x0

    const-string/jumbo p1, "hiicsaecqdnoEtbn.aet flecloreEdcasCelA"

    const-string p1, "easeels.ilnotcoEiadbfEctlacs AehdecCnr"

    const-string p1, "ecsaanhdcolclicAEbauCd eot.etrsefeliEn"

    const-string p1, "AcousticEchoCanceler.setEnabled failed"

    const/4 v12, 0x7

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x2

    return v2

    :cond_a
    const/4 v12, 0x7

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/media/audiofx/AudioEffect;->getDescriptor()Landroid/media/audiofx/AudioEffect$Descriptor;

    move-result-object p1

    const/4 v12, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const-string/jumbo v2, "ohrmtnniAlcecac uc:eeo maCm"

    const-string/jumbo v2, "iuCm:cecml hAst accneonoera"

    const-string v2, "cCcloc:uAaoEecmnrth ainose "

    const-string v2, "AcousticEchoCanceler name: "

    const/4 v12, 0x4

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    iget-object v2, p1, Landroid/media/audiofx/AudioEffect$Descriptor;->name:Ljava/lang/String;

    const/4 v12, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v2, "meetrb nimop:"

    const-string v2, "eipnor:m mlet"

    const-string v2, "emmroiup :lnt"

    const-string/jumbo v2, "implementor: "

    const/4 v12, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    iget-object v2, p1, Landroid/media/audiofx/AudioEffect$Descriptor;->implementor:Ljava/lang/String;

    const/4 v12, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const-string p2, ":p biu"

    const-string/jumbo p2, "u :uib"

    const-string p2, ": qdui"

    const-string/jumbo p2, "uuid: "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    iget-object p1, p1, Landroid/media/audiofx/AudioEffect$Descriptor;->uuid:Ljava/util/UUID;

    const/4 v12, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x2

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string p2, "cAsleochsuuaoid:bEnErenctlt .Cgec"

    const-string p2, "ceoneEuh: ECuAotencc.ilgbldctasre"

    const-string/jumbo p2, "laumtElerAcneehdogocEbesa:.t cniC"

    const-string p2, "AcousticEchoCanceler.getEnabled: "

    const/4 v12, 0x4

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x3

    iget-object p2, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x0

    invoke-virtual {p2}, Landroid/media/audiofx/AudioEffect;->getEnabled()Z

    move-result p2

    const/4 v12, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x3

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x4

    return v3

    :catch_1
    move-exception p1

    const/4 v12, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x6

    return v2
.end method

.method private static NTLOGE(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "N2oToReAideuVpdcr"

    const-string/jumbo v0, "ucVroeopNeAid2dRT"

    const/4 v2, 0x0

    const-string v0, "TNueobdeRAcorridV"

    const-string v0, "NTAudioRecorderV2"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method private static NTLOGI(Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    const-string v0, "deqRioureodrcVA2u"

    const-string v0, "eriucrARqeodTVo2d"

    const/4 v2, 0x6

    const-string v0, "RdeorN2pocVTuridA"

    const-string v0, "NTAudioRecorderV2"

    const/4 v2, 0x4

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private StartRecording()Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v0, "gorRiserqtcdan"

    const-string v0, "dSsgerrRontcia"

    const/4 v7, 0x2

    const-string v0, "crstSdoRriteag"

    const-string v0, "StartRecording"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v1, "muNmdirooeT2cAeRr"

    const-string/jumbo v1, "rormNouieAdcRdeT2"

    const/4 v7, 0x5

    const-string v1, "VoNdoeTRiruoAred2"

    const-string v1, "NTAudioRecorderV2"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    if-eqz v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    move v0, v2

    const/4 v7, 0x5

    move v0, v2

    move v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v0, v3

    move v0, v3

    const/4 v7, 0x4

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioThread:Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v0, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v0, v2

    move v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    move v0, v3

    move v0, v3

    move v0, v3

    move v0, v3

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    const/4 v7, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v4}, Landroid/media/AudioRecord;->startRecording()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v5, 0x3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eq v4, v5, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const-string v4, "eodtrb tnrss=lf+.Aagdi otecaeueodioctrida "

    const-string v4, " iitonlcsee.rrdseo t+uodit=raAg Rcaoddftea"

    const/4 v7, 0x7

    const-string/jumbo v4, "sstridu+R  cefdgae.oditnaoierctuRal ed=Ato"

    const-string v4, "AudioRecord.startRecording failed + state="

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-virtual {v4}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x6

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    return v3

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v0, Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v1, "Vreiodep2dAaoucJdbRT"

    const-string v1, "aV2rrbdueecdooRTdAiJ"

    const-string/jumbo v1, "ucRViArdqdehdar2oTeo"

    const-string v1, "AudioRecordJThreadV2"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v0, p0, v1}, Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;-><init>(Lcom/voiceengine/NTAudioRecordV2;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioThread:Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    return v2

    :catch_0
    move-exception v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v5, "f:sidrentdoR  eogdsear.AlcuRocruiit"

    const-string/jumbo v5, "teu:aeuc siidr.nricRoAdedagtofo lRr"

    const/4 v7, 0x0

    const-string v5, ".eomiatAucRanfdiiscro:Rg  oderretdl"

    const-string v5, "AudioRecord.startRecording failed: "

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    return v3
.end method

.method static synthetic access$0(Lcom/voiceengine/NTAudioRecordV2;)Landroid/media/AudioRecord;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$1(Z)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic access$2(Lcom/voiceengine/NTAudioRecordV2;)Ljava/nio/ByteBuffer;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/voiceengine/NTAudioRecordV2;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$3(Lcom/voiceengine/NTAudioRecordV2;)I
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget p0, p0, Lcom/voiceengine/NTAudioRecordV2;->sample_rate_:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$4(Lcom/voiceengine/NTAudioRecordV2;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget p0, p0, Lcom/voiceengine/NTAudioRecordV2;->channels_:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$5(Lcom/voiceengine/NTAudioRecordV2;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget p0, p0, Lcom/voiceengine/NTAudioRecordV2;->per_channel_sample_number_:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic access$6(Lcom/voiceengine/NTAudioRecordV2;Ljava/nio/ByteBuffer;IIII)V
    .locals 2

    const/4 v1, 0x2

    invoke-direct/range {p0 .. p5}, Lcom/voiceengine/NTAudioRecordV2;->FireRecordFrame(Ljava/nio/ByteBuffer;IIII)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method private static assertTrue(Z)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v2, 0x7

    const-string/jumbo v0, "ntr oEt etoecxo  pdinebpteoui"

    const-string v0, " t etitpoEeccnntox dp euoebri"

    const/4 v2, 0x4

    const-string v0, "Expected condition to be true"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    throw p0
.end method

.method private static builtInAECIsAvailable()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->isAcousticEchoCancelerSupported()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public static chkNewDev()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method


# virtual methods
.method public AddCallback(Lcom/voiceengine/NTAudioRecordV2Callback;)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-nez p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const-string/jumbo p1, "r2euNbRdqecrdioAT"

    const-string/jumbo p1, "ier2udRdqoAVcreNT"

    const-string p1, "eNiTc2uoAdodrreuV"

    const-string p1, "NTAudioRecorderV2"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "idan lkp lbscldbsalAc cklalC"

    const-string/jumbo v1, "l sliscdllnlbckaCdkaAb  claa"

    const/4 v5, 0x2

    const-string/jumbo v1, "ua c bsAqklacaldll acnCilkbd"

    const-string v1, "AddCallback callback is null"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo p1, "oNsRicTrumroVded2"

    const-string p1, "deNmeRoudoiTVr2cr"

    const/4 v5, 0x0

    const-string p1, "dTrmNoeiAVde2Rcur"

    const-string p1, "NTAudioRecorderV2"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const-string v1, " k noabstldCoiullAdsilac"

    const-string/jumbo v1, "ildaoclkdlitaCl ub lnsAs"

    const/4 v5, 0x2

    const-string v1, "AddCallback list is null"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p1, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    monitor-exit p0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {v1, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo p1, "riRrdbooN2VeAecud"

    const-string p1, "VreodbecRrANdo2iu"

    const/4 v5, 0x4

    const-string/jumbo p1, "irANuoudroe2eTdRc"

    const-string p1, "NTAudioRecorderV2"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const-string v1, "cCAuabxpdai sebkkalc dlctl"

    const-string v1, "ClAe lubakaadct lisdbcxcak"

    const/4 v5, 0x1

    const-string v1, "aaldaiccqCtlkbx  allekdsbc"

    const-string v1, "AddCallback callback exist"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p1, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    monitor-exit p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    return v0

    :cond_2
    const/4 v4, 0x1

    move v5, v4

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v1, "eespVNcidTo2roRAu"

    const-string v1, "dorANerpu2ioTceRV"

    const-string v1, "ceem2ddViArroTuRo"

    const-string v1, "NTAudioRecorderV2"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v3, "icl.o=tdilAdzaskqbel s"

    const-string/jumbo v3, "idbllds qacA=ez.ailtks"

    const/4 v5, 0x6

    const-string/jumbo v3, "llCs=baiaecb.d kdztilA"

    const-string v3, "AddCallback list.size="

    const/4 v5, 0x2

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const-string/jumbo v0, "suer "

    const-string v0, "ers ="

    const/4 v5, 0x0

    const-string v0, "erpt "

    const-string v0, " ret="

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return p1

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    throw p1
.end method

.method public EnableBuiltInAEC(Z)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "emC(ntAbqiBnulEaI"

    const-string v1, "AllmiEneBnubICta("

    const/4 v4, 0x5

    const-string/jumbo v1, "uas(elAEICtnBlnEb"

    const-string v1, "EnableBuiltInAEC("

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/16 v1, 0x29

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "uoom2dAVRceroNTei"

    const-string v1, "TRNuoicrAd2eVeood"

    const/4 v4, 0x2

    const-string v1, "2dodoeTAeuNcRrVor"

    const-string v1, "NTAudioRecorderV2"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->isAcousticEchoCancelerApproved()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string p1, "bAlunbEAepCourcctcEen oanntIiuelsotEohBcpibrs l t"

    const-string p1, "capsubhnErBcAnobsoCttlnc e  uncieECtplEleuiotorIA"

    const/4 v4, 0x5

    const-string p1, " s AutuelbElrnEpiaceAosuoncCIetBcnCp nrhoilEaoutt"

    const-string p1, "EnableBuiltInAEC AcousticEchoCanceler not support"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    return v2

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->isAcousticEchoCancelerApproved()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecordV2;->assertTrue(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-boolean p1, p0, Lcom/voiceengine/NTAudioRecordV2;->useBuiltInAEC:Z

    const/4 v4, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/media/audiofx/AudioEffect;->setEnabled(Z)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string p1, "anutoelp c.ElccoinaisreebdcAlehCutsadE"

    const-string/jumbo p1, "rtnCedu acloiscouicEeeAhcednE.blltaeas"

    const/4 v4, 0x5

    const-string p1, "cEa .fieqolbAcacCstedlnsanroluecdeEthe"

    const-string p1, "AcousticEchoCanceler.setEnabled failed"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v2

    :cond_1
    const/4 v4, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v0, "eastng.eciC:eorEuEose cdAclabtlcn"

    const-string v0, "AcousticEchoCanceler.getEnabled: "

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/media/audiofx/AudioEffect;->getEnabled()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return p1
.end method

.method public IsMicSource(Z)V
    .locals 2

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/voiceengine/NTAudioRecordV2;->is_mic_source_:Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public IsRemoteSubmixSource(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/voiceengine/NTAudioRecordV2;->is_remote_submix_source_:Z

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public RemoveCallback(Lcom/voiceengine/NTAudioRecordV2Callback;)Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez p1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string p1, "dVRm2eocArTuriopd"

    const-string/jumbo p1, "oNTrdrdpi2ceVRAuo"

    const/4 v5, 0x7

    const-string/jumbo p1, "oAdRoorVireue2cNT"

    const-string p1, "NTAudioRecorderV2"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v1, "kaoccbn lallClbiebu vmcl Rkelaa"

    const-string v1, "RemoveCallback callback is null"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p1, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    return v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo p1, "qcToRdurNeu2VAied"

    const-string/jumbo p1, "uNdVoi2cqroATedRe"

    const/4 v5, 0x2

    const-string p1, "eTR2rAopVcdorNiue"

    const-string p1, "NTAudioRecorderV2"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v1, "mlRaolnkqs aecvs leltibusCl"

    const-string/jumbo v1, "lasnvlbtilk smcilo usaeRCle"

    const/4 v5, 0x2

    const-string/jumbo v1, "vlsllelaR nak  ouitecliCmbs"

    const-string v1, "RemoveCallback list is null"

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-static {p1, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    monitor-exit p0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v0

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v1, p1}, Ljava/util/List;->remove(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->callback_list_:Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v1, "ruommdeTRdcNVieor"

    const-string v1, "dTim2NuoReVrrdeoc"

    const/4 v5, 0x6

    const-string v1, "RAroocuioVTed2red"

    const-string v1, "NTAudioRecorderV2"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v3, "Ceaieb.mvltoskbaRc=ilzlo "

    const-string v3, "Rcstol=.beaekl aoivmlCezi"

    const/4 v5, 0x3

    const-string/jumbo v3, "ollzckuaievsle.aeitRsCb m"

    const-string v3, "RemoveCallback list.size="

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const-string/jumbo v0, "rep=t"

    const-string v0, "br=et"

    const/4 v5, 0x7

    const-string/jumbo v0, "rt=qe"

    const-string v0, " ret="

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    return p1

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    throw p1
.end method

.method public Start()Z
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    const v0, 0xac44

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {p0, v0, v1}, Lcom/voiceengine/NTAudioRecordV2;->InitRecording(II)I

    const/4 v6, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x0

    move v6, v2

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    const-string v3, "dVsireTcodRorANue"

    const-string/jumbo v3, "ieuorcuroVRTNAded"

    const/4 v6, 0x5

    const-string v3, "VAim2RrNrTodedeco"

    const-string v3, "NTAudioRecorderV2"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v0, "pd doStrrltni lucas aoRie"

    const-string v0, " nR aespuuladidrlSttri oc"

    const/4 v6, 0x6

    const-string/jumbo v0, "orrlib nlRa taStsuuedc di"

    const-string v0, "Start audioRecord is null"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    return v2

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p0}, Lcom/voiceengine/NTAudioRecordV2;->StartRecording()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-nez v0, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v4, "gltt,aRoqi!St=der rdaieefrcn"

    const-string/jumbo v4, "ien,=euar tf rctoerig!aStdRl"

    const-string v4, "StartRecording failed!, ret="

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    return v2

    :cond_1
    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v0, "akSt osp"

    const-string v0, " rsSkoat"

    const/4 v6, 0x0

    const-string/jumbo v0, "qttkaS o"

    const-string v0, "Start ok"

    const/4 v6, 0x5

    invoke-static {v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    return v1
.end method

.method public Stop()Z
    .locals 6

    const/4 v4, 0x2

    move v5, v4

    const-string/jumbo v0, "pSs+ot"

    const-string v0, "Stop++"

    const/4 v5, 0x1

    const-string/jumbo v1, "oTNmrVRmr2oeAduei"

    const-string v1, "ecdmArrRVouoei2NT"

    const/4 v5, 0x1

    const-string v1, "ANd2orerTRouiVodc"

    const-string v1, "NTAudioRecorderV2"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioThread:Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x2

    xor-int/2addr v4, v2

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x4

    move v5, v4

    return v2

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;->joinThread()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioThread:Lcom/voiceengine/NTAudioRecordV2$AudioRecordThread;

    const/4 v5, 0x7

    const/4 v4, 0x5

    iget-object v3, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-virtual {v3}, Landroid/media/audiofx/AudioEffect;->release()V

    const/4 v4, 0x7

    xor-int/2addr v5, v4

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v3}, Landroid/media/AudioRecord;->release()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecordV2;->audioRecord:Landroid/media/AudioRecord;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v0, "o-tpob"

    const-string v0, "-op-ot"

    const/4 v5, 0x7

    const-string/jumbo v0, "u--toS"

    const-string v0, "Stop--"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x3

    const/4 v4, 0x3

    return v2
.end method
