.class Lcom/voiceengine/NTAudioManager;
.super Ljava/lang/Object;


# static fields
.field private static final AUDIO_MODES:[Ljava/lang/String;

.field private static final BITS_PER_SAMPLE:I = 0x10

.field private static final CHANNELS:I = 0x1

.field private static final DEBUG:Z = false

.field private static final DEFAULT_FRAME_PER_BUFFER:I = 0x100

.field private static final SAMPLE_RATE_HZ:I = 0x1f40

.field private static final TAG:Ljava/lang/String; = "NTAudioManager"


# instance fields
.field private final audioManager:Landroid/media/AudioManager;

.field private channels:I

.field private final context:Landroid/content/Context;

.field private hardwareAEC:Z

.field private initialized:Z

.field private inputBufferSize:I

.field private lowLatencyOutput:Z

.field private final nativeAudioManager:J

.field private nativeChannels:I

.field private nativeSampleRate:I

.field private outputBufferSize:I

.field private sampleRate:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v0, "LIsEDsA__NOL"

    const-string v0, "D_sACEILONL_"

    const/4 v5, 0x6

    const-string v0, "ODCmMLA_N_LI"

    const-string v0, "MODE_IN_CALL"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v1, "COIMoOE_CATN_NMmIMDOU"

    const-string v1, "_UOmMNAIMCENMNOIDC_OT"

    const/4 v5, 0x5

    const-string v1, "MIT_Cb_EMOMNCINAOINDU"

    const-string v1, "MODE_IN_COMMUNICATION"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, "RALEoOuDMNM"

    const-string v2, "MARMoODNOEL"

    const/4 v5, 0x4

    const-string v2, "ERNMAL_pOMD"

    const-string v2, "MODE_NORMAL"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v3, "ETOGNbOIqRDME"

    const-string v3, "RIDENbOEMOTNG"

    const/4 v5, 0x7

    const-string v3, "NTsMI_OGEEDOR"

    const-string v3, "MODE_RINGTONE"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    filled-new-array {v2, v3, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    sput-object v0, Lcom/voiceengine/NTAudioManager;->AUDIO_MODES:[Ljava/lang/String;

    const/4 v5, 0x3

    return-void
.end method

.method constructor <init>(Landroid/content/Context;JII)V
    .locals 10

    const/4 v9, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    move v9, v0

    move v9, v0

    iput-boolean v0, p0, Lcom/voiceengine/NTAudioManager;->initialized:Z

    const/4 v9, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const-string/jumbo v1, "u rmha:e"

    const-string v1, "e da:ruh"

    const-string v1, "aehroTd:"

    const-string v1, "Thread: "

    const/4 v9, 0x1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->NTLOGI(Ljava/lang/String;)V

    const/4 v9, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const-string/jumbo v1, "ps pebRlatem"

    const-string/jumbo v1, "p eRes:paltm"

    const-string v1, "eaap: uRslmt"

    const-string/jumbo v1, "sampleRate: "

    const/4 v9, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x7

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->NTLOGI(Ljava/lang/String;)V

    const/4 v9, 0x7

    iput-object p1, p0, Lcom/voiceengine/NTAudioManager;->context:Landroid/content/Context;

    const/4 v9, 0x6

    iput-wide p2, p0, Lcom/voiceengine/NTAudioManager;->nativeAudioManager:J

    const/4 v9, 0x1

    iput p4, p0, Lcom/voiceengine/NTAudioManager;->sampleRate:I

    iput p5, p0, Lcom/voiceengine/NTAudioManager;->channels:I

    const/4 v9, 0x6

    const-string/jumbo p5, "qapud"

    const-string/jumbo p5, "uaiqd"

    const-string p5, "daiqo"

    const-string p5, "audio"

    const/4 v9, 0x5

    invoke-virtual {p1, p5}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v9, 0x5

    check-cast p1, Landroid/media/AudioManager;

    const/4 v9, 0x6

    iput-object p1, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    invoke-direct {p0}, Lcom/voiceengine/NTAudioManager;->storeAudioParameters()V

    const/4 v9, 0x5

    iget v2, p0, Lcom/voiceengine/NTAudioManager;->channels:I

    const/4 v9, 0x3

    iget-boolean v3, p0, Lcom/voiceengine/NTAudioManager;->hardwareAEC:Z

    const/4 v9, 0x7

    iget-boolean v4, p0, Lcom/voiceengine/NTAudioManager;->lowLatencyOutput:Z

    const/4 v9, 0x0

    iget v5, p0, Lcom/voiceengine/NTAudioManager;->outputBufferSize:I

    const/4 v9, 0x3

    iget v6, p0, Lcom/voiceengine/NTAudioManager;->inputBufferSize:I

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x5

    move v1, p4

    move v1, p4

    move v1, p4

    move v1, p4

    move-wide v7, p2

    const/4 v9, 0x0

    invoke-direct/range {v0 .. v8}, Lcom/voiceengine/NTAudioManager;->nativeCacheAudioParameters(IIZZIIJ)V

    const/4 v9, 0x1

    return-void
.end method

.method private static NTLOGE(Ljava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@lsi~  b@@~@- @m~@ @K ~b@n ~ @~t~oa@~~ Sdo~oi@@y i~~@4 o@bur~~~cfl~of@~o~@@/~@  /~v@~  ~.1s@ M t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string v0, "aaumgeiMAdosrn"

    const-string/jumbo v0, "oNsniaaAreudgM"

    const/4 v2, 0x6

    const-string v0, "aeTnooNArdMgia"

    const-string v0, "NTAudioManager"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method private static NTLOGI(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo v0, "ruanAbmdMgTaei"

    const-string v0, "dnAmNiaugMeaTr"

    const/4 v2, 0x1

    const-string/jumbo v0, "naoTaguuiedNMA"

    const-string v0, "NTAudioManager"

    const/4 v2, 0x0

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x4

    move v2, v1

    return-void
.end method

.method private static assertTrue(Z)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "ctbooti d ritEp e oenxuendoec"

    const/4 v2, 0x6

    const-string/jumbo v0, "xneeEnop iipedrt  cotuteot cb"

    const-string v0, "Expected condition to be true"

    const/4 v2, 0x5

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    throw p0
.end method

.method private dispose()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v1, "sqeosdb"

    const-string/jumbo v1, "sdiosbe"

    const/4 v3, 0x6

    const-string/jumbo v1, "oispsse"

    const-string v1, "dispose"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->NTLOGI(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method private getLowLatencyInputFramesPerBuffer()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/voiceengine/NTAudioManager;->isLowLatencyInputSupported()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->assertTrue(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/voiceengine/NTAudioManager;->getLowLatencyOutputFramesPerBuffer()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method

.method private getLowLatencyOutputFramesPerBuffer()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/voiceengine/NTAudioManager;->isLowLatencyOutputSupported()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->assertTrue(Z)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->runningOnJellyBeanMR1OrHigher()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/16 v1, 0x100

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v4, 0x3

    const-string/jumbo v2, "mBRmpopReTM_nUoed.u_RSrETEAFdyUr_PrtPUFdFaiOa.."

    const-string/jumbo v2, "pPRrRrutFFaiF.deoMBd_TdrRO_oUApE.E_mUnyU.eSiTPa"

    const-string v2, "OdTRotPpREPUTdFamFir.So_EpUMBi_eFrUnREAdye.r_.a"

    const-string v2, "android.media.property.OUTPUT_FRAMES_PER_BUFFER"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Landroid/media/AudioManager;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v1

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v1
.end method

.method private static getMinInputFrameSize(II)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    mul-int/lit8 v0, p1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    if-ne p1, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v1}, Lcom/voiceengine/NTAudioManager;->assertTrue(Z)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/16 p1, 0x10

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, p1, v1}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    div-int/2addr p0, v0

    const/4 v3, 0x4

    return p0
.end method

.method private static getMinOutputFrameSize(II)I
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    mul-int/lit8 v0, p1, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x1

    shr-int/2addr v3, v1

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne p1, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 p1, 0x4

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ne p1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/16 p1, 0xc

    :goto_0
    const/4 v4, 0x3

    invoke-static {p0, p1, v2}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    div-int/2addr p0, v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    return p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 p0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    return p0
.end method

.method private getNativeOutputSampleRate()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/16 v0, 0x1f40

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method private hasEarpiece()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->context:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-string/jumbo v1, "heleaborprdwa.any.tirnpehd"

    const-string v1, "aaalyndphdo.ewpred.renrtih"

    const/4 v3, 0x6

    const-string/jumbo v1, "nodrd.uae.nodrphihaewteray"

    const-string v1, "android.hardware.telephony"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method private init()Z
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v1, "itin"

    const-string/jumbo v1, "inti"

    const/4 v5, 0x2

    const-string/jumbo v1, "init"

    const-string/jumbo v1, "init"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->NTLOGI(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/voiceengine/NTAudioManager;->initialized:Z

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "qdomsa:pu o iid"

    const-string v2, ": ui msiq aoodd"

    const/4 v5, 0x1

    const-string/jumbo v2, "u :oddiaqe iosm"

    const-string v2, "audio mode is: "

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object v2, Lcom/voiceengine/NTAudioManager;->AUDIO_MODES:[Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v3, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v3}, Landroid/media/AudioManager;->getMode()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    aget-object v2, v2, v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->NTLOGI(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-boolean v1, p0, Lcom/voiceengine/NTAudioManager;->initialized:Z

    const/4 v5, 0x3

    const/4 v4, 0x4

    return v1
.end method

.method private static isAcousticEchoCancelerSupported()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->deviceIsBlacklistedForHwAecUsage()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "Ccsl   gaf Atuke absissolesi!HEWr"

    const-string/jumbo v1, "fksg WCA a eeiEo  sulatsc!Hs ilbr"

    const/4 v3, 0x5

    const-string v1, "cElma  WC Aasidei rs!Hgoufsbt k e"

    const-string v1, " is blacklisted for HW AEC usage!"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/voiceengine/NTAudioManager;->NTLOGI(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->isAcousticEchoCancelerSupported()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    return v0
.end method

.method private isCommunicationModeEnabled()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/media/AudioManager;->getMode()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    return v0
.end method

.method private isDeviceBlacklistedForOpenSLESUsage()Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->deviceIsBlacklistedForOpenSLESUsage()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const-string v2, "Eb eotfd  !eLOur sl lpSeSakngiic osm"

    const-string/jumbo v2, "otLmlb secup ke r Ofgnseisi S!SdEl a"

    const/4 v4, 0x0

    const-string/jumbo v2, "g OlcbeSsE k b tSsui as d!eLifernolp"

    const-string v2, " is blacklisted for OpenSL ES usage!"

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v1}, Lcom/voiceengine/NTAudioManager;->NTLOGE(Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return v0
.end method

.method private isLowLatencyOutputSupported()Z
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Lcom/voiceengine/NTAudioManager;->isOpenSLESSupported()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->context:Landroid/content/Context;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v1, "ialoiaudh.lrca.onoyeweuda.ddwn_rar"

    const-string v1, ".ia.oreaalnarwdln.oeddurwooac_dhyi"

    const/4 v3, 0x2

    const-string v1, "aan.hnrpiow.coydeawtrad_oudri.leld"

    const-string v1, "android.hardware.audio.low_latency"

    const/4 v2, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    move v3, v0

    and-int/2addr v2, v0

    const/4 v3, 0x5

    return v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    return v0
.end method

.method private static isOpenSLESSupported()Z
    .locals 3

    const/4 v2, 0x1

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->runningOnGingerBreadOrHigher()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method private native nativeCacheAudioParameters(IIZZIIJ)V
.end method

.method private storeAudioParameters()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/voiceengine/NTAudioManager;->isAcousticEchoCancelerSupported()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/voiceengine/NTAudioManager;->hardwareAEC:Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/voiceengine/NTAudioManager;->isLowLatencyOutputSupported()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/voiceengine/NTAudioManager;->lowLatencyOutput:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Lcom/voiceengine/NTAudioManager;->getLowLatencyOutputFramesPerBuffer()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    iget v0, p0, Lcom/voiceengine/NTAudioManager;->sampleRate:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    iget v1, p0, Lcom/voiceengine/NTAudioManager;->channels:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/voiceengine/NTAudioManager;->getMinOutputFrameSize(II)I

    move-result v0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput v0, p0, Lcom/voiceengine/NTAudioManager;->outputBufferSize:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p0, Lcom/voiceengine/NTAudioManager;->sampleRate:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v1, p0, Lcom/voiceengine/NTAudioManager;->channels:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/voiceengine/NTAudioManager;->getMinInputFrameSize(II)I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput v0, p0, Lcom/voiceengine/NTAudioManager;->inputBufferSize:I

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public changeToHeadset()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setSpeakerphoneOn(Z)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public changeToReceiver()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v2, 0x7

    or-int/2addr v3, v2

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setSpeakerphoneOn(Z)V

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v3, 0x5

    return-void
.end method

.method public changeToSpeaker()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setMode(I)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioManager;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->setSpeakerphoneOn(Z)V

    const/4 v2, 0x4

    or-int/2addr v3, v2

    return-void
.end method

.method public isLowLatencyInputSupported()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->runningOnLollipopOrHigher()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/voiceengine/NTAudioManager;->isLowLatencyOutputSupported()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    return v0

    :cond_0
    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method
