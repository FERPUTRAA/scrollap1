.class public Lcom/voiceengine/NTAudioRecord;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "NewApi"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/voiceengine/NTAudioRecord$AudioRecordThread;
    }
.end annotation


# static fields
.field private static final BITS_PER_SAMPLE:I = 0x10

.field private static final BUFFERS_PER_SECOND:I = 0x64

.field private static final CALLBACK_BUFFER_SIZE_MS:I = 0xa

.field private static final DEBUG:Z = false

.field private static final TAG:Ljava/lang/String; = "NTAudioRecorder"


# instance fields
.field private aec:Landroid/media/audiofx/AcousticEchoCanceler;

.field private audioRecord:Landroid/media/AudioRecord;

.field private audioThread:Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

.field private byteBuffer:Ljava/nio/ByteBuffer;

.field private final context:Landroid/content/Context;

.field private final nativeAudioRecord:J

.field private useBuiltInAEC:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;J)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v3, 0x1

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioThread:Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/voiceengine/NTAudioRecord;->useBuiltInAEC:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    const-string/jumbo v1, "orct"

    const-string/jumbo v1, "tocr"

    const/4 v3, 0x5

    const-string v1, "crot"

    const-string v1, "ctor"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, "dAsdorrieTNoesR"

    const-string v1, "dcsdiNTooeAeRrr"

    const/4 v3, 0x5

    const-string v1, "dNAmeToRdroueic"

    const-string v1, "NTAudioRecorder"

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/voiceengine/NTAudioRecord;->context:Landroid/content/Context;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    iput-wide p2, p0, Lcom/voiceengine/NTAudioRecord;->nativeAudioRecord:J

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method private native BufferData([BI)V
.end method

.method private EnableBuiltInAEC(Z)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "lAEuoI(nBlbetECai"

    const-string v1, "EnableBuiltInAEC("

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/16 v1, 0x29

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v1, "eddurbcrNiooRTe"

    const-string v1, "RNemrocdriTuode"

    const/4 v3, 0x4

    const-string v1, "derRruuceooAdNT"

    const-string v1, "NTAudioRecorder"

    const/4 v2, 0x7

    or-int/2addr v3, v2

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->isAcousticEchoCancelerApproved()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-boolean p1, p0, Lcom/voiceengine/NTAudioRecord;->useBuiltInAEC:Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/media/audiofx/AudioEffect;->setEnabled(Z)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const-string/jumbo p1, "ldetsoapeoioehcEllsaCennEiArubfea.cdcc"

    const-string p1, "bsfdoecCcruillenEhaioAoase.cnecledE ta"

    const/4 v3, 0x5

    const-string p1, "CEln olaqebtielscfsadid.ncrucacEehoete"

    const-string p1, "AcousticEchoCanceler.setEnabled failed"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 p1, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, "cnsrc:eEeodecntbtl.oc gaEaCihuesb"

    const-string v0, "cbru bto.CcgsacaEElnoedeteicA:hen"

    const/4 v3, 0x1

    const-string/jumbo v0, "occm EaeActicn:t.uerlldsabgeECheo"

    const-string v0, "AcousticEchoCanceler.getEnabled: "

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/media/audiofx/AudioEffect;->getEnabled()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return p1
.end method

.method private InitRecording(II)I
    .locals 13

    const/4 v12, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "i(mtogn=euedIprailntRsacR"

    const-string v1, "dierlpunRmtasI=aR(tcgnoie"

    const-string/jumbo v1, "nRiIebasoetRian(mdcrel=tg"

    const-string v1, "InitRecording(sampleRate="

    const/4 v12, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const-string/jumbo v1, "nnhlepucas "

    const-string v1, "cln=asnp he"

    const-string v1, "an ,ecnplhs"

    const-string v1, ", channels="

    const/4 v12, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string v1, ")"

    const-string v1, ")"

    const-string v1, ")"

    const-string v1, ")"

    const/4 v12, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x4

    const-string v1, "eRcArqudqioToNr"

    const-string/jumbo v1, "roduTAReqrdcoiN"

    const-string v1, "cusRArTeoeodrNi"

    const-string v1, "NTAudioRecorder"

    const/4 v12, 0x6

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->context:Landroid/content/Context;

    const/4 v12, 0x0

    const-string/jumbo v2, "rRomiAe_Emi..soCsOdDnIOisdnaUDR"

    const-string/jumbo v2, "nCsIdEmOe.sROdor.D_iriUsaDRniAo"

    const-string v2, "UsrRoo.iOOme.Ddn_rRdiIsECADaipn"

    const-string v2, "android.permission.RECORD_AUDIO"

    const/4 v12, 0x5

    invoke-static {v0, v2}, Lcom/voiceengine/NTAudioUtils;->hasPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v12, 0x2

    const/4 v2, -0x1

    const/4 v12, 0x1

    if-nez v0, :cond_0

    const/4 v12, 0x6

    const-string p1, "RECORD_AUDIO permission is missing"

    const/4 v12, 0x5

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x4

    return v2

    :cond_0
    const/4 v12, 0x0

    const/4 v0, 0x2

    const/4 v12, 0x1

    mul-int/2addr p2, v0

    const/4 v12, 0x2

    div-int/lit8 v3, p1, 0x64

    const/4 v12, 0x2

    mul-int/2addr p2, v3

    invoke-static {p2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v12, 0x5

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecord;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string/jumbo v4, "meeb baBytic.ff:tracp"

    const-string v4, "a.imatyBecrybfc:pft e"

    const-string v4, "bapetyu. :tccarifeuBy"

    const-string v4, "byteBuffer.capacity: "

    const/4 v12, 0x0

    invoke-direct {p2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecord;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x0

    invoke-virtual {v4}, Ljava/nio/Buffer;->capacity()I

    move-result v4

    const/4 v12, 0x6

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string/jumbo v4, "mf:euaepoPB rerffrs"

    const-string/jumbo v4, "rureo esfemfB: Pfra"

    const-string v4, " eP: mfrq;efrBuaesf"

    const-string v4, "; framesPerBuffer: "

    const/4 v12, 0x3

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x5

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x6

    iget-object p2, p0, Lcom/voiceengine/NTAudioRecord;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x1

    iget-wide v4, p0, Lcom/voiceengine/NTAudioRecord;->nativeAudioRecord:J

    const/4 v12, 0x4

    invoke-direct {p0, p2, v4, v5}, Lcom/voiceengine/NTAudioRecord;->nativeCacheDirectBufferAddress(Ljava/nio/ByteBuffer;J)V

    const/4 v12, 0x5

    const/16 p2, 0x10

    const/4 v12, 0x6

    invoke-static {p1, p2, v0}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result p2

    const/4 v12, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string/jumbo v4, "fusrfuBAzei Stecidendg:e.RMroo"

    const-string v4, "dAofebitorBede:fRuierMgc n.uzS"

    const-string/jumbo v4, "utemczSfud.e:iioAfoMnig edBeRr"

    const-string v4, "AudioRecord.getMinBufferSize: "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x5

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x4

    if-eqz v0, :cond_1

    const/4 v12, 0x4

    invoke-virtual {v0}, Landroid/media/audiofx/AudioEffect;->release()V

    const/4 v12, 0x5

    const/4 v0, 0x0

    const/4 v12, 0x7

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    :cond_1
    const/4 v12, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v12, 0x6

    if-nez v0, :cond_2

    const/4 v12, 0x6

    move v0, v5

    move v0, v5

    move v0, v5

    move v0, v5

    const/4 v12, 0x1

    goto :goto_0

    :cond_2
    const/4 v12, 0x2

    move v0, v4

    move v0, v4

    move v0, v4

    move v0, v4

    :goto_0
    const/4 v12, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/nio/Buffer;->capacity()I

    move-result v0

    const/4 v12, 0x0

    invoke-static {v0, p2}, Ljava/lang/Math;->max(II)I

    move-result v11

    const/4 v12, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo v0, "zbeBo efunseuirS:It"

    const-string v0, "eIriBfubSsnufezte :"

    const-string v0, "IfSebbitfsyu n:rzBe"

    const-string v0, "bufferSizeInBytes: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-virtual {p2, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v12, 0x7

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :try_start_0
    const/4 v12, 0x5

    invoke-static {}, Lcom/voiceengine/NTAudioRecord;->chkNewDev()Z

    move-result p2

    const/4 v12, 0x5

    if-eqz p2, :cond_3

    const-string/jumbo p2, "hcihteucer  kwpeD etunv"

    const-string p2, "ecehucipkD terh  wvne t"

    const-string p2, "check new Dev with true"

    const/4 v12, 0x3

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x0

    new-instance p2, Landroid/media/AudioRecord;

    const/4 v12, 0x6

    const/4 v7, 0x7

    const/4 v12, 0x6

    const/16 v9, 0x10

    const/4 v12, 0x6

    const/4 v10, 0x2

    move-object v6, p2

    move-object v6, p2

    const/4 v12, 0x5

    move v8, p1

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v12, 0x2

    invoke-direct/range {v6 .. v11}, Landroid/media/AudioRecord;-><init>(IIIII)V

    const/4 v12, 0x7

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x4

    goto :goto_1

    :cond_3
    const/4 v12, 0x6

    const-string p2, "aDhiechpq en veks fwlwct"

    const-string p2, "e wikctvqDlhfse eeh wcna"

    const-string p2, " ksDtaehqne c fhwecilve "

    const-string p2, "check new Dev with false"

    const/4 v12, 0x5

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x6

    new-instance p2, Landroid/media/AudioRecord;

    const/4 v12, 0x0

    const/4 v7, 0x1

    const/4 v12, 0x2

    const/16 v9, 0x10

    const/4 v12, 0x0

    const/4 v10, 0x2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v12, 0x6

    move v8, p1

    move v8, p1

    move v8, p1

    const/4 v12, 0x1

    invoke-direct/range {v6 .. v11}, Landroid/media/AudioRecord;-><init>(IIIII)V

    const/4 v12, 0x6

    iput-object p2, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1

    :goto_1
    iget-object p1, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    invoke-virtual {p1}, Landroid/media/AudioRecord;->getState()I

    move-result p1

    const/4 v12, 0x5

    if-ne p1, v5, :cond_4

    const/4 v12, 0x3

    move v4, v5

    move v4, v5

    move v4, v5

    move v4, v5

    :cond_4
    const/4 v12, 0x3

    invoke-static {v4}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    const/4 v12, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const-string p2, "essussd:n s ricRoD IAoio"

    const-string/jumbo p2, "inssRA  ueDosd:oIosei rc"

    const-string/jumbo p2, "nc msioordo :I RsAieDuds"

    const-string p2, "AudioRecord session ID: "

    const/4 v12, 0x0

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x5

    iget-object p2, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x0

    invoke-virtual {p2}, Landroid/media/AudioRecord;->getAudioSessionId()I

    move-result p2

    const/4 v12, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const-string p2, ", "

    const-string p2, ", "

    const/4 v12, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string v0, "ar:doo mouit a"

    const-string v0, "audio format: "

    const/4 v12, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x5

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getAudioFormat()I

    move-result v0

    const/4 v12, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string/jumbo v0, "nacn blsem"

    const-string v0, ":c mlsnena"

    const-string/jumbo v0, "sh:canunl "

    const-string v0, "channels: "

    const/4 v12, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x4

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getChannelCount()I

    move-result v0

    const/4 v12, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string v0, "ee lrmap :pts"

    const-string/jumbo v0, "sample rate: "

    const/4 v12, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x3

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getSampleRate()I

    move-result v0

    const/4 v12, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const-string/jumbo v0, "iChccuaeq:Aa.AsoeicasnElolv obctil"

    const-string v0, "CAolovEtnclbsAcecas. aeliaiiuc:orh"

    const-string/jumbo v0, "ossetCvcerlaaucA:sohcclinE.iiela b"

    const-string v0, "AcousticEchoCanceler.isAvailable: "

    const/4 v12, 0x6

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x3

    invoke-static {}, Lcom/voiceengine/NTAudioRecord;->builtInAECIsAvailable()Z

    move-result v0

    const/4 v12, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x4

    invoke-static {}, Lcom/voiceengine/NTAudioRecord;->builtInAECIsAvailable()Z

    move-result p1

    const/4 v12, 0x0

    if-nez p1, :cond_5

    const/4 v12, 0x1

    return v3

    :cond_5
    const/4 v12, 0x3

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->deviceIsBlacklistedForHwAecUsage()Z

    move-result p1

    const/4 v12, 0x7

    if-eqz p1, :cond_6

    const/4 v12, 0x1

    iget-boolean p1, p0, Lcom/voiceengine/NTAudioRecord;->useBuiltInAEC:Z

    const/4 v12, 0x5

    xor-int/2addr p1, v5

    const/4 v12, 0x5

    invoke-static {p1}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    :cond_6
    const/4 v12, 0x1

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/media/AudioRecord;->getAudioSessionId()I

    move-result p1

    const/4 v12, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string v4, "S imons ewtiisbh:ou"

    const-string/jumbo v4, "s:oeabnu  wSiitiohs"

    const-string/jumbo v4, "w :soiuoanestoSid h"

    const-string v4, "audioSession with: "

    const/4 v12, 0x0

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x0

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->NTLOGI(Ljava/lang/String;)V

    :try_start_1
    const/4 v12, 0x7

    invoke-static {p1}, Landroid/media/audiofx/AcousticEchoCanceler;->create(I)Landroid/media/audiofx/AcousticEchoCanceler;

    move-result-object p1

    const/4 v12, 0x7

    iput-object p1, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    const/4 v12, 0x6

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x3

    if-nez p1, :cond_7

    const/4 v12, 0x6

    const-string/jumbo p1, "etuahbcAeirccEn.elr aodeeuofacctsl"

    const-string p1, "c cdehuctaAlraiua.eroencteEfelosic"

    const-string p1, "AcousticEchoCanceler.create failed"

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x4

    return v2

    :cond_7
    const/4 v12, 0x2

    iget-boolean v0, p0, Lcom/voiceengine/NTAudioRecord;->useBuiltInAEC:Z

    const/4 v12, 0x0

    invoke-virtual {p1, v0}, Landroid/media/audiofx/AudioEffect;->setEnabled(Z)I

    move-result p1

    const/4 v12, 0x2

    if-eqz p1, :cond_8

    const/4 v12, 0x1

    const-string/jumbo p1, "iiealauoeebAhscocfnepacldrCtn.cEsEulet"

    const-string p1, "dielsbnputdAollienacoC.tfEEcacseheerac"

    const-string/jumbo p1, "tdne Capie.hlacElsobetanlAecuiEsorccfd"

    const-string p1, "AcousticEchoCanceler.setEnabled failed"

    const/4 v12, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x7

    return v2

    :cond_8
    const/4 v12, 0x2

    iget-object p1, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x0

    invoke-virtual {p1}, Landroid/media/audiofx/AudioEffect;->getDescriptor()Landroid/media/audiofx/AudioEffect$Descriptor;

    move-result-object p1

    const/4 v12, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const-string v2, "aehl rAcqqauneteEcon omcCcs"

    const-string/jumbo v2, "lec EAmcqccusaeC:toharo nne"

    const-string v2, " hscmeacsulEnnaeocetAoci r:"

    const-string v2, "AcousticEchoCanceler name: "

    const/4 v12, 0x3

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x5

    iget-object v2, p1, Landroid/media/audiofx/AudioEffect$Descriptor;->name:Ljava/lang/String;

    const/4 v12, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const-string/jumbo v2, "tpim:snmme el"

    const-string/jumbo v2, "etsnimmprl: e"

    const-string/jumbo v2, "mmpeo:ino etr"

    const-string/jumbo v2, "implementor: "

    const/4 v12, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    iget-object v2, p1, Landroid/media/audiofx/AudioEffect$Descriptor;->implementor:Ljava/lang/String;

    const/4 v12, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const-string/jumbo p2, "ud:mi "

    const-string p2, "d:u ib"

    const-string/jumbo p2, "uuid: "

    const/4 v12, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    iget-object p1, p1, Landroid/media/audiofx/AudioEffect$Descriptor;->uuid:Ljava/util/UUID;

    const/4 v12, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x4

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string/jumbo p2, "uiAtrsuecn Etocoacdbl:.haeeCoclEn"

    const-string p2, "et.aotclhnE:eucle EodgcAobciarnCs"

    const-string p2, "dErtoblpcCtnshoecacaE uen:Ae.elic"

    const-string p2, "AcousticEchoCanceler.getEnabled: "

    const/4 v12, 0x6

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x5

    iget-object p2, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v12, 0x0

    invoke-virtual {p2}, Landroid/media/audiofx/AudioEffect;->getEnabled()Z

    move-result p2

    const/4 v12, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x0

    invoke-static {v1, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x1

    return v3

    :catch_1
    move-exception p1

    const/4 v12, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x1

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v12, 0x0

    return v2
.end method

.method private static NTLOGE(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "ecorRurTqeNbdoA"

    const-string v0, "AurNRbTdcooeerd"

    const/4 v2, 0x3

    const-string v0, "NescTAoderrRuid"

    const-string v0, "NTAudioRecorder"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method private static NTLOGI(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string v0, "dRTmrdueoNoecuA"

    const-string v0, "NudecRurrTeoAdo"

    const/4 v2, 0x0

    const-string/jumbo v0, "reTuorecRAdioNd"

    const-string v0, "NTAudioRecorder"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method private StartRecording()Z
    .locals 8

    const/4 v7, 0x3

    const-string/jumbo v0, "neaRgbtrdStipr"

    const-string/jumbo v0, "tanidReprogtSr"

    const/4 v7, 0x4

    const-string/jumbo v0, "orrtteuSacgRni"

    const-string v0, "StartRecording"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v1, "eeTAiqNpdodcorr"

    const-string v1, "cerTeiAdqooRNrd"

    const/4 v7, 0x6

    const-string v1, "eTNuorodqiARcer"

    const-string v1, "NTAudioRecorder"

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    move v0, v2

    move v0, v2

    const/4 v7, 0x7

    move v0, v2

    move v0, v2

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    move v0, v3

    move v0, v3

    const/4 v7, 0x7

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioThread:Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez v0, :cond_1

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v0, v2

    move v0, v2

    const/4 v7, 0x2

    move v0, v2

    move v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto :goto_1

    :cond_1
    const/4 v7, 0x6

    move v0, v3

    move v0, v3

    const/4 v7, 0x6

    move v0, v3

    move v0, v3

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v0, 0x0

    or-int/2addr v7, v0

    :try_start_0
    const/4 v6, 0x7

    move v7, v6

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v4}, Landroid/media/AudioRecord;->startRecording()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v4}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v4

    const/4 v6, 0x4

    xor-int/2addr v7, v6

    const/4 v5, 0x3

    move v7, v5

    const/4 v6, 0x0

    move v7, v6

    if-eq v4, v5, :cond_2

    const/4 v7, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo v4, "resctduis =dn  ol.csseAritiRoadeogdtaRaft+"

    const-string/jumbo v4, "tuseA.sr iirdcaRlio e+tcdnsatdd=tRaf orgoe"

    const/4 v7, 0x1

    const-string v4, "as=m d uAst.dodlRritaceagceeoretio+Rn tfdr"

    const-string v4, "AudioRecord.startRecording failed + state="

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v4}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v6, 0x6

    move v7, v6

    return v3

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v0, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v1, "vRruoddrJhedoocTaemia"

    const-string/jumbo v1, "idrmaeoRJdhcuvdaTorea"

    const/4 v7, 0x2

    const-string v1, "ArrdRbadoodehJevcuTai"

    const-string v1, "AudioRecordJavaThread"

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v0, p0, v1}, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;-><init>(Lcom/voiceengine/NTAudioRecord;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioThread:Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    return v2

    :catch_0
    move-exception v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v5, ":roiR u.urnddogaiiedrtocsde aRclAft"

    const-string v5, "adeiocisrdg rrufl.ntda:oi eRAtRcdoo"

    const/4 v7, 0x1

    const-string/jumbo v5, "tuie rcpoecAd.ddiedlaioRrRsfgno: rt"

    const-string v5, "AudioRecord.startRecording failed: "

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x3

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    return v3
.end method

.method static synthetic access$0(Lcom/voiceengine/NTAudioRecord;)Landroid/media/AudioRecord;
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$1(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/voiceengine/NTAudioRecord;->assertTrue(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$2(Lcom/voiceengine/NTAudioRecord;)Ljava/nio/ByteBuffer;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/voiceengine/NTAudioRecord;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-object p0
.end method

.method static synthetic access$3(Lcom/voiceengine/NTAudioRecord;)J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/voiceengine/NTAudioRecord;->nativeAudioRecord:J

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-wide v0
.end method

.method static synthetic access$4(Lcom/voiceengine/NTAudioRecord;IJ)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2, p3}, Lcom/voiceengine/NTAudioRecord;->nativeDataIsRecorded(IJ)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method private static assertTrue(Z)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "teni bipnecred d ut coEooxett"

    const/4 v2, 0x5

    const-string/jumbo v0, "ntccEpi qetdetrx o enuitebood"

    const-string v0, "Expected condition to be true"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    throw p0
.end method

.method private static builtInAECIsAvailable()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->isAcousticEchoCancelerSupported()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public static chkNewDev()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method private native nativeCacheDirectBufferAddress(Ljava/nio/ByteBuffer;J)V
.end method

.method private native nativeDataIsRecorded(IJ)V
.end method


# virtual methods
.method public StopRecording()Z
    .locals 5

    const-string/jumbo v0, "nostgrepiodcS"

    const-string v0, "Sdigtournocep"

    const/4 v4, 0x2

    const-string v0, "StopRecording"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/voiceengine/NTAudioRecord;->NTLOGI(Ljava/lang/String;)V

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioThread:Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    move v4, v3

    return v1

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/voiceengine/NTAudioRecord$AudioRecordThread;->joinThread()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioThread:Lcom/voiceengine/NTAudioRecord$AudioRecordThread;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v2}, Landroid/media/audiofx/AudioEffect;->release()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->aec:Landroid/media/audiofx/AcousticEchoCanceler;

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    iget-object v2, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/media/AudioRecord;->release()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/voiceengine/NTAudioRecord;->audioRecord:Landroid/media/AudioRecord;

    const/4 v4, 0x1

    return v1
.end method

.method public native executeAudioRecordMethod()I
.end method
