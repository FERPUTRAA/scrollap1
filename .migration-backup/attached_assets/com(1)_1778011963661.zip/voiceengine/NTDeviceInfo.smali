.class public final Lcom/voiceengine/NTDeviceInfo;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static getAndroidBuildId()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y@s ~ @~ ~4 .@l@/@@@ @n i @@~~Komd~~ u@~~f  ls~r~c@ ~~~~S@ o@ibbo v@~@b o@ taM ~~~ /~tf~o@1io-~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Landroid/os/Build;->ID:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method public static getBrand()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getBuildRelease()Ljava/lang/String;
    .locals 3

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public static getBuildType()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Landroid/os/Build;->TYPE:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getDevice()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static getDeviceManufacturer()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public static getDeviceModel()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getProduct()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public static getSdkVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-object v0
.end method
