.class public Lcom/voiceengine/NTAudioTrack;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/voiceengine/NTAudioTrack$AudioTrackThread;
    }
.end annotation


# static fields
.field private static final BITS_PER_SAMPLE:I = 0x10

.field private static final BUFFERS_PER_SECOND:I = 0x64

.field private static final CALLBACK_BUFFER_SIZE_MS:I = 0xa

.field private static final DEBUG:Z = true

.field private static final TAG:Ljava/lang/String; = "NTAudioTrack"


# instance fields
.field private final audioManager:Landroid/media/AudioManager;

.field private audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

.field private audioTrack:Landroid/media/AudioTrack;

.field private byteBuffer:Ljava/nio/ByteBuffer;

.field private final context:Landroid/content/Context;

.field private final nativeAudioTrack:J


# direct methods
.method public constructor <init>(Landroid/content/Context;J)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v2, 0x3

    move v3, v2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string/jumbo v1, "tcor"

    const-string/jumbo v1, "ocrt"

    const/4 v3, 0x5

    const-string/jumbo v1, "rotc"

    const-string v1, "ctor"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->getThreadInfo()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "scskoTTNAdiu"

    const-string/jumbo v1, "rusAkdTocTNi"

    const-string v1, "cuomTrNiAakd"

    const-string v1, "NTAudioTrack"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/voiceengine/NTAudioTrack;->context:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-wide p2, p0, Lcom/voiceengine/NTAudioTrack;->nativeAudioTrack:J

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo p2, "iuamo"

    const-string/jumbo p2, "uiamo"

    const/4 v3, 0x0

    const-string p2, "bdoui"

    const-string p2, "audio"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    check-cast p1, Landroid/media/AudioManager;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v1}, Lcom/voiceengine/NTAudioUtils;->logDeviceInfo(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method private GetStreamMaxVolume()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~@@@@u@b@ l~ @@ o~~n@@td~iK~@@Mu ~cf @o~S s~ v4~-  r.~y t@~~ o~i@~ b@~  ~a~ilf1@~ /@o/~m@ ~ o@o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-string v0, "TuToakApiNcr"

    const-string v0, "NTAudioTrack"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v1, "umatVemGqtrMSlaoex"

    const-string v1, "GetStreamMaxVolume"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamMaxVolume(I)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v0
.end method

.method private GetStreamVolume()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v0, "TosuNkoAiTar"

    const-string v0, "TATaorkidouN"

    const/4 v3, 0x0

    const-string/jumbo v0, "ukNmiTroaTcd"

    const-string v0, "NTAudioTrack"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "eemtoetSorlumGb"

    const-string/jumbo v1, "rGtmebouateemlS"

    const/4 v3, 0x0

    const-string v1, "SVrltbamGemteeu"

    const-string v1, "GetStreamVolume"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    move v0, v1

    move v0, v1

    const/4 v3, 0x1

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Landroid/media/AudioManager;->getStreamVolume(I)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v0
.end method

.method private InitPlayout(II)V
    .locals 12

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string v1, "=P(teauostalaeRilItypnu"

    const-string v1, "InitPlayout(sampleRate="

    const/4 v11, 0x0

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    const-string/jumbo v1, "lhuans,p=ce"

    const-string/jumbo v1, "snnle=u,ach"

    const/4 v11, 0x1

    const-string v1, ", channels="

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const-string v1, ")"

    const-string v1, ")"

    const-string v1, ")"

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string/jumbo v1, "oApkaricqNTu"

    const-string/jumbo v1, "ocTrakipATNu"

    const/4 v11, 0x0

    const-string v1, "aTsAcrkNuoTd"

    const-string v1, "NTAudioTrack"

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    const/4 v0, 0x2

    const/4 v10, 0x2

    and-int/2addr v11, v10

    mul-int/2addr p2, v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    div-int/lit8 v2, p1, 0x64

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    mul-int/2addr p2, v2

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-static {p2}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object p2

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    iput-object p2, p0, Lcom/voiceengine/NTAudioTrack;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string v2, "atrmpef.Bty efuqcb:ia"

    const-string/jumbo v2, "pireac:tqby. cfeaBuft"

    const/4 v11, 0x6

    const-string/jumbo v2, "ffieopc:ytcuarbBy .ta"

    const-string v2, "byteBuffer.capacity: "

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/voiceengine/NTAudioTrack;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x6

    const/4 v10, 0x5

    iget-object p2, p0, Lcom/voiceengine/NTAudioTrack;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    iget-wide v2, p0, Lcom/voiceengine/NTAudioTrack;->nativeAudioTrack:J

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-direct {p0, p2, v2, v3}, Lcom/voiceengine/NTAudioTrack;->nativeCacheDirectBufferAddress(Ljava/nio/ByteBuffer;J)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 p2, 0x4

    move v11, p2

    const/4 v10, 0x3

    or-int/2addr v11, v10

    invoke-static {p1, p2, v0}, Landroid/media/AudioTrack;->getMinBufferSize(III)I

    move-result v7

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string v0, "eed:fbSuiszaAuf gtnMroekcriT."

    const-string v0, ":usfutreAedf.nigerkcaoTziS Mi"

    const-string v0, "AudioTrack.getMinBufferSize: "

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {p2, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {v1, p2}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x3

    iget-object p2, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v0, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v9, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    if-nez p2, :cond_0

    const/4 v10, 0x5

    shr-int/2addr v11, v10

    move p2, v9

    move p2, v9

    const/4 v11, 0x0

    move p2, v9

    move p2, v9

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto :goto_0

    :cond_0
    const/4 v11, 0x1

    move p2, v0

    move p2, v0

    const/4 v11, 0x3

    move p2, v0

    move p2, v0

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {p2}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    iget-object p2, p0, Lcom/voiceengine/NTAudioTrack;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p2}, Ljava/nio/Buffer;->capacity()I

    move-result p2

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-ge p2, v7, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    move p2, v9

    move p2, v9

    move p2, v9

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto :goto_1

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    move p2, v0

    move p2, v0

    const/4 v11, 0x5

    move p2, v0

    move p2, v0

    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-static {p2}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    :try_start_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    new-instance p2, Landroid/media/AudioTrack;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/4 v3, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v5, 0x4

    const/4 v11, 0x4

    const/4 v6, 0x2

    const/4 v11, 0x6

    shl-int/2addr v10, v6

    const/4 v11, 0x0

    const/4 v8, 0x5

    const/4 v11, 0x1

    const/4 v8, 0x1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    move v4, p1

    move v4, p1

    const/4 v11, 0x6

    move v4, p1

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-direct/range {v2 .. v8}, Landroid/media/AudioTrack;-><init>(IIIIII)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    iput-object p2, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {p2}, Landroid/media/AudioTrack;->getState()I

    move-result p1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-ne p1, v9, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    move p1, v9

    move p1, v9

    const/4 v11, 0x3

    move p1, v9

    move p1, v9

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    goto :goto_2

    :cond_2
    const/4 v11, 0x2

    move p1, v0

    move p1, v0

    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {p1}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v10, 0x3

    move v11, v10

    iget-object p1, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {p1}, Landroid/media/AudioTrack;->getPlayState()I

    move-result p1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-ne p1, v9, :cond_3

    const/4 v11, 0x4

    const/4 v10, 0x1

    move v0, v9

    move v0, v9

    const/4 v11, 0x2

    move v0, v9

    :cond_3
    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {v0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-void
.end method

.method private static NTLOGE(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string v0, "duiTokumTNac"

    const-string v0, "ciomTuTardNk"

    const/4 v2, 0x6

    const-string/jumbo v0, "iuTraoTpNdkc"

    const-string v0, "NTAudioTrack"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method private static NTLOGI(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string/jumbo v0, "roNTTdikqAua"

    const-string/jumbo v0, "kTdroiToaANu"

    const/4 v2, 0x0

    const-string v0, "TTsiaAdkucoN"

    const-string v0, "NTAudioTrack"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method private SetStreamVolume(I)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v1, "teSm(trmobeaulem"

    const-string/jumbo v1, "moerabmVet(tlueS"

    const/4 v5, 0x0

    const-string/jumbo v1, "m(StomeVuaeetrlS"

    const-string v1, "SetStreamVolume("

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v1, ")"

    const/4 v5, 0x2

    const-string v1, ")"

    const-string v1, ")"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v1, "TaAdTbiurkuo"

    const-string v1, "dcTuATukairo"

    const/4 v5, 0x4

    const-string v1, "NTriauudcATo"

    const-string v1, "NTAudioTrack"

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x3

    move v0, v3

    move v0, v3

    const/4 v5, 0x6

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {}, Lcom/voiceengine/NTAudioUtils;->runningOnLollipopOrHigher()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/media/AudioManager;->isVolumeFixed()Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    const-string/jumbo p1, "fy pmespmve elhatoxpiene  plecdi eicodTv .il"

    const-string p1, "Tale  lpems pci xo. eehetyclvefipdvdemiinom "

    const/4 v5, 0x3

    const-string p1, "cdve mplqoi f.y eieolpvxseeh ad uinml emetTi"

    const-string p1, "The device implements a fixed volume policy."

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v3

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioManager:Landroid/media/AudioManager;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v3, p1, v3}, Landroid/media/AudioManager;->setStreamVolume(III)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    return v2
.end method

.method private StartPlayout()Z
    .locals 5

    const/4 v4, 0x1

    const-string v0, "TosdkqNrAiTu"

    const-string v0, "TrNiduATqako"

    const/4 v4, 0x2

    const-string v0, "arTmATNkudci"

    const-string v0, "NTAudioTrack"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "tlsPoSutyort"

    const-string v1, "atsStlutrPyo"

    const/4 v4, 0x4

    const-string v1, "SutaPbrtotya"

    const-string v1, "StartPlayout"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    move v0, v2

    move v0, v2

    move v0, v2

    move v0, v2

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    move v1, v2

    move v1, v2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    :cond_1
    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v4, 0x1

    new-instance v0, Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v1, "dcroiauahkmTTuAaavrJ"

    const-string v1, "aovmTkrirTacdhaAaudJ"

    const/4 v4, 0x6

    const-string/jumbo v1, "iadehTTprJcarAduvkoa"

    const-string v1, "AudioTrackJavaThread"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0, p0, v1}, Lcom/voiceengine/NTAudioTrack$AudioTrackThread;-><init>(Lcom/voiceengine/NTAudioTrack;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v2
.end method

.method private StopPlayout()Z
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v0, "uArkiaNoqodc"

    const-string/jumbo v0, "urTcoANodaik"

    const/4 v4, 0x1

    const-string v0, "TdscTuaoNAki"

    const-string v0, "NTAudioTrack"

    const/4 v4, 0x0

    const-string/jumbo v1, "oSumlttpbyo"

    const-string/jumbo v1, "looptbutayS"

    const/4 v4, 0x7

    const-string/jumbo v1, "oopyotuPStl"

    const-string v1, "StopPlayout"

    const/4 v4, 0x2

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x0

    shl-int/2addr v3, v1

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    move v0, v1

    move v0, v1

    move v0, v1

    move v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/voiceengine/NTAudioTrack$AudioTrackThread;->joinThread()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioThread:Lcom/voiceengine/NTAudioTrack$AudioTrackThread;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-eqz v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v2}, Landroid/media/AudioTrack;->release()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    return v1
.end method

.method static synthetic access$0(Lcom/voiceengine/NTAudioTrack;)Landroid/media/AudioTrack;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/voiceengine/NTAudioTrack;->audioTrack:Landroid/media/AudioTrack;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$1(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/voiceengine/NTAudioTrack;->assertTrue(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    return-void
.end method

.method static synthetic access$2(Lcom/voiceengine/NTAudioTrack;)Ljava/nio/ByteBuffer;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/voiceengine/NTAudioTrack;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$3(Lcom/voiceengine/NTAudioTrack;)J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/voiceengine/NTAudioTrack;->nativeAudioTrack:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-wide v0
.end method

.method static synthetic access$4(Lcom/voiceengine/NTAudioTrack;IJ)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/voiceengine/NTAudioTrack;->nativeGetPlayoutData(IJ)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-void
.end method

.method private static assertTrue(Z)V
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "uEtp bdxburie tecceotoenit do"

    const-string/jumbo v0, "oupeiduEe et xcnttbo cterdo i"

    const/4 v2, 0x4

    const-string v0, "cto c u ro iendenpttxEutbdoei"

    const-string v0, "Expected condition to be true"

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw p0
.end method

.method private native nativeCacheDirectBufferAddress(Ljava/nio/ByteBuffer;J)V
.end method

.method private native nativeGetPlayoutData(IJ)V
.end method


# virtual methods
.method public native executeMethod()V
.end method
