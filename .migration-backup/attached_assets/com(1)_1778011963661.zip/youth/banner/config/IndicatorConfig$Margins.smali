.class public Lcom/youth/banner/config/IndicatorConfig$Margins;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/youth/banner/config/IndicatorConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Margins"
.end annotation


# instance fields
.field public bottomMargin:I

.field public leftMargin:I

.field public rightMargin:I

.field public topMargin:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget v0, Lcom/youth/banner/config/BannerConfig;->INDICATOR_MARGIN:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Lcom/youth/banner/config/IndicatorConfig$Margins;-><init>(I)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    invoke-direct {p0, p1, p1, p1, p1}, Lcom/youth/banner/config/IndicatorConfig$Margins;-><init>(IIII)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig$Margins;->leftMargin:I

    const/4 v0, 0x4

    move v1, v0

    iput p2, p0, Lcom/youth/banner/config/IndicatorConfig$Margins;->topMargin:I

    const/4 v1, 0x4

    iput p3, p0, Lcom/youth/banner/config/IndicatorConfig$Margins;->rightMargin:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p4, p0, Lcom/youth/banner/config/IndicatorConfig$Margins;->bottomMargin:I

    const/4 v1, 0x3

    return-void
.end method
