.class public Lcom/youth/banner/config/IndicatorConfig;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/youth/banner/config/IndicatorConfig$Margins;,
        Lcom/youth/banner/config/IndicatorConfig$Direction;
    }
.end annotation


# instance fields
.field private attachToBanner:Z

.field private currentPosition:I

.field private gravity:I

.field private height:I

.field private indicatorSize:I

.field private indicatorSpace:I

.field private margins:Lcom/youth/banner/config/IndicatorConfig$Margins;

.field private normalColor:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private normalWidth:I

.field private radius:I

.field private selectedColor:I
    .annotation build Landroidx/annotation/l;
    .end annotation
.end field

.field private selectedWidth:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput v0, p0, Lcom/youth/banner/config/IndicatorConfig;->gravity:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_SPACE:I

    const/4 v3, 0x2

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->indicatorSpace:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_NORMAL_WIDTH:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->normalWidth:I

    sget v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_SELECTED_WIDTH:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->selectedWidth:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const v1, -0x77000001

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->normalColor:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/high16 v1, -0x78000000

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->selectedColor:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_RADIUS:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->radius:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_HEIGHT:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v1, p0, Lcom/youth/banner/config/IndicatorConfig;->height:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/youth/banner/config/IndicatorConfig;->attachToBanner:Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public getCurrentPosition()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/sf@@v@~~@sm@o@~r~@-~ d@ b ~~. @t/@~n~~1 o~  @~ Mi @o@uo@ ai~ @~K  otb4~~l~l @~ ~@S f@b~ co~@iy"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->currentPosition:I

    const/4 v2, 0x7

    return v0
.end method

.method public getGravity()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->gravity:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public getHeight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->height:I

    const/4 v2, 0x2

    return v0
.end method

.method public getIndicatorSize()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->indicatorSize:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public getIndicatorSpace()I
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->indicatorSpace:I

    const/4 v2, 0x2

    return v0
.end method

.method public getMargins()Lcom/youth/banner/config/IndicatorConfig$Margins;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/youth/banner/config/IndicatorConfig;->margins:Lcom/youth/banner/config/IndicatorConfig$Margins;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    new-instance v0, Lcom/youth/banner/config/IndicatorConfig$Margins;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/youth/banner/config/IndicatorConfig$Margins;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, v0}, Lcom/youth/banner/config/IndicatorConfig;->setMargins(Lcom/youth/banner/config/IndicatorConfig$Margins;)Lcom/youth/banner/config/IndicatorConfig;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/youth/banner/config/IndicatorConfig;->margins:Lcom/youth/banner/config/IndicatorConfig$Margins;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getNormalColor()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->normalColor:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    return v0
.end method

.method public getNormalWidth()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->normalWidth:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getRadius()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->radius:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    return v0
.end method

.method public getSelectedColor()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->selectedColor:I

    const/4 v2, 0x0

    return v0
.end method

.method public getSelectedWidth()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/youth/banner/config/IndicatorConfig;->selectedWidth:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public isAttachToBanner()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/youth/banner/config/IndicatorConfig;->attachToBanner:Z

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public setAttachToBanner(Z)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-boolean p1, p0, Lcom/youth/banner/config/IndicatorConfig;->attachToBanner:Z

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public setCurrentPosition(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->currentPosition:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public setGravity(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->gravity:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method public setHeight(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->height:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public setIndicatorSize(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->indicatorSize:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public setIndicatorSpace(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->indicatorSpace:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method public setMargins(Lcom/youth/banner/config/IndicatorConfig$Margins;)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/youth/banner/config/IndicatorConfig;->margins:Lcom/youth/banner/config/IndicatorConfig$Margins;

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public setNormalColor(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->normalColor:I

    const/4 v1, 0x3

    return-object p0
.end method

.method public setNormalWidth(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x7

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->normalWidth:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public setRadius(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->radius:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public setSelectedColor(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->selectedColor:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public setSelectedWidth(I)Lcom/youth/banner/config/IndicatorConfig;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lcom/youth/banner/config/IndicatorConfig;->selectedWidth:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method
