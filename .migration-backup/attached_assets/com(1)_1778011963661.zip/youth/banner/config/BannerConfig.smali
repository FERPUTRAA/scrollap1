.class public Lcom/youth/banner/config/BannerConfig;
.super Ljava/lang/Object;


# static fields
.field public static final INCREASE_COUNT:I = 0x2

.field public static final INDICATOR_HEIGHT:I

.field public static final INDICATOR_MARGIN:I

.field public static final INDICATOR_NORMAL_COLOR:I = -0x77000001

.field public static final INDICATOR_NORMAL_WIDTH:I

.field public static final INDICATOR_RADIUS:I

.field public static final INDICATOR_SELECTED_COLOR:I = -0x78000000

.field public static final INDICATOR_SELECTED_WIDTH:I

.field public static final INDICATOR_SPACE:I

.field public static final IS_AUTO_LOOP:Z = true

.field public static final IS_INFINITE_LOOP:Z = true

.field public static final LOOP_TIME:I = 0xbb8

.field public static final SCROLL_TIME:I = 0x258


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/high16 v0, 0x40a00000    # 5.0f

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/youth/banner/util/BannerUtils;->dp2px(F)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    sput v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_NORMAL_WIDTH:I

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    const/high16 v1, 0x40e00000    # 7.0f

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v1}, Lcom/youth/banner/util/BannerUtils;->dp2px(F)I

    move-result v1

    const/4 v2, 0x1

    move v3, v2

    sput v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_SELECTED_WIDTH:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/youth/banner/util/BannerUtils;->dp2px(F)I

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_SPACE:I

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/youth/banner/util/BannerUtils;->dp2px(F)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput v0, Lcom/youth/banner/config/BannerConfig;->INDICATOR_MARGIN:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/high16 v0, 0x40400000    # 3.0f

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v0}, Lcom/youth/banner/util/BannerUtils;->dp2px(F)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    sput v1, Lcom/youth/banner/config/BannerConfig;->INDICATOR_HEIGHT:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/youth/banner/util/BannerUtils;->dp2px(F)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    sput v0, Lcom/youth/banner/config/BannerConfig;->INDICATOR_RADIUS:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method
