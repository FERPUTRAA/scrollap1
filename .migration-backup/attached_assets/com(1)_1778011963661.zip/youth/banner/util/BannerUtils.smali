.class public Lcom/youth/banner/util/BannerUtils;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method public static dp2px(F)I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s@@ ~ ~@m~b@c@ul  .~o@4~Kb@ oSn f~~@~ ~os/@o~ M@@~~@li@b ~@~o@va i@  /otti@~@ 1~ ~ ~-fd~ r~~ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v1, p0, v0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    float-to-int p0, p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return p0
.end method

.method public static getRealPosition(ZII)I
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-nez p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return p1

    :cond_0
    if-nez p1, :cond_1

    const/4 v0, 0x5

    move v1, v0

    add-int/lit8 p2, p2, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    goto :goto_0

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    add-int/lit8 p2, p2, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-ne p1, p2, :cond_2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    goto :goto_0

    :cond_2
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    add-int/lit8 p2, p1, -0x1

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p2
.end method

.method public static getView(Landroid/view/ViewGroup;I)Landroid/view/View;
    .locals 4
    .param p0    # Landroid/view/ViewGroup;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p1    # I
        .annotation build Landroidx/annotation/j0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1, p0, v1}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v0, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v0, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    if-eq v0, v1, :cond_1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v1, p1, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput v1, p1, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object p0
.end method

.method public static setBannerRound(Landroid/view/View;F)V
    .locals 3
    .annotation build Landroidx/annotation/w0;
        api = 0x15
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/youth/banner/util/BannerUtils$1;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Lcom/youth/banner/util/BannerUtils$1;-><init>(F)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/view/View;->setOutlineProvider(Landroid/view/ViewOutlineProvider;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 p1, 0x1

    and-int/2addr v2, p1

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Landroid/view/View;->setClipToOutline(Z)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method
