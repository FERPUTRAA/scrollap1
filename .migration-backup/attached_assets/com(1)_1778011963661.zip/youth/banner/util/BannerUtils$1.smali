.class final Lcom/youth/banner/util/BannerUtils$1;
.super Landroid/view/ViewOutlineProvider;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/youth/banner/util/BannerUtils;->setBannerRound(Landroid/view/View;F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = null
.end annotation


# instance fields
.field final synthetic val$radius:F


# direct methods
.method constructor <init>(F)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/youth/banner/util/BannerUtils$1;->val$radius:F

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/view/ViewOutlineProvider;-><init>()V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public getOutline(Landroid/view/View;Landroid/graphics/Outline;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " @s~ ~~ fMS~o-o~ @~@o  l~b~rt@is  ~~~o~ @@@ 1i@o.b@@@ ~a/@i@ K~ ~nof/~@u~@tm@ b@~ @@~l~cy~@v~ 4d"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget v5, p0, Lcom/youth/banner/util/BannerUtils$1;->val$radius:F

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Outline;->setRoundRect(IIIIF)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void
.end method
