.class public Lcom/youth/banner/util/LogUtils;
.super Ljava/lang/Object;


# static fields
.field private static final DEBUG:Z = false

.field public static final TAG:Ljava/lang/String; = "banner_log"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method public static d(Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~sv@~@@y@tl~ mn~c1 o  b@K @u@~o@~@ar~  d~i~ ~ ~f~ ~o4 ~@s@i/of @~@@t-S@o @ l~.~~~~b @b@o @/ i@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    return-void
.end method

.method public static e(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public static i(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    return-void
.end method

.method public static v(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    return-void
.end method

.method public static w(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method
