.class public final Lcom/youth/banner/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/youth/banner/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final alpha:I = 0x7f040031

.field public static final banner_auto_loop:I = 0x7f04005e

.field public static final banner_indicator_gravity:I = 0x7f04005f

.field public static final banner_indicator_height:I = 0x7f040060

.field public static final banner_indicator_margin:I = 0x7f040061

.field public static final banner_indicator_marginBottom:I = 0x7f040062

.field public static final banner_indicator_marginLeft:I = 0x7f040063

.field public static final banner_indicator_marginRight:I = 0x7f040064

.field public static final banner_indicator_marginTop:I = 0x7f040065

.field public static final banner_indicator_normal_color:I = 0x7f040066

.field public static final banner_indicator_normal_width:I = 0x7f040067

.field public static final banner_indicator_radius:I = 0x7f040068

.field public static final banner_indicator_selected_color:I = 0x7f040069

.field public static final banner_indicator_selected_width:I = 0x7f04006a

.field public static final banner_indicator_space:I = 0x7f04006b

.field public static final banner_infinite_loop:I = 0x7f04006c

.field public static final banner_loop_time:I = 0x7f04006d

.field public static final banner_orientation:I = 0x7f04006e

.field public static final banner_radius:I = 0x7f04006f

.field public static final banner_round_bottom_left:I = 0x7f040070

.field public static final banner_round_bottom_right:I = 0x7f040071

.field public static final banner_round_top_left:I = 0x7f040072

.field public static final banner_round_top_right:I = 0x7f040073

.field public static final fastScrollEnabled:I = 0x7f0401e7

.field public static final fastScrollHorizontalThumbDrawable:I = 0x7f0401e8

.field public static final fastScrollHorizontalTrackDrawable:I = 0x7f0401e9

.field public static final fastScrollVerticalThumbDrawable:I = 0x7f0401ea

.field public static final fastScrollVerticalTrackDrawable:I = 0x7f0401eb

.field public static final font:I = 0x7f04020f

.field public static final fontProviderAuthority:I = 0x7f040211

.field public static final fontProviderCerts:I = 0x7f040212

.field public static final fontProviderFetchStrategy:I = 0x7f040213

.field public static final fontProviderFetchTimeout:I = 0x7f040214

.field public static final fontProviderPackage:I = 0x7f040215

.field public static final fontProviderQuery:I = 0x7f040216

.field public static final fontStyle:I = 0x7f040218

.field public static final fontVariationSettings:I = 0x7f040219

.field public static final fontWeight:I = 0x7f04021a

.field public static final layoutManager:I = 0x7f040298

.field public static final normal_drawable:I = 0x7f04037f

.field public static final recyclerViewStyle:I = 0x7f040407

.field public static final reverseLayout:I = 0x7f04040e

.field public static final selected_drawable:I = 0x7f04042d

.field public static final spanCount:I = 0x7f04045c

.field public static final stackFromEnd:I = 0x7f0404a6

.field public static final ttcIndex:I = 0x7f04057d


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method
