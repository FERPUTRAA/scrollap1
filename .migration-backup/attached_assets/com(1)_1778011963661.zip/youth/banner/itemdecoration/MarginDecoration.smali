.class public Lcom/youth/banner/itemdecoration/MarginDecoration;
.super Landroidx/recyclerview/widget/RecyclerView$o;


# instance fields
.field private mMarginPx:I


# direct methods
.method public constructor <init>(I)V
    .locals 2
    .param p1    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView$o;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p1, p0, Lcom/youth/banner/itemdecoration/MarginDecoration;->mMarginPx:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private requireLinearLayoutManager(Landroidx/recyclerview/widget/RecyclerView;)Landroidx/recyclerview/widget/LinearLayoutManager;
    .locals 3
    .param p1    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s~s@ @f@@y ou @~~~K~ @1~ f.@ id ~r@ ~4/~M~  t~b ~o ~o@oimc @l@vi -@@~ b@~l~/~~~no @@@ @Stoab~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p1}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Landroidx/recyclerview/widget/RecyclerView$p;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    instance-of v0, p1, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p1, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const-string/jumbo v0, "s nmhg aataytuToi n ybLeMresaeuutalerrnLageam"

    const-string v0, "Ttsrnleee nooginarLtsa  u LyeruatauMgabehmaya"

    const/4 v2, 0x4

    const-string v0, "aau oheetoemganaae nlTLteLrutusirM nayMrb yga"

    const-string v0, "The layoutManager must be LinearLayoutManager"

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    throw p1
.end method


# virtual methods
.method public getItemOffsets(Landroid/graphics/Rect;Landroid/view/View;Landroidx/recyclerview/widget/RecyclerView;Landroidx/recyclerview/widget/RecyclerView$c0;)V
    .locals 2
    .param p1    # Landroid/graphics/Rect;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Landroidx/recyclerview/widget/RecyclerView;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p4    # Landroidx/recyclerview/widget/RecyclerView$c0;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p3}, Lcom/youth/banner/itemdecoration/MarginDecoration;->requireLinearLayoutManager(Landroidx/recyclerview/widget/RecyclerView;)Landroidx/recyclerview/widget/LinearLayoutManager;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-virtual {p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->getOrientation()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    const/4 p3, 0x1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    if-ne p2, p3, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget p2, p0, Lcom/youth/banner/itemdecoration/MarginDecoration;->mMarginPx:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p2, p1, Landroid/graphics/Rect;->top:I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p2, p1, Landroid/graphics/Rect;->bottom:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iget p2, p0, Lcom/youth/banner/itemdecoration/MarginDecoration;->mMarginPx:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p2, p1, Landroid/graphics/Rect;->left:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p1, Landroid/graphics/Rect;->right:I

    :goto_0
    const/4 v1, 0x3

    return-void
.end method
