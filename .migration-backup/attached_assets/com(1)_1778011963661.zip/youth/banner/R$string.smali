.class public final Lcom/youth/banner/R$string;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/youth/banner/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final banner_adapter_null_error:I = 0x7f11047b

.field public static final indicator_color_error:I = 0x7f11070f

.field public static final status_bar_notification_info_overflow:I = 0x7f110a56


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
