.class public final Lcom/youth/banner/R$dimen;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/youth/banner/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final compat_button_inset_horizontal_material:I = 0x7f070063

.field public static final compat_button_inset_vertical_material:I = 0x7f070064

.field public static final compat_button_padding_horizontal_material:I = 0x7f070065

.field public static final compat_button_padding_vertical_material:I = 0x7f070066

.field public static final compat_control_corner_material:I = 0x7f070067

.field public static final compat_notification_large_icon_max_height:I = 0x7f070068

.field public static final compat_notification_large_icon_max_width:I = 0x7f070069

.field public static final fastscroll_default_thickness:I = 0x7f070225

.field public static final fastscroll_margin:I = 0x7f070226

.field public static final fastscroll_minimum_range:I = 0x7f070227

.field public static final item_touch_helper_max_drag_scroll_per_frame:I = 0x7f07022f

.field public static final item_touch_helper_swipe_escape_max_velocity:I = 0x7f070230

.field public static final item_touch_helper_swipe_escape_velocity:I = 0x7f070231

.field public static final notification_action_icon_size:I = 0x7f0703bf

.field public static final notification_action_text_size:I = 0x7f0703c0

.field public static final notification_big_circle_margin:I = 0x7f0703c1

.field public static final notification_content_margin_start:I = 0x7f0703c2

.field public static final notification_large_icon_height:I = 0x7f0703c3

.field public static final notification_large_icon_width:I = 0x7f0703c4

.field public static final notification_main_column_padding_top:I = 0x7f0703c5

.field public static final notification_media_narrow_margin:I = 0x7f0703c6

.field public static final notification_right_icon_size:I = 0x7f0703c7

.field public static final notification_right_side_padding_top:I = 0x7f0703c8

.field public static final notification_small_icon_background_padding:I = 0x7f0703c9

.field public static final notification_small_icon_size_as_large:I = 0x7f0703ca

.field public static final notification_subtext_size:I = 0x7f0703cb

.field public static final notification_top_pad:I = 0x7f0703cc

.field public static final notification_top_pad_large_text:I = 0x7f0703cd


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
