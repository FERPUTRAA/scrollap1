.class public interface abstract Lcom/youth/banner/listener/OnPageChangeListener;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onPageScrollStateChanged(I)V
.end method

.method public abstract onPageScrolled(IFI)V
    .param p3    # I
        .annotation build Landroidx/annotation/u0;
        .end annotation
    .end param
.end method

.method public abstract onPageSelected(I)V
.end method
