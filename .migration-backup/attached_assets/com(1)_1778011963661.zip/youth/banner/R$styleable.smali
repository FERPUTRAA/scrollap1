.class public final Lcom/youth/banner/R$styleable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/youth/banner/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static final Banner:[I

.field public static final Banner_banner_auto_loop:I = 0x0

.field public static final Banner_banner_indicator_gravity:I = 0x1

.field public static final Banner_banner_indicator_height:I = 0x2

.field public static final Banner_banner_indicator_margin:I = 0x3

.field public static final Banner_banner_indicator_marginBottom:I = 0x4

.field public static final Banner_banner_indicator_marginLeft:I = 0x5

.field public static final Banner_banner_indicator_marginRight:I = 0x6

.field public static final Banner_banner_indicator_marginTop:I = 0x7

.field public static final Banner_banner_indicator_normal_color:I = 0x8

.field public static final Banner_banner_indicator_normal_width:I = 0x9

.field public static final Banner_banner_indicator_radius:I = 0xa

.field public static final Banner_banner_indicator_selected_color:I = 0xb

.field public static final Banner_banner_indicator_selected_width:I = 0xc

.field public static final Banner_banner_indicator_space:I = 0xd

.field public static final Banner_banner_infinite_loop:I = 0xe

.field public static final Banner_banner_loop_time:I = 0xf

.field public static final Banner_banner_orientation:I = 0x10

.field public static final Banner_banner_radius:I = 0x11

.field public static final Banner_banner_round_bottom_left:I = 0x12

.field public static final Banner_banner_round_bottom_right:I = 0x13

.field public static final Banner_banner_round_top_left:I = 0x14

.field public static final Banner_banner_round_top_right:I = 0x15

.field public static final ColorStateListItem:[I

.field public static final ColorStateListItem_alpha:I = 0x3

.field public static final ColorStateListItem_android_alpha:I = 0x1

.field public static final ColorStateListItem_android_color:I = 0x0

.field public static final ColorStateListItem_android_lStar:I = 0x2

.field public static final ColorStateListItem_lStar:I = 0x4

.field public static final DrawableIndicator:[I

.field public static final DrawableIndicator_normal_drawable:I = 0x0

.field public static final DrawableIndicator_selected_drawable:I = 0x1

.field public static final FontFamily:[I

.field public static final FontFamilyFont:[I

.field public static final FontFamilyFont_android_font:I = 0x0

.field public static final FontFamilyFont_android_fontStyle:I = 0x2

.field public static final FontFamilyFont_android_fontVariationSettings:I = 0x4

.field public static final FontFamilyFont_android_fontWeight:I = 0x1

.field public static final FontFamilyFont_android_ttcIndex:I = 0x3

.field public static final FontFamilyFont_font:I = 0x5

.field public static final FontFamilyFont_fontStyle:I = 0x6

.field public static final FontFamilyFont_fontVariationSettings:I = 0x7

.field public static final FontFamilyFont_fontWeight:I = 0x8

.field public static final FontFamilyFont_ttcIndex:I = 0x9

.field public static final FontFamily_fontProviderAuthority:I = 0x0

.field public static final FontFamily_fontProviderCerts:I = 0x1

.field public static final FontFamily_fontProviderFetchStrategy:I = 0x2

.field public static final FontFamily_fontProviderFetchTimeout:I = 0x3

.field public static final FontFamily_fontProviderPackage:I = 0x4

.field public static final FontFamily_fontProviderQuery:I = 0x5

.field public static final FontFamily_fontProviderSystemFontFamily:I = 0x6

.field public static final GradientColor:[I

.field public static final GradientColorItem:[I

.field public static final GradientColorItem_android_color:I = 0x0

.field public static final GradientColorItem_android_offset:I = 0x1

.field public static final GradientColor_android_centerColor:I = 0x7

.field public static final GradientColor_android_centerX:I = 0x3

.field public static final GradientColor_android_centerY:I = 0x4

.field public static final GradientColor_android_endColor:I = 0x1

.field public static final GradientColor_android_endX:I = 0xa

.field public static final GradientColor_android_endY:I = 0xb

.field public static final GradientColor_android_gradientRadius:I = 0x5

.field public static final GradientColor_android_startColor:I = 0x0

.field public static final GradientColor_android_startX:I = 0x8

.field public static final GradientColor_android_startY:I = 0x9

.field public static final GradientColor_android_tileMode:I = 0x6

.field public static final GradientColor_android_type:I = 0x2

.field public static final RecyclerView:[I

.field public static final RecyclerView_android_clipToPadding:I = 0x1

.field public static final RecyclerView_android_descendantFocusability:I = 0x2

.field public static final RecyclerView_android_orientation:I = 0x0

.field public static final RecyclerView_fastScrollEnabled:I = 0x3

.field public static final RecyclerView_fastScrollHorizontalThumbDrawable:I = 0x4

.field public static final RecyclerView_fastScrollHorizontalTrackDrawable:I = 0x5

.field public static final RecyclerView_fastScrollVerticalThumbDrawable:I = 0x6

.field public static final RecyclerView_fastScrollVerticalTrackDrawable:I = 0x7

.field public static final RecyclerView_layoutManager:I = 0x8

.field public static final RecyclerView_reverseLayout:I = 0x9

.field public static final RecyclerView_spanCount:I = 0xa

.field public static final RecyclerView_stackFromEnd:I = 0xb

.field public static final ViewPager2:[I

.field public static final ViewPager2_android_orientation:I


# direct methods
.method public static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/16 v0, 0x16

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-array v0, v0, [I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    fill-array-data v0, :array_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    sput-object v0, Lcom/youth/banner/R$styleable;->Banner:[I

    const/4 v6, 0x5

    const v0, 0x7f040031

    const/4 v6, 0x4

    const v1, 0x7f04028e

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const v2, 0x10101a5

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    const v3, 0x101031f

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const v4, 0x1010647

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    filled-new-array {v2, v3, v4, v0, v1}, [I

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    sput-object v0, Lcom/youth/banner/R$styleable;->ColorStateListItem:[I

    const/4 v6, 0x6

    const v0, 0x7f04037f

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const v1, 0x7f04042d

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    filled-new-array {v0, v1}, [I

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    sput-object v0, Lcom/youth/banner/R$styleable;->DrawableIndicator:[I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v0, 0x7

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-array v0, v0, [I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    fill-array-data v0, :array_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    sput-object v0, Lcom/youth/banner/R$styleable;->FontFamily:[I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/16 v0, 0xa

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-array v0, v0, [I

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    fill-array-data v0, :array_2

    const/4 v6, 0x6

    sput-object v0, Lcom/youth/banner/R$styleable;->FontFamilyFont:[I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/16 v0, 0xc

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-array v1, v0, [I

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    fill-array-data v1, :array_3

    const/4 v6, 0x4

    sput-object v1, Lcom/youth/banner/R$styleable;->GradientColor:[I

    const v1, 0x1010514

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    filled-new-array {v2, v1}, [I

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    sput-object v1, Lcom/youth/banner/R$styleable;->GradientColorItem:[I

    const/4 v6, 0x3

    const/4 v5, 0x2

    new-array v0, v0, [I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    fill-array-data v0, :array_4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    sput-object v0, Lcom/youth/banner/R$styleable;->RecyclerView:[I

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const v0, 0x10100c4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    sput-object v0, Lcom/youth/banner/R$styleable;->ViewPager2:[I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-void

    nop

    :array_0
    .array-data 4
        0x7f04005e
        0x7f04005f
        0x7f040060
        0x7f040061
        0x7f040062
        0x7f040063
        0x7f040064
        0x7f040065
        0x7f040066
        0x7f040067
        0x7f040068
        0x7f040069
        0x7f04006a
        0x7f04006b
        0x7f04006c
        0x7f04006d
        0x7f04006e
        0x7f04006f
        0x7f040070
        0x7f040071
        0x7f040072
        0x7f040073
    .end array-data

    :array_1
    .array-data 4
        0x7f040211
        0x7f040212
        0x7f040213
        0x7f040214
        0x7f040215
        0x7f040216
        0x7f040217
    .end array-data

    :array_2
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f04020f
        0x7f040218
        0x7f040219
        0x7f04021a
        0x7f04057d
    .end array-data

    :array_3
    .array-data 4
        0x101019d
        0x101019e
        0x10101a1
        0x10101a2
        0x10101a3
        0x10101a4
        0x1010201
        0x101020b
        0x1010510
        0x1010511
        0x1010512
        0x1010513
    .end array-data

    :array_4
    .array-data 4
        0x10100c4
        0x10100eb
        0x10100f1
        0x7f0401e7
        0x7f0401e8
        0x7f0401e9
        0x7f0401ea
        0x7f0401eb
        0x7f040298
        0x7f04040e
        0x7f04045c
        0x7f0404a6
    .end array-data
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method
