.class public abstract Lcom/zego/ve/IHwAudioEngine$Stub;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/zego/ve/IHwAudioEngine;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/IHwAudioEngine;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;
    }
.end annotation


# static fields
.field static final TRANSACTION_getSupportedFeatures:I = 0x1

.field static final TRANSACTION_init:I = 0x3

.field static final TRANSACTION_isFeatureSupported:I = 0x2


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string/jumbo v0, "g.sHii.iIuucigoemeAadaesouwdmdilnauhtwinn..mEiee"

    const-string v0, "aisl.unuieAeowngimdnwi.n.dEeHihgcam.Iduuiaeetomi"

    const/4 v2, 0x7

    const-string/jumbo v0, "ouimoediiun.miwedgEe.nenue.lnhAuciHmawiaato.mIid"

    const-string v0, "com.huawei.multimedia.audioengine.IHwAudioEngine"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Lcom/zego/ve/IHwAudioEngine;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@/@~oc@~i~@bo~tb@4 tMo@ ~ . @~ @i~  @@l  @@  ~@~~v~@-fa  i~@~os @do~@@@/~rou1f@ ~S m~n y~o~Kl~b~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const-string/jumbo v0, "lneombteaeo.i..wieiuuoHdcgeuiuwigEnmmndah.dImnia"

    const-string/jumbo v0, "naomieudHceAhomumd.euingiie.uilmIagnadowwe.nEt.i"

    const/4 v3, 0x2

    const-string/jumbo v0, "uenHmiuicuhnIoAnolddE.eta..oemeiiawniegi.uawmigu"

    const-string v0, "com.huawei.multimedia.audioengine.IHwAudioEngine"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    instance-of v1, v0, Lcom/zego/ve/IHwAudioEngine;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v0, Lcom/zego/ve/IHwAudioEngine;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/zego/ve/IHwAudioEngine$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    :goto_0
    const/4 v3, 0x6

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v3, 0x6

    const-string/jumbo v0, "iduieuopwio.cegotneanoAi.eImgmiHhi.Ewd.eiunuamal"

    const-string v0, "cuihoaAein.g.ueeniiIeewowiultaHn.damimog.dimodEu"

    const/4 v4, 0x7

    const-string v0, "ei.dmumoqaanidHetduingumin.cioweniaow.EiAIgel.uh"

    const-string v0, "com.huawei.multimedia.audioengine.IHwAudioEngine"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x1

    or-int/2addr v4, v1

    if-eq p1, v1, :cond_3

    const/4 v4, 0x6

    const/4 v2, 0x2

    const/4 v4, 0x6

    move v3, v2

    move v3, v2

    const/4 v4, 0x3

    if-eq p1, v2, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eq p1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const v2, 0x5f4e5446

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eq p1, v2, :cond_0

    const/4 v4, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    return p1

    :cond_0
    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p3, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    return v1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-interface {p0, p1, p2}, Lcom/zego/ve/IHwAudioEngine;->init(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    return v1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {p0, p1}, Lcom/zego/ve/IHwAudioEngine;->isFeatureSupported(I)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    return v1

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p2, v0}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p0}, Lcom/zego/ve/IHwAudioEngine;->getSupportedFeatures()Ljava/util/List;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p3, p1}, Landroid/os/Parcel;->writeList(Ljava/util/List;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1
.end method
