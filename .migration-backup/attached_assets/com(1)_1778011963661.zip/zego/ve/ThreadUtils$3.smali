.class Lcom/zego/ve/ThreadUtils$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/ThreadUtils;->invokeUninterruptibly(Landroid/os/Handler;Ljava/util/concurrent/Callable;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$barrier:Ljava/util/concurrent/CountDownLatch;

.field final synthetic val$callable:Ljava/util/concurrent/Callable;

.field final synthetic val$result:Lcom/zego/ve/ThreadUtils$1Result;


# direct methods
.method constructor <init>(Lcom/zego/ve/ThreadUtils$1Result;Ljava/util/concurrent/Callable;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/ve/ThreadUtils$3;->val$result:Lcom/zego/ve/ThreadUtils$1Result;

    const/4 v1, 0x4

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/zego/ve/ThreadUtils$3;->val$callable:Ljava/util/concurrent/Callable;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/zego/ve/ThreadUtils$3;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s ~@@t@y@@b@c~rM@@ / ~~~v/ @~~ lt ~ @an~@4@~uf@~oli oobfo ~ .  ~~~o@~ ~@s@~1@ iS ~-Ki@do@b@~m "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/ve/ThreadUtils$3;->val$result:Lcom/zego/ve/ThreadUtils$1Result;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/zego/ve/ThreadUtils$3;->val$callable:Ljava/util/concurrent/Callable;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/concurrent/Callable;->call()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v1, v0, Lcom/zego/ve/ThreadUtils$1Result;->value:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/zego/ve/ThreadUtils$3;->val$barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    :catch_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v3, "rtemlhnseolel tw ibpx: eCa"

    const-string v3, "Cxs le who bpntciear:lleet"

    const/4 v5, 0x4

    const-string v3, " :ewoli lcphteorlexnaCa te"

    const-string v3, "Callable threw exception: "

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->setStackTrace([Ljava/lang/StackTraceElement;)V

    const/4 v4, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw v1
.end method
