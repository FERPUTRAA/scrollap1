.class Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/HwAudioKaraokeFeatureKit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;


# direct methods
.method constructor <init>(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v0, 0x0

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public binderDied()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ sr~@ 4@ov~-o~ /~~@~a@~ ~  ~b~@o@~@ @fdM~l~ tu.f~yt~nK@    o  i@~o~@ @i@o @@b~ c@~S~m@l@@/1i@~s"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$700(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Landroid/os/IBinder;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$600(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Landroid/os/IBinder$DeathRecipient;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0, v1, v2}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$400(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/16 v1, 0x3eb

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$2;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$702(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Landroid/os/IBinder;)Landroid/os/IBinder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method
