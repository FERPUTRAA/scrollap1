.class Lcom/zego/ve/HwAudioKit$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/IBinder$DeathRecipient;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/HwAudioKit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/HwAudioKit;


# direct methods
.method constructor <init>(Lcom/zego/ve/HwAudioKit;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit$2;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public binderDied()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@os@o~lm @S b tr@ ~@bb~~@v~l/ ~d @K~o~~of1~sM @.~@ -y~~@i@ ~@~~@~ u@4 t~ o @ani @ @ i@@ ~~~oc@~f"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit$2;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/zego/ve/HwAudioKit;->access$700(Lcom/zego/ve/HwAudioKit;)Landroid/os/IBinder;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/zego/ve/HwAudioKit$2;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/zego/ve/HwAudioKit;->access$600(Lcom/zego/ve/HwAudioKit;)Landroid/os/IBinder$DeathRecipient;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Landroid/os/IBinder;->unlinkToDeath(Landroid/os/IBinder$DeathRecipient;I)Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit$2;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/zego/ve/HwAudioKit;->access$200(Lcom/zego/ve/HwAudioKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit$2;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/zego/ve/HwAudioKit;->access$702(Lcom/zego/ve/HwAudioKit;Landroid/os/IBinder;)Landroid/os/IBinder;

    const/4 v4, 0x1

    return-void
.end method
