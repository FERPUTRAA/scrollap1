.class Lcom/zego/ve/VCam$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/zego/ve/CameraAvailabilityCallback$Listener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/VCam;->registerCameraAvailabilityCallback(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/VCam;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onCameraAvailable(JLjava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "f~s~t/.l   M ~ ~fso @ di@@~u@@b~@Koc@@b@y~~@@~  ~@ av~@ii -/ ~~o~@o~~lnr1@St ~ob@@~ ~@@~4  @o~ m"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "iutmors rtinets pt:ecianr"

    const-string/jumbo v1, "t spihra to:ierntcurstnie"

    const/4 v3, 0x3

    const-string/jumbo v1, "ineeon ptttur as:cihr oti"

    const-string/jumbo v1, "trace interruption this: "

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, " a,eIbm:cdr "

    const-string v1, "a :m,dmeIc r"

    const/4 v3, 0x0

    const-string v1, " d,Imeura:c "

    const-string v1, ", cameraId: "

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    or-int/2addr v3, v2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "saeUeolplaaC,ema:dIair vmb"

    const-string v1, "Cvr:omlasidaa,bIemlUe  aea"

    const/4 v3, 0x2

    const-string v1, "ai e I ,qlav:ademseblramCU"

    const-string v1, " available, mUseCameraId: "

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, v1, Lcom/zego/ve/VCam;->mUseCameraId:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v1, "cpav"

    const-string/jumbo v1, "pcva"

    const/4 v3, 0x4

    const-string v1, "apcv"

    const-string/jumbo v1, "vcap"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, p3}, Lcom/zego/ve/VCam;->access$000(Lcom/zego/ve/VCam;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    invoke-static {p3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p3

    const/4 v3, 0x2

    invoke-static {p1, p2, p3}, Lcom/zego/ve/VCam;->access$100(JI)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p3, -0x1

    invoke-static {p1, p2, p3}, Lcom/zego/ve/VCam;->access$100(JI)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public onCameraUnavailable(JLjava/lang/String;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, "absrt t sprhunnroecii t:e"

    const-string v1, " cip batrn:thsin rtoeuter"

    const/4 v3, 0x6

    const-string/jumbo v1, "tromtprti  reiuh:ten snca"

    const-string/jumbo v1, "trace interruption this: "

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v1, "r m o:ueaaI,"

    const-string v1, " :I, durmaae"

    const/4 v3, 0x0

    const-string/jumbo v1, "r: adbm,aIe "

    const-string v1, ", cameraId: "

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string v1, "avau,muaUbC: d  aepnelmiaeIl"

    const-string v1, "eI:aslapCaaavde en mmUuil b,"

    const/4 v3, 0x0

    const-string v1, "Ievismrpmellabad, aaa enUu C"

    const-string v1, " unavailable, mUseCameraId: "

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v1, v1, Lcom/zego/ve/VCam;->mUseCameraId:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "vapc"

    const-string/jumbo v1, "vcap"

    const/4 v3, 0x4

    const/4 v2, 0x3

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/VCam$1;->this$0:Lcom/zego/ve/VCam;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, p3}, Lcom/zego/ve/VCam;->access$000(Lcom/zego/ve/VCam;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p3

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p1, p2, p3}, Lcom/zego/ve/VCam;->access$200(JI)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p3, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p1, p2, p3}, Lcom/zego/ve/VCam;->access$200(JI)V

    :goto_0
    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method
