.class public Lcom/zego/ve/ThreadUtils$ThreadChecker;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/ThreadUtils;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ThreadChecker"
.end annotation


# instance fields
.field private thread:Ljava/lang/Thread;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/zego/ve/ThreadUtils$ThreadChecker;->thread:Ljava/lang/Thread;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public checkIsOnValidThread()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " os  aSKb~~1@t~~ b@@ ~@ @./ ~~~i4nf~@@m~@~  ~o @ot@r~~ ~o~ @~cs@f o@@ l d@@@ vM@i~@ ~lou~~yi/@b~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/ThreadUtils$ThreadChecker;->thread:Ljava/lang/Thread;

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/zego/ve/ThreadUtils$ThreadChecker;->thread:Ljava/lang/Thread;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/zego/ve/ThreadUtils$ThreadChecker;->thread:Ljava/lang/Thread;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v1, "oagmnhtrs rd"

    const-string v1, "a sdgrrtnWoh"

    const-string v1, "Wrong thread"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    throw v0
.end method

.method public detachThread()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/zego/ve/ThreadUtils$ThreadChecker;->thread:Ljava/lang/Thread;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
