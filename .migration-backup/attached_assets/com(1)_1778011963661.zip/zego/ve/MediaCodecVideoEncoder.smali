.class public Lcom/zego/ve/MediaCodecVideoEncoder;
.super Landroid/media/MediaCodec$Callback;


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "NewApi"
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;,
        Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;,
        Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;,
        Lcom/zego/ve/MediaCodecVideoEncoder$VImage;,
        Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;,
        Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;,
        Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;
    }
.end annotation


# static fields
.field private static final BITRATE_CORRECTION_MAX_SCALE:D = 2.0

.field private static final BITRATE_CORRECTION_SEC:D = 3.0

.field private static final BITRATE_CORRECTION_STEPS:I = 0xa

.field private static final COLOR_FormatYUV420Flexible:I = 0x7f420888

.field private static final COLOR_QCOM_FORMATYUV420PackedSemiPlanar32m:I = 0x7fa30c04

.field private static final DEQUEUE_TIMEOUT:I = 0x0

.field private static final H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

.field private static final H264_MIME_TYPE:Ljava/lang/String; = "video/avc"

.field private static final H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

.field private static final HEVC_MIME_TYPE:Ljava/lang/String; = "video/hevc"

.field private static final HW_BLACKLISTS:[Ljava/lang/String;

.field private static final MAXIMUM_INITIAL_FPS:I = 0x3c

.field private static final MEDIA_CODEC_RELEASE_TIMEOUT_MS:I = 0x1388

.field private static final TAG:Ljava/lang/String; = "MediaCodecVideoEncoder"

.field private static final VIDEO_ControlRateCQ:I = 0x0

.field private static final VIDEO_ControlRateConstant:I = 0x2

.field private static final VIDEO_ControlRateVariable:I = 0x1

.field private static final VP8_MIME_TYPE:Ljava/lang/String; = "video/x-vnd.on2.vp8"

.field private static final VP9_MIME_TYPE:Ljava/lang/String; = "video/x-vnd.on2.vp9"

.field private static final amlogicH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static codecErrors:I

.field private static enableWhitelist:Z

.field private static errorCallback:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

.field private static final exynosH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final exynosHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final exynosVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final freescaleH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final h264HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final hevcHwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static hwEncoderDisabledTypes:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static final intelH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final intelVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final kirin960H264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final kirin960HEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final kirinH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final kirinHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final mstarH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final mtkH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final mtkHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final nvidiaH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final qcomH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final qcomHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final qcomVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final rkH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static runningInstance:Lcom/zego/ve/MediaCodecVideoEncoder;

.field private static final sprdH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final supportedColorList:[I

.field private static final supportedSurfaceColorList:[I

.field private static final tiH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final vp8HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

.field private static final winnerH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;


# instance fields
.field private bitrateAccumulator:D

.field private bitrateAccumulatorMax:D

.field private bitrateAdjustmentScaleExp:I

.field private bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

.field private bitrateObservationTimeMs:D

.field private cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

.field private colorFormat:I

.field private configData:Ljava/nio/ByteBuffer;

.field private forcedKeyFrameMs:J

.field private height:I

.field private inputBuffers:[Ljava/nio/ByteBuffer;

.field private inputSurface:Landroid/view/Surface;

.field private isRunning:Z

.field private lastKeyFrameMs:J

.field private mediaCodec:Landroid/media/MediaCodec;

.field private mediaCodecThread:Ljava/lang/Thread;

.field private originFps:I

.field private outputBuffers:[Ljava/nio/ByteBuffer;

.field private pthis:J

.field private sliceHeight:I

.field private stride:I

.field private targetBitrateBps:I

.field private targetFps:I

.field private type:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

.field private width:I


# direct methods
.method static constructor <clinit>()V
    .locals 24

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    sget-object v1, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const-string v2, ".msos.XcO"

    const-string/jumbo v2, "m.sOcXoq."

    const-string v2, "XO.mMq.mo"

    const-string v2, "OMX.qcom."

    const/16 v3, 0x13

    invoke-direct {v0, v2, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->qcomVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v4, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/16 v5, 0x17

    const-string v6, "Oy..onXxMsm"

    const-string/jumbo v6, "oysm.xn.XOM"

    const-string/jumbo v6, "onsE.b.XOMy"

    const-string v6, "OMX.Exynos."

    invoke-direct {v4, v6, v5, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v4, Lcom/zego/ve/MediaCodecVideoEncoder;->exynosVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v5, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string/jumbo v7, "tn.lo.eMOX"

    const-string v7, "OelMn.uIXt"

    const-string v7, "OMX.Intel."

    const/16 v8, 0x15

    invoke-direct {v5, v7, v8, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v5, Lcom/zego/ve/MediaCodecVideoEncoder;->intelVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v9, 0x3

    new-array v10, v9, [Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v11, 0x0

    aput-object v0, v10, v11

    const/4 v0, 0x1

    aput-object v4, v10, v0

    const/4 v4, 0x2

    aput-object v5, v10, v4

    sput-object v10, Lcom/zego/ve/MediaCodecVideoEncoder;->vp8HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v5, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    invoke-direct {v5, v2, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v5, Lcom/zego/ve/MediaCodecVideoEncoder;->qcomH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v10, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    invoke-direct {v10, v6, v8, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v10, Lcom/zego/ve/MediaCodecVideoEncoder;->exynosH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v12, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string v13, ".TMOX.bp"

    const-string v13, "XOMTMb.."

    const-string/jumbo v13, "qOMXKT.."

    const-string v13, "OMX.MTK."

    invoke-direct {v12, v13, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v12, Lcom/zego/ve/MediaCodecVideoEncoder;->mtkH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v14, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string v15, ".Ms.GOuI"

    const-string v15, "..IMGMuO"

    const-string v15, "IGOm.MXM"

    const-string v15, "OMX.IMG."

    invoke-direct {v14, v15, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v14, Lcom/zego/ve/MediaCodecVideoEncoder;->kirinH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v8, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string v9, "MrOpoXk"

    const-string/jumbo v9, "pkXMO.r"

    const-string v9, ".kM.ObX"

    const-string v9, "OMX.rk."

    invoke-direct {v8, v9, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v8, Lcom/zego/ve/MediaCodecVideoEncoder;->rkH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v9, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string v4, "OiX.Mquhi"

    const-string v4, ".OXiiM.hq"

    const-string/jumbo v4, "isOh..MpX"

    const-string v4, "OMX.hisi."

    invoke-direct {v9, v4, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v9, Lcom/zego/ve/MediaCodecVideoEncoder;->kirin960H264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string v11, "Ma.wleXnqrnils"

    const-string v11, "Mis.enlnlaX.rw"

    const-string/jumbo v11, "nisnMl.ewO.arl"

    const-string v11, "OMX.allwinner."

    invoke-direct {v0, v11, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->winnerH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v11, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v18, v6

    move-object/from16 v18, v6

    move-object/from16 v18, v6

    move-object/from16 v18, v6

    const-string v6, ".XTmm.O"

    const-string v6, "TXOmM.."

    const-string v6, "OXT.o.M"

    const-string v6, "OMX.TI."

    invoke-direct {v11, v6, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v11, Lcom/zego/ve/MediaCodecVideoEncoder;->tiH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v6, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v19, v13

    move-object/from16 v19, v13

    move-object/from16 v19, v13

    const-string v13, ".o.MObS"

    const-string v13, "O.XSoM."

    const-string v13, "..OMSMu"

    const-string v13, "OMX.MS."

    invoke-direct {v6, v13, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v6, Lcom/zego/ve/MediaCodecVideoEncoder;->mstarH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v13, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v20, v15

    move-object/from16 v20, v15

    move-object/from16 v20, v15

    move-object/from16 v20, v15

    const-string v15, "OasebclpXMreFe"

    const-string/jumbo v15, "sereabMecF.lOX"

    const-string/jumbo v15, "la.eXesMqOFecr"

    const-string v15, "OMX.Freescale."

    invoke-direct {v13, v15, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v13, Lcom/zego/ve/MediaCodecVideoEncoder;->freescaleH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v15, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v21, v4

    move-object/from16 v21, v4

    const-string/jumbo v4, "pMsO.dsuX"

    const-string v4, ".sdMXpu.O"

    const-string v4, "OMX.sprd."

    invoke-direct {v15, v4, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v15, Lcom/zego/ve/MediaCodecVideoEncoder;->sprdH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v4, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v22, v2

    move-object/from16 v22, v2

    move-object/from16 v22, v2

    move-object/from16 v22, v2

    const-string/jumbo v2, "opimO.gMXcl."

    const-string v2, "XMmO.cipg.ol"

    const-string v2, ".g.lociMaOXo"

    const-string v2, "OMX.amlogic."

    invoke-direct {v4, v2, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v4, Lcom/zego/ve/MediaCodecVideoEncoder;->amlogicH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v2, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    invoke-direct {v2, v7, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v2, Lcom/zego/ve/MediaCodecVideoEncoder;->intelH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v7, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    const-string v4, "XONvibaMi.."

    const-string/jumbo v4, "vOXN.a.iqMi"

    const-string v4, "di.OiXu.vaM"

    const-string v4, "OMX.Nvidia."

    invoke-direct {v7, v4, v3, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v7, Lcom/zego/ve/MediaCodecVideoEncoder;->nvidiaH264HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/16 v3, 0xe

    new-array v3, v3, [Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v4, 0x0

    aput-object v5, v3, v4

    const/4 v4, 0x1

    aput-object v10, v3, v4

    const/4 v4, 0x2

    aput-object v12, v3, v4

    const/4 v4, 0x3

    aput-object v14, v3, v4

    const/4 v4, 0x4

    aput-object v9, v3, v4

    const/4 v5, 0x5

    aput-object v11, v3, v5

    const/4 v9, 0x6

    aput-object v2, v3, v9

    const/4 v2, 0x7

    aput-object v7, v3, v2

    const/16 v2, 0x8

    aput-object v8, v3, v2

    const/16 v7, 0x9

    aput-object v0, v3, v7

    const/16 v0, 0xa

    aput-object v6, v3, v0

    const/16 v0, 0xb

    aput-object v13, v3, v0

    const/16 v0, 0xc

    aput-object v15, v3, v0

    const/16 v0, 0xd

    aput-object v23, v3, v0

    sput-object v3, Lcom/zego/ve/MediaCodecVideoEncoder;->h264HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    move-object/from16 v3, v22

    const/16 v6, 0x15

    invoke-direct {v0, v3, v6, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->qcomHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v3, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v7, v21

    move-object/from16 v7, v21

    move-object/from16 v7, v21

    move-object/from16 v7, v21

    invoke-direct {v3, v7, v6, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v3, Lcom/zego/ve/MediaCodecVideoEncoder;->kirin960HEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v7, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v8, v20

    move-object/from16 v8, v20

    move-object/from16 v8, v20

    move-object/from16 v8, v20

    invoke-direct {v7, v8, v6, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v7, Lcom/zego/ve/MediaCodecVideoEncoder;->kirinHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v8, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v9, v19

    move-object/from16 v9, v19

    move-object/from16 v9, v19

    move-object/from16 v9, v19

    invoke-direct {v8, v9, v6, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v8, Lcom/zego/ve/MediaCodecVideoEncoder;->mtkHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-instance v9, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    move-object/from16 v10, v18

    move-object/from16 v10, v18

    move-object/from16 v10, v18

    move-object/from16 v10, v18

    invoke-direct {v9, v10, v6, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;)V

    sput-object v9, Lcom/zego/ve/MediaCodecVideoEncoder;->exynosHEVCHwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    new-array v1, v5, [Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v5, 0x0

    aput-object v0, v1, v5

    const/4 v0, 0x1

    aput-object v3, v1, v0

    const/4 v0, 0x2

    aput-object v7, v1, v0

    const/4 v0, 0x3

    aput-object v8, v1, v0

    aput-object v9, v1, v4

    sput-object v1, Lcom/zego/ve/MediaCodecVideoEncoder;->hevcHwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const-string/jumbo v10, "s-U3NAHp7SM-ISG3"

    const-string v10, "MIsS7H3-NSGUSA3-"

    const-string v10, "HS7A3SU3qSNIM--G"

    const-string v10, "SAMSUNG-SGH-I337"

    const-string v11, "7xsmeus"

    const-string/jumbo v11, "uxemNs7"

    const-string v11, " esmNux"

    const-string v11, "Nexus 7"

    const-string v12, "4 xNoeu"

    const-string/jumbo v12, "u4x oNe"

    const-string/jumbo v12, "ueN4sb "

    const-string v12, "Nexus 4"

    const-string v13, "AML-Ebu0"

    const-string v13, "-ML0LbEA"

    const-string v13, "M0LEAL-p"

    const-string v13, "EML-AL00"

    const-string v14, "1uq9TX"

    const-string/jumbo v14, "u7T19X"

    const-string v14, "9XsT01"

    const-string v14, "XT1079"

    const-string v15, "A0Mm0C"

    const-string v15, "MpA00C"

    const-string v15, "PA0MoC"

    const-string v15, "PACM00"

    const-string v16, "G0qSMb52"

    const-string/jumbo v16, "qG0MS2-5"

    const-string v16, "MGS20-u5"

    const-string v16, "SM-G9250"

    const-string v17, "VCs881A"

    const-string/jumbo v17, "pV8A1C1"

    const-string v17, "V1818CA"

    filled-new-array/range {v10 .. v17}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    const-string/jumbo v0, "mq8CV1A"

    const-string v0, "18Vm1AC"

    const-string v0, "18sC8V1"

    const-string v0, "V1818CA"

    const-string v1, "00X6"

    const-string v1, "X600"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    const/4 v0, 0x1

    sput-boolean v0, Lcom/zego/ve/MediaCodecVideoEncoder;->enableWhitelist:Z

    const-string/jumbo v3, "lxem.go.omo"

    const-string/jumbo v3, "lxeoomg.go."

    const-string v3, "emolo.g.goo"

    const-string/jumbo v3, "omx.google."

    const-string/jumbo v4, "xoepgb.bm.f"

    const-string/jumbo v4, "f..fmbxgpoe"

    const-string v4, ".efpgouxm.m"

    const-string/jumbo v4, "omx.ffmpeg."

    const-string/jumbo v5, "mppo.u"

    const-string/jumbo v5, "u.vopm"

    const-string/jumbo v5, "omqp.x"

    const-string/jumbo v5, "omx.pv"

    const-string/jumbo v6, "oks.efg..mx3pf"

    const-string/jumbo v6, "x.eof3mpk.mg.f"

    const-string/jumbo v6, "op.m3.g.xmfemf"

    const-string/jumbo v6, "omx.k3.ffmpeg."

    const-string v7, "cc.oo.qmovxd"

    const-string/jumbo v7, "macxcoovqd.."

    const-string/jumbo v7, "ovdacbxme.c."

    const-string/jumbo v7, "omx.avcodec."

    const-string/jumbo v8, "tm..xoutsai"

    const-string/jumbo v8, "oasi.xmtmt."

    const-string/jumbo v8, "moxttm.pi.i"

    const-string/jumbo v8, "omx.ittiam."

    const-string v9, "cm..mswcq.exsao"

    const-string/jumbo v9, "os.mescwxa.c..m"

    const-string v9, "css.mxv.waco..s"

    const-string/jumbo v9, "omx.sec.avc.sw."

    const-string v10, "an6me.cloeomedlieh2rrd.4xvmvo"

    const-string/jumbo v10, "x.2.ooale6nilevrhe4odrvmecdm."

    const-string v10, "..vdoeele.v2drxrcnmeoloao46hi"

    const-string/jumbo v10, "omx.marvell.video.h264encoder"

    filled-new-array/range {v3 .. v10}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->HW_BLACKLISTS:[Ljava/lang/String;

    new-array v0, v2, [I

    fill-array-data v0, :array_0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    const v0, 0x7f000789

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    return-void

    nop

    :array_0
    .array-data 4
        0x15
        0x7f420888
        0x7fa30c00
        0x7fa30c04
        0x13
        0x14
        0x7f000100
        0x7f000789
    .end array-data
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Landroid/media/MediaCodec$Callback;-><init>()V

    const/4 v3, 0x7

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance v1, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1, v0}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;-><init>(Lcom/zego/ve/MediaCodecVideoEncoder$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->isRunning:Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->pthis:J

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method static synthetic access$100(Lcom/zego/ve/MediaCodecVideoEncoder;)Landroid/media/MediaCodec;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " u~@ b@ ay~ @@tbo~ ~ ~/fcb ~S@~@@mi@bKf lMn~~o  /~@o@v@i-~@r@~4 ~o l @~@~1@ ~s@ .~ ~d~oi@~@t@o~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$102(Lcom/zego/ve/MediaCodecVideoEncoder;Landroid/media/MediaCodec;)Landroid/media/MediaCodec;
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x5

    return-object p1
.end method

.method private checkOnMediaCodecThread()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/RuntimeException;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v2, "oEicVeudiooc r sepea dyebnrad doeMlrpventodiCe"

    const-string/jumbo v2, "oedodbapesMv uidltiVerpenocEyiocer rCod e enad"

    const/4 v5, 0x7

    const-string/jumbo v2, "po e Vrpacieodtdoeoi dCecdEdlrrosineva ynepeuo"

    const-string v2, "MediaCodecVideoEncoder previously operated on "

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, "  adolw qb sletoc uniu"

    const-string/jumbo v2, "n u d uoc batlsoe  ilw"

    const/4 v5, 0x0

    const-string v2, " ust obslnwi   olcn ea"

    const-string v2, " but is now called on "

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    throw v0
.end method

.method static createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;
    .locals 2

    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0}, Landroid/media/MediaCodec;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0

    :catch_0
    const/4 v0, 0x1

    move v1, v0

    const/4 p0, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method public static disableH264HwCodec()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "oVcmdMoiEnderepcCadode"

    const-string v0, "aVerdcdpCeinoocdeoidEM"

    const/4 v3, 0x0

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "iHpnobybiooci4inditg adssl.2le. capaq e nd"

    const-string/jumbo v1, "nt 6apsiqcb.gsa cl be.a4eldinioy iin2poHdd"

    const/4 v3, 0x6

    const-string v1, "ctibdbeo42Hiscpsidi np..n bal  dge na6ylia"

    const-string v1, "H.264 encoding is disabled by application."

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v1, "od/aevuic"

    const-string/jumbo v1, "video/avc"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public static disableHEVCHwCodec()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "rdoiCnVpdedodeoEeMaesc"

    const-string v0, "CEsiiedddncoVdeereooaM"

    const/4 v3, 0x0

    const-string v0, "VddCdoioqdnrcaeeEoceeM"

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v1, "Cesidtipglcn ecHaompdn.ba  b ViinaoysidsE"

    const-string v1, "   mci ae nsticsEinoHyVdeobapibp.ialdgndC"

    const/4 v3, 0x0

    const-string v1, "acymHatbicibdpoeasnpi eCl n is.V ldi dong"

    const-string v1, "HEVC encoding is disabled by application."

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "/covovdeoi"

    const-string/jumbo v1, "vdevoc/oie"

    const/4 v3, 0x4

    const-string/jumbo v1, "hvcevbe/id"

    const-string/jumbo v1, "video/hevc"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public static disableVp8HwCodec()V
    .locals 4

    const/4 v3, 0x5

    const-string v0, "dieVebuedCaeMEordoccon"

    const-string v0, "cnrVobedeiCMdeodEeaodc"

    const/4 v3, 0x0

    const-string v0, "ddcieedpCoMeVnordcieEa"

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "s niidcaqbpednt  cbnl8glsipa iPoedioyVu "

    const-string/jumbo v1, "nc8niiu  pVgypc dstal ne aiibi.bodPledos"

    const/4 v3, 0x7

    const-string/jumbo v1, "igsaityais  das8di.o onlc  plienbecnPpdb"

    const-string v1, "VP8 encoding is disabled by application."

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x6

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo v1, "ovpm.2de/n.i8nod-xp"

    const-string v1, ".dvoe82piop/dn-nvx."

    const/4 v3, 0x5

    const-string v1, "/e.ponioxvdv.8d2v-n"

    const-string/jumbo v1, "video/x-vnd.on2.vp8"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public static disableVp9HwCodec()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "VceoebdoeiednaEqMCrcid"

    const-string v0, "drdEcCdeqneedoVoiceMai"

    const/4 v3, 0x7

    const-string v0, "eecodnuCdeidVeoiMdorac"

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, "aiaboaepyiidnsb snp ec.sop li cPi ndlgt9"

    const-string/jumbo v1, "slsde eiicanybta .godip9 icn lanioPdbp s"

    const/4 v3, 0x6

    const-string v1, "cai lliaqi9nido cesPn.bp Vetdabogyp ds n"

    const-string v1, "VP9 encoding is disabled by application."

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "2.spio/-devvvoxnd.n"

    const-string/jumbo v1, "odvmnpve.xo.-ni/d2v"

    const/4 v3, 0x5

    const-string/jumbo v1, "ovpmde9od-2i/x..vnn"

    const-string/jumbo v1, "video/x-vnd.on2.vp9"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method private static findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move/from16 v4, p3

    move/from16 v4, p3

    move/from16 v4, p3

    move/from16 v4, p3

    const-string/jumbo v5, "leoiopf"

    const-string/jumbo v5, "rofeoip"

    const-string/jumbo v5, "profile"

    const-string v6, "ae/vdbciv"

    const-string v6, "/eocvbvdi"

    const-string/jumbo v6, "video/avc"

    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string v7, "du Mleu"

    const-string v7, "Me:d lu"

    const-string v7, "Model: "

    const/4 v8, 0x0

    const-string/jumbo v9, "ricpeoopVencCeEeiadodd"

    const-string/jumbo v9, "oeodriMpceCdcdVEeiaeno"

    const-string/jumbo v9, "onCeoEcMqadcdeeiiVdeod"

    const-string v9, "MediaCodecVideoEncoder"

    if-eqz v0, :cond_0

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v10, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-interface {v0, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v1, "l2sicoea hb alqdkHsnee t4 rs d.6"

    const-string v1, "coe.leskqHi a dbe2a6ns hrcd  lt4"

    const-string v1, "ahim4aet 2. lklHs6cnebdc ro  des"

    const-string v1, " has black listed H.264 encoder."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v8

    :cond_0
    const-string/jumbo v0, "vhvioseoec"

    const-string/jumbo v0, "vcshdeoive"

    const-string v0, "devieb/vco"

    const-string/jumbo v0, "video/hevc"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v10, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-interface {v0, v10}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " .ckllu. rbdec tseasa2 ehon m6id"

    const-string/jumbo v1, "rlam c tl.os6ak e2.d5s bicned he"

    const-string v1, " e  ksopedr.n2h dicb.5alH6s atle"

    const-string v1, " has black listed H.265 encoder."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v9, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v8

    :cond_1
    const/4 v10, 0x0

    :goto_0
    :try_start_0
    invoke-static {}, Landroid/media/MediaCodecList;->getCodecCount()I

    move-result v0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-ge v10, v0, :cond_15

    :try_start_1
    invoke-static {v10}, Landroid/media/MediaCodecList;->getCodecInfoAt(I)Landroid/media/MediaCodecInfo;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_2

    goto :goto_1

    :catch_0
    move-exception v0

    move-object v11, v0

    move-object v11, v0

    :try_start_2
    const-string/jumbo v0, "rontoCteneaevcdcc donieoeeirnro f "

    const-string v0, " inrooeeqoneedn itoe ccrtc nafvder"

    const-string v0, "Cannot retrieve encoder codec info"

    invoke-static {v9, v0, v11}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    move-object v0, v8

    move-object v0, v8

    move-object v0, v8

    :goto_1
    if-eqz v0, :cond_14

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v11

    if-nez v11, :cond_2

    goto/16 :goto_f

    :cond_2
    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v11

    array-length v12, v11

    const/4 v13, 0x0

    :goto_2
    if-ge v13, v12, :cond_4

    aget-object v14, v11, v13

    invoke-virtual {v14, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_3

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v11

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    move-object v15, v11

    goto :goto_3

    :cond_3
    add-int/lit8 v13, v13, 0x1

    goto :goto_2

    :cond_4
    move-object v15, v8

    move-object v15, v8

    :goto_3
    if-nez v15, :cond_5

    goto/16 :goto_f

    :cond_5
    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "enst aecncra idoddFdn bu"

    const-string/jumbo v12, "idaeubc ta dFdrnodeconn "

    const-string v12, "cdnmeeouatian deod d nrc"

    const-string v12, "Found candidate encoder "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-static {v9, v11}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v11, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    sget-boolean v12, Lcom/zego/ve/MediaCodecVideoEncoder;->enableWhitelist:Z

    if-eqz v12, :cond_a

    array-length v12, v2

    const/4 v14, 0x0

    :goto_4
    if-ge v14, v12, :cond_9

    aget-object v7, v2, v14

    iget-object v8, v7, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;->codecPrefix:Ljava/lang/String;

    invoke-virtual {v15, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_8

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    iget v13, v7, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;->minSdk:I
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_2

    const-string/jumbo v2, "ucCdoe"

    const-string/jumbo v2, "uCdoce"

    const-string/jumbo v2, "odc eb"

    const-string v2, "Codec "

    if-ge v8, v13, :cond_6

    :try_start_3
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, " de lduvpK ta brsDu eiisdSos no "

    const-string v2, "D irs vpSd ies ditdnesKo ul bo a"

    const-string/jumbo v2, "l un eiped dess tod isa brioSDK "

    const-string v2, " is disabled due to SDK version "

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v9, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_5

    :cond_6
    iget-object v7, v7, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    sget-object v8, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->NO_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    if-eq v7, v8, :cond_7

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "saueutebqte sintq rmdjt ar iqr"

    const-string/jumbo v2, "mus rttrqqti  adea stnubj:erie"

    const-string v2, "ensami rjettsr situet:bq  deur"

    const-string v2, " requires bitrate adjustment: "

    invoke-virtual {v8, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v9, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    move-object v11, v7

    move-object v11, v7

    move-object v11, v7

    move-object v11, v7

    :cond_7
    const/4 v2, 0x1

    goto :goto_8

    :cond_8
    :goto_5
    add-int/lit8 v14, v14, 0x1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    const/4 v8, 0x0

    goto :goto_4

    :cond_9
    const/4 v2, 0x0

    goto :goto_8

    :cond_a
    invoke-virtual {v15}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v2

    sget-object v7, Lcom/zego/ve/MediaCodecVideoEncoder;->HW_BLACKLISTS:[Ljava/lang/String;

    array-length v8, v7

    const/4 v12, 0x0

    :goto_6
    if-ge v12, v8, :cond_c

    aget-object v13, v7, v12

    invoke-virtual {v2, v13}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v13
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_2

    if-eqz v13, :cond_b

    const/4 v2, 0x1

    goto :goto_7

    :cond_b
    add-int/lit8 v12, v12, 0x1

    goto :goto_6

    :cond_c
    const/4 v2, 0x0

    :goto_7
    const/4 v7, 0x1

    xor-int/2addr v2, v7

    :goto_8
    if-nez v2, :cond_d

    goto/16 :goto_f

    :cond_d
    :try_start_4
    invoke-virtual {v0, v1}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v0
    :try_end_4
    .catch Ljava/lang/IllegalArgumentException; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    :try_start_5
    iget-object v2, v0, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length v7, v2

    const/4 v8, 0x0

    :goto_9
    if-ge v8, v7, :cond_e

    aget v12, v2, v8

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v14, "soxmr:oCl"

    const-string v14, " rsool:Cx"

    const-string v14, "C:r oo0xl"

    const-string v14, "Color: 0x"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v12}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v9, v12}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    add-int/lit8 v8, v8, 0x1

    goto :goto_9

    :cond_e
    array-length v2, v3

    const/4 v7, 0x0

    :goto_a
    if-ge v7, v2, :cond_14

    aget v8, v3, v7

    iget-object v12, v0, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length v13, v12

    const/4 v14, 0x0

    :goto_b
    if-ge v14, v13, :cond_13

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    aget v2, v12, v14

    if-ne v2, v8, :cond_12

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "nodeeba ocrrnoetmd  rgtmFfemu "

    const-string/jumbo v7, "etdmaorFfnteruor    cm enedomg"

    const-string v7, " enfnouo rre F oedc gtuamrdmte"

    const-string v7, "Found target encoder for mime "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "  :"

    const-string v7, ":  "

    const-string v7, " : "

    const-string v7, " : "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "oCo r.op :l"

    const-string/jumbo v7, "oro.o : Cxl"

    const-string/jumbo v7, "o:Clro0 qx "

    const-string v7, ". Color: 0x"

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, " ms:teijtn d.eBtutraba"

    const-string/jumbo v7, "tB.j b tdnaar:miett eu"

    const-string v7, "Bremmi nu s et:tajtdta"

    const-string v7, ". Bitrate adjustment: "

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v9, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    invoke-virtual {v0}, Landroid/media/MediaCodecInfo$CodecCapabilities;->getEncoderCapabilities()Landroid/media/MediaCodecInfo$EncoderCapabilities;

    move-result-object v3

    const/4 v7, -0x1

    if-eqz v3, :cond_f

    if-eq v4, v7, :cond_f

    invoke-virtual {v3, v4}, Landroid/media/MediaCodecInfo$EncoderCapabilities;->isBitrateModeSupported(I)Z

    move-result v3

    if-eqz v3, :cond_f

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v8, "mode is supported"

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v9, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    goto :goto_c

    :cond_f
    const/4 v3, 0x0

    :goto_c
    invoke-virtual {v1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_10

    const/16 v6, 0x280

    const/16 v8, 0x1e0

    invoke-static {v1, v6, v8}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object v1

    const/4 v6, 0x1

    invoke-virtual {v1, v5, v6}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    invoke-virtual {v0, v1}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFormatSupported(Landroid/media/MediaFormat;)Z

    move-result v6

    const/16 v8, 0x8

    invoke-virtual {v1, v5, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    invoke-virtual {v0, v1}, Landroid/media/MediaCodecInfo$CodecCapabilities;->isFormatSupported(Landroid/media/MediaFormat;)Z

    move-result v0

    move/from16 v20, v0

    move/from16 v20, v0

    move/from16 v20, v0

    move/from16 v20, v0

    move/from16 v19, v6

    move/from16 v19, v6

    move/from16 v19, v6

    move/from16 v19, v6

    goto :goto_d

    :cond_10
    const/16 v19, 0x0

    const/16 v20, 0x0

    :goto_d
    if-nez v3, :cond_11

    if-eq v4, v7, :cond_11

    move/from16 v18, v7

    move/from16 v18, v7

    goto :goto_e

    :cond_11
    move/from16 v18, v4

    move/from16 v18, v4

    move/from16 v18, v4

    move/from16 v18, v4

    :goto_e
    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move-object v14, v0

    move/from16 v16, v2

    move/from16 v16, v2

    move/from16 v16, v2

    move/from16 v16, v2

    move-object/from16 v17, v11

    move-object/from16 v17, v11

    move-object/from16 v17, v11

    move-object/from16 v17, v11

    invoke-direct/range {v14 .. v20}, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;-><init>(Ljava/lang/String;ILcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;IZZ)V

    return-object v0

    :cond_12
    const/4 v2, 0x1

    add-int/lit8 v14, v14, 0x1

    move/from16 v2, v18

    move/from16 v2, v18

    goto/16 :goto_b

    :cond_13
    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    move/from16 v18, v2

    const/4 v2, 0x1

    add-int/lit8 v7, v7, 0x1

    move/from16 v2, v18

    move/from16 v2, v18

    goto/16 :goto_a

    :catch_1
    move-exception v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const-string/jumbo v0, "etdrote riuaeCnsnaeacrben tevci looi"

    const-string v0, "aeiCteurtos annvreolerieeac tin bdic"

    const-string/jumbo v0, "siip btc ieCnedvarrelatt nbeeaiornoc"

    const-string v0, "Cannot retrieve encoder capabilities"

    invoke-static {v9, v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    :try_end_5
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_5} :catch_2

    :cond_14
    :goto_f
    add-int/lit8 v10, v10, 0x1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    const/4 v8, 0x0

    goto/16 :goto_0

    :cond_15
    move-object v1, v8

    move-object v1, v8

    goto :goto_10

    :catch_2
    invoke-static {}, Lcom/zego/ve/MediaCodecVideoEncoder;->printStackTrace()V

    const/4 v1, 0x0

    :goto_10
    return-object v1
.end method

.method private getBitrateScale(I)D
    .locals 6

    const/4 v4, 0x7

    const/4 v5, 0x1

    int-to-double v0, p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const-wide/high16 v2, 0x4024000000000000L    # 10.0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    div-double/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v5, 0x3

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const-wide/high16 v2, 0x4000000000000000L    # 2.0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-wide v0
.end method

.method public static getCodecName()Ljava/lang/String;
    .locals 6

    const/4 v4, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->h264HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object v1, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v3, "divcvouap"

    const-string v3, "ecvodiapv"

    const/4 v5, 0x0

    const-string v3, "/ciodvvpe"

    const-string/jumbo v3, "video/avc"

    const/4 v5, 0x0

    invoke-static {v3, v0, v1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, v0, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->codecName:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v0
.end method

.method private getProfileType(Ljava/lang/String;II)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/16 v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-nez p2, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    move p3, v0

    move p3, v0

    const/4 v2, 0x4

    move p3, v0

    move p3, v0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo p2, "mani"

    const-string/jumbo p2, "nami"

    const/4 v2, 0x0

    const-string/jumbo p2, "iman"

    const-string/jumbo p2, "main"

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-eqz p2, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x0

    goto/16 :goto_1

    :cond_1
    const/4 v2, 0x5

    const-string/jumbo p2, "hhig"

    const-string/jumbo p2, "hhig"

    const-string/jumbo p2, "high"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz p2, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto/16 :goto_1

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo p2, "g1qhi0"

    const-string/jumbo p2, "i1q0hg"

    const/4 v2, 0x6

    const-string p2, "1hs0hg"

    const-string/jumbo p2, "high10"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p2, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/16 v0, 0x10

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_1

    :cond_3
    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string p2, "242mish"

    const-string/jumbo p2, "igsh242"

    const/4 v2, 0x1

    const-string p2, "2hghoi4"

    const-string/jumbo p2, "high422"

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz p2, :cond_4

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/16 v0, 0x20

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_1

    :cond_4
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string p2, "44im4bh"

    const-string/jumbo p2, "h44mhi4"

    const/4 v2, 0x3

    const-string/jumbo p2, "ghi44hu"

    const-string/jumbo p2, "high444"

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p2, :cond_5

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/16 v0, 0x40

    const/4 v2, 0x2

    goto :goto_1

    :cond_5
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo p2, "extnddep"

    const-string p2, "eddeoxtn"

    const/4 v2, 0x2

    const-string/jumbo p2, "extended"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    if-eqz p2, :cond_6

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_1

    :cond_6
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    move v0, p3

    move v0, p3

    const/4 v2, 0x2

    move v0, p3

    move v0, p3

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string/jumbo p3, "plbf:eioq"

    const-string/jumbo p3, "lf pobi:e"

    const/4 v2, 0x0

    const-string/jumbo p3, "lfsoe pri"

    const-string/jumbo p3, "profile: "

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string p1, ", "

    const-string p1, ", "

    const/4 v2, 0x2

    const-string p1, ", "

    const-string p1, ", "

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string p2, "ddcmdeoeneModcVuiCioEe"

    const-string/jumbo p2, "ooeieiucoVndECeMcdeddr"

    const/4 v2, 0x4

    const-string p2, "eoroocediadeMdVECodcei"

    const-string p2, "MediaCodecVideoEncoder"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x6

    return v0
.end method

.method public static isH264HwSupported(Z)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    sput-boolean p0, Lcom/zego/ve/MediaCodecVideoEncoder;->enableWhitelist:Z

    const/4 v3, 0x6

    and-int/2addr v4, v3

    sget-object p0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v0, "ivpavbe/o"

    const-string/jumbo v0, "iead/vvpo"

    const/4 v4, 0x1

    const-string/jumbo v0, "iveacdu/o"

    const-string/jumbo v0, "video/avc"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    sget-object p0, Lcom/zego/ve/MediaCodecVideoEncoder;->h264HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-object v1, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v0, p0, v1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x7

    const/4 p0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    move v4, v3

    const/4 p0, 0x0

    shl-int/2addr v4, p0

    :goto_0
    const/4 v3, 0x5

    const/4 v3, 0x7

    return p0
.end method

.method public static isH264HwSupportedUsingTextures()Z
    .locals 6

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v1, "/cqdeiopa"

    const-string/jumbo v1, "odecav/iq"

    const/4 v5, 0x0

    const-string/jumbo v1, "vcvaod/iq"

    const-string/jumbo v1, "video/avc"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v0, v1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->h264HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object v2, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v3, -0x1

    const/4 v5, 0x5

    invoke-static {v1, v0, v2, v3}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x4

    or-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    return v0
.end method

.method public static isHEVCHwSupported(Z)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    sput-boolean p0, Lcom/zego/ve/MediaCodecVideoEncoder;->enableWhitelist:Z

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object p0, Lcom/zego/ve/MediaCodecVideoEncoder;->hwEncoderDisabledTypes:Ljava/util/Set;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v0, "ecsivdhvoe"

    const/4 v4, 0x5

    const-string v0, "ehs/divoec"

    const-string/jumbo v0, "video/hevc"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-object p0, Lcom/zego/ve/MediaCodecVideoEncoder;->hevcHwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v1, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v2, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v0, p0, v1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 p0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 p0, 0x0

    move v4, p0

    :goto_0
    const/4 v3, 0x5

    move v4, v3

    return p0
.end method

.method public static isVp8HwSupported(Z)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 p0, 0x0

    and-int/2addr v1, p0

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method private static native on_error(JI)I
.end method

.method private static native on_input_buffer_available(JI)I
.end method

.method private static native on_output_buffer_available(JLcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;)I
.end method

.method public static printStackTrace()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->runningInstance:Lcom/zego/ve/MediaCodecVideoEncoder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v0, v0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    array-length v1, v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-lez v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v1, "antmkCMrdacEoedcco:decVis odasetreie"

    const/4 v6, 0x2

    const-string/jumbo v1, "scemekrddinMtaeCradosoe iceadVo:E cc"

    const-string v1, "MediaCodecVideoEncoder stacks trace:"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v2, "dVaoooedcdMCeioinEeedr"

    const-string v2, "MediaCodecVideoEncoder"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    array-length v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x1

    if-ge v3, v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    aget-object v4, v0, v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void
.end method

.method private reportEncodedFrame(I)V
    .locals 12

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-eqz v0, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    sget-object v2, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eq v1, v2, :cond_0

    const/4 v10, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    goto/16 :goto_1

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    int-to-double v1, v1

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const-wide/high16 v3, 0x4020000000000000L    # 8.0

    const/4 v11, 0x5

    int-to-double v5, v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    mul-double/2addr v5, v3

    const/4 v11, 0x3

    const/4 v10, 0x1

    div-double/2addr v1, v5

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-wide v3, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    int-to-double v5, p1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    sub-double/2addr v5, v1

    const/4 v11, 0x4

    add-double/2addr v3, v5

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    iput-wide v3, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-wide v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-wide v5, 0x408f400000000000L    # 1000.0

    const-wide v5, 0x408f400000000000L    # 1000.0

    const/4 v11, 0x1

    const-wide v5, 0x408f400000000000L    # 1000.0

    const-wide v5, 0x408f400000000000L    # 1000.0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    int-to-double v7, v0

    const/4 v11, 0x1

    const/4 v10, 0x2

    div-double/2addr v5, v7

    const/4 v10, 0x6

    move v11, v10

    add-double/2addr v1, v5

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    iput-wide v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const/4 v11, 0x4

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const-wide/high16 v0, 0x4008000000000000L    # 3.0

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    iget-wide v5, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v11, 0x4

    const/4 v10, 0x2

    mul-double/2addr v5, v0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->min(DD)D

    move-result-wide v0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    iput-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    neg-double v2, v5

    const/4 v11, 0x3

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->max(DD)D

    move-result-wide v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    iput-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const/4 v11, 0x1

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const-wide v2, 0x40a7700000000000L    # 3000.0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    cmpl-double p1, v0, v2

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-lez p1, :cond_4

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string v0, "bo cc"

    const-string v0, "c :co"

    const/4 v11, 0x0

    const-string v0, " uA:c"

    const-string v0, "Acc: "

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    iget-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    double-to-int v0, v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string/jumbo v0, "x:. abM"

    const/4 v11, 0x2

    const-string/jumbo v0, "p .:Max"

    const-string v0, ". Max: "

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    and-int/2addr v11, v10

    iget-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    double-to-int v0, v0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string v0, "Ea.:Sxuce l "

    const/4 v11, 0x7

    const-string v0, " epExl:.qac "

    const-string v0, ". ExpScale: "

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v0, "eisecEcVodCeeadMidornp"

    const-string v0, "edoaMcdprVcdEeCeidnioe"

    const/4 v11, 0x0

    const-string/jumbo v0, "rdEmadeeCnocdoeoVdeiic"

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x4

    iget-wide v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-wide v3, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    cmpl-double p1, v1, v3

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v5, 0x1

    const/4 v10, 0x6

    or-int/2addr v11, v10

    const-wide/high16 v6, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v6, 0x3fe0000000000000L    # 0.5

    const/4 v11, 0x2

    const-wide/high16 v6, 0x3fe0000000000000L    # 0.5

    const-wide/high16 v6, 0x3fe0000000000000L    # 0.5

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-lez p1, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    div-double/2addr v1, v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    add-double/2addr v1, v6

    const/4 v11, 0x6

    const/4 v10, 0x6

    double-to-int p1, v1

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    sub-int/2addr v1, p1

    const/4 v10, 0x3

    move v11, v10

    iput v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    iput-wide v3, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v11, 0x3

    const/4 v10, 0x2

    goto :goto_0

    :cond_1
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    neg-double v8, v3

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    cmpg-double p1, v1, v8

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-gez p1, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    neg-double v1, v1

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    div-double/2addr v1, v3

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    add-double/2addr v1, v6

    const/4 v11, 0x5

    const/4 v10, 0x0

    double-to-int p1, v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    add-int/2addr v1, p1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    iput v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    neg-double v1, v3

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    iput-wide v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v10, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    goto :goto_0

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    const/4 v5, 0x0

    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-eqz v5, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/16 v1, 0xa

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result p1

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/16 v1, -0xa

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {p1, v1}, Ljava/lang/Math;->max(II)I

    move-result p1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v1, "cetio nAgt tb rqjs etsoaiau"

    const-string/jumbo v1, "racsnijdqtAe g i  stotueabt"

    const/4 v11, 0x6

    const-string v1, "cg atbnebl iuoss teditra tA"

    const-string v1, "Adjusting bitrate scale to "

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string/jumbo v1, "seV:.uu a"

    const-string v1, "e:s Vau. "

    const/4 v11, 0x6

    const-string v1, ":ue V ap."

    const-string v1, ". Value: "

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    iget v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v11, 0x7

    invoke-direct {p0, v1}, Lcom/zego/ve/MediaCodecVideoEncoder;->getBitrateScale(I)D

    move-result-wide v1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p1, v1, v2}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-static {v0, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    iget p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v10, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    div-int/lit16 p1, p1, 0x3e8

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    const/4 v11, 0x3

    const/4 v10, 0x7

    invoke-direct {p0, p1, v0}, Lcom/zego/ve/MediaCodecVideoEncoder;->setRates(II)Z

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v11, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    iput-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    :cond_4
    :goto_1
    const/4 v10, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    return-void
.end method

.method public static setErrorCallback(Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v0, "VecrcoMoqdeeCimdddeioa"

    const-string/jumbo v0, "iedmrMnaoioVcdeedceCod"

    const/4 v3, 0x3

    const-string/jumbo v0, "rnseeiddVeoaCccoEdoMed"

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, "ecrmokSlct aroer l"

    const-string v1, "cSrcoraa otkel lre"

    const/4 v3, 0x1

    const-string/jumbo v1, "lcetolarrSb r ckao"

    const-string v1, "Set error callback"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object p0, Lcom/zego/ve/MediaCodecVideoEncoder;->errorCallback:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method private setRates(II)Z
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v7, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    sget-object v1, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->DYNAMIC_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ne v0, v1, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    int-to-double v2, p1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-wide/high16 v4, 0x4020000000000000L    # 8.0

    const-wide/high16 v4, 0x4020000000000000L    # 8.0

    const/4 v8, 0x3

    const-wide/high16 v4, 0x4020000000000000L    # 8.0

    const-wide/high16 v4, 0x4020000000000000L    # 8.0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    div-double v4, v2, v4

    const/4 v7, 0x4

    move v8, v7

    iput-wide v4, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const/4 v8, 0x2

    iget v4, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-lez v4, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-ge p1, v4, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-wide v5, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    mul-double/2addr v5, v2

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    int-to-double v2, v4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    div-double/2addr v5, v2

    const/4 v8, 0x6

    iput-wide v5, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetBitrateBps:I

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    iput p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    sget-object v2, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string v3, " b.skbp :bps"

    const-string v3, ":p. bbpFss k"

    const/4 v8, 0x6

    const-string/jumbo v3, "pkFsb u : ps"

    const-string v3, " kbps. Fps: "

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string/jumbo v4, "t:euRtaps "

    const-string/jumbo v4, "tses: uRta"

    const/4 v8, 0x6

    const-string v4, "ea:ets sqt"

    const-string/jumbo v4, "setRates: "

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string v5, "ersoenEVidpMdceodecodC"

    const-string v5, "VrdoeccpnieModeEdadCoe"

    const-string v5, "decmdioeanodVMeeridcCo"

    const-string v5, "MediaCodecVideoEncoder"

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-ne v0, v2, :cond_1

    const/4 v8, 0x0

    if-lez p2, :cond_1

    const/4 v8, 0x1

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->originFps:I

    const/4 v8, 0x2

    mul-int/2addr v0, p1

    const/4 v8, 0x3

    div-int/2addr v0, p2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    div-int/lit16 p1, p1, 0x3e8

    const/4 v8, 0x7

    const/4 v7, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string p1, "-  >"

    const-string p1, " > -"

    const/4 v8, 0x7

    const-string p1, "  >-"

    const-string p1, " -> "

    const/4 v8, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    div-int/lit16 p1, v0, 0x3e8

    const/4 v8, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v5, p1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    move p1, v0

    move p1, v0

    const/4 v8, 0x3

    move p1, v0

    move p1, v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-ne v0, v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    div-int/lit16 v0, p1, 0x3e8

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    const/4 v7, 0x4

    and-int/2addr v8, v7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v0, " . loqS:cEpe"

    const-string/jumbo v0, "p :S.lc qeaE"

    const/4 v8, 0x6

    const-string/jumbo v0, "l xSpb. :caE"

    const-string v0, ". ExpScale: "

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    move v8, v7

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v5, p2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    const/4 v8, 0x7

    if-eqz p2, :cond_3

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    int-to-double v0, p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p0, p2}, Lcom/zego/ve/MediaCodecVideoEncoder;->getBitrateScale(I)D

    move-result-wide p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    mul-double/2addr v0, p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    double-to-int p1, v0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    invoke-virtual {p2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    div-int/lit16 v0, p1, 0x3e8

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    iget v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v5, p2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    :goto_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance p2, Landroid/os/Bundle;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v0, "aedtbsui-ieov"

    const-string v0, "aesirv-doteib"

    const/4 v8, 0x5

    const-string/jumbo v0, "video-bitrate"

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p2, v0, p1}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1, p2}, Landroid/media/MediaCodec;->setParameters(Landroid/os/Bundle;)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 p1, 0x1

    const/4 v7, 0x7

    and-int/2addr v8, v7

    return p1

    :catch_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const-string p2, "eeat alpsisdfem"

    const-string p2, " sfmldaeaeRsite"

    const/4 v8, 0x4

    const-string/jumbo p2, "seia safqdleett"

    const-string/jumbo p2, "setRates failed"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v5, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 p1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x4

    return p1
.end method


# virtual methods
.method checkKeyFrameRequired(ZJ)V
    .locals 8

    const/4 v7, 0x7

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v7, 0x5

    const-wide/16 v0, 0x1f4

    const-wide/16 v0, 0x1f4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    add-long/2addr p2, v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v7, 0x3

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    div-long/2addr p2, v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->lastKeyFrameMs:J

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x2

    const-wide/16 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    cmp-long v0, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-gez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    iput-wide p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->lastKeyFrameMs:J

    :cond_0
    const/4 v6, 0x7

    move v7, v6

    const/4 v0, 0x0

    shr-int/2addr v7, v0

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez p1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-wide v4, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->forcedKeyFrameMs:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    cmp-long v1, v4, v2

    const/4 v7, 0x6

    if-lez v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-wide v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->lastKeyFrameMs:J

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    add-long/2addr v1, v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    cmp-long v1, p2, v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-lez v1, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    move v1, v0

    move v1, v0

    const/4 v7, 0x6

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez p1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v1, :cond_4

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v1, "iisarcoeeedEooVdeCMndc"

    const-string v1, "ciedoedaVorcoCMioEeden"

    const/4 v7, 0x7

    const-string v1, "eocmVoaenciddEiMrdeeoC"

    const-string v1, "MediaCodecVideoEncoder"

    const/4 v7, 0x6

    if-eqz p1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const-string p1, "asrtoeScneeyfru  m"

    const-string/jumbo p1, "frSrebtcs mn eayue"

    const/4 v7, 0x3

    const-string/jumbo p1, "qercebrustefm Syn "

    const-string p1, "Sync frame request"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    goto :goto_1

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string/jumbo p1, "r ffnrumodeac Syu"

    const-string p1, "dryoSmurcfacfen  "

    const/4 v7, 0x0

    const-string/jumbo p1, "rref  dpnycomaSfc"

    const-string p1, "Sync frame forced"

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance p1, Landroid/os/Bundle;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const-string/jumbo v1, "nsqcuyesqpre"

    const-string v1, "-cuyenepqrss"

    const/4 v7, 0x2

    const-string v1, "essseynctruq"

    const-string/jumbo v1, "request-sync"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Landroid/media/MediaCodec;->setParameters(Landroid/os/Bundle;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    iput-wide p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->lastKeyFrameMs:J

    :cond_4
    const/4 v7, 0x7

    const/4 v6, 0x2

    return-void
.end method

.method dequeueInputBuffer()I
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/media/MediaCodec;->dequeueInputBuffer(J)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    return v0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "ufum BeulffeertaqIedqndpte"

    const-string v2, "dte qeIBqupenueuradiffletf"

    const-string v2, "BuueofaeIdufeqittdefpunl r"

    const-string v2, "dequeueIntputBuffer failed"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v1, "desVebcnoadECedcieorMo"

    const-string v1, "VEsieacdeeCcododderoMn"

    const/4 v4, 0x2

    const-string/jumbo v1, "ocoeoeundiVecddaErdeCM"

    const-string v1, "MediaCodecVideoEncoder"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, -0x2

    const/4 v4, 0x7

    const/4 v3, 0x5

    return v0
.end method

.method dequeueOutputBuffer()Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;
    .locals 12

    const/4 v11, 0x1

    const-string v0, "ddediaipcenMceooemdoVr"

    const-string v0, "deMmrCaicieoocVdednedo"

    const/4 v11, 0x1

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v11, 0x3

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x0

    new-instance v1, Landroid/media/MediaCodec$BufferInfo;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {v1}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget-object v2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x4

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v2, v1, v3, v4}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/4 v5, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v6, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    if-ltz v2, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    iget v7, v1, Landroid/media/MediaCodec$BufferInfo;->flags:I

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x1

    and-int/lit8 v7, v7, 0x2

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-eqz v7, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    move v7, v5

    move v7, v5

    const/4 v11, 0x6

    move v7, v5

    move v7, v5

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    goto :goto_0

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    move v7, v6

    move v7, v6

    const/4 v11, 0x1

    move v7, v6

    move v7, v6

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    if-eqz v7, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string v8, "d:oaoreefCga. etene frimsfgn tf "

    const-string/jumbo v8, "tfd ng:eqsi oef Cnre Ofteagm.aef"

    const-string v8, "Config frame generated. Offset: "

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget v8, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    const-string/jumbo v8, "ezsS : i"

    const-string/jumbo v8, "i  zebS:"

    const/4 v11, 0x4

    const-string/jumbo v8, "z:im.S  "

    const-string v8, ". Size: "

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget v8, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v0, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget v7, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v10, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v7}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v7

    const/4 v11, 0x6

    const/4 v10, 0x5

    iput-object v7, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-virtual {p0, v6, v2}, Lcom/zego/ve/MediaCodecVideoEncoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object v7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget v8, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x0

    invoke-virtual {v7, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget v8, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x1

    iget v9, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x4

    add-int/2addr v8, v9

    const/4 v11, 0x0

    invoke-virtual {v7, v8}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-object v8, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {v8, v7}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v10, 0x0

    move v11, v10

    iget-object v7, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v7, v2, v6}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v2, v1, v3, v4}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v2

    :cond_1
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    move v3, v2

    move v3, v2

    const/4 v11, 0x7

    move v3, v2

    move v3, v2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-ltz v3, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {p0, v6, v3}, Lcom/zego/ve/MediaCodecVideoEncoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget v4, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget v4, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget v7, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    add-int/2addr v4, v7

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v2, v4}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget v4, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-direct {p0, v4}, Lcom/zego/ve/MediaCodecVideoEncoder;->reportEncodedFrame(I)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget v4, v1, Landroid/media/MediaCodec$BufferInfo;->flags:I

    const/4 v10, 0x2

    const/4 v11, 0x7

    and-int/2addr v4, v5

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-eqz v4, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    move v6, v5

    move v6, v5

    const/4 v11, 0x5

    move v6, v5

    move v6, v5

    :cond_2
    const/4 v11, 0x4

    new-instance v9, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    iget v5, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x2

    iget-wide v7, v1, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-direct/range {v2 .. v8}, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;-><init>(ILjava/nio/ByteBuffer;IZJ)V

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    return-object v9

    :cond_3
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v1, -0x3

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    if-ne v3, v1, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->dequeueOutputBuffer()Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    return-object v0

    :cond_4
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    const/4 v1, -0x2

    const/4 v10, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    if-ne v3, v1, :cond_5

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->dequeueOutputBuffer()Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    return-object v0

    :cond_5
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    const/4 v1, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    if-ne v3, v1, :cond_6

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/4 v0, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    return-object v0

    :cond_6
    const/4 v11, 0x4

    const/4 v10, 0x6

    new-instance v1, Ljava/lang/RuntimeException;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x3

    const-string v4, " puOoBuuefdtut:eueuqr"

    const-string/jumbo v4, "puuetfuu:eeufurtOd Bq"

    const/4 v11, 0x4

    const-string v4, "OurBdbteefu:uup equet"

    const-string v4, "dequeueOutputBuffer: "

    const/4 v11, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x1

    throw v1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception v1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const-string v2, "eBfapuufueeeultqrfudidu ep"

    const-string v2, "eflp urpuieudduftteBeuqaef"

    const/4 v11, 0x4

    const-string/jumbo v2, "uff edapruetieBeuOuupqdtel"

    const-string v2, "dequeueOutputBuffer failed"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {v0, v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x4

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v4, -0x1

    const/4 v4, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    const/4 v5, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    const/4 v6, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v7, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-wide/16 v8, -0x1

    const-wide/16 v8, -0x1

    const/4 v11, 0x7

    const-wide/16 v8, -0x1

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct/range {v3 .. v9}, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;-><init>(ILjava/nio/ByteBuffer;IZJ)V

    const/4 v11, 0x3

    const/4 v10, 0x6

    return-object v0
.end method

.method encodeBuffer(ZIIJ)Z
    .locals 9

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0, p1, p4, p5}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkKeyFrameRequired(ZJ)V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    const/4 v2, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v6, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    move v1, p2

    move v1, p2

    move v1, p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    move v3, p3

    move v3, p3

    const/4 v8, 0x2

    move v3, p3

    move v3, p3

    move-wide v4, p4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual/range {v0 .. v6}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 p1, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    return p1

    :catch_0
    move-exception p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v8, 0x2

    const-string p2, "ceeoecidqorMniaVqCEodd"

    const-string p2, "eErcdMVoqdnicoeCeeoaid"

    const/4 v8, 0x1

    const-string/jumbo p2, "oesdMadeenCEiecdoorcdV"

    const-string p2, "MediaCodecVideoEncoder"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo p3, "odrmfniluefedB ecsf"

    const-string p3, "deseilBnr deffoucfe"

    const/4 v8, 0x5

    const-string p3, "cfeBorfoanedudli fe"

    const-string p3, "encodeBuffer failed"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 p1, 0x0

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    return p1
.end method

.method encodeTexture(ZI[FJ)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p0, p1, p4, p5}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkKeyFrameRequired(ZJ)V
    :try_end_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x7

    return p1

    :catch_0
    move-exception p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    const-string p2, "enmdibeCicaedodMrdeVEo"

    const-string p2, "MedmeeocCidnoaodrdEeVi"

    const/4 v1, 0x5

    const-string p2, "edniedudeVEoCeaociorMd"

    const-string p2, "MediaCodecVideoEncoder"

    const/4 v1, 0x1

    const/4 v0, 0x6

    const-string p3, "Tefdorepexae eiodclu"

    const-string/jumbo p3, "i xcoTdodltreeeauefe"

    const-string p3, " Tletaxfqreueddnceoe"

    const-string p3, "encodeTexture failed"

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p1
.end method

.method getByteBuffer(ZI)Ljava/nio/ByteBuffer;
    .locals 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/media/MediaCodec;->getInputBuffer(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Landroid/media/MediaCodec;->getOutputBuffer(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x5

    return-object p1
.end method

.method getImage(I)Lcom/zego/ve/MediaCodecVideoEncoder$VImage;
    .locals 7
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Landroid/media/MediaCodec;->getInputImage(I)Landroid/media/Image;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    aget-object v2, p1, v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v0, v2}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$202(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    aget-object v2, p1, v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v0, v2}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$302(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;I)I

    const/4 v6, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x5

    aget-object v3, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v3}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$402(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    aget-object v3, p1, v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v0, v3}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$502(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;I)I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget-object v4, p1, v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v4}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v0, v4}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$602(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    aget-object v4, p1, v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v4}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v0, v4}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$702(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;I)I

    const/4 v6, 0x2

    aget-object v0, p1, v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ne v0, v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    aget-object p1, p1, v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ne p1, v2, :cond_0

    const/4 v5, 0x6

    or-int/2addr v6, v5

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p1, v2}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$802(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Z)Z

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p1, v1}, Lcom/zego/ve/MediaCodecVideoEncoder$VImage;->access$802(Lcom/zego/ve/MediaCodecVideoEncoder$VImage;Z)Z

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->cacheImage:Lcom/zego/ve/MediaCodecVideoEncoder$VImage;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-object p1
.end method

.method initEncode(IIIIIZIILjava/lang/String;IZ)Z
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v0, p1

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v3, p3

    move/from16 v3, p3

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v4, p4

    move/from16 v4, p4

    move/from16 v5, p5

    move/from16 v5, p5

    move/from16 v5, p5

    move/from16 v5, p5

    move/from16 v6, p6

    move/from16 v6, p6

    move/from16 v6, p6

    move/from16 v6, p6

    move/from16 v7, p7

    move/from16 v7, p7

    move/from16 v7, p7

    move/from16 v7, p7

    move/from16 v8, p8

    move/from16 v8, p8

    move/from16 v8, p8

    move/from16 v9, p10

    move/from16 v9, p10

    move/from16 v9, p10

    move/from16 v9, p10

    const-string/jumbo v10, "hhsgltiiesbe"

    const-string/jumbo v10, "lsihhbe-geit"

    const-string/jumbo v10, "ethm-sihgice"

    const-string/jumbo v10, "slice-height"

    const-string v11, "dsuroi"

    const-string/jumbo v11, "uiersd"

    const-string/jumbo v11, "stride"

    const-string/jumbo v12, "ne nabiolfcdEtdei"

    const-string/jumbo v12, "initEncode failed"

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v14, "itcaJvuia:nEe d p"

    const-string v14, ":JitdiepvoEac an "

    const-string/jumbo v14, "itc iedpa J:onvna"

    const-string v14, "Java initEncode: "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "x  "

    const-string/jumbo v14, "x  "

    const-string v14, " x "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v15, "@ . "

    const-string v15, "@ . "

    const-string v15, "  .@"

    const-string v15, ". @ "

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-int/lit16 v15, v4, 0x3e8

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v15, ". :bsk Fq ps"

    const-string v15, "Fs  ks .q:bp"

    const-string/jumbo v15, "sks p Fb.s: "

    const-string v15, " kbps. Fps: "

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v15, "ussmrS:eafuc"

    const-string v15, "eess:ucufraS"

    const-string v15, "aScfouese r:"

    const-string v15, " useSurface:"

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const-string v15, "dirmcbCnMEddoocaoeeide"

    const-string/jumbo v15, "neamieeedrModcdiocdEoC"

    const-string v15, "EcdVneuoeoderiCiecddMa"

    const-string v15, "MediaCodecVideoEncoder"

    invoke-static {v15, v13}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iput v2, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->width:I

    iput v3, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->height:I

    move-object/from16 v16, v12

    move-object/from16 v16, v12

    move-object/from16 v16, v12

    move-object/from16 v16, v12

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    const-wide/16 v12, 0x0

    iput-wide v12, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->forcedKeyFrameMs:J

    const-wide/16 v12, -0x1

    const-wide/16 v12, -0x1

    const-wide/16 v12, -0x1

    const-wide/16 v12, -0x1

    iput-wide v12, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->lastKeyFrameMs:J

    iget-object v12, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    if-nez v12, :cond_15

    invoke-static {}, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->values()[Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    move-result-object v12

    aget-object v12, v12, v0

    sget-object v13, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_H264_AVC:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    move-object/from16 v17, v14

    move-object/from16 v17, v14

    move-object/from16 v17, v14

    move-object/from16 v17, v14

    if-ne v12, v13, :cond_4

    const-string/jumbo v12, "r6o  icpoetienh2n"

    const-string v12, "c26iooenihrnd te "

    const-string v12, " onec2dtqe4inrh6i"

    const-string/jumbo v12, "init h264 encoder"

    invoke-static {v15, v12}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v12, Lcom/zego/ve/MediaCodecVideoEncoder;->h264HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    if-eqz v6, :cond_0

    sget-object v13, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    goto :goto_0

    :cond_0
    sget-object v13, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    :goto_0
    const-string/jumbo v0, "i/svvebdo"

    const-string/jumbo v0, "odevab/iv"

    const-string v0, "cvem/vaoi"

    const-string/jumbo v0, "video/avc"

    invoke-static {v0, v12, v13, v9}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object v9

    iget-boolean v12, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->supportedProfile:Z

    if-eqz v12, :cond_3

    iget-boolean v12, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->supportedHighProfile:Z

    if-eqz v12, :cond_1

    const/16 v12, 0x8

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    goto :goto_1

    :cond_1
    move-object/from16 v13, p9

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    const/4 v12, 0x1

    :goto_1
    invoke-direct {v1, v13, v8, v12}, Lcom/zego/ve/MediaCodecVideoEncoder;->getProfileType(Ljava/lang/String;II)I

    move-result v12

    mul-int v13, v2, v3

    div-int/lit16 v13, v13, 0x100

    const/16 v14, 0x2000

    if-gt v13, v14, :cond_2

    const/16 v13, 0x800

    goto :goto_6

    :cond_2
    const v13, 0x8000

    goto :goto_6

    :cond_3
    :goto_2
    const/4 v12, -0x1

    const/4 v13, -0x1

    goto :goto_6

    :cond_4
    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_H265:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    if-ne v12, v0, :cond_6

    const-string v0, "dt hoer noenivicc"

    const-string/jumbo v0, "init hevc encoder"

    invoke-static {v15, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->hevcHwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    if-eqz v6, :cond_5

    sget-object v12, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    goto :goto_3

    :cond_5
    sget-object v12, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    :goto_3
    const-string/jumbo v13, "ochuvbdvi/"

    const-string v13, "eiv/dhuvoc"

    const-string v13, "ci/eoduvvh"

    const-string/jumbo v13, "video/hevc"

    invoke-static {v13, v0, v12, v9}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object v9

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    move-object v0, v13

    goto :goto_2

    :cond_6
    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;->VIDEO_CODEC_VP8:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    if-ne v12, v0, :cond_14

    const-string v12, "d ioeneprct8 pin"

    const-string/jumbo v12, "i vpednpot ecinr"

    const-string/jumbo v12, "init vp8 encoder"

    invoke-static {v15, v12}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    sget-object v12, Lcom/zego/ve/MediaCodecVideoEncoder;->vp8HwList:[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    if-eqz v6, :cond_7

    sget-object v13, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedSurfaceColorList:[I

    goto :goto_4

    :cond_7
    sget-object v13, Lcom/zego/ve/MediaCodecVideoEncoder;->supportedColorList:[I

    :goto_4
    const-string/jumbo v14, "o.q2n-diqvonvxd8vp/"

    const-string v14, "2.nipd8-qvx/nvdoo.v"

    const-string/jumbo v14, "iosxnvodv.vpe/n-.8d"

    const-string/jumbo v14, "video/x-vnd.on2.vp8"

    invoke-static {v14, v12, v13, v9}, Lcom/zego/ve/MediaCodecVideoEncoder;->findHwEncoder(Ljava/lang/String;[Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;[II)Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;

    move-result-object v9

    iget-object v12, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->type:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    if-ne v12, v0, :cond_9

    iget-object v0, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->codecName:Ljava/lang/String;

    sget-object v12, Lcom/zego/ve/MediaCodecVideoEncoder;->qcomVp8HwProperties:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;

    iget-object v12, v12, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecProperties;->codecPrefix:Ljava/lang/String;

    invoke-virtual {v0, v12}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_9

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v12, 0x17

    if-ne v0, v12, :cond_8

    mul-int/lit16 v0, v7, 0x3e8

    int-to-long v12, v0

    iput-wide v12, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->forcedKeyFrameMs:J

    goto :goto_5

    :cond_8
    if-le v0, v12, :cond_9

    mul-int/lit16 v0, v7, 0x3e8

    int-to-long v12, v0

    iput-wide v12, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->forcedKeyFrameMs:J

    :cond_9
    :goto_5
    move-object v0, v14

    move-object v0, v14

    move-object v0, v14

    move-object v0, v14

    goto :goto_2

    :goto_6
    if-eqz v9, :cond_13

    sput-object v1, Lcom/zego/ve/MediaCodecVideoEncoder;->runningInstance:Lcom/zego/ve/MediaCodecVideoEncoder;

    iget v14, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->colorFormat:I

    iput v14, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->colorFormat:I

    iget-object v14, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    iput-object v14, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    const/16 v14, 0x3c

    invoke-static {v5, v14}, Ljava/lang/Math;->min(II)I

    move-result v5

    iget-object v14, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    move-object/from16 v18, v10

    move-object/from16 v18, v10

    sget-object v10, Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;->FRAMERATE_ADJUSTMENT:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    if-ne v14, v10, :cond_a

    iput v5, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->originFps:I

    :cond_a
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "Ca:ml romo ors"

    const-string/jumbo v14, "rCsrtmalo oo :"

    const-string v14, "ao:oomt  rrlof"

    const-string v14, "Color format: "

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v14, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->colorFormat:I

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "tit abeam. mn:rBdt set"

    const-string/jumbo v14, "rnsm  e:tjdtemtBt aia."

    const-string v14, ". Bitrate adjustment: "

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v14, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentType:Lcom/zego/ve/MediaCodecVideoEncoder$BitrateAdjustmentType;

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v14, " .Isi uot lp:ai"

    const-string v14, "It soai fl.p i:"

    const-string v14, "  as nfpIl.iti:"

    const-string v14, ". Initial fps: "

    invoke-virtual {v10, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v15, v10}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iput v4, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->targetBitrateBps:I

    iput v5, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    move-object v14, v11

    move-object v14, v11

    move-object v14, v11

    move-object v14, v11

    int-to-double v10, v4

    const-wide/high16 v19, 0x4020000000000000L    # 8.0

    const-wide/high16 v19, 0x4020000000000000L    # 8.0

    const-wide/high16 v19, 0x4020000000000000L    # 8.0

    const-wide/high16 v19, 0x4020000000000000L    # 8.0

    div-double v10, v10, v19

    iput-wide v10, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulatorMax:D

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    iput-wide v10, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAccumulator:D

    iput-wide v10, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateObservationTimeMs:D

    const/4 v10, 0x0

    iput v10, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->bitrateAdjustmentScaleExp:I

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v10

    iput-object v10, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    :try_start_0
    invoke-static {v0, v2, v3}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object v0

    const-string/jumbo v10, "tqabrit"

    const-string/jumbo v10, "tariebt"

    const-string/jumbo v10, "ttsibae"

    const-string v10, "bitrate"

    iget v11, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->targetBitrateBps:I

    invoke-virtual {v0, v10, v11}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    iget v10, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->rcMode:I

    const/4 v11, -0x1

    if-eq v10, v11, :cond_b

    if-nez v8, :cond_b

    const-string v11, "-irmmaebettu"

    const-string v11, "atmieeud-tbr"

    const-string v11, "diaeoetrobt-"

    const-string v11, "bitrate-mode"

    invoke-virtual {v0, v11, v10}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_b
    const-string/jumbo v10, "oaolpb-rmtfc"

    const-string v10, "-rcamofpoolt"

    const-string v10, "artoomufor-c"

    const-string v10, "color-format"

    iget v11, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->colorFormat:I

    invoke-virtual {v0, v10, v11}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string/jumbo v10, "qaetrrfpa-"

    const-string/jumbo v10, "rmtfaa-eqr"

    const-string v10, "afm-rartqe"

    const-string/jumbo v10, "frame-rate"

    iget v11, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->targetFps:I

    invoke-virtual {v0, v10, v11}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v10, "ersnfmvielsai-rt"

    const-string v10, "-nsvemra-rftiile"

    const-string/jumbo v10, "i-frame-interval"

    invoke-virtual {v0, v10, v7}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const/4 v7, -0x1

    if-eq v12, v7, :cond_c

    const-string/jumbo v7, "oermlfp"

    const-string/jumbo v7, "frpmleo"

    const-string/jumbo v7, "rlieoop"

    const-string/jumbo v7, "profile"

    invoke-virtual {v0, v7, v12}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v7, "bevll"

    const-string/jumbo v7, "vlleo"

    const-string/jumbo v7, "eulle"

    const-string/jumbo v7, "level"

    invoke-virtual {v0, v7, v13}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    if-eqz v8, :cond_c

    const-string/jumbo v7, "piotirrp"

    const-string/jumbo v7, "priority"

    const/4 v10, 0x1

    invoke-virtual {v0, v7, v10}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string/jumbo v7, "tyanebl"

    const-string/jumbo v7, "nqlatey"

    const-string/jumbo v7, "latency"

    const/4 v10, 0x3

    invoke-virtual {v0, v7, v10}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string v7, "armefsu-xab"

    const-string/jumbo v7, "m-sxfbaarem"

    const-string/jumbo v7, "max-bframes"

    invoke-virtual {v0, v7, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string/jumbo v7, "omemf-rsdaer-dbn_r.aeppi"

    const-string v7, "dia-narprersf_epdb-o.efm"

    const-string v7, "eerbosnpmfr.--rdda_oirea"

    const-string v7, "android._prefer-b-frames"

    const/4 v8, 0x1

    invoke-virtual {v0, v7, v8}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_c
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "o:t  b Fmq"

    const-string/jumbo v8, "m Fr:  oqt"

    const-string/jumbo v8, "m o:rau Ft"

    const-string v8, "  Format: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v15, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object v7, v9, Lcom/zego/ve/MediaCodecVideoEncoder$EncoderProperties;->codecName:Ljava/lang/String;

    invoke-static {v7}, Lcom/zego/ve/MediaCodecVideoEncoder;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object v7

    iput-object v7, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    iget-object v8, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->type:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    iput-object v8, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->type:Lcom/zego/ve/MediaCodecVideoEncoder$VideoCodecType;

    if-nez v7, :cond_d

    const-string v0, " osaeateeedca deiCnnnmrc or "

    const-string/jumbo v0, "rm eedipaeenartd  eontcCa on"

    const-string v0, "Can not create media encoder"

    invoke-static {v15, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    return v2

    :cond_d
    if-nez p11, :cond_e

    invoke-virtual {v7, v1}, Landroid/media/MediaCodec;->setCallback(Landroid/media/MediaCodec$Callback;)V

    :cond_e
    iget-object v7, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v7, v0, v8, v8, v9}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    if-eqz v6, :cond_f

    iget-object v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->createInputSurface()Landroid/view/Surface;

    move-result-object v0

    iput-object v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->inputSurface:Landroid/view/Surface;

    :cond_f
    iget-object v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->start()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_2

    if-nez v6, :cond_12

    const/4 v6, 0x0

    :try_start_1
    iput v6, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->stride:I

    iput v6, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->sliceHeight:I
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/Error; {:try_start_1 .. :try_end_1} :catch_2

    :try_start_2
    iget-object v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v0}, Landroid/media/MediaCodec;->getInputFormat()Landroid/media/MediaFormat;

    move-result-object v0

    move-object v6, v14

    move-object v6, v14

    move-object v6, v14

    move-object v6, v14

    invoke-virtual {v0, v6}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_10

    invoke-virtual {v0, v6}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v6

    iput v6, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->stride:I

    :cond_10
    move-object/from16 v6, v18

    move-object/from16 v6, v18

    move-object/from16 v6, v18

    move-object/from16 v6, v18

    invoke-virtual {v0, v6}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_11

    invoke-virtual {v0, v6}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v0

    iput v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->sliceHeight:I

    :cond_11
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "istmh :itmcateplrgnde ee nhuf   srdia"

    const-string v6, "e d esthqd: Iihrnerm us ctatigilp aef"

    const-string v6, "Input frame stride and slice height: "

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->stride:I

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-object/from16 v6, v17

    move-object/from16 v6, v17

    move-object/from16 v6, v17

    move-object/from16 v6, v17

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->sliceHeight:I

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v15, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->stride:I

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->stride:I

    iget v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->sliceHeight:I

    invoke-static {v3, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    iput v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->sliceHeight:I

    goto :goto_7

    :catch_0
    move-exception v0

    move v3, v6

    move v3, v6

    move v3, v6

    move v3, v6

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    goto :goto_8

    :catch_1
    move-exception v0

    move v3, v6

    move v3, v6

    move v3, v6

    move v3, v6

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    goto :goto_9

    :cond_12
    :goto_7
    invoke-direct {v1, v4, v5}, Lcom/zego/ve/MediaCodecVideoEncoder;->setRates(II)Z

    const/4 v0, 0x1

    iput-boolean v0, v1, Lcom/zego/ve/MediaCodecVideoEncoder;->isRunning:Z
    :try_end_2
    .catch Ljava/lang/IllegalStateException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/Error; {:try_start_2 .. :try_end_2} :catch_2

    return v0

    :catch_2
    move-exception v0

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    invoke-static {v15, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x0

    return v3

    :catch_3
    move-exception v0

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    const/4 v3, 0x0

    :goto_8
    invoke-static {}, Lcom/zego/ve/MediaCodecVideoEncoder;->printStackTrace()V

    invoke-static {v15, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-static {}, Lcom/zego/ve/MediaCodecVideoEncoder;->printStackTrace()V

    return v3

    :catch_4
    move-exception v0

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    const/4 v3, 0x0

    :goto_9
    invoke-static {v15, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-static {}, Lcom/zego/ve/MediaCodecVideoEncoder;->printStackTrace()V

    return v3

    :cond_13
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v2, " Hs2W nh6e orfor nftn4dCoeoi cdn"

    const-string/jumbo v2, "f nno C odfr2oinercd6eHho nt a4W"

    const-string/jumbo v2, "f hmdHcadfiW Cnt2 n roeeon6nr 4o"

    const-string v2, "Can not find HW encoder for h264"

    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_14
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "snsnoeoth :rbdcup  poe tti"

    const-string/jumbo v2, "p en bdoeis nsp:u croottth"

    const-string/jumbo v2, "rd nobeenipptsott h :cu os"

    const-string/jumbo v2, "not support this encoder: "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move/from16 v2, p1

    move/from16 v2, p1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v15, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    return v2

    :cond_15
    new-instance v0, Ljava/lang/RuntimeException;

    const-string/jumbo v2, "oera Fulrto(ee tou)?"

    const-string v2, " or(otuF et)elor?sea"

    const-string v2, "aF(l?osptorerote eg)"

    const-string v2, "Forgot to release()?"

    invoke-direct {v0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public onError(Landroid/media/MediaCodec;Landroid/media/MediaCodec$CodecException;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-boolean p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->isRunning:Z

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object p2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x7

    move v2, v1

    if-eqz p2, :cond_1

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p1, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Lcom/zego/ve/MediaCodecVideoEncoder;->printStackTrace()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-wide p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->pthis:J

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, p2, v0}, Lcom/zego/ve/MediaCodecVideoEncoder;->on_error(JI)I

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public onInputBufferAvailable(Landroid/media/MediaCodec;I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    iget-boolean v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->isRunning:Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->pthis:J

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0, v1, p2}, Lcom/zego/ve/MediaCodecVideoEncoder;->on_input_buffer_available(JI)I

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public onOutputBufferAvailable(Landroid/media/MediaCodec;ILandroid/media/MediaCodec$BufferInfo;)V
    .locals 12

    const/4 v11, 0x3

    iget-boolean v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->isRunning:Z

    const/4 v10, 0x2

    xor-int/2addr v11, v10

    if-eqz v0, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v11, 0x3

    if-eqz v0, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-nez p1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    goto/16 :goto_2

    :cond_0
    const/4 v11, 0x6

    iget p1, p3, Landroid/media/MediaCodec$BufferInfo;->flags:I

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    and-int/lit8 p1, p1, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    const/4 v0, 0x1

    const/4 v11, 0x4

    const/4 v1, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-eqz p1, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    move p1, v0

    move p1, v0

    const/4 v11, 0x5

    move p1, v0

    move p1, v0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    goto :goto_0

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    move p1, v1

    move p1, v1

    const/4 v11, 0x2

    move p1, v1

    move p1, v1

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-eqz p1, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string/jumbo v0, "tr efg oqanns:aedreOf .fe eCfmit"

    const-string v0, "Config frame generated. Offset: "

    const/4 v10, 0x2

    move v11, v10

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    iget v0, p3, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string v0, "S:se  zi"

    const-string v0, ". Size: "

    const/4 v11, 0x0

    const/4 v10, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget v0, p3, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v0, "adEmoeeindroecpeMVoCdi"

    const-string v0, "eEdceeopMdoiroaCVcndie"

    const/4 v11, 0x0

    const-string v0, "dMaeoCnoeiVdociedcEero"

    const-string v0, "MediaCodecVideoEncoder"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v10, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget p1, p3, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x3

    invoke-static {p1}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x6

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {p0, v1, p2}, Lcom/zego/ve/MediaCodecVideoEncoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    iget v0, p3, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget v0, p3, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget p3, p3, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    add-int/2addr v0, p3

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {p1, v0}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    iget-object p3, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->configData:Ljava/nio/ByteBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {p3, p1}, Ljava/nio/ByteBuffer;->put(Ljava/nio/ByteBuffer;)Ljava/nio/ByteBuffer;

    const/4 v10, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {p1, p2, v1}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V

    const/4 v11, 0x1

    return-void

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p0, v1, p2}, Lcom/zego/ve/MediaCodecVideoEncoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->duplicate()Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget v2, p3, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {p1, v2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget v2, p3, Landroid/media/MediaCodec$BufferInfo;->offset:I

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget v3, p3, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x3

    add-int/2addr v2, v3

    invoke-virtual {p1, v2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget v2, p3, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {p0, v2}, Lcom/zego/ve/MediaCodecVideoEncoder;->reportEncodedFrame(I)V

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    iget v2, p3, Landroid/media/MediaCodec$BufferInfo;->flags:I

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    and-int/2addr v2, v0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-eqz v2, :cond_3

    const/4 v10, 0x4

    move v11, v10

    move v7, v0

    move v7, v0

    const/4 v11, 0x4

    move v7, v0

    move v7, v0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto :goto_1

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x1

    move v7, v1

    move v7, v1

    const/4 v11, 0x1

    move v7, v1

    move v7, v1

    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v0, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object v5

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    iget v6, p3, Landroid/media/MediaCodec$BufferInfo;->size:I

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    iget-wide v8, p3, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    move v4, p2

    const/4 v11, 0x1

    move v4, p2

    move v4, p2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-direct/range {v3 .. v9}, Lcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;-><init>(ILjava/nio/ByteBuffer;IZJ)V

    const/4 v11, 0x4

    const/4 v10, 0x2

    iget-wide p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->pthis:J

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-static {p1, p2, v0}, Lcom/zego/ve/MediaCodecVideoEncoder;->on_output_buffer_available(JLcom/zego/ve/MediaCodecVideoEncoder$OutputBufferInfo;)I

    :cond_4
    :goto_2
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-void
.end method

.method public onOutputFormatChanged(Landroid/media/MediaCodec;Landroid/media/MediaFormat;)V
    .locals 2

    const/4 v1, 0x0

    return-void
.end method

.method release()V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string v0, "area bvdJasqnoErece"

    const-string v0, "easoedanqevrcJEre a"

    const/4 v7, 0x1

    const-string v0, "Java releaseEncoder"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const-string/jumbo v1, "osdVoeuMCdidciaEcenroe"

    const-string/jumbo v1, "oisaMooCdceediVdeeErcn"

    const/4 v7, 0x0

    const-string/jumbo v1, "oMniooipEddVddeceCreca"

    const-string v1, "MediaCodecVideoEncoder"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    move v7, v6

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput-boolean v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->isRunning:Z

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->inputSurface:Landroid/view/Surface;

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/view/Surface;->release()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    iput-object v2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->inputSurface:Landroid/view/Surface;

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/4 v3, 0x1

    const/4 v7, 0x2

    invoke-direct {v0, v3}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v4, Lcom/zego/ve/MediaCodecVideoEncoder$1;

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-direct {v4, p0, v0}, Lcom/zego/ve/MediaCodecVideoEncoder$1;-><init>(Lcom/zego/ve/MediaCodecVideoEncoder;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v5, Ljava/lang/Thread;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v5, v4}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-virtual {v5}, Ljava/lang/Thread;->start()V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const/4 v7, 0x4

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v0, v4, v5}, Lcom/zego/ve/ThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;J)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v0, "minMsreoqle ueoieecmtteerd a "

    const-string/jumbo v0, "ltem Moeesrt d neiueiaomecedr"

    const/4 v7, 0x5

    const-string v0, "amsliedueM to rdencesie eotar"

    const-string v0, "Media encoder release timeout"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget v0, Lcom/zego/ve/MediaCodecVideoEncoder;->codecErrors:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/2addr v0, v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    sput v0, Lcom/zego/ve/MediaCodecVideoEncoder;->codecErrors:I

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->errorCallback:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo v3, "vd mran  ar loecbkrcsErco kl.o:erIoec"

    const-string v3, " ob oorke re.:rcacodck vr IlcanslorEe"

    const/4 v7, 0x0

    const-string v3, " srrodrb c ovl.cIka ooEnee:krlcerr ac"

    const-string v3, "Invoke codec error callback. Errors: "

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget v3, Lcom/zego/ve/MediaCodecVideoEncoder;->codecErrors:I

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    sget-object v0, Lcom/zego/ve/MediaCodecVideoEncoder;->errorCallback:Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget v3, Lcom/zego/ve/MediaCodecVideoEncoder;->codecErrors:I

    const/4 v6, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-interface {v0, v3}, Lcom/zego/ve/MediaCodecVideoEncoder$MediaCodecVideoEncoderErrorCallback;->onMediaCodecVideoEncoderCriticalError(I)V

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object v2, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    sput-object v2, Lcom/zego/ve/MediaCodecVideoEncoder;->runningInstance:Lcom/zego/ve/MediaCodecVideoEncoder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v0, "Jlrn bs Eebcvanerdeaaeod"

    const-string v0, "dnaolbsJeenva codErrae e"

    const/4 v7, 0x4

    const-string/jumbo v0, "oeEJrruea cnos aveddanle"

    const-string v0, "Java releaseEncoder done"

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-void
.end method

.method releaseOutputBuffer(I)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->checkOnMediaCodecThread()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, p1, v0}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    return p1

    :catch_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "iCVddeopdMoaecreouncEd"

    const-string v1, "cMEaoouCeoeeddinrddVci"

    const/4 v4, 0x3

    const-string/jumbo v1, "rdCEoidcqedViceoenaMoe"

    const-string v1, "MediaCodecVideoEncoder"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "efsrrtfeaeOsBt aufpdueluil"

    const-string/jumbo v2, "releaseOutputBuffer failed"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v0
.end method

.method public setThis(J)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-wide p1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->pthis:J

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return p1
.end method

.method signalEOS()V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v9, 0x1

    if-nez v0, :cond_0

    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->inputSurface:Landroid/view/Surface;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0}, Landroid/media/MediaCodec;->signalEndOfInputStream()V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->dequeueInputBuffer()I

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    move v2, v0

    move v2, v0

    const/4 v9, 0x1

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v0, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x7

    if-ne v2, v0, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-wide/16 v0, 0x64

    const-wide/16 v0, 0x64

    const/4 v9, 0x5

    const-wide/16 v0, 0x64

    const-wide/16 v0, 0x64

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/zego/ve/MediaCodecVideoEncoder;->dequeueInputBuffer()I

    move-result v2
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto :goto_0

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x5

    if-ltz v2, :cond_3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoEncoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v8, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v4, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v7, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual/range {v1 .. v7}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V

    :cond_3
    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-void
.end method
