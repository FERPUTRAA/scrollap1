.class public Lcom/zego/ve/HwAudioKit;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/HwAudioKit$state;
    }
.end annotation


# static fields
.field public static final APP_CONTEXT_NULL:I = 0x7

.field public static final AUDIO_KIT_SERVICE_DIED:I = 0x6

.field public static final AUDIO_KIT_SERVICE_DISCONNECTED:I = 0x4

.field public static final AUDIO_KIT_SERVICE_LINKFAILED:I = 0x5

.field public static final AUDIO_KIT_SUCCESS:I = 0x0

.field private static final ENGINE_CLASS_NAME:Ljava/lang/String; = "com.huawei.multimedia.audioengine.HwAudioEngineService"

.field public static final GET_LATENCY_FAIL:I = -0x1

.field public static final KARAOKE_SERVICE_DIED:I = 0x3eb

.field public static final KARAOKE_SERVICE_DISCONNECTED:I = 0x3e9

.field public static final KARAOKE_SERVICE_LINKFAIL:I = 0x3ea

.field public static final KARAOKE_SUCCESS:I = 0x3e8

.field public static final KARAOKE_WIRED_HEADSET_NOT_PLUG_IN:I = 0x70d

.field public static final PARAME_VALUE_ERROR:I = 0x70f

.field public static final PLATEFORM_NOT_SUPPORT:I = 0x70e

.field public static final SERVICE_BIND_ERROR:I = -0x2

.field private static final TAG:Ljava/lang/String; = "HwAudioKit.HwAudioKit"

.field public static final VENDOR_NOT_SUPPORTED:I = 0x2


# instance fields
.field protected _callBack:Lcom/zego/ve/IAudioKitCallback;

.field protected _hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

.field protected _state:Lcom/zego/ve/HwAudioKit$state;

.field protected barrier:Ljava/util/concurrent/CountDownLatch;

.field private mConnection:Landroid/content/ServiceConnection;

.field private mContext:Landroid/content/Context;

.field private mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

.field private mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

.field private mIHwAudioEngine:Lcom/zego/ve/IHwAudioEngine;

.field private mIsServiceConnected:Z

.field private mService:Landroid/os/IBinder;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->mIHwAudioEngine:Lcom/zego/ve/IHwAudioEngine;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-boolean v1, p0, Lcom/zego/ve/HwAudioKit;->mIsServiceConnected:Z

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {}, Lcom/zego/ve/FeatureKitManager;->getInstance()Lcom/zego/ve/FeatureKitManager;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->mService:Landroid/os/IBinder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    new-instance v1, Lcom/zego/ve/HwAudioKit$1;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/zego/ve/HwAudioKit$1;-><init>(Lcom/zego/ve/HwAudioKit;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/zego/ve/HwAudioKit;->mConnection:Landroid/content/ServiceConnection;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v1, Lcom/zego/ve/HwAudioKit$2;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/zego/ve/HwAudioKit$2;-><init>(Lcom/zego/ve/HwAudioKit;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/zego/ve/HwAudioKit;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->_hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v3, 0x2

    const/4 v2, 0x5

    sget-object v1, Lcom/zego/ve/HwAudioKit$state;->state_none:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x7

    iput-object v1, p0, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x7

    and-int/2addr v3, v2

    new-instance v0, Lcom/zego/ve/HwAudioKit$3;

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/zego/ve/HwAudioKit$3;-><init>(Lcom/zego/ve/HwAudioKit;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->_callBack:Lcom/zego/ve/IAudioKitCallback;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {v1, v0}, Lcom/zego/ve/FeatureKitManager;->setCallBack(Lcom/zego/ve/IAudioKitCallback;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic access$000(Lcom/zego/ve/HwAudioKit;)Lcom/zego/ve/IHwAudioEngine;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~as ~oi1@-~@@~  ~l~~ d/~~~b@@t mf@lo.u~sty ~  i@~@@~/ @ ~ @ f  b@K@~Moo~vo@@b4~@@orS ~ci~ n@~@ ~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/zego/ve/HwAudioKit;->mIHwAudioEngine:Lcom/zego/ve/IHwAudioEngine;

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$002(Lcom/zego/ve/HwAudioKit;Lcom/zego/ve/IHwAudioEngine;)Lcom/zego/ve/IHwAudioEngine;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit;->mIHwAudioEngine:Lcom/zego/ve/IHwAudioEngine;

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-object p1
.end method

.method static synthetic access$102(Lcom/zego/ve/HwAudioKit;Z)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/zego/ve/HwAudioKit;->mIsServiceConnected:Z

    const/4 v1, 0x6

    return p1
.end method

.method static synthetic access$200(Lcom/zego/ve/HwAudioKit;)Lcom/zego/ve/FeatureKitManager;
    .locals 2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$300(Lcom/zego/ve/HwAudioKit;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$400(Lcom/zego/ve/HwAudioKit;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/zego/ve/HwAudioKit;->serviceInit(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic access$500(Lcom/zego/ve/HwAudioKit;Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/zego/ve/HwAudioKit;->serviceLinkToDeath(Landroid/os/IBinder;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic access$600(Lcom/zego/ve/HwAudioKit;)Landroid/os/IBinder$DeathRecipient;
    .locals 2

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/zego/ve/HwAudioKit;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$700(Lcom/zego/ve/HwAudioKit;)Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/zego/ve/HwAudioKit;->mService:Landroid/os/IBinder;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method static synthetic access$702(Lcom/zego/ve/HwAudioKit;Landroid/os/IBinder;)Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit;->mService:Landroid/os/IBinder;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method private bindService(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    iget-boolean v1, p0, Lcom/zego/ve/HwAudioKit;->mIsServiceConnected:Z

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/zego/ve/HwAudioKit;->mConnection:Landroid/content/ServiceConnection;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "nuamacgElinoodmumieAiSt.Hduwmiegiseennehweiic.roaedu.i"

    const-string/jumbo v2, "ndsnoiruiganioElhc.eiAdinda..imewueetegeuom.HaimSuciew"

    const/4 v4, 0x7

    const-string/jumbo v2, "w.deoaunHndSmnwiEteivehiu.oeiomgciiA.iniea.eomarulcged"

    const-string v2, "com.huawei.multimedia.audioengine.HwAudioEngineService"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, p1, v1, v2}, Lcom/zego/ve/FeatureKitManager;->bindService(Landroid/content/Context;Landroid/content/ServiceConnection;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x0

    return-void
.end method

.method private serviceInit(Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mIHwAudioEngine:Lcom/zego/ve/IHwAudioEngine;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-boolean v1, p0, Lcom/zego/ve/HwAudioKit;->mIsServiceConnected:Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    invoke-interface {v0, p1, p2}, Lcom/zego/ve/IHwAudioEngine;->init(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_0
    return-void
.end method

.method private serviceLinkToDeath(Landroid/os/IBinder;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit;->mService:Landroid/os/IBinder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mDeathRecipient:Landroid/os/IBinder$DeathRecipient;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-interface {p1, v0, v1}, Landroid/os/IBinder;->linkToDeath(Landroid/os/IBinder$DeathRecipient;I)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x5

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    :cond_0
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public createFeatureKaraoke()Z
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    const/4 v1, 0x1

    move v6, v1

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/zego/ve/FeatureKitManager;->createFeatureKit(ILandroid/content/Context;)Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->_hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x4

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x7

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v0, v3, v4, v2}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-nez v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string/jumbo v0, "o.ioAbKdudwAtitHKmHuw"

    const-string/jumbo v0, "uAtmiwiKHdt.odAiHuoKw"

    const/4 v6, 0x2

    const-string/jumbo v0, "ouKdAwu.iuAdiHioHttwi"

    const-string v0, "HwAudioKit.HwAudioKit"

    const/4 v6, 0x2

    const-string/jumbo v2, "uaeeeetpaKrouotkc iFtataoree"

    const-string/jumbo v2, "etocoKteakerar etauFiuotmaee"

    const/4 v6, 0x2

    const-string v2, "earotm uqeKurteFcoketeaeiara"

    const-string v2, "createFeatureKaraoke timeout"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v2}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x2

    move v6, v5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget-object v2, Lcom/zego/ve/HwAudioKit$state;->state_karaoke_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-ne v0, v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v1, 0x0

    :goto_1
    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    return v1
.end method

.method public destroy()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/zego/ve/HwAudioKit;->mIsServiceConnected:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-boolean v0, p0, Lcom/zego/ve/HwAudioKit;->mIsServiceConnected:Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/zego/ve/HwAudioKit;->mConnection:Landroid/content/ServiceConnection;

    const/4 v3, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1, v2}, Lcom/zego/ve/FeatureKitManager;->unbindService(Landroid/content/Context;Landroid/content/ServiceConnection;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v3, 0x3

    move v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->destroy()V

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method

.method public enableKaraokeFeature(Z)I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->enableKaraokeFeature(Z)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return p1
.end method

.method public initialize()Z
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x7

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v5, 0x0

    move v6, v5

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v2, 0x7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v2, v0}, Lcom/zego/ve/FeatureKitManager;->isMediaKitSupport(Landroid/content/Context;)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mFeatureKitManager:Lcom/zego/ve/FeatureKitManager;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v2, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->mContext:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {p0, v0}, Lcom/zego/ve/HwAudioKit;->bindService(Landroid/content/Context;)V

    :goto_0
    :try_start_0
    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x5

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v3, v4, v2}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-nez v0, :cond_2

    const/4 v6, 0x1

    const-string v0, "bAsuHudKKHodAottiwiii"

    const-string/jumbo v0, "tidiibHuoutwKoA.KAdiH"

    const/4 v6, 0x3

    const-string/jumbo v0, "woAmiAtiKuKotdHHiiwd."

    const-string v0, "HwAudioKit.HwAudioKit"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v2, "itmtozeuiituiieo n"

    const-string/jumbo v2, "iietinutuzm eoatii"

    const/4 v6, 0x4

    const-string/jumbo v2, "titazbuni imleeiit"

    const-string/jumbo v2, "initialize timeout"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v0, v2}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_1
    const/4 v6, 0x3

    const/4 v0, 0x3

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/zego/ve/HwAudioKit;->barrier:Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v6, 0x3

    const/4 v5, 0x7

    sget-object v2, Lcom/zego/ve/HwAudioKit$state;->state_audiokit_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ne v0, v2, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto :goto_2

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v1, 0x0

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v1
.end method

.method public isFeatureKaraokeOn()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_state:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v1, Lcom/zego/ve/HwAudioKit$state;->state_karaoke_success:Lcom/zego/ve/HwAudioKit$state;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0
.end method

.method public setKaraokeReverbMode(I)V
    .locals 4

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    const-string/jumbo v1, "oderoabpve=er_a_Kkre"

    const-string v1, "bd=_aruerrvoeoeaKkme"

    const-string v1, "Karaoke_reverb_mode="

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1, p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->setParameter(Ljava/lang/String;I)I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public setKaraokeVolume(I)V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/16 v0, 0x64

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-le p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    move p1, v0

    move p1, v0

    const/4 v3, 0x3

    move p1, v0

    move p1, v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/zego/ve/HwAudioKit;->_hwAudioKaraokeFeatureKit:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v1, "okeaoKup=lvrea_"

    const-string v1, "Karaoke_volume="

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->setParameter(Ljava/lang/String;I)I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
