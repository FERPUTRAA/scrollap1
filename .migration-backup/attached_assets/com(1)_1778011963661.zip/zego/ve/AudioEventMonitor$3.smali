.class Lcom/zego/ve/AudioEventMonitor$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor;->CheckPhoneState()I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$3;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    :try_start_0
    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~so~@f~tio@y s   @.f~~S~b ~t~4~u~ro  @~b@di~ a~@ o- oMnvl1@ ~@@ ~@ K~@~@@c@~@ @~@l~~~mbio@@  @/"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$3;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x2

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/zego/ve/AudioEventMonitor;->_context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, "ehsmp"

    const-string/jumbo v1, "phsne"

    const/4 v5, 0x6

    const-string/jumbo v1, "phone"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    check-cast v0, Landroid/telephony/TelephonyManager;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/telephony/TelephonyManager;->getCallState()I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$3;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x6

    iget-boolean v0, v0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    const/4 v5, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const-string/jumbo v0, "ieceov"

    const-string/jumbo v0, "veemci"

    const/4 v5, 0x0

    const-string/jumbo v0, "videcb"

    const-string v0, "device"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v1, "ec aetutrhlilcnsreptioai s l tdintuo kcer,em "

    const-string v1, "est okdtteepimrtlt iuha oecicnin lsra,uercl  "

    const/4 v5, 0x5

    const-string v1, " ceterep ca iidmuels ct onsia,huettrertlnlpi "

    const-string/jumbo v1, "interruption check call state idle, resume it"

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$3;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iput-boolean v1, v0, Lcom/zego/ve/AudioEventMonitor;->_once_call_come_in:Z

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iput-boolean v1, v0, Lcom/zego/ve/AudioEventMonitor;->_isCalling:Z

    invoke-static {v0}, Lcom/zego/ve/AudioEventMonitor;->access$100(Lcom/zego/ve/AudioEventMonitor;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/zego/ve/AudioEventMonitor$3;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/zego/ve/AudioEventMonitor;->event_notify_:Lcom/zego/ve/AudioEventMonitor$IEventNotify;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-interface {v1}, Lcom/zego/ve/AudioEventMonitor$IEventNotify;->OnInterruptionEnd()V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    throw v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v1, "beqvce"

    const-string v1, "eivecb"

    const/4 v5, 0x6

    const-string v1, "desevi"

    const-string v1, "device"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v3, "CheckPhoneState failed, "

    const-string v3, "CheckPhoneState failed, "

    const/4 v5, 0x2

    const-string v3, "CheckPhoneState failed, "

    const-string v3, "CheckPhoneState failed, "

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v0}, Lcom/zego/ve/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method
