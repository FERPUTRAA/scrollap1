.class Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/HwAudioKaraokeFeatureKit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;


# direct methods
.method constructor <init>(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@subo@ @@~~m@ ~@o Mo@f~@b~ o~ -~ @~a @i l c ~4~/t@ i@1~@K n~@b  S~l@fov@~@@~/s@.~~~~~y ~d or it"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p2}, Lcom/zego/ve/IHwAudioKaraokeFeature$Stub;->asInterface(Landroid/os/IBinder;)Lcom/zego/ve/IHwAudioKaraokeFeature;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$002(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Lcom/zego/ve/IHwAudioKaraokeFeature;)Lcom/zego/ve/IHwAudioKaraokeFeature;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$000(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/IHwAudioKaraokeFeature;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz p1, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$102(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Z)Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$200(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$300(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-gez p1, :cond_0

    const/4 v1, 0x3

    move v2, v1

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$400(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/16 p2, 0x3ea

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1, p2}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$500(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Landroid/os/IBinder;)V

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$400(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const/16 p2, 0x3e8

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$102(Lcom/zego/ve/HwAudioKaraokeFeatureKit;Z)Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$400(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object p1

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/zego/ve/HwAudioKaraokeFeatureKit$1;->this$0:Lcom/zego/ve/HwAudioKaraokeFeatureKit;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/zego/ve/HwAudioKaraokeFeatureKit;->access$400(Lcom/zego/ve/HwAudioKaraokeFeatureKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/16 v0, 0x3e9

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    :cond_0
    const/4 v2, 0x1

    return-void
.end method
