.class Lcom/zego/ve/AudioEventMonitor$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/AudioEventMonitor;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/AudioEventMonitor;

.field final synthetic val$currentOpSeq:I


# direct methods
.method constructor <init>(Lcom/zego/ve/AudioEventMonitor;I)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/AudioEventMonitor$1;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p2, p0, Lcom/zego/ve/AudioEventMonitor$1;->val$currentOpSeq:I

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " os@v~~@/~ ~ ~ b~~f ~o~t  @~~b@o@~slm@ @/@~ @~@~1n@o @ ~ri@@~t~aS d~co~@K M~ ib-@f4ul@@o i~ y@.@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$1;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/zego/ve/AudioEventMonitor;->access$000(Lcom/zego/ve/AudioEventMonitor;)I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget v1, p0, Lcom/zego/ve/AudioEventMonitor$1;->val$currentOpSeq:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Landroid/bluetooth/BluetoothAdapter;->getDefaultAdapter()Landroid/bluetooth/BluetoothAdapter;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Landroid/bluetooth/BluetoothAdapter;->getProfileConnectionState(I)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-ne v1, v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/zego/ve/AudioEventMonitor$1;->this$0:Lcom/zego/ve/AudioEventMonitor;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/zego/ve/AudioEventMonitor;->ChangeAudioRoute(I)V

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    return-void
.end method
