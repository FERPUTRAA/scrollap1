.class public final synthetic Lcom/zego/ve/q;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s~K@ fvt ~~. s @~b@r~@~ @~~~o  ~ di@iM /~ y@1o ~ ~i~@c~oo~lutab@o/@ @@S~~~~~@bf@ -@o @ ~n4 @@l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Landroid/media/ExifInterface;

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-void
.end method
