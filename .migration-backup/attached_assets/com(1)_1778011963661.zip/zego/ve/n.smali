.class public final synthetic Lcom/zego/ve/n;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/media/AudioPlaybackConfiguration;)Landroid/media/AudioAttributes;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@is@~n/@ft~~@@om yud~ba~~b@f~o ivb~M~@ i~~~@l@ @@ ~S~@1~ r@o@~ o@-~~@l~ @ t ~ ~/o K  4 @o~@ .@ s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/media/AudioPlaybackConfiguration;->getAudioAttributes()Landroid/media/AudioAttributes;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p0
.end method
