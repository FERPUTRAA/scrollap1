.class public final synthetic Lcom/zego/ve/f;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Landroid/media/AudioManager;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s  @@@~M@1@b  ioo ~u@~~b KS~/l~n cf -~~~~o il ~@@v~r@ t~@.o~~o~@oab@i @~ ~@ s@4y@@@ f~@m/ ~@d~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/media/AudioManager;->clearCommunicationDevice()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method
