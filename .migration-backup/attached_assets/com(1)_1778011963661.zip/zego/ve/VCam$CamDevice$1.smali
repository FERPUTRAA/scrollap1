.class Lcom/zego/ve/VCam$CamDevice$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/hardware/Camera$AutoFocusCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/VCam$CamDevice;->startCam(Z)I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/zego/ve/VCam$CamDevice;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam$CamDevice;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/zego/ve/VCam$CamDevice$1;->this$1:Lcom/zego/ve/VCam$CamDevice;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onAutoFocus(ZLandroid/hardware/Camera;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "n@s~KS@~ ~s@too   ~@1-o@~@b  ~~ ~/o~~avo @~~@.@~~lyurm Mi@  4c~l o~@ft/ ~ib@i~@b @ @@d  f~~~@~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const-string/jumbo v0, "ufsm ctv:es s:c supsoesc"

    const-string v0, ":csssccev tefp suuso:c s"

    const/4 v2, 0x3

    const-string v0, " o uosects:vcscseucap: f"

    const-string/jumbo v0, "vcap: set focus success:"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string p2, "cavp"

    const-string/jumbo p2, "vcap"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x1

    and-int/2addr v2, v1

    iget-object p1, p0, Lcom/zego/ve/VCam$CamDevice$1;->this$1:Lcom/zego/ve/VCam$CamDevice;

    const/4 v2, 0x4

    iget-object p1, p1, Lcom/zego/ve/VCam$CamDevice;->this$0:Lcom/zego/ve/VCam;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p2, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-boolean p2, p1, Lcom/zego/ve/VCam;->mIsFocusing:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method
