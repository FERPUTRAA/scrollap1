.class public Lcom/zego/ve/VeBitmap;
.super Ljava/lang/Object;


# static fields
.field private static final TAG:Ljava/lang/String; = "VeBitmap"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method

.method public static calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s~ ~u ~M @bb@@~ mt i@/~~@@l ~d  s~@rl  @~o~@~@o@b@a~~1~@o@@cK.  ~~ @~f/-nto~i~~4f o~~iv@ oy@@S"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget v0, p0, Landroid/graphics/BitmapFactory$Options;->outHeight:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget p0, p0, Landroid/graphics/BitmapFactory$Options;->outWidth:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-gt v0, p2, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-le p0, p1, :cond_1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    div-int/lit8 v0, v0, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    div-int/lit8 p0, p0, 0x2

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    div-int v2, v0, v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-lt v2, p2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    div-int v2, p0, v1

    const/4 v4, 0x7

    if-lt v2, p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    mul-int/lit8 v1, v1, 0x2

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1
.end method

.method public static createBitmapRGBA(II)Landroid/graphics/Bitmap;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    const/4 v2, 0x6

    const/4 v1, 0x0

    invoke-static {p0, p1, v0}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public static getBitmap(Landroid/content/Context;IILjava/lang/String;)Landroid/graphics/Bitmap;
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 v0, 0x3a

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-ne v0, v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object v2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p3, v1, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p3, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, "essmt"

    const-string v3, "essta"

    const/4 v5, 0x6

    const-string v3, "assto"

    const-string v3, "asset"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p0, v0}, Lcom/zego/ve/VeBitmap;->getBitmapFromAsset(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0

    :cond_1
    const/4 v4, 0x0

    move v5, v4

    const-string v3, "eilf"

    const-string/jumbo v3, "ilef"

    const/4 v5, 0x1

    const-string/jumbo v3, "lfie"

    const-string/jumbo v3, "file"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-nez v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p0, p1, p2, v0}, Lcom/zego/ve/VeBitmap;->getBitmapFromPath(Landroid/content/Context;IILjava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-object p0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v0, "otmtnbc"

    const-string/jumbo v0, "ntomect"

    const/4 v5, 0x1

    const-string v0, "content"

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-nez v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p0, p1, p2, p3}, Lcom/zego/ve/VeBitmap;->getBitmapFromUri(Landroid/content/Context;IILjava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v5, 0x2

    return-object p0

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object v2
.end method

.method public static getBitmapFromAsset(Landroid/content/Context;Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v1, 0x17

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-le p1, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lcom/zego/ve/q;->a()V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/zego/ve/p;->a(Ljava/io/InputStream;)Landroid/media/ExifInterface;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo p1, "roiintutoOe"

    const-string p1, "eitnonritOo"

    const/4 v3, 0x4

    const-string p1, "Orientation"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1, v1}, Landroid/media/ExifInterface;->getAttributeInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, v0}, Lcom/zego/ve/VeBitmap;->rotateBitmap(ILandroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0
.end method

.method public static getBitmapFromPath(Landroid/content/Context;IILjava/lang/String;)Landroid/graphics/Bitmap;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 p0, 0x0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v0, Landroid/graphics/BitmapFactory$Options;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v4, 0x1

    const/4 v1, 0x1

    const/4 v4, 0x6

    xor-int/2addr v3, v1

    const/4 v4, 0x3

    iput-boolean v1, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p3, v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-boolean v2, v0, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v4, 0x0

    invoke-static {v0, p1, p2}, Lcom/zego/ve/VeBitmap;->calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    iput p1, v0, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    const/4 v4, 0x1

    invoke-static {p3, v0}, Landroid/graphics/BitmapFactory;->decodeFile(Ljava/lang/String;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance p1, Landroid/media/ExifInterface;

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p1, p3}, Landroid/media/ExifInterface;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo p2, "iraioObpnet"

    const-string p2, "Onairbieont"

    const/4 v4, 0x3

    const-string/jumbo p2, "niaroiOtqtn"

    const-string p2, "Orientation"

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-virtual {p1, p2, v1}, Landroid/media/ExifInterface;->getAttributeInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, p0}, Lcom/zego/ve/VeBitmap;->rotateBitmap(ILandroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method public static getBitmapFromUri(Landroid/content/Context;IILjava/lang/String;)Landroid/graphics/Bitmap;
    .locals 5

    const/4 v4, 0x3

    invoke-static {p3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "r"

    const-string/jumbo v1, "r"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p0, p3, v1}, Landroid/content/ContentResolver;->openFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/os/ParcelFileDescriptor;->getFileDescriptor()Ljava/io/FileDescriptor;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance p3, Landroid/graphics/BitmapFactory$Options;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {p3}, Landroid/graphics/BitmapFactory$Options;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-boolean v1, p3, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v4, 0x6

    invoke-static {p0, v0, p3}, Landroid/graphics/BitmapFactory;->decodeFileDescriptor(Ljava/io/FileDescriptor;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-boolean v2, p3, Landroid/graphics/BitmapFactory$Options;->inJustDecodeBounds:Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-static {p3, p1, p2}, Lcom/zego/ve/VeBitmap;->calculateInSampleSize(Landroid/graphics/BitmapFactory$Options;II)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput p1, p3, Landroid/graphics/BitmapFactory$Options;->inSampleSize:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-static {p0, v0, p3}, Landroid/graphics/BitmapFactory;->decodeFileDescriptor(Ljava/io/FileDescriptor;Landroid/graphics/Rect;Landroid/graphics/BitmapFactory$Options;)Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 p2, 0x17

    const/4 v4, 0x6

    const/4 v3, 0x3

    if-le p1, p2, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {}, Lcom/zego/ve/q;->a()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/zego/ve/r;->a(Ljava/io/FileDescriptor;)Landroid/media/ExifInterface;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo p1, "ttsiuarOnie"

    const-string/jumbo p1, "ritnnOuetia"

    const/4 v4, 0x6

    const-string p1, "Oetmaoiitnr"

    const-string p1, "Orientation"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p1, v1}, Landroid/media/ExifInterface;->getAttributeInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p0, v0}, Lcom/zego/ve/VeBitmap;->rotateBitmap(ILandroid/graphics/Bitmap;)Landroid/graphics/Bitmap;

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-object v0
.end method

.method public static rotateBitmap(ILandroid/graphics/Bitmap;)Landroid/graphics/Bitmap;
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v0, 0x3

    const/4 v7, 0x1

    move v8, v7

    if-eq p0, v0, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v0, 0x6

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eq p0, v0, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/16 v0, 0x8

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-eq p0, v0, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 p0, 0x4

    const/4 p0, 0x0

    const/4 v7, 0x5

    move v8, v7

    goto :goto_0

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    const/16 p0, 0x10e

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/16 p0, 0x5a

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_0

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/16 p0, 0xb4

    :goto_0
    const/4 v7, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-instance v5, Landroid/graphics/Matrix;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct {v5}, Landroid/graphics/Matrix;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    int-to-float p0, p0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v5, p0}, Landroid/graphics/Matrix;->postRotate(F)Z

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    const/4 v6, 0x1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    invoke-static/range {v0 .. v6}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x5

    return-object p0
.end method

.method public static saveBitmap(Landroid/graphics/Bitmap;)I
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Ljava/io/File;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "so-toasnh"

    const-string/jumbo v2, "nhsast-po"

    const/4 v5, 0x2

    const-string v2, "aph-nbsst"

    const-string/jumbo v2, "snapshot-"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v2, "jg.p"

    const-string v2, ".pjg"

    const/4 v5, 0x7

    const-string/jumbo v2, "jgp."

    const-string v2, ".jpg"

    const/4 v4, 0x1

    shl-int/2addr v5, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, "aqrc/dud"

    const-string/jumbo v2, "qcr/dad/"

    const/4 v5, 0x0

    const-string/jumbo v2, "s/adrc/p"

    const-string v2, "/sdcard/"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v0, v2, v1}, Ljava/io/File;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v1, Ljava/io/FileOutputStream;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v0, Landroid/graphics/Bitmap$CompressFormat;->JPEG:Landroid/graphics/Bitmap$CompressFormat;

    const/4 v4, 0x7

    const/4 v4, 0x4

    const/16 v2, 0x50

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0, v0, v2, v1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/io/OutputStream;->flush()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/io/FileOutputStream;->close()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    return p0

    :catch_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 p0, -0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    return p0
.end method
