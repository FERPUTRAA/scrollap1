.class public Lcom/zego/ve/MediaCodecVideoDecoder;
.super Ljava/lang/Object;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x10
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;,
        Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;,
        Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;
    }
.end annotation


# static fields
.field private static final COLOR_FormatYUV420Flexible:I = 0x7f420888

.field private static final COLOR_QCOM_FORMATYUV420PackedSemiPlanar32m:I = 0x7fa30c04

.field private static final COLOR_QCOM_FormatYUV420PackedSemiPlanar64x32Tile2m8ka:I = 0x7fa30c03

.field private static final DEQUEUE_INPUT_TIMEOUT:I = 0x7a120

.field private static final FORMAT_KEY_CROP_BOTTOM:Ljava/lang/String; = "crop-bottom"

.field private static final FORMAT_KEY_CROP_LEFT:Ljava/lang/String; = "crop-left"

.field private static final FORMAT_KEY_CROP_RIGHT:Ljava/lang/String; = "crop-right"

.field private static final FORMAT_KEY_CROP_TOP:Ljava/lang/String; = "crop-top"

.field private static final FORMAT_KEY_SLICE_HEIGHT:Ljava/lang/String; = "slice-height"

.field private static final FORMAT_KEY_STRIDE:Ljava/lang/String; = "stride"

.field private static final H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

.field private static final H264_MIME_TYPE:Ljava/lang/String; = "video/avc"

.field private static final H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

.field private static final HEVC_MIME_TYPE:Ljava/lang/String; = "video/hevc"

.field private static final HW_BLACKLISTS:[Ljava/lang/String;

.field private static final HW_SURFACE_BLACKLISTS:[Ljava/lang/String;

.field private static final MAX_QUEUED_OUTPUTBUFFERS:I = 0x3

.field private static final MEDIA_CODEC_RELEASE_TIMEOUT_MS:I = 0x1388

.field private static final TAG:Ljava/lang/String; = "MediaCodecVideoDecoder"

.field private static final VIDEO_CODEC_H264:I = 0x2

.field private static final VIDEO_CODEC_HEVC:I = 0x3

.field private static final VIDEO_CODEC_VP8:I = 0x0

.field private static final VIDEO_CODEC_VP9:I = 0x1

.field private static final VP8_MIME_TYPE:Ljava/lang/String; = "video/x-vnd.on2.vp8"

.field private static final VP9_MIME_TYPE:Ljava/lang/String; = "video/x-vnd.on2.vp9"

.field private static codecErrors:I

.field private static enableWhitelist:Z

.field private static errorCallback:Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;

.field private static hwDecoderDisabledTypes:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static runningInstance:Lcom/zego/ve/MediaCodecVideoDecoder;

.field private static final supportedColorList:[I

.field private static final supportedH264HwCodecPrefixes:[Ljava/lang/String;

.field private static final supportedHEVCHwCodecPrefixes:[Ljava/lang/String;

.field private static final supportedSurfaceColorList:[I

.field private static final supportedVp8HwCodecPrefixes:[Ljava/lang/String;

.field private static final supportedVp9HwCodecPrefixes:[Ljava/lang/String;


# instance fields
.field private codecName:Ljava/lang/String;

.field private colorFormat:I

.field private cropLeft:I

.field private cropTop:I

.field private hasDecodedFirstFrame:Z

.field private height:I

.field private inputBuffers:[Ljava/nio/ByteBuffer;

.field private isImageReader:Z

.field private mediaCodec:Landroid/media/MediaCodec;

.field private mediaCodecThread:Ljava/lang/Thread;

.field private outputBuffers:[Ljava/nio/ByteBuffer;

.field private sliceHeight:I

.field private stride:I

.field private surface:Landroid/view/Surface;

.field private width:I


# direct methods
.method static constructor <clinit>()V
    .locals 18

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const-string v1, "OXsom.Mcq"

    const-string v1, "OMX.qcom."

    const-string/jumbo v2, "iMOmsXhi."

    const-string v2, "Xis.hMOsi"

    const-string/jumbo v2, "hsi.oOi.M"

    const-string v2, "OMX.hisi."

    const-string v3, "G.ImMbXM"

    const-string v3, "M.ImGOMX"

    const-string v3, "OMX.IMG."

    const-string v4, "a.oOdiuXMNv"

    const-string v4, "MXOvoaiN.id"

    const-string v4, ".aNXiOdp.iM"

    const-string v4, "OMX.Nvidia."

    const-string v5, "MyEOnsoXq.."

    const-string v5, "OMX.Exynos."

    const-string v6, ".MsOIXtebn"

    const-string v6, ".OXenbMI.t"

    const-string v6, ".eMmXIn.tO"

    const-string v6, "OMX.Intel."

    filled-new-array/range {v1 .. v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedVp8HwCodecPrefixes:[Ljava/lang/String;

    const-string v0, "MqX.o.cuO"

    const-string/jumbo v0, "mOcX.quM."

    const-string v0, "OoMX.bqc."

    const-string v0, "OMX.qcom."

    const-string v1, "OsXxnouyEp."

    const-string/jumbo v1, "sX.MoOxpEny"

    const-string v1, "OMX.Exynos."

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedVp9HwCodecPrefixes:[Ljava/lang/String;

    const-string/jumbo v1, "mcXM.Oqpo"

    const-string/jumbo v1, "mcMoXOq.q"

    const-string/jumbo v1, "qXMc..Omq"

    const-string v1, "OMX.qcom."

    const-string v2, "M.sxXoEn.yO"

    const-string/jumbo v2, "nMsEox..yOX"

    const-string/jumbo v2, "nyOmo.sXxEM"

    const-string v2, "OMX.Exynos."

    const-string v3, ".KMmoXOM"

    const-string v3, ".XMmKMO."

    const-string v3, "MT.MXb.K"

    const-string v3, "OMX.MTK."

    const-string/jumbo v4, "iXsO.iuoM"

    const-string v4, "XO.Moiis."

    const-string/jumbo v4, "ihOsM..pi"

    const-string v4, "OMX.hisi."

    const-string/jumbo v5, "qIMbG.MO"

    const-string v5, ".GIMOb.M"

    const-string v5, ".MsMOGXI"

    const-string v5, "OMX.IMG."

    const-string v6, "3kXmO.M"

    const-string v6, ".M3kOXu"

    const-string v6, ".MO3okX"

    const-string v6, "OMX.k3."

    const-string v7, "XTOM.bI"

    const-string/jumbo v7, "p.XTMOI"

    const-string v7, ".XITO.u"

    const-string v7, "OMX.TI."

    const-string/jumbo v8, "p.Mr.qX"

    const-string v8, ".qMXr.O"

    const-string v8, ".qXMO.k"

    const-string v8, "OMX.rk."

    const-string v9, "..socsamlgiO"

    const-string v9, "cMsiOgam.l.o"

    const-string v9, "almm.i.oXOcg"

    const-string v9, "OMX.amlogic."

    const-string/jumbo v10, "tIOnolX.Me"

    const-string v10, "MlemOXtIn."

    const-string v10, ".e.nlbOMXI"

    const-string v10, "OMX.Intel."

    const-string/jumbo v11, "iiNMdvuO.Xo"

    const-string v11, "N.idoiMXaOv"

    const-string v11, ".iX.MONpaiv"

    const-string v11, "OMX.Nvidia."

    const-string v12, "O.rlMnbeqnaXl."

    const-string v12, "Xalnnbr.M.Olew"

    const-string/jumbo v12, "l.sMi.rlanneOX"

    const-string v12, "OMX.allwinner."

    const-string v13, ".OXmSMu"

    const-string v13, "MXS.O.u"

    const-string v13, "X.MSo.O"

    const-string v13, "OMX.MS."

    const-string v14, "atk.rbX.OleM"

    const-string v14, "OMX.realtek."

    const-string v15, "XOeeeMucl.Fpsa"

    const-string v15, "FecrseMpaOXe.l"

    const-string v15, "eFlr..cpMOXase"

    const-string v15, "OMX.Freescale."

    const-string v16, ".dXsMqr.q"

    const-string/jumbo v16, "pMX.rsd.q"

    const-string/jumbo v16, "spsMOX.d."

    const-string v16, "OMX.sprd."

    const-string/jumbo v17, "qtsci.2"

    const-string v17, ".iqm2.c"

    const-string v17, "c2.qti."

    filled-new-array/range {v1 .. v17}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedH264HwCodecPrefixes:[Ljava/lang/String;

    const-string v1, ".moXoOqmc"

    const-string v1, ".o.mmOXqc"

    const-string v1, "XOMc.b.qm"

    const-string v1, "OMX.qcom."

    const-string v2, "OsMoX.uh."

    const-string v2, ".Ms.oiXOh"

    const-string/jumbo v2, "si.M.XipO"

    const-string v2, "OMX.hisi."

    const-string/jumbo v3, "qbMGX..M"

    const-string v3, "IMMG.bX."

    const-string v3, ".IsXG.MM"

    const-string v3, "OMX.IMG."

    const-string v4, "eMlmI.tnuX"

    const-string v4, "M..nXluIet"

    const-string/jumbo v4, "lIOeo.nXMt"

    const-string v4, "OMX.Intel."

    const-string v5, "TMpXObK"

    const-string/jumbo v5, "pTK.OMX"

    const-string v5, "MTMOK.u"

    const-string v5, "OMX.MTK"

    const-string v6, "Onoyq.XpMxs"

    const-string v6, "Myox.sXOq.n"

    const-string/jumbo v6, "nxyoX.EsqOM"

    const-string v6, "OMX.Exynos."

    const-string v7, "cqsit.2"

    const-string/jumbo v7, "iqsct2."

    const-string v7, ".i.m2tc"

    const-string v7, "c2.qti."

    filled-new-array/range {v1 .. v7}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedHEVCHwCodecPrefixes:[Ljava/lang/String;

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const v0, 0x7f000789

    const v1, 0x7f420888

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedSurfaceColorList:[I

    const/4 v0, 0x1

    sput-boolean v0, Lcom/zego/ve/MediaCodecVideoDecoder;->enableWhitelist:Z

    const-string/jumbo v1, "ooegoxmg..m"

    const-string/jumbo v1, "golmo.xm.eg"

    const-string/jumbo v1, "g.ogobxleom"

    const-string/jumbo v1, "omx.google."

    const-string/jumbo v2, "xefogoufmp."

    const-string/jumbo v2, "gmofo.fexmp"

    const-string/jumbo v2, "f.pmf.mpoxg"

    const-string/jumbo v2, "omx.ffmpeg."

    const-string/jumbo v3, "pbqxm."

    const-string/jumbo v3, "xp.mvb"

    const-string v3, ".xspom"

    const-string/jumbo v3, "omx.pv"

    const-string v4, ".3pmk.exgf.fmm"

    const-string/jumbo v4, "omx.k3.ffmpeg."

    const-string v5, "acm.odoe.uxo"

    const-string v5, "ao.dxoucme.c"

    const-string/jumbo v5, "exoa.bcdmcv."

    const-string/jumbo v5, "omx.avcodec."

    const-string/jumbo v6, "m..ioxutitm"

    const-string/jumbo v6, "omx.ittiam."

    const-string/jumbo v7, "omx.sec.avc.sw."

    const-string/jumbo v8, "xleep4dpoarvr.i.dmdol2hcev6eo"

    const-string v8, "coa.iehprx2ddeoolev4lmd.vme6r"

    const-string/jumbo v8, "i6.crlexqeevdl.domo4doer2.mhv"

    const-string/jumbo v8, "omx.marvell.video.h264decoder"

    filled-new-array/range {v1 .. v8}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->HW_BLACKLISTS:[Ljava/lang/String;

    const-string v0, "MMs..qX"

    const-string v0, ".q.MMSX"

    const-string v0, "S.MmMO."

    const-string v0, "OMX.MS."

    const-string/jumbo v1, "sKTMoMO"

    const-string v1, "KTsOM.M"

    const-string v1, "OKMT.bM"

    const-string v1, "OMX.MTK"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->HW_SURFACE_BLACKLISTS:[Ljava/lang/String;

    const-string v0, "VC1A1mu"

    const-string v0, "C1VmA81"

    const-string/jumbo v0, "pC1V188"

    const-string v0, "V1818CA"

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v1

    sput-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    return-void

    :array_0
    .array-data 4
        0x13
        0x7f420888
        0x15
        0x7fa30c00
        0x7fa30c04
        0x7fa30c03
        0x7f000100
        0x7f000789
    .end array-data
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    move v2, v0

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x7

    move v2, v1

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x6

    shr-int/2addr v2, v1

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->codecName:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic access$000(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/media/MediaCodec;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~b~K@b~oqds  ~bn~@~@~ @~tvy@~~/~oS o~4r.@@ f@t~l@ ~~ o1ia@~~@m@ c@~@f@-@i  l o~@  ~@/ ~@u M~i@  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iget-object p0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic access$002(Lcom/zego/ve/MediaCodecVideoDecoder;Landroid/media/MediaCodec;)Landroid/media/MediaCodec;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p1
.end method

.method static synthetic access$100(Lcom/zego/ve/MediaCodecVideoDecoder;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iget-boolean p0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->isImageReader:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return p0
.end method

.method static synthetic access$200(Lcom/zego/ve/MediaCodecVideoDecoder;)Landroid/view/Surface;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    iget-object p0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$202(Lcom/zego/ve/MediaCodecVideoDecoder;Landroid/view/Surface;)Landroid/view/Surface;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method private checkOnMediaCodecThread()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    cmp-long v0, v0, v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v2, "oesD  ei adCr ryodioMvoadosoidpcurVeeeteedencl"

    const-string v2, "MediaCodecVideoDecoder previously operated on "

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v2, " i mnbo oaltndces uwl "

    const-string v2, " but is now called on "

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    throw v0
.end method

.method private dequeueInputBuffer()I
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-wide/32 v1, 0x7a120

    const-wide/32 v1, 0x7a120

    const/4 v4, 0x6

    const-wide/32 v1, 0x7a120

    const-wide/32 v1, 0x7a120

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/media/MediaCodec;->dequeueInputBuffer(J)I

    move-result v0
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "erddoeoVodceMaidiCoeDc"

    const-string v1, "eoVdoeraMoCiDddcoecide"

    const/4 v4, 0x2

    const-string v1, "eiocrbViaedcoeDdCddMoe"

    const-string v1, "MediaCodecVideoDecoder"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v2, "iq upeuteudfnBatbfdeefIrle"

    const-string v2, "I ulebuaetirBfpdfeeedtunfq"

    const/4 v4, 0x7

    const-string/jumbo v2, "pBtruiepn efudeqetludaufef"

    const-string v2, "dequeueIntputBuffer failed"

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 v0, -0x2

    const/4 v4, 0x5

    return v0
.end method

.method private dequeueOutputBuffer(I)Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;
    .locals 20

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    invoke-direct/range {p0 .. p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    new-instance v1, Landroid/media/MediaCodec$BufferInfo;

    invoke-direct {v1}, Landroid/media/MediaCodec$BufferInfo;-><init>()V

    :cond_0
    :goto_0
    iget-object v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    move/from16 v4, p1

    move/from16 v4, p1

    move/from16 v4, p1

    move/from16 v4, p1

    int-to-long v5, v4

    invoke-virtual {v3, v5, v6}, Ljava/util/concurrent/TimeUnit;->toMicros(J)J

    move-result-wide v5

    invoke-virtual {v2, v1, v5, v6}, Landroid/media/MediaCodec;->dequeueOutputBuffer(Landroid/media/MediaCodec$BufferInfo;J)I

    move-result v8

    const/4 v2, -0x3

    if-eq v8, v2, :cond_0

    const/4 v2, -0x2

    const-string/jumbo v3, "oocedidiqeerCecdeVDduo"

    const-string v3, "CiaeoruocoddcieDdedeVe"

    const-string v3, "MediaCodecVideoDecoder"

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v8, v2, :cond_6

    const/4 v2, -0x1

    if-eq v8, v2, :cond_5

    iget-boolean v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hasDecodedFirstFrame:Z

    xor-int/lit8 v18, v2, 0x1

    iput-boolean v5, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hasDecodedFirstFrame:Z

    iget v2, v1, Landroid/media/MediaCodec$BufferInfo;->flags:I

    and-int/lit8 v2, v2, 0x4

    if-eqz v2, :cond_1

    move/from16 v19, v5

    move/from16 v19, v5

    move/from16 v19, v5

    move/from16 v19, v5

    goto :goto_1

    :cond_1
    move/from16 v19, v6

    move/from16 v19, v6

    move/from16 v19, v6

    move/from16 v19, v6

    :goto_1
    if-eqz v19, :cond_2

    const-string v2, "OSspEp uut"

    const-string/jumbo v2, "upESo tpOu"

    const-string/jumbo v2, "ttSmpou EO"

    const-string/jumbo v2, "output EOS"

    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_2
    iget v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    const v3, 0x7f420888

    if-eq v2, v3, :cond_3

    invoke-virtual {v0, v6, v8}, Lcom/zego/ve/MediaCodecVideoDecoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object v9

    iget v2, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    invoke-virtual {v9, v2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget v2, v1, Landroid/media/MediaCodec$BufferInfo;->offset:I

    iget v3, v1, Landroid/media/MediaCodec$BufferInfo;->size:I

    add-int/2addr v2, v3

    invoke-virtual {v9, v2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    new-instance v2, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;

    iget-wide v10, v1, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move/from16 v12, v18

    move/from16 v12, v18

    move/from16 v12, v18

    move/from16 v13, v19

    move/from16 v13, v19

    move/from16 v13, v19

    move/from16 v13, v19

    invoke-direct/range {v7 .. v13}, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;-><init>(ILjava/nio/ByteBuffer;JZZ)V

    return-object v2

    :cond_3
    iget-object v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v2, v8}, Landroid/media/MediaCodec;->getOutputImage(I)Landroid/media/Image;

    move-result-object v2

    invoke-virtual {v2}, Landroid/media/Image;->getPlanes()[Landroid/media/Image$Plane;

    move-result-object v2

    aget-object v3, v2, v5

    invoke-virtual {v3}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v5, :cond_4

    aget-object v3, v2, v4

    invoke-virtual {v3}, Landroid/media/Image$Plane;->getPixelStride()I

    move-result v3

    if-ne v3, v5, :cond_4

    move v15, v5

    move v15, v5

    move v15, v5

    move v15, v5

    goto :goto_2

    :cond_4
    move v15, v6

    move v15, v6

    move v15, v6

    move v15, v6

    :goto_2
    new-instance v3, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;

    aget-object v7, v2, v6

    invoke-virtual {v7}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v9

    aget-object v7, v2, v5

    invoke-virtual {v7}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v10

    aget-object v7, v2, v4

    invoke-virtual {v7}, Landroid/media/Image$Plane;->getBuffer()Ljava/nio/ByteBuffer;

    move-result-object v11

    aget-object v6, v2, v6

    invoke-virtual {v6}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v12

    aget-object v5, v2, v5

    invoke-virtual {v5}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v13

    aget-object v2, v2, v4

    invoke-virtual {v2}, Landroid/media/Image$Plane;->getRowStride()I

    move-result v14

    iget-wide v1, v1, Landroid/media/MediaCodec$BufferInfo;->presentationTimeUs:J

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-wide/from16 v16, v1

    invoke-direct/range {v7 .. v19}, Lcom/zego/ve/MediaCodecVideoDecoder$DecodedOutputBuffer;-><init>(ILjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;Ljava/nio/ByteBuffer;IIIZJZZ)V

    return-object v3

    :cond_5
    const/4 v1, 0x0

    return-object v1

    :cond_6
    iget-object v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {v2}, Landroid/media/MediaCodec;->getOutputFormat()Landroid/media/MediaFormat;

    move-result-object v2

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, ":otdoar ce d ncgemaDrfho"

    const-string v8, "aDm eodoqe f:crdrhca ngt"

    const-string v8, "dado:bDotehc r cenmgar f"

    const-string v8, "Decoder format changed: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Landroid/media/MediaFormat;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v3, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const-string/jumbo v7, "sefc-outl"

    const-string/jumbo v7, "ofstel-rc"

    const-string v7, "clf-reopp"

    const-string v7, "crop-left"

    invoke-virtual {v2, v7}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v8

    if-eqz v8, :cond_7

    const-string/jumbo v8, "rotgihcpqm"

    const-string/jumbo v8, "ochmptgr-i"

    const-string/jumbo v8, "iostphr-rg"

    const-string v8, "crop-right"

    invoke-virtual {v2, v8}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_7

    const-string v9, "cormotpobot"

    const-string/jumbo v9, "opt-obrcoto"

    const-string/jumbo v9, "t-ocotoborm"

    const-string v9, "crop-bottom"

    invoke-virtual {v2, v9}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_7

    const-string/jumbo v10, "r-obtbpp"

    const-string/jumbo v10, "t-ropbop"

    const-string/jumbo v10, "oorp-cut"

    const-string v10, "crop-top"

    invoke-virtual {v2, v10}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_7

    invoke-virtual {v2, v10}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v10

    iput v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->cropTop:I

    invoke-virtual {v2, v7}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v7

    iput v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->cropLeft:I

    invoke-virtual {v2, v8}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v7

    iget v8, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->cropLeft:I

    sub-int/2addr v7, v8

    add-int/2addr v7, v5

    invoke-virtual {v2, v9}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v8

    iget v9, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->cropTop:I

    sub-int/2addr v8, v9

    add-int/2addr v8, v5

    goto :goto_3

    :cond_7
    iput v6, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->cropTop:I

    iput v6, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->cropLeft:I

    move v7, v6

    move v7, v6

    move v7, v6

    move v7, v6

    move v8, v7

    move v8, v7

    move v8, v7

    move v8, v7

    :goto_3
    const-string/jumbo v5, "ihpdu"

    const-string v5, "duiwh"

    const-string v5, "dtiqw"

    const-string/jumbo v5, "width"

    invoke-virtual {v2, v5}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_8

    const-string v9, "egsihp"

    const-string/jumbo v9, "hphige"

    const-string/jumbo v9, "htemgi"

    const-string/jumbo v9, "height"

    invoke-virtual {v2, v9}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_8

    invoke-virtual {v2, v5}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v5

    invoke-virtual {v2, v9}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v9

    goto :goto_4

    :cond_8
    move v5, v6

    move v5, v6

    move v5, v6

    move v9, v5

    move v9, v5

    move v9, v5

    :goto_4
    iget-boolean v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hasDecodedFirstFrame:Z

    if-nez v10, :cond_a

    if-eqz v5, :cond_9

    if-eqz v9, :cond_9

    iget v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    if-gt v5, v10, :cond_9

    iget v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    if-gt v9, v10, :cond_9

    iput v5, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    iput v9, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    :cond_9
    if-eqz v7, :cond_b

    if-eqz v8, :cond_b

    iget v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    if-gt v7, v10, :cond_b

    iget v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    if-gt v8, v10, :cond_b

    iput v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    iput v8, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    goto :goto_5

    :cond_a
    iget v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    if-ne v5, v7, :cond_13

    iget v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    if-ne v9, v7, :cond_13

    :cond_b
    :goto_5
    if-eqz v9, :cond_c

    iput v9, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    :cond_c
    iget-object v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->codecName:Ljava/lang/String;

    const-string/jumbo v8, "rX.OoM"

    const-string v8, "O.qMrX"

    const-string v8, "X.OkMb"

    const-string v8, "OMX.rk"

    invoke-virtual {v7, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    const/16 v8, 0x15

    if-eqz v7, :cond_d

    iget v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    if-ne v7, v8, :cond_d

    iput v8, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    goto :goto_6

    :cond_d
    const-string v7, "-tmasruoroof"

    const-string/jumbo v7, "orsofr-aotlm"

    const-string/jumbo v7, "olfo-atporrc"

    const-string v7, "color-format"

    invoke-virtual {v2, v7}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_e

    invoke-virtual {v2, v7}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v7

    iput v7, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v10, "xoCl:0 mq"

    const-string/jumbo v10, "l0rm xo:C"

    const-string/jumbo v10, "o0solC :x"

    const-string v10, "Color: 0x"

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v10, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    invoke-static {v10}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v3, v7}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_e
    :goto_6
    const-string/jumbo v7, "termis"

    const-string/jumbo v7, "tsrioe"

    const-string/jumbo v7, "riedos"

    const-string/jumbo v7, "stride"

    invoke-virtual {v2, v7}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_f

    invoke-virtual {v2, v7}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v5

    iput v5, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->stride:I

    goto :goto_7

    :cond_f
    iput v5, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->stride:I

    :goto_7
    const-string/jumbo v5, "hti-gbbleehi"

    const-string v5, "eghe-biclthi"

    const-string v5, "e-lehiuhcist"

    const-string/jumbo v5, "slice-height"

    invoke-virtual {v2, v5}, Landroid/media/MediaFormat;->containsKey(Ljava/lang/String;)Z

    move-result v7

    if-eqz v7, :cond_10

    invoke-virtual {v2, v5}, Landroid/media/MediaFormat;->getInteger(Ljava/lang/String;)I

    move-result v2

    iput v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    :cond_10
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "udeumitpnl:eh ufr tepsa sre  gitOtah c"

    const-string v5, "Oetmenuf iate ltagr:r cdup t hss iuhei"

    const-string/jumbo v5, "ricee t qOiuftes  g  itldhnustda:hepmr"

    const-string v5, "Output frame stride and slice height: "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->stride:I

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, "  x"

    const-string/jumbo v5, "x  "

    const-string/jumbo v5, "x  "

    const-string v5, " x "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v5, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    iget v3, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->stride:I

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    iput v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->stride:I

    iget v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    const/16 v3, 0x13

    if-eq v3, v2, :cond_11

    if-ne v8, v2, :cond_12

    :cond_11
    iget v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    if-eq v9, v2, :cond_12

    iget v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    iput v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    goto :goto_8

    :cond_12
    iget v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    iget v3, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    move-result v2

    iput v2, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->sliceHeight:I

    :goto_8
    iput-boolean v6, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hasDecodedFirstFrame:Z

    goto/16 :goto_0

    :cond_13
    new-instance v1, Ljava/lang/RuntimeException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "nsshannpge ific.eU oxedrcdeetzC ue "

    const-string v3, "Unexpected size change. Configured "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v3, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, "*"

    const-string v3, "*"

    const-string v3, "*"

    const-string v3, "*"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "we.m N"

    const-string v4, " pwe.N"

    const-string v4, "e . oN"

    const-string v4, ". New "

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public static disableH264HwCodec()V
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    const-string v0, "dcVCobdodaeeicdieqeMor"

    const-string v0, "eeddcVeeqerdCiMacooido"

    const/4 v3, 0x3

    const-string v0, "eoeeddureciDdCooVacidM"

    const-string v0, "MediaCodecVideoDecoder"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v1, "pec.isbp i4as .iae6idy bd2nnd dgapoloictHl"

    const-string v1, "H.264 decoding is disabled by application."

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const-string v1, "/vsoicdvq"

    const-string v1, "cosv/daiv"

    const-string/jumbo v1, "video/avc"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public static disableHEVCHwCodec()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v0, "VMsieaodecoeermdCDdieo"

    const-string v0, "VcomedieaeideMrdodeoCD"

    const/4 v3, 0x4

    const-string v0, "eoimVCideeooddMrDcdeea"

    const-string v0, "MediaCodecVideoDecoder"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v1, "EbtioHsbddg  a.lo Ca oilyaVdnsieopcinpdc "

    const-string/jumbo v1, "lo sodsel cpHa ncatCa i nibdyoVEd.dibpiig"

    const/4 v3, 0x4

    const-string v1, "c dVabnEpdo  aclgiidaiosbd iHClepbstye in"

    const-string v1, "HEVC decoding is disabled by application."

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const-string/jumbo v1, "v/hidbcvoe"

    const/4 v3, 0x7

    const-string/jumbo v1, "vvecdou/he"

    const-string/jumbo v1, "video/hevc"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public static disableVp8HwCodec()V
    .locals 4

    const-string/jumbo v0, "iadceoopieerDceduVModC"

    const-string v0, "edCddDuieeodicoeorcMaV"

    const-string/jumbo v0, "iodoCecoqdeeDediderMVa"

    const-string v0, "MediaCodecVideoDecoder"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "gls pieipni P8s styccbebiod.a dodapanVld"

    const-string v1, "ca ciaypi de lp.nltoipsbnddibV8eosP dg a"

    const/4 v3, 0x0

    const-string/jumbo v1, "pocmacspn  obdeddyaai.lb sdi niPVei8tig "

    const-string v1, "VP8 decoding is disabled by application."

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x1

    const/4 v2, 0x3

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x5

    const-string v1, "dv-noedxnoq.poi.2/v"

    const-string/jumbo v1, "nxv./d-dqiovpeon.v2"

    const/4 v3, 0x4

    const-string/jumbo v1, "o.nn2b-/x8edvivpv.d"

    const-string/jumbo v1, "video/x-vnd.on2.vp8"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-void
.end method

.method public static disableVp9HwCodec()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "rdocseueCdMdoeDoVidcai"

    const-string v0, "cesdodceadeMCdeDiriVoo"

    const/4 v3, 0x6

    const-string v0, "cciMiDdpeoroeVeCddeeao"

    const-string v0, "MediaCodecVideoDecoder"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v1, "bdoiltdVq eliniPcyeo9 paiip dbm .nd aagc"

    const-string v1, "by migd9 V idcopao p.salPiitncediael bnd"

    const/4 v3, 0x0

    const-string v1, "Vds a9  se.bndlnld oatipdpbyiii gcPaoeic"

    const-string v1, "VP9 decoding is disabled by application."

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "donm..on9iev/vo-dxp"

    const-string/jumbo v1, "vi.pon-.xno/dvo2de9"

    const/4 v3, 0x7

    const-string/jumbo v1, "p/nooevdx9.-ido.2vn"

    const-string/jumbo v1, "video/x-vnd.on2.vp9"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method private static findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;
    .locals 13

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "b cHtb dofgiir y drnneWmToeire o md"

    const-string v1, "  deobdyiHe Tfrnmt c omgini rrodfWe"

    const-string/jumbo v1, "io ginudT   fmyedcWeftd rroHm ion e"

    const-string v1, "Trying to find HW decoder for mime "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "cracMedpiuoeVeDioCeedo"

    const-string/jumbo v1, "roiieeuoaDcMedVdCdoece"

    const-string/jumbo v1, "oiedMocoqieedeDVrCeacd"

    const-string v1, "MediaCodecVideoDecoder"

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const-string/jumbo v0, "iosvevpda"

    const-string v0, "/dvveoipa"

    const-string/jumbo v0, "iv/maodec"

    const-string/jumbo v0, "video/avc"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const-string/jumbo v2, "l: qood"

    const-string/jumbo v2, "oq:e dl"

    const-string v2, "Md oeb:"

    const-string v2, "Model: "

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-interface {v0, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo p1, "sdhds ueksdole.6rc2 Hct.ib4ale a"

    const-string p1, " .s. d seaHh4c 6kdtsal2roibeledc"

    const-string p1, "d lidbcpstace4s6h.oa eH l k2erd "

    const-string p1, " has black listed H.264 decoder."

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v3

    :cond_0
    const-string v0, "cveme/ihdo"

    const-string/jumbo v0, "video/hevc"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-interface {v0, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "2 ed o.cqsaodit l.ed5kbhH6 resla"

    const-string/jumbo p1, "kH  oh5sab.dd lc6rai  leeoe.2dst"

    const-string/jumbo p1, "s2s6dccda  t .5 Hk.dlsaliheeboe "

    const-string p1, " has black listed H.265 decoder."

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v3

    :cond_1
    const/4 v0, 0x0

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    :goto_0
    :try_start_0
    invoke-static {}, Landroid/media/MediaCodecList;->getCodecCount()I

    move-result v4

    if-ge v2, v4, :cond_10

    invoke-static {v2}, Landroid/media/MediaCodecList;->getCodecInfoAt(I)Landroid/media/MediaCodecInfo;

    move-result-object v4

    invoke-virtual {v4}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v5

    if-eqz v5, :cond_2

    goto/16 :goto_a

    :cond_2
    invoke-virtual {v4}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v5

    array-length v6, v5

    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    :goto_1
    if-ge v7, v6, :cond_4

    aget-object v8, v5, v7

    invoke-virtual {v8, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_3

    invoke-virtual {v4}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v5

    goto :goto_2

    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto :goto_1

    :cond_4
    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    :goto_2
    if-nez v5, :cond_5

    goto/16 :goto_a

    :cond_5
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, " nemaudFeibatoeddr docdc"

    const-string/jumbo v7, "tdeaFbi dondddeucoera  c"

    const-string v7, "edcFou naiodaeon td ddre"

    const-string v7, "Found candidate decoder "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v1, v6}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    sget-boolean v6, Lcom/zego/ve/MediaCodecVideoDecoder;->enableWhitelist:Z

    const/4 v7, 0x1

    if-eqz v6, :cond_8

    array-length v6, p1

    move v8, v0

    :goto_3
    if-ge v8, v6, :cond_7

    aget-object v9, p1, v8

    invoke-virtual {v5, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_6

    goto :goto_6

    :cond_6
    add-int/lit8 v8, v8, 0x1

    goto :goto_3

    :cond_7
    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    goto :goto_6

    :cond_8
    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    sget-object v8, Lcom/zego/ve/MediaCodecVideoDecoder;->HW_BLACKLISTS:[Ljava/lang/String;

    array-length v9, v8

    move v10, v0

    move v10, v0

    move v10, v0

    :goto_4
    if-ge v10, v9, :cond_a

    aget-object v11, v8, v10

    invoke-virtual {v6, v11}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_9

    move v6, v7

    move v6, v7

    move v6, v7

    move v6, v7

    goto :goto_5

    :cond_9
    add-int/lit8 v10, v10, 0x1

    goto :goto_4

    :cond_a
    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    :goto_5
    xor-int/2addr v7, v6

    :goto_6
    if-nez v7, :cond_b

    goto/16 :goto_a

    :cond_b
    invoke-virtual {v4, p0}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object v4

    iget-object v6, v4, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length v7, v6

    move v8, v0

    move v8, v0

    move v8, v0

    move v8, v0

    :goto_7
    if-ge v8, v7, :cond_c

    aget v9, v6, v8

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "o:rl bux0"

    const-string v11, " 0:lxruoo"

    const-string/jumbo v11, "o0rxlCu: "

    const-string v11, "Color: 0x"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v9}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v1, v9}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    add-int/lit8 v8, v8, 0x1

    goto :goto_7

    :cond_c
    array-length v6, p2

    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    :goto_8
    if-ge v7, v6, :cond_f

    aget v8, p2, v7

    iget-object v9, v4, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length v10, v9

    move v11, v0

    move v11, v0

    move v11, v0

    move v11, v0

    :goto_9
    if-ge v11, v10, :cond_e

    aget v12, v9, v11

    if-ne v12, v8, :cond_d

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "dde toFpocdr rp eaeut"

    const-string/jumbo p2, "r  nuoep ddtdaotFecre"

    const-string/jumbo p2, "uac e neqdtdF edtgroo"

    const-string p2, "Found target decoder "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "Cqs:.r  oox"

    const-string p2, "C: .orx0q o"

    const-string p2, "0lrm.ox : C"

    const-string p2, ". Color: 0x"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v12}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    new-instance p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    invoke-direct {p1, v5, v12}, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;-><init>(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    return-object p1

    :cond_d
    add-int/lit8 v11, v11, 0x1

    goto :goto_9

    :cond_e
    add-int/lit8 v7, v7, 0x1

    goto :goto_8

    :cond_f
    :goto_a
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_0

    :catch_0
    move-exception p1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_10
    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "dmieo rsWd o doenf  muecNor o"

    const-string/jumbo p2, "uosfNome df dreienod oW m cr "

    const-string p2, "  fcrbWem dr fm  HNeonuiodeoo"

    const-string p2, "No HW decoder found for mime "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    return-object v3
.end method

.method private flush()V
    .locals 5

    const/4 v4, 0x1

    const-string/jumbo v0, "uvDmJacoaehsf rde"

    const/4 v4, 0x2

    const-string v0, "Jefodvurcauls eDh"

    const-string v0, "Java flushDecoder"

    const-string v1, "eMrdocepCieDdeaiVoedoo"

    const-string v1, "eeoaooedrdCecVoiediDMc"

    const/4 v4, 0x5

    const-string v1, "eDdardedqoeCcoVMeiceid"

    const-string v1, "MediaCodecVideoDecoder"

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    goto :goto_1

    :cond_0
    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/media/MediaCodec;->flush()V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v2, "elsbaesddriff a Mloceddhui"

    const-string/jumbo v2, "ro ufbh ldiddeiaefcel Mads"

    const/4 v4, 0x1

    const-string v2, "Mr miofafddidscehuea ldeel"

    const-string v2, "Media decoder flush failed"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void

    :cond_1
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "Jaedoevya esderdol sa fuehu raeral"

    const-string v0, " lrhrousvcdfeealee aae duJsad raye"

    const/4 v4, 0x6

    const-string/jumbo v0, "ualdhba  rceeeaeeslvrreyolf sdadJa"

    const-string v0, "Java decoder flush already release"

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public static getCodecName()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedH264HwCodecPrefixes:[Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v2, "dcvv/iuea"

    const-string/jumbo v2, "video/avc"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v2, v0, v1}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, v0, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method private getColorFormat(ILjava/lang/Object;)I
    .locals 6

    const/4 v0, 0x0

    const/4 v0, 0x4

    const/4 v5, 0x6

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p1, :cond_4

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v3, "64h2"

    const-string v3, "2h46"

    const-string v3, "2h46"

    const-string/jumbo v3, "h264"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eq p1, v2, :cond_2

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v2, 0x3

    const/4 v5, 0x1

    if-eq p1, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 p1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto/16 :goto_3

    :cond_0
    const/4 v5, 0x0

    sget-object p1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedHEVCHwCodecPrefixes:[Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz p2, :cond_1

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    move v0, v1

    move v0, v1

    const/4 v5, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v2, "vedvhcipe/"

    const-string v2, "cev/hvepdi"

    const/4 v5, 0x0

    const-string v2, "deeciohvq/"

    const-string/jumbo v2, "video/hevc"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p0, v2, p1, v0}, Lcom/zego/ve/MediaCodecVideoDecoder;->getDecoderInfo(Ljava/lang/String;[Ljava/lang/String;Z)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v3, "echv"

    const-string/jumbo v3, "evch"

    const/4 v5, 0x5

    const-string/jumbo v3, "hvec"

    const-string/jumbo v3, "hevc"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_3

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object p1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedH264HwCodecPrefixes:[Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p2, :cond_3

    const/4 v4, 0x3

    and-int/2addr v5, v4

    goto :goto_1

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x6

    move v0, v1

    move v0, v1

    const/4 v5, 0x5

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v2, "d/sevciqa"

    const-string v2, "d/eicavvq"

    const/4 v5, 0x6

    const-string v2, "acimv/vdo"

    const-string/jumbo v2, "video/avc"

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-direct {p0, v2, p1, v0}, Lcom/zego/ve/MediaCodecVideoDecoder;->getDecoderInfo(Ljava/lang/String;[Ljava/lang/String;Z)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_3

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object p1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedVp8HwCodecPrefixes:[Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz p2, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_2

    :cond_5
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    move v0, v1

    move v0, v1

    const/4 v5, 0x5

    move v0, v1

    move v0, v1

    :goto_2
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v2, "en.-oxd.vsd/novv8op"

    const-string v2, ".-s2vo.dnvodnve8/xp"

    const/4 v5, 0x2

    const-string/jumbo v2, "ov2v8bxviep.n.nd-od"

    const-string/jumbo v2, "video/x-vnd.on2.vp8"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {p0, v2, p1, v0}, Lcom/zego/ve/MediaCodecVideoDecoder;->getDecoderInfo(Ljava/lang/String;[Ljava/lang/String;Z)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v3, "vp8"

    const-string/jumbo v3, "p8v"

    const/4 v5, 0x4

    const-string v3, "8pv"

    const-string/jumbo v3, "vp8"

    :goto_3
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez p1, :cond_6

    const/4 v4, 0x7

    or-int/2addr v5, v4

    return v1

    :cond_6
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget v0, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-class v1, Landroid/media/ImageReader;

    const-class v1, Landroid/media/ImageReader;

    const/4 v5, 0x5

    const-class v1, Landroid/media/ImageReader;

    const-class v1, Landroid/media/ImageReader;

    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, p2}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz p2, :cond_7

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object p2, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v1, "OXM"

    const-string v1, "OXM"

    const/4 v5, 0x5

    const-string v1, "OXM"

    const-string v1, "OMX"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz p2, :cond_7

    const/4 v4, 0x4

    or-int/2addr v5, v4

    const v0, 0x7f420888

    :cond_7
    const/4 v5, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, " goermutceo,t:FradoomlC"

    const-string/jumbo v1, "o omoetcCmFd:rarog,let "

    const/4 v5, 0x7

    const-string/jumbo v1, "oetoc epmFCr: gl,ooctra"

    const-string/jumbo v1, "getColorFormat, codec: "

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const-string/jumbo v1, "x rloCooq0"

    const-string/jumbo v1, "r0o ol xoC"

    const/4 v5, 0x1

    const-string v1, ":os lCr0 x"

    const-string v1, " Color: 0x"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    iget p1, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const-string/jumbo p2, "oddmacicbeederiMeoVoCD"

    const-string p2, "coDcibidMoaodreeeedCdV"

    const/4 v5, 0x5

    const-string p2, "McerodieoDcdoaeVeidodC"

    const-string p2, "MediaCodecVideoDecoder"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p2, p1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v4, 0x5

    const/4 v5, 0x4

    return v0
.end method

.method private getDecoderInfo(Ljava/lang/String;[Ljava/lang/String;Z)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;
    .locals 12

    const/4 v11, 0x7

    const-string v0, "deocubvva"

    const-string/jumbo v0, "vvc/eduoa"

    const-string/jumbo v0, "eviac/uvd"

    const-string/jumbo v0, "video/avc"

    const/4 v11, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x6

    const-string/jumbo v1, "pdo leM"

    const-string v1, "Model: "

    const/4 v11, 0x4

    const-string v2, "eocCpVrcqedDidoieaeMdo"

    const-string/jumbo v2, "oeeiCoDpVarcdMicedeodd"

    const-string v2, "desadoMrdCeeodociicVeD"

    const-string v2, "MediaCodecVideoDecoder"

    const/4 v11, 0x4

    const/4 v3, 0x0

    const/4 v11, 0x1

    if-eqz v0, :cond_0

    const/4 v11, 0x5

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->H264_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v11, 0x5

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v11, 0x2

    invoke-interface {v0, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x4

    if-eqz v0, :cond_1

    const/4 v11, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const-string/jumbo p2, "so meb cti.ds acale. l4d h2dq6re"

    const-string p2, "  a.cdb.qsr4dleced6h ksetol2ai  "

    const-string p2, "dk  o.shcdtale 24oesdeHa 6 .libc"

    const-string p2, " has black listed H.264 decoder."

    const/4 v11, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x0

    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-object v3

    :cond_0
    const/4 v11, 0x4

    const-string/jumbo v0, "evohvbsdc/"

    const-string/jumbo v0, "oesevdvh/c"

    const-string/jumbo v0, "iceeh/uovd"

    const-string/jumbo v0, "video/hevc"

    const/4 v11, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x4

    if-eqz v0, :cond_1

    const/4 v11, 0x0

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->H265_HW_EXCEPTION_MODELS:[Ljava/lang/String;

    const/4 v11, 0x2

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v4, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const/4 v11, 0x4

    invoke-interface {v0, v4}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v11, 0x1

    if-eqz v0, :cond_1

    const/4 v11, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const-string/jumbo p2, "sdce .rp aelsad5b6 d 2oH. klhtci"

    const-string p2, " has black listed H.265 decoder."

    const/4 v11, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x5

    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v11, 0x0

    return-object v3

    :cond_1
    const/4 v0, 0x0

    move v11, v0

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    :try_start_0
    const/4 v11, 0x0

    invoke-static {}, Landroid/media/MediaCodecList;->getCodecCount()I

    move-result v2

    const/4 v11, 0x4

    if-ge v1, v2, :cond_11

    const/4 v11, 0x4

    invoke-static {v1}, Landroid/media/MediaCodecList;->getCodecInfoAt(I)Landroid/media/MediaCodecInfo;

    move-result-object v2

    const/4 v11, 0x4

    invoke-virtual {v2}, Landroid/media/MediaCodecInfo;->isEncoder()Z

    move-result v4

    const/4 v11, 0x6

    if-eqz v4, :cond_2

    const/4 v11, 0x0

    goto/16 :goto_7

    :cond_2
    const/4 v11, 0x0

    invoke-virtual {v2}, Landroid/media/MediaCodecInfo;->getSupportedTypes()[Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x4

    array-length v5, v4

    const/4 v11, 0x7

    move v6, v0

    move v6, v0

    move v6, v0

    move v6, v0

    :goto_1
    const/4 v11, 0x7

    if-ge v6, v5, :cond_4

    const/4 v11, 0x0

    aget-object v7, v4, v6

    const/4 v11, 0x5

    invoke-virtual {v7, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    const/4 v11, 0x7

    if-eqz v7, :cond_3

    const/4 v11, 0x1

    invoke-virtual {v2}, Landroid/media/MediaCodecInfo;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    goto :goto_2

    :cond_3
    const/4 v11, 0x4

    add-int/lit8 v6, v6, 0x1

    const/4 v11, 0x7

    goto :goto_1

    :cond_4
    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    :goto_2
    const/4 v11, 0x7

    if-nez v4, :cond_5

    const/4 v11, 0x1

    goto :goto_7

    :cond_5
    const/4 v11, 0x7

    sget-boolean v5, Lcom/zego/ve/MediaCodecVideoDecoder;->enableWhitelist:Z

    const/4 v11, 0x7

    const/4 v6, 0x1

    const/4 v11, 0x5

    if-eqz v5, :cond_8

    const/4 v11, 0x2

    array-length v5, p2

    const/4 v11, 0x7

    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    :goto_3
    const/4 v11, 0x7

    if-ge v7, v5, :cond_7

    const/4 v11, 0x5

    aget-object v8, p2, v7

    const/4 v11, 0x2

    invoke-virtual {v4, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v8

    const/4 v11, 0x7

    if-eqz v8, :cond_6

    goto :goto_6

    :cond_6
    const/4 v11, 0x0

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x7

    goto :goto_3

    :cond_7
    const/4 v11, 0x6

    move v6, v0

    move v6, v0

    const/4 v11, 0x2

    goto :goto_6

    :cond_8
    const/4 v11, 0x0

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x2

    sget-object v7, Lcom/zego/ve/MediaCodecVideoDecoder;->HW_BLACKLISTS:[Ljava/lang/String;

    const/4 v11, 0x2

    array-length v8, v7

    const/4 v11, 0x2

    move v9, v0

    move v9, v0

    move v9, v0

    move v9, v0

    :goto_4
    const/4 v11, 0x6

    if-ge v9, v8, :cond_a

    const/4 v11, 0x2

    aget-object v10, v7, v9

    const/4 v11, 0x4

    invoke-virtual {v5, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    const/4 v11, 0x5

    if-eqz v10, :cond_9

    move v5, v6

    move v5, v6

    move v5, v6

    const/4 v11, 0x1

    goto :goto_5

    :cond_9
    add-int/lit8 v9, v9, 0x1

    const/4 v11, 0x3

    goto :goto_4

    :cond_a
    const/4 v11, 0x1

    move v5, v0

    move v5, v0

    move v5, v0

    move v5, v0

    :goto_5
    const/4 v11, 0x0

    xor-int/2addr v6, v5

    :goto_6
    const/4 v11, 0x3

    if-nez v6, :cond_b

    :goto_7
    const/4 v11, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_b
    const/4 v11, 0x0

    invoke-virtual {v2, p1}, Landroid/media/MediaCodecInfo;->getCapabilitiesForType(Ljava/lang/String;)Landroid/media/MediaCodecInfo$CodecCapabilities;

    move-result-object p1

    const/4 v11, 0x2

    if-eqz p3, :cond_d

    const/4 v11, 0x2

    iget-object p2, p1, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length p3, p2

    const/4 v11, 0x6

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_8
    const/4 v11, 0x7

    if-ge v1, p3, :cond_10

    const/4 v11, 0x2

    aget v2, p2, v1

    const/4 v11, 0x2

    const/high16 v5, 0x70000000

    const/4 v11, 0x6

    if-lt v2, v5, :cond_c

    const/4 v11, 0x0

    new-instance p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    const/4 v11, 0x3

    invoke-direct {p1, v4, v2}, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;-><init>(Ljava/lang/String;I)V

    const/4 v11, 0x3

    return-object p1

    :cond_c
    const/4 v11, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x1

    goto :goto_8

    :cond_d
    const/4 v11, 0x0

    iget-object p2, p1, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    array-length p3, p2

    const/4 v11, 0x5

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_9
    const/4 v11, 0x4

    if-ge v1, p3, :cond_10

    aget v2, p2, v1

    const/4 v11, 0x6

    sget-object v5, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const/4 v11, 0x4

    array-length v6, v5

    const/4 v11, 0x6

    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    :goto_a
    const/4 v11, 0x4

    if-ge v7, v6, :cond_f

    const/4 v11, 0x7

    aget v8, v5, v7

    const/4 v11, 0x1

    if-ne v2, v8, :cond_e

    const/4 v11, 0x7

    new-instance p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    const/4 v11, 0x6

    invoke-direct {p1, v4, v2}, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;-><init>(Ljava/lang/String;I)V

    const/4 v11, 0x7

    return-object p1

    :cond_e
    const/4 v11, 0x0

    add-int/lit8 v7, v7, 0x1

    const/4 v11, 0x1

    goto :goto_a

    :cond_f
    const/4 v11, 0x1

    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_10
    new-instance p2, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    iget-object p1, p1, Landroid/media/MediaCodecInfo$CodecCapabilities;->colorFormats:[I

    const/4 v11, 0x0

    aget p1, p1, v0

    const/4 v11, 0x3

    invoke-direct {p2, v4, p1}, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;-><init>(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x2

    return-object p2

    :catch_0
    move-exception p1

    const/4 v11, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_11
    const/4 v11, 0x7

    return-object v3
.end method

.method private getSurface(Ljava/lang/Object;II)Landroid/view/Surface;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-class v0, Landroid/graphics/SurfaceTexture;

    const-class v0, Landroid/graphics/SurfaceTexture;

    const/4 v3, 0x1

    const-class v0, Landroid/graphics/SurfaceTexture;

    const-class v0, Landroid/graphics/SurfaceTexture;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-boolean v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->isImageReader:Z

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast p1, Landroid/graphics/SurfaceTexture;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/16 v1, 0x18

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-lt v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1, p2, p3}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance p2, Landroid/view/Surface;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p2, p1}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    const/4 v3, 0x0

    iput-object p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-class p2, Landroid/media/ImageReader;

    const-class p2, Landroid/media/ImageReader;

    const/4 v3, 0x1

    const-class p2, Landroid/media/ImageReader;

    const-class p2, Landroid/media/ImageReader;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p2, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p2, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-boolean p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->isImageReader:Z

    const/4 v2, 0x2

    move v3, v2

    check-cast p1, Landroid/media/ImageReader;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    :cond_2
    :goto_0
    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1
.end method

.method private initDecode(IIILjava/nio/ByteBuffer;Ljava/lang/Object;Z)Z
    .locals 9

    const-string/jumbo v0, "finmieodq aecdltD"

    const-string/jumbo v0, "icemeiDdnf itdlao"

    const-string v0, "eDsct fdinildeoea"

    const-string/jumbo v0, "initDecode failed"

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v2, 0x0

    if-eqz v1, :cond_0

    return v2

    :cond_0
    const/4 v1, 0x0

    if-eqz p1, :cond_3

    const/4 v3, 0x2

    const-string v4, "624h"

    const-string/jumbo v4, "h624"

    const-string/jumbo v4, "h264"

    if-eq p1, v3, :cond_2

    const/4 v3, 0x3

    if-eq p1, v3, :cond_1

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    goto :goto_0

    :cond_1
    sget-object p1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedHEVCHwCodecPrefixes:[Ljava/lang/String;

    sget-object v3, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const-string v4, "civmd/veoh"

    const-string/jumbo v4, "ohv/odciev"

    const-string v4, "eihvo/oedv"

    const-string/jumbo v4, "video/hevc"

    invoke-static {v4, p1, v3}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p1

    const-string/jumbo v3, "hecv"

    const-string v3, "cehv"

    const-string/jumbo v3, "hevc"

    const-string/jumbo v3, "hevc"

    goto :goto_0

    :cond_2
    sget-object p1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedH264HwCodecPrefixes:[Ljava/lang/String;

    sget-object v3, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const-string/jumbo v5, "vbdcebvoa"

    const-string/jumbo v5, "vcaodbive"

    const-string v5, "edvicvu/o"

    const-string/jumbo v5, "video/avc"

    invoke-static {v5, p1, v3}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p1

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    goto :goto_0

    :cond_3
    sget-object p1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedVp8HwCodecPrefixes:[Ljava/lang/String;

    sget-object v3, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const-string/jumbo v4, "vdio.8upn2en.x/vd-v"

    const-string/jumbo v4, "ixv.o.u8odedn/vn-2v"

    const-string v4, ".vvxnod.qi2vpend8/o"

    const-string/jumbo v4, "video/x-vnd.on2.vp8"

    invoke-static {v4, p1, v3}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p1

    const-string/jumbo v3, "vp8"

    const-string/jumbo v3, "p8v"

    const-string/jumbo v3, "p8v"

    const-string/jumbo v3, "vp8"

    :goto_0
    if-nez p1, :cond_4

    return v2

    :cond_4
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "oasce ,cc Jvi: deetonipa"

    const-string/jumbo v6, "odec:Japiei vondtcc,ea  "

    const-string v6, "Java initDecode, codec: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "xo mCrl qo"

    const-string v6, "Cor l oxq0"

    const-string/jumbo v6, "x0C:or  ol"

    const-string v6, " Color: 0x"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v6, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    invoke-static {v6}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const-string v6, "CcsoMeeodcaioiDdederVe"

    const-string v6, "edceeboCaodDreeidVoidc"

    const-string v6, "MediaCodecVideoDecoder"

    invoke-static {v6, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    sput-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->runningInstance:Lcom/zego/ve/MediaCodecVideoDecoder;

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v5

    iput-object v5, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    :try_start_0
    invoke-static {v4, p2, p3}, Landroid/media/MediaFormat;->createVideoFormat(Ljava/lang/String;II)Landroid/media/MediaFormat;

    move-result-object v4
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Error; {:try_start_0 .. :try_end_0} :catch_0

    const-string v5, "amfmltrc-roo"

    const-string/jumbo v5, "rloftourmca-"

    const-string v5, "color-format"

    const/4 v7, 0x1

    if-nez p5, :cond_5

    :try_start_1
    iget p5, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    invoke-virtual {v4, v5, p5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    goto :goto_2

    :cond_5
    const-class v8, Landroid/graphics/SurfaceTexture;

    const-class v8, Landroid/graphics/SurfaceTexture;

    const-class v8, Landroid/graphics/SurfaceTexture;

    const-class v8, Landroid/graphics/SurfaceTexture;

    invoke-virtual {v8, p5}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_7

    iput-boolean v2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->isImageReader:Z

    check-cast p5, Landroid/graphics/SurfaceTexture;

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v8, 0x18

    if-lt v5, v8, :cond_6

    invoke-virtual {p5, p2, p3}, Landroid/graphics/SurfaceTexture;->setDefaultBufferSize(II)V

    :cond_6
    new-instance v5, Landroid/view/Surface;

    invoke-direct {v5, p5}, Landroid/view/Surface;-><init>(Landroid/graphics/SurfaceTexture;)V

    iput-object v5, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    goto :goto_2

    :cond_7
    const-class v8, Landroid/media/ImageReader;

    const-class v8, Landroid/media/ImageReader;

    const-class v8, Landroid/media/ImageReader;

    const-class v8, Landroid/media/ImageReader;

    invoke-virtual {v8, p5}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_9

    iput-boolean v7, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->isImageReader:Z

    check-cast p5, Landroid/media/ImageReader;

    invoke-virtual {p5}, Landroid/media/ImageReader;->getSurface()Landroid/view/Surface;

    move-result-object p5

    iput-object p5, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    iget-object p5, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    const-string v8, "MXO"

    const-string v8, "OXM"

    const-string v8, "XMO"

    const-string v8, "OMX"

    invoke-virtual {p5, v8}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p5

    if-eqz p5, :cond_8

    const p5, 0x7f420888

    goto :goto_1

    :cond_8
    iget p5, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    :goto_1
    invoke-virtual {v4, v5, p5}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    :cond_9
    :goto_2
    if-eqz p4, :cond_a

    const-string/jumbo p5, "ocpd0"

    const-string p5, "0scdo"

    const-string p5, "-cdqs"

    const-string p5, "csd-0"

    invoke-virtual {v4, p5, p4}, Landroid/media/MediaFormat;->setByteBuffer(Ljava/lang/String;Ljava/nio/ByteBuffer;)V

    :cond_a
    new-instance p4, Ljava/lang/StringBuilder;

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const-string p5, " bstar:F"

    const-string p5, "a tFob:r"

    const-string p5, ":rFmm ta"

    const-string p5, "Format: "

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p4, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    invoke-static {v6, p4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    iget-object p4, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    invoke-static {p4}, Lcom/zego/ve/MediaCodecVideoEncoder;->createByCodecName(Ljava/lang/String;)Landroid/media/MediaCodec;

    move-result-object p4

    iput-object p4, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    if-nez p4, :cond_b

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "edt odemtandir ceea:e oaCc u r"

    const-string/jumbo p2, "ric dmuratC: n atdaedeoeen ce "

    const-string p2, "a  ceb: atar red deoidcCmtnnee"

    const-string p2, "Can not create media decoder: "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v6, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/Error; {:try_start_1 .. :try_end_1} :catch_0

    return v2

    :cond_b
    const-string/jumbo p4, "pOXhiMui"

    const-string/jumbo p4, "isXOMihp"

    const-string/jumbo p4, "sOXMhi.p"

    const-string p4, "OMX.hisi"

    if-eqz p6, :cond_c

    :try_start_2
    iget-object p5, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    invoke-virtual {p5, p4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p5

    if-eqz p5, :cond_c

    const-string/jumbo p5, "yxwlodenqs-avolcld-yt-ovrooeninr.cfrdeeieveoe.-eeid-cqltsheq--ianw-c-"

    const-string p5, "-trdolovq-coanidd-tinev-.vyiedxrc.soe--eaitewc--rcfhwleoleqoene-lynse"

    const-string p5, "c-sexwlclovwdnlreeidlrsiio.cnnodite-qhvreooovnytec.a----f---yee-aesed"

    const-string/jumbo p5, "vendor.hisi-ext-low-latency-video-dec.video-scene-for-low-latency-req"

    invoke-virtual {v4, p5, v7}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string p5, "daxm-idsn.i-owln-oe-eet-ee.civlvelyyoer-wdfotdctsoc--n-read-ihnevsocy"

    const-string/jumbo p5, "n-st-i-ietsxofrocyvhnrtylveeoedwd--o--w.ecolna.-ad-scrlvdie-iocendyee"

    const-string/jumbo p5, "vendor.hisi-ext-low-latency-video-dec.video-scene-for-low-latency-rdy"

    const/4 v3, -0x1

    invoke-virtual {v4, p5, v3}, Landroid/media/MediaFormat;->setInteger(Ljava/lang/String;I)V

    const-string p5, " mwhosteicnliol"

    const-string/jumbo p5, "icsm nhleolwtyi"

    const-string/jumbo p5, "tl iwbsinachelo"

    const-string/jumbo p5, "hisi lowlatency"

    invoke-static {v6, p5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_c
    iget-object p5, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    invoke-virtual {p5, v4, v3, v1, v2}, Landroid/media/MediaCodec;->configure(Landroid/media/MediaFormat;Landroid/view/Surface;Landroid/media/MediaCrypto;I)V

    iget-object p5, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {p5}, Landroid/media/MediaCodec;->start()V

    iget-object p5, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    iput-object p5, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->codecName:Ljava/lang/String;

    iget p1, p1, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->colorFormat:I

    iput p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->colorFormat:I

    iput-boolean v2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->hasDecodedFirstFrame:Z

    iput p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->width:I

    iput p3, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->height:I

    if-eqz p6, :cond_d

    invoke-virtual {p5, p4}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_d

    new-instance p1, Landroid/os/Bundle;

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo p2, "oeyacnut-lw"

    const-string/jumbo p2, "t-weoynocla"

    const-string/jumbo p2, "l-ocnalpywt"

    const-string/jumbo p2, "low-latency"

    invoke-virtual {p1, p2, v7}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    iget-object p2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    invoke-virtual {p2, p1}, Landroid/media/MediaCodec;->setParameters(Landroid/os/Bundle;)V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/Error; {:try_start_2 .. :try_end_2} :catch_0

    :cond_d
    return v7

    :catch_0
    move-exception p1

    invoke-static {v6, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    invoke-static {}, Lcom/zego/ve/MediaCodecVideoDecoder;->printStackTrace()V

    return v2

    :catch_1
    move-exception p1

    invoke-static {v6, v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return v2
.end method

.method public static isH264HwSupported(Z)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-boolean p0, Lcom/zego/ve/MediaCodecVideoDecoder;->enableWhitelist:Z

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const-string/jumbo v0, "vdoi/beav"

    const/4 v3, 0x1

    const-string v0, "dviv/eaoq"

    const-string/jumbo v0, "video/avc"

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedH264HwCodecPrefixes:[Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0, p0, v1}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 p0, 0x1

    move v3, p0

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p0
.end method

.method public static isH264HwSupportedUsingTextures()Z
    .locals 11

    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedH264HwCodecPrefixes:[Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    sget-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedSurfaceColorList:[I

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string/jumbo v2, "uvsveoacd"

    const-string v2, "avvoecudi"

    const-string/jumbo v2, "video/avc"

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v2, v0, v1}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v3, 0x1

    const/4 v10, 0x3

    if-eqz v0, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x0

    sget-object v4, Lcom/zego/ve/MediaCodecVideoDecoder;->HW_SURFACE_BLACKLISTS:[Ljava/lang/String;

    const/4 v9, 0x4

    shr-int/2addr v10, v9

    array-length v5, v4

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    move v6, v1

    move v6, v1

    const/4 v10, 0x7

    move v6, v1

    move v6, v1

    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-ge v6, v5, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    aget-object v7, v4, v6

    const/4 v10, 0x3

    iget-object v8, v0, Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;->codecName:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v8, v7}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v7

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v7, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto :goto_1

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    add-int/lit8 v6, v6, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto :goto_0

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    move v4, v3

    move v4, v3

    const/4 v10, 0x5

    move v4, v3

    move v4, v3

    const/4 v9, 0x2

    move v10, v9

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    move v4, v1

    move v4, v1

    const/4 v10, 0x4

    move v4, v1

    move v4, v1

    :goto_2
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    sget-object v5, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {v5, v2}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez v2, :cond_3

    const/4 v9, 0x3

    move v10, v9

    if-eqz v0, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz v4, :cond_3

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    move v1, v3

    move v1, v3

    const/4 v10, 0x2

    move v1, v3

    move v1, v3

    :cond_3
    const/4 v10, 0x0

    return v1
.end method

.method public static isHEVCHwSupported(Z)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-boolean p0, Lcom/zego/ve/MediaCodecVideoDecoder;->enableWhitelist:Z

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x7

    const-string v0, "/pcmidehve"

    const-string/jumbo v0, "vie/chdpve"

    const-string/jumbo v0, "vvcio/eoed"

    const-string/jumbo v0, "video/hevc"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedHEVCHwCodecPrefixes:[Ljava/lang/String;

    const/4 v2, 0x7

    move v3, v2

    sget-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const/4 v2, 0x1

    move v3, v2

    invoke-static {v0, p0, v1}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 p0, 0x0

    move v3, p0

    :goto_0
    const/4 v2, 0x1

    return p0
.end method

.method public static isVp8HwSupported(Z)Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v0, ".e./o82pqv-vddvonni"

    const/4 v3, 0x6

    const-string v0, "doedxb/.28-pvvi.onv"

    const-string/jumbo v0, "video/x-vnd.on2.vp8"

    const/4 v3, 0x5

    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedVp8HwCodecPrefixes:[Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-static {v0, p0, v1}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p0
.end method

.method public static isVp9HwSupported(Z)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->hwDecoderDisabledTypes:Ljava/util/Set;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "evno.vups2-x/.niodv"

    const-string v0, "eos2/dvv.9o.ixnvn-p"

    const/4 v3, 0x2

    const-string v0, "dp.x2dvpive.n/v9oon"

    const-string/jumbo v0, "video/x-vnd.on2.vp9"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-interface {p0, v0}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    sget-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedVp9HwCodecPrefixes:[Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v1, Lcom/zego/ve/MediaCodecVideoDecoder;->supportedColorList:[I

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {v0, p0, v1}, Lcom/zego/ve/MediaCodecVideoDecoder;->findDecoder(Ljava/lang/String;[Ljava/lang/String;[I)Lcom/zego/ve/MediaCodecVideoDecoder$DecoderProperties;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 p0, 0x1

    move v3, p0

    const/4 v2, 0x7

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x2

    return p0
.end method

.method public static printStackTrace()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x6

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->runningInstance:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v0, v0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    array-length v1, v0

    const/4 v6, 0x0

    if-lez v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v1, "dtrcete qedde:mM idocacsicoeCaVeoskr"

    const-string v1, "dtemedakerCceoidceioadrco:VeMsc ta s"

    const/4 v6, 0x4

    const-string v1, "dssdtrdeiekecee aceciadocrCDo:to Mas"

    const-string v1, "MediaCodecVideoDecoder stacks trace:"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string v2, "edomdoriceeoCVDddMaoce"

    const-string/jumbo v2, "iodooDcadeMVeeecedodCr"

    const/4 v6, 0x2

    const-string/jumbo v2, "oedMoecdrCoDeodiVaeeic"

    const-string v2, "MediaCodecVideoDecoder"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v2, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    array-length v1, v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-ge v3, v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    aget-object v4, v0, v3

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v2, v4}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void
.end method

.method private queueConfig(II)Z
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v0, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/4 v1, 0x1

    :try_start_0
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p0, v1, p1}, Lcom/zego/ve/MediaCodecVideoDecoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x1

    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v2, p2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v10, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/4 v5, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x1

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    const/4 v9, 0x2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    move v4, p1

    move v4, p1

    const/4 v11, 0x6

    move v4, p1

    move v4, p1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    move v6, p2

    move v6, p2

    const/4 v11, 0x3

    move v6, p2

    move v6, p2

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual/range {v3 .. v9}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x4

    const/4 v11, 0x1

    return v1

    :catch_0
    move-exception p1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const-string p2, "VDeoebecddoeModCiarbde"

    const-string p2, "edodibodeDaercMVcdeeCo"

    const/4 v11, 0x7

    const-string p2, "dceModuocCVeeoirdeDdae"

    const-string p2, "MediaCodecVideoDecoder"

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string v1, "daef odpieucd"

    const-string v1, "eieadoudefc d"

    const/4 v11, 0x3

    const-string v1, "acieoedeq dfd"

    const-string v1, "decode failed"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-static {p2, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    return v0
.end method

.method private queueEOS(I)Z
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v0, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v1, 0x0

    :try_start_0
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {p0, v0, p1}, Lcom/zego/ve/MediaCodecVideoDecoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v2, v1}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v5, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/4 v6, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x4

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/4 v9, 0x4

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    move v4, p1

    move v4, p1

    const/4 v11, 0x0

    move v4, p1

    move v4, p1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual/range {v3 .. v9}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    return v0

    :catch_0
    move-exception p1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string v0, "eosedoeiecdredCMcoiaVp"

    const-string/jumbo v0, "oeVaodrpoeceeidCdceiMd"

    const/4 v11, 0x7

    const-string v0, "adMmeVcoiereDcoededodC"

    const-string v0, "MediaCodecVideoDecoder"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string v2, "edddo felqceo"

    const-string/jumbo v2, "fdde aeoqcled"

    const/4 v11, 0x0

    const-string v2, " ieadbdeflcdo"

    const-string v2, "decode failed"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v0, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    return v1
.end method

.method private queueInputBuffer(IIJ)Z
    .locals 11

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    const/4 v10, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    move v10, v1

    move v10, v1

    :try_start_0
    invoke-virtual {p0, v1, p1}, Lcom/zego/ve/MediaCodecVideoDecoder;->getByteBuffer(ZI)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v10, 0x7

    invoke-virtual {v2, v0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    const/4 v10, 0x2

    invoke-virtual {v2, p2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    const/4 v10, 0x5

    iget-object v3, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v10, 0x6

    const/4 v5, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    move v4, p1

    move v4, p1

    move v4, p1

    move v4, p1

    const/4 v10, 0x0

    move v6, p2

    move v6, p2

    move v6, p2

    move v6, p2

    move-wide v7, p3

    const/4 v10, 0x5

    invoke-virtual/range {v3 .. v9}, Landroid/media/MediaCodec;->queueInputBuffer(IIIJI)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x2

    return v1

    :catch_0
    move-exception p1

    const/4 v10, 0x3

    const-string/jumbo p2, "rdoiodueceeCscDeddMVeo"

    const-string p2, "ddsereeMeoodVoeDcidcaC"

    const-string p2, "edrCDedpiodeioMecdeVoa"

    const-string p2, "MediaCodecVideoDecoder"

    const/4 v10, 0x0

    const-string p3, "aeld fdoqemid"

    const-string/jumbo p3, "iaomeledfd ed"

    const-string p3, "decode failed"

    const/4 v10, 0x7

    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v10, 0x0

    return v0
.end method

.method private release()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v0, " rsroeleeJeecsaaDda"

    const-string v0, "Java releaseDecoder"

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v1, "eDdcoeodecadoioeCrVied"

    const/4 v6, 0x2

    const-string v1, "edMmrdcCoeeeVdcideiaDo"

    const-string v1, "MediaCodecVideoDecoder"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v0, v2}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v3, Lcom/zego/ve/MediaCodecVideoDecoder$1;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v3, p0, v0}, Lcom/zego/ve/MediaCodecVideoDecoder$1;-><init>(Lcom/zego/ve/MediaCodecVideoDecoder;Ljava/util/concurrent/CountDownLatch;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    new-instance v4, Ljava/lang/Thread;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {v4, v3}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v4}, Ljava/lang/Thread;->start()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-wide/16 v3, 0x1388

    const-wide/16 v3, 0x1388

    const/4 v6, 0x7

    const-wide/16 v3, 0x1388

    const-wide/16 v3, 0x1388

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v3, v4}, Lcom/zego/ve/ThreadUtils;->awaitUninterruptibly(Ljava/util/concurrent/CountDownLatch;J)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez v0, :cond_1

    const/4 v5, 0x1

    move v6, v5

    const-string v0, "cbioou l rarMedmaeetsoediedte"

    const-string/jumbo v0, "tdl aboeriercatseidoeeuMdem  "

    const/4 v6, 0x1

    const-string/jumbo v0, "ide lbatoeeer osdMca ueeimder"

    const-string v0, "Media decoder release timeout"

    const/4 v6, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    sget v0, Lcom/zego/ve/MediaCodecVideoDecoder;->codecErrors:I

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/2addr v0, v2

    const/4 v6, 0x0

    sput v0, Lcom/zego/ve/MediaCodecVideoDecoder;->codecErrors:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->errorCallback:Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "csno:eulcEro .cke o krbaa rdIov crrrl"

    const-string v2, "Invoke codec error callback. Errors: "

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    sget v2, Lcom/zego/ve/MediaCodecVideoDecoder;->codecErrors:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->errorCallback:Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;

    const/4 v5, 0x7

    move v6, v5

    sget v2, Lcom/zego/ve/MediaCodecVideoDecoder;->codecErrors:I

    const/4 v5, 0x7

    move v6, v5

    invoke-interface {v0, v2}, Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;->onMediaCodecVideoDecoderCriticalError(I)V

    :cond_1
    const/4 v6, 0x5

    const/4 v0, 0x7

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodecThread:Ljava/lang/Thread;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    sput-object v0, Lcom/zego/ve/MediaCodecVideoDecoder;->runningInstance:Lcom/zego/ve/MediaCodecVideoDecoder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v0, "cnereoepaelJver Dd aased"

    const-string v0, "Java releaseDecoder done"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-void

    :cond_2
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v0, "acavear qdseJlld rdouy eraae"

    const-string v0, "aal yJuoedreaac searedrled v"

    const/4 v6, 0x7

    const-string v0, "desora eaeyrdd raeclJsele va"

    const-string v0, "Java decoder already release"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method

.method public static setErrorCallback(Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;)V
    .locals 4

    const/4 v3, 0x0

    const-string v0, "eidmoepVMorocCdiedeDad"

    const-string/jumbo v0, "oeMcCoipieaoeedVerddDd"

    const/4 v3, 0x7

    const-string v0, "DMCeoeareddecdcoooiide"

    const-string v0, "MediaCodecVideoDecoder"

    const/4 v3, 0x0

    const-string v1, "bcrcSbokrltqealear"

    const-string/jumbo v1, "tScceeorqlklrra ab"

    const/4 v3, 0x0

    const-string/jumbo v1, "raclerutoer kbSalc"

    const-string v1, "Set error callback"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    sput-object p0, Lcom/zego/ve/MediaCodecVideoDecoder;->errorCallback:Lcom/zego/ve/MediaCodecVideoDecoder$MediaCodecVideoDecoderErrorCallback;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method private surfaceIsImageReader(Ljava/lang/Object;)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const-class v0, Landroid/media/ImageReader;

    const-class v0, Landroid/media/ImageReader;

    const/4 v2, 0x5

    const-class v0, Landroid/media/ImageReader;

    const-class v0, Landroid/media/ImageReader;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    return p1
.end method


# virtual methods
.method getByteBuffer(ZI)Ljava/nio/ByteBuffer;
    .locals 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Landroid/media/MediaCodec;->getInputBuffer(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Landroid/media/MediaCodec;->getOutputBuffer(I)Ljava/nio/ByteBuffer;

    move-result-object p1

    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p1
.end method

.method public returnDecodedOutputBuffer(I)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->surface:Landroid/view/Surface;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    move v2, v3

    move v2, v3

    const/4 v5, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    move v2, v0

    move v2, v0

    const/4 v5, 0x4

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, p1, v2}, Landroid/media/MediaCodec;->releaseOutputBuffer(IZ)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    return v3

    :catch_0
    move-exception p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "CdeiecdpioMeeoVodrsDad"

    const-string v1, "cisdodiMeVeDoeedacCord"

    const/4 v5, 0x0

    const-string v1, "VdCeicdeqieDodMocoedae"

    const-string v1, "MediaCodecVideoDecoder"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v2, "uesetde telBaerflursuimffO"

    const-string/jumbo v2, "reumfiffaletduselaOuB rete"

    const/4 v5, 0x7

    const-string v2, "arfm lBtiuufaeereufsOedpel"

    const-string/jumbo v2, "releaseOutputBuffer failed"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v5, 0x4

    return v0
.end method

.method public returnDecodedOutputBufferWithTS(IJ)Z
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/zego/ve/MediaCodecVideoDecoder;->checkOnMediaCodecThread()V

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/zego/ve/MediaCodecVideoDecoder;->mediaCodec:Landroid/media/MediaCodec;

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2, p3}, Landroid/media/MediaCodec;->releaseOutputBuffer(IJ)V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return p1

    :catch_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo p2, "ieeMoorioeddeCacdVDcoe"

    const-string/jumbo p2, "iedDoMVeoecaeediroddCc"

    const/4 v2, 0x0

    const-string p2, "MediaCodecVideoDecoder"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo p3, "ttalubeOdBielfeueureapfsr "

    const-string/jumbo p3, "releaseOutputBuffer failed"

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p2, p3, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return p1
.end method
