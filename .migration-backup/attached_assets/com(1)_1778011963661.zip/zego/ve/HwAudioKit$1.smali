.class Lcom/zego/ve/HwAudioKit$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/HwAudioKit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/zego/ve/HwAudioKit;


# direct methods
.method constructor <init>(Lcom/zego/ve/HwAudioKit;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s~@@~sooK~@bi@ ~.@Mv@   @~co@~~     @/@~uoi4~l@bS@@ @@ @~1od l@~ ~~~bf /-mt~f~~a~~~~ r@yn ti@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p2}, Lcom/zego/ve/IHwAudioEngine$Stub;->asInterface(Landroid/os/IBinder;)Lcom/zego/ve/IHwAudioEngine;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKit;->access$002(Lcom/zego/ve/HwAudioKit;Lcom/zego/ve/IHwAudioEngine;)Lcom/zego/ve/IHwAudioEngine;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/zego/ve/HwAudioKit;->access$000(Lcom/zego/ve/HwAudioKit;)Lcom/zego/ve/IHwAudioEngine;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    or-int/2addr v3, v2

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKit;->access$102(Lcom/zego/ve/HwAudioKit;Z)Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/zego/ve/HwAudioKit;->access$200(Lcom/zego/ve/HwAudioKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/zego/ve/HwAudioKit;->access$300(Lcom/zego/ve/HwAudioKit;)Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v1, ".10m1"

    const-string v1, "01s1."

    const/4 v3, 0x4

    const-string v1, "..11o"

    const-string v1, "1.0.1"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1, v0, v1}, Lcom/zego/ve/HwAudioKit;->access$400(Lcom/zego/ve/HwAudioKit;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, p2}, Lcom/zego/ve/HwAudioKit;->access$500(Lcom/zego/ve/HwAudioKit;Landroid/os/IBinder;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKit;->access$002(Lcom/zego/ve/HwAudioKit;Lcom/zego/ve/IHwAudioEngine;)Lcom/zego/ve/IHwAudioEngine;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/zego/ve/HwAudioKit;->access$102(Lcom/zego/ve/HwAudioKit;Z)Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object p1, p0, Lcom/zego/ve/HwAudioKit$1;->this$0:Lcom/zego/ve/HwAudioKit;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/zego/ve/HwAudioKit;->access$200(Lcom/zego/ve/HwAudioKit;)Lcom/zego/ve/FeatureKitManager;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lcom/zego/ve/FeatureKitManager;->onCallBack(I)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method
