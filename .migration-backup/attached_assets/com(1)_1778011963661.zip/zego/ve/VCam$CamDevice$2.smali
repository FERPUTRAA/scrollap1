.class Lcom/zego/ve/VCam$CamDevice$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/zego/ve/VCam$CamDevice;->stopCam()I
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lcom/zego/ve/VCam$CamDevice;

.field final synthetic val$done:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam$CamDevice;Ljava/util/concurrent/CountDownLatch;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/zego/ve/VCam$CamDevice$2;->this$1:Lcom/zego/ve/VCam$CamDevice;

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/zego/ve/VCam$CamDevice$2;->val$done:Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const-string v0, "cpav"

    const-string/jumbo v0, "pcva"

    const-string/jumbo v0, "vcpa"

    const-string/jumbo v0, "vcap"

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, " wsvtopc areentre:d oaplvhaeissre e"

    const-string/jumbo v1, "v sesas  wldrnteetc:oroe avheaepipr"

    const/4 v3, 0x6

    const-string/jumbo v1, "vlam ePvprsir:nhttw e  aopoeseedcer"

    const-string/jumbo v1, "vcap: stopPreview on release thread"

    const/4 v3, 0x3

    const/4 v2, 0x6

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/zego/ve/VCam$CamDevice$2;->this$1:Lcom/zego/ve/VCam$CamDevice;

    const/4 v3, 0x1

    invoke-static {v1}, Lcom/zego/ve/VCam$CamDevice;->access$800(Lcom/zego/ve/VCam$CamDevice;)Landroid/hardware/Camera;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1}, Landroid/hardware/Camera;->stopPreview()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v1, "a:p onodeeveeem adoriPs eplh ra votswcne"

    const-string v1, "edamrvwdeeiov en Pnsotaeae tpr: coheslp "

    const/4 v3, 0x7

    const-string v1, "ae:rpbaaheoe ee Ptero vsrn vo tnlwddiepc"

    const-string/jumbo v1, "vcap: stopPreview on release thread done"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "valpPwusft:ecpoer d aevi"

    const-string/jumbo v1, "pseooaevcvPpd l :irwetaf"

    const-string/jumbo v1, "fvare vppiwPtepda:eolcsi"

    const-string/jumbo v1, "vcap: stopPreview failed"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/zego/ve/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/zego/ve/VCam$CamDevice$2;->val$done:Ljava/util/concurrent/CountDownLatch;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method
