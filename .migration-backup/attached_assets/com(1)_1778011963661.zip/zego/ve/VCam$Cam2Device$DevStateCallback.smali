.class Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;
.super Landroid/hardware/camera2/CameraDevice$StateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/zego/ve/VCam$Cam2Device;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "DevStateCallback"
.end annotation


# instance fields
.field final synthetic this$1:Lcom/zego/ve/VCam$Cam2Device;


# direct methods
.method constructor <init>(Lcom/zego/ve/VCam$Cam2Device;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/hardware/camera2/CameraDevice$StateCallback;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public onClosed(Landroid/hardware/camera2/CameraDevice;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "m s@@i@i ~@~M~  @@o@~o 1~v@@@@a~roo @@~4 ~@S@d@./~l~ @~ o b~~~fn~ fb~b ~ /~-s ~~@t o~~yi@u@ clt "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    const-string/jumbo p1, "vacp"

    const-string p1, "cavp"

    const/4 v2, 0x4

    const-string/jumbo p1, "vcpa"

    const-string/jumbo p1, "vcap"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const-string/jumbo v0, "l  mdpCacorasvmeecnas"

    const-string v0, "drscaacmp  Csea:nevol"

    const/4 v2, 0x1

    const-string v0, "d: oolvceasCepaan cmo"

    const-string/jumbo v0, "vcap: camera onClosed"

    const/4 v2, 0x5

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lcom/zego/ve/VCam$Cam2Device;->access$1402(Lcom/zego/ve/VCam$Cam2Device;Z)Z

    const/4 v1, 0x0

    move v2, v1

    return-void
.end method

.method public onDisconnected(Landroid/hardware/camera2/CameraDevice;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo p1, "vcap"

    const-string/jumbo p1, "pavc"

    const/4 v2, 0x7

    const-string p1, "cpva"

    const-string/jumbo p1, "vcap"

    const/4 v2, 0x3

    const-string v0, "ancvmb ceetnrD:c caoepaiond"

    const-string/jumbo v0, "vcap: camera onDisconnected"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/zego/ve/VCam$Cam2Device;->access$1402(Lcom/zego/ve/VCam$Cam2Device;Z)Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public onError(Landroid/hardware/camera2/CameraDevice;I)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "neaaaEuprr:mc rvromco"

    const-string/jumbo v0, "r amEr:rmraeoo vnpacc"

    const/4 v2, 0x0

    const-string/jumbo v0, "vcap: camera onError "

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "vapc"

    const-string/jumbo v0, "vcap"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p1, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eq p2, p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p1, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-ne p2, p1, :cond_1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object p1, p1, Lcom/zego/ve/VCam$Cam2Device;->this$0:Lcom/zego/ve/VCam;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lcom/zego/ve/VCam;->access$1602(Lcom/zego/ve/VCam;Z)Z

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public onOpened(Landroid/hardware/camera2/CameraDevice;)V
    .locals 4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/zego/ve/VCam$Cam2Device;->access$1402(Lcom/zego/ve/VCam$Cam2Device;Z)Z

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/zego/ve/VCam$Cam2Device$DevStateCallback;->this$1:Lcom/zego/ve/VCam$Cam2Device;

    const/4 v3, 0x0

    const/4 v2, 0x4

    iput-object p1, v0, Lcom/zego/ve/VCam$Cam2Device;->mCamDevice:Landroid/hardware/camera2/CameraDevice;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/zego/ve/VCam$Cam2Device;->access$1500(Lcom/zego/ve/VCam$Cam2Device;)Ljava/util/concurrent/Semaphore;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method
